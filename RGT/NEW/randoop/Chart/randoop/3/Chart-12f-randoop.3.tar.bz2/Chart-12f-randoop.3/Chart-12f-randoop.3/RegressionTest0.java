import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int1 = color0.getRGB();
        java.awt.Stroke stroke2 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        try {
            org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke2, rectangleInsets3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-32640) + "'", int1 == (-32640));
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        try {
            defaultKeyedValues2D1.removeColumn((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        piePlot1.setDataset(pieDataset2);
        org.jfree.chart.block.Arrangement arrangement4 = null;
        org.jfree.chart.block.Arrangement arrangement5 = null;
        try {
            org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, arrangement4, arrangement5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int1 = color0.getBlue();
        java.awt.color.ColorSpace colorSpace2 = null;
        float[] floatArray3 = new float[] {};
        try {
            float[] floatArray4 = color0.getColorComponents(colorSpace2, floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int3 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 10);
        try {
            java.lang.Number number6 = defaultKeyedValues2D1.getValue((java.lang.Comparable) (-1.0f), (java.lang.Comparable) 10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 10");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("hi!", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int3 = java.awt.Color.HSBtoRGB((float) (byte) -1, 0.0f, (float) 10L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-10) + "'", int3 == (-10));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.plot.Plot plot2 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("", font1, plot2, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        try {
            java.awt.Color color1 = java.awt.Color.decode("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int3 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 10);
        try {
            java.lang.Comparable comparable5 = defaultKeyedValues2D1.getRowKey((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double5 = rectangleInsets4.getBottom();
        piePlot1.setSimpleLabelOffset(rectangleInsets4);
        double double7 = rectangleInsets4.getTop();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        try {
            defaultKeyedValues2D1.removeColumn((java.lang.Comparable) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: 10");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        java.awt.Paint paint3 = null;
        try {
            piePlot1.setBaseSectionOutlinePaint(paint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int3 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 10);
        java.lang.Comparable comparable5 = null;
        try {
            defaultKeyedValues2D1.addValue((java.lang.Number) (-1.0d), comparable5, (java.lang.Comparable) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int1 = color0.getBlue();
        java.awt.Color color2 = color0.darker();
        int int3 = color2.getRed();
        java.awt.color.ColorSpace colorSpace4 = null;
        float[] floatArray6 = new float[] { (-1.0f) };
        try {
            float[] floatArray7 = color2.getColorComponents(colorSpace4, floatArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 89 + "'", int3 == 89);
        org.junit.Assert.assertNotNull(floatArray6);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str2 = projectInfo1.toString();
        java.util.List list3 = projectInfo1.getContributors();
        boolean boolean4 = standardPieSectionLabelGenerator0.equals((java.lang.Object) projectInfo1);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list2 = defaultKeyedValues2D1.getColumnKeys();
        java.util.List list3 = defaultKeyedValues2D1.getRowKeys();
        java.lang.Object obj4 = defaultKeyedValues2D1.clone();
        java.lang.Comparable comparable6 = null;
        try {
            defaultKeyedValues2D1.addValue((java.lang.Number) 0.4d, comparable6, (java.lang.Comparable) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 89, 1, (java.lang.Comparable) '4', "", "hi!");
        java.awt.Shape shape8 = null;
        try {
            pieSectionEntity7.setArea(shape8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double5 = rectangleInsets4.getBottom();
        piePlot1.setSimpleLabelOffset(rectangleInsets4);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets4.createInsetRectangle(rectangle2D7, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        float float4 = piePlot1.getBackgroundAlpha();
        piePlot1.setSectionOutlinesVisible(true);
        piePlot1.setIgnoreNullValues(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double10 = rectangleInsets9.getBottom();
        piePlot1.setSimpleLabelOffset(rectangleInsets9);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Point2D point2D14 = null;
        org.jfree.chart.plot.PlotState plotState15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            piePlot1.draw(graphics2D12, rectangle2D13, point2D14, plotState15, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(89);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        double double5 = piePlot4.getMaximumExplodePercent();
        double double6 = piePlot4.getShadowYOffset();
        piePlot4.setPieIndex((int) (short) 100);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot4.getLegendLabelGenerator();
        try {
            objectList1.set((int) (byte) -1, (java.lang.Object) pieSectionLabelGenerator9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleAnchor.CENTER", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 100.0d, (double) '4');
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        float float4 = piePlot1.getBackgroundAlpha();
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Stroke stroke8 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) (-32640));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNull(stroke8);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("{0}", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 89, 1, (java.lang.Comparable) '4', "", "hi!");
        pieSectionEntity7.setPieIndex((int) (short) 10);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator10 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator11 = null;
        try {
            java.lang.String str12 = pieSectionEntity7.getImageMapAreaTag(toolTipTagFragmentGenerator10, uRLTagFragmentGenerator11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot1, jFreeChart4);
        piePlot1.setExplodePercent((java.lang.Comparable) true, (double) (short) 1);
        java.awt.Font font10 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        double double13 = piePlot12.getMaximumExplodePercent();
        double double14 = piePlot12.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets15.getBottom();
        piePlot12.setSimpleLabelOffset(rectangleInsets15);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font10, (org.jfree.chart.plot.Plot) piePlot12, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D21 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list22 = defaultKeyedValues2D21.getColumnKeys();
        java.util.List list23 = defaultKeyedValues2D21.getRowKeys();
        jFreeChart19.setSubtitles(list23);
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart19);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.awt.geom.Point2D point2D28 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = null;
        try {
            jFreeChart19.draw(graphics2D26, rectangle2D27, point2D28, chartRenderingInfo29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(list23);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        piePlot1.setBackgroundAlpha(0.0f);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int8 = color7.getRGB();
        java.awt.Color color9 = color7.darker();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int11 = color10.getBlue();
        java.awt.Color color12 = color10.darker();
        boolean boolean13 = color9.equals((java.lang.Object) color12);
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) (short) 100, (java.awt.Paint) color9);
        float[] floatArray18 = null;
        float[] floatArray19 = java.awt.Color.RGBtoHSB((int) (byte) 1, 15, (int) (short) -1, floatArray18);
        float[] floatArray20 = color9.getRGBComponents(floatArray18);
        int int21 = color9.getAlpha();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-32640) + "'", int8 == (-32640));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 255 + "'", int21 == 255);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        float float4 = piePlot1.getBackgroundImageAlpha();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle5 = piePlot1.getLabelLinkStyle();
        java.lang.Object obj6 = piePlot1.clone();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = null;
        try {
            piePlot1.setLegendLabelGenerator(pieSectionLabelGenerator7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.5f + "'", float4 == 0.5f);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("hi!", font2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = textTitle3.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment4, (double) (byte) -1, (-1.0d));
        java.lang.String str8 = verticalAlignment4.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "VerticalAlignment.CENTER" + "'", str8.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle2.getVerticalAlignment();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = textTitle2.arrange(graphics2D4, rectangleConstraint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment3);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.awt.Color color1 = null;
        java.awt.Color color2 = java.awt.Color.getColor("", color1);
        org.junit.Assert.assertNull(color2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        try {
            java.awt.Color color1 = java.awt.Color.decode("Pie Plot");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Pie Plot\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 89, 1, (java.lang.Comparable) '4', "", "hi!");
        pieSectionEntity7.setPieIndex((int) (short) 10);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        pieSectionEntity7.setDataset(pieDataset10);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator12 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator13 = null;
        try {
            java.lang.String str14 = pieSectionEntity7.getImageMapAreaTag(toolTipTagFragmentGenerator12, uRLTagFragmentGenerator13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list14);
        java.awt.RenderingHints renderingHints16 = jFreeChart10.getRenderingHints();
        org.jfree.chart.event.ChartChangeListener chartChangeListener17 = null;
        try {
            jFreeChart10.addChangeListener(chartChangeListener17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(renderingHints16);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list2 = defaultKeyedValues2D1.getColumnKeys();
        int int4 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 100.0f);
        try {
            java.lang.Comparable comparable6 = defaultKeyedValues2D1.getColumnKey((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = null;
        try {
            org.jfree.chart.util.Size2D size2D5 = textTitle2.arrange(graphics2D3, rectangleConstraint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 15, (double) (short) 10, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.awt.Color color0 = java.awt.Color.white;
        java.lang.Class<?> wildcardClass1 = color0.getClass();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "hi!", "");
        java.lang.String str6 = basicProjectInfo5.getCopyright();
        basicProjectInfo5.setCopyright("RectangleAnchor.CENTER");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot1, jFreeChart4);
        piePlot1.setExplodePercent((java.lang.Comparable) true, (double) (short) 1);
        java.awt.Font font10 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        double double13 = piePlot12.getMaximumExplodePercent();
        double double14 = piePlot12.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets15.getBottom();
        piePlot12.setSimpleLabelOffset(rectangleInsets15);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font10, (org.jfree.chart.plot.Plot) piePlot12, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D21 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list22 = defaultKeyedValues2D21.getColumnKeys();
        java.util.List list23 = defaultKeyedValues2D21.getRowKeys();
        jFreeChart19.setSubtitles(list23);
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart19);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D27 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list28 = defaultKeyedValues2D27.getColumnKeys();
        java.util.List list29 = defaultKeyedValues2D27.getRowKeys();
        jFreeChart19.setSubtitles(list29);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNotNull(list29);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.toString();
        java.util.List list2 = projectInfo0.getContributors();
        java.lang.String str3 = projectInfo0.getLicenceText();
        projectInfo0.setInfo("VerticalAlignment.CENTER");
        projectInfo0.addOptionalLibrary("RectangleAnchor.CENTER");
        org.jfree.chart.ui.ProjectInfo projectInfo8 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str9 = projectInfo8.toString();
        java.util.List list10 = projectInfo8.getContributors();
        projectInfo0.setContributors(list10);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(projectInfo8);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        int int3 = java.awt.Color.HSBtoRGB(0.0f, (float) 3, 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list14);
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("hi!", font17);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle18.getVerticalAlignment();
        java.lang.Object obj20 = textTitle18.clone();
        jFreeChart10.removeSubtitle((org.jfree.chart.title.Title) textTitle18);
        org.jfree.chart.title.TextTitle textTitle22 = null;
        jFreeChart10.setTitle(textTitle22);
        boolean boolean24 = jFreeChart10.isBorderVisible();
        java.awt.Paint paint25 = jFreeChart10.getBackgroundPaint();
        java.awt.Font font28 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("hi!", font28);
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = textTitle29.getVerticalAlignment();
        java.lang.Object obj31 = textTitle29.clone();
        try {
            jFreeChart10.addSubtitle((int) (byte) 1, (org.jfree.chart.title.Title) textTitle29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(verticalAlignment30);
        org.junit.Assert.assertNotNull(obj31);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.util.TableOrder tableOrder0 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        java.lang.String str1 = tableOrder0.toString();
        java.lang.String str2 = tableOrder0.toString();
        org.junit.Assert.assertNotNull(tableOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TableOrder.BY_COLUMN" + "'", str1.equals("TableOrder.BY_COLUMN"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TableOrder.BY_COLUMN" + "'", str2.equals("TableOrder.BY_COLUMN"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.awt.Color color2 = java.awt.Color.getColor("RectangleAnchor.CENTER", (int) (byte) 1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createInsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) '#');
        pieLabelDistributor1.distributeLabels((double) (-1L), (double) (-1L));
        pieLabelDistributor1.distributeLabels((double) (byte) -1, 100.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot1, jFreeChart4);
        piePlot1.setExplodePercent((java.lang.Comparable) true, (double) (short) 1);
        java.awt.Shape shape9 = piePlot1.getLegendItemShape();
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint12 = lineBorder11.getPaint();
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) 0.08d, paint12);
        double double14 = piePlot1.getMinimumArcAngleToDraw();
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0E-5d + "'", double14 == 1.0E-5d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str1.equals("Rotation.ANTICLOCKWISE"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D3 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list4 = defaultKeyedValues2D3.getColumnKeys();
        java.util.List list5 = defaultKeyedValues2D3.getRowKeys();
        projectInfo0.setContributors(list5);
        projectInfo0.setLicenceText("Pie Plot");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list2 = defaultKeyedValues2D1.getColumnKeys();
        java.lang.Comparable comparable4 = null;
        try {
            java.lang.Number number5 = defaultKeyedValues2D1.getValue((java.lang.Comparable) 1L, comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.0f, 0.0f, (float) (byte) 100);
        java.awt.color.ColorSpace colorSpace4 = null;
        float[] floatArray11 = new float[] { 128, (-1L), 100.0f, 128, 1L, 10.0f };
        try {
            float[] floatArray12 = color3.getComponents(colorSpace4, floatArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        java.lang.String str3 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        piePlot1.setPieIndex((int) (short) 100);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        double double8 = piePlot7.getMaximumExplodePercent();
        double double9 = piePlot7.getShadowYOffset();
        float float10 = piePlot7.getBackgroundAlpha();
        piePlot1.setParent((org.jfree.chart.plot.Plot) piePlot7);
        piePlot7.setShadowXOffset(0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        piePlot1.setBackgroundAlpha(0.0f);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = piePlot1.getLegendItems();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(legendItemCollection6);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray11 = new float[] { 100.0f, 100L, (-1), (byte) 100, (-10), (short) 100 };
        float[] floatArray12 = java.awt.Color.RGBtoHSB((int) '4', 0, (int) 'a', floatArray11);
        try {
            float[] floatArray13 = color0.getComponents(colorSpace1, floatArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot1, jFreeChart4);
        piePlot1.setExplodePercent((java.lang.Comparable) true, (double) (short) 1);
        java.awt.Shape shape9 = piePlot1.getLegendItemShape();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment10, verticalAlignment11, (double) (short) 1, (-1.0d));
        columnArrangement14.clear();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int18 = color17.getBlue();
        java.awt.Color color19 = java.awt.Color.getColor("", color17);
        boolean boolean20 = columnArrangement14.equals((java.lang.Object) color19);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment22 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement25 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment21, verticalAlignment22, (double) (short) 1, (-1.0d));
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) columnArrangement14, (org.jfree.chart.block.Arrangement) columnArrangement25);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double29 = rectangleInsets28.getBottom();
        java.awt.Font font31 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("hi!", font31);
        org.jfree.chart.util.VerticalAlignment verticalAlignment33 = textTitle32.getVerticalAlignment();
        java.lang.Object obj34 = textTitle32.clone();
        textTitle32.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D37 = textTitle32.getBounds();
        rectangleInsets28.trim(rectangle2D37);
        try {
            legendTitle26.draw(graphics2D27, rectangle2D37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(verticalAlignment33);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(rectangle2D37);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        float float4 = piePlot1.getBackgroundImageAlpha();
        double double5 = piePlot1.getMinimumArcAngleToDraw();
        java.awt.Paint paint7 = piePlot1.getSectionPaint((java.lang.Comparable) (-1.0f));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.5f + "'", float4 == 0.5f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-5d + "'", double5 == 1.0E-5d);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle2.getPadding();
        double double4 = rectangleInsets3.getLeft();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        piePlot1.setPieIndex((int) (short) 100);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot1.getLegendLabelGenerator();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.Font font9 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle10.getPadding();
        java.awt.Font font13 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("hi!", font13);
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = textTitle14.getVerticalAlignment();
        java.lang.Object obj16 = textTitle14.clone();
        textTitle14.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = textTitle14.getBounds();
        java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets11.createInsetRectangle(rectangle2D19);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.Object obj22 = null;
        boolean boolean23 = rectangleEdge21.equals(obj22);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D25 = new org.jfree.data.DefaultKeyedValues2D(false);
        boolean boolean26 = rectangleEdge21.equals((java.lang.Object) false);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge21);
        double double28 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D19, rectangleEdge21);
        java.awt.geom.Point2D point2D29 = null;
        org.jfree.chart.plot.PlotState plotState30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        try {
            piePlot1.draw(graphics2D7, rectangle2D19, point2D29, plotState30, plotRenderingInfo31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(verticalAlignment15);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.lang.String str1 = verticalAlignment0.toString();
        java.lang.String str2 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VerticalAlignment.TOP" + "'", str1.equals("VerticalAlignment.TOP"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VerticalAlignment.TOP" + "'", str2.equals("VerticalAlignment.TOP"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) '#');
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = pieLabelDistributor1.getPieLabelRecord((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot1, jFreeChart4);
        java.lang.Object obj6 = chartChangeEvent5.getSource();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        boolean boolean9 = chartChangeEventType7.equals((java.lang.Object) 10L);
        chartChangeEvent5.setType(chartChangeEventType7);
        java.lang.Object obj11 = chartChangeEvent5.getSource();
        java.lang.String str12 = chartChangeEvent5.toString();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        piePlot1.setBackgroundImageAlpha(0.0f);
        java.awt.Color color5 = java.awt.Color.RED;
        piePlot1.setShadowPaint((java.awt.Paint) color5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double8 = rectangleInsets7.getBottom();
        double double10 = rectangleInsets7.trimWidth((double) 0L);
        double double12 = rectangleInsets7.calculateBottomInset((double) (byte) -1);
        piePlot1.setInsets(rectangleInsets7);
        double double15 = rectangleInsets7.calculateRightOutset((double) 1L);
        double double17 = rectangleInsets7.calculateRightOutset((double) 255);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list14);
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("hi!", font17);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle18.getVerticalAlignment();
        java.lang.Object obj20 = textTitle18.clone();
        jFreeChart10.removeSubtitle((org.jfree.chart.title.Title) textTitle18);
        org.jfree.chart.title.TextTitle textTitle22 = null;
        jFreeChart10.setTitle(textTitle22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double25 = rectangleInsets24.getBottom();
        double double27 = rectangleInsets24.calculateTopOutset((double) 0.0f);
        java.lang.String str28 = rectangleInsets24.toString();
        jFreeChart10.setPadding(rectangleInsets24);
        org.jfree.chart.ui.ProjectInfo projectInfo30 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray31 = projectInfo30.getOptionalLibraries();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D33 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list34 = defaultKeyedValues2D33.getColumnKeys();
        java.util.List list35 = defaultKeyedValues2D33.getRowKeys();
        projectInfo30.setContributors(list35);
        jFreeChart10.setSubtitles(list35);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo40 = null;
        try {
            java.awt.image.BufferedImage bufferedImage41 = jFreeChart10.createBufferedImage((int) ' ', 0, chartRenderingInfo40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (32) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str28.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNotNull(projectInfo30);
        org.junit.Assert.assertNotNull(libraryArray31);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(list35);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Font font3 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("hi!", font3);
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = textTitle4.getVerticalAlignment();
        java.lang.Object obj6 = textTitle4.clone();
        textTitle4.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle4.getBounds();
        java.awt.geom.Rectangle2D rectangle2D10 = textTitle4.getBounds();
        try {
            blockBorder0.draw(graphics2D1, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangle2D10);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            defaultCategoryDataset0.removeColumn((-10));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list14);
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("hi!", font17);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle18.getVerticalAlignment();
        java.lang.Object obj20 = textTitle18.clone();
        jFreeChart10.removeSubtitle((org.jfree.chart.title.Title) textTitle18);
        org.jfree.chart.title.TextTitle textTitle22 = null;
        jFreeChart10.setTitle(textTitle22);
        boolean boolean24 = jFreeChart10.isBorderVisible();
        java.awt.Paint paint25 = jFreeChart10.getBackgroundPaint();
        java.util.List list26 = jFreeChart10.getSubtitles();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(list26);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(89);
        java.lang.Object obj2 = objectList1.clone();
        objectList1.clear();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int7 = color6.getRGB();
        java.awt.Color color8 = java.awt.Color.getColor("", color6);
        java.awt.Paint[] paintArray9 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        boolean boolean10 = color6.equals((java.lang.Object) paintArray9);
        objectList1.set(0, (java.lang.Object) paintArray9);
        java.lang.Object obj13 = null;
        objectList1.set(3, obj13);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-32640) + "'", int7 == (-32640));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        try {
            defaultKeyedValues2D1.removeRow((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list14);
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("hi!", font17);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle18.getVerticalAlignment();
        java.lang.Object obj20 = textTitle18.clone();
        jFreeChart10.removeSubtitle((org.jfree.chart.title.Title) textTitle18);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.Font font24 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("hi!", font24);
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = textTitle25.getVerticalAlignment();
        java.lang.Object obj27 = textTitle25.clone();
        textTitle25.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle25.getBounds();
        try {
            jFreeChart10.draw(graphics2D22, rectangle2D30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(verticalAlignment26);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(rectangle2D30);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot1, jFreeChart4);
        piePlot1.setExplodePercent((java.lang.Comparable) true, (double) (short) 1);
        java.awt.Shape shape9 = piePlot1.getLegendItemShape();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment10, verticalAlignment11, (double) (short) 1, (-1.0d));
        columnArrangement14.clear();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int18 = color17.getBlue();
        java.awt.Color color19 = java.awt.Color.getColor("", color17);
        boolean boolean20 = columnArrangement14.equals((java.lang.Object) color19);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment22 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement25 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment21, verticalAlignment22, (double) (short) 1, (-1.0d));
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) columnArrangement14, (org.jfree.chart.block.Arrangement) columnArrangement25);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        try {
            java.lang.Object obj30 = legendTitle26.draw(graphics2D27, rectangle2D28, (java.lang.Object) (-10));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int2 = color1.getRGB();
        java.awt.Color color3 = java.awt.Color.getColor("", color1);
        int int4 = color1.getBlue();
        int int5 = color1.getRGB();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-32640) + "'", int2 == (-32640));
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-32640) + "'", int5 == (-32640));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        java.lang.Object obj1 = paintMap0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot1, jFreeChart4);
        piePlot1.setExplodePercent((java.lang.Comparable) true, (double) (short) 1);
        java.awt.Stroke stroke9 = piePlot1.getLabelLinkStroke();
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle2.getVerticalAlignment();
        textTitle2.setText("Pie Plot");
        java.lang.Object obj6 = textTitle2.clone();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = null;
        try {
            org.jfree.chart.util.Size2D size2D9 = textTitle2.arrange(graphics2D7, rectangleConstraint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray2 = projectInfo1.getOptionalLibraries();
        org.jfree.chart.ui.Library library7 = new org.jfree.chart.ui.Library("", "", "hi!", "hi!");
        projectInfo1.addLibrary(library7);
        projectInfo0.addOptionalLibrary(library7);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(libraryArray2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot1, jFreeChart4);
        piePlot1.setExplodePercent((java.lang.Comparable) true, (double) (short) 1);
        java.awt.Font font10 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        double double13 = piePlot12.getMaximumExplodePercent();
        double double14 = piePlot12.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets15.getBottom();
        piePlot12.setSimpleLabelOffset(rectangleInsets15);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font10, (org.jfree.chart.plot.Plot) piePlot12, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D21 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list22 = defaultKeyedValues2D21.getColumnKeys();
        java.util.List list23 = defaultKeyedValues2D21.getRowKeys();
        jFreeChart19.setSubtitles(list23);
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart19);
        float float26 = jFreeChart19.getBackgroundImageAlpha();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = null;
        try {
            java.awt.image.BufferedImage bufferedImage31 = jFreeChart19.createBufferedImage((int) (byte) 1, 0, 0, chartRenderingInfo30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.5f + "'", float26 == 0.5f);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        textTitle2.setText("PieLabelLinkStyle.STANDARD");
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        java.awt.Font font4 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("hi!", font4);
        piePlot1.setLabelFont(font4);
        boolean boolean7 = piePlot1.isCircular();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list2 = defaultKeyedValues2D1.getColumnKeys();
        int int4 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 100.0f);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) (-1L), (java.lang.Comparable) 100.0f);
        java.awt.Font font9 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        double double12 = piePlot11.getMaximumExplodePercent();
        double double13 = piePlot11.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double15 = rectangleInsets14.getBottom();
        piePlot11.setSimpleLabelOffset(rectangleInsets14);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font9, (org.jfree.chart.plot.Plot) piePlot11, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D20 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list21 = defaultKeyedValues2D20.getColumnKeys();
        java.util.List list22 = defaultKeyedValues2D20.getRowKeys();
        jFreeChart18.setSubtitles(list22);
        java.awt.RenderingHints renderingHints24 = jFreeChart18.getRenderingHints();
        boolean boolean25 = defaultKeyedValues2D1.equals((java.lang.Object) jFreeChart18);
        try {
            defaultKeyedValues2D1.removeColumn((java.lang.Comparable) "{0}");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: {0}");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(renderingHints24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 89, 1, (java.lang.Comparable) '4', "", "hi!");
        java.lang.String str8 = pieSectionEntity7.getShapeCoords();
        int int9 = pieSectionEntity7.getSectionIndex();
        int int10 = pieSectionEntity7.getPieIndex();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator11 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator12 = null;
        try {
            java.lang.String str13 = pieSectionEntity7.getImageMapAreaTag(toolTipTagFragmentGenerator11, uRLTagFragmentGenerator12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-4,-4,4,4" + "'", str8.equals("-4,-4,4,4"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 89 + "'", int10 == 89);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 3, (float) 100L, (float) (short) 100);
        java.awt.Color color4 = color3.darker();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list2 = defaultKeyedValues2D1.getColumnKeys();
        int int4 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 100.0f);
        int int6 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) '#');
        try {
            defaultKeyedValues2D1.removeRow((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = null;
        java.awt.Stroke[] strokeArray3 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke4 = null;
        java.awt.Stroke[] strokeArray5 = new java.awt.Stroke[] { stroke4 };
        java.awt.Shape[] shapeArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray3, strokeArray5, shapeArray6);
        java.awt.Shape shape8 = defaultDrawingSupplier7.getNextShape();
        try {
            java.awt.Paint paint9 = defaultDrawingSupplier7.getNextOutlinePaint();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(strokeArray5);
        org.junit.Assert.assertNotNull(shapeArray6);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = null;
        java.awt.Stroke[] strokeArray3 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke4 = null;
        java.awt.Stroke[] strokeArray5 = new java.awt.Stroke[] { stroke4 };
        java.awt.Shape[] shapeArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray3, strokeArray5, shapeArray6);
        java.awt.Shape shape8 = defaultDrawingSupplier7.getNextShape();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator11 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot10.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator11);
        piePlot10.setBackgroundAlpha((float) 10);
        java.awt.Paint paint15 = piePlot10.getLabelLinkPaint();
        boolean boolean16 = defaultDrawingSupplier7.equals((java.lang.Object) paint15);
        try {
            java.awt.Paint paint17 = defaultDrawingSupplier7.getNextOutlinePaint();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(strokeArray5);
        org.junit.Assert.assertNotNull(shapeArray6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list2 = defaultKeyedValues2D1.getColumnKeys();
        int int4 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 100.0f);
        int int6 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) '#');
        java.lang.Comparable comparable9 = null;
        try {
            defaultKeyedValues2D1.setValue((java.lang.Number) 89, (java.lang.Comparable) 89, comparable9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list14);
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("hi!", font17);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle18.getVerticalAlignment();
        java.lang.Object obj20 = textTitle18.clone();
        jFreeChart10.removeSubtitle((org.jfree.chart.title.Title) textTitle18);
        org.jfree.chart.title.TextTitle textTitle22 = null;
        jFreeChart10.setTitle(textTitle22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double25 = rectangleInsets24.getBottom();
        double double27 = rectangleInsets24.calculateTopOutset((double) 0.0f);
        java.lang.String str28 = rectangleInsets24.toString();
        jFreeChart10.setPadding(rectangleInsets24);
        org.jfree.chart.ui.ProjectInfo projectInfo30 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray31 = projectInfo30.getOptionalLibraries();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D33 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list34 = defaultKeyedValues2D33.getColumnKeys();
        java.util.List list35 = defaultKeyedValues2D33.getRowKeys();
        projectInfo30.setContributors(list35);
        jFreeChart10.setSubtitles(list35);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo41 = null;
        try {
            java.awt.image.BufferedImage bufferedImage42 = jFreeChart10.createBufferedImage((-32640), (-32640), (int) (short) 1, chartRenderingInfo41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-32640) and height (-32640) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str28.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNotNull(projectInfo30);
        org.junit.Assert.assertNotNull(libraryArray31);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(list35);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int5 = color4.getRGB();
        java.awt.Color color6 = color4.darker();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int8 = color7.getBlue();
        java.awt.Color color9 = color7.darker();
        boolean boolean10 = color6.equals((java.lang.Object) color9);
        boolean boolean11 = standardPieSectionLabelGenerator2.equals((java.lang.Object) boolean10);
        java.lang.String str12 = standardPieSectionLabelGenerator2.getLabelFormat();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        try {
            java.text.AttributedString attributedString15 = standardPieSectionLabelGenerator2.generateAttributedSectionLabel(pieDataset13, (java.lang.Comparable) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-32640) + "'", int5 == (-32640));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "{0}" + "'", str12.equals("{0}"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        piePlot1.setBackgroundImageAlpha(0.0f);
        boolean boolean5 = piePlot1.getSectionOutlinesVisible();
        java.lang.String str6 = piePlot1.getNoDataMessage();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = piePlot1.getLegendItems();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(legendItemCollection7);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("Pie Plot", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((-10), (-49088), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red Green");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        float float4 = piePlot1.getBackgroundAlpha();
        piePlot1.setSectionOutlinesVisible(true);
        int int7 = piePlot1.getBackgroundImageAlignment();
        boolean boolean8 = piePlot1.getSimpleLabels();
        piePlot1.setCircular(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) (short) 1, (-1.0d));
        columnArrangement5.clear();
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement5);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.Font font10 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("hi!", font10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = textTitle11.getPadding();
        java.awt.Font font14 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("hi!", font14);
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = textTitle15.getVerticalAlignment();
        java.lang.Object obj17 = textTitle15.clone();
        textTitle15.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D20 = textTitle15.getBounds();
        java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets12.createInsetRectangle(rectangle2D20);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.Object obj23 = null;
        boolean boolean24 = rectangleEdge22.equals(obj23);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D26 = new org.jfree.data.DefaultKeyedValues2D(false);
        boolean boolean27 = rectangleEdge22.equals((java.lang.Object) false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge22);
        double double29 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D20, rectangleEdge22);
        try {
            blockContainer0.draw(graphics2D8, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        try {
            defaultKeyedValues2D1.removeColumn((java.lang.Comparable) "");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: ");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        piePlot1.drawBackgroundImage(graphics2D5, rectangle2D6);
        java.awt.Font font9 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        double double12 = piePlot11.getMaximumExplodePercent();
        double double13 = piePlot11.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double15 = rectangleInsets14.getBottom();
        piePlot11.setSimpleLabelOffset(rectangleInsets14);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font9, (org.jfree.chart.plot.Plot) piePlot11, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D20 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list21 = defaultKeyedValues2D20.getColumnKeys();
        java.util.List list22 = defaultKeyedValues2D20.getRowKeys();
        jFreeChart18.setSubtitles(list22);
        jFreeChart18.setBackgroundImageAlpha(1.0f);
        java.awt.Stroke stroke26 = jFreeChart18.getBorderStroke();
        piePlot1.setBaseSectionOutlineStroke(stroke26);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.validateObject();
        defaultCategoryDataset0.addValue((double) 100.0f, (java.lang.Comparable) 1L, (java.lang.Comparable) (byte) 100);
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (byte) 100, (java.lang.Comparable) (byte) -1);
        try {
            defaultCategoryDataset0.removeColumn(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        piePlot1.setBackgroundAlpha((float) 10);
        java.awt.Paint paint6 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot1.getSimpleLabelOffset();
        org.jfree.chart.util.UnitType unitType8 = rectangleInsets7.getUnitType();
        java.lang.String str9 = unitType8.toString();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(unitType8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UnitType.RELATIVE" + "'", str9.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(89);
        java.lang.Object obj2 = objectList1.clone();
        objectList1.clear();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int7 = color6.getRGB();
        java.awt.Color color8 = java.awt.Color.getColor("", color6);
        java.awt.Paint[] paintArray9 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        boolean boolean10 = color6.equals((java.lang.Object) paintArray9);
        objectList1.set(0, (java.lang.Object) paintArray9);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        double double15 = piePlot14.getMaximumExplodePercent();
        piePlot14.setBackgroundImageAlpha(0.0f);
        java.awt.Color color18 = java.awt.Color.RED;
        piePlot14.setShadowPaint((java.awt.Paint) color18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double21 = rectangleInsets20.getBottom();
        double double23 = rectangleInsets20.trimWidth((double) 0L);
        double double25 = rectangleInsets20.calculateBottomInset((double) (byte) -1);
        piePlot14.setInsets(rectangleInsets20);
        java.awt.Paint paint27 = piePlot14.getLabelPaint();
        objectList1.set((int) (byte) 1, (java.lang.Object) paint27);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-32640) + "'", int7 == (-32640));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle2.getVerticalAlignment();
        java.lang.Object obj4 = textTitle2.clone();
        textTitle2.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle2.getBounds();
        java.lang.String str8 = textTitle2.getURLText();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        textTitle2.setBackgroundPaint((java.awt.Paint) color9);
        java.lang.String str11 = textTitle2.getID();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        java.lang.Object obj11 = jFreeChart10.getTextAntiAlias();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(obj11);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        double double1 = blockContainer0.getWidth();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list2 = defaultKeyedValues2D1.getColumnKeys();
        int int4 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 100.0f);
        try {
            defaultKeyedValues2D1.removeRow((java.lang.Comparable) (-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            defaultCategoryDataset0.removeColumn(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int5 = color4.getRGB();
        java.awt.Color color6 = color4.darker();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int8 = color7.getBlue();
        java.awt.Color color9 = color7.darker();
        boolean boolean10 = color6.equals((java.lang.Object) color9);
        boolean boolean11 = standardPieSectionLabelGenerator2.equals((java.lang.Object) boolean10);
        java.lang.Object obj12 = standardPieSectionLabelGenerator2.clone();
        java.text.AttributedString attributedString14 = null;
        standardPieSectionLabelGenerator2.setAttributedLabel(89, attributedString14);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-32640) + "'", int5 == (-32640));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        float float4 = piePlot1.getBackgroundImageAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double6 = rectangleInsets5.getBottom();
        double double8 = rectangleInsets5.trimWidth((double) 0L);
        double double10 = rectangleInsets5.trimHeight((double) (byte) 0);
        double double11 = rectangleInsets5.getRight();
        piePlot1.setInsets(rectangleInsets5);
        boolean boolean13 = piePlot1.getSimpleLabels();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.5f + "'", float4 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle2.getVerticalAlignment();
        java.lang.Object obj4 = textTitle2.clone();
        textTitle2.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle2.getBounds();
        java.lang.String str8 = textTitle2.getURLText();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        textTitle2.setBackgroundPaint((java.awt.Paint) color9);
        java.lang.String str11 = textTitle2.getURLText();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = textTitle2.getHorizontalAlignment();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(horizontalAlignment12);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 89, 1, (java.lang.Comparable) '4', "", "hi!");
        pieSectionEntity7.setSectionKey((java.lang.Comparable) 89);
        pieSectionEntity7.setURLText("");
        org.jfree.data.general.PieDataset pieDataset12 = pieSectionEntity7.getDataset();
        java.lang.String str13 = pieSectionEntity7.getToolTipText();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        pieSectionEntity7.setDataset(pieDataset14);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(pieDataset12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) '#');
        pieLabelDistributor1.distributeLabels((double) 0, 100.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle2.getVerticalAlignment();
        java.lang.Object obj4 = textTitle2.clone();
        double double5 = textTitle2.getContentXOffset();
        double double6 = textTitle2.getHeight();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Image image2 = piePlot1.getBackgroundImage();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent3 = null;
        piePlot1.axisChanged(axisChangeEvent3);
        org.junit.Assert.assertNull(image2);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        double double3 = rectangleInsets1.calculateTopOutset((double) 10.0f);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = null;
        java.awt.Stroke[] strokeArray3 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke4 = null;
        java.awt.Stroke[] strokeArray5 = new java.awt.Stroke[] { stroke4 };
        java.awt.Shape[] shapeArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray3, strokeArray5, shapeArray6);
        try {
            java.awt.Stroke stroke8 = defaultDrawingSupplier7.getNextStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(strokeArray5);
        org.junit.Assert.assertNotNull(shapeArray6);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D3 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list4 = defaultKeyedValues2D3.getColumnKeys();
        java.util.List list5 = defaultKeyedValues2D3.getRowKeys();
        projectInfo0.setContributors(list5);
        java.util.List list7 = projectInfo0.getContributors();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement0.clear();
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int1 = color0.getRGB();
        java.awt.Color color2 = color0.darker();
        int int3 = color2.getTransparency();
        int int4 = color2.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-32640) + "'", int1 == (-32640));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-5088935) + "'", int4 == (-5088935));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int2 = color1.getRGB();
        java.awt.Color color3 = java.awt.Color.getColor("", color1);
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color3);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-32640) + "'", int2 == (-32640));
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        piePlot3.setBackgroundAlpha(0.0f);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int10 = color9.getRGB();
        java.awt.Color color11 = color9.darker();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int13 = color12.getBlue();
        java.awt.Color color14 = color12.darker();
        boolean boolean15 = color11.equals((java.lang.Object) color14);
        piePlot3.setSectionOutlinePaint((java.lang.Comparable) (short) 100, (java.awt.Paint) color11);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("PieLabelLinkStyle.STANDARD", font1, (org.jfree.chart.plot.Plot) piePlot3, true);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent19 = null;
        try {
            jFreeChart18.titleChanged(titleChangeEvent19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-32640) + "'", int10 == (-32640));
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (short) -1, (java.lang.Comparable) 100L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 3, (double) 2, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        piePlot1.setPieIndex((int) (short) 100);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        double double8 = piePlot7.getMaximumExplodePercent();
        double double9 = piePlot7.getShadowYOffset();
        float float10 = piePlot7.getBackgroundAlpha();
        piePlot1.setParent((org.jfree.chart.plot.Plot) piePlot7);
        piePlot7.setExplodePercent((java.lang.Comparable) 10, (double) (-32640));
        org.jfree.chart.util.Rotation rotation15 = piePlot7.getDirection();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator19 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot18.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator19);
        piePlot18.setBackgroundAlpha((float) 10);
        java.awt.Paint paint23 = piePlot18.getLabelLinkPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = piePlot18.getSimpleLabelOffset();
        java.awt.Font font26 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        double double29 = piePlot28.getMaximumExplodePercent();
        double double30 = piePlot28.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double32 = rectangleInsets31.getBottom();
        piePlot28.setSimpleLabelOffset(rectangleInsets31);
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font26, (org.jfree.chart.plot.Plot) piePlot28, false);
        piePlot18.setNoDataMessageFont(font26);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot37 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        multiplePiePlot37.setDataset(categoryDataset38);
        org.jfree.chart.LegendItemCollection legendItemCollection40 = multiplePiePlot37.getLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        multiplePiePlot37.setDataset(categoryDataset41);
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("{0} version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).\n{0} LICENCE TERMS:\nPie Plot", font26, (org.jfree.chart.plot.Plot) multiplePiePlot37, false);
        java.awt.Color color45 = java.awt.Color.lightGray;
        multiplePiePlot37.setAggregatedItemsPaint((java.awt.Paint) color45);
        piePlot7.setLabelBackgroundPaint((java.awt.Paint) color45);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertNotNull(rotation15);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 4.0d + "'", double30 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection40);
        org.junit.Assert.assertNotNull(color45);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.0f, (float) 0L, (float) 255);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.validateObject();
        defaultCategoryDataset0.addValue((double) 100.0f, (java.lang.Comparable) 1L, (java.lang.Comparable) (byte) 100);
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (byte) 100, (java.lang.Comparable) (byte) -1);
        defaultCategoryDataset0.validateObject();
        org.jfree.data.general.DatasetGroup datasetGroup10 = null;
        try {
            defaultCategoryDataset0.setGroup(datasetGroup10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'group' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 89, 1, (java.lang.Comparable) '4', "", "hi!");
        pieSectionEntity7.setSectionKey((java.lang.Comparable) 89);
        pieSectionEntity7.setURLText("");
        org.jfree.data.general.PieDataset pieDataset12 = null;
        pieSectionEntity7.setDataset(pieDataset12);
        java.lang.String str14 = pieSectionEntity7.getToolTipText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = null;
        java.awt.Stroke[] strokeArray3 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke4 = null;
        java.awt.Stroke[] strokeArray5 = new java.awt.Stroke[] { stroke4 };
        java.awt.Shape[] shapeArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray3, strokeArray5, shapeArray6);
        org.jfree.chart.util.TableOrder tableOrder8 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        boolean boolean9 = defaultDrawingSupplier7.equals((java.lang.Object) tableOrder8);
        java.awt.Stroke stroke10 = defaultDrawingSupplier7.getNextOutlineStroke();
        java.lang.Object obj11 = defaultDrawingSupplier7.clone();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(strokeArray5);
        org.junit.Assert.assertNotNull(shapeArray6);
        org.junit.Assert.assertNotNull(tableOrder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        java.lang.String str6 = standardPieSectionLabelGenerator2.generateSectionLabel(pieDataset4, (java.lang.Comparable) (short) 1);
        java.text.NumberFormat numberFormat7 = standardPieSectionLabelGenerator2.getNumberFormat();
        java.lang.Object obj8 = standardPieSectionLabelGenerator2.clone();
        java.lang.String str9 = standardPieSectionLabelGenerator2.getLabelFormat();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{0}" + "'", str9.equals("{0}"));
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test175");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.toString();
//        java.util.List list2 = projectInfo0.getContributors();
//        projectInfo0.setVersion("VerticalAlignment.CENTER");
//        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
//        java.util.List list6 = projectInfo5.getContributors();
//        projectInfo0.setContributors(list6);
//        java.lang.String str8 = projectInfo0.getInfo();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0} version VerticalAlignment.CENTER.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).\n{0} LICENCE TERMS:\nPie Plot" + "'", str1.equals("{0} version VerticalAlignment.CENTER.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).\n{0} LICENCE TERMS:\nPie Plot"));
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertNotNull(projectInfo5);
//        org.junit.Assert.assertNotNull(list6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "VerticalAlignment.CENTER" + "'", str8.equals("VerticalAlignment.CENTER"));
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        piePlot3.setBackgroundAlpha(0.0f);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int10 = color9.getRGB();
        java.awt.Color color11 = color9.darker();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int13 = color12.getBlue();
        java.awt.Color color14 = color12.darker();
        boolean boolean15 = color11.equals((java.lang.Object) color14);
        piePlot3.setSectionOutlinePaint((java.lang.Comparable) (short) 100, (java.awt.Paint) color11);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("PieLabelLinkStyle.STANDARD", font1, (org.jfree.chart.plot.Plot) piePlot3, true);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart18.getLegend();
        java.awt.Paint paint20 = legendTitle19.getItemPaint();
        org.jfree.chart.block.BlockContainer blockContainer21 = legendTitle19.getItemContainer();
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.Font font24 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("hi!", font24);
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = textTitle25.getVerticalAlignment();
        java.lang.Object obj27 = textTitle25.clone();
        textTitle25.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle25.getBounds();
        java.awt.geom.Rectangle2D rectangle2D31 = textTitle25.getBounds();
        try {
            legendTitle19.draw(graphics2D22, rectangle2D31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-32640) + "'", int10 == (-32640));
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(legendTitle19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(blockContainer21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(verticalAlignment26);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D31);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 89, 1, (java.lang.Comparable) '4', "", "hi!");
        int int8 = pieSectionEntity7.getSectionIndex();
        pieSectionEntity7.setURLText("Rotation.ANTICLOCKWISE");
        java.lang.Object obj11 = pieSectionEntity7.clone();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) (short) 1, (-1.0d));
        columnArrangement5.clear();
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement5);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.Font font10 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("hi!", font10);
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = textTitle11.getVerticalAlignment();
        java.lang.Object obj13 = textTitle11.clone();
        textTitle11.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D16 = textTitle11.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16, "TableOrder.BY_COLUMN", "{0} version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).\n{0} LICENCE TERMS:\nPie Plot");
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator22 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot21.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator22);
        org.jfree.chart.JFreeChart jFreeChart24 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot21, jFreeChart24);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType26 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        boolean boolean28 = chartChangeEventType26.equals((java.lang.Object) 10L);
        chartChangeEvent25.setType(chartChangeEventType26);
        try {
            java.lang.Object obj30 = blockContainer0.draw(graphics2D8, rectangle2D16, (java.lang.Object) chartChangeEventType26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(verticalAlignment12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(chartChangeEventType26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = null;
        java.awt.Stroke[] strokeArray3 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke4 = null;
        java.awt.Stroke[] strokeArray5 = new java.awt.Stroke[] { stroke4 };
        java.awt.Shape[] shapeArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray3, strokeArray5, shapeArray6);
        java.awt.Shape shape8 = defaultDrawingSupplier7.getNextShape();
        java.awt.Paint paint9 = defaultDrawingSupplier7.getNextPaint();
        java.lang.Object obj10 = defaultDrawingSupplier7.clone();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(strokeArray5);
        org.junit.Assert.assertNotNull(shapeArray6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        double double3 = piePlot2.getMaximumExplodePercent();
        double double4 = piePlot2.getShadowYOffset();
        float float5 = piePlot2.getBackgroundAlpha();
        piePlot2.setSectionOutlinesVisible(true);
        int int8 = piePlot2.getBackgroundImageAlignment();
        boolean boolean9 = piePlot2.getSimpleLabels();
        java.awt.Paint paint10 = piePlot2.getBackgroundPaint();
        java.awt.Font font12 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        double double15 = piePlot14.getMaximumExplodePercent();
        double double16 = piePlot14.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double18 = rectangleInsets17.getBottom();
        piePlot14.setSimpleLabelOffset(rectangleInsets17);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font12, (org.jfree.chart.plot.Plot) piePlot14, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D23 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list24 = defaultKeyedValues2D23.getColumnKeys();
        java.util.List list25 = defaultKeyedValues2D23.getRowKeys();
        jFreeChart21.setSubtitles(list25);
        jFreeChart21.setBackgroundImageAlpha(1.0f);
        java.awt.Stroke stroke29 = jFreeChart21.getBorderStroke();
        java.awt.Font font31 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("hi!", font31);
        org.jfree.chart.util.VerticalAlignment verticalAlignment33 = textTitle32.getVerticalAlignment();
        java.lang.Object obj34 = textTitle32.clone();
        textTitle32.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D37 = textTitle32.getBounds();
        org.jfree.chart.block.BlockBorder blockBorder38 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = blockBorder38.getInsets();
        textTitle32.setMargin(rectangleInsets39);
        org.jfree.chart.block.LineBorder lineBorder41 = new org.jfree.chart.block.LineBorder(paint10, stroke29, rectangleInsets39);
        boolean boolean42 = rotation0.equals((java.lang.Object) rectangleInsets39);
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(verticalAlignment33);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        java.awt.Font font4 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        piePlot1.setNoDataMessageFont(font4);
        java.lang.String str6 = piePlot1.getPlotType();
        java.awt.Paint paint7 = piePlot1.getLabelPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Pie Plot" + "'", str6.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.validateObject();
        defaultCategoryDataset0.addValue((double) 100.0f, (java.lang.Comparable) 1L, (java.lang.Comparable) (byte) 100);
        try {
            defaultCategoryDataset0.incrementValue(0.0d, (java.lang.Comparable) (-5088935), (java.lang.Comparable) 1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 1");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        piePlot1.setBackgroundImageAlpha(0.0f);
        java.awt.Color color5 = java.awt.Color.RED;
        piePlot1.setShadowPaint((java.awt.Paint) color5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double8 = rectangleInsets7.getBottom();
        double double10 = rectangleInsets7.trimWidth((double) 0L);
        double double12 = rectangleInsets7.calculateBottomInset((double) (byte) -1);
        piePlot1.setInsets(rectangleInsets7);
        double double15 = rectangleInsets7.calculateRightOutset((double) 1L);
        double double16 = rectangleInsets7.getRight();
        double double18 = rectangleInsets7.calculateLeftInset(4.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        int int3 = defaultKeyedValues2D1.getColumnIndex((java.lang.Comparable) "RectangleAnchor.CENTER");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double5 = rectangleInsets4.getBottom();
        piePlot1.setSimpleLabelOffset(rectangleInsets4);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int9 = color8.getBlue();
        java.awt.Color color10 = java.awt.Color.getColor("", color8);
        piePlot1.setShadowPaint((java.awt.Paint) color10);
        boolean boolean12 = piePlot1.isCircular();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Image image2 = piePlot1.getBackgroundImage();
        java.awt.Image image3 = piePlot1.getBackgroundImage();
        piePlot1.setMaximumLabelWidth((double) (short) 0);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNull(image3);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        float float4 = piePlot1.getBackgroundAlpha();
        java.awt.Image image5 = null;
        piePlot1.setBackgroundImage(image5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot1.getLabelPadding();
        java.awt.Paint paint8 = piePlot1.getLabelBackgroundPaint();
        java.awt.Paint[] paintArray9 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray10 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray11 = null;
        java.awt.Stroke[] strokeArray12 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Shape[] shapeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray10, paintArray11, strokeArray12, strokeArray14, shapeArray15);
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier16);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot();
        boolean boolean19 = defaultDrawingSupplier16.equals((java.lang.Object) multiplePiePlot18);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.Font font22 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("hi!", font22);
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = textTitle23.getVerticalAlignment();
        java.lang.Object obj25 = textTitle23.clone();
        textTitle23.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle23.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity31 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D28, "TableOrder.BY_COLUMN", "{0} version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).\n{0} LICENCE TERMS:\nPie Plot");
        java.awt.geom.Point2D point2D32 = null;
        org.jfree.chart.plot.PlotState plotState33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        try {
            multiplePiePlot18.draw(graphics2D20, rectangle2D28, point2D32, plotState33, plotRenderingInfo34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(shapeArray15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(rectangle2D28);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot1, jFreeChart4);
        piePlot1.setExplodePercent((java.lang.Comparable) true, (double) (short) 1);
        java.awt.Font font10 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        double double13 = piePlot12.getMaximumExplodePercent();
        double double14 = piePlot12.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets15.getBottom();
        piePlot12.setSimpleLabelOffset(rectangleInsets15);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font10, (org.jfree.chart.plot.Plot) piePlot12, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D21 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list22 = defaultKeyedValues2D21.getColumnKeys();
        java.util.List list23 = defaultKeyedValues2D21.getRowKeys();
        jFreeChart19.setSubtitles(list23);
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart19);
        java.awt.Image image26 = jFreeChart19.getBackgroundImage();
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNull(image26);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        java.awt.Font font2 = null;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        double double5 = piePlot4.getMaximumExplodePercent();
        double double6 = piePlot4.getShadowYOffset();
        piePlot4.setBackgroundAlpha(0.0f);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int11 = color10.getRGB();
        java.awt.Color color12 = color10.darker();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int14 = color13.getBlue();
        java.awt.Color color15 = color13.darker();
        boolean boolean16 = color12.equals((java.lang.Object) color15);
        piePlot4.setSectionOutlinePaint((java.lang.Comparable) (short) 100, (java.awt.Paint) color12);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("PieLabelLinkStyle.STANDARD", font2, (org.jfree.chart.plot.Plot) piePlot4, true);
        org.jfree.chart.title.LegendTitle legendTitle20 = jFreeChart19.getLegend();
        java.awt.Paint paint21 = legendTitle20.getItemPaint();
        org.jfree.chart.block.BlockContainer blockContainer22 = legendTitle20.getItemContainer();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = null;
        try {
            org.jfree.chart.util.Size2D size2D25 = flowArrangement0.arrange(blockContainer22, graphics2D23, rectangleConstraint24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-32640) + "'", int11 == (-32640));
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(legendTitle20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(blockContainer22);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list14);
        java.awt.RenderingHints renderingHints16 = jFreeChart10.getRenderingHints();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        double double19 = piePlot18.getMaximumExplodePercent();
        double double20 = piePlot18.getShadowYOffset();
        float float21 = piePlot18.getBackgroundAlpha();
        java.awt.Image image22 = null;
        piePlot18.setBackgroundImage(image22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = piePlot18.getLabelPadding();
        jFreeChart10.setPadding(rectangleInsets24);
        float float26 = jFreeChart10.getBackgroundImageAlpha();
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.Font font29 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("hi!", font29);
        org.jfree.chart.util.VerticalAlignment verticalAlignment31 = textTitle30.getVerticalAlignment();
        java.lang.Object obj32 = textTitle30.clone();
        textTitle30.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D35 = textTitle30.getBounds();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = null;
        try {
            jFreeChart10.draw(graphics2D27, rectangle2D35, chartRenderingInfo36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(renderingHints16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 1.0f + "'", float21 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.5f + "'", float26 == 0.5f);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(verticalAlignment31);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(rectangle2D35);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle2.getPadding();
        java.lang.String str4 = rectangleInsets3.toString();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str4.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Font font3 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("hi!", font3);
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = textTitle4.getVerticalAlignment();
        java.lang.Object obj6 = textTitle4.clone();
        textTitle4.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle4.getBounds();
        try {
            blockBorder0.draw(graphics2D1, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(rectangle2D9);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.util.TableOrder tableOrder0 = org.jfree.chart.util.TableOrder.BY_ROW;
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        double double5 = piePlot4.getMaximumExplodePercent();
        double double6 = piePlot4.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double8 = rectangleInsets7.getBottom();
        piePlot4.setSimpleLabelOffset(rectangleInsets7);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font2, (org.jfree.chart.plot.Plot) piePlot4, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D13 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list14 = defaultKeyedValues2D13.getColumnKeys();
        java.util.List list15 = defaultKeyedValues2D13.getRowKeys();
        jFreeChart11.setSubtitles(list15);
        java.awt.Font font18 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("hi!", font18);
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = textTitle19.getVerticalAlignment();
        java.lang.Object obj21 = textTitle19.clone();
        jFreeChart11.removeSubtitle((org.jfree.chart.title.Title) textTitle19);
        org.jfree.chart.title.TextTitle textTitle23 = null;
        jFreeChart11.setTitle(textTitle23);
        boolean boolean25 = jFreeChart11.isBorderVisible();
        java.awt.Paint paint26 = jFreeChart11.getBackgroundPaint();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) tableOrder0, jFreeChart11);
        try {
            java.awt.image.BufferedImage bufferedImage30 = jFreeChart11.createBufferedImage((-49088), (-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-49088) and height (-16777216) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tableOrder0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(verticalAlignment20);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.awt.Color color0 = java.awt.Color.RED;
        float[] floatArray7 = new float[] { (byte) 0, '#', '4', 3, 0.0f, 10 };
        float[] floatArray8 = color0.getComponents(floatArray7);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot11.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator12);
        piePlot11.setBackgroundAlpha((float) 10);
        java.awt.Paint paint16 = piePlot11.getLabelLinkPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = piePlot11.getSimpleLabelOffset();
        java.awt.Font font19 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        double double22 = piePlot21.getMaximumExplodePercent();
        double double23 = piePlot21.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double25 = rectangleInsets24.getBottom();
        piePlot21.setSimpleLabelOffset(rectangleInsets24);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font19, (org.jfree.chart.plot.Plot) piePlot21, false);
        piePlot11.setNoDataMessageFont(font19);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot30 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        multiplePiePlot30.setDataset(categoryDataset31);
        org.jfree.chart.LegendItemCollection legendItemCollection33 = multiplePiePlot30.getLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        multiplePiePlot30.setDataset(categoryDataset34);
        org.jfree.chart.JFreeChart jFreeChart37 = new org.jfree.chart.JFreeChart("{0} version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).\n{0} LICENCE TERMS:\nPie Plot", font19, (org.jfree.chart.plot.Plot) multiplePiePlot30, false);
        org.jfree.chart.title.TextTitle textTitle38 = jFreeChart37.getTitle();
        java.awt.Paint paint39 = jFreeChart37.getBackgroundPaint();
        boolean boolean40 = color0.equals((java.lang.Object) paint39);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection33);
        org.junit.Assert.assertNotNull(textTitle38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        piePlot1.setDataset(pieDataset2);
        java.awt.Paint paint4 = piePlot1.getOutlinePaint();
        java.awt.Paint paint5 = piePlot1.getBaseSectionPaint();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        piePlot1.setDataset(pieDataset6);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        piePlot1.setBackgroundImageAlpha(0.0f);
        java.awt.Color color5 = java.awt.Color.RED;
        piePlot1.setShadowPaint((java.awt.Paint) color5);
        piePlot1.setForegroundAlpha((float) 8);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        piePlot1.setNoDataMessagePaint((java.awt.Paint) color9);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(89);
        java.lang.Object obj2 = objectList1.clone();
        objectList1.clear();
        objectList1.clear();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.awt.Color color6 = java.awt.Color.RED;
        float[] floatArray13 = new float[] { (byte) 0, '#', '4', 3, 0.0f, 10 };
        float[] floatArray14 = color6.getComponents(floatArray13);
        float[] floatArray15 = java.awt.Color.RGBtoHSB(100, (int) (short) 1, (int) (short) -1, floatArray13);
        float[] floatArray16 = java.awt.Color.RGBtoHSB((int) (short) -1, 89, (-49088), floatArray13);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int1 = color0.getRGB();
        java.awt.Color color2 = color0.darker();
        org.jfree.data.general.Dataset dataset3 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color0, dataset3);
        java.lang.Object obj5 = datasetChangeEvent4.getSource();
        org.jfree.data.general.Dataset dataset6 = datasetChangeEvent4.getDataset();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-32640) + "'", int1 == (-32640));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(dataset6);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        piePlot1.setBackgroundImageAlpha(0.0f);
        boolean boolean5 = piePlot1.getSectionOutlinesVisible();
        java.awt.Paint paint6 = piePlot1.getLabelOutlinePaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator7);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle2.getVerticalAlignment();
        java.lang.Object obj4 = textTitle2.clone();
        textTitle2.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle2.getBounds();
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = blockBorder8.getInsets();
        textTitle2.setMargin(rectangleInsets9);
        double double12 = rectangleInsets9.trimWidth((double) (-1L));
        double double14 = rectangleInsets9.calculateLeftOutset((double) (short) -1);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-3.0d) + "'", double12 == (-3.0d));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list14);
        java.awt.RenderingHints renderingHints16 = jFreeChart10.getRenderingHints();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        double double19 = piePlot18.getMaximumExplodePercent();
        double double20 = piePlot18.getShadowYOffset();
        float float21 = piePlot18.getBackgroundAlpha();
        java.awt.Image image22 = null;
        piePlot18.setBackgroundImage(image22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = piePlot18.getLabelPadding();
        jFreeChart10.setPadding(rectangleInsets24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = null;
        try {
            java.awt.image.BufferedImage bufferedImage30 = jFreeChart10.createBufferedImage(0, (-10), (int) (byte) -1, chartRenderingInfo29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(renderingHints16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 1.0f + "'", float21 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets24);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D3 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list4 = defaultKeyedValues2D3.getColumnKeys();
        java.util.List list5 = defaultKeyedValues2D3.getRowKeys();
        projectInfo0.setContributors(list5);
        java.lang.String str7 = projectInfo0.getLicenceText();
        java.lang.String str8 = projectInfo0.getLicenceText();
        java.lang.String str9 = projectInfo0.getVersion();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pie Plot" + "'", str7.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pie Plot" + "'", str8.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "VerticalAlignment.CENTER" + "'", str9.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list14);
        java.awt.RenderingHints renderingHints16 = jFreeChart10.getRenderingHints();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        double double19 = piePlot18.getMaximumExplodePercent();
        double double20 = piePlot18.getShadowYOffset();
        float float21 = piePlot18.getBackgroundAlpha();
        java.awt.Image image22 = null;
        piePlot18.setBackgroundImage(image22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = piePlot18.getLabelPadding();
        jFreeChart10.setPadding(rectangleInsets24);
        float float26 = jFreeChart10.getBackgroundImageAlpha();
        jFreeChart10.setBorderVisible(true);
        jFreeChart10.clearSubtitles();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(renderingHints16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 1.0f + "'", float21 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.5f + "'", float26 == 0.5f);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int5 = color4.getRGB();
        java.awt.Color color6 = color4.darker();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int8 = color7.getBlue();
        java.awt.Color color9 = color7.darker();
        boolean boolean10 = color6.equals((java.lang.Object) color9);
        piePlot1.setBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = piePlot1.getSimpleLabelOffset();
        piePlot1.setCircular(true);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator15 = null;
        piePlot1.setURLGenerator(pieURLGenerator15);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-32640) + "'", int5 == (-32640));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        piePlot3.setBackgroundAlpha(0.0f);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int10 = color9.getRGB();
        java.awt.Color color11 = color9.darker();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int13 = color12.getBlue();
        java.awt.Color color14 = color12.darker();
        boolean boolean15 = color11.equals((java.lang.Object) color14);
        piePlot3.setSectionOutlinePaint((java.lang.Comparable) (short) 100, (java.awt.Paint) color11);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("PieLabelLinkStyle.STANDARD", font1, (org.jfree.chart.plot.Plot) piePlot3, true);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart18.getLegend();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendTitle19.getLegendItemGraphicPadding();
        java.lang.String str21 = rectangleInsets20.toString();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-32640) + "'", int10 == (-32640));
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(legendTitle19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]" + "'", str21.equals("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        double double5 = piePlot4.getMaximumExplodePercent();
        double double6 = piePlot4.getShadowYOffset();
        java.awt.Paint paint7 = piePlot4.getBackgroundPaint();
        piePlot1.setLabelLinkPaint(paint7);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        piePlot1.markerChanged(markerChangeEvent9);
        java.awt.Color color11 = java.awt.Color.YELLOW;
        piePlot1.setLabelLinkPaint((java.awt.Paint) color11);
        java.awt.Paint paint14 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(paint14);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list14);
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("hi!", font17);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle18.getVerticalAlignment();
        java.lang.Object obj20 = textTitle18.clone();
        jFreeChart10.removeSubtitle((org.jfree.chart.title.Title) textTitle18);
        org.jfree.chart.title.TextTitle textTitle22 = null;
        jFreeChart10.setTitle(textTitle22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double25 = rectangleInsets24.getBottom();
        double double27 = rectangleInsets24.calculateTopOutset((double) 0.0f);
        java.lang.String str28 = rectangleInsets24.toString();
        jFreeChart10.setPadding(rectangleInsets24);
        double double31 = rectangleInsets24.calculateRightOutset((double) (byte) 100);
        double double33 = rectangleInsets24.calculateLeftOutset((double) 0);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str28.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot1, jFreeChart4);
        piePlot1.setExplodePercent((java.lang.Comparable) true, (double) (short) 1);
        java.awt.Font font10 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        double double13 = piePlot12.getMaximumExplodePercent();
        double double14 = piePlot12.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets15.getBottom();
        piePlot12.setSimpleLabelOffset(rectangleInsets15);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font10, (org.jfree.chart.plot.Plot) piePlot12, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D21 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list22 = defaultKeyedValues2D21.getColumnKeys();
        java.util.List list23 = defaultKeyedValues2D21.getRowKeys();
        jFreeChart19.setSubtitles(list23);
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart19);
        float float26 = jFreeChart19.getBackgroundImageAlpha();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double29 = rectangleInsets28.getBottom();
        java.awt.Font font31 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("hi!", font31);
        org.jfree.chart.util.VerticalAlignment verticalAlignment33 = textTitle32.getVerticalAlignment();
        java.lang.Object obj34 = textTitle32.clone();
        textTitle32.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D37 = textTitle32.getBounds();
        rectangleInsets28.trim(rectangle2D37);
        java.awt.geom.Point2D point2D39 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo40 = null;
        try {
            jFreeChart19.draw(graphics2D27, rectangle2D37, point2D39, chartRenderingInfo40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.5f + "'", float26 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(verticalAlignment33);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(rectangle2D37);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list2 = defaultKeyedValues2D1.getColumnKeys();
        int int4 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 100.0f);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) (-1L), (java.lang.Comparable) 100.0f);
        try {
            defaultKeyedValues2D1.removeColumn(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        int int3 = java.awt.Color.HSBtoRGB((float) 89, (float) 100, (float) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-668) + "'", int3 == (-668));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        piePlot1.setDataset(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot1.removeChangeListener(plotChangeListener4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment6, verticalAlignment7, (double) (short) 1, (-1.0d));
        columnArrangement10.clear();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int14 = color13.getBlue();
        java.awt.Color color15 = java.awt.Color.getColor("", color13);
        boolean boolean16 = columnArrangement10.equals((java.lang.Object) color15);
        piePlot1.setOutlinePaint((java.awt.Paint) color15);
        int int18 = color15.getAlpha();
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 255 + "'", int18 == 255);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int5 = color4.getBlue();
        java.awt.Color color6 = color4.darker();
        int int7 = color6.getRed();
        java.awt.Color color8 = color6.darker();
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color8);
        double double10 = piePlot1.getLabelGap();
        piePlot1.setForegroundAlpha((float) (-16777216));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 89 + "'", int7 == 89);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.025d + "'", double10 == 0.025d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        piePlot1.setBackgroundImageAlpha(0.0f);
        piePlot1.setStartAngle((double) 1L);
        java.awt.Paint paint8 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 10L);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot1.getToolTipGenerator();
        double double10 = piePlot1.getShadowYOffset();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "hi!", "");
        java.lang.String str6 = basicProjectInfo5.getCopyright();
        basicProjectInfo5.setName("");
        org.jfree.chart.ui.Library[] libraryArray9 = basicProjectInfo5.getOptionalLibraries();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(libraryArray9);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 89, 1, (java.lang.Comparable) '4', "", "hi!");
        java.lang.String str8 = pieSectionEntity7.getShapeCoords();
        int int9 = pieSectionEntity7.getSectionIndex();
        java.lang.String str10 = pieSectionEntity7.getShapeType();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        pieSectionEntity7.setDataset(pieDataset11);
        java.lang.String str13 = pieSectionEntity7.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-4,-4,4,4" + "'", str8.equals("-4,-4,4,4"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "rect" + "'", str10.equals("rect"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PieSection: 89, 1(4)" + "'", str13.equals("PieSection: 89, 1(4)"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list14);
        jFreeChart10.setBackgroundImageAlpha(1.0f);
        java.awt.Stroke stroke18 = jFreeChart10.getBorderStroke();
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot19 = jFreeChart10.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(89);
        java.lang.Object obj2 = objectList1.clone();
        java.lang.Object obj3 = objectList1.clone();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list14);
        java.awt.RenderingHints renderingHints16 = jFreeChart10.getRenderingHints();
        java.lang.Object obj17 = jFreeChart10.clone();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        try {
            jFreeChart10.handleClick(3, 89, chartRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(renderingHints16);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        piePlot1.setBackgroundAlpha((float) 10);
        java.awt.Paint paint6 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot1.getSimpleLabelOffset();
        org.jfree.chart.util.UnitType unitType8 = rectangleInsets7.getUnitType();
        java.awt.Font font10 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        double double13 = piePlot12.getMaximumExplodePercent();
        double double14 = piePlot12.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets15.getBottom();
        piePlot12.setSimpleLabelOffset(rectangleInsets15);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font10, (org.jfree.chart.plot.Plot) piePlot12, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D21 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list22 = defaultKeyedValues2D21.getColumnKeys();
        java.util.List list23 = defaultKeyedValues2D21.getRowKeys();
        jFreeChart19.setSubtitles(list23);
        java.awt.Font font26 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("hi!", font26);
        org.jfree.chart.util.VerticalAlignment verticalAlignment28 = textTitle27.getVerticalAlignment();
        java.lang.Object obj29 = textTitle27.clone();
        jFreeChart19.removeSubtitle((org.jfree.chart.title.Title) textTitle27);
        org.jfree.chart.title.TextTitle textTitle31 = null;
        jFreeChart19.setTitle(textTitle31);
        int int33 = jFreeChart19.getBackgroundImageAlignment();
        boolean boolean34 = unitType8.equals((java.lang.Object) int33);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = new org.jfree.chart.util.RectangleInsets(unitType8, (double) 2, (double) 0.0f, (double) (-1.0f), 4.0d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(unitType8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(verticalAlignment28);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 15 + "'", int33 == 15);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        piePlot1.setBackgroundImageAlpha(0.0f);
        boolean boolean5 = piePlot1.getSectionOutlinesVisible();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int5 = color4.getRGB();
        java.awt.Color color6 = color4.darker();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int8 = color7.getBlue();
        java.awt.Color color9 = color7.darker();
        boolean boolean10 = color6.equals((java.lang.Object) color9);
        piePlot1.setBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = piePlot1.getSimpleLabelOffset();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = null;
        piePlot1.notifyListeners(plotChangeEvent13);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-32640) + "'", int5 == (-32640));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle2.getVerticalAlignment();
        java.lang.Object obj4 = textTitle2.clone();
        textTitle2.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle2.getBounds();
        java.lang.String str8 = textTitle2.getURLText();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        textTitle2.setBackgroundPaint((java.awt.Paint) color9);
        java.awt.Color color11 = java.awt.Color.YELLOW;
        boolean boolean12 = textTitle2.equals((java.lang.Object) color11);
        java.lang.Object obj13 = textTitle2.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator1.getPercentFormat();
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getLGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        piePlot1.setDataset(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot1.removeChangeListener(plotChangeListener4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment6, verticalAlignment7, (double) (short) 1, (-1.0d));
        columnArrangement10.clear();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int14 = color13.getBlue();
        java.awt.Color color15 = java.awt.Color.getColor("", color13);
        boolean boolean16 = columnArrangement10.equals((java.lang.Object) color15);
        piePlot1.setOutlinePaint((java.awt.Paint) color15);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent18 = null;
        piePlot1.markerChanged(markerChangeEvent18);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 1, (-1.0d));
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int1 = color0.getBlue();
        java.awt.Color color2 = color0.darker();
        int int3 = color2.getRed();
        java.awt.Color color4 = color2.darker();
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 89 + "'", int3 == 89);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 89, 1, (java.lang.Comparable) '4', "", "hi!");
        java.lang.String str8 = pieSectionEntity7.getShapeCoords();
        int int9 = pieSectionEntity7.getSectionIndex();
        java.lang.String str10 = pieSectionEntity7.getShapeType();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator11 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator12 = null;
        try {
            java.lang.String str13 = pieSectionEntity7.getImageMapAreaTag(toolTipTagFragmentGenerator11, uRLTagFragmentGenerator12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-4,-4,4,4" + "'", str8.equals("-4,-4,4,4"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "rect" + "'", str10.equals("rect"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        piePlot3.setBackgroundAlpha(0.0f);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int10 = color9.getRGB();
        java.awt.Color color11 = color9.darker();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int13 = color12.getBlue();
        java.awt.Color color14 = color12.darker();
        boolean boolean15 = color11.equals((java.lang.Object) color14);
        piePlot3.setSectionOutlinePaint((java.lang.Comparable) (short) 100, (java.awt.Paint) color11);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("PieLabelLinkStyle.STANDARD", font1, (org.jfree.chart.plot.Plot) piePlot3, true);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart18.getLegend();
        java.awt.Paint paint20 = legendTitle19.getItemPaint();
        org.jfree.chart.block.BlockContainer blockContainer21 = legendTitle19.getItemContainer();
        java.awt.Font font22 = legendTitle19.getItemFont();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-32640) + "'", int10 == (-32640));
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(legendTitle19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(blockContainer21);
        org.junit.Assert.assertNotNull(font22);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(89);
        java.lang.Object obj2 = objectList1.clone();
        objectList1.clear();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("hi!", font5);
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = textTitle6.getVerticalAlignment();
        java.lang.Object obj8 = textTitle6.clone();
        textTitle6.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D11 = textTitle6.getBounds();
        textTitle6.setMargin(10.0d, (double) (short) 100, (double) 'a', 1.0d);
        textTitle6.setMargin((double) (-16777216), (double) 10, 0.4d, (double) 15);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = textTitle6.getTextAlignment();
        int int23 = objectList1.indexOf((java.lang.Object) horizontalAlignment22);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo30 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray31 = basicProjectInfo30.getLibraries();
        objectList1.set(0, (java.lang.Object) basicProjectInfo30);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(libraryArray31);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list14);
        boolean boolean16 = jFreeChart10.isNotify();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.Font font19 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("hi!", font19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = textTitle20.getPadding();
        java.awt.Font font23 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("hi!", font23);
        org.jfree.chart.util.VerticalAlignment verticalAlignment25 = textTitle24.getVerticalAlignment();
        java.lang.Object obj26 = textTitle24.clone();
        textTitle24.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D29 = textTitle24.getBounds();
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets21.createInsetRectangle(rectangle2D29);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = null;
        try {
            jFreeChart10.draw(graphics2D17, rectangle2D30, chartRenderingInfo31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(verticalAlignment25);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D30);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        piePlot1.setIgnoreZeroValues(true);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.Font font9 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle10.getPadding();
        java.awt.Font font13 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("hi!", font13);
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = textTitle14.getVerticalAlignment();
        java.lang.Object obj16 = textTitle14.clone();
        textTitle14.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = textTitle14.getBounds();
        java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets11.createInsetRectangle(rectangle2D19);
        try {
            piePlot1.drawOutline(graphics2D7, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(verticalAlignment15);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangle2D20);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(0, (-1), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Green Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        try {
            org.jfree.chart.title.Title title12 = jFreeChart10.getSubtitle((-32640));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot1, jFreeChart4);
        piePlot1.setExplodePercent((java.lang.Comparable) true, (double) (short) 1);
        java.awt.Shape shape9 = piePlot1.getLegendItemShape();
        piePlot1.setBackgroundAlpha((float) 15);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 128, (double) 100, (double) 100, 0.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.awt.Font font0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "hi!", "");
        java.lang.String str6 = basicProjectInfo5.getCopyright();
        basicProjectInfo5.setVersion("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        java.lang.Class<?> wildcardClass9 = basicProjectInfo5.getClass();
        org.jfree.chart.ui.Library[] libraryArray10 = basicProjectInfo5.getLibraries();
        basicProjectInfo5.addOptionalLibrary("PieLabelLinkStyle.STANDARD");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(libraryArray10);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.validateObject();
        defaultCategoryDataset0.addValue((double) 100.0f, (java.lang.Comparable) 1L, (java.lang.Comparable) (byte) 100);
        int int6 = defaultCategoryDataset0.getColumnCount();
        defaultCategoryDataset0.addValue((java.lang.Number) 128, (java.lang.Comparable) "{0} version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).\n{0} LICENCE TERMS:\nPie Plot", (java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        double double13 = piePlot12.getMaximumExplodePercent();
        double double14 = piePlot12.getShadowYOffset();
        piePlot12.setBackgroundAlpha(0.0f);
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot12);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list2 = defaultKeyedValues2D1.getColumnKeys();
        int int4 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 100.0f);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) (-1L), (java.lang.Comparable) 100.0f);
        try {
            defaultKeyedValues2D1.removeColumn((-5088935));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 89, 1, (java.lang.Comparable) '4', "", "hi!");
        java.lang.String str8 = pieSectionEntity7.getShapeCoords();
        int int9 = pieSectionEntity7.getPieIndex();
        pieSectionEntity7.setPieIndex((int) (short) 0);
        pieSectionEntity7.setSectionIndex(10);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-4,-4,4,4" + "'", str8.equals("-4,-4,4,4"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 89 + "'", int9 == 89);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        int int3 = java.awt.Color.HSBtoRGB((float) 1, (float) (-32640), 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
        java.lang.Object obj2 = null;
        int int3 = objectList1.indexOf(obj2);
        int int4 = objectList1.size();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        strokeMap0.clear();
        boolean boolean3 = strokeMap0.containsKey((java.lang.Comparable) (short) 100);
        boolean boolean5 = strokeMap0.containsKey((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        boolean boolean7 = strokeMap0.containsKey((java.lang.Comparable) (-10));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "RectangleAnchor.CENTER", "RectangleAnchor.CENTER", "ChartChangeEventType.DATASET_UPDATED");
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("{0} version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).\n{0} LICENCE TERMS:\nPie Plot");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name {0} version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).\n{0} LICENCE TERMS:\nPie Plot, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator13 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot12.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator13);
        float float15 = piePlot12.getBackgroundImageAlpha();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle16 = piePlot12.getLabelLinkStyle();
        double double17 = piePlot12.getInteriorGap();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = piePlot12.getInsets();
        piePlot3.setSimpleLabelOffset(rectangleInsets18);
        try {
            piePlot3.setInteriorGap((double) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (2.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.08d + "'", double17 == 0.08d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        piePlot3.setBackgroundAlpha(0.0f);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int10 = color9.getRGB();
        java.awt.Color color11 = color9.darker();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int13 = color12.getBlue();
        java.awt.Color color14 = color12.darker();
        boolean boolean15 = color11.equals((java.lang.Object) color14);
        piePlot3.setSectionOutlinePaint((java.lang.Comparable) (short) 100, (java.awt.Paint) color11);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("PieLabelLinkStyle.STANDARD", font1, (org.jfree.chart.plot.Plot) piePlot3, true);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart18.getLegend();
        java.awt.Paint paint20 = legendTitle19.getItemPaint();
        boolean boolean21 = legendTitle19.getNotify();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-32640) + "'", int10 == (-32640));
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(legendTitle19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        java.lang.String str3 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str3.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        piePlot1.setDataset(pieDataset2);
        java.awt.Paint paint4 = piePlot1.getOutlinePaint();
        java.awt.Paint paint5 = piePlot1.getBaseSectionPaint();
        java.awt.Stroke stroke6 = null;
        piePlot1.setLabelOutlineStroke(stroke6);
        java.awt.Paint paint8 = piePlot1.getLabelBackgroundPaint();
        double double9 = piePlot1.getLabelLinkMargin();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.025d + "'", double9 == 0.025d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        piePlot1.setBackgroundAlpha(0.0f);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int8 = color7.getRGB();
        java.awt.Color color9 = color7.darker();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int11 = color10.getBlue();
        java.awt.Color color12 = color10.darker();
        boolean boolean13 = color9.equals((java.lang.Object) color12);
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) (short) 100, (java.awt.Paint) color9);
        float float15 = piePlot1.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-32640) + "'", int8 == (-32640));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int2 = color1.getBlue();
        java.awt.Color color3 = color1.darker();
        float[] floatArray7 = null;
        float[] floatArray8 = java.awt.Color.RGBtoHSB((int) (short) 0, 1, 1, floatArray7);
        float[] floatArray9 = color3.getRGBColorComponents(floatArray7);
        try {
            float[] floatArray10 = color0.getComponents(floatArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) (short) 1, (-1.0d));
        columnArrangement5.clear();
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement5);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.Font font10 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("hi!", font10);
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = textTitle11.getVerticalAlignment();
        java.lang.Object obj13 = textTitle11.clone();
        textTitle11.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D16 = textTitle11.getBounds();
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle11.getBounds();
        try {
            blockContainer0.draw(graphics2D8, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(verticalAlignment12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D17);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        piePlot1.setBackgroundImageAlpha(0.0f);
        java.awt.Color color5 = java.awt.Color.RED;
        piePlot1.setShadowPaint((java.awt.Paint) color5);
        piePlot1.setStartAngle((double) 255);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int10 = color9.getRGB();
        java.awt.Color color11 = color9.darker();
        piePlot1.setLabelPaint((java.awt.Paint) color9);
        piePlot1.setStartAngle((double) 100);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("hi!", font17);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle18.getVerticalAlignment();
        java.lang.Object obj20 = textTitle18.clone();
        textTitle18.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D23 = textTitle18.getBounds();
        try {
            piePlot1.drawOutline(graphics2D15, rectangle2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-32640) + "'", int10 == (-32640));
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(rectangle2D23);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int2 = color1.getRGB();
        java.awt.Color color3 = java.awt.Color.getColor("", color1);
        java.awt.Paint[] paintArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        boolean boolean5 = color1.equals((java.lang.Object) paintArray4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator10 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot9.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator10);
        piePlot9.setBackgroundAlpha((float) 10);
        java.awt.Paint paint14 = piePlot9.getLabelLinkPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = piePlot9.getSimpleLabelOffset();
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        double double20 = piePlot19.getMaximumExplodePercent();
        double double21 = piePlot19.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double23 = rectangleInsets22.getBottom();
        piePlot19.setSimpleLabelOffset(rectangleInsets22);
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font17, (org.jfree.chart.plot.Plot) piePlot19, false);
        piePlot9.setNoDataMessageFont(font17);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot28 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        multiplePiePlot28.setDataset(categoryDataset29);
        org.jfree.chart.LegendItemCollection legendItemCollection31 = multiplePiePlot28.getLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        multiplePiePlot28.setDataset(categoryDataset32);
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("{0} version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).\n{0} LICENCE TERMS:\nPie Plot", font17, (org.jfree.chart.plot.Plot) multiplePiePlot28, false);
        java.awt.Color color36 = java.awt.Color.lightGray;
        multiplePiePlot28.setAggregatedItemsPaint((java.awt.Paint) color36);
        java.awt.Color color38 = java.awt.Color.BLACK;
        java.awt.Color color39 = color38.darker();
        java.awt.Color color40 = java.awt.Color.LIGHT_GRAY;
        org.jfree.data.general.PieDataset pieDataset41 = null;
        org.jfree.chart.plot.PiePlot piePlot42 = new org.jfree.chart.plot.PiePlot(pieDataset41);
        org.jfree.data.general.PieDataset pieDataset43 = null;
        piePlot42.setDataset(pieDataset43);
        org.jfree.chart.event.PlotChangeListener plotChangeListener45 = null;
        piePlot42.removeChangeListener(plotChangeListener45);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment47 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment48 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement51 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment47, verticalAlignment48, (double) (short) 1, (-1.0d));
        columnArrangement51.clear();
        java.awt.Color color54 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int55 = color54.getBlue();
        java.awt.Color color56 = java.awt.Color.getColor("", color54);
        boolean boolean57 = columnArrangement51.equals((java.lang.Object) color56);
        piePlot42.setOutlinePaint((java.awt.Paint) color56);
        java.awt.Color color59 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int60 = color59.getBlue();
        java.awt.Color color61 = color59.darker();
        float[] floatArray65 = null;
        float[] floatArray66 = java.awt.Color.RGBtoHSB((int) (short) 0, 1, 1, floatArray65);
        float[] floatArray67 = color61.getRGBColorComponents(floatArray65);
        float[] floatArray68 = color56.getColorComponents(floatArray67);
        java.awt.Paint[] paintArray69 = new java.awt.Paint[] { color6, color36, color38, color40, color56 };
        java.awt.Stroke[] strokeArray70 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Paint[] paintArray71 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray72 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray73 = null;
        java.awt.Stroke[] strokeArray74 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke75 = null;
        java.awt.Stroke[] strokeArray76 = new java.awt.Stroke[] { stroke75 };
        java.awt.Shape[] shapeArray77 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier78 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray71, paintArray72, paintArray73, strokeArray74, strokeArray76, shapeArray77);
        java.awt.Shape[] shapeArray79 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier80 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray4, paintArray69, strokeArray70, strokeArray74, shapeArray79);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-32640) + "'", int2 == (-32640));
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(floatArray66);
        org.junit.Assert.assertNotNull(floatArray67);
        org.junit.Assert.assertNotNull(floatArray68);
        org.junit.Assert.assertNotNull(paintArray69);
        org.junit.Assert.assertNotNull(strokeArray70);
        org.junit.Assert.assertNotNull(paintArray71);
        org.junit.Assert.assertNotNull(paintArray72);
        org.junit.Assert.assertNotNull(strokeArray74);
        org.junit.Assert.assertNotNull(strokeArray76);
        org.junit.Assert.assertNotNull(shapeArray77);
        org.junit.Assert.assertNotNull(shapeArray79);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list2 = defaultKeyedValues2D1.getColumnKeys();
        java.util.List list3 = defaultKeyedValues2D1.getRowKeys();
        java.lang.Object obj4 = defaultKeyedValues2D1.clone();
        try {
            java.lang.Number number7 = defaultKeyedValues2D1.getValue((-10), (-49088));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle2.getVerticalAlignment();
        java.lang.Object obj4 = textTitle2.clone();
        textTitle2.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle2.getBounds();
        textTitle2.setMargin(10.0d, (double) (short) 100, (double) 'a', 1.0d);
        textTitle2.setMargin((double) (-16777216), (double) 10, 0.4d, (double) 15);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = textTitle2.getTextAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle2.setHorizontalAlignment(horizontalAlignment19);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        float float4 = piePlot1.getBackgroundAlpha();
        piePlot1.setSectionOutlinesVisible(true);
        int int7 = piePlot1.getBackgroundImageAlignment();
        java.awt.Stroke stroke8 = piePlot1.getBaseSectionOutlineStroke();
        java.awt.Paint[] paintArray9 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray10 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray11 = null;
        java.awt.Stroke[] strokeArray12 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Shape[] shapeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray10, paintArray11, strokeArray12, strokeArray14, shapeArray15);
        org.jfree.chart.util.TableOrder tableOrder17 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        boolean boolean18 = defaultDrawingSupplier16.equals((java.lang.Object) tableOrder17);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int21 = color20.getRGB();
        java.awt.Color color22 = java.awt.Color.getColor("", color20);
        boolean boolean23 = defaultDrawingSupplier16.equals((java.lang.Object) color20);
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier16);
        java.lang.Object obj25 = null;
        boolean boolean26 = defaultDrawingSupplier16.equals(obj25);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(shapeArray15);
        org.junit.Assert.assertNotNull(tableOrder17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-32640) + "'", int21 == (-32640));
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle2.getVerticalAlignment();
        textTitle2.setText("Pie Plot");
        java.lang.Object obj6 = textTitle2.clone();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent7 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle2);
        java.lang.String str8 = titleChangeEvent7.toString();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle2.getVerticalAlignment();
        java.lang.Object obj4 = textTitle2.clone();
        textTitle2.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle2.getBounds();
        java.lang.String str8 = textTitle2.getURLText();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        textTitle2.setBackgroundPaint((java.awt.Paint) color9);
        java.awt.Color color11 = java.awt.Color.YELLOW;
        boolean boolean12 = textTitle2.equals((java.lang.Object) color11);
        java.awt.Font font14 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        double double17 = piePlot16.getMaximumExplodePercent();
        double double18 = piePlot16.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets19.getBottom();
        piePlot16.setSimpleLabelOffset(rectangleInsets19);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font14, (org.jfree.chart.plot.Plot) piePlot16, false);
        textTitle2.setFont(font14);
        java.awt.Color color25 = java.awt.Color.magenta;
        textTitle2.setPaint((java.awt.Paint) color25);
        textTitle2.setPadding((double) (byte) -1, (double) 0, (double) 128, (double) (-32640));
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.awt.Color color2 = java.awt.Color.getColor("Pie Plot", (int) '4');
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        float float4 = piePlot1.getBackgroundAlpha();
        piePlot1.setLabelGap((double) 10L);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        double double9 = piePlot8.getMaximumExplodePercent();
        double double10 = piePlot8.getShadowYOffset();
        float float11 = piePlot8.getBackgroundAlpha();
        piePlot8.setSectionOutlinesVisible(true);
        piePlot8.setIgnoreNullValues(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double17 = rectangleInsets16.getBottom();
        piePlot8.setSimpleLabelOffset(rectangleInsets16);
        java.awt.Paint paint19 = piePlot8.getLabelPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = piePlot8.getLabelPadding();
        piePlot1.setSimpleLabelOffset(rectangleInsets20);
        double double23 = rectangleInsets20.trimHeight(100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 96.0d + "'", double23 == 96.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list14);
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("hi!", font17);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle18.getVerticalAlignment();
        java.lang.Object obj20 = textTitle18.clone();
        jFreeChart10.removeSubtitle((org.jfree.chart.title.Title) textTitle18);
        org.jfree.chart.title.TextTitle textTitle22 = null;
        jFreeChart10.setTitle(textTitle22);
        java.awt.Font font25 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("hi!", font25);
        org.jfree.chart.util.VerticalAlignment verticalAlignment27 = textTitle26.getVerticalAlignment();
        java.lang.Object obj28 = textTitle26.clone();
        double double29 = textTitle26.getContentXOffset();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment30 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle26.setHorizontalAlignment(horizontalAlignment30);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.Object obj33 = null;
        boolean boolean34 = rectangleEdge32.equals(obj33);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D36 = new org.jfree.data.DefaultKeyedValues2D(false);
        boolean boolean37 = rectangleEdge32.equals((java.lang.Object) false);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge32);
        java.awt.Color color39 = org.jfree.chart.ChartColor.LIGHT_RED;
        boolean boolean40 = rectangleEdge38.equals((java.lang.Object) color39);
        boolean boolean41 = textTitle26.equals((java.lang.Object) boolean40);
        jFreeChart10.removeSubtitle((org.jfree.chart.title.Title) textTitle26);
        try {
            org.jfree.chart.plot.XYPlot xYPlot43 = jFreeChart10.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(verticalAlignment27);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment30);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle2.getVerticalAlignment();
        java.lang.Object obj4 = textTitle2.clone();
        textTitle2.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle2.getBounds();
        java.awt.geom.Rectangle2D rectangle2D8 = textTitle2.getBounds();
        double double9 = textTitle2.getHeight();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        double double5 = piePlot4.getMaximumExplodePercent();
        double double6 = piePlot4.getShadowYOffset();
        java.awt.Paint paint7 = piePlot4.getBackgroundPaint();
        piePlot1.setLabelLinkPaint(paint7);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        piePlot1.markerChanged(markerChangeEvent9);
        java.awt.Paint paint11 = piePlot1.getShadowPaint();
        java.awt.Paint paint12 = piePlot1.getLabelOutlinePaint();
        boolean boolean13 = piePlot1.isOutlineVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle2.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.Object obj5 = null;
        boolean boolean6 = rectangleEdge4.equals(obj5);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D8 = new org.jfree.data.DefaultKeyedValues2D(false);
        boolean boolean9 = rectangleEdge4.equals((java.lang.Object) false);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge4);
        boolean boolean11 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge4);
        textTitle2.setPosition(rectangleEdge4);
        boolean boolean13 = textTitle2.getExpandToFitSpace();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.awt.Color color1 = java.awt.Color.getColor("{0} version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).\n{0} LICENCE TERMS:\nPie Plot");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle2.getVerticalAlignment();
        textTitle2.setText("Pie Plot");
        java.lang.Object obj6 = textTitle2.clone();
        java.lang.Object obj7 = textTitle2.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        piePlot1.setBackgroundImageAlpha(0.0f);
        java.awt.Color color5 = java.awt.Color.RED;
        piePlot1.setShadowPaint((java.awt.Paint) color5);
        piePlot1.setForegroundAlpha((float) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = piePlot1.getSimpleLabelOffset();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int5 = color4.getRGB();
        java.awt.Color color6 = color4.darker();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int8 = color7.getBlue();
        java.awt.Color color9 = color7.darker();
        boolean boolean10 = color6.equals((java.lang.Object) color9);
        boolean boolean11 = standardPieSectionLabelGenerator2.equals((java.lang.Object) boolean10);
        java.text.AttributedString attributedString13 = null;
        try {
            standardPieSectionLabelGenerator2.setAttributedLabel((int) (short) -1, attributedString13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-32640) + "'", int5 == (-32640));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot1, jFreeChart4);
        piePlot1.setExplodePercent((java.lang.Comparable) true, (double) (short) 1);
        java.awt.Shape shape9 = piePlot1.getLegendItemShape();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment10, verticalAlignment11, (double) (short) 1, (-1.0d));
        columnArrangement14.clear();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int18 = color17.getBlue();
        java.awt.Color color19 = java.awt.Color.getColor("", color17);
        boolean boolean20 = columnArrangement14.equals((java.lang.Object) color19);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment22 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement25 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment21, verticalAlignment22, (double) (short) 1, (-1.0d));
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) columnArrangement14, (org.jfree.chart.block.Arrangement) columnArrangement25);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.Object obj28 = null;
        boolean boolean29 = rectangleEdge27.equals(obj28);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D31 = new org.jfree.data.DefaultKeyedValues2D(false);
        boolean boolean32 = rectangleEdge27.equals((java.lang.Object) false);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge27);
        boolean boolean34 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge27);
        boolean boolean35 = columnArrangement25.equals((java.lang.Object) rectangleEdge27);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("rect", "hi!", "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list14);
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("hi!", font17);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle18.getVerticalAlignment();
        java.lang.Object obj20 = textTitle18.clone();
        jFreeChart10.removeSubtitle((org.jfree.chart.title.Title) textTitle18);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        textTitle18.setBackgroundPaint((java.awt.Paint) color22);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        double double26 = piePlot25.getMaximumExplodePercent();
        piePlot25.setBackgroundImageAlpha(0.0f);
        java.awt.Color color29 = java.awt.Color.RED;
        piePlot25.setShadowPaint((java.awt.Paint) color29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double32 = rectangleInsets31.getBottom();
        double double34 = rectangleInsets31.trimWidth((double) 0L);
        double double36 = rectangleInsets31.calculateBottomInset((double) (byte) -1);
        piePlot25.setInsets(rectangleInsets31);
        textTitle18.setPadding(rectangleInsets31);
        java.awt.Paint paint39 = textTitle18.getPaint();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent40 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle18);
        java.lang.String str41 = titleChangeEvent40.toString();
        org.jfree.chart.title.Title title42 = titleChangeEvent40.getTitle();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(title42);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list14);
        boolean boolean16 = jFreeChart10.isNotify();
        try {
            java.awt.image.BufferedImage bufferedImage19 = jFreeChart10.createBufferedImage((-16777216), (-32640));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-16777216) and height (-32640) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        java.util.Locale locale3 = jFreeChartResources0.getLocale();
        java.util.Set<java.lang.String> strSet4 = jFreeChartResources0.keySet();
        java.util.Enumeration<java.lang.String> strEnumeration5 = jFreeChartResources0.getKeys();
        java.lang.Object[][] objArray6 = jFreeChartResources0.getContents();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertNotNull(strSet4);
        org.junit.Assert.assertNotNull(strEnumeration5);
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle2.getVerticalAlignment();
        textTitle2.setText("Pie Plot");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets();
        double double8 = rectangleInsets6.calculateTopInset(0.14d);
        textTitle2.setPadding(rectangleInsets6);
        double double11 = rectangleInsets6.calculateRightInset((double) (byte) 10);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        strokeMap0.clear();
        boolean boolean3 = strokeMap0.containsKey((java.lang.Comparable) 0.08d);
        strokeMap0.clear();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        piePlot1.setBackgroundAlpha((float) 10);
        java.awt.Paint paint6 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot1.getSimpleLabelOffset();
        double double9 = rectangleInsets7.extendWidth(4.0d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 6.25d + "'", double9 == 6.25d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle2.getVerticalAlignment();
        textTitle2.setText("Pie Plot");
        java.lang.Object obj6 = textTitle2.clone();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent7 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle2);
        org.jfree.chart.title.Title title8 = titleChangeEvent7.getTitle();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(title8);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        double double3 = piePlot2.getMaximumExplodePercent();
        double double4 = piePlot2.getShadowYOffset();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        piePlot2.setNoDataMessageFont(font5);
        multiplePiePlot0.setNoDataMessageFont(font5);
        java.awt.Color color8 = java.awt.Color.gray;
        multiplePiePlot0.setOutlinePaint((java.awt.Paint) color8);
        org.jfree.chart.JFreeChart jFreeChart10 = multiplePiePlot0.getPieChart();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        java.awt.image.BufferedImage bufferedImage16 = jFreeChart10.createBufferedImage(100, 8, (double) 10.0f, (double) 3, chartRenderingInfo15);
        jFreeChart10.setTitle("VerticalAlignment.CENTER");
        java.awt.Paint paint19 = null;
        jFreeChart10.setBackgroundPaint(paint19);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(jFreeChart10);
        org.junit.Assert.assertNotNull(bufferedImage16);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        piePlot1.setBackgroundAlpha((float) 10);
        java.awt.Paint paint6 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot1.getSimpleLabelOffset();
        org.jfree.chart.util.UnitType unitType8 = rectangleInsets7.getUnitType();
        double double9 = rectangleInsets7.getLeft();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(unitType8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.18d + "'", double9 == 0.18d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        float float4 = piePlot1.getBackgroundImageAlpha();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle5 = piePlot1.getLabelLinkStyle();
        double double6 = piePlot1.getInteriorGap();
        java.awt.Paint paint7 = piePlot1.getLabelPaint();
        piePlot1.setLabelLinksVisible(true);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.5f + "'", float4 == 0.5f);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        piePlot1.setBackgroundImageAlpha(0.0f);
        piePlot1.setStartAngle((double) 1L);
        java.awt.Paint paint7 = piePlot1.getBaseSectionPaint();
        double double8 = piePlot1.getStartAngle();
        java.awt.Stroke stroke9 = piePlot1.getOutlineStroke();
        piePlot1.zoom((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        piePlot1.setBackgroundAlpha((float) 10);
        java.awt.Paint paint6 = piePlot1.getBaseSectionPaint();
        piePlot1.setExplodePercent((java.lang.Comparable) 1L, (double) 0L);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.toString();
//        projectInfo0.setName("{0}");
//        projectInfo0.setInfo("RectangleAnchor.CENTER");
//        projectInfo0.setCopyright("");
//        java.util.List list8 = projectInfo0.getContributors();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0} version hi!.\nVerticalAlignment.CENTER.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:RectangleAnchor.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).{0} hi! (RectangleAnchor.CENTER).\n{0} LICENCE TERMS:\nPie Plot" + "'", str1.equals("{0} version hi!.\nVerticalAlignment.CENTER.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:RectangleAnchor.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).{0} hi! (RectangleAnchor.CENTER).\n{0} LICENCE TERMS:\nPie Plot"));
//        org.junit.Assert.assertNotNull(list8);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        double double3 = piePlot2.getMaximumExplodePercent();
        double double4 = piePlot2.getShadowYOffset();
        float float5 = piePlot2.getBackgroundAlpha();
        piePlot2.setSectionOutlinesVisible(true);
        int int8 = piePlot2.getBackgroundImageAlignment();
        java.awt.Font font11 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        double double14 = piePlot13.getMaximumExplodePercent();
        double double15 = piePlot13.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double17 = rectangleInsets16.getBottom();
        piePlot13.setSimpleLabelOffset(rectangleInsets16);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font11, (org.jfree.chart.plot.Plot) piePlot13, false);
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot(pieDataset21);
        double double23 = piePlot22.getMaximumExplodePercent();
        double double24 = piePlot22.getShadowYOffset();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int26 = color25.getBlue();
        java.awt.Color color27 = color25.darker();
        int int28 = color27.getRed();
        java.awt.Color color29 = color27.darker();
        piePlot22.setLabelOutlinePaint((java.awt.Paint) color29);
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart("Rotation.ANTICLOCKWISE", font11, (org.jfree.chart.plot.Plot) piePlot22, false);
        piePlot2.setNoDataMessageFont(font11);
        boolean boolean34 = rectangleAnchor0.equals((java.lang.Object) font11);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 4.0d + "'", double24 == 4.0d);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 89 + "'", int28 == 89);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 2, (double) (short) 1, 0.0d, (double) 10, paint4);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=0,g=128,b=0]", "{0} version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).\n{0} LICENCE TERMS:\nPie Plot", "Rotation.ANTICLOCKWISE", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        double double3 = piePlot2.getMaximumExplodePercent();
        double double4 = piePlot2.getShadowYOffset();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        piePlot2.setNoDataMessageFont(font5);
        multiplePiePlot0.setNoDataMessageFont(font5);
        java.awt.Color color8 = java.awt.Color.gray;
        multiplePiePlot0.setOutlinePaint((java.awt.Paint) color8);
        java.lang.Object obj10 = multiplePiePlot0.clone();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        piePlot4.setDataset(pieDataset5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot4.removeChangeListener(plotChangeListener7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement13 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment9, verticalAlignment10, (double) (short) 1, (-1.0d));
        columnArrangement13.clear();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int17 = color16.getBlue();
        java.awt.Color color18 = java.awt.Color.getColor("", color16);
        boolean boolean19 = columnArrangement13.equals((java.lang.Object) color18);
        piePlot4.setOutlinePaint((java.awt.Paint) color18);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int22 = color21.getBlue();
        java.awt.Color color23 = color21.darker();
        float[] floatArray27 = null;
        float[] floatArray28 = java.awt.Color.RGBtoHSB((int) (short) 0, 1, 1, floatArray27);
        float[] floatArray29 = color23.getRGBColorComponents(floatArray27);
        float[] floatArray30 = color18.getColorComponents(floatArray29);
        float[] floatArray31 = color0.getColorComponents(colorSpace2, floatArray29);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.awt.Font font2 = null;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        double double5 = piePlot4.getMaximumExplodePercent();
        double double6 = piePlot4.getShadowYOffset();
        piePlot4.setBackgroundAlpha(0.0f);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int11 = color10.getRGB();
        java.awt.Color color12 = color10.darker();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int14 = color13.getBlue();
        java.awt.Color color15 = color13.darker();
        boolean boolean16 = color12.equals((java.lang.Object) color15);
        piePlot4.setSectionOutlinePaint((java.lang.Comparable) (short) 100, (java.awt.Paint) color12);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("PieLabelLinkStyle.STANDARD", font2, (org.jfree.chart.plot.Plot) piePlot4, true);
        org.jfree.chart.title.LegendTitle legendTitle20 = jFreeChart19.getLegend();
        java.lang.Object obj21 = jFreeChart19.clone();
        boolean boolean22 = rectangleEdge0.equals(obj21);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-32640) + "'", int11 == (-32640));
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(legendTitle20);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        org.jfree.chart.ui.Library library6 = new org.jfree.chart.ui.Library("", "", "hi!", "hi!");
        projectInfo0.addLibrary(library6);
        projectInfo0.setLicenceName("RectangleAnchor.CENTER");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("Pie Plot", "RectangleAnchor.CENTER");
        java.lang.String str3 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pie Plot" + "'", str3.equals("Pie Plot"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        piePlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment5, verticalAlignment6, (double) (short) 1, (-1.0d));
        boolean boolean10 = piePlot1.equals((java.lang.Object) verticalAlignment6);
        try {
            piePlot1.setBackgroundImageAlpha((float) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list2 = defaultKeyedValues2D1.getColumnKeys();
        int int4 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 100.0f);
        defaultKeyedValues2D1.clear();
        defaultKeyedValues2D1.setValue((java.lang.Number) (-1.0f), (java.lang.Comparable) "", (java.lang.Comparable) "RectangleAnchor.CENTER");
        try {
            defaultKeyedValues2D1.removeColumn(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list14);
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("hi!", font17);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle18.getVerticalAlignment();
        java.lang.Object obj20 = textTitle18.clone();
        jFreeChart10.removeSubtitle((org.jfree.chart.title.Title) textTitle18);
        org.jfree.chart.title.TextTitle textTitle22 = null;
        jFreeChart10.setTitle(textTitle22);
        java.awt.Font font25 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("hi!", font25);
        org.jfree.chart.util.VerticalAlignment verticalAlignment27 = textTitle26.getVerticalAlignment();
        java.lang.Object obj28 = textTitle26.clone();
        double double29 = textTitle26.getContentXOffset();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment30 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle26.setHorizontalAlignment(horizontalAlignment30);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.Object obj33 = null;
        boolean boolean34 = rectangleEdge32.equals(obj33);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D36 = new org.jfree.data.DefaultKeyedValues2D(false);
        boolean boolean37 = rectangleEdge32.equals((java.lang.Object) false);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge32);
        java.awt.Color color39 = org.jfree.chart.ChartColor.LIGHT_RED;
        boolean boolean40 = rectangleEdge38.equals((java.lang.Object) color39);
        boolean boolean41 = textTitle26.equals((java.lang.Object) boolean40);
        jFreeChart10.removeSubtitle((org.jfree.chart.title.Title) textTitle26);
        java.awt.Font font44 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("hi!", font44);
        org.jfree.chart.util.VerticalAlignment verticalAlignment46 = textTitle45.getVerticalAlignment();
        java.lang.Object obj47 = textTitle45.clone();
        textTitle45.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D50 = textTitle45.getBounds();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent51 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textTitle45);
        textTitle45.setURLText("");
        org.jfree.chart.util.VerticalAlignment verticalAlignment54 = textTitle45.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double56 = rectangleInsets55.getBottom();
        java.awt.Font font58 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle59 = new org.jfree.chart.title.TextTitle("hi!", font58);
        org.jfree.chart.util.VerticalAlignment verticalAlignment60 = textTitle59.getVerticalAlignment();
        java.lang.Object obj61 = textTitle59.clone();
        textTitle59.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D64 = textTitle59.getBounds();
        rectangleInsets55.trim(rectangle2D64);
        textTitle45.setBounds(rectangle2D64);
        textTitle45.setExpandToFitSpace(true);
        jFreeChart10.setTitle(textTitle45);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(verticalAlignment27);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment30);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(verticalAlignment46);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(verticalAlignment54);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertNotNull(verticalAlignment60);
        org.junit.Assert.assertNotNull(obj61);
        org.junit.Assert.assertNotNull(rectangle2D64);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle2.getVerticalAlignment();
        java.lang.Object obj4 = textTitle2.clone();
        textTitle2.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle2.getBounds();
        textTitle2.setMargin(10.0d, (double) (short) 100, (double) 'a', 1.0d);
        textTitle2.setMargin((double) (-16777216), (double) 10, 0.4d, (double) 15);
        textTitle2.setID("{0} version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).\n{0} LICENCE TERMS:\nPie Plot");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangle2D7);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list14);
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("hi!", font17);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle18.getVerticalAlignment();
        java.lang.Object obj20 = textTitle18.clone();
        jFreeChart10.removeSubtitle((org.jfree.chart.title.Title) textTitle18);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        textTitle18.setBackgroundPaint((java.awt.Paint) color22);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        double double26 = piePlot25.getMaximumExplodePercent();
        piePlot25.setBackgroundImageAlpha(0.0f);
        java.awt.Color color29 = java.awt.Color.RED;
        piePlot25.setShadowPaint((java.awt.Paint) color29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double32 = rectangleInsets31.getBottom();
        double double34 = rectangleInsets31.trimWidth((double) 0L);
        double double36 = rectangleInsets31.calculateBottomInset((double) (byte) -1);
        piePlot25.setInsets(rectangleInsets31);
        textTitle18.setPadding(rectangleInsets31);
        java.awt.Paint paint39 = textTitle18.getPaint();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent40 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle18);
        org.jfree.chart.JFreeChart jFreeChart41 = titleChangeEvent40.getChart();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNull(jFreeChart41);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.clear();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = blockContainer0.arrange(graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.validateObject();
        defaultCategoryDataset0.addValue((double) 100.0f, (java.lang.Comparable) 1L, (java.lang.Comparable) (byte) 100);
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (byte) 100, (java.lang.Comparable) (byte) -1);
        try {
            java.lang.Comparable comparable10 = defaultCategoryDataset0.getColumnKey(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.toString();
//        java.util.List list2 = projectInfo0.getContributors();
//        projectInfo0.setVersion("VerticalAlignment.CENTER");
//        java.lang.String str5 = projectInfo0.getLicenceText();
//        projectInfo0.setCopyright("");
//        org.jfree.data.general.PieDataset pieDataset8 = null;
//        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
//        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator10 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//        piePlot9.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator10);
//        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
//        int int13 = color12.getRGB();
//        java.awt.Color color14 = color12.darker();
//        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_RED;
//        int int16 = color15.getBlue();
//        java.awt.Color color17 = color15.darker();
//        boolean boolean18 = color14.equals((java.lang.Object) color17);
//        boolean boolean19 = standardPieSectionLabelGenerator10.equals((java.lang.Object) boolean18);
//        java.lang.Object obj20 = standardPieSectionLabelGenerator10.clone();
//        boolean boolean21 = projectInfo0.equals(obj20);
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0} version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:RectangleAnchor.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).{0} hi! (RectangleAnchor.CENTER).  (hi!).\n{0} LICENCE TERMS:\nPie Plot" + "'", str1.equals("{0} version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:RectangleAnchor.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).{0} hi! (RectangleAnchor.CENTER).  (hi!).\n{0} LICENCE TERMS:\nPie Plot"));
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pie Plot" + "'", str5.equals("Pie Plot"));
//        org.junit.Assert.assertNotNull(color12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-32640) + "'", int13 == (-32640));
//        org.junit.Assert.assertNotNull(color14);
//        org.junit.Assert.assertNotNull(color15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(color17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(obj20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.awt.Font font1 = null;
        java.awt.Font font3 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        double double6 = piePlot5.getMaximumExplodePercent();
        double double7 = piePlot5.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double9 = rectangleInsets8.getBottom();
        piePlot5.setSimpleLabelOffset(rectangleInsets8);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font3, (org.jfree.chart.plot.Plot) piePlot5, false);
        double double13 = piePlot5.getShadowYOffset();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        double double16 = piePlot15.getMaximumExplodePercent();
        piePlot5.setParent((org.jfree.chart.plot.Plot) piePlot15);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("{0} version VerticalAlignment.CENTER.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).  (hi!).\n{0} LICENCE TERMS:\nPie Plot", font1, (org.jfree.chart.plot.Plot) piePlot5, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = null;
        try {
            jFreeChart19.handleClick((-16777216), (int) (byte) 100, chartRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        piePlot1.setBackgroundImageAlpha(0.0f);
        java.awt.Color color5 = java.awt.Color.RED;
        piePlot1.setShadowPaint((java.awt.Paint) color5);
        piePlot1.setForegroundAlpha((float) 8);
        java.awt.Font font10 = null;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        double double13 = piePlot12.getMaximumExplodePercent();
        double double14 = piePlot12.getShadowYOffset();
        piePlot12.setBackgroundAlpha(0.0f);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int19 = color18.getRGB();
        java.awt.Color color20 = color18.darker();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int22 = color21.getBlue();
        java.awt.Color color23 = color21.darker();
        boolean boolean24 = color20.equals((java.lang.Object) color23);
        piePlot12.setSectionOutlinePaint((java.lang.Comparable) (short) 100, (java.awt.Paint) color20);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("PieLabelLinkStyle.STANDARD", font10, (org.jfree.chart.plot.Plot) piePlot12, true);
        org.jfree.chart.title.LegendTitle legendTitle28 = jFreeChart27.getLegend();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = legendTitle28.getLegendItemGraphicPadding();
        org.jfree.data.general.PieDataset pieDataset30 = null;
        org.jfree.chart.plot.PiePlot piePlot31 = new org.jfree.chart.plot.PiePlot(pieDataset30);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator32 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot31.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator32);
        org.jfree.chart.JFreeChart jFreeChart34 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent35 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot31, jFreeChart34);
        piePlot31.setExplodePercent((java.lang.Comparable) true, (double) (short) 1);
        java.awt.Shape shape39 = piePlot31.getLegendItemShape();
        org.jfree.chart.block.LineBorder lineBorder41 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint42 = lineBorder41.getPaint();
        piePlot31.setSectionOutlinePaint((java.lang.Comparable) 0.08d, paint42);
        legendTitle28.setBackgroundPaint(paint42);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double46 = rectangleInsets45.getBottom();
        double double48 = rectangleInsets45.calculateTopOutset((double) 0.0f);
        java.lang.String str49 = rectangleInsets45.toString();
        double double51 = rectangleInsets45.calculateLeftOutset(0.0d);
        legendTitle28.setLegendItemGraphicPadding(rectangleInsets45);
        boolean boolean53 = piePlot1.equals((java.lang.Object) rectangleInsets45);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-32640) + "'", int19 == (-32640));
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(legendTitle28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str49.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list2 = defaultKeyedValues2D1.getColumnKeys();
        int int4 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 100.0f);
        int int6 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) '#');
        java.lang.Comparable comparable8 = null;
        try {
            java.lang.Number number9 = defaultKeyedValues2D1.getValue((java.lang.Comparable) (-1.0d), comparable8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 89, 1, (java.lang.Comparable) '4', "", "hi!");
        pieSectionEntity7.setSectionKey((java.lang.Comparable) 89);
        pieSectionEntity7.setURLText("");
        java.lang.String str12 = pieSectionEntity7.getToolTipText();
        boolean boolean14 = pieSectionEntity7.equals((java.lang.Object) 0.08d);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        float float4 = piePlot1.getBackgroundAlpha();
        java.awt.Image image5 = null;
        piePlot1.setBackgroundImage(image5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot1.getLabelPadding();
        java.awt.Paint paint8 = piePlot1.getLabelBackgroundPaint();
        boolean boolean9 = piePlot1.getLabelLinksVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("{0} version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).\n{0} LICENCE TERMS:\nPie Plot", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        float float4 = piePlot1.getBackgroundAlpha();
        piePlot1.setSectionOutlinesVisible(true);
        int int7 = piePlot1.getBackgroundImageAlignment();
        org.jfree.data.general.DatasetGroup datasetGroup8 = piePlot1.getDatasetGroup();
        boolean boolean9 = piePlot1.isCircular();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int12 = color11.getRGB();
        java.awt.Color color13 = java.awt.Color.getColor("", color11);
        piePlot1.setShadowPaint((java.awt.Paint) color11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNull(datasetGroup8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-32640) + "'", int12 == (-32640));
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        float float4 = piePlot1.getBackgroundAlpha();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Image image7 = piePlot6.getBackgroundImage();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot6.setOutlineStroke(stroke8);
        piePlot1.setLabelLinkStroke(stroke8);
        piePlot1.setExplodePercent((java.lang.Comparable) (short) -1, (double) 8);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "hi!", "");
        java.lang.String str6 = basicProjectInfo5.getCopyright();
        org.jfree.chart.ui.ProjectInfo projectInfo7 = org.jfree.chart.JFreeChart.INFO;
        basicProjectInfo5.addLibrary((org.jfree.chart.ui.Library) projectInfo7);
        projectInfo7.addOptionalLibrary("PieSection: 89, 1(4)");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(projectInfo7);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = multiplePiePlot0.getLegendItems();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot0.getPieChart();
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(jFreeChart4);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list14);
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("hi!", font17);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle18.getVerticalAlignment();
        java.lang.Object obj20 = textTitle18.clone();
        jFreeChart10.removeSubtitle((org.jfree.chart.title.Title) textTitle18);
        org.jfree.chart.title.TextTitle textTitle22 = jFreeChart10.getTitle();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.Font font25 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("hi!", font25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = textTitle26.getPadding();
        java.awt.Font font29 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("hi!", font29);
        org.jfree.chart.util.VerticalAlignment verticalAlignment31 = textTitle30.getVerticalAlignment();
        java.lang.Object obj32 = textTitle30.clone();
        textTitle30.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D35 = textTitle30.getBounds();
        java.awt.geom.Rectangle2D rectangle2D36 = rectangleInsets27.createInsetRectangle(rectangle2D35);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.Object obj38 = null;
        boolean boolean39 = rectangleEdge37.equals(obj38);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D41 = new org.jfree.data.DefaultKeyedValues2D(false);
        boolean boolean42 = rectangleEdge37.equals((java.lang.Object) false);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge37);
        double double44 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D35, rectangleEdge37);
        try {
            jFreeChart10.draw(graphics2D23, rectangle2D35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(textTitle22);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(verticalAlignment31);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list2 = defaultKeyedValues2D1.getColumnKeys();
        int int4 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 100.0f);
        int int6 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) '#');
        try {
            java.lang.Comparable comparable8 = defaultKeyedValues2D1.getRowKey(128);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 128, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("hi!", font2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = textTitle3.getPadding();
        java.awt.Font font6 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("hi!", font6);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = textTitle7.getVerticalAlignment();
        java.lang.Object obj9 = textTitle7.clone();
        textTitle7.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D12 = textTitle7.getBounds();
        java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets4.createInsetRectangle(rectangle2D12);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType14 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = rectangleInsets0.createAdjustedRectangle(rectangle2D13, lengthAdjustmentType14, lengthAdjustmentType15);
        double double18 = rectangleInsets0.calculateBottomOutset((double) (-1L));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        piePlot1.setBackgroundImageAlpha(0.0f);
        java.awt.Color color5 = java.awt.Color.RED;
        piePlot1.setShadowPaint((java.awt.Paint) color5);
        piePlot1.setStartAngle((double) 255);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator11 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot10.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator11);
        float float13 = piePlot10.getBackgroundImageAlpha();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle14 = piePlot10.getLabelLinkStyle();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int16 = color15.getRGB();
        java.awt.Color color17 = color15.darker();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int19 = color18.getBlue();
        java.awt.Color color20 = color18.darker();
        boolean boolean21 = color17.equals((java.lang.Object) color20);
        piePlot10.setLabelPaint((java.awt.Paint) color17);
        piePlot1.setLabelLinkPaint((java.awt.Paint) color17);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-32640) + "'", int16 == (-32640));
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        textTitle2.draw(graphics2D3, rectangle2D4);
        textTitle2.setHeight((double) (byte) -1);
        textTitle2.setToolTipText("TableOrder.BY_COLUMN");
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle2.setBackgroundPaint((java.awt.Paint) color10);
        textTitle2.setURLText("PieLabelLinkStyle.STANDARD");
        org.jfree.chart.util.TableOrder tableOrder14 = org.jfree.chart.util.TableOrder.BY_ROW;
        java.awt.Font font16 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        double double19 = piePlot18.getMaximumExplodePercent();
        double double20 = piePlot18.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double22 = rectangleInsets21.getBottom();
        piePlot18.setSimpleLabelOffset(rectangleInsets21);
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font16, (org.jfree.chart.plot.Plot) piePlot18, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D27 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list28 = defaultKeyedValues2D27.getColumnKeys();
        java.util.List list29 = defaultKeyedValues2D27.getRowKeys();
        jFreeChart25.setSubtitles(list29);
        java.awt.Font font32 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle33 = new org.jfree.chart.title.TextTitle("hi!", font32);
        org.jfree.chart.util.VerticalAlignment verticalAlignment34 = textTitle33.getVerticalAlignment();
        java.lang.Object obj35 = textTitle33.clone();
        jFreeChart25.removeSubtitle((org.jfree.chart.title.Title) textTitle33);
        org.jfree.chart.title.TextTitle textTitle37 = null;
        jFreeChart25.setTitle(textTitle37);
        boolean boolean39 = jFreeChart25.isBorderVisible();
        java.awt.Paint paint40 = jFreeChart25.getBackgroundPaint();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent41 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) tableOrder14, jFreeChart25);
        textTitle2.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart25);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(tableOrder14);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(verticalAlignment34);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        java.awt.Font font4 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        piePlot1.setNoDataMessageFont(font4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = piePlot1.getLabelPadding();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        double double5 = piePlot4.getMaximumExplodePercent();
        double double6 = piePlot4.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double8 = rectangleInsets7.getBottom();
        piePlot4.setSimpleLabelOffset(rectangleInsets7);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font2, (org.jfree.chart.plot.Plot) piePlot4, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D13 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list14 = defaultKeyedValues2D13.getColumnKeys();
        java.util.List list15 = defaultKeyedValues2D13.getRowKeys();
        jFreeChart11.setSubtitles(list15);
        java.awt.Font font18 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("hi!", font18);
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = textTitle19.getVerticalAlignment();
        java.lang.Object obj21 = textTitle19.clone();
        jFreeChart11.removeSubtitle((org.jfree.chart.title.Title) textTitle19);
        org.jfree.chart.title.TextTitle textTitle23 = null;
        jFreeChart11.setTitle(textTitle23);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) '4', jFreeChart11);
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot(pieDataset26);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator28 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot27.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator28);
        org.jfree.chart.JFreeChart jFreeChart30 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot27, jFreeChart30);
        org.jfree.chart.JFreeChart jFreeChart32 = chartChangeEvent31.getChart();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType33 = chartChangeEvent31.getType();
        chartChangeEvent25.setType(chartChangeEventType33);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(verticalAlignment20);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNull(jFreeChart32);
        org.junit.Assert.assertNotNull(chartChangeEventType33);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list14);
        java.awt.RenderingHints renderingHints16 = jFreeChart10.getRenderingHints();
        java.lang.Object obj17 = jFreeChart10.clone();
        jFreeChart10.removeLegend();
        jFreeChart10.removeLegend();
        int int20 = jFreeChart10.getBackgroundImageAlignment();
        try {
            java.awt.image.BufferedImage bufferedImage23 = jFreeChart10.createBufferedImage((-668), 128);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-668) and height (128) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(renderingHints16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 15 + "'", int20 == 15);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot2.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator3);
        piePlot2.setBackgroundAlpha((float) 10);
        java.awt.Paint paint7 = piePlot2.getLabelLinkPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot2.getSimpleLabelOffset();
        java.awt.Font font10 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        double double13 = piePlot12.getMaximumExplodePercent();
        double double14 = piePlot12.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets15.getBottom();
        piePlot12.setSimpleLabelOffset(rectangleInsets15);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font10, (org.jfree.chart.plot.Plot) piePlot12, false);
        piePlot2.setNoDataMessageFont(font10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot21 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        multiplePiePlot21.setDataset(categoryDataset22);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = multiplePiePlot21.getLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        multiplePiePlot21.setDataset(categoryDataset25);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("{0} version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).\n{0} LICENCE TERMS:\nPie Plot", font10, (org.jfree.chart.plot.Plot) multiplePiePlot21, false);
        jFreeChart28.setTextAntiAlias(true);
        boolean boolean31 = jFreeChart28.isNotify();
        org.jfree.data.general.PieDataset pieDataset32 = null;
        org.jfree.chart.plot.PiePlot piePlot33 = new org.jfree.chart.plot.PiePlot(pieDataset32);
        java.awt.Image image34 = piePlot33.getBackgroundImage();
        java.awt.Image image35 = piePlot33.getBackgroundImage();
        try {
            jFreeChart28.setTextAntiAlias((java.lang.Object) piePlot33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: org.jfree.chart.plot.PiePlot@63fc6eb0 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection24);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(image34);
        org.junit.Assert.assertNull(image35);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list14);
        java.awt.RenderingHints renderingHints16 = jFreeChart10.getRenderingHints();
        java.lang.Object obj17 = jFreeChart10.clone();
        jFreeChart10.removeLegend();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = null;
        try {
            jFreeChart10.plotChanged(plotChangeEvent19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(renderingHints16);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        java.awt.Font font4 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        double double7 = piePlot6.getMaximumExplodePercent();
        double double8 = piePlot6.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double10 = rectangleInsets9.getBottom();
        piePlot6.setSimpleLabelOffset(rectangleInsets9);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font4, (org.jfree.chart.plot.Plot) piePlot6, false);
        double double14 = piePlot6.getShadowYOffset();
        boolean boolean15 = defaultKeyedValues2D1.equals((java.lang.Object) double14);
        defaultKeyedValues2D1.setValue((java.lang.Number) 0.0f, (java.lang.Comparable) (-668), (java.lang.Comparable) 10);
        int int20 = defaultKeyedValues2D1.getColumnCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 89, 1, (java.lang.Comparable) '4', "", "hi!");
        pieSectionEntity7.setPieIndex((int) (short) 10);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        pieSectionEntity7.setDataset(pieDataset10);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        pieSectionEntity7.setDataset(pieDataset12);
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 89, 1, (java.lang.Comparable) '4', "", "hi!");
        java.lang.String str8 = pieSectionEntity7.getShapeCoords();
        int int9 = pieSectionEntity7.getPieIndex();
        java.lang.String str10 = pieSectionEntity7.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-4,-4,4,4" + "'", str8.equals("-4,-4,4,4"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 89 + "'", int9 == 89);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PieSection: 89, 1(4)" + "'", str10.equals("PieSection: 89, 1(4)"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot2.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator3);
        piePlot2.setBackgroundAlpha((float) 10);
        java.awt.Paint paint7 = piePlot2.getLabelLinkPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot2.getSimpleLabelOffset();
        java.awt.Font font10 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        double double13 = piePlot12.getMaximumExplodePercent();
        double double14 = piePlot12.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets15.getBottom();
        piePlot12.setSimpleLabelOffset(rectangleInsets15);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font10, (org.jfree.chart.plot.Plot) piePlot12, false);
        piePlot2.setNoDataMessageFont(font10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot21 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        multiplePiePlot21.setDataset(categoryDataset22);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = multiplePiePlot21.getLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        multiplePiePlot21.setDataset(categoryDataset25);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("{0} version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).\n{0} LICENCE TERMS:\nPie Plot", font10, (org.jfree.chart.plot.Plot) multiplePiePlot21, false);
        jFreeChart28.setTextAntiAlias(true);
        java.awt.Font font33 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot(pieDataset34);
        double double36 = piePlot35.getMaximumExplodePercent();
        double double37 = piePlot35.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double39 = rectangleInsets38.getBottom();
        piePlot35.setSimpleLabelOffset(rectangleInsets38);
        org.jfree.chart.JFreeChart jFreeChart42 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font33, (org.jfree.chart.plot.Plot) piePlot35, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D44 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list45 = defaultKeyedValues2D44.getColumnKeys();
        java.util.List list46 = defaultKeyedValues2D44.getRowKeys();
        jFreeChart42.setSubtitles(list46);
        java.awt.Font font49 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle("hi!", font49);
        org.jfree.chart.util.VerticalAlignment verticalAlignment51 = textTitle50.getVerticalAlignment();
        java.lang.Object obj52 = textTitle50.clone();
        jFreeChart42.removeSubtitle((org.jfree.chart.title.Title) textTitle50);
        try {
            jFreeChart28.addSubtitle((int) (short) -1, (org.jfree.chart.title.Title) textTitle50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection24);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 4.0d + "'", double37 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(verticalAlignment51);
        org.junit.Assert.assertNotNull(obj52);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle2.getPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.Object obj5 = null;
        boolean boolean6 = rectangleEdge4.equals(obj5);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D8 = new org.jfree.data.DefaultKeyedValues2D(false);
        boolean boolean9 = rectangleEdge4.equals((java.lang.Object) false);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge4);
        boolean boolean11 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge4);
        textTitle2.setPosition(rectangleEdge4);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = textTitle2.getPadding();
        java.lang.Object obj14 = textTitle2.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) (short) 1, (-1.0d));
        columnArrangement5.clear();
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement5);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = null;
        try {
            org.jfree.chart.util.Size2D size2D10 = blockContainer0.arrange(graphics2D8, rectangleConstraint9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        float float4 = piePlot1.getBackgroundImageAlpha();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle5 = piePlot1.getLabelLinkStyle();
        int int6 = piePlot1.getBackgroundImageAlignment();
        boolean boolean7 = piePlot1.getIgnoreNullValues();
        piePlot1.setMaximumLabelWidth(0.0d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.5f + "'", float4 == 0.5f);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        piePlot3.setBackgroundAlpha(0.0f);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int10 = color9.getRGB();
        java.awt.Color color11 = color9.darker();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int13 = color12.getBlue();
        java.awt.Color color14 = color12.darker();
        boolean boolean15 = color11.equals((java.lang.Object) color14);
        piePlot3.setSectionOutlinePaint((java.lang.Comparable) (short) 100, (java.awt.Paint) color11);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("PieLabelLinkStyle.STANDARD", font1, (org.jfree.chart.plot.Plot) piePlot3, true);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart18.getLegend();
        java.awt.Paint paint20 = legendTitle19.getItemPaint();
        java.awt.Font font21 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        legendTitle19.setItemFont(font21);
        java.awt.Paint[] paintArray23 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray24 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray25 = null;
        java.awt.Stroke[] strokeArray26 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke27 = null;
        java.awt.Stroke[] strokeArray28 = new java.awt.Stroke[] { stroke27 };
        java.awt.Shape[] shapeArray29 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray23, paintArray24, paintArray25, strokeArray26, strokeArray28, shapeArray29);
        java.awt.Shape shape31 = defaultDrawingSupplier30.getNextShape();
        java.awt.Paint paint32 = defaultDrawingSupplier30.getNextPaint();
        boolean boolean33 = legendTitle19.equals((java.lang.Object) paint32);
        java.awt.Paint paint34 = legendTitle19.getItemPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = legendTitle19.getLegendItemGraphicLocation();
        java.awt.Graphics2D graphics2D36 = null;
        java.awt.Color color37 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.image.ColorModel colorModel38 = null;
        java.awt.Rectangle rectangle39 = null;
        java.awt.Font font41 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("hi!", font41);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = textTitle42.getPadding();
        java.awt.Font font45 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle("hi!", font45);
        org.jfree.chart.util.VerticalAlignment verticalAlignment47 = textTitle46.getVerticalAlignment();
        java.lang.Object obj48 = textTitle46.clone();
        textTitle46.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D51 = textTitle46.getBounds();
        java.awt.geom.Rectangle2D rectangle2D52 = rectangleInsets43.createInsetRectangle(rectangle2D51);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.Object obj54 = null;
        boolean boolean55 = rectangleEdge53.equals(obj54);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D57 = new org.jfree.data.DefaultKeyedValues2D(false);
        boolean boolean58 = rectangleEdge53.equals((java.lang.Object) false);
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge53);
        double double60 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D51, rectangleEdge53);
        java.awt.geom.AffineTransform affineTransform61 = null;
        java.awt.Font font63 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset64 = null;
        org.jfree.chart.plot.PiePlot piePlot65 = new org.jfree.chart.plot.PiePlot(pieDataset64);
        double double66 = piePlot65.getMaximumExplodePercent();
        double double67 = piePlot65.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double69 = rectangleInsets68.getBottom();
        piePlot65.setSimpleLabelOffset(rectangleInsets68);
        org.jfree.chart.JFreeChart jFreeChart72 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font63, (org.jfree.chart.plot.Plot) piePlot65, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D74 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list75 = defaultKeyedValues2D74.getColumnKeys();
        java.util.List list76 = defaultKeyedValues2D74.getRowKeys();
        jFreeChart72.setSubtitles(list76);
        java.awt.RenderingHints renderingHints78 = jFreeChart72.getRenderingHints();
        java.awt.PaintContext paintContext79 = color37.createContext(colorModel38, rectangle39, rectangle2D51, affineTransform61, renderingHints78);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D81 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list82 = defaultKeyedValues2D81.getColumnKeys();
        java.util.List list83 = defaultKeyedValues2D81.getRowKeys();
        java.lang.Object obj84 = defaultKeyedValues2D81.clone();
        defaultKeyedValues2D81.clear();
        try {
            java.lang.Object obj86 = legendTitle19.draw(graphics2D36, (java.awt.geom.Rectangle2D) rectangle39, (java.lang.Object) defaultKeyedValues2D81);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-32640) + "'", int10 == (-32640));
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(legendTitle19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(paintArray23);
        org.junit.Assert.assertNotNull(paintArray24);
        org.junit.Assert.assertNotNull(strokeArray26);
        org.junit.Assert.assertNotNull(strokeArray28);
        org.junit.Assert.assertNotNull(shapeArray29);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(verticalAlignment47);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(font63);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 4.0d + "'", double67 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(list75);
        org.junit.Assert.assertNotNull(list76);
        org.junit.Assert.assertNotNull(renderingHints78);
        org.junit.Assert.assertNotNull(paintContext79);
        org.junit.Assert.assertNotNull(list82);
        org.junit.Assert.assertNotNull(list83);
        org.junit.Assert.assertNotNull(obj84);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot1, jFreeChart4);
        piePlot1.setExplodePercent((java.lang.Comparable) true, (double) (short) 1);
        double double9 = piePlot1.getMinimumArcAngleToDraw();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0E-5d + "'", double9 == 1.0E-5d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        java.lang.Comparable comparable4 = null;
        try {
            java.lang.Number number5 = defaultKeyedValues2D1.getValue((java.lang.Comparable) (byte) 10, comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        piePlot1.setBackgroundAlpha((float) 10);
        java.awt.Paint paint6 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot1.getSimpleLabelOffset();
        org.jfree.chart.util.UnitType unitType8 = rectangleInsets7.getUnitType();
        java.lang.String str9 = rectangleInsets7.toString();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(unitType8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleInsets[t=0.18,l=0.18,b=0.18,r=0.18]" + "'", str9.equals("RectangleInsets[t=0.18,l=0.18,b=0.18,r=0.18]"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.validateObject();
        defaultCategoryDataset0.addValue((double) 100.0f, (java.lang.Comparable) 1L, (java.lang.Comparable) (byte) 100);
        try {
            java.lang.Number number8 = defaultCategoryDataset0.getValue((java.lang.Comparable) 89, (java.lang.Comparable) 0.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 0.0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot1, jFreeChart4);
        double double6 = piePlot1.getStartAngle();
        piePlot1.zoom((double) (short) 10);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart9.clearSubtitles();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 90.0d + "'", double6 == 90.0d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        double double5 = piePlot4.getMaximumExplodePercent();
        double double6 = piePlot4.getShadowYOffset();
        java.awt.Paint paint7 = piePlot4.getBackgroundPaint();
        piePlot1.setLabelLinkPaint(paint7);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        piePlot1.markerChanged(markerChangeEvent9);
        java.awt.Paint paint11 = piePlot1.getShadowPaint();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle12 = piePlot1.getLabelLinkStyle();
        boolean boolean13 = piePlot1.isCircular();
        piePlot1.setIgnoreNullValues(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list14);
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("hi!", font17);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle18.getVerticalAlignment();
        java.lang.Object obj20 = textTitle18.clone();
        jFreeChart10.removeSubtitle((org.jfree.chart.title.Title) textTitle18);
        org.jfree.chart.title.TextTitle textTitle22 = null;
        jFreeChart10.setTitle(textTitle22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double25 = rectangleInsets24.getBottom();
        double double27 = rectangleInsets24.calculateTopOutset((double) 0.0f);
        java.lang.String str28 = rectangleInsets24.toString();
        jFreeChart10.setPadding(rectangleInsets24);
        org.jfree.chart.ui.ProjectInfo projectInfo30 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray31 = projectInfo30.getOptionalLibraries();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D33 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list34 = defaultKeyedValues2D33.getColumnKeys();
        java.util.List list35 = defaultKeyedValues2D33.getRowKeys();
        projectInfo30.setContributors(list35);
        jFreeChart10.setSubtitles(list35);
        try {
            org.jfree.chart.title.Title title39 = jFreeChart10.getSubtitle((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str28.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNotNull(projectInfo30);
        org.junit.Assert.assertNotNull(libraryArray31);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(list35);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.text.NumberFormat numberFormat1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot3.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int7 = color6.getRGB();
        java.awt.Color color8 = color6.darker();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int10 = color9.getBlue();
        java.awt.Color color11 = color9.darker();
        boolean boolean12 = color8.equals((java.lang.Object) color11);
        boolean boolean13 = standardPieSectionLabelGenerator4.equals((java.lang.Object) boolean12);
        java.lang.String str14 = standardPieSectionLabelGenerator4.getLabelFormat();
        java.lang.Object obj15 = standardPieSectionLabelGenerator4.clone();
        java.text.NumberFormat numberFormat16 = standardPieSectionLabelGenerator4.getPercentFormat();
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator17 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("VerticalAlignment.CENTER", numberFormat1, numberFormat16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-32640) + "'", int7 == (-32640));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{0}" + "'", str14.equals("{0}"));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(numberFormat16);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        org.jfree.chart.ui.Library[] libraryArray2 = projectInfo0.getLibraries();
        java.lang.String str3 = projectInfo0.getInfo();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNotNull(libraryArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleAnchor.CENTER" + "'", str3.equals("RectangleAnchor.CENTER"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        float float4 = piePlot1.getBackgroundAlpha();
        piePlot1.setSectionOutlinesVisible(true);
        piePlot1.setIgnoreNullValues(true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        piePlot1.setLabelBackgroundPaint((java.awt.Paint) color9);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list14);
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("hi!", font17);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle18.getVerticalAlignment();
        java.lang.Object obj20 = textTitle18.clone();
        jFreeChart10.removeSubtitle((org.jfree.chart.title.Title) textTitle18);
        org.jfree.chart.title.TextTitle textTitle22 = null;
        jFreeChart10.setTitle(textTitle22);
        java.lang.Object obj24 = jFreeChart10.getTextAntiAlias();
        jFreeChart10.setBorderVisible(true);
        jFreeChart10.setAntiAlias(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = jFreeChart10.getPadding();
        jFreeChart10.removeLegend();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertNotNull(rectangleInsets29);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        java.lang.String str2 = licences0.getGPL();
        java.lang.String str3 = licences0.getGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 89, 1, (java.lang.Comparable) '4', "", "hi!");
        pieSectionEntity7.setPieIndex((int) (short) 10);
        java.lang.String str10 = pieSectionEntity7.getShapeCoords();
        int int11 = pieSectionEntity7.getSectionIndex();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-4,-4,4,4" + "'", str10.equals("-4,-4,4,4"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("hi!", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        float float4 = piePlot1.getBackgroundAlpha();
        java.awt.Image image5 = null;
        piePlot1.setBackgroundImage(image5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot1.getLabelPadding();
        java.awt.Paint paint8 = piePlot1.getLabelBackgroundPaint();
        java.awt.Paint[] paintArray9 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray10 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray11 = null;
        java.awt.Stroke[] strokeArray12 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Shape[] shapeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray10, paintArray11, strokeArray12, strokeArray14, shapeArray15);
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier16);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot();
        boolean boolean19 = defaultDrawingSupplier16.equals((java.lang.Object) multiplePiePlot18);
        java.awt.Paint paint20 = multiplePiePlot18.getAggregatedItemsPaint();
        java.awt.Paint paint21 = multiplePiePlot18.getNoDataMessagePaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(shapeArray15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        piePlot1.setPieIndex((int) (short) 100);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        double double8 = piePlot7.getMaximumExplodePercent();
        double double9 = piePlot7.getShadowYOffset();
        float float10 = piePlot7.getBackgroundAlpha();
        piePlot1.setParent((org.jfree.chart.plot.Plot) piePlot7);
        piePlot7.setExplodePercent((java.lang.Comparable) 10, (double) (-32640));
        java.awt.Stroke stroke15 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot7.setLabelOutlineStroke(stroke15);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(89);
        java.lang.Object obj2 = objectList1.clone();
        objectList1.clear();
        java.lang.Object obj5 = objectList1.get((int) (short) 0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        boolean boolean2 = chartChangeEventType0.equals((java.lang.Object) 10L);
        java.lang.String str3 = chartChangeEventType0.toString();
        java.lang.String str4 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str3.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str4.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list2 = defaultKeyedValues2D1.getColumnKeys();
        int int4 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 100.0f);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) (-1L), (java.lang.Comparable) 100.0f);
        java.awt.Font font9 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        double double12 = piePlot11.getMaximumExplodePercent();
        double double13 = piePlot11.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double15 = rectangleInsets14.getBottom();
        piePlot11.setSimpleLabelOffset(rectangleInsets14);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font9, (org.jfree.chart.plot.Plot) piePlot11, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D20 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list21 = defaultKeyedValues2D20.getColumnKeys();
        java.util.List list22 = defaultKeyedValues2D20.getRowKeys();
        jFreeChart18.setSubtitles(list22);
        java.awt.RenderingHints renderingHints24 = jFreeChart18.getRenderingHints();
        boolean boolean25 = defaultKeyedValues2D1.equals((java.lang.Object) jFreeChart18);
        java.awt.Font font27 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("hi!", font27);
        org.jfree.chart.util.VerticalAlignment verticalAlignment29 = textTitle28.getVerticalAlignment();
        java.lang.Object obj30 = textTitle28.clone();
        textTitle28.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D33 = textTitle28.getBounds();
        java.lang.String str34 = textTitle28.getURLText();
        java.awt.Paint paint35 = textTitle28.getPaint();
        jFreeChart18.removeSubtitle((org.jfree.chart.title.Title) textTitle28);
        textTitle28.setExpandToFitSpace(false);
        boolean boolean39 = textTitle28.getExpandToFitSpace();
        java.awt.Paint paint40 = textTitle28.getPaint();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(renderingHints24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(verticalAlignment29);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "PieLabelLinkStyle.STANDARD", "", "RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]");
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("{0} version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).{0} hi! (VerticalAlignment.CENTER).\n{0} LICENCE TERMS:\nPie Plot", "RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]");
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(8);
        java.lang.String str2 = pieLabelDistributor1.toString();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord4 = pieLabelDistributor1.getPieLabelRecord(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getBottom();
        double double3 = rectangleInsets0.trimWidth((double) 0L);
        double double5 = rectangleInsets0.trimHeight((double) (byte) 0);
        double double7 = rectangleInsets0.calculateBottomOutset(10.0d);
        double double8 = rectangleInsets0.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.awt.Color color1 = java.awt.Color.getColor("-4,-4,4,4");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        double double3 = piePlot2.getMaximumExplodePercent();
        double double4 = piePlot2.getShadowYOffset();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        piePlot2.setNoDataMessageFont(font5);
        multiplePiePlot0.setNoDataMessageFont(font5);
        java.awt.Color color8 = java.awt.Color.gray;
        multiplePiePlot0.setOutlinePaint((java.awt.Paint) color8);
        org.jfree.chart.JFreeChart jFreeChart10 = multiplePiePlot0.getPieChart();
        boolean boolean11 = jFreeChart10.isBorderVisible();
        org.jfree.chart.event.ChartChangeListener chartChangeListener12 = null;
        try {
            jFreeChart10.addChangeListener(chartChangeListener12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(jFreeChart10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) (short) 1, (-1.0d));
        columnArrangement5.clear();
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement5);
        java.util.List list8 = blockContainer0.getBlocks();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.Font font11 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("hi!", font11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = textTitle12.getPadding();
        java.awt.Font font15 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("hi!", font15);
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = textTitle16.getVerticalAlignment();
        java.lang.Object obj18 = textTitle16.clone();
        textTitle16.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D21 = textTitle16.getBounds();
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets13.createInsetRectangle(rectangle2D21);
        try {
            blockContainer0.draw(graphics2D9, rectangle2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D22);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        float float4 = piePlot1.getBackgroundAlpha();
        piePlot1.setSectionOutlinesVisible(true);
        piePlot1.setMaximumLabelWidth(0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double5 = rectangleInsets4.getBottom();
        piePlot1.setSimpleLabelOffset(rectangleInsets4);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int9 = color8.getBlue();
        java.awt.Color color10 = java.awt.Color.getColor("", color8);
        piePlot1.setShadowPaint((java.awt.Paint) color10);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator12 = piePlot1.getLegendLabelURLGenerator();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(pieURLGenerator12);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint1 = blockBorder0.getPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder0.getInsets();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        float float4 = piePlot1.getBackgroundImageAlpha();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle5 = piePlot1.getLabelLinkStyle();
        double double6 = piePlot1.getInteriorGap();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot1.getInsets();
        double double9 = rectangleInsets7.calculateLeftOutset((-3.0d));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.5f + "'", float4 == 0.5f);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 8.0d + "'", double9 == 8.0d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot1, jFreeChart4);
        piePlot1.setExplodePercent((java.lang.Comparable) true, (double) (short) 1);
        java.awt.Shape shape9 = piePlot1.getLegendItemShape();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment10, verticalAlignment11, (double) (short) 1, (-1.0d));
        columnArrangement14.clear();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int18 = color17.getBlue();
        java.awt.Color color19 = java.awt.Color.getColor("", color17);
        boolean boolean20 = columnArrangement14.equals((java.lang.Object) color19);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment22 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement25 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment21, verticalAlignment22, (double) (short) 1, (-1.0d));
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) columnArrangement14, (org.jfree.chart.block.Arrangement) columnArrangement25);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot(pieDataset28);
        double double30 = piePlot29.getMaximumExplodePercent();
        double double31 = piePlot29.getShadowYOffset();
        java.awt.Paint paint32 = piePlot29.getBackgroundPaint();
        org.jfree.data.general.PieDataset pieDataset33 = null;
        org.jfree.chart.plot.PiePlot piePlot34 = new org.jfree.chart.plot.PiePlot(pieDataset33);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator35 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot34.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator35);
        piePlot34.setBackgroundAlpha((float) 10);
        java.awt.Paint paint39 = piePlot34.getLabelLinkPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = piePlot34.getSimpleLabelOffset();
        java.awt.Font font42 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset43 = null;
        org.jfree.chart.plot.PiePlot piePlot44 = new org.jfree.chart.plot.PiePlot(pieDataset43);
        double double45 = piePlot44.getMaximumExplodePercent();
        double double46 = piePlot44.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double48 = rectangleInsets47.getBottom();
        piePlot44.setSimpleLabelOffset(rectangleInsets47);
        org.jfree.chart.JFreeChart jFreeChart51 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font42, (org.jfree.chart.plot.Plot) piePlot44, false);
        piePlot34.setNoDataMessageFont(font42);
        piePlot29.setNoDataMessageFont(font42);
        java.awt.Font font55 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle("hi!", font55);
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = textTitle56.getMargin();
        piePlot29.setSimpleLabelOffset(rectangleInsets57);
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Font font61 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle62 = new org.jfree.chart.title.TextTitle("hi!", font61);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = textTitle62.getPadding();
        java.awt.Font font65 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle66 = new org.jfree.chart.title.TextTitle("hi!", font65);
        org.jfree.chart.util.VerticalAlignment verticalAlignment67 = textTitle66.getVerticalAlignment();
        java.lang.Object obj68 = textTitle66.clone();
        textTitle66.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D71 = textTitle66.getBounds();
        java.awt.geom.Rectangle2D rectangle2D72 = rectangleInsets63.createInsetRectangle(rectangle2D71);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType73 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType74 = null;
        java.awt.geom.Rectangle2D rectangle2D75 = rectangleInsets59.createAdjustedRectangle(rectangle2D72, lengthAdjustmentType73, lengthAdjustmentType74);
        java.awt.geom.Rectangle2D rectangle2D78 = rectangleInsets57.createOutsetRectangle(rectangle2D75, true, true);
        try {
            legendTitle26.draw(graphics2D27, rectangle2D78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 4.0d + "'", double31 == 4.0d);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 4.0d + "'", double46 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertNotNull(font61);
        org.junit.Assert.assertNotNull(rectangleInsets63);
        org.junit.Assert.assertNotNull(font65);
        org.junit.Assert.assertNotNull(verticalAlignment67);
        org.junit.Assert.assertNotNull(obj68);
        org.junit.Assert.assertNotNull(rectangle2D71);
        org.junit.Assert.assertNotNull(rectangle2D72);
        org.junit.Assert.assertNotNull(rectangle2D75);
        org.junit.Assert.assertNotNull(rectangle2D78);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list2 = defaultKeyedValues2D1.getColumnKeys();
        int int4 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 100.0f);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) (-1L), (java.lang.Comparable) 100.0f);
        java.awt.Font font9 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        double double12 = piePlot11.getMaximumExplodePercent();
        double double13 = piePlot11.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double15 = rectangleInsets14.getBottom();
        piePlot11.setSimpleLabelOffset(rectangleInsets14);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font9, (org.jfree.chart.plot.Plot) piePlot11, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D20 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list21 = defaultKeyedValues2D20.getColumnKeys();
        java.util.List list22 = defaultKeyedValues2D20.getRowKeys();
        jFreeChart18.setSubtitles(list22);
        java.awt.RenderingHints renderingHints24 = jFreeChart18.getRenderingHints();
        boolean boolean25 = defaultKeyedValues2D1.equals((java.lang.Object) jFreeChart18);
        java.awt.Font font27 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("hi!", font27);
        org.jfree.chart.util.VerticalAlignment verticalAlignment29 = textTitle28.getVerticalAlignment();
        java.lang.Object obj30 = textTitle28.clone();
        textTitle28.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D33 = textTitle28.getBounds();
        java.lang.String str34 = textTitle28.getURLText();
        java.awt.Paint paint35 = textTitle28.getPaint();
        jFreeChart18.removeSubtitle((org.jfree.chart.title.Title) textTitle28);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int39 = color38.getRGB();
        java.awt.Color color40 = java.awt.Color.getColor("", color38);
        int int41 = color38.getRed();
        textTitle28.setBackgroundPaint((java.awt.Paint) color38);
        java.lang.Object obj43 = textTitle28.clone();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(renderingHints24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(verticalAlignment29);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-32640) + "'", int39 == (-32640));
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 255 + "'", int41 == 255);
        org.junit.Assert.assertNotNull(obj43);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        java.awt.Font font4 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        piePlot1.setNoDataMessageFont(font4);
        java.lang.String str6 = piePlot1.getPlotType();
        java.awt.Color color7 = java.awt.Color.cyan;
        piePlot1.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = null;
        piePlot1.notifyListeners(plotChangeEvent9);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Pie Plot" + "'", str6.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot3.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator4);
        piePlot3.setBackgroundAlpha((float) 10);
        java.awt.Paint paint8 = piePlot3.getLabelLinkPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = piePlot3.getSimpleLabelOffset();
        java.awt.Font font11 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        double double14 = piePlot13.getMaximumExplodePercent();
        double double15 = piePlot13.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double17 = rectangleInsets16.getBottom();
        piePlot13.setSimpleLabelOffset(rectangleInsets16);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font11, (org.jfree.chart.plot.Plot) piePlot13, false);
        piePlot3.setNoDataMessageFont(font11);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        multiplePiePlot22.setDataset(categoryDataset23);
        org.jfree.chart.LegendItemCollection legendItemCollection25 = multiplePiePlot22.getLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        multiplePiePlot22.setDataset(categoryDataset26);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("{0} version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).\n{0} LICENCE TERMS:\nPie Plot", font11, (org.jfree.chart.plot.Plot) multiplePiePlot22, false);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int31 = color30.getBlue();
        java.awt.Color color32 = color30.darker();
        java.awt.Font font34 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("hi!", font34);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = textTitle35.getPadding();
        java.awt.Font font38 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle("hi!", font38);
        org.jfree.chart.util.VerticalAlignment verticalAlignment40 = textTitle39.getVerticalAlignment();
        java.lang.Object obj41 = textTitle39.clone();
        textTitle39.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D44 = textTitle39.getBounds();
        java.awt.geom.Rectangle2D rectangle2D45 = rectangleInsets36.createInsetRectangle(rectangle2D44);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.Object obj47 = null;
        boolean boolean48 = rectangleEdge46.equals(obj47);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D50 = new org.jfree.data.DefaultKeyedValues2D(false);
        boolean boolean51 = rectangleEdge46.equals((java.lang.Object) false);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge46);
        double double53 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D44, rectangleEdge46);
        boolean boolean54 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge46);
        java.awt.Font font56 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle57 = new org.jfree.chart.title.TextTitle("hi!", font56);
        org.jfree.chart.util.VerticalAlignment verticalAlignment58 = textTitle57.getVerticalAlignment();
        java.lang.Object obj59 = textTitle57.clone();
        double double60 = textTitle57.getContentXOffset();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment61 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle57.setHorizontalAlignment(horizontalAlignment61);
        org.jfree.chart.util.VerticalAlignment verticalAlignment63 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement66 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment61, verticalAlignment63, 0.08d, (double) 'a');
        org.jfree.chart.util.VerticalAlignment verticalAlignment67 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        java.awt.Font font69 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle70 = new org.jfree.chart.title.TextTitle("hi!", font69);
        org.jfree.chart.util.RectangleInsets rectangleInsets71 = textTitle70.getPadding();
        org.jfree.chart.title.TextTitle textTitle72 = new org.jfree.chart.title.TextTitle("Rotation.ANTICLOCKWISE", font11, (java.awt.Paint) color32, rectangleEdge46, horizontalAlignment61, verticalAlignment67, rectangleInsets71);
        org.jfree.data.general.PieDataset pieDataset73 = null;
        org.jfree.chart.plot.PiePlot piePlot74 = new org.jfree.chart.plot.PiePlot(pieDataset73);
        double double75 = piePlot74.getMaximumExplodePercent();
        double double76 = piePlot74.getShadowYOffset();
        piePlot74.setBackgroundAlpha(0.0f);
        java.awt.Color color80 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int81 = color80.getRGB();
        java.awt.Color color82 = color80.darker();
        java.awt.Color color83 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int84 = color83.getBlue();
        java.awt.Color color85 = color83.darker();
        boolean boolean86 = color82.equals((java.lang.Object) color85);
        piePlot74.setSectionOutlinePaint((java.lang.Comparable) (short) 100, (java.awt.Paint) color82);
        java.awt.Stroke stroke89 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        piePlot74.setSectionOutlineStroke((java.lang.Comparable) "PieSection: 89, 1(4)", stroke89);
        boolean boolean91 = piePlot74.getSectionOutlinesVisible();
        boolean boolean92 = verticalAlignment67.equals((java.lang.Object) piePlot74);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(verticalAlignment40);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNotNull(verticalAlignment58);
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0d + "'", double60 == 1.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment61);
        org.junit.Assert.assertNotNull(verticalAlignment67);
        org.junit.Assert.assertNotNull(font69);
        org.junit.Assert.assertNotNull(rectangleInsets71);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 4.0d + "'", double76 == 4.0d);
        org.junit.Assert.assertNotNull(color80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + (-32640) + "'", int81 == (-32640));
        org.junit.Assert.assertNotNull(color82);
        org.junit.Assert.assertNotNull(color83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertNotNull(color85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(stroke89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        piePlot1.setBackgroundImageAlpha(0.0f);
        java.awt.Color color5 = java.awt.Color.RED;
        piePlot1.setShadowPaint((java.awt.Paint) color5);
        java.awt.Color color7 = color5.darker();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int5 = color4.getRGB();
        java.awt.Color color6 = color4.darker();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int8 = color7.getBlue();
        java.awt.Color color9 = color7.darker();
        boolean boolean10 = color6.equals((java.lang.Object) color9);
        piePlot1.setBackgroundPaint((java.awt.Paint) color6);
        java.awt.Paint paint12 = piePlot1.getBaseSectionPaint();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        double double15 = piePlot14.getMaximumExplodePercent();
        double double16 = piePlot14.getShadowYOffset();
        piePlot14.setPieIndex((int) (short) 100);
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        double double21 = piePlot20.getMaximumExplodePercent();
        double double22 = piePlot20.getShadowYOffset();
        float float23 = piePlot20.getBackgroundAlpha();
        piePlot14.setParent((org.jfree.chart.plot.Plot) piePlot20);
        piePlot20.setExplodePercent((java.lang.Comparable) 10, (double) (-32640));
        org.jfree.chart.util.Rotation rotation28 = piePlot20.getDirection();
        double double29 = rotation28.getFactor();
        piePlot1.setDirection(rotation28);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-32640) + "'", int5 == (-32640));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 4.0d + "'", double22 == 4.0d);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertNotNull(rotation28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + (-1.0d) + "'", double29 == (-1.0d));
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.toString();
//        java.awt.Image image2 = projectInfo0.getLogo();
//        java.awt.Image image3 = projectInfo0.getLogo();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0} version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:RectangleAnchor.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).{0} hi! (RectangleAnchor.CENTER).  (hi!).  (hi!).{0} hi! (RectangleAnchor.CENTER).\n{0} LICENCE TERMS:\nPie Plot" + "'", str1.equals("{0} version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:RectangleAnchor.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).{0} hi! (RectangleAnchor.CENTER).  (hi!).  (hi!).{0} hi! (RectangleAnchor.CENTER).\n{0} LICENCE TERMS:\nPie Plot"));
//        org.junit.Assert.assertNotNull(image2);
//        org.junit.Assert.assertNotNull(image3);
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.jfree.chart.StrokeMap strokeMap1 = new org.jfree.chart.StrokeMap();
        strokeMap1.clear();
        boolean boolean4 = strokeMap1.containsKey((java.lang.Comparable) (short) 100);
        boolean boolean6 = strokeMap1.containsKey((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        java.lang.Object obj7 = strokeMap1.clone();
        boolean boolean8 = rotation0.equals(obj7);
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        piePlot1.drawBackgroundImage(graphics2D5, rectangle2D6);
        double double8 = piePlot1.getInteriorGap();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator11 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot10.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator11);
        piePlot10.setBackgroundAlpha((float) 10);
        java.awt.Paint paint15 = piePlot10.getLabelLinkPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = piePlot10.getSimpleLabelOffset();
        java.awt.Font font18 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        double double21 = piePlot20.getMaximumExplodePercent();
        double double22 = piePlot20.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double24 = rectangleInsets23.getBottom();
        piePlot20.setSimpleLabelOffset(rectangleInsets23);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font18, (org.jfree.chart.plot.Plot) piePlot20, false);
        piePlot10.setNoDataMessageFont(font18);
        piePlot10.setPieIndex(128);
        java.awt.Paint paint31 = piePlot10.getLabelLinkPaint();
        piePlot1.setLabelBackgroundPaint(paint31);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.08d + "'", double8 == 0.08d);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 4.0d + "'", double22 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(paint31);
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.toString();
//        java.util.List list2 = projectInfo0.getContributors();
//        java.lang.String str3 = projectInfo0.getLicenceText();
//        projectInfo0.setLicenceName("TableOrder.BY_COLUMN");
//        org.jfree.chart.ui.ProjectInfo projectInfo9 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str10 = projectInfo9.toString();
//        java.util.List list11 = projectInfo9.getContributors();
//        java.lang.String str12 = projectInfo9.getLicenceText();
//        java.awt.Image image13 = projectInfo9.getLogo();
//        org.jfree.chart.ui.ProjectInfo projectInfo17 = new org.jfree.chart.ui.ProjectInfo("VerticalAlignment.TOP", "VerticalAlignment.CENTER", "Rotation.ANTICLOCKWISE", image13, "PieLabelLinkStyle.STANDARD", "", "hi!");
//        projectInfo0.setLogo(image13);
//        projectInfo0.setCopyright("VerticalAlignment.CENTER");
//        org.jfree.chart.ui.ProjectInfo projectInfo21 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str22 = projectInfo21.toString();
//        java.util.List list23 = projectInfo21.getContributors();
//        java.lang.String str24 = projectInfo21.getLicenceText();
//        projectInfo21.setInfo("VerticalAlignment.CENTER");
//        org.jfree.chart.ui.ProjectInfo projectInfo27 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str28 = projectInfo27.toString();
//        java.awt.Image image29 = projectInfo27.getLogo();
//        projectInfo21.setLogo(image29);
//        projectInfo0.setLogo(image29);
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0} version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:RectangleAnchor.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).{0} hi! (RectangleAnchor.CENTER).  (hi!).  (hi!).{0} hi! (RectangleAnchor.CENTER).\n{0} LICENCE TERMS:\nPie Plot" + "'", str1.equals("{0} version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:RectangleAnchor.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).{0} hi! (RectangleAnchor.CENTER).  (hi!).  (hi!).{0} hi! (RectangleAnchor.CENTER).\n{0} LICENCE TERMS:\nPie Plot"));
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pie Plot" + "'", str3.equals("Pie Plot"));
//        org.junit.Assert.assertNotNull(projectInfo9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{0} version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:RectangleAnchor.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).{0} hi! (RectangleAnchor.CENTER).  (hi!).  (hi!).{0} hi! (RectangleAnchor.CENTER).\n{0} LICENCE TERMS:\nPie Plot" + "'", str10.equals("{0} version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:RectangleAnchor.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).{0} hi! (RectangleAnchor.CENTER).  (hi!).  (hi!).{0} hi! (RectangleAnchor.CENTER).\n{0} LICENCE TERMS:\nPie Plot"));
//        org.junit.Assert.assertNotNull(list11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Pie Plot" + "'", str12.equals("Pie Plot"));
//        org.junit.Assert.assertNotNull(image13);
//        org.junit.Assert.assertNotNull(projectInfo21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "{0} version hi!.\nVerticalAlignment.CENTER.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:RectangleAnchor.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).{0} hi! (RectangleAnchor.CENTER).  (hi!).  (hi!).{0} hi! (RectangleAnchor.CENTER).\n{0} LICENCE TERMS:\nPie Plot" + "'", str22.equals("{0} version hi!.\nVerticalAlignment.CENTER.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:RectangleAnchor.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).{0} hi! (RectangleAnchor.CENTER).  (hi!).  (hi!).{0} hi! (RectangleAnchor.CENTER).\n{0} LICENCE TERMS:\nPie Plot"));
//        org.junit.Assert.assertNotNull(list23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pie Plot" + "'", str24.equals("Pie Plot"));
//        org.junit.Assert.assertNotNull(projectInfo27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "{0} version hi!.\nVerticalAlignment.CENTER.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).{0} hi! (VerticalAlignment.CENTER).  (hi!).  (hi!).{0} hi! (VerticalAlignment.CENTER).\n{0} LICENCE TERMS:\nPie Plot" + "'", str28.equals("{0} version hi!.\nVerticalAlignment.CENTER.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).{0} hi! (VerticalAlignment.CENTER).  (hi!).  (hi!).{0} hi! (VerticalAlignment.CENTER).\n{0} LICENCE TERMS:\nPie Plot"));
//        org.junit.Assert.assertNotNull(image29);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list2 = defaultKeyedValues2D1.getColumnKeys();
        java.util.List list3 = defaultKeyedValues2D1.getRowKeys();
        java.lang.Object obj4 = defaultKeyedValues2D1.clone();
        defaultKeyedValues2D1.clear();
        int int6 = defaultKeyedValues2D1.getRowCount();
        java.lang.Object obj7 = defaultKeyedValues2D1.clone();
        try {
            java.lang.Comparable comparable9 = defaultKeyedValues2D1.getRowKey((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("hi!", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle2.getPadding();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("hi!", font5);
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = textTitle6.getVerticalAlignment();
        java.lang.Object obj8 = textTitle6.clone();
        textTitle6.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D11 = textTitle6.getBounds();
        java.awt.geom.Rectangle2D rectangle2D12 = rectangleInsets3.createInsetRectangle(rectangle2D11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.Object obj14 = null;
        boolean boolean15 = rectangleEdge13.equals(obj14);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D17 = new org.jfree.data.DefaultKeyedValues2D(false);
        boolean boolean18 = rectangleEdge13.equals((java.lang.Object) false);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge13);
        double double20 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D11, rectangleEdge13);
        boolean boolean21 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge13);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D23 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list24 = defaultKeyedValues2D23.getColumnKeys();
        int int26 = defaultKeyedValues2D23.getRowIndex((java.lang.Comparable) 100.0f);
        int int28 = defaultKeyedValues2D23.getRowIndex((java.lang.Comparable) '#');
        boolean boolean29 = rectangleEdge13.equals((java.lang.Object) int28);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.validateObject();
        defaultCategoryDataset0.addValue((double) 100.0f, (java.lang.Comparable) 1L, (java.lang.Comparable) (byte) 100);
        int int6 = defaultCategoryDataset0.getColumnCount();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "Pie Plot", (java.lang.Comparable) 0.14d);
        try {
            java.lang.Comparable comparable11 = defaultCategoryDataset0.getRowKey((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.awt.Paint[] paintArray0 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int3 = color2.getRGB();
        java.awt.Color color4 = java.awt.Color.getColor("", color2);
        java.awt.Paint[] paintArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        boolean boolean6 = color2.equals((java.lang.Object) paintArray5);
        java.awt.Stroke[] strokeArray7 = null;
        java.awt.Paint[] paintArray8 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray9 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray10 = null;
        java.awt.Stroke[] strokeArray11 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke12 = null;
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] { stroke12 };
        java.awt.Shape[] shapeArray14 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray8, paintArray9, paintArray10, strokeArray11, strokeArray13, shapeArray14);
        java.awt.Shape[] shapeArray16 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray5, strokeArray7, strokeArray11, shapeArray16);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-32640) + "'", int3 == (-32640));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(strokeArray11);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(shapeArray14);
        org.junit.Assert.assertNotNull(shapeArray16);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        piePlot1.drawBackgroundImage(graphics2D5, rectangle2D6);
        piePlot1.setBackgroundImageAlignment(8);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(paint4);
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
//        org.jfree.data.general.PieDataset pieDataset2 = null;
//        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
//        double double4 = piePlot3.getMaximumExplodePercent();
//        double double5 = piePlot3.getShadowYOffset();
//        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
//        double double7 = rectangleInsets6.getBottom();
//        piePlot3.setSimpleLabelOffset(rectangleInsets6);
//        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
//        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
//        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
//        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
//        jFreeChart10.setSubtitles(list14);
//        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
//        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("hi!", font17);
//        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle18.getVerticalAlignment();
//        java.lang.Object obj20 = textTitle18.clone();
//        jFreeChart10.removeSubtitle((org.jfree.chart.title.Title) textTitle18);
//        org.jfree.chart.title.TextTitle textTitle22 = null;
//        jFreeChart10.setTitle(textTitle22);
//        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
//        double double25 = rectangleInsets24.getBottom();
//        double double27 = rectangleInsets24.calculateTopOutset((double) 0.0f);
//        java.lang.String str28 = rectangleInsets24.toString();
//        jFreeChart10.setPadding(rectangleInsets24);
//        org.jfree.chart.ui.ProjectInfo projectInfo30 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.Library[] libraryArray31 = projectInfo30.getOptionalLibraries();
//        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D33 = new org.jfree.data.DefaultKeyedValues2D(false);
//        java.util.List list34 = defaultKeyedValues2D33.getColumnKeys();
//        java.util.List list35 = defaultKeyedValues2D33.getRowKeys();
//        projectInfo30.setContributors(list35);
//        jFreeChart10.setSubtitles(list35);
//        org.jfree.chart.ui.ProjectInfo projectInfo38 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str39 = projectInfo38.toString();
//        java.util.List list40 = projectInfo38.getContributors();
//        java.lang.String str41 = projectInfo38.getLicenceText();
//        projectInfo38.setLicenceName("TableOrder.BY_COLUMN");
//        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D45 = new org.jfree.data.DefaultKeyedValues2D(false);
//        java.util.List list46 = defaultKeyedValues2D45.getColumnKeys();
//        projectInfo38.setContributors(list46);
//        jFreeChart10.setSubtitles(list46);
//        org.junit.Assert.assertNotNull(font1);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
//        org.junit.Assert.assertNotNull(rectangleInsets6);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertNotNull(list14);
//        org.junit.Assert.assertNotNull(font17);
//        org.junit.Assert.assertNotNull(verticalAlignment19);
//        org.junit.Assert.assertNotNull(obj20);
//        org.junit.Assert.assertNotNull(rectangleInsets24);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str28.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
//        org.junit.Assert.assertNotNull(projectInfo30);
//        org.junit.Assert.assertNotNull(libraryArray31);
//        org.junit.Assert.assertNotNull(list34);
//        org.junit.Assert.assertNotNull(list35);
//        org.junit.Assert.assertNotNull(projectInfo38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "{0} version hi!.\nVerticalAlignment.CENTER.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).{0} hi! (VerticalAlignment.CENTER).  (hi!).  (hi!).{0} hi! (VerticalAlignment.CENTER).\n{0} LICENCE TERMS:\nPie Plot" + "'", str39.equals("{0} version hi!.\nVerticalAlignment.CENTER.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).{0} hi! (VerticalAlignment.CENTER).  (hi!).  (hi!).{0} hi! (VerticalAlignment.CENTER).\n{0} LICENCE TERMS:\nPie Plot"));
//        org.junit.Assert.assertNotNull(list40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Pie Plot" + "'", str41.equals("Pie Plot"));
//        org.junit.Assert.assertNotNull(list46);
//    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 89, 1, (java.lang.Comparable) '4', "", "hi!");
        java.lang.String str8 = pieSectionEntity7.getShapeCoords();
        int int9 = pieSectionEntity7.getSectionIndex();
        int int10 = pieSectionEntity7.getPieIndex();
        int int11 = pieSectionEntity7.getPieIndex();
        java.awt.Shape shape12 = pieSectionEntity7.getArea();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-4,-4,4,4" + "'", str8.equals("-4,-4,4,4"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 89 + "'", int10 == 89);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 89 + "'", int11 == 89);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        textTitle2.draw(graphics2D3, rectangle2D4);
        textTitle2.setHeight((double) (byte) -1);
        textTitle2.setToolTipText("TableOrder.BY_COLUMN");
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle2.setBackgroundPaint((java.awt.Paint) color10);
        textTitle2.setURLText("PieLabelLinkStyle.STANDARD");
        textTitle2.setHeight((double) (-1.0f));
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("Rotation.ANTICLOCKWISE", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.validateObject();
        defaultCategoryDataset0.addValue((double) 100.0f, (java.lang.Comparable) 1L, (java.lang.Comparable) (byte) 100);
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (byte) 100, (java.lang.Comparable) (byte) -1);
        java.util.List list9 = defaultCategoryDataset0.getRowKeys();
        int int11 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) "Rotation.ANTICLOCKWISE");
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 89, 1, (java.lang.Comparable) '4', "", "hi!");
        pieSectionEntity7.setSectionKey((java.lang.Comparable) 89);
        pieSectionEntity7.setURLText("");
        org.jfree.data.general.PieDataset pieDataset12 = null;
        pieSectionEntity7.setDataset(pieDataset12);
        java.lang.Object obj14 = pieSectionEntity7.clone();
        pieSectionEntity7.setURLText("Pie Plot");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        double double3 = multiplePiePlot0.getLimit();
        java.awt.Paint paint4 = multiplePiePlot0.getAggregatedItemsPaint();
        java.lang.Comparable comparable5 = multiplePiePlot0.getAggregatedItemsKey();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "Other" + "'", comparable5.equals("Other"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("VerticalAlignment.CENTER");
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list14);
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("hi!", font17);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle18.getVerticalAlignment();
        java.lang.Object obj20 = textTitle18.clone();
        jFreeChart10.removeSubtitle((org.jfree.chart.title.Title) textTitle18);
        org.jfree.chart.title.TextTitle textTitle22 = null;
        jFreeChart10.setTitle(textTitle22);
        int int24 = jFreeChart10.getBackgroundImageAlignment();
        org.jfree.chart.title.LegendTitle legendTitle25 = jFreeChart10.getLegend();
        java.awt.Paint paint26 = jFreeChart10.getBorderPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 15 + "'", int24 == 15);
        org.junit.Assert.assertNull(legendTitle25);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        piePlot1.setBackgroundImageAlpha(0.0f);
        piePlot1.setStartAngle((double) 1L);
        java.awt.Paint paint7 = piePlot1.getBaseSectionPaint();
        double double8 = piePlot1.getStartAngle();
        int int9 = piePlot1.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot6.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator7);
        piePlot6.setBackgroundAlpha((float) 10);
        java.awt.Paint paint11 = piePlot6.getLabelLinkPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = piePlot6.getSimpleLabelOffset();
        java.awt.Font font14 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        double double17 = piePlot16.getMaximumExplodePercent();
        double double18 = piePlot16.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets19.getBottom();
        piePlot16.setSimpleLabelOffset(rectangleInsets19);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font14, (org.jfree.chart.plot.Plot) piePlot16, false);
        piePlot6.setNoDataMessageFont(font14);
        piePlot1.setNoDataMessageFont(font14);
        java.awt.Font font27 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("hi!", font27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = textTitle28.getMargin();
        piePlot1.setSimpleLabelOffset(rectangleInsets29);
        java.lang.String str31 = rectangleInsets29.toString();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str31.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        piePlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment5, verticalAlignment6, (double) (short) 1, (-1.0d));
        boolean boolean10 = piePlot1.equals((java.lang.Object) verticalAlignment6);
        piePlot1.setShadowXOffset((double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot2.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator3);
        piePlot2.setBackgroundAlpha((float) 10);
        java.awt.Paint paint7 = piePlot2.getLabelLinkPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot2.getSimpleLabelOffset();
        java.awt.Font font10 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        double double13 = piePlot12.getMaximumExplodePercent();
        double double14 = piePlot12.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets15.getBottom();
        piePlot12.setSimpleLabelOffset(rectangleInsets15);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font10, (org.jfree.chart.plot.Plot) piePlot12, false);
        piePlot2.setNoDataMessageFont(font10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot21 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        multiplePiePlot21.setDataset(categoryDataset22);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = multiplePiePlot21.getLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        multiplePiePlot21.setDataset(categoryDataset25);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("{0} version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).\n{0} LICENCE TERMS:\nPie Plot", font10, (org.jfree.chart.plot.Plot) multiplePiePlot21, false);
        org.jfree.chart.util.TableOrder tableOrder29 = multiplePiePlot21.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder30 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        multiplePiePlot21.setDataExtractOrder(tableOrder30);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection24);
        org.junit.Assert.assertNotNull(tableOrder29);
        org.junit.Assert.assertNotNull(tableOrder30);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.awt.Color color0 = java.awt.Color.PINK;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 175 + "'", int1 == 175);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = null;
        java.awt.Stroke[] strokeArray3 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke4 = null;
        java.awt.Stroke[] strokeArray5 = new java.awt.Stroke[] { stroke4 };
        java.awt.Shape[] shapeArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray3, strokeArray5, shapeArray6);
        java.awt.Shape shape8 = defaultDrawingSupplier7.getNextShape();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator11 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot10.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator11);
        piePlot10.setBackgroundAlpha((float) 10);
        java.awt.Paint paint15 = piePlot10.getLabelLinkPaint();
        boolean boolean16 = defaultDrawingSupplier7.equals((java.lang.Object) paint15);
        java.awt.Shape shape17 = defaultDrawingSupplier7.getNextShape();
        try {
            java.awt.Paint paint18 = defaultDrawingSupplier7.getNextOutlinePaint();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(strokeArray5);
        org.junit.Assert.assertNotNull(shapeArray6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(shape17);
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
//        org.jfree.chart.ui.Library library6 = new org.jfree.chart.ui.Library("", "", "hi!", "hi!");
//        projectInfo0.addLibrary(library6);
//        projectInfo0.setVersion("hi!");
//        org.jfree.chart.ui.Library[] libraryArray10 = projectInfo0.getLibraries();
//        org.jfree.chart.ui.ProjectInfo projectInfo11 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo11);
//        org.jfree.chart.ui.Library[] libraryArray13 = projectInfo0.getOptionalLibraries();
//        org.jfree.chart.ui.ProjectInfo projectInfo14 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str15 = projectInfo14.toString();
//        java.util.List list16 = projectInfo14.getContributors();
//        java.lang.String str17 = projectInfo14.getLicenceText();
//        projectInfo14.setLicenceName("TableOrder.BY_COLUMN");
//        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D21 = new org.jfree.data.DefaultKeyedValues2D(false);
//        java.util.List list22 = defaultKeyedValues2D21.getColumnKeys();
//        projectInfo14.setContributors(list22);
//        projectInfo0.setContributors(list22);
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(libraryArray1);
//        org.junit.Assert.assertNotNull(libraryArray10);
//        org.junit.Assert.assertNotNull(projectInfo11);
//        org.junit.Assert.assertNotNull(libraryArray13);
//        org.junit.Assert.assertNotNull(projectInfo14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{0} version hi!.\nVerticalAlignment.CENTER.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).{0} hi! (VerticalAlignment.CENTER).  (hi!).  (hi!).{0} hi! (VerticalAlignment.CENTER).  (hi!).{0} hi! (VerticalAlignment.CENTER).\n{0} LICENCE TERMS:\nPie Plot" + "'", str15.equals("{0} version hi!.\nVerticalAlignment.CENTER.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).{0} hi! (VerticalAlignment.CENTER).  (hi!).  (hi!).{0} hi! (VerticalAlignment.CENTER).  (hi!).{0} hi! (VerticalAlignment.CENTER).\n{0} LICENCE TERMS:\nPie Plot"));
//        org.junit.Assert.assertNotNull(list16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Pie Plot" + "'", str17.equals("Pie Plot"));
//        org.junit.Assert.assertNotNull(list22);
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.lang.String str1 = rectangleEdge0.toString();
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleEdge.BOTTOM" + "'", str1.equals("RectangleEdge.BOTTOM"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.awt.Color color0 = java.awt.Color.cyan;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        float float4 = piePlot1.getBackgroundImageAlpha();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle5 = piePlot1.getLabelLinkStyle();
        piePlot1.setLabelLinkMargin((double) 10);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = piePlot1.getLabelLinkStyle();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.5f + "'", float4 == 0.5f);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle5);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.TOP_LEFT" + "'", str1.equals("RectangleAnchor.TOP_LEFT"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list14);
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("hi!", font17);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle18.getVerticalAlignment();
        java.lang.Object obj20 = textTitle18.clone();
        jFreeChart10.removeSubtitle((org.jfree.chart.title.Title) textTitle18);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        textTitle18.setBackgroundPaint((java.awt.Paint) color22);
        double double24 = textTitle18.getWidth();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list14);
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("hi!", font17);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle18.getVerticalAlignment();
        java.lang.Object obj20 = textTitle18.clone();
        jFreeChart10.removeSubtitle((org.jfree.chart.title.Title) textTitle18);
        org.jfree.chart.title.TextTitle textTitle22 = null;
        jFreeChart10.setTitle(textTitle22);
        java.lang.Object obj24 = jFreeChart10.getTextAntiAlias();
        org.jfree.chart.event.ChartProgressListener chartProgressListener25 = null;
        jFreeChart10.addProgressListener(chartProgressListener25);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNull(obj24);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        org.jfree.chart.ui.Library library6 = new org.jfree.chart.ui.Library("", "", "hi!", "hi!");
        projectInfo0.addLibrary(library6);
        java.lang.String str8 = projectInfo0.getLicenceText();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pie Plot" + "'", str8.equals("Pie Plot"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot6.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator7);
        piePlot6.setBackgroundAlpha((float) 10);
        java.awt.Paint paint11 = piePlot6.getLabelLinkPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = piePlot6.getSimpleLabelOffset();
        java.awt.Font font14 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        double double17 = piePlot16.getMaximumExplodePercent();
        double double18 = piePlot16.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets19.getBottom();
        piePlot16.setSimpleLabelOffset(rectangleInsets19);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font14, (org.jfree.chart.plot.Plot) piePlot16, false);
        piePlot6.setNoDataMessageFont(font14);
        piePlot1.setNoDataMessageFont(font14);
        java.awt.Font font27 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("hi!", font27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = textTitle28.getMargin();
        piePlot1.setSimpleLabelOffset(rectangleInsets29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Font font33 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("hi!", font33);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = textTitle34.getPadding();
        java.awt.Font font37 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("hi!", font37);
        org.jfree.chart.util.VerticalAlignment verticalAlignment39 = textTitle38.getVerticalAlignment();
        java.lang.Object obj40 = textTitle38.clone();
        textTitle38.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = textTitle38.getBounds();
        java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets35.createInsetRectangle(rectangle2D43);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType45 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = rectangleInsets31.createAdjustedRectangle(rectangle2D44, lengthAdjustmentType45, lengthAdjustmentType46);
        java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets29.createOutsetRectangle(rectangle2D47, true, true);
        double double51 = rectangleInsets29.getBottom();
        double double53 = rectangleInsets29.trimWidth(0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(verticalAlignment39);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        double double5 = piePlot4.getMaximumExplodePercent();
        double double6 = piePlot4.getShadowYOffset();
        java.awt.Paint paint7 = piePlot4.getBackgroundPaint();
        piePlot1.setLabelLinkPaint(paint7);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        piePlot1.markerChanged(markerChangeEvent9);
        java.awt.Paint paint11 = piePlot1.getShadowPaint();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle12 = piePlot1.getLabelLinkStyle();
        piePlot1.setMinimumArcAngleToDraw((double) '#');
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = piePlot1.getDrawingSupplier();
        int int16 = piePlot1.getPieIndex();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle12);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        piePlot3.setBackgroundAlpha(0.0f);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int10 = color9.getRGB();
        java.awt.Color color11 = color9.darker();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int13 = color12.getBlue();
        java.awt.Color color14 = color12.darker();
        boolean boolean15 = color11.equals((java.lang.Object) color14);
        piePlot3.setSectionOutlinePaint((java.lang.Comparable) (short) 100, (java.awt.Paint) color11);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("PieLabelLinkStyle.STANDARD", font1, (org.jfree.chart.plot.Plot) piePlot3, true);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart18.getLegend();
        java.awt.Paint paint20 = legendTitle19.getItemPaint();
        java.awt.Font font22 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("hi!", font22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = textTitle23.getPadding();
        java.awt.Font font26 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("hi!", font26);
        org.jfree.chart.util.VerticalAlignment verticalAlignment28 = textTitle27.getVerticalAlignment();
        java.lang.Object obj29 = textTitle27.clone();
        textTitle27.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D32 = textTitle27.getBounds();
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets24.createInsetRectangle(rectangle2D32);
        legendTitle19.setLegendItemGraphicPadding(rectangleInsets24);
        java.awt.Paint paint35 = null;
        try {
            legendTitle19.setItemPaint(paint35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-32640) + "'", int10 == (-32640));
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(legendTitle19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(verticalAlignment28);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangle2D33);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        double double3 = piePlot2.getMaximumExplodePercent();
        double double4 = piePlot2.getShadowYOffset();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        piePlot2.setNoDataMessageFont(font5);
        multiplePiePlot0.setNoDataMessageFont(font5);
        java.awt.Color color8 = java.awt.Color.gray;
        multiplePiePlot0.setOutlinePaint((java.awt.Paint) color8);
        float[] floatArray13 = null;
        float[] floatArray14 = java.awt.Color.RGBtoHSB((int) (byte) 1, 15, (int) (short) -1, floatArray13);
        try {
            float[] floatArray15 = color8.getRGBComponents(floatArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray14);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = multiplePiePlot0.getLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = multiplePiePlot0.getLegendItems();
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        float float4 = piePlot1.getBackgroundAlpha();
        java.awt.Image image5 = null;
        piePlot1.setBackgroundImage(image5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot1.getLabelPadding();
        java.awt.Paint paint8 = piePlot1.getLabelBackgroundPaint();
        java.awt.Paint[] paintArray9 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray10 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray11 = null;
        java.awt.Stroke[] strokeArray12 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Shape[] shapeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray10, paintArray11, strokeArray12, strokeArray14, shapeArray15);
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier16);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot();
        boolean boolean19 = defaultDrawingSupplier16.equals((java.lang.Object) multiplePiePlot18);
        try {
            java.awt.Stroke stroke20 = defaultDrawingSupplier16.getNextStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(shapeArray15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.validateObject();
        defaultCategoryDataset0.addValue((double) 100.0f, (java.lang.Comparable) 1L, (java.lang.Comparable) (byte) 100);
        int int6 = defaultCategoryDataset0.getColumnCount();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "Pie Plot", (java.lang.Comparable) 0.14d);
        defaultCategoryDataset0.setValue((java.lang.Number) 10.0d, (java.lang.Comparable) (short) 100, (java.lang.Comparable) 100L);
        try {
            java.lang.Comparable comparable15 = defaultCategoryDataset0.getColumnKey((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 89, 1, (java.lang.Comparable) '4', "", "hi!");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D9 = new org.jfree.data.DefaultKeyedValues2D(true);
        boolean boolean10 = pieSectionEntity7.equals((java.lang.Object) true);
        java.awt.Shape shape11 = pieSectionEntity7.getArea();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        piePlot1.setBackgroundImageAlpha(0.0f);
        java.awt.Color color5 = java.awt.Color.RED;
        piePlot1.setShadowPaint((java.awt.Paint) color5);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = null;
        piePlot1.setURLGenerator(pieURLGenerator7);
        piePlot1.setStartAngle((double) 15);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        java.awt.Font font4 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        double double7 = piePlot6.getMaximumExplodePercent();
        double double8 = piePlot6.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double10 = rectangleInsets9.getBottom();
        piePlot6.setSimpleLabelOffset(rectangleInsets9);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font4, (org.jfree.chart.plot.Plot) piePlot6, false);
        double double14 = piePlot6.getShadowYOffset();
        boolean boolean15 = defaultKeyedValues2D1.equals((java.lang.Object) double14);
        defaultKeyedValues2D1.setValue((java.lang.Number) 0.0f, (java.lang.Comparable) (-668), (java.lang.Comparable) 10);
        try {
            defaultKeyedValues2D1.removeColumn(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = textTitle2.getPosition();
        textTitle2.setToolTipText("{0} version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).\n{0} LICENCE TERMS:\nPie Plot");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot2.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator3);
        piePlot2.setBackgroundAlpha((float) 10);
        java.awt.Paint paint7 = piePlot2.getLabelLinkPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot2.getSimpleLabelOffset();
        java.awt.Font font10 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        double double13 = piePlot12.getMaximumExplodePercent();
        double double14 = piePlot12.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets15.getBottom();
        piePlot12.setSimpleLabelOffset(rectangleInsets15);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font10, (org.jfree.chart.plot.Plot) piePlot12, false);
        piePlot2.setNoDataMessageFont(font10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot21 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        multiplePiePlot21.setDataset(categoryDataset22);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = multiplePiePlot21.getLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        multiplePiePlot21.setDataset(categoryDataset25);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("{0} version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).\n{0} LICENCE TERMS:\nPie Plot", font10, (org.jfree.chart.plot.Plot) multiplePiePlot21, false);
        org.jfree.chart.title.TextTitle textTitle29 = jFreeChart28.getTitle();
        jFreeChart28.setTextAntiAlias(true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection24);
        org.junit.Assert.assertNotNull(textTitle29);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        piePlot1.setBackgroundImageAlpha(0.0f);
        java.awt.Color color5 = java.awt.Color.RED;
        piePlot1.setShadowPaint((java.awt.Paint) color5);
        piePlot1.setForegroundAlpha((float) 8);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator11 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot10.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator11);
        float float13 = piePlot10.getBackgroundImageAlpha();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle14 = piePlot10.getLabelLinkStyle();
        java.lang.String str15 = pieLabelLinkStyle14.toString();
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle14);
        java.awt.Color color17 = java.awt.Color.RED;
        int int18 = color17.getRed();
        boolean boolean19 = pieLabelLinkStyle14.equals((java.lang.Object) color17);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PieLabelLinkStyle.STANDARD" + "'", str15.equals("PieLabelLinkStyle.STANDARD"));
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 255 + "'", int18 == 255);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        piePlot3.setBackgroundAlpha(0.0f);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int10 = color9.getRGB();
        java.awt.Color color11 = color9.darker();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int13 = color12.getBlue();
        java.awt.Color color14 = color12.darker();
        boolean boolean15 = color11.equals((java.lang.Object) color14);
        piePlot3.setSectionOutlinePaint((java.lang.Comparable) (short) 100, (java.awt.Paint) color11);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("PieLabelLinkStyle.STANDARD", font1, (org.jfree.chart.plot.Plot) piePlot3, true);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart18.getLegend();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendTitle19.getLegendItemGraphicPadding();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = null;
        org.jfree.chart.util.Size2D size2D23 = legendTitle19.arrange(graphics2D21, rectangleConstraint22);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-32640) + "'", int10 == (-32640));
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(legendTitle19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(size2D23);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle2.getVerticalAlignment();
        java.lang.Object obj4 = textTitle2.clone();
        double double5 = textTitle2.getContentXOffset();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle2.setHorizontalAlignment(horizontalAlignment6);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment6, verticalAlignment8, 0.08d, (double) 'a');
        java.lang.String str12 = horizontalAlignment6.toString();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "HorizontalAlignment.CENTER" + "'", str12.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "hi!", "");
        java.lang.String str6 = basicProjectInfo5.getCopyright();
        org.jfree.chart.ui.ProjectInfo projectInfo7 = org.jfree.chart.JFreeChart.INFO;
        basicProjectInfo5.addLibrary((org.jfree.chart.ui.Library) projectInfo7);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D10 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list11 = defaultKeyedValues2D10.getColumnKeys();
        java.util.List list12 = defaultKeyedValues2D10.getRowKeys();
        projectInfo7.setContributors(list12);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D15 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int17 = defaultKeyedValues2D15.getRowIndex((java.lang.Comparable) 10);
        java.util.List list18 = defaultKeyedValues2D15.getRowKeys();
        projectInfo7.setContributors(list18);
        java.lang.String str20 = projectInfo7.getLicenceName();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(projectInfo7);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "TableOrder.BY_COLUMN" + "'", str20.equals("TableOrder.BY_COLUMN"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.awt.Color color2 = java.awt.Color.getColor("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", 0);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.validateObject();
        defaultCategoryDataset0.addValue((double) 100.0f, (java.lang.Comparable) 1L, (java.lang.Comparable) (byte) 100);
        defaultCategoryDataset0.setValue((java.lang.Number) (short) 100, (java.lang.Comparable) ' ', (java.lang.Comparable) "VerticalAlignment.CENTER");
        java.lang.Comparable comparable10 = null;
        try {
            defaultCategoryDataset0.removeRow(comparable10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        piePlot1.setDataset(pieDataset2);
        java.awt.Paint paint4 = piePlot1.getOutlinePaint();
        java.awt.Paint paint5 = piePlot1.getBaseSectionPaint();
        java.awt.Font font7 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!", font7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = textTitle8.getPadding();
        java.awt.Font font11 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("hi!", font11);
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = textTitle12.getVerticalAlignment();
        java.lang.Object obj14 = textTitle12.clone();
        textTitle12.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle12.getBounds();
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets9.createInsetRectangle(rectangle2D17);
        piePlot1.setLegendItemShape((java.awt.Shape) rectangle2D17);
        java.lang.Object obj20 = piePlot1.clone();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        piePlot1.setDataset(pieDataset2);
        java.awt.Paint paint4 = piePlot1.getOutlinePaint();
        java.awt.Paint paint5 = piePlot1.getBaseSectionPaint();
        java.awt.Stroke stroke6 = null;
        piePlot1.setLabelOutlineStroke(stroke6);
        java.awt.Paint paint8 = piePlot1.getLabelBackgroundPaint();
        java.awt.Paint paint9 = piePlot1.getBaseSectionPaint();
        double double10 = piePlot1.getLabelLinkMargin();
        boolean boolean11 = piePlot1.getSimpleLabels();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.025d + "'", double10 == 0.025d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list14);
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("hi!", font17);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle18.getVerticalAlignment();
        java.lang.Object obj20 = textTitle18.clone();
        jFreeChart10.removeSubtitle((org.jfree.chart.title.Title) textTitle18);
        org.jfree.chart.title.TextTitle textTitle22 = null;
        jFreeChart10.setTitle(textTitle22);
        int int24 = jFreeChart10.getBackgroundImageAlignment();
        java.awt.Color color28 = java.awt.Color.getHSBColor((float) 3, (float) 100L, (float) (short) 100);
        jFreeChart10.setBackgroundPaint((java.awt.Paint) color28);
        java.awt.Font font31 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("hi!", font31);
        org.jfree.chart.util.VerticalAlignment verticalAlignment33 = textTitle32.getVerticalAlignment();
        java.lang.Object obj34 = textTitle32.clone();
        textTitle32.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D37 = textTitle32.getBounds();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent38 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textTitle32);
        textTitle32.setURLText("");
        java.awt.Paint paint41 = textTitle32.getPaint();
        textTitle32.setPadding(1.0d, (-1.0d), (-1.0d), (double) '4');
        jFreeChart10.addSubtitle((org.jfree.chart.title.Title) textTitle32);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 15 + "'", int24 == 15);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(verticalAlignment33);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        boolean boolean2 = defaultCategoryDataset0.equals((java.lang.Object) color1);
        try {
            defaultCategoryDataset0.removeRow((java.lang.Comparable) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list14);
        jFreeChart10.setAntiAlias(true);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot1, jFreeChart4);
        piePlot1.setExplodePercent((java.lang.Comparable) true, (double) (short) 1);
        java.awt.Color color9 = java.awt.Color.ORANGE;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color9);
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        java.awt.Font font14 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("hi!", font14);
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = textTitle15.getVerticalAlignment();
        java.lang.Object obj17 = textTitle15.clone();
        textTitle15.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D20 = textTitle15.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.Object obj22 = null;
        boolean boolean23 = rectangleEdge21.equals(obj22);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D25 = new org.jfree.data.DefaultKeyedValues2D(false);
        boolean boolean26 = rectangleEdge21.equals((java.lang.Object) false);
        double double27 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D20, rectangleEdge21);
        java.awt.geom.AffineTransform affineTransform28 = null;
        java.awt.Font font30 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset31 = null;
        org.jfree.chart.plot.PiePlot piePlot32 = new org.jfree.chart.plot.PiePlot(pieDataset31);
        double double33 = piePlot32.getMaximumExplodePercent();
        double double34 = piePlot32.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double36 = rectangleInsets35.getBottom();
        piePlot32.setSimpleLabelOffset(rectangleInsets35);
        org.jfree.chart.JFreeChart jFreeChart39 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font30, (org.jfree.chart.plot.Plot) piePlot32, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D41 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list42 = defaultKeyedValues2D41.getColumnKeys();
        java.util.List list43 = defaultKeyedValues2D41.getRowKeys();
        jFreeChart39.setSubtitles(list43);
        java.awt.Font font46 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle47 = new org.jfree.chart.title.TextTitle("hi!", font46);
        org.jfree.chart.util.VerticalAlignment verticalAlignment48 = textTitle47.getVerticalAlignment();
        java.lang.Object obj49 = textTitle47.clone();
        jFreeChart39.removeSubtitle((org.jfree.chart.title.Title) textTitle47);
        org.jfree.chart.title.TextTitle textTitle51 = null;
        jFreeChart39.setTitle(textTitle51);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double54 = rectangleInsets53.getBottom();
        double double56 = rectangleInsets53.calculateTopOutset((double) 0.0f);
        java.lang.String str57 = rectangleInsets53.toString();
        jFreeChart39.setPadding(rectangleInsets53);
        org.jfree.chart.ui.ProjectInfo projectInfo59 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray60 = projectInfo59.getOptionalLibraries();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D62 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list63 = defaultKeyedValues2D62.getColumnKeys();
        java.util.List list64 = defaultKeyedValues2D62.getRowKeys();
        projectInfo59.setContributors(list64);
        jFreeChart39.setSubtitles(list64);
        java.awt.RenderingHints renderingHints67 = jFreeChart39.getRenderingHints();
        java.awt.PaintContext paintContext68 = color9.createContext(colorModel11, rectangle12, rectangle2D20, affineTransform28, renderingHints67);
        java.awt.Font font70 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset71 = null;
        org.jfree.chart.plot.PiePlot piePlot72 = new org.jfree.chart.plot.PiePlot(pieDataset71);
        double double73 = piePlot72.getMaximumExplodePercent();
        double double74 = piePlot72.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets75 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double76 = rectangleInsets75.getBottom();
        piePlot72.setSimpleLabelOffset(rectangleInsets75);
        org.jfree.chart.JFreeChart jFreeChart79 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font70, (org.jfree.chart.plot.Plot) piePlot72, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D81 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list82 = defaultKeyedValues2D81.getColumnKeys();
        java.util.List list83 = defaultKeyedValues2D81.getRowKeys();
        jFreeChart79.setSubtitles(list83);
        java.awt.RenderingHints renderingHints85 = jFreeChart79.getRenderingHints();
        java.lang.Object obj86 = jFreeChart79.clone();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType87 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        boolean boolean89 = chartChangeEventType87.equals((java.lang.Object) 10L);
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent90 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rectangle12, jFreeChart79, chartChangeEventType87);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 4.0d + "'", double34 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(verticalAlignment48);
        org.junit.Assert.assertNotNull(obj49);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str57.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNotNull(projectInfo59);
        org.junit.Assert.assertNotNull(libraryArray60);
        org.junit.Assert.assertNotNull(list63);
        org.junit.Assert.assertNotNull(list64);
        org.junit.Assert.assertNotNull(renderingHints67);
        org.junit.Assert.assertNotNull(paintContext68);
        org.junit.Assert.assertNotNull(font70);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 4.0d + "'", double74 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(list82);
        org.junit.Assert.assertNotNull(list83);
        org.junit.Assert.assertNotNull(renderingHints85);
        org.junit.Assert.assertNotNull(obj86);
        org.junit.Assert.assertNotNull(chartChangeEventType87);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        piePlot1.setDataset(pieDataset2);
        piePlot1.setLabelLinkMargin((double) 10.0f);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        piePlot3.setBackgroundAlpha(0.0f);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int10 = color9.getRGB();
        java.awt.Color color11 = color9.darker();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int13 = color12.getBlue();
        java.awt.Color color14 = color12.darker();
        boolean boolean15 = color11.equals((java.lang.Object) color14);
        piePlot3.setSectionOutlinePaint((java.lang.Comparable) (short) 100, (java.awt.Paint) color11);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("PieLabelLinkStyle.STANDARD", font1, (org.jfree.chart.plot.Plot) piePlot3, true);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart18.getLegend();
        java.awt.Paint paint20 = legendTitle19.getItemPaint();
        java.awt.Font font21 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        legendTitle19.setItemFont(font21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double25 = rectangleInsets23.calculateBottomOutset((double) 89);
        legendTitle19.setLegendItemGraphicPadding(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-32640) + "'", int10 == (-32640));
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(legendTitle19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot1, jFreeChart4);
        piePlot1.setExplodePercent((java.lang.Comparable) true, (double) (short) 1);
        java.awt.Shape shape9 = piePlot1.getLegendItemShape();
        double double10 = piePlot1.getMaximumLabelWidth();
        boolean boolean11 = piePlot1.getLabelLinksVisible();
        java.awt.Paint paint12 = piePlot1.getBackgroundPaint();
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.14d + "'", double10 == 0.14d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.validateObject();
        defaultCategoryDataset0.addValue((double) 100.0f, (java.lang.Comparable) 1L, (java.lang.Comparable) (byte) 100);
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (byte) 100, (java.lang.Comparable) (byte) -1);
        try {
            defaultCategoryDataset0.removeRow((java.lang.Comparable) 1.0E-5d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        float float4 = piePlot1.getBackgroundAlpha();
        piePlot1.setSectionOutlinesVisible(true);
        int int7 = piePlot1.getBackgroundImageAlignment();
        java.awt.Stroke stroke8 = piePlot1.getBaseSectionOutlineStroke();
        java.awt.Paint[] paintArray9 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray10 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray11 = null;
        java.awt.Stroke[] strokeArray12 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Shape[] shapeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray10, paintArray11, strokeArray12, strokeArray14, shapeArray15);
        org.jfree.chart.util.TableOrder tableOrder17 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        boolean boolean18 = defaultDrawingSupplier16.equals((java.lang.Object) tableOrder17);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int21 = color20.getRGB();
        java.awt.Color color22 = java.awt.Color.getColor("", color20);
        boolean boolean23 = defaultDrawingSupplier16.equals((java.lang.Object) color20);
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier16);
        java.lang.Object obj25 = defaultDrawingSupplier16.clone();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(shapeArray15);
        org.junit.Assert.assertNotNull(tableOrder17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-32640) + "'", int21 == (-32640));
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        piePlot1.setBackgroundImageAlpha(0.0f);
        java.awt.Color color5 = java.awt.Color.RED;
        piePlot1.setShadowPaint((java.awt.Paint) color5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double8 = rectangleInsets7.getBottom();
        double double10 = rectangleInsets7.trimWidth((double) 0L);
        double double12 = rectangleInsets7.calculateBottomInset((double) (byte) -1);
        piePlot1.setInsets(rectangleInsets7);
        java.awt.Paint paint14 = piePlot1.getLabelPaint();
        java.awt.Stroke stroke16 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) "{0} version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).\n{0} LICENCE TERMS:\nPie Plot");
        org.jfree.chart.StrokeMap strokeMap17 = new org.jfree.chart.StrokeMap();
        strokeMap17.clear();
        strokeMap17.clear();
        java.awt.Stroke stroke21 = strokeMap17.getStroke((java.lang.Comparable) "{0} version VerticalAlignment.CENTER.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).  (hi!).\n{0} LICENCE TERMS:\nPie Plot");
        java.awt.Font font24 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot(pieDataset25);
        double double27 = piePlot26.getMaximumExplodePercent();
        double double28 = piePlot26.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double30 = rectangleInsets29.getBottom();
        piePlot26.setSimpleLabelOffset(rectangleInsets29);
        org.jfree.chart.JFreeChart jFreeChart33 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font24, (org.jfree.chart.plot.Plot) piePlot26, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D35 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list36 = defaultKeyedValues2D35.getColumnKeys();
        java.util.List list37 = defaultKeyedValues2D35.getRowKeys();
        jFreeChart33.setSubtitles(list37);
        java.awt.RenderingHints renderingHints39 = jFreeChart33.getRenderingHints();
        org.jfree.data.general.PieDataset pieDataset40 = null;
        org.jfree.chart.plot.PiePlot piePlot41 = new org.jfree.chart.plot.PiePlot(pieDataset40);
        double double42 = piePlot41.getMaximumExplodePercent();
        double double43 = piePlot41.getShadowYOffset();
        float float44 = piePlot41.getBackgroundAlpha();
        java.awt.Image image45 = null;
        piePlot41.setBackgroundImage(image45);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = piePlot41.getLabelPadding();
        jFreeChart33.setPadding(rectangleInsets47);
        float float49 = jFreeChart33.getBackgroundImageAlpha();
        java.awt.Stroke stroke50 = jFreeChart33.getBorderStroke();
        strokeMap17.put((java.lang.Comparable) 89, stroke50);
        piePlot1.setLabelLinkStroke(stroke50);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(stroke16);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 4.0d + "'", double28 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertNotNull(renderingHints39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 4.0d + "'", double43 == 4.0d);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 1.0f + "'", float44 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + float49 + "' != '" + 0.5f + "'", float49 == 0.5f);
        org.junit.Assert.assertNotNull(stroke50);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        piePlot1.setBackgroundAlpha(0.0f);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int8 = color7.getRGB();
        java.awt.Color color9 = color7.darker();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int11 = color10.getBlue();
        java.awt.Color color12 = color10.darker();
        boolean boolean13 = color9.equals((java.lang.Object) color12);
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) (short) 100, (java.awt.Paint) color9);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator15 = piePlot1.getLegendLabelToolTipGenerator();
        java.awt.Image image16 = piePlot1.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        double double19 = piePlot18.getMaximumExplodePercent();
        piePlot18.setBackgroundImageAlpha(0.0f);
        java.awt.Color color22 = java.awt.Color.RED;
        piePlot18.setShadowPaint((java.awt.Paint) color22);
        piePlot18.setForegroundAlpha((float) 8);
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot(pieDataset26);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator28 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot27.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator28);
        float float30 = piePlot27.getBackgroundImageAlpha();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle31 = piePlot27.getLabelLinkStyle();
        java.lang.String str32 = pieLabelLinkStyle31.toString();
        piePlot18.setLabelLinkStyle(pieLabelLinkStyle31);
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle31);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-32640) + "'", int8 == (-32640));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator15);
        org.junit.Assert.assertNull(image16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.5f + "'", float30 == 0.5f);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "PieLabelLinkStyle.STANDARD" + "'", str32.equals("PieLabelLinkStyle.STANDARD"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        piePlot1.setBackgroundImageAlpha(0.0f);
        java.awt.Color color5 = java.awt.Color.RED;
        piePlot1.setShadowPaint((java.awt.Paint) color5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double8 = rectangleInsets7.getBottom();
        double double10 = rectangleInsets7.trimWidth((double) 0L);
        double double12 = rectangleInsets7.calculateBottomInset((double) (byte) -1);
        piePlot1.setInsets(rectangleInsets7);
        java.awt.Paint paint14 = piePlot1.getLabelPaint();
        java.awt.Stroke stroke16 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) "{0} version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).\n{0} LICENCE TERMS:\nPie Plot");
        piePlot1.setSimpleLabels(false);
        piePlot1.setCircular(false, true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(stroke16);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) (short) 1, (-1.0d));
        columnArrangement5.clear();
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement5);
        blockContainer0.clear();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = null;
        try {
            org.jfree.chart.util.Size2D size2D11 = blockContainer0.arrange(graphics2D9, rectangleConstraint10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        java.lang.String str6 = standardPieSectionLabelGenerator2.generateSectionLabel(pieDataset4, (java.lang.Comparable) (short) 1);
        java.text.NumberFormat numberFormat7 = standardPieSectionLabelGenerator2.getNumberFormat();
        java.text.AttributedString attributedString9 = null;
        standardPieSectionLabelGenerator2.setAttributedLabel(0, attributedString9);
        java.lang.Object obj11 = standardPieSectionLabelGenerator2.clone();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        piePlot1.setBackgroundAlpha((float) 10);
        java.awt.Paint paint6 = piePlot1.getBaseSectionPaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = piePlot1.getURLGenerator();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke8);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = null;
        piePlot1.setURLGenerator(pieURLGenerator10);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(pieURLGenerator7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        java.lang.String str6 = standardPieSectionLabelGenerator2.generateSectionLabel(pieDataset4, (java.lang.Comparable) (short) 1);
        java.text.NumberFormat numberFormat7 = standardPieSectionLabelGenerator2.getNumberFormat();
        java.text.AttributedString attributedString9 = null;
        standardPieSectionLabelGenerator2.setAttributedLabel(0, attributedString9);
        java.text.NumberFormat numberFormat11 = standardPieSectionLabelGenerator2.getNumberFormat();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        try {
            java.text.AttributedString attributedString14 = standardPieSectionLabelGenerator2.generateAttributedSectionLabel(pieDataset12, (java.lang.Comparable) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertNotNull(numberFormat11);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        double double3 = piePlot2.getMaximumExplodePercent();
        double double4 = piePlot2.getShadowYOffset();
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        piePlot2.setNoDataMessageFont(font5);
        multiplePiePlot0.setNoDataMessageFont(font5);
        java.awt.Color color8 = java.awt.Color.gray;
        multiplePiePlot0.setOutlinePaint((java.awt.Paint) color8);
        org.jfree.chart.JFreeChart jFreeChart10 = multiplePiePlot0.getPieChart();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        java.awt.image.BufferedImage bufferedImage16 = jFreeChart10.createBufferedImage(100, 8, (double) 10.0f, (double) 3, chartRenderingInfo15);
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator19 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot18.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator19);
        org.jfree.chart.JFreeChart jFreeChart21 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot18, jFreeChart21);
        piePlot18.setExplodePercent((java.lang.Comparable) true, (double) (short) 1);
        java.awt.Color color26 = java.awt.Color.ORANGE;
        piePlot18.setBaseSectionOutlinePaint((java.awt.Paint) color26);
        java.awt.image.ColorModel colorModel28 = null;
        java.awt.Rectangle rectangle29 = null;
        java.awt.Font font31 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("hi!", font31);
        org.jfree.chart.util.VerticalAlignment verticalAlignment33 = textTitle32.getVerticalAlignment();
        java.lang.Object obj34 = textTitle32.clone();
        textTitle32.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D37 = textTitle32.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.Object obj39 = null;
        boolean boolean40 = rectangleEdge38.equals(obj39);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D42 = new org.jfree.data.DefaultKeyedValues2D(false);
        boolean boolean43 = rectangleEdge38.equals((java.lang.Object) false);
        double double44 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D37, rectangleEdge38);
        java.awt.geom.AffineTransform affineTransform45 = null;
        java.awt.Font font47 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset48 = null;
        org.jfree.chart.plot.PiePlot piePlot49 = new org.jfree.chart.plot.PiePlot(pieDataset48);
        double double50 = piePlot49.getMaximumExplodePercent();
        double double51 = piePlot49.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double53 = rectangleInsets52.getBottom();
        piePlot49.setSimpleLabelOffset(rectangleInsets52);
        org.jfree.chart.JFreeChart jFreeChart56 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font47, (org.jfree.chart.plot.Plot) piePlot49, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D58 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list59 = defaultKeyedValues2D58.getColumnKeys();
        java.util.List list60 = defaultKeyedValues2D58.getRowKeys();
        jFreeChart56.setSubtitles(list60);
        java.awt.Font font63 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle64 = new org.jfree.chart.title.TextTitle("hi!", font63);
        org.jfree.chart.util.VerticalAlignment verticalAlignment65 = textTitle64.getVerticalAlignment();
        java.lang.Object obj66 = textTitle64.clone();
        jFreeChart56.removeSubtitle((org.jfree.chart.title.Title) textTitle64);
        org.jfree.chart.title.TextTitle textTitle68 = null;
        jFreeChart56.setTitle(textTitle68);
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double71 = rectangleInsets70.getBottom();
        double double73 = rectangleInsets70.calculateTopOutset((double) 0.0f);
        java.lang.String str74 = rectangleInsets70.toString();
        jFreeChart56.setPadding(rectangleInsets70);
        org.jfree.chart.ui.ProjectInfo projectInfo76 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray77 = projectInfo76.getOptionalLibraries();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D79 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list80 = defaultKeyedValues2D79.getColumnKeys();
        java.util.List list81 = defaultKeyedValues2D79.getRowKeys();
        projectInfo76.setContributors(list81);
        jFreeChart56.setSubtitles(list81);
        java.awt.RenderingHints renderingHints84 = jFreeChart56.getRenderingHints();
        java.awt.PaintContext paintContext85 = color26.createContext(colorModel28, rectangle29, rectangle2D37, affineTransform45, renderingHints84);
        jFreeChart10.setRenderingHints(renderingHints84);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(jFreeChart10);
        org.junit.Assert.assertNotNull(bufferedImage16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(verticalAlignment33);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 4.0d + "'", double51 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(list59);
        org.junit.Assert.assertNotNull(list60);
        org.junit.Assert.assertNotNull(font63);
        org.junit.Assert.assertNotNull(verticalAlignment65);
        org.junit.Assert.assertNotNull(obj66);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str74.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNotNull(projectInfo76);
        org.junit.Assert.assertNotNull(libraryArray77);
        org.junit.Assert.assertNotNull(list80);
        org.junit.Assert.assertNotNull(list81);
        org.junit.Assert.assertNotNull(renderingHints84);
        org.junit.Assert.assertNotNull(paintContext85);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int4 = color3.getBlue();
        java.awt.Color color5 = color3.darker();
        float[] floatArray9 = null;
        float[] floatArray10 = java.awt.Color.RGBtoHSB((int) (short) 0, 1, 1, floatArray9);
        float[] floatArray11 = color5.getRGBColorComponents(floatArray9);
        float[] floatArray12 = java.awt.Color.RGBtoHSB((int) (byte) 10, (int) (byte) 100, 1, floatArray11);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        java.awt.Font font4 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        piePlot1.setNoDataMessageFont(font4);
        java.lang.String str6 = piePlot1.getPlotType();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        double double9 = piePlot8.getMaximumExplodePercent();
        double double10 = piePlot8.getShadowYOffset();
        float float11 = piePlot8.getBackgroundAlpha();
        piePlot8.setSectionOutlinesVisible(true);
        int int14 = piePlot8.getBackgroundImageAlignment();
        piePlot1.setParent((org.jfree.chart.plot.Plot) piePlot8);
        boolean boolean16 = piePlot1.getIgnoreNullValues();
        int int17 = piePlot1.getBackgroundImageAlignment();
        double double18 = piePlot1.getShadowXOffset();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Pie Plot" + "'", str6.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test462");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.toString();
//        java.util.List list2 = projectInfo0.getContributors();
//        java.lang.String str3 = projectInfo0.getLicenceText();
//        projectInfo0.setInfo("VerticalAlignment.CENTER");
//        projectInfo0.addOptionalLibrary("RectangleAnchor.CENTER");
//        projectInfo0.setName("{0} version hi!.\nVerticalAlignment.CENTER.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:RectangleAnchor.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).{0} hi! (RectangleAnchor.CENTER).\n{0} LICENCE TERMS:\nPie Plot");
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0} version hi!.\nVerticalAlignment.CENTER.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).{0} hi! (VerticalAlignment.CENTER).  (hi!).  (hi!).{0} hi! (VerticalAlignment.CENTER).  (hi!).{0} hi! (VerticalAlignment.CENTER).  (hi!).\n{0} LICENCE TERMS:\nPie Plot" + "'", str1.equals("{0} version hi!.\nVerticalAlignment.CENTER.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).{0} hi! (VerticalAlignment.CENTER).  (hi!).  (hi!).{0} hi! (VerticalAlignment.CENTER).  (hi!).{0} hi! (VerticalAlignment.CENTER).  (hi!).\n{0} LICENCE TERMS:\nPie Plot"));
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pie Plot" + "'", str3.equals("Pie Plot"));
//    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list2 = defaultKeyedValues2D1.getColumnKeys();
        int int4 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 100.0f);
        defaultKeyedValues2D1.clear();
        defaultKeyedValues2D1.clear();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = multiplePiePlot0.getLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        multiplePiePlot0.setDataset(categoryDataset4);
        org.jfree.chart.plot.Plot plot6 = multiplePiePlot0.getRootPlot();
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(plot6);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot1, jFreeChart4);
        org.jfree.chart.JFreeChart jFreeChart6 = chartChangeEvent5.getChart();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = chartChangeEvent5.getType();
        java.lang.String str8 = chartChangeEventType7.toString();
        org.junit.Assert.assertNull(jFreeChart6);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str8.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.validateObject();
        defaultCategoryDataset0.addValue((double) 100.0f, (java.lang.Comparable) 1L, (java.lang.Comparable) (byte) 100);
        int int6 = defaultCategoryDataset0.getColumnCount();
        defaultCategoryDataset0.addValue((java.lang.Number) 128, (java.lang.Comparable) "{0} version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).\n{0} LICENCE TERMS:\nPie Plot", (java.lang.Comparable) 1.0d);
        defaultCategoryDataset0.clear();
        defaultCategoryDataset0.validateObject();
        try {
            defaultCategoryDataset0.removeRow((-668));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -668");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        piePlot1.setPieIndex((int) (short) 100);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        double double8 = piePlot7.getMaximumExplodePercent();
        double double9 = piePlot7.getShadowYOffset();
        float float10 = piePlot7.getBackgroundAlpha();
        piePlot1.setParent((org.jfree.chart.plot.Plot) piePlot7);
        piePlot7.setExplodePercent((java.lang.Comparable) 10, (double) (-32640));
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator15 = piePlot7.getToolTipGenerator();
        org.jfree.chart.plot.Plot plot16 = piePlot7.getRootPlot();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertNull(pieToolTipGenerator15);
        org.junit.Assert.assertNotNull(plot16);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle2.getVerticalAlignment();
        java.lang.Object obj4 = textTitle2.clone();
        textTitle2.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle2.getBounds();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textTitle2);
        textTitle2.setURLText("");
        java.awt.Paint paint11 = textTitle2.getPaint();
        java.awt.Graphics2D graphics2D12 = null;
        try {
            org.jfree.chart.util.Size2D size2D13 = textTitle2.arrange(graphics2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        java.util.Locale locale3 = jFreeChartResources0.getLocale();
        java.util.Set<java.lang.String> strSet4 = jFreeChartResources0.keySet();
        java.lang.Object[][] objArray5 = jFreeChartResources0.getContents();
        try {
            java.lang.String str7 = jFreeChartResources0.getString("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertNotNull(strSet4);
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.validateObject();
        defaultCategoryDataset0.addValue((double) 100.0f, (java.lang.Comparable) 1L, (java.lang.Comparable) (byte) 100);
        int int6 = defaultCategoryDataset0.getColumnCount();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        double double9 = piePlot8.getMaximumExplodePercent();
        double double10 = piePlot8.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double12 = rectangleInsets11.getBottom();
        piePlot8.setSimpleLabelOffset(rectangleInsets11);
        double double14 = piePlot8.getShadowXOffset();
        boolean boolean15 = defaultCategoryDataset0.equals((java.lang.Object) piePlot8);
        piePlot8.setIgnoreNullValues(false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets1.getBottom();
        double double4 = rectangleInsets1.trimWidth((double) 0L);
        double double6 = rectangleInsets1.trimHeight((double) (byte) 0);
        double double7 = rectangleInsets1.getRight();
        blockContainer0.setMargin(rectangleInsets1);
        boolean boolean9 = blockContainer0.isEmpty();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        java.lang.String str6 = standardPieSectionLabelGenerator2.generateSectionLabel(pieDataset4, (java.lang.Comparable) (short) 1);
        java.text.NumberFormat numberFormat7 = standardPieSectionLabelGenerator2.getNumberFormat();
        java.text.AttributedString attributedString9 = null;
        standardPieSectionLabelGenerator2.setAttributedLabel((int) (short) 10, attributedString9);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(numberFormat7);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list14);
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("hi!", font17);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle18.getVerticalAlignment();
        java.lang.Object obj20 = textTitle18.clone();
        jFreeChart10.removeSubtitle((org.jfree.chart.title.Title) textTitle18);
        org.jfree.chart.title.TextTitle textTitle22 = null;
        jFreeChart10.setTitle(textTitle22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double25 = rectangleInsets24.getBottom();
        double double27 = rectangleInsets24.calculateTopOutset((double) 0.0f);
        java.lang.String str28 = rectangleInsets24.toString();
        jFreeChart10.setPadding(rectangleInsets24);
        org.jfree.chart.ui.ProjectInfo projectInfo30 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray31 = projectInfo30.getOptionalLibraries();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D33 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list34 = defaultKeyedValues2D33.getColumnKeys();
        java.util.List list35 = defaultKeyedValues2D33.getRowKeys();
        projectInfo30.setContributors(list35);
        jFreeChart10.setSubtitles(list35);
        java.awt.RenderingHints renderingHints38 = jFreeChart10.getRenderingHints();
        java.util.List list39 = jFreeChart10.getSubtitles();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str28.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNotNull(projectInfo30);
        org.junit.Assert.assertNotNull(libraryArray31);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNotNull(renderingHints38);
        org.junit.Assert.assertNotNull(list39);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo7 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "hi!", "");
        java.lang.String str8 = basicProjectInfo7.getCopyright();
        org.jfree.chart.ui.ProjectInfo projectInfo9 = org.jfree.chart.JFreeChart.INFO;
        basicProjectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo9);
        java.lang.String str11 = basicProjectInfo7.getCopyright();
        basicProjectInfo7.addOptionalLibrary("{0}");
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo7);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(projectInfo9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        double double5 = piePlot4.getMaximumExplodePercent();
        double double6 = piePlot4.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double8 = rectangleInsets7.getBottom();
        piePlot4.setSimpleLabelOffset(rectangleInsets7);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font2, (org.jfree.chart.plot.Plot) piePlot4, false);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        double double14 = piePlot13.getMaximumExplodePercent();
        double double15 = piePlot13.getShadowYOffset();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int17 = color16.getBlue();
        java.awt.Color color18 = color16.darker();
        int int19 = color18.getRed();
        java.awt.Color color20 = color18.darker();
        piePlot13.setLabelOutlinePaint((java.awt.Paint) color20);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("Rotation.ANTICLOCKWISE", font2, (org.jfree.chart.plot.Plot) piePlot13, false);
        piePlot13.setBackgroundImageAlignment(0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 89 + "'", int19 == 89);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets6.getBottom();
        piePlot3.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list13 = defaultKeyedValues2D12.getColumnKeys();
        java.util.List list14 = defaultKeyedValues2D12.getRowKeys();
        jFreeChart10.setSubtitles(list14);
        java.awt.RenderingHints renderingHints16 = jFreeChart10.getRenderingHints();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        double double19 = piePlot18.getMaximumExplodePercent();
        double double20 = piePlot18.getShadowYOffset();
        float float21 = piePlot18.getBackgroundAlpha();
        java.awt.Image image22 = null;
        piePlot18.setBackgroundImage(image22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = piePlot18.getLabelPadding();
        jFreeChart10.setPadding(rectangleInsets24);
        org.jfree.chart.ui.ProjectInfo projectInfo26 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list27 = projectInfo26.getContributors();
        jFreeChart10.setSubtitles(list27);
        org.jfree.chart.event.ChartChangeListener chartChangeListener29 = null;
        try {
            jFreeChart10.removeChangeListener(chartChangeListener29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(renderingHints16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 1.0f + "'", float21 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(projectInfo26);
        org.junit.Assert.assertNotNull(list27);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot1, jFreeChart4);
        piePlot1.setExplodePercent((java.lang.Comparable) true, (double) (short) 1);
        java.awt.Font font10 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        double double13 = piePlot12.getMaximumExplodePercent();
        double double14 = piePlot12.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets15.getBottom();
        piePlot12.setSimpleLabelOffset(rectangleInsets15);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font10, (org.jfree.chart.plot.Plot) piePlot12, false);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D21 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list22 = defaultKeyedValues2D21.getColumnKeys();
        java.util.List list23 = defaultKeyedValues2D21.getRowKeys();
        jFreeChart19.setSubtitles(list23);
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart19);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double27 = rectangleInsets26.getBottom();
        double double29 = rectangleInsets26.calculateTopOutset((double) 0.0f);
        java.lang.String str30 = rectangleInsets26.toString();
        jFreeChart19.setPadding(rectangleInsets26);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = null;
        try {
            java.awt.image.BufferedImage bufferedImage36 = jFreeChart19.createBufferedImage(0, (int) (short) -1, 0, chartRenderingInfo35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str30.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list2 = defaultKeyedValues2D1.getColumnKeys();
        java.util.List list3 = defaultKeyedValues2D1.getRowKeys();
        int int4 = defaultKeyedValues2D1.getRowCount();
        java.util.List list5 = defaultKeyedValues2D1.getRowKeys();
        try {
            defaultKeyedValues2D1.removeColumn((java.lang.Comparable) 3.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: 3.0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list2 = defaultKeyedValues2D1.getColumnKeys();
        int int4 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 100.0f);
        int int6 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) '#');
        try {
            defaultKeyedValues2D1.removeRow((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) '#');
        pieLabelDistributor1.clear();
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        float float4 = piePlot1.getBackgroundAlpha();
        piePlot1.setSectionOutlinesVisible(true);
        int int7 = piePlot1.getBackgroundImageAlignment();
        boolean boolean8 = piePlot1.getSimpleLabels();
        java.awt.Paint paint9 = piePlot1.getBackgroundPaint();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        int int11 = piePlot1.getPieIndex();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle2.getVerticalAlignment();
        java.lang.Object obj4 = textTitle2.clone();
        double double5 = textTitle2.getContentXOffset();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle2.setHorizontalAlignment(horizontalAlignment6);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment6, verticalAlignment8, 0.08d, (double) 'a');
        java.awt.Font font13 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("hi!", font13);
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = textTitle14.getVerticalAlignment();
        java.lang.Object obj16 = textTitle14.clone();
        textTitle14.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = textTitle14.getBounds();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textTitle14);
        textTitle14.setURLText("");
        org.jfree.chart.util.VerticalAlignment verticalAlignment23 = textTitle14.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement26 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment6, verticalAlignment23, (double) (short) 0, (double) 10);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(verticalAlignment15);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(verticalAlignment23);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        double double4 = piePlot3.getMaximumExplodePercent();
        double double5 = piePlot3.getShadowYOffset();
        piePlot3.setBackgroundAlpha(0.0f);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int10 = color9.getRGB();
        java.awt.Color color11 = color9.darker();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int13 = color12.getBlue();
        java.awt.Color color14 = color12.darker();
        boolean boolean15 = color11.equals((java.lang.Object) color14);
        piePlot3.setSectionOutlinePaint((java.lang.Comparable) (short) 100, (java.awt.Paint) color11);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("PieLabelLinkStyle.STANDARD", font1, (org.jfree.chart.plot.Plot) piePlot3, true);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart18.getLegend();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendTitle19.getLegendItemGraphicPadding();
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot(pieDataset21);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator23 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot22.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator23);
        org.jfree.chart.JFreeChart jFreeChart25 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot22, jFreeChart25);
        piePlot22.setExplodePercent((java.lang.Comparable) true, (double) (short) 1);
        java.awt.Shape shape30 = piePlot22.getLegendItemShape();
        org.jfree.chart.block.LineBorder lineBorder32 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint33 = lineBorder32.getPaint();
        piePlot22.setSectionOutlinePaint((java.lang.Comparable) 0.08d, paint33);
        legendTitle19.setBackgroundPaint(paint33);
        double double36 = legendTitle19.getContentXOffset();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment38 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.awt.Font font40 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle("hi!", font40);
        org.jfree.chart.util.VerticalAlignment verticalAlignment42 = textTitle41.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement45 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment38, verticalAlignment42, (double) (byte) -1, (-1.0d));
        boolean boolean46 = rectangleAnchor37.equals((java.lang.Object) columnArrangement45);
        legendTitle19.setLegendItemGraphicLocation(rectangleAnchor37);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-32640) + "'", int10 == (-32640));
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(legendTitle19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 3.0d + "'", double36 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNotNull(horizontalAlignment38);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(verticalAlignment42);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        float float4 = piePlot1.getBackgroundAlpha();
        piePlot1.setSectionOutlinesVisible(true);
        int int7 = piePlot1.getBackgroundImageAlignment();
        java.awt.Stroke stroke8 = piePlot1.getBaseSectionOutlineStroke();
        double double9 = piePlot1.getMaximumLabelWidth();
        piePlot1.setShadowXOffset((double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.14d + "'", double9 == 0.14d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        java.lang.String str6 = standardPieSectionLabelGenerator2.generateSectionLabel(pieDataset4, (java.lang.Comparable) (short) 1);
        java.text.NumberFormat numberFormat7 = standardPieSectionLabelGenerator2.getNumberFormat();
        java.text.AttributedString attributedString9 = null;
        standardPieSectionLabelGenerator2.setAttributedLabel(0, attributedString9);
        java.text.NumberFormat numberFormat11 = standardPieSectionLabelGenerator2.getNumberFormat();
        java.text.AttributedString attributedString13 = standardPieSectionLabelGenerator2.getAttributedLabel((-10));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertNotNull(numberFormat11);
        org.junit.Assert.assertNull(attributedString13);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Image image2 = piePlot1.getBackgroundImage();
        java.awt.Image image3 = piePlot1.getBackgroundImage();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = piePlot1.getDrawingSupplier();
        java.awt.Paint paint5 = piePlot1.getBackgroundPaint();
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        java.awt.Color color1 = java.awt.Color.darkGray;
        boolean boolean2 = blockBorder0.equals((java.lang.Object) color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("HorizontalAlignment.CENTER", "", "Other", "");
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot2.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator3);
        piePlot2.setBackgroundAlpha((float) 10);
        java.awt.Paint paint7 = piePlot2.getLabelLinkPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot2.getSimpleLabelOffset();
        java.awt.Font font10 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        double double13 = piePlot12.getMaximumExplodePercent();
        double double14 = piePlot12.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets15.getBottom();
        piePlot12.setSimpleLabelOffset(rectangleInsets15);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font10, (org.jfree.chart.plot.Plot) piePlot12, false);
        piePlot2.setNoDataMessageFont(font10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot21 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        multiplePiePlot21.setDataset(categoryDataset22);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = multiplePiePlot21.getLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        multiplePiePlot21.setDataset(categoryDataset25);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("{0} version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:VerticalAlignment.CENTER\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY {0}:  (hi!).  (hi!).\n{0} LICENCE TERMS:\nPie Plot", font10, (org.jfree.chart.plot.Plot) multiplePiePlot21, false);
        jFreeChart28.setTextAntiAlias(true);
        boolean boolean31 = jFreeChart28.isNotify();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent32 = null;
        try {
            jFreeChart28.plotChanged(plotChangeEvent32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection24);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        float float4 = piePlot1.getBackgroundImageAlpha();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle5 = piePlot1.getLabelLinkStyle();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int7 = color6.getRGB();
        java.awt.Color color8 = color6.darker();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int10 = color9.getBlue();
        java.awt.Color color11 = color9.darker();
        boolean boolean12 = color8.equals((java.lang.Object) color11);
        piePlot1.setLabelPaint((java.awt.Paint) color8);
        java.awt.Paint paint14 = piePlot1.getLabelShadowPaint();
        java.lang.Object obj15 = piePlot1.clone();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.5f + "'", float4 == 0.5f);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-32640) + "'", int7 == (-32640));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot6.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator7);
        piePlot6.setBackgroundAlpha((float) 10);
        java.awt.Paint paint11 = piePlot6.getLabelLinkPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = piePlot6.getSimpleLabelOffset();
        java.awt.Font font14 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        double double17 = piePlot16.getMaximumExplodePercent();
        double double18 = piePlot16.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets19.getBottom();
        piePlot16.setSimpleLabelOffset(rectangleInsets19);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font14, (org.jfree.chart.plot.Plot) piePlot16, false);
        piePlot6.setNoDataMessageFont(font14);
        piePlot1.setNoDataMessageFont(font14);
        boolean boolean26 = piePlot1.getSimpleLabels();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot1, jFreeChart4);
        double double6 = piePlot1.getStartAngle();
        piePlot1.zoom((double) (short) 10);
        try {
            piePlot1.setBackgroundImageAlpha((float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 90.0d + "'", double6 == 90.0d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color5 = color4.brighter();
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(6.25d, (double) 2, (double) (-49088), (double) (byte) -1, (java.awt.Paint) color5);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        textTitle2.draw(graphics2D3, rectangle2D4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int7 = color6.getBlue();
        java.awt.Color color8 = color6.darker();
        float[] floatArray12 = null;
        float[] floatArray13 = java.awt.Color.RGBtoHSB((int) (short) 0, 1, 1, floatArray12);
        float[] floatArray14 = color8.getRGBColorComponents(floatArray12);
        java.awt.color.ColorSpace colorSpace15 = color8.getColorSpace();
        textTitle2.setBackgroundPaint((java.awt.Paint) color8);
        float[] floatArray23 = null;
        float[] floatArray24 = java.awt.Color.RGBtoHSB((int) (short) 0, 1, 1, floatArray23);
        float[] floatArray25 = java.awt.Color.RGBtoHSB(0, 8, 89, floatArray23);
        try {
            float[] floatArray26 = color8.getRGBComponents(floatArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(colorSpace15);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getMaximumExplodePercent();
        double double3 = piePlot1.getShadowYOffset();
        piePlot1.setPieIndex((int) (short) 100);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        double double8 = piePlot7.getMaximumExplodePercent();
        double double9 = piePlot7.getShadowYOffset();
        float float10 = piePlot7.getBackgroundAlpha();
        piePlot1.setParent((org.jfree.chart.plot.Plot) piePlot7);
        boolean boolean12 = piePlot7.getLabelLinksVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle2.getVerticalAlignment();
        java.lang.Object obj4 = textTitle2.clone();
        textTitle2.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle2.getBounds();
        textTitle2.setMargin(10.0d, (double) (short) 100, (double) 'a', 1.0d);
        textTitle2.setMargin((double) (-16777216), (double) 10, 0.4d, (double) 15);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = textTitle2.getTextAlignment();
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.Font font21 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("hi!", font21);
        org.jfree.chart.util.VerticalAlignment verticalAlignment23 = textTitle22.getVerticalAlignment();
        java.lang.Object obj24 = textTitle22.clone();
        textTitle22.setURLText("hi!");
        java.awt.geom.Rectangle2D rectangle2D27 = textTitle22.getBounds();
        org.jfree.chart.ui.ProjectInfo projectInfo28 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray29 = projectInfo28.getOptionalLibraries();
        org.jfree.chart.ui.Library[] libraryArray30 = projectInfo28.getLibraries();
        java.lang.Object obj31 = textTitle2.draw(graphics2D19, rectangle2D27, (java.lang.Object) libraryArray30);
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D27, "");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(verticalAlignment23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(projectInfo28);
        org.junit.Assert.assertNotNull(libraryArray29);
        org.junit.Assert.assertNotNull(libraryArray30);
        org.junit.Assert.assertNull(obj31);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        strokeMap0.clear();
        boolean boolean3 = strokeMap0.containsKey((java.lang.Comparable) 0.08d);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        double double6 = piePlot5.getMaximumExplodePercent();
        piePlot5.setBackgroundImageAlpha(0.0f);
        piePlot5.setStartAngle((double) 1L);
        java.awt.Paint paint11 = piePlot5.getBaseSectionPaint();
        boolean boolean12 = strokeMap0.equals((java.lang.Object) paint11);
        boolean boolean14 = strokeMap0.containsKey((java.lang.Comparable) "");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        java.lang.String str1 = pieLabelLinkStyle0.toString();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PieLabelLinkStyle.STANDARD" + "'", str1.equals("PieLabelLinkStyle.STANDARD"));
    }
}

