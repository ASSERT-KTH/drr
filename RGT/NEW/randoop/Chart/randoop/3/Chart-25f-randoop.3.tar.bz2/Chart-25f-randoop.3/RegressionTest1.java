import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame2 = blockContainer0.getFrame();
        double double3 = blockContainer0.getWidth();
        java.awt.geom.Rectangle2D rectangle2D4 = blockContainer0.getBounds();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockContainer0.getMargin();
        double double7 = rectangleInsets5.trimHeight(0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(blockFrame2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        java.lang.Object obj6 = categoryAxis1.clone();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape9);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis1, shape9, "", "NOID");
        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape9, paint14);
        boolean boolean16 = legendGraphic15.isShapeOutlineVisible();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("", "", "LengthConstraintType.NONE", "RectangleAnchor.TOP_LEFT");
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.awt.Color color0 = java.awt.Color.darkGray;
        int int1 = color0.getTransparency();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        statisticalBarRenderer2.setSeriesShape((int) (short) 0, shape6);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke11 = categoryAxis10.getTickMarkStroke();
        statisticalBarRenderer2.setBaseOutlineStroke(stroke11);
        java.awt.Color color13 = java.awt.Color.cyan;
        statisticalBarRenderer2.setErrorIndicatorPaint((java.awt.Paint) color13);
        java.awt.Color color15 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass16 = color15.getClass();
        org.jfree.chart.text.TextLine textLine18 = new org.jfree.chart.text.TextLine("");
        boolean boolean20 = textLine18.equals((java.lang.Object) (-1L));
        org.jfree.chart.text.TextFragment textFragment21 = null;
        textLine18.removeFragment(textFragment21);
        boolean boolean23 = color15.equals((java.lang.Object) textLine18);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace25 = color24.getColorSpace();
        float[] floatArray32 = new float[] { 'a', 100.0f, 100L, (byte) 10, 0.5f, ' ' };
        float[] floatArray33 = color15.getComponents(colorSpace25, floatArray32);
        float[] floatArray34 = color13.getComponents(floatArray32);
        float[] floatArray35 = color0.getRGBColorComponents(floatArray34);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(colorSpace25);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray35);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 2.0f);
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement3 = blockContainer2.getArrangement();
        boolean boolean4 = valueMarker1.equals((java.lang.Object) arrangement3);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset5 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5);
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5, (java.lang.Comparable) 10L);
        double double9 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset8);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer11 = new org.jfree.chart.title.LegendItemBlockContainer(arrangement3, (org.jfree.data.general.Dataset) pieDataset8, (java.lang.Comparable) '#');
        legendItemBlockContainer11.setToolTipText("NOID");
        org.junit.Assert.assertNotNull(arrangement3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertEquals((double) number6, Double.NaN, 0);
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        boolean boolean19 = statisticalBarRenderer8.getAutoPopulateSeriesFillPaint();
        java.awt.Paint paint21 = statisticalBarRenderer8.getSeriesFillPaint(500);
        statisticalBarRenderer8.setItemLabelAnchorOffset((double) (byte) -1);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator26 = statisticalBarRenderer8.getToolTipGenerator(15, 0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer27 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity32 = new org.jfree.chart.entity.ChartEntity(shape31);
        statisticalBarRenderer27.setSeriesShape((int) (short) 0, shape31);
        statisticalBarRenderer27.setAutoPopulateSeriesShape(false);
        java.util.EventListener eventListener36 = null;
        boolean boolean37 = statisticalBarRenderer27.hasListener(eventListener36);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer38 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape42 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity43 = new org.jfree.chart.entity.ChartEntity(shape42);
        statisticalBarRenderer38.setSeriesShape((int) (short) 0, shape42);
        java.lang.Object obj45 = statisticalBarRenderer38.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition46 = new org.jfree.chart.labels.ItemLabelPosition();
        statisticalBarRenderer38.setBasePositiveItemLabelPosition(itemLabelPosition46);
        statisticalBarRenderer27.setBaseNegativeItemLabelPosition(itemLabelPosition46);
        statisticalBarRenderer8.setPositiveItemLabelPositionFallback(itemLabelPosition46);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNull(categoryToolTipGenerator26);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(obj45);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        java.awt.Stroke stroke23 = categoryPlot18.getDomainGridlineStroke();
        java.awt.Stroke stroke24 = categoryPlot18.getRangeCrosshairStroke();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation25 = null;
        try {
            boolean boolean26 = categoryPlot18.removeAnnotation(categoryAnnotation25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ChartEntity: tooltip = null", graphics2D1, 0.2d, 1.0f, 2.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        java.awt.Stroke stroke5 = categoryAxis3.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color1, stroke5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = valueMarker6.getLabelAnchor();
        java.awt.Paint paint8 = valueMarker6.getLabelPaint();
        java.awt.Stroke stroke9 = valueMarker6.getStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        float float12 = categoryAxis11.getTickMarkOutsideLength();
        categoryAxis11.setCategoryLabelPositionOffset((int) (byte) 0);
        java.lang.Object obj15 = categoryAxis11.clone();
        java.awt.Paint paint16 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        categoryAxis11.setTickMarkPaint(paint16);
        valueMarker6.setPaint(paint16);
        java.awt.Stroke stroke19 = valueMarker6.getStroke();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesItemLabelPaint(0, (java.awt.Paint) color9, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer12.getAutoPopulateSeriesStroke();
        statisticalBarRenderer12.setIncludeBaseInRange(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        statisticalBarRenderer12.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition17);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = statisticalBarRenderer12.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        java.awt.Stroke stroke22 = statisticalBarRenderer0.lookupSeriesStroke(10);
        java.awt.Stroke stroke25 = statisticalBarRenderer0.getItemStroke(2, (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj2 = keyedObjects0.getObject((int) (short) 0);
        java.lang.Object obj4 = keyedObjects0.getObject((-16777216));
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("java.awt.Color[r=0,g=255,b=255]", "VerticalAlignment.TOP", "hi!", image3, "", "ClassContext", "");
        java.awt.Image image8 = null;
        projectInfo7.setLogo(image8);
        org.jfree.chart.ui.Library[] libraryArray10 = projectInfo7.getOptionalLibraries();
        org.junit.Assert.assertNotNull(libraryArray10);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke9 = categoryAxis8.getTickMarkStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke9);
        java.awt.Color color11 = java.awt.Color.cyan;
        statisticalBarRenderer0.setErrorIndicatorPaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = statisticalBarRenderer0.getSeriesOutlineStroke(100);
        boolean boolean15 = statisticalBarRenderer0.getIncludeBaseInRange();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str1 = layer0.toString();
        java.lang.String str2 = layer0.toString();
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Layer.FOREGROUND" + "'", str1.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Layer.FOREGROUND" + "'", str2.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(10.0d, (double) (short) 1, 0.0d, (double) (short) 1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        boolean boolean8 = statisticalBarRenderer0.isSeriesItemLabelsVisible((int) (byte) 0);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        int int11 = color10.getAlpha();
        statisticalBarRenderer0.setSeriesFillPaint(500, (java.awt.Paint) color10, true);
        java.awt.Paint paint14 = statisticalBarRenderer0.getBaseOutlinePaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = statisticalBarRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getRight();
        double double3 = rectangleInsets0.calculateTopInset((double) 1.0f);
        org.jfree.chart.util.UnitType unitType4 = rectangleInsets0.getUnitType();
        double double6 = rectangleInsets0.calculateTopInset((-1.0d));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        defaultStatisticalCategoryDataset0.add((double) (-1.0f), (double) (byte) 1, (java.lang.Comparable) (-1.0f), (java.lang.Comparable) (byte) 1);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtLeft();
        java.util.List list2 = axisCollection0.getAxesAtRight();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        float float5 = categoryAxis4.getTickMarkOutsideLength();
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = categoryAxis4.hasListener(eventListener6);
        java.lang.String str8 = categoryAxis4.getLabelURL();
        java.awt.Font font10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis4.setTickLabelFont((java.lang.Comparable) 0, font10);
        categoryAxis4.setMaximumCategoryLabelWidthRatio(0.0f);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset14 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset14);
        defaultStatisticalCategoryDataset14.validateObject();
        int int17 = defaultStatisticalCategoryDataset14.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("");
        int int20 = categoryAxis19.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape26);
        statisticalBarRenderer22.setSeriesShape((int) (short) 0, shape26);
        statisticalBarRenderer22.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset14, categoryAxis19, valueAxis21, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22);
        categoryPlot32.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener35 = null;
        categoryPlot32.addChangeListener(plotChangeListener35);
        float float37 = categoryPlot32.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor38 = categoryPlot32.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("");
        float float42 = categoryAxis41.getTickMarkOutsideLength();
        java.lang.String str44 = categoryAxis41.getCategoryLabelToolTip((java.lang.Comparable) '4');
        categoryAxis41.setLabel("");
        categoryAxis41.setTickMarkOutsideLength((float) 4);
        categoryPlot32.setDomainAxis((int) '#', categoryAxis41);
        org.jfree.chart.title.TextTitle textTitle52 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D53 = null;
        java.awt.Color color55 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke58 = categoryAxis57.getTickMarkStroke();
        java.awt.Stroke stroke59 = categoryAxis57.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker60 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color55, stroke59);
        java.awt.image.ColorModel colorModel61 = null;
        java.awt.Rectangle rectangle62 = null;
        org.jfree.chart.block.BlockContainer blockContainer63 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = blockContainer63.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame65 = blockContainer63.getFrame();
        double double66 = blockContainer63.getWidth();
        java.awt.geom.Rectangle2D rectangle2D67 = blockContainer63.getBounds();
        java.awt.geom.AffineTransform affineTransform68 = null;
        java.awt.RenderingHints renderingHints69 = null;
        java.awt.PaintContext paintContext70 = color55.createContext(colorModel61, rectangle62, rectangle2D67, affineTransform68, renderingHints69);
        textTitle52.draw(graphics2D53, rectangle2D67);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions72 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor73 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor74 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition75 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor73, textBlockAnchor74);
        float float76 = categoryLabelPosition75.getWidthRatio();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions77 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions72, categoryLabelPosition75);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor78 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor79 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition80 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor78, textBlockAnchor79);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions81 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions72, categoryLabelPosition80);
        org.jfree.chart.util.RectangleEdge rectangleEdge82 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition83 = categoryLabelPositions81.getLabelPosition(rectangleEdge82);
        double double84 = categoryAxis41.getCategoryStart((-16776961), 4, rectangle2D67, rectangleEdge82);
        axisCollection0.add((org.jfree.chart.axis.Axis) categoryAxis4, rectangleEdge82);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 2.0f + "'", float5 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 1.0f + "'", float37 == 1.0f);
        org.junit.Assert.assertNotNull(categoryAnchor38);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 2.0f + "'", float42 == 2.0f);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertNotNull(blockFrame65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(paintContext70);
        org.junit.Assert.assertNotNull(categoryLabelPositions72);
        org.junit.Assert.assertNotNull(rectangleAnchor73);
        org.junit.Assert.assertNotNull(textBlockAnchor74);
        org.junit.Assert.assertTrue("'" + float76 + "' != '" + 0.95f + "'", float76 == 0.95f);
        org.junit.Assert.assertNotNull(categoryLabelPositions77);
        org.junit.Assert.assertNotNull(rectangleAnchor78);
        org.junit.Assert.assertNotNull(textBlockAnchor79);
        org.junit.Assert.assertNotNull(categoryLabelPositions81);
        org.junit.Assert.assertNotNull(rectangleEdge82);
        org.junit.Assert.assertNotNull(categoryLabelPosition83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 1.0f, (double) 100L);
        boolean boolean4 = meanAndStandardDeviation2.equals((java.lang.Object) 0L);
        java.awt.Font font5 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        boolean boolean6 = meanAndStandardDeviation2.equals((java.lang.Object) font5);
        java.lang.Number number7 = meanAndStandardDeviation2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100.0d + "'", number7.equals(100.0d));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        categoryAxis1.setCategoryLabelPositionOffset((int) (byte) 0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape13);
        statisticalBarRenderer9.setSeriesShape((int) (short) 0, shape13);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "", "", "java.awt.Color[r=0,g=255,b=255]", shape13, (java.awt.Paint) color16);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer18 = legendItem17.getFillPaintTransformer();
        boolean boolean19 = categoryAxis1.equals((java.lang.Object) legendItem17);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(gradientPaintTransformer18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getLicenceName();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color1 = color0.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.shift(range0, 3.0d, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        java.awt.Color color19 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass20 = color19.getClass();
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine("");
        boolean boolean24 = textLine22.equals((java.lang.Object) (-1L));
        org.jfree.chart.text.TextFragment textFragment25 = null;
        textLine22.removeFragment(textFragment25);
        boolean boolean27 = color19.equals((java.lang.Object) textLine22);
        int int28 = color19.getBlue();
        categoryPlot18.setOutlinePaint((java.awt.Paint) color19);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment30 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment31 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement34 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment30, verticalAlignment31, (double) 10L, (double) 'a');
        org.jfree.chart.block.BlockContainer blockContainer35 = new org.jfree.chart.block.BlockContainer();
        double double36 = blockContainer35.getContentYOffset();
        double double37 = blockContainer35.getWidth();
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke42 = categoryAxis41.getTickMarkStroke();
        java.awt.Stroke stroke43 = categoryAxis41.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color39, stroke43);
        flowArrangement34.add((org.jfree.chart.block.Block) blockContainer35, (java.lang.Object) stroke43);
        categoryPlot18.setRangeGridlineStroke(stroke43);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = categoryPlot18.getDomainAxisEdge((-16776961));
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis52.setFixedDimension((double) 2.0f);
        float float55 = categoryAxis52.getMaximumCategoryLabelWidthRatio();
        int int56 = categoryPlot18.getDomainAxisIndex(categoryAxis52);
        java.awt.Stroke stroke57 = categoryPlot18.getDomainGridlineStroke();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 192 + "'", int28 == 192);
        org.junit.Assert.assertNotNull(verticalAlignment31);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertTrue("'" + float55 + "' != '" + 0.0f + "'", float55 == 0.0f);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
        org.junit.Assert.assertNotNull(stroke57);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        statisticalBarRenderer0.setSeriesItemLabelsVisible((int) (byte) 0, (java.lang.Boolean) true);
        java.awt.Stroke stroke13 = statisticalBarRenderer0.getItemOutlineStroke((int) ' ', 3);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator14, true);
        java.awt.Shape shape17 = null;
        try {
            statisticalBarRenderer0.setBaseShape(shape17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range5 = statisticalBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, (double) (short) 0);
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4);
        int int10 = defaultStatisticalCategoryDataset4.getColumnIndex((java.lang.Comparable) 4.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets();
        boolean boolean12 = defaultStatisticalCategoryDataset4.equals((java.lang.Object) rectangleInsets11);
        int int13 = defaultStatisticalCategoryDataset4.getRowCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertEquals((double) number8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        java.lang.Object obj2 = blockContainer0.clone();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj2 = keyedObjects0.getObject((int) (short) 0);
        try {
            keyedObjects0.removeValue((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        java.lang.Object obj7 = statisticalBarRenderer0.clone();
        java.awt.Stroke stroke8 = statisticalBarRenderer0.getBaseOutlineStroke();
        statisticalBarRenderer0.setSeriesVisible(192, (java.lang.Boolean) false, true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!", font1, (java.awt.Paint) color2, 1.0f);
        java.awt.Font font6 = textFragment5.getFont();
        java.lang.String str7 = textFragment5.getText();
        java.awt.Graphics2D graphics2D8 = null;
        try {
            org.jfree.chart.util.Size2D size2D9 = textFragment5.calculateDimensions(graphics2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("java.awt.Color[r=0,g=255,b=255]", "VerticalAlignment.TOP", "hi!", image3, "", "ClassContext", "");
        projectInfo7.addOptionalLibrary("NOID");
        projectInfo7.setLicenceText("ItemLabelAnchor.INSIDE12");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "ItemLabelAnchor.INSIDE12");
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint3 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) "hi!");
        double double4 = categoryAxis1.getFixedDimension();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "ItemLabelAnchor.INSIDE12", "");
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range5 = statisticalBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = statisticalBarRenderer0.getGradientPaintTransformer();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.Block block1 = null;
        org.jfree.chart.util.StrokeList strokeList2 = new org.jfree.chart.util.StrokeList();
        strokeList2.clear();
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        boolean boolean5 = strokeList2.equals((java.lang.Object) textAnchor4);
        centerArrangement0.add(block1, (java.lang.Object) textAnchor4);
        java.lang.String str7 = textAnchor4.toString();
        java.lang.String str8 = textAnchor4.toString();
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TextAnchor.CENTER_LEFT" + "'", str7.equals("TextAnchor.CENTER_LEFT"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TextAnchor.CENTER_LEFT" + "'", str8.equals("TextAnchor.CENTER_LEFT"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        boolean boolean4 = textBlockAnchor2.equals((java.lang.Object) (short) 0);
        org.jfree.chart.block.CenterArrangement centerArrangement5 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.Block block6 = null;
        org.jfree.chart.util.StrokeList strokeList7 = new org.jfree.chart.util.StrokeList();
        strokeList7.clear();
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        boolean boolean10 = strokeList7.equals((java.lang.Object) textAnchor9);
        centerArrangement5.add(block6, (java.lang.Object) textAnchor9);
        org.jfree.chart.axis.CategoryTick categoryTick13 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) (-1.0d), textBlock1, textBlockAnchor2, textAnchor9, (double) 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor14 = categoryTick13.getTextAnchor();
        java.lang.Object obj15 = null;
        boolean boolean16 = categoryTick13.equals(obj15);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) 0L, range1, lengthConstraintType2, 0.2d, range4, lengthConstraintType5);
        java.lang.String str7 = lengthConstraintType5.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "LengthConstraintType.NONE" + "'", str7.equals("LengthConstraintType.NONE"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setTickLabelsVisible(false);
        double double5 = categoryAxis1.getFixedDimension();
        java.awt.Font font7 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 1.0f);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = statisticalBarRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Shape shape4 = null;
        statisticalBarRenderer0.setSeriesShape(100, shape4);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(0, categoryToolTipGenerator7, false);
        java.awt.Stroke stroke10 = statisticalBarRenderer0.getBaseStroke();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        java.awt.Stroke stroke5 = categoryAxis3.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color1, stroke5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = valueMarker6.getLabelAnchor();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        valueMarker6.setLabelPaint((java.awt.Paint) color8);
        org.jfree.chart.JFreeChart jFreeChart10 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color8, jFreeChart10);
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        chartChangeEvent11.setChart(jFreeChart12);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        java.lang.Object obj6 = categoryAxis1.clone();
        java.awt.Font font8 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 1.0d);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset9 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset9);
        defaultStatisticalCategoryDataset9.validateObject();
        int int12 = defaultStatisticalCategoryDataset9.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        int int15 = categoryAxis14.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape21);
        statisticalBarRenderer17.setSeriesShape((int) (short) 0, shape21);
        statisticalBarRenderer17.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset9, categoryAxis14, valueAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer17);
        categoryPlot27.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener30 = null;
        categoryPlot27.addChangeListener(plotChangeListener30);
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot27.setRangeAxisLocation(0, axisLocation33);
        categoryPlot27.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double39 = rectangleInsets37.calculateTopInset((-1.0d));
        double double41 = rectangleInsets37.calculateBottomOutset((double) 10L);
        categoryPlot27.setInsets(rectangleInsets37, true);
        boolean boolean44 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot27);
        boolean boolean45 = categoryAxis1.isTickMarksVisible();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape8);
        statisticalBarRenderer4.setSeriesShape((int) (short) 0, shape8);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape8, (double) (byte) 1, 0.0d);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity14 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        java.awt.Shape shape15 = legendItemEntity14.getArea();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color18 = java.awt.Color.BLUE;
        int int19 = color18.getRGB();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke24 = categoryAxis23.getTickMarkStroke();
        java.awt.Stroke stroke25 = categoryAxis23.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color21, stroke25);
        valueMarker26.setValue((double) 192);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        valueMarker26.setOutlineStroke(stroke29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke34 = categoryAxis33.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) (short) 100, (java.awt.Paint) color18, stroke29, (java.awt.Paint) color31, stroke34, (float) 0);
        java.awt.Paint paint37 = null;
        try {
            org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem(attributedString0, "ItemLabelAnchor.INSIDE1", "", "Category Plot", shape15, (java.awt.Paint) color16, stroke34, paint37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-16776961) + "'", int19 == (-16776961));
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("java.awt.Color[r=0,g=255,b=255]", "VerticalAlignment.TOP", "hi!", image3, "", "ClassContext", "");
        projectInfo7.addOptionalLibrary("NOID");
        projectInfo7.setLicenceText("NOID");
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        double double3 = rectangleConstraint2.getWidth();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = rectangleConstraint2.getWidthConstraintType();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        float float23 = categoryPlot18.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor24 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        categoryPlot18.setDomainGridlinePosition(categoryAnchor24);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertNotNull(categoryAnchor24);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 15, (float) (-1));
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        java.util.List list23 = categoryPlot18.getCategories();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(list23);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesItemLabelPaint(0, (java.awt.Paint) color9, false);
        java.awt.Color color12 = color9.darker();
        java.awt.Color color13 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass14 = color13.getClass();
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("");
        boolean boolean18 = textLine16.equals((java.lang.Object) (-1L));
        org.jfree.chart.text.TextFragment textFragment19 = null;
        textLine16.removeFragment(textFragment19);
        boolean boolean21 = color13.equals((java.lang.Object) textLine16);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace23 = color22.getColorSpace();
        float[] floatArray30 = new float[] { 'a', 100.0f, 100L, (byte) 10, 0.5f, ' ' };
        float[] floatArray31 = color13.getComponents(colorSpace23, floatArray30);
        float[] floatArray32 = color12.getColorComponents(floatArray30);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(colorSpace23);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape8);
        statisticalBarRenderer4.setSeriesShape((int) (short) 0, shape8);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("", "", "", "java.awt.Color[r=0,g=255,b=255]", shape8, (java.awt.Paint) color11);
        java.awt.Shape shape13 = legendItem12.getShape();
        legendItem12.setSeriesIndex((int) '4');
        org.jfree.data.general.Dataset dataset16 = null;
        legendItem12.setDataset(dataset16);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        float float23 = categoryPlot18.getBackgroundAlpha();
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot18.getDomainMarkers(layer24);
        boolean boolean26 = categoryPlot18.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = null;
        try {
            categoryPlot18.addDomainMarker(categoryMarker27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=0,g=255,b=255]", "", "hi!", "");
        java.lang.String str5 = basicProjectInfo4.getName();
        java.lang.String str6 = basicProjectInfo4.getVersion();
        basicProjectInfo4.setName("ChartEntity: tooltip = null");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo13 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=0,g=255,b=255]", "", "hi!", "");
        java.lang.String str14 = basicProjectInfo13.getLicenceName();
        basicProjectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo13);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=0,g=255,b=255]" + "'", str5.equals("java.awt.Color[r=0,g=255,b=255]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape7);
        statisticalBarRenderer3.setSeriesShape((int) (short) 0, shape7);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke12 = categoryAxis11.getTickMarkStroke();
        statisticalBarRenderer3.setBaseOutlineStroke(stroke12);
        java.awt.Color color14 = java.awt.Color.cyan;
        statisticalBarRenderer3.setErrorIndicatorPaint((java.awt.Paint) color14);
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass17 = color16.getClass();
        org.jfree.chart.text.TextLine textLine19 = new org.jfree.chart.text.TextLine("");
        boolean boolean21 = textLine19.equals((java.lang.Object) (-1L));
        org.jfree.chart.text.TextFragment textFragment22 = null;
        textLine19.removeFragment(textFragment22);
        boolean boolean24 = color16.equals((java.lang.Object) textLine19);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace26 = color25.getColorSpace();
        float[] floatArray33 = new float[] { 'a', 100.0f, 100L, (byte) 10, 0.5f, ' ' };
        float[] floatArray34 = color16.getComponents(colorSpace26, floatArray33);
        float[] floatArray35 = color14.getComponents(floatArray33);
        float[] floatArray36 = color0.getComponents(colorSpace2, floatArray35);
        java.awt.image.ColorModel colorModel37 = null;
        java.awt.Rectangle rectangle38 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke44 = categoryAxis43.getTickMarkStroke();
        java.awt.Stroke stroke45 = categoryAxis43.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color41, stroke45);
        java.awt.image.ColorModel colorModel47 = null;
        java.awt.Rectangle rectangle48 = null;
        org.jfree.chart.block.BlockContainer blockContainer49 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = blockContainer49.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame51 = blockContainer49.getFrame();
        double double52 = blockContainer49.getWidth();
        java.awt.geom.Rectangle2D rectangle2D53 = blockContainer49.getBounds();
        java.awt.geom.AffineTransform affineTransform54 = null;
        java.awt.RenderingHints renderingHints55 = null;
        java.awt.PaintContext paintContext56 = color41.createContext(colorModel47, rectangle48, rectangle2D53, affineTransform54, renderingHints55);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType57 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType58 = null;
        java.awt.geom.Rectangle2D rectangle2D59 = rectangleInsets39.createAdjustedRectangle(rectangle2D53, lengthAdjustmentType57, lengthAdjustmentType58);
        java.awt.geom.AffineTransform affineTransform60 = null;
        java.awt.RenderingHints renderingHints61 = null;
        java.awt.PaintContext paintContext62 = color0.createContext(colorModel37, rectangle38, rectangle2D59, affineTransform60, renderingHints61);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(colorSpace26);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(blockFrame51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(paintContext56);
        org.junit.Assert.assertNotNull(lengthAdjustmentType57);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertNotNull(paintContext62);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getHeightConstraintType();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Comparable comparable5 = null;
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, comparable5);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleConstraint2, (org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset4);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        float float10 = categoryAxis9.getTickMarkOutsideLength();
        categoryAxis9.setCategoryLabelPositionOffset((int) (byte) 0);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape18);
        statisticalBarRenderer14.setSeriesShape((int) (short) 0, shape18);
        statisticalBarRenderer14.setAutoPopulateSeriesShape(false);
        java.util.EventListener eventListener23 = null;
        boolean boolean24 = statisticalBarRenderer14.hasListener(eventListener23);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity(shape29);
        statisticalBarRenderer25.setSeriesShape((int) (short) 0, shape29);
        java.lang.Object obj32 = statisticalBarRenderer25.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = new org.jfree.chart.labels.ItemLabelPosition();
        statisticalBarRenderer25.setBasePositiveItemLabelPosition(itemLabelPosition33);
        statisticalBarRenderer14.setBaseNegativeItemLabelPosition(itemLabelPosition33);
        java.lang.Object obj36 = statisticalBarRenderer14.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, categoryAxis9, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer14);
        java.awt.Paint paint38 = categoryAxis9.getTickLabelPaint();
        categoryAxis9.setTickMarkInsideLength((-1.0f));
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, 4.0d, 0.0d, 3.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint3 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) "hi!");
        double double4 = categoryAxis1.getLowerMargin();
        categoryAxis1.setLabelToolTip("TextAnchor.CENTER_LEFT");
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis1.getTickLabelInsets();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D5, (float) 0L, 0.0f, textAnchor8, (double) '#', (float) 10L, 0.0f);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.util.StrokeList strokeList18 = new org.jfree.chart.util.StrokeList();
        strokeList18.clear();
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        boolean boolean21 = strokeList18.equals((java.lang.Object) textAnchor20);
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D15, (float) (byte) 0, (float) '#', textAnchor20, 0.2d, (float) (byte) 1, (float) 0);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ChartChangeEventType.GENERAL", graphics2D1, (float) 100, (float) 128, textAnchor8, (double) 10, textAnchor20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Comparable comparable2 = null;
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1, comparable2);
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset3, (java.lang.Comparable) (short) 0, 97.0d, 0);
        org.jfree.data.category.CategoryDataset categoryDataset8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 1L, (org.jfree.data.KeyedValues) pieDataset7);
        double double9 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset7);
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertNotNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = statisticalBarRenderer0.getLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = statisticalBarRenderer0.getLegendItems();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3);
        java.util.List list5 = defaultStatisticalCategoryDataset3.getColumnKeys();
        double double7 = defaultStatisticalCategoryDataset3.getRangeLowerBound(false);
        boolean boolean8 = legendItemCollection2.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(legendItemCollection2);
        org.junit.Assert.assertEquals((double) number4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getTickMarkOutsideLength();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = categoryAxis2.hasListener(eventListener4);
        java.lang.String str6 = categoryAxis2.getLabelURL();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis2.setTickLabelFont((java.lang.Comparable) 0, font8);
        java.awt.Paint paint10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.axis.AxisState axisState12 = new org.jfree.chart.axis.AxisState((double) 0.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge14);
        axisState12.moveCursor(0.0d, rectangleEdge14);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor20 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition21 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor19, textBlockAnchor20);
        float float22 = categoryLabelPosition21.getWidthRatio();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = categoryLabelPosition21.getLabelAnchor();
        boolean boolean24 = horizontalAlignment18.equals((java.lang.Object) categoryLabelPosition21);
        org.jfree.chart.util.VerticalAlignment verticalAlignment25 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement28 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment18, verticalAlignment25, 1.0d, (double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font8, paint10, rectangleEdge14, horizontalAlignment17, verticalAlignment25, rectangleInsets29);
        java.lang.String str31 = verticalAlignment25.toString();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(textBlockAnchor20);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.95f + "'", float22 == 0.95f);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(verticalAlignment25);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "VerticalAlignment.CENTER" + "'", str31.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setTickLabelsVisible(false);
        double double5 = categoryAxis1.getFixedDimension();
        java.awt.Paint paint6 = categoryAxis1.getTickMarkPaint();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(500);
        java.lang.Object obj3 = objectList1.get((-1));
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        boolean boolean19 = statisticalBarRenderer8.getAutoPopulateSeriesFillPaint();
        java.awt.Font font21 = statisticalBarRenderer8.getSeriesItemLabelFont(0);
        java.awt.Stroke stroke24 = statisticalBarRenderer8.getItemOutlineStroke(192, 500);
        java.lang.Class<?> wildcardClass25 = statisticalBarRenderer8.getClass();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent26 = null;
        statisticalBarRenderer8.notifyListeners(rendererChangeEvent26);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(font21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(wildcardClass25);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = defaultDrawingSupplier0.clone();
        java.lang.Object obj2 = null;
        boolean boolean3 = defaultDrawingSupplier0.equals(obj2);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot18.getRangeAxisEdge(0);
        categoryPlot18.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis27 = categoryPlot18.getRangeAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = categoryPlot18.getDomainAxis();
        java.awt.Font font29 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis28.setLabelFont(font29);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(categoryAxis28);
        org.junit.Assert.assertNotNull(font29);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 2.0f);
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement3 = blockContainer2.getArrangement();
        boolean boolean4 = valueMarker1.equals((java.lang.Object) arrangement3);
        java.awt.Stroke stroke5 = valueMarker1.getOutlineStroke();
        java.lang.String str6 = valueMarker1.getLabel();
        org.junit.Assert.assertNotNull(arrangement3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) 4.0d);
        java.util.List list3 = keyedObjects0.getKeys();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        java.awt.Stroke stroke5 = categoryAxis3.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color1, stroke5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = valueMarker6.getLabelAnchor();
        java.awt.Paint paint8 = valueMarker6.getLabelPaint();
        java.awt.Paint paint9 = valueMarker6.getPaint();
        double double10 = valueMarker6.getValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = null;
        try {
            valueMarker6.setLabelOffset(rectangleInsets11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        try {
            org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem(attributedString0, "CategoryAnchor.MIDDLE", "", "RectangleEdge.TOP", shape5, (java.awt.Paint) color6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation(0.0d, 0.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        boolean boolean8 = statisticalBarRenderer0.isSeriesItemLabelsVisible((int) (byte) 0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape13);
        statisticalBarRenderer9.setSeriesShape((int) (short) 0, shape13);
        java.lang.Object obj16 = statisticalBarRenderer9.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = new org.jfree.chart.labels.ItemLabelPosition();
        statisticalBarRenderer9.setBasePositiveItemLabelPosition(itemLabelPosition17);
        statisticalBarRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition17);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = statisticalBarRenderer0.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNull(itemLabelPosition20);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        categoryAxis1.setCategoryLabelPositionOffset((int) (byte) 0);
        java.lang.Object obj5 = categoryAxis1.clone();
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range5 = statisticalBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, (double) (short) 0);
        java.lang.Object obj8 = defaultStatisticalCategoryDataset4.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        java.util.EventListener eventListener3 = null;
        boolean boolean4 = categoryAxis1.hasListener(eventListener3);
        java.lang.String str5 = categoryAxis1.getLabelURL();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "ItemLabelAnchor.INSIDE1", "NOID");
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor8 = itemLabelPosition7.getRotationAnchor();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        java.util.Collection collection24 = categoryPlot18.getDomainMarkers(15, layer22);
        java.awt.Stroke stroke25 = categoryPlot18.getRangeGridlineStroke();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=0,g=255,b=255]", "", "hi!", "");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo9 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=0,g=255,b=255]", "", "hi!", "");
        basicProjectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo9);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo15 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=0,g=255,b=255]", "", "hi!", "");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo20 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=0,g=255,b=255]", "", "hi!", "");
        basicProjectInfo15.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo20);
        basicProjectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo20);
        basicProjectInfo4.setInfo("");
        java.awt.Image image28 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo32 = new org.jfree.chart.ui.ProjectInfo("java.awt.Color[r=0,g=255,b=255]", "VerticalAlignment.TOP", "hi!", image28, "", "ClassContext", "");
        java.util.List list33 = null;
        projectInfo32.setContributors(list33);
        basicProjectInfo4.addLibrary((org.jfree.chart.ui.Library) projectInfo32);
        projectInfo32.setCopyright("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        java.lang.String str38 = projectInfo32.toString();
        java.lang.String str39 = projectInfo32.getLicenceName();
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "java.awt.Color[r=0,g=255,b=255] version VerticalAlignment.TOP.\nRectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY java.awt.Color[r=0,g=255,b=255]:None\njava.awt.Color[r=0,g=255,b=255] LICENCE TERMS:\n" + "'", str38.equals("java.awt.Color[r=0,g=255,b=255] version VerticalAlignment.TOP.\nRectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY java.awt.Color[r=0,g=255,b=255]:None\njava.awt.Color[r=0,g=255,b=255] LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "ClassContext" + "'", str39.equals("ClassContext"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        statisticalBarRenderer0.setAutoPopulateSeriesShape(false);
        java.util.EventListener eventListener9 = null;
        boolean boolean10 = statisticalBarRenderer0.hasListener(eventListener9);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape15);
        statisticalBarRenderer11.setSeriesShape((int) (short) 0, shape15);
        java.lang.Object obj18 = statisticalBarRenderer11.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition();
        statisticalBarRenderer11.setBasePositiveItemLabelPosition(itemLabelPosition19);
        statisticalBarRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition19);
        java.lang.Boolean boolean23 = statisticalBarRenderer0.getSeriesVisibleInLegend(2);
        java.awt.Color color25 = java.awt.Color.BLUE;
        int int26 = color25.getRGB();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke31 = categoryAxis30.getTickMarkStroke();
        java.awt.Stroke stroke32 = categoryAxis30.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color28, stroke32);
        valueMarker33.setValue((double) 192);
        java.awt.Stroke stroke36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        valueMarker33.setOutlineStroke(stroke36);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke41 = categoryAxis40.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 100, (java.awt.Paint) color25, stroke36, (java.awt.Paint) color38, stroke41, (float) 0);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color25);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNull(boolean23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-16776961) + "'", int26 == (-16776961));
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(stroke41);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint((double) (short) 0, range3);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = rectangleConstraint4.getWidthConstraintType();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = rectangleConstraint4.getHeightConstraintType();
        org.jfree.data.Range range8 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 192, range1, lengthConstraintType6, (double) 'a', range8, lengthConstraintType9);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        categoryAxis1.setCategoryLabelPositionOffset((int) (byte) 0);
        boolean boolean5 = categoryAxis1.isTickMarksVisible();
        double double6 = categoryAxis1.getLabelAngle();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        java.util.List list1 = axisState0.getTicks();
        java.util.Collection collection2 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list1);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(collection2);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        java.awt.Stroke stroke7 = categoryAxis5.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color3, stroke7);
        java.awt.image.ColorModel colorModel9 = null;
        java.awt.Rectangle rectangle10 = null;
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = blockContainer11.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame13 = blockContainer11.getFrame();
        double double14 = blockContainer11.getWidth();
        java.awt.geom.Rectangle2D rectangle2D15 = blockContainer11.getBounds();
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color3.createContext(colorModel9, rectangle10, rectangle2D15, affineTransform16, renderingHints17);
        textTitle0.draw(graphics2D1, rectangle2D15);
        textTitle0.setPadding((double) (byte) 0, 0.0d, (double) 3, (double) 15);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(blockFrame13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(paintContext18);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        statisticalBarRenderer0.setBaseSeriesVisible(true, true);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        statisticalBarRenderer0.setBaseOutlinePaint((java.awt.Paint) color10, true);
        java.awt.Stroke stroke13 = statisticalBarRenderer0.getBaseOutlineStroke();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double1 = rectangleConstraint0.getWidth();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = rectangleConstraint0.getHeightConstraintType();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType2);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        boolean boolean19 = statisticalBarRenderer8.getAutoPopulateSeriesFillPaint();
        java.awt.Font font21 = statisticalBarRenderer8.getSeriesItemLabelFont(0);
        java.awt.Stroke stroke24 = statisticalBarRenderer8.getItemOutlineStroke(192, 500);
        double double25 = statisticalBarRenderer8.getMinimumBarLength();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(font21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) 2.0f);
        org.jfree.chart.text.TextAnchor textAnchor3 = valueMarker2.getLabelTextAnchor();
        java.awt.Stroke stroke4 = valueMarker2.getStroke();
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("LengthConstraintType.NONE", font6, paint7);
        valueMarker2.setLabelFont(font6);
        boolean boolean10 = centerArrangement0.equals((java.lang.Object) valueMarker2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        strokeList0.clear();
        java.lang.Object obj2 = strokeList0.clone();
        java.lang.Object obj3 = strokeList0.clone();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateX((double) 500);
        double double3 = blockParams0.getTranslateX();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 500.0d + "'", double3 == 500.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = null;
        try {
            numberAxis0.setTickUnit(numberTickUnit1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.resizeRange((double) (short) 1, (double) (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 0.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge3);
        axisState1.moveCursor(0.0d, rectangleEdge3);
        java.util.List list6 = axisState1.getTicks();
        axisState1.cursorUp((double) 100L);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("Category Plot");
        double[] doubleArray8 = new double[] { (-1L), (short) 10 };
        double[] doubleArray11 = new double[] { (-1L), (short) 10 };
        double[] doubleArray14 = new double[] { (-1L), (short) 10 };
        double[] doubleArray17 = new double[] { (-1L), (short) 10 };
        double[][] doubleArray18 = new double[][] { doubleArray8, doubleArray11, doubleArray14, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=0,g=255,b=255]", "Size2D[width=0.0, height=10.0]", doubleArray18);
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=64,g=64,b=64]", doubleArray18);
        try {
            java.lang.String str22 = standardCategorySeriesLabelGenerator1.generateLabel(categoryDataset20, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(categoryDataset20);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.axis.TickType tickType0 = null;
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D4, (float) 0L, 0.0f, textAnchor7, (double) '#', (float) 10L, 0.0f);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity(shape16);
        statisticalBarRenderer12.setSeriesShape((int) (short) 0, shape16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = statisticalBarRenderer12.getBasePositiveItemLabelPosition();
        java.awt.Paint paint21 = statisticalBarRenderer12.lookupSeriesPaint(0);
        boolean boolean22 = statisticalBarRenderer12.getBaseSeriesVisible();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = statisticalBarRenderer12.getNegativeItemLabelPosition((int) (short) 100, 0);
        org.jfree.chart.text.TextAnchor textAnchor26 = itemLabelPosition25.getTextAnchor();
        org.jfree.chart.axis.NumberTick numberTick28 = new org.jfree.chart.axis.NumberTick(tickType0, (-1.0d), "-1,100,-100,100,-100,1,100,1,100,100,1,100,1,-100,100,-100,100,-1,-100,-1,-100,-100,-1,-100,-1,-100", textAnchor7, textAnchor26, (double) 2.0f);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
        org.junit.Assert.assertNotNull(textAnchor26);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesItemLabelPaint(0, (java.awt.Paint) color9, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer12.getAutoPopulateSeriesStroke();
        statisticalBarRenderer12.setIncludeBaseInRange(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        statisticalBarRenderer12.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition17);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = statisticalBarRenderer12.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        java.awt.Stroke stroke22 = statisticalBarRenderer0.lookupSeriesStroke(10);
        boolean boolean24 = statisticalBarRenderer0.isSeriesVisible((int) '4');
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke5 = categoryAxis4.getTickMarkStroke();
        java.awt.Stroke stroke6 = categoryAxis4.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color2, stroke6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = valueMarker7.getLabelAnchor();
        java.awt.Paint paint9 = valueMarker7.getLabelPaint();
        java.awt.Paint paint10 = valueMarker7.getPaint();
        boolean boolean11 = gradientPaintTransformType0.equals((java.lang.Object) paint10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke14 = categoryAxis13.getTickMarkStroke();
        categoryAxis13.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        java.lang.Object obj18 = categoryAxis13.clone();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape21);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity25 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis13, shape21, "", "NOID");
        boolean boolean26 = gradientPaintTransformType0.equals((java.lang.Object) axisLabelEntity25);
        java.lang.String str27 = axisLabelEntity25.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "AxisLabelEntity: label = " + "'", str27.equals("AxisLabelEntity: label = "));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        java.awt.Stroke stroke5 = categoryAxis3.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color1, stroke5);
        valueMarker6.setValue((double) 192);
        java.awt.Stroke stroke9 = valueMarker6.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = valueMarker6.getLabelOffset();
        double double12 = rectangleInsets10.calculateBottomInset((double) (-1.0f));
        double double14 = rectangleInsets10.calculateLeftInset((double) 2.0f);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.0d + "'", double14 == 3.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.util.Locale locale1 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        org.jfree.chart.renderer.RendererState rendererState6 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo5);
        java.lang.Class<?> wildcardClass7 = rendererState6.getClass();
        java.awt.Color color8 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass9 = color8.getClass();
        java.lang.Object obj10 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ItemLabelAnchor.OUTSIDE1", (java.lang.Class) wildcardClass7, (java.lang.Class) wildcardClass9);
        java.lang.ClassLoader classLoader11 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass7);
        boolean boolean12 = plotRenderingInfo3.equals((java.lang.Object) classLoader11);
        java.util.ResourceBundle.Control control13 = null;
        try {
            java.util.ResourceBundle resourceBundle14 = java.util.ResourceBundle.getBundle("", locale1, classLoader11, control13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertNotNull(classLoader11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        categoryAxis1.setCategoryLabelPositionOffset((int) (byte) 0);
        java.lang.Object obj5 = categoryAxis1.clone();
        categoryAxis1.configure();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        statisticalBarRenderer0.setAutoPopulateSeriesShape(false);
        java.util.EventListener eventListener9 = null;
        boolean boolean10 = statisticalBarRenderer0.hasListener(eventListener9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_BLUE;
        statisticalBarRenderer0.setErrorIndicatorPaint((java.awt.Paint) color11);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator13);
        java.awt.Color color16 = java.awt.Color.BLUE;
        int int17 = color16.getRGB();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke22 = categoryAxis21.getTickMarkStroke();
        java.awt.Stroke stroke23 = categoryAxis21.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color19, stroke23);
        valueMarker24.setValue((double) 192);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        valueMarker24.setOutlineStroke(stroke27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke32 = categoryAxis31.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker((double) (short) 100, (java.awt.Paint) color16, stroke27, (java.awt.Paint) color29, stroke32, (float) 0);
        boolean boolean35 = statisticalBarRenderer0.equals((java.lang.Object) 0);
        statisticalBarRenderer0.setAutoPopulateSeriesShape(true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-16776961) + "'", int17 == (-16776961));
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        defaultStatisticalCategoryDataset0.addChangeListener(datasetChangeListener3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, true);
        try {
            java.lang.Comparable comparable8 = defaultStatisticalCategoryDataset0.getColumnKey(128);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 128, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        java.awt.Stroke stroke5 = categoryAxis3.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color1, stroke5);
        valueMarker6.setValue((double) 192);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        valueMarker6.setOutlineStroke(stroke9);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset11 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset11);
        defaultStatisticalCategoryDataset11.validateObject();
        int int14 = defaultStatisticalCategoryDataset11.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        int int17 = categoryAxis16.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity(shape23);
        statisticalBarRenderer19.setSeriesShape((int) (short) 0, shape23);
        statisticalBarRenderer19.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset11, categoryAxis16, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer19);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke34 = categoryAxis33.getTickMarkStroke();
        java.awt.Stroke stroke35 = categoryAxis33.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color31, stroke35);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = valueMarker36.getLabelAnchor();
        java.awt.Paint paint38 = valueMarker36.getLabelPaint();
        java.awt.Paint paint39 = valueMarker36.getPaint();
        categoryPlot29.setOutlinePaint(paint39);
        valueMarker6.setOutlinePaint(paint39);
        double double42 = valueMarker6.getValue();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 192.0d + "'", double42 == 192.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape8);
        statisticalBarRenderer4.setSeriesShape((int) (short) 0, shape8);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("", "", "", "java.awt.Color[r=0,g=255,b=255]", shape8, (java.awt.Paint) color11);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity13 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        java.awt.Shape shape14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        legendItemEntity13.setArea(shape14);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        java.util.EventListener eventListener3 = null;
        boolean boolean4 = categoryAxis1.hasListener(eventListener3);
        categoryAxis1.setVisible(true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis1);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = categoryAxis1.getCategoryLabelPositions();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        java.util.List list1 = axisState0.getTicks();
        axisState0.cursorRight((double) 10L);
        axisState0.cursorRight(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge7);
        axisState0.moveCursor((double) '#', rectangleEdge8);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("java.awt.Color[r=0,g=255,b=255]", "VerticalAlignment.TOP", "hi!", image3, "", "ClassContext", "");
        java.awt.Image image8 = null;
        projectInfo7.setLogo(image8);
        java.lang.String str10 = projectInfo7.getCopyright();
        java.awt.Image image11 = projectInfo7.getLogo();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNull(image11);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateTopInset((-1.0d));
        double double4 = rectangleInsets0.calculateLeftInset(2.0d);
        double double5 = rectangleInsets0.getTop();
        double double7 = rectangleInsets0.calculateTopInset(3.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        java.awt.Stroke stroke5 = categoryAxis3.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color1, stroke5);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke11 = categoryAxis10.getTickMarkStroke();
        java.awt.Stroke stroke12 = categoryAxis10.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color8, stroke12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = valueMarker13.getLabelAnchor();
        valueMarker6.setLabelAnchor(rectangleAnchor14);
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass17 = color16.getClass();
        org.jfree.chart.text.TextLine textLine19 = new org.jfree.chart.text.TextLine("");
        boolean boolean21 = textLine19.equals((java.lang.Object) (-1L));
        org.jfree.chart.text.TextFragment textFragment22 = null;
        textLine19.removeFragment(textFragment22);
        boolean boolean24 = color16.equals((java.lang.Object) textLine19);
        valueMarker6.setLabelPaint((java.awt.Paint) color16);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("-1,100,-100,100,-100,1,100,1,100,100,1,100,1,-100,100,-100,100,-1,-100,-1,-100,-100,-1,-100,-1,-100", "RectangleAnchor.TOP_LEFT", "Layer.FOREGROUND", "ChartChangeEventType.NEW_DATASET");
        java.lang.String str5 = basicProjectInfo4.getCopyright();
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        java.awt.Shape shape5 = statisticalBarRenderer0.lookupSeriesShape((int) (byte) 10);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean8 = statisticalBarRenderer7.getAutoPopulateSeriesStroke();
        statisticalBarRenderer7.setIncludeBaseInRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke13 = categoryAxis12.getTickMarkStroke();
        statisticalBarRenderer7.setBaseOutlineStroke(stroke13);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity(shape19);
        statisticalBarRenderer15.setSeriesShape((int) (short) 0, shape19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = statisticalBarRenderer15.getBasePositiveItemLabelPosition();
        java.awt.Paint paint24 = statisticalBarRenderer15.lookupSeriesPaint(0);
        boolean boolean25 = statisticalBarRenderer15.getBaseSeriesVisible();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = statisticalBarRenderer15.getNegativeItemLabelPosition((int) (short) 100, 0);
        statisticalBarRenderer7.setBasePositiveItemLabelPosition(itemLabelPosition28, true);
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition(10, itemLabelPosition28, true);
        org.jfree.chart.text.TextAnchor textAnchor33 = itemLabelPosition28.getTextAnchor();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertNotNull(textAnchor33);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        statisticalBarRenderer0.setAutoPopulateSeriesShape(false);
        java.awt.Font font11 = statisticalBarRenderer0.getItemLabelFont(255, 0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator12, false);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint16 = defaultDrawingSupplier15.getNextPaint();
        java.awt.Stroke stroke17 = defaultDrawingSupplier15.getNextStroke();
        statisticalBarRenderer0.setErrorIndicatorStroke(stroke17);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setVisible(false);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4);
        defaultStatisticalCategoryDataset4.validateObject();
        int int7 = defaultStatisticalCategoryDataset4.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        int int10 = categoryAxis9.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity(shape16);
        statisticalBarRenderer12.setSeriesShape((int) (short) 0, shape16);
        statisticalBarRenderer12.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, categoryAxis9, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer12);
        categoryPlot22.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        categoryPlot22.addChangeListener(plotChangeListener25);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot22.getRangeAxisEdge(0);
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot22);
        org.jfree.data.general.DatasetGroup datasetGroup30 = categoryPlot22.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis32.setFixedDimension((double) 2.0f);
        java.awt.Font font35 = categoryAxis32.getTickLabelFont();
        categoryAxis32.setCategoryMargin((double) (short) 10);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState40 = new org.jfree.chart.axis.AxisState((double) 10);
        axisState40.cursorRight((double) 100.0f);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke49 = categoryAxis48.getTickMarkStroke();
        java.awt.Stroke stroke50 = categoryAxis48.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker51 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color46, stroke50);
        java.awt.image.ColorModel colorModel52 = null;
        java.awt.Rectangle rectangle53 = null;
        org.jfree.chart.block.BlockContainer blockContainer54 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = blockContainer54.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame56 = blockContainer54.getFrame();
        double double57 = blockContainer54.getWidth();
        java.awt.geom.Rectangle2D rectangle2D58 = blockContainer54.getBounds();
        java.awt.geom.AffineTransform affineTransform59 = null;
        java.awt.RenderingHints renderingHints60 = null;
        java.awt.PaintContext paintContext61 = color46.createContext(colorModel52, rectangle53, rectangle2D58, affineTransform59, renderingHints60);
        textTitle43.draw(graphics2D44, rectangle2D58);
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge63);
        double double65 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D58, rectangleEdge64);
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge66);
        java.util.List list68 = categoryAxis32.refreshTicks(graphics2D38, axisState40, rectangle2D58, rectangleEdge67);
        categoryAxis32.configure();
        boolean boolean70 = categoryAxis32.isTickLabelsVisible();
        int int71 = categoryPlot22.getDomainAxisIndex(categoryAxis32);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNull(datasetGroup30);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(blockFrame56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(paintContext61);
        org.junit.Assert.assertNotNull(rectangleEdge63);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge66);
        org.junit.Assert.assertNotNull(rectangleEdge67);
        org.junit.Assert.assertNotNull(list68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        org.jfree.chart.renderer.RendererState rendererState3 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo2);
        java.lang.Class<?> wildcardClass4 = rendererState3.getClass();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass6 = color5.getClass();
        java.lang.Object obj7 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("java.awt.Color[r=0,g=255,b=255]", (java.lang.Class) wildcardClass4, (java.lang.Class) wildcardClass6);
        java.io.InputStream inputStream8 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ClassContext", (java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNull(inputStream8);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.util.Locale locale1 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        org.jfree.chart.renderer.RendererState rendererState4 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo3);
        java.lang.Class<?> wildcardClass5 = rendererState4.getClass();
        java.awt.Color color6 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass7 = color6.getClass();
        java.lang.Object obj8 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ItemLabelAnchor.OUTSIDE1", (java.lang.Class) wildcardClass5, (java.lang.Class) wildcardClass7);
        java.lang.ClassLoader classLoader9 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass5);
        java.util.ResourceBundle.Control control10 = null;
        try {
            java.util.ResourceBundle resourceBundle11 = java.util.ResourceBundle.getBundle("java.awt.Color[r=0,g=255,b=255]", locale1, classLoader9, control10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(classLoader9);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        statisticalBarRenderer0.setAutoPopulateSeriesPaint(true);
        java.awt.Stroke stroke6 = statisticalBarRenderer0.getBaseOutlineStroke();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator7);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = defaultDrawingSupplier0.clone();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        double[] doubleArray27 = new double[] { (-1L), (short) 10 };
        double[] doubleArray30 = new double[] { (-1L), (short) 10 };
        double[] doubleArray33 = new double[] { (-1L), (short) 10 };
        double[] doubleArray36 = new double[] { (-1L), (short) 10 };
        double[][] doubleArray37 = new double[][] { doubleArray27, doubleArray30, doubleArray33, doubleArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=0,g=255,b=255]", "Size2D[width=0.0, height=10.0]", doubleArray37);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = categoryPlot18.getRendererForDataset(categoryDataset38);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment40 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor42 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition43 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor41, textBlockAnchor42);
        float float44 = categoryLabelPosition43.getWidthRatio();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor45 = categoryLabelPosition43.getLabelAnchor();
        boolean boolean46 = horizontalAlignment40.equals((java.lang.Object) categoryLabelPosition43);
        boolean boolean47 = categoryPlot18.equals((java.lang.Object) boolean46);
        org.jfree.chart.block.BlockBorder blockBorder48 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = blockBorder48.getInsets();
        categoryPlot18.setInsets(rectangleInsets49);
        org.jfree.chart.axis.ValueAxis valueAxis52 = categoryPlot18.getRangeAxisForDataset((-1));
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNull(categoryItemRenderer39);
        org.junit.Assert.assertNotNull(horizontalAlignment40);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(textBlockAnchor42);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 0.95f + "'", float44 == 0.95f);
        org.junit.Assert.assertNotNull(textBlockAnchor45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(blockBorder48);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNull(valueAxis52);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        statisticalBarRenderer0.setBaseSeriesVisible(true, true);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        statisticalBarRenderer0.setBaseOutlinePaint((java.awt.Paint) color10, true);
        java.awt.Paint paint13 = statisticalBarRenderer0.getBaseOutlinePaint();
        statisticalBarRenderer0.setSeriesCreateEntities(1, (java.lang.Boolean) false, true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setBackgroundImageAlignment(0);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = statisticalBarRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Shape shape4 = null;
        statisticalBarRenderer0.setSeriesShape(100, shape4);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = statisticalBarRenderer0.getBaseToolTipGenerator();
        java.awt.Paint paint8 = statisticalBarRenderer0.getSeriesOutlinePaint((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot18.setRangeAxisLocation(0, axisLocation24);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        categoryPlot18.setRangeAxis(valueAxis26);
        categoryPlot18.setOutlineVisible(false);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation24);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getTickMarkOutsideLength();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = categoryAxis2.hasListener(eventListener4);
        java.lang.String str6 = categoryAxis2.getLabelURL();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis2.setTickLabelFont((java.lang.Comparable) 0, font8);
        java.awt.Paint paint10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.axis.AxisState axisState12 = new org.jfree.chart.axis.AxisState((double) 0.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge14);
        axisState12.moveCursor(0.0d, rectangleEdge14);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor20 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition21 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor19, textBlockAnchor20);
        float float22 = categoryLabelPosition21.getWidthRatio();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = categoryLabelPosition21.getLabelAnchor();
        boolean boolean24 = horizontalAlignment18.equals((java.lang.Object) categoryLabelPosition21);
        org.jfree.chart.util.VerticalAlignment verticalAlignment25 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement28 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment18, verticalAlignment25, 1.0d, (double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font8, paint10, rectangleEdge14, horizontalAlignment17, verticalAlignment25, rectangleInsets29);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.data.Range range32 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = new org.jfree.chart.block.RectangleConstraint(range32, 1.0d);
        org.jfree.data.Range range35 = rectangleConstraint34.getHeightRange();
        try {
            org.jfree.chart.util.Size2D size2D36 = textTitle30.arrange(graphics2D31, rectangleConstraint34);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(textBlockAnchor20);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.95f + "'", float22 == 0.95f);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(verticalAlignment25);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNull(range35);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        categoryAxis1.setTickLabelsVisible(false);
        java.lang.String str9 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) (-16777216));
        java.awt.Paint paint10 = categoryAxis1.getTickMarkPaint();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        statisticalBarRenderer0.setAutoPopulateSeriesShape(false);
        java.util.EventListener eventListener9 = null;
        boolean boolean10 = statisticalBarRenderer0.hasListener(eventListener9);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape15);
        statisticalBarRenderer11.setSeriesShape((int) (short) 0, shape15);
        java.lang.Object obj18 = statisticalBarRenderer11.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition();
        statisticalBarRenderer11.setBasePositiveItemLabelPosition(itemLabelPosition19);
        statisticalBarRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition19);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = itemLabelPosition19.getItemLabelAnchor();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor23 = itemLabelPosition19.getItemLabelAnchor();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertNotNull(itemLabelAnchor23);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        statisticalBarRenderer0.setAutoPopulateSeriesShape(false);
        java.util.EventListener eventListener9 = null;
        boolean boolean10 = statisticalBarRenderer0.hasListener(eventListener9);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape15);
        statisticalBarRenderer11.setSeriesShape((int) (short) 0, shape15);
        java.lang.Object obj18 = statisticalBarRenderer11.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition();
        statisticalBarRenderer11.setBasePositiveItemLabelPosition(itemLabelPosition19);
        statisticalBarRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition19);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor22 = itemLabelPosition19.getItemLabelAnchor();
        double double23 = itemLabelPosition19.getAngle();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(itemLabelAnchor22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = null;
        textBlock0.draw(graphics2D1, (float) (short) 1, 0.5f, textBlockAnchor4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextBlock textBlock9 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions13 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition16 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor14, textBlockAnchor15);
        float float17 = categoryLabelPosition16.getWidthRatio();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions18 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions13, categoryLabelPosition16);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor20 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition21 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor19, textBlockAnchor20);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions22 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions13, categoryLabelPosition21);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = categoryLabelPosition21.getLabelAnchor();
        textBlock9.draw(graphics2D10, (float) '4', 0.0f, textBlockAnchor23, 0.95f, 0.0f, (double) (byte) 0);
        textBlock0.draw(graphics2D6, (float) ' ', (float) (-1), textBlockAnchor23);
        org.junit.Assert.assertNotNull(categoryLabelPositions13);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(textBlockAnchor15);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.95f + "'", float17 == 0.95f);
        org.junit.Assert.assertNotNull(categoryLabelPositions18);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(textBlockAnchor20);
        org.junit.Assert.assertNotNull(categoryLabelPositions22);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        float float23 = categoryPlot18.getBackgroundAlpha();
        int int24 = categoryPlot18.getWeight();
        java.lang.String str25 = categoryPlot18.getNoDataMessage();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape26);
        statisticalBarRenderer22.setSeriesShape((int) (short) 0, shape26);
        java.lang.Object obj29 = statisticalBarRenderer22.clone();
        java.awt.Paint paint31 = statisticalBarRenderer22.lookupSeriesFillPaint(192);
        categoryPlot18.setRenderer((int) (short) 0, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22, false);
        boolean boolean34 = statisticalBarRenderer22.getAutoPopulateSeriesShape();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation35 = null;
        try {
            statisticalBarRenderer22.addAnnotation(categoryAnnotation35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot18.setRangeAxisLocation(0, axisLocation24);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke30 = categoryAxis29.getTickMarkStroke();
        java.awt.Stroke stroke31 = categoryAxis29.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color27, stroke31);
        java.awt.image.ColorModel colorModel33 = null;
        java.awt.Rectangle rectangle34 = null;
        org.jfree.chart.block.BlockContainer blockContainer35 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = blockContainer35.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame37 = blockContainer35.getFrame();
        double double38 = blockContainer35.getWidth();
        java.awt.geom.Rectangle2D rectangle2D39 = blockContainer35.getBounds();
        java.awt.geom.AffineTransform affineTransform40 = null;
        java.awt.RenderingHints renderingHints41 = null;
        java.awt.PaintContext paintContext42 = color27.createContext(colorModel33, rectangle34, rectangle2D39, affineTransform40, renderingHints41);
        boolean boolean43 = axisLocation24.equals((java.lang.Object) paintContext42);
        org.jfree.chart.plot.PlotOrientation plotOrientation44 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str45 = plotOrientation44.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation24, plotOrientation44);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(blockFrame37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(paintContext42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(plotOrientation44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "PlotOrientation.VERTICAL" + "'", str45.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertNotNull(rectangleEdge46);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.lang.Comparable comparable0 = null;
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        try {
            org.jfree.chart.axis.CategoryTick categoryTick5 = new org.jfree.chart.axis.CategoryTick(comparable0, textBlock1, textBlockAnchor2, textAnchor3, 500.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        org.jfree.chart.renderer.RendererState rendererState4 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo3);
        java.lang.Class<?> wildcardClass5 = rendererState4.getClass();
        java.awt.Color color6 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass7 = color6.getClass();
        java.lang.Object obj8 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ItemLabelAnchor.OUTSIDE1", (java.lang.Class) wildcardClass5, (java.lang.Class) wildcardClass7);
        java.lang.ClassLoader classLoader9 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass5);
        boolean boolean10 = plotRenderingInfo1.equals((java.lang.Object) classLoader9);
        java.util.ResourceBundle.clearCache(classLoader9);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(classLoader9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot18.setRangeAxisLocation(0, axisLocation24);
        int int26 = categoryPlot18.getBackgroundImageAlignment();
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        categoryPlot18.setFixedDomainAxisSpace(axisSpace27);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 15 + "'", int26 == 15);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = null;
        try {
            numberAxis0.setTickUnit(numberTickUnit1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        float float23 = categoryPlot18.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor24 = categoryPlot18.getDomainGridlinePosition();
        categoryPlot18.configureRangeAxes();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity31 = new org.jfree.chart.entity.ChartEntity(shape30);
        statisticalBarRenderer26.setSeriesShape((int) (short) 0, shape30);
        boolean boolean34 = statisticalBarRenderer26.isSeriesItemLabelsVisible((int) (byte) 0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer35 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity40 = new org.jfree.chart.entity.ChartEntity(shape39);
        statisticalBarRenderer35.setSeriesShape((int) (short) 0, shape39);
        java.lang.Object obj42 = statisticalBarRenderer35.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition43 = new org.jfree.chart.labels.ItemLabelPosition();
        statisticalBarRenderer35.setBasePositiveItemLabelPosition(itemLabelPosition43);
        statisticalBarRenderer26.setBaseNegativeItemLabelPosition(itemLabelPosition43);
        categoryPlot18.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer26, false);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertNotNull(categoryAnchor24);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(obj42);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        double[] doubleArray27 = new double[] { (-1L), (short) 10 };
        double[] doubleArray30 = new double[] { (-1L), (short) 10 };
        double[] doubleArray33 = new double[] { (-1L), (short) 10 };
        double[] doubleArray36 = new double[] { (-1L), (short) 10 };
        double[][] doubleArray37 = new double[][] { doubleArray27, doubleArray30, doubleArray33, doubleArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=0,g=255,b=255]", "Size2D[width=0.0, height=10.0]", doubleArray37);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = categoryPlot18.getRendererForDataset(categoryDataset38);
        categoryPlot18.setWeight((int) (short) 1);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNull(categoryItemRenderer39);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        boolean boolean2 = sortOrder0.equals((java.lang.Object) "ChartChangeEventType.GENERAL");
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape8);
        statisticalBarRenderer4.setSeriesShape((int) (short) 0, shape8);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke13 = categoryAxis12.getTickMarkStroke();
        java.awt.Stroke stroke14 = categoryAxis12.getAxisLineStroke();
        java.awt.Color color15 = java.awt.Color.cyan;
        java.lang.String str16 = color15.toString();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "", "", "hi!", shape8, stroke14, (java.awt.Paint) color15);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer18 = legendItem17.getFillPaintTransformer();
        java.lang.String str19 = legendItem17.getURLText();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "java.awt.Color[r=0,g=255,b=255]" + "'", str16.equals("java.awt.Color[r=0,g=255,b=255]"));
        org.junit.Assert.assertNotNull(gradientPaintTransformer18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        org.jfree.chart.renderer.RendererState rendererState3 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo2);
        java.lang.Class<?> wildcardClass4 = rendererState3.getClass();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass6 = color5.getClass();
        java.lang.Object obj7 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ItemLabelAnchor.OUTSIDE1", (java.lang.Class) wildcardClass4, (java.lang.Class) wildcardClass6);
        java.lang.Object obj8 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("AxisLabelEntity: label = ", (java.lang.Class) wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNull(obj8);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        java.awt.Stroke stroke23 = categoryPlot18.getDomainGridlineStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        java.awt.geom.Point2D point2D28 = null;
        categoryPlot18.zoomDomainAxes((double) (short) 0, 0.0d, plotRenderingInfo27, point2D28);
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = plotRenderingInfo27.getSubplotInfo(192);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 192, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        statisticalBarRenderer0.setAutoPopulateSeriesShape(false);
        java.lang.Boolean boolean10 = statisticalBarRenderer0.getSeriesVisible(2);
        boolean boolean12 = statisticalBarRenderer0.isSeriesVisible((int) '#');
        boolean boolean13 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtLeft();
        java.util.List list2 = axisCollection0.getAxesAtRight();
        java.util.List list3 = axisCollection0.getAxesAtLeft();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String[] strArray2 = jFreeChartResources0.getStringArray("RectangleEdge.TOP");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key RectangleEdge.TOP");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        java.lang.Object obj6 = categoryAxis1.clone();
        java.awt.Font font8 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 1.0d);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset9 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset9);
        defaultStatisticalCategoryDataset9.validateObject();
        int int12 = defaultStatisticalCategoryDataset9.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        int int15 = categoryAxis14.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape21);
        statisticalBarRenderer17.setSeriesShape((int) (short) 0, shape21);
        statisticalBarRenderer17.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset9, categoryAxis14, valueAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer17);
        categoryPlot27.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener30 = null;
        categoryPlot27.addChangeListener(plotChangeListener30);
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot27.setRangeAxisLocation(0, axisLocation33);
        categoryPlot27.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double39 = rectangleInsets37.calculateTopInset((-1.0d));
        double double41 = rectangleInsets37.calculateBottomOutset((double) 10L);
        categoryPlot27.setInsets(rectangleInsets37, true);
        boolean boolean44 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot27);
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker((double) 2.0f);
        org.jfree.chart.block.BlockContainer blockContainer47 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement48 = blockContainer47.getArrangement();
        boolean boolean49 = valueMarker46.equals((java.lang.Object) arrangement48);
        java.awt.Stroke stroke50 = valueMarker46.getOutlineStroke();
        categoryPlot27.setOutlineStroke(stroke50);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(arrangement48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(stroke50);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        boolean boolean2 = verticalAlignment0.equals((java.lang.Object) '#');
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape26);
        statisticalBarRenderer22.setSeriesShape((int) (short) 0, shape26);
        java.lang.Object obj29 = statisticalBarRenderer22.clone();
        java.awt.Paint paint31 = statisticalBarRenderer22.lookupSeriesFillPaint(192);
        categoryPlot18.setRenderer((int) (short) 0, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22, false);
        boolean boolean34 = categoryPlot18.isDomainZoomable();
        org.jfree.chart.util.Layer layer35 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str36 = layer35.toString();
        java.util.Collection collection37 = categoryPlot18.getRangeMarkers(layer35);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(layer35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Layer.FOREGROUND" + "'", str36.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection37);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        numberAxis0.setUpArrow(shape1);
        java.awt.Shape shape3 = numberAxis0.getLeftArrow();
        numberAxis0.setUpperBound(0.0d);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesItemLabelPaint(0, (java.awt.Paint) color9, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer12.getAutoPopulateSeriesStroke();
        statisticalBarRenderer12.setIncludeBaseInRange(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        statisticalBarRenderer12.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition17);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = statisticalBarRenderer12.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = statisticalBarRenderer0.getNegativeItemLabelPositionFallback();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean23 = statisticalBarRenderer22.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = statisticalBarRenderer22.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint26 = statisticalBarRenderer22.lookupSeriesOutlinePaint((int) (short) 0);
        statisticalBarRenderer0.setBaseFillPaint(paint26);
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker((double) 2.0f);
        org.jfree.chart.text.TextAnchor textAnchor30 = valueMarker29.getLabelTextAnchor();
        java.awt.Stroke stroke31 = valueMarker29.getStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke31, true);
        statisticalBarRenderer0.setMinimumBarLength((double) (-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator19);
        org.junit.Assert.assertNull(itemLabelPosition21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape26);
        statisticalBarRenderer22.setSeriesShape((int) (short) 0, shape26);
        java.lang.Object obj29 = statisticalBarRenderer22.clone();
        java.awt.Paint paint31 = statisticalBarRenderer22.lookupSeriesFillPaint(192);
        categoryPlot18.setRenderer((int) (short) 0, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22, false);
        org.jfree.chart.LegendItemCollection legendItemCollection34 = null;
        categoryPlot18.setFixedLegendItems(legendItemCollection34);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier36 = categoryPlot18.getDrawingSupplier();
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("");
        float float39 = categoryAxis38.getTickMarkOutsideLength();
        java.util.EventListener eventListener40 = null;
        boolean boolean41 = categoryAxis38.hasListener(eventListener40);
        categoryAxis38.setVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = categoryAxis38.getTickLabelInsets();
        categoryAxis38.setCategoryLabelPositionOffset(0);
        int int47 = categoryPlot18.getDomainAxisIndex(categoryAxis38);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(drawingSupplier36);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 2.0f + "'", float39 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
        java.lang.Class<?> wildcardClass2 = rendererState1.getClass();
        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass2);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader3);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(classLoader3);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame2 = blockContainer0.getFrame();
        double double3 = blockContainer0.getWidth();
        double double4 = blockContainer0.getHeight();
        blockContainer0.setHeight((double) 255);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(blockFrame2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getHeightConstraintType();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Comparable comparable5 = null;
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, comparable5);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleConstraint2, (org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset4);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        float float10 = categoryAxis9.getTickMarkOutsideLength();
        categoryAxis9.setCategoryLabelPositionOffset((int) (byte) 0);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape18);
        statisticalBarRenderer14.setSeriesShape((int) (short) 0, shape18);
        statisticalBarRenderer14.setAutoPopulateSeriesShape(false);
        java.util.EventListener eventListener23 = null;
        boolean boolean24 = statisticalBarRenderer14.hasListener(eventListener23);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity(shape29);
        statisticalBarRenderer25.setSeriesShape((int) (short) 0, shape29);
        java.lang.Object obj32 = statisticalBarRenderer25.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = new org.jfree.chart.labels.ItemLabelPosition();
        statisticalBarRenderer25.setBasePositiveItemLabelPosition(itemLabelPosition33);
        statisticalBarRenderer14.setBaseNegativeItemLabelPosition(itemLabelPosition33);
        java.lang.Object obj36 = statisticalBarRenderer14.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, categoryAxis9, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer14);
        boolean boolean38 = categoryPlot37.isRangeZoomable();
        org.jfree.chart.JFreeChart jFreeChart39 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent40 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot37, jFreeChart39);
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        float float23 = categoryPlot18.getBackgroundAlpha();
        int int24 = categoryPlot18.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot18.setFixedRangeAxisSpace(axisSpace25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double29 = rectangleInsets27.calculateTopOutset((double) (-1.0f));
        categoryPlot18.setAxisOffset(rectangleInsets27);
        categoryPlot18.clearRangeMarkers(2);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 2.0d + "'", double29 == 2.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.Block block1 = null;
        org.jfree.chart.util.StrokeList strokeList2 = new org.jfree.chart.util.StrokeList();
        strokeList2.clear();
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        boolean boolean5 = strokeList2.equals((java.lang.Object) textAnchor4);
        centerArrangement0.add(block1, (java.lang.Object) textAnchor4);
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        float float23 = categoryPlot18.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor24 = categoryPlot18.getDomainGridlinePosition();
        java.awt.Stroke stroke25 = categoryPlot18.getOutlineStroke();
        float float26 = categoryPlot18.getBackgroundAlpha();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertNotNull(categoryAnchor24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getTickMarkOutsideLength();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = categoryAxis2.hasListener(eventListener4);
        java.lang.String str6 = categoryAxis2.getLabelURL();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis2.setTickLabelFont((java.lang.Comparable) 0, font8);
        java.awt.Paint paint10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.axis.AxisState axisState12 = new org.jfree.chart.axis.AxisState((double) 0.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge14);
        axisState12.moveCursor(0.0d, rectangleEdge14);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor20 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition21 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor19, textBlockAnchor20);
        float float22 = categoryLabelPosition21.getWidthRatio();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = categoryLabelPosition21.getLabelAnchor();
        boolean boolean24 = horizontalAlignment18.equals((java.lang.Object) categoryLabelPosition21);
        org.jfree.chart.util.VerticalAlignment verticalAlignment25 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement28 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment18, verticalAlignment25, 1.0d, (double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font8, paint10, rectangleEdge14, horizontalAlignment17, verticalAlignment25, rectangleInsets29);
        java.awt.Font font31 = textTitle30.getFont();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent32 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle30);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke36 = categoryAxis35.getTickMarkStroke();
        categoryAxis35.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        java.lang.Object obj40 = categoryAxis35.clone();
        java.awt.Font font42 = categoryAxis35.getTickLabelFont((java.lang.Comparable) 1.0d);
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder48 = new org.jfree.chart.block.BlockBorder((double) 10.0f, (double) 100, 10.0d, (double) 2, (java.awt.Paint) color47);
        org.jfree.chart.text.TextBlock textBlock49 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font42, (java.awt.Paint) color47);
        textTitle30.setFont(font42);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(textBlockAnchor20);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.95f + "'", float22 == 0.95f);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(verticalAlignment25);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(textBlock49);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        java.awt.Stroke stroke7 = categoryAxis5.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color3, stroke7);
        java.awt.image.ColorModel colorModel9 = null;
        java.awt.Rectangle rectangle10 = null;
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = blockContainer11.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame13 = blockContainer11.getFrame();
        double double14 = blockContainer11.getWidth();
        java.awt.geom.Rectangle2D rectangle2D15 = blockContainer11.getBounds();
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color3.createContext(colorModel9, rectangle10, rectangle2D15, affineTransform16, renderingHints17);
        textTitle0.draw(graphics2D1, rectangle2D15);
        java.lang.String str20 = textTitle0.getID();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(blockFrame13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset20 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset20);
        defaultStatisticalCategoryDataset20.validateObject();
        int int23 = defaultStatisticalCategoryDataset20.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        int int26 = categoryAxis25.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer28 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity(shape32);
        statisticalBarRenderer28.setSeriesShape((int) (short) 0, shape32);
        statisticalBarRenderer28.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset20, categoryAxis25, valueAxis27, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer28);
        categoryPlot38.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer42 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape46 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity47 = new org.jfree.chart.entity.ChartEntity(shape46);
        statisticalBarRenderer42.setSeriesShape((int) (short) 0, shape46);
        java.lang.Object obj49 = statisticalBarRenderer42.clone();
        java.awt.Paint paint51 = statisticalBarRenderer42.lookupSeriesFillPaint(192);
        categoryPlot38.setRenderer((int) (short) 0, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer42, false);
        java.awt.Paint paint54 = categoryPlot38.getOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = categoryPlot38.getDomainAxis();
        java.lang.String str56 = categoryPlot38.getPlotType();
        org.jfree.chart.axis.NumberAxis numberAxis57 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean58 = numberAxis57.isInverted();
        boolean boolean59 = numberAxis57.getAutoRangeStickyZero();
        numberAxis57.setLowerMargin(0.0d);
        categoryPlot38.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis57);
        org.jfree.chart.block.BlockContainer blockContainer63 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D64 = blockContainer63.getBounds();
        try {
            statisticalBarRenderer8.drawOutline(graphics2D19, categoryPlot38, rectangle2D64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(obj49);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(categoryAxis55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Category Plot" + "'", str56.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(rectangle2D64);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape8);
        statisticalBarRenderer4.setSeriesShape((int) (short) 0, shape8);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("", "", "", "java.awt.Color[r=0,g=255,b=255]", shape8, (java.awt.Paint) color11);
        java.awt.Shape shape13 = legendItem12.getShape();
        java.lang.String str14 = legendItem12.getDescription();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) 10L, (double) 'a');
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment2, 100.0d, (double) (-16776961));
        java.lang.String str9 = verticalAlignment2.toString();
        boolean boolean11 = verticalAlignment2.equals((java.lang.Object) (byte) -1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "VerticalAlignment.TOP" + "'", str9.equals("VerticalAlignment.TOP"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape5);
        statisticalBarRenderer1.setSeriesShape((int) (short) 0, shape5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = statisticalBarRenderer1.getBasePositiveItemLabelPosition();
        statisticalBarRenderer1.setSeriesItemLabelsVisible((int) (byte) 0, (java.lang.Boolean) true);
        java.awt.Stroke stroke14 = statisticalBarRenderer1.getItemOutlineStroke((int) ' ', 3);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double17 = rectangleInsets15.calculateTopInset((-1.0d));
        double double19 = rectangleInsets15.calculateRightOutset((double) 'a');
        org.jfree.chart.block.LineBorder lineBorder20 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke14, rectangleInsets15);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        float float24 = categoryAxis23.getTickMarkOutsideLength();
        java.util.EventListener eventListener25 = null;
        boolean boolean26 = categoryAxis23.hasListener(eventListener25);
        java.lang.String str27 = categoryAxis23.getLabelURL();
        java.awt.Font font29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis23.setTickLabelFont((java.lang.Comparable) 0, font29);
        java.awt.Paint paint31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.axis.AxisState axisState33 = new org.jfree.chart.axis.AxisState((double) 0.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge35);
        axisState33.moveCursor(0.0d, rectangleEdge35);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment38 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment39 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor41 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition42 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor40, textBlockAnchor41);
        float float43 = categoryLabelPosition42.getWidthRatio();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor44 = categoryLabelPosition42.getLabelAnchor();
        boolean boolean45 = horizontalAlignment39.equals((java.lang.Object) categoryLabelPosition42);
        org.jfree.chart.util.VerticalAlignment verticalAlignment46 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement49 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment39, verticalAlignment46, 1.0d, (double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font29, paint31, rectangleEdge35, horizontalAlignment38, verticalAlignment46, rectangleInsets50);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment52 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment53 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement56 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment52, verticalAlignment53, (double) 10L, (double) 'a');
        org.jfree.chart.block.ColumnArrangement columnArrangement59 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment38, verticalAlignment53, (double) (byte) -1, (double) 100);
        boolean boolean60 = lineBorder20.equals((java.lang.Object) horizontalAlignment38);
        org.jfree.chart.util.RectangleInsets rectangleInsets61 = lineBorder20.getInsets();
        java.awt.Graphics2D graphics2D62 = null;
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        try {
            lineBorder20.draw(graphics2D62, rectangle2D63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 2.0f + "'", float24 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(horizontalAlignment38);
        org.junit.Assert.assertNotNull(horizontalAlignment39);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(textBlockAnchor41);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.95f + "'", float43 == 0.95f);
        org.junit.Assert.assertNotNull(textBlockAnchor44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(verticalAlignment46);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(verticalAlignment53);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(rectangleInsets61);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("LengthConstraintType.NONE", font2, paint3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape13);
        statisticalBarRenderer9.setSeriesShape((int) (short) 0, shape13);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "", "", "java.awt.Color[r=0,g=255,b=255]", shape13, (java.awt.Paint) color16);
        java.text.AttributedString attributedString18 = legendItem17.getAttributedLabel();
        java.awt.Paint paint19 = legendItem17.getLinePaint();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset20 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset20);
        defaultStatisticalCategoryDataset20.validateObject();
        int int23 = defaultStatisticalCategoryDataset20.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        int int26 = categoryAxis25.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer28 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity(shape32);
        statisticalBarRenderer28.setSeriesShape((int) (short) 0, shape32);
        statisticalBarRenderer28.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset20, categoryAxis25, valueAxis27, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer28);
        categoryPlot38.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener41 = null;
        categoryPlot38.addChangeListener(plotChangeListener41);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot38.getRangeAxisEdge(0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment45 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment46 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor48 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition49 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor47, textBlockAnchor48);
        float float50 = categoryLabelPosition49.getWidthRatio();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor51 = categoryLabelPosition49.getLabelAnchor();
        boolean boolean52 = horizontalAlignment46.equals((java.lang.Object) categoryLabelPosition49);
        org.jfree.chart.util.VerticalAlignment verticalAlignment53 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement56 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment46, verticalAlignment53, 1.0d, (double) (-1.0f));
        org.jfree.chart.block.BlockBorder blockBorder57 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = blockBorder57.getInsets();
        org.jfree.chart.title.TextTitle textTitle59 = new org.jfree.chart.title.TextTitle("Layer.FOREGROUND", font2, paint19, rectangleEdge44, horizontalAlignment45, verticalAlignment53, rectangleInsets58);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(attributedString18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertNotNull(horizontalAlignment45);
        org.junit.Assert.assertNotNull(horizontalAlignment46);
        org.junit.Assert.assertNotNull(rectangleAnchor47);
        org.junit.Assert.assertNotNull(textBlockAnchor48);
        org.junit.Assert.assertTrue("'" + float50 + "' != '" + 0.95f + "'", float50 == 0.95f);
        org.junit.Assert.assertNotNull(textBlockAnchor51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(verticalAlignment53);
        org.junit.Assert.assertNotNull(blockBorder57);
        org.junit.Assert.assertNotNull(rectangleInsets58);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        statisticalBarRenderer0.setBaseSeriesVisible(true, true);
        statisticalBarRenderer0.setBase((double) ' ');
        boolean boolean14 = statisticalBarRenderer0.getItemCreateEntity((int) '4', (-16776961));
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesItemLabelPaint(0, (java.awt.Paint) color9, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer12.getAutoPopulateSeriesStroke();
        statisticalBarRenderer12.setIncludeBaseInRange(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        statisticalBarRenderer12.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition17);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = statisticalBarRenderer12.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        statisticalBarRenderer0.setBaseSeriesVisibleInLegend(true, true);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset25 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range26 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset25);
        defaultStatisticalCategoryDataset25.validateObject();
        int int28 = defaultStatisticalCategoryDataset25.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        int int31 = categoryAxis30.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer33 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape37 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity38 = new org.jfree.chart.entity.ChartEntity(shape37);
        statisticalBarRenderer33.setSeriesShape((int) (short) 0, shape37);
        statisticalBarRenderer33.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset25, categoryAxis30, valueAxis32, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer33);
        categoryPlot43.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("");
        float float48 = categoryAxis47.getTickMarkOutsideLength();
        java.util.EventListener eventListener49 = null;
        boolean boolean50 = categoryAxis47.hasListener(eventListener49);
        java.lang.String str51 = categoryAxis47.getLabelURL();
        org.jfree.chart.plot.CategoryMarker categoryMarker52 = null;
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D54 = null;
        java.awt.Color color56 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke59 = categoryAxis58.getTickMarkStroke();
        java.awt.Stroke stroke60 = categoryAxis58.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker61 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color56, stroke60);
        java.awt.image.ColorModel colorModel62 = null;
        java.awt.Rectangle rectangle63 = null;
        org.jfree.chart.block.BlockContainer blockContainer64 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = blockContainer64.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame66 = blockContainer64.getFrame();
        double double67 = blockContainer64.getWidth();
        java.awt.geom.Rectangle2D rectangle2D68 = blockContainer64.getBounds();
        java.awt.geom.AffineTransform affineTransform69 = null;
        java.awt.RenderingHints renderingHints70 = null;
        java.awt.PaintContext paintContext71 = color56.createContext(colorModel62, rectangle63, rectangle2D68, affineTransform69, renderingHints70);
        textTitle53.draw(graphics2D54, rectangle2D68);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor73 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape76 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D68, rectangleAnchor73, (double) 10, (double) '4');
        try {
            statisticalBarRenderer0.drawDomainMarker(graphics2D24, categoryPlot43, categoryAxis47, categoryMarker52, rectangle2D68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator19);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 2.0f + "'", float48 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(rectangleInsets65);
        org.junit.Assert.assertNotNull(blockFrame66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertNotNull(paintContext71);
        org.junit.Assert.assertNotNull(rectangleAnchor73);
        org.junit.Assert.assertNotNull(shape76);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        boolean boolean19 = statisticalBarRenderer8.getAutoPopulateSeriesFillPaint();
        java.awt.Paint paint21 = statisticalBarRenderer8.getSeriesFillPaint(500);
        statisticalBarRenderer8.setItemLabelAnchorOffset((double) (byte) -1);
        statisticalBarRenderer8.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, true);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(paint21);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        statisticalBarRenderer0.setAutoPopulateSeriesShape(false);
        java.util.EventListener eventListener9 = null;
        boolean boolean10 = statisticalBarRenderer0.hasListener(eventListener9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_BLUE;
        statisticalBarRenderer0.setErrorIndicatorPaint((java.awt.Paint) color11);
        boolean boolean13 = statisticalBarRenderer0.getBaseSeriesVisible();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        float float23 = categoryPlot18.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor24 = categoryPlot18.getDomainGridlinePosition();
        java.awt.Image image25 = null;
        categoryPlot18.setBackgroundImage(image25);
        boolean boolean27 = categoryPlot18.isDomainZoomable();
        java.awt.Stroke stroke28 = categoryPlot18.getDomainGridlineStroke();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertNotNull(categoryAnchor24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setVisible(false);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4);
        defaultStatisticalCategoryDataset4.validateObject();
        int int7 = defaultStatisticalCategoryDataset4.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        int int10 = categoryAxis9.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity(shape16);
        statisticalBarRenderer12.setSeriesShape((int) (short) 0, shape16);
        statisticalBarRenderer12.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, categoryAxis9, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer12);
        categoryPlot22.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        categoryPlot22.addChangeListener(plotChangeListener25);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot22.getRangeAxisEdge(0);
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot22);
        org.jfree.data.general.DatasetGroup datasetGroup30 = categoryPlot22.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation32 = categoryPlot22.getDomainAxisLocation(3);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNull(datasetGroup30);
        org.junit.Assert.assertNotNull(axisLocation32);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        java.util.Collection collection24 = categoryPlot18.getDomainMarkers(15, layer22);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot18.getDomainAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        float float29 = categoryAxis28.getTickMarkOutsideLength();
        java.util.EventListener eventListener30 = null;
        boolean boolean31 = categoryAxis28.hasListener(eventListener30);
        java.lang.String str32 = categoryAxis28.getLabelURL();
        java.awt.Font font34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis28.setTickLabelFont((java.lang.Comparable) 0, font34);
        java.awt.Paint paint36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.axis.AxisState axisState38 = new org.jfree.chart.axis.AxisState((double) 0.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge40);
        axisState38.moveCursor(0.0d, rectangleEdge40);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment43 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor46 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition47 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor45, textBlockAnchor46);
        float float48 = categoryLabelPosition47.getWidthRatio();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor49 = categoryLabelPosition47.getLabelAnchor();
        boolean boolean50 = horizontalAlignment44.equals((java.lang.Object) categoryLabelPosition47);
        org.jfree.chart.util.VerticalAlignment verticalAlignment51 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement54 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment44, verticalAlignment51, 1.0d, (double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font34, paint36, rectangleEdge40, horizontalAlignment43, verticalAlignment51, rectangleInsets55);
        boolean boolean57 = rectangleEdge25.equals((java.lang.Object) verticalAlignment51);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 2.0f + "'", float29 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(horizontalAlignment43);
        org.junit.Assert.assertNotNull(horizontalAlignment44);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(textBlockAnchor46);
        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 0.95f + "'", float48 == 0.95f);
        org.junit.Assert.assertNotNull(textBlockAnchor49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(verticalAlignment51);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 0, (double) (byte) 10);
        java.lang.Object obj3 = size2D2.clone();
        java.lang.String str4 = size2D2.toString();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Size2D[width=0.0, height=10.0]" + "'", str4.equals("Size2D[width=0.0, height=10.0]"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 2.0f);
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement3 = blockContainer2.getArrangement();
        boolean boolean4 = valueMarker1.equals((java.lang.Object) arrangement3);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset5 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5);
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5, (java.lang.Comparable) 10L);
        double double9 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset8);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer11 = new org.jfree.chart.title.LegendItemBlockContainer(arrangement3, (org.jfree.data.general.Dataset) pieDataset8, (java.lang.Comparable) '#');
        boolean boolean12 = legendItemBlockContainer11.isEmpty();
        org.junit.Assert.assertNotNull(arrangement3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertEquals((double) number6, Double.NaN, 0);
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape26);
        statisticalBarRenderer22.setSeriesShape((int) (short) 0, shape26);
        java.lang.Object obj29 = statisticalBarRenderer22.clone();
        java.awt.Paint paint31 = statisticalBarRenderer22.lookupSeriesFillPaint(192);
        categoryPlot18.setRenderer((int) (short) 0, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22, false);
        java.awt.Paint paint34 = categoryPlot18.getOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = categoryPlot18.getDomainAxis();
        java.lang.String str36 = categoryPlot18.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset38 = categoryPlot18.getDataset(10);
        org.jfree.chart.axis.ValueAxis valueAxis39 = categoryPlot18.getRangeAxis();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(categoryAxis35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Category Plot" + "'", str36.equals("Category Plot"));
        org.junit.Assert.assertNull(categoryDataset38);
        org.junit.Assert.assertNull(valueAxis39);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        java.awt.Stroke stroke5 = categoryAxis3.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color1, stroke5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = valueMarker6.getLabelAnchor();
        java.awt.Paint paint8 = valueMarker6.getLabelPaint();
        java.awt.Stroke stroke9 = valueMarker6.getStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        float float12 = categoryAxis11.getTickMarkOutsideLength();
        categoryAxis11.setCategoryLabelPositionOffset((int) (byte) 0);
        java.lang.Object obj15 = categoryAxis11.clone();
        java.awt.Paint paint16 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        categoryAxis11.setTickMarkPaint(paint16);
        valueMarker6.setPaint(paint16);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        valueMarker6.setLabelOffset(rectangleInsets19);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(rectangleInsets19);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double3 = rectangleInsets1.calculateTopInset((-1.0d));
        double double5 = rectangleInsets1.calculateBottomOutset((double) 10L);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset6 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset6);
        defaultStatisticalCategoryDataset6.validateObject();
        int int9 = defaultStatisticalCategoryDataset6.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        int int12 = categoryAxis11.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape18);
        statisticalBarRenderer14.setSeriesShape((int) (short) 0, shape18);
        statisticalBarRenderer14.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset6, categoryAxis11, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer14);
        categoryPlot24.setRangeCrosshairLockedOnData(false);
        java.awt.Stroke stroke27 = categoryPlot24.getRangeCrosshairStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = categoryPlot24.getDomainAxis(3);
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot24.setRangeAxisLocation(axisLocation30, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = categoryPlot24.getDomainAxis((int) ' ');
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke42 = categoryAxis41.getTickMarkStroke();
        java.awt.Stroke stroke43 = categoryAxis41.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color39, stroke43);
        java.awt.image.ColorModel colorModel45 = null;
        java.awt.Rectangle rectangle46 = null;
        org.jfree.chart.block.BlockContainer blockContainer47 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = blockContainer47.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame49 = blockContainer47.getFrame();
        double double50 = blockContainer47.getWidth();
        java.awt.geom.Rectangle2D rectangle2D51 = blockContainer47.getBounds();
        java.awt.geom.AffineTransform affineTransform52 = null;
        java.awt.RenderingHints renderingHints53 = null;
        java.awt.PaintContext paintContext54 = color39.createContext(colorModel45, rectangle46, rectangle2D51, affineTransform52, renderingHints53);
        textTitle36.draw(graphics2D37, rectangle2D51);
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge56);
        double double58 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D51, rectangleEdge57);
        categoryPlot24.drawBackgroundImage(graphics2D35, rectangle2D51);
        java.awt.geom.Rectangle2D rectangle2D60 = rectangleInsets1.createOutsetRectangle(rectangle2D51);
        boolean boolean61 = categoryLabelPositions0.equals((java.lang.Object) rectangle2D60);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(categoryAxis29);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNull(categoryAxis34);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(blockFrame49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(paintContext54);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertNotNull(rectangleEdge57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        boolean boolean19 = statisticalBarRenderer8.getAutoPopulateSeriesFillPaint();
        java.awt.Paint paint21 = statisticalBarRenderer8.getSeriesFillPaint(500);
        statisticalBarRenderer8.setItemLabelAnchorOffset((double) (byte) -1);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator26 = statisticalBarRenderer8.getToolTipGenerator(15, 0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer31 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity36 = new org.jfree.chart.entity.ChartEntity(shape35);
        statisticalBarRenderer31.setSeriesShape((int) (short) 0, shape35);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("", "", "", "java.awt.Color[r=0,g=255,b=255]", shape35, (java.awt.Paint) color38);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer40 = legendItem39.getFillPaintTransformer();
        statisticalBarRenderer8.setGradientPaintTransformer(gradientPaintTransformer40);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer42 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean43 = statisticalBarRenderer42.getAutoPopulateSeriesStroke();
        statisticalBarRenderer42.setIncludeBaseInRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke48 = categoryAxis47.getTickMarkStroke();
        statisticalBarRenderer42.setBaseOutlineStroke(stroke48);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer50 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape54 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity55 = new org.jfree.chart.entity.ChartEntity(shape54);
        statisticalBarRenderer50.setSeriesShape((int) (short) 0, shape54);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition57 = statisticalBarRenderer50.getBasePositiveItemLabelPosition();
        java.awt.Paint paint59 = statisticalBarRenderer50.lookupSeriesPaint(0);
        boolean boolean60 = statisticalBarRenderer50.getBaseSeriesVisible();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition63 = statisticalBarRenderer50.getNegativeItemLabelPosition((int) (short) 100, 0);
        statisticalBarRenderer42.setBasePositiveItemLabelPosition(itemLabelPosition63, true);
        statisticalBarRenderer8.setBasePositiveItemLabelPosition(itemLabelPosition63);
        double double67 = statisticalBarRenderer8.getItemLabelAnchorOffset();
        double double68 = statisticalBarRenderer8.getItemLabelAnchorOffset();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNull(categoryToolTipGenerator26);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(gradientPaintTransformer40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(itemLabelPosition57);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition63);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + (-1.0d) + "'", double67 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + (-1.0d) + "'", double68 == (-1.0d));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition5);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = statisticalBarRenderer0.getLegendItemLabelGenerator();
        java.lang.Object obj8 = statisticalBarRenderer0.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        java.lang.Object obj7 = statisticalBarRenderer0.clone();
        java.awt.Stroke stroke8 = statisticalBarRenderer0.getBaseOutlineStroke();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        try {
            statisticalBarRenderer0.addAnnotation(categoryAnnotation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        java.awt.Stroke stroke5 = categoryAxis3.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color1, stroke5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = valueMarker6.getLabelAnchor();
        java.awt.Paint paint8 = valueMarker6.getLabelPaint();
        java.awt.Stroke stroke9 = valueMarker6.getOutlineStroke();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        statisticalBarRenderer0.setAutoPopulateSeriesShape(false);
        java.util.EventListener eventListener9 = null;
        boolean boolean10 = statisticalBarRenderer0.hasListener(eventListener9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_BLUE;
        statisticalBarRenderer0.setErrorIndicatorPaint((java.awt.Paint) color11);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator13);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation15 = null;
        try {
            statisticalBarRenderer0.addAnnotation(categoryAnnotation15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (float) (short) 0);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        int int3 = java.awt.Color.HSBtoRGB((float) (short) 10, (float) 'a', (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ItemLabelAnchor.INSIDE8");
        boolean boolean2 = numberAxis1.getAutoRangeStickyZero();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        org.jfree.chart.renderer.RendererState rendererState3 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo2);
        java.lang.Class<?> wildcardClass4 = rendererState3.getClass();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass6 = color5.getClass();
        java.lang.Object obj7 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ItemLabelAnchor.OUTSIDE1", (java.lang.Class) wildcardClass4, (java.lang.Class) wildcardClass6);
        java.net.URL uRL8 = org.jfree.chart.util.ObjectUtilities.getResource("ClassContext", (java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNull(uRL8);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset8 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset8);
        defaultStatisticalCategoryDataset8.validateObject();
        int int11 = defaultStatisticalCategoryDataset8.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        int int14 = categoryAxis13.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape20);
        statisticalBarRenderer16.setSeriesShape((int) (short) 0, shape20);
        statisticalBarRenderer16.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset8, categoryAxis13, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer16);
        java.awt.Color color27 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass28 = color27.getClass();
        org.jfree.chart.text.TextLine textLine30 = new org.jfree.chart.text.TextLine("");
        boolean boolean32 = textLine30.equals((java.lang.Object) (-1L));
        org.jfree.chart.text.TextFragment textFragment33 = null;
        textLine30.removeFragment(textFragment33);
        boolean boolean35 = color27.equals((java.lang.Object) textLine30);
        int int36 = color27.getBlue();
        categoryPlot26.setOutlinePaint((java.awt.Paint) color27);
        org.jfree.chart.block.BlockBorder blockBorder38 = new org.jfree.chart.block.BlockBorder((double) 255, (double) (byte) -1, 4.0d, (double) (short) 0, (java.awt.Paint) color27);
        org.jfree.chart.block.BlockBorder blockBorder39 = new org.jfree.chart.block.BlockBorder((double) 0.95f, (double) 0.95f, (double) (byte) 0, (double) ' ', (java.awt.Paint) color27);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 192 + "'", int36 == 192);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setFixedDimension((double) 2.0f);
        java.awt.Font font4 = categoryAxis1.getTickLabelFont();
        categoryAxis1.setCategoryMargin((double) (short) 10);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState9 = new org.jfree.chart.axis.AxisState((double) 10);
        axisState9.cursorRight((double) 100.0f);
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke18 = categoryAxis17.getTickMarkStroke();
        java.awt.Stroke stroke19 = categoryAxis17.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color15, stroke19);
        java.awt.image.ColorModel colorModel21 = null;
        java.awt.Rectangle rectangle22 = null;
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = blockContainer23.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame25 = blockContainer23.getFrame();
        double double26 = blockContainer23.getWidth();
        java.awt.geom.Rectangle2D rectangle2D27 = blockContainer23.getBounds();
        java.awt.geom.AffineTransform affineTransform28 = null;
        java.awt.RenderingHints renderingHints29 = null;
        java.awt.PaintContext paintContext30 = color15.createContext(colorModel21, rectangle22, rectangle2D27, affineTransform28, renderingHints29);
        textTitle12.draw(graphics2D13, rectangle2D27);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge32);
        double double34 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D27, rectangleEdge33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge35);
        java.util.List list37 = categoryAxis1.refreshTicks(graphics2D7, axisState9, rectangle2D27, rectangleEdge36);
        categoryAxis1.configure();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 500);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(blockFrame25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(paintContext30);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(list37);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape26);
        statisticalBarRenderer22.setSeriesShape((int) (short) 0, shape26);
        java.lang.Object obj29 = statisticalBarRenderer22.clone();
        java.awt.Paint paint31 = statisticalBarRenderer22.lookupSeriesFillPaint(192);
        categoryPlot18.setRenderer((int) (short) 0, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22, false);
        java.awt.Paint paint34 = categoryPlot18.getOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = categoryPlot18.getDomainAxis();
        java.lang.String str36 = categoryPlot18.getPlotType();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean38 = numberAxis37.isInverted();
        boolean boolean39 = numberAxis37.getAutoRangeStickyZero();
        numberAxis37.setLowerMargin(0.0d);
        categoryPlot18.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis37);
        double double43 = numberAxis37.getUpperBound();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(categoryAxis35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Category Plot" + "'", str36.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.05d + "'", double43 == 1.05d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        java.util.EventListener eventListener3 = null;
        boolean boolean4 = categoryAxis1.hasListener(eventListener3);
        categoryAxis1.setCategoryLabelPositionOffset(100);
        java.awt.Font font8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace10 = color9.getColorSpace();
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("hi!", font8, (java.awt.Paint) color9, 1.0f);
        categoryAxis1.setTickLabelFont(font8);
        categoryAxis1.setTickLabelsVisible(true);
        java.awt.Font font17 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 15);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(colorSpace10);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke5 = categoryAxis4.getTickMarkStroke();
        java.awt.Stroke stroke6 = categoryAxis4.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color2, stroke6);
        java.awt.image.ColorModel colorModel8 = null;
        java.awt.Rectangle rectangle9 = null;
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = blockContainer10.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame12 = blockContainer10.getFrame();
        double double13 = blockContainer10.getWidth();
        java.awt.geom.Rectangle2D rectangle2D14 = blockContainer10.getBounds();
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color2.createContext(colorModel8, rectangle9, rectangle2D14, affineTransform15, renderingHints16);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType18 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets0.createAdjustedRectangle(rectangle2D14, lengthAdjustmentType18, lengthAdjustmentType19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke25 = categoryAxis24.getTickMarkStroke();
        java.awt.Stroke stroke26 = categoryAxis24.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color22, stroke26);
        valueMarker27.setValue((double) 192);
        java.awt.Stroke stroke30 = valueMarker27.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = valueMarker27.getLabelOffset();
        boolean boolean32 = lengthAdjustmentType18.equals((java.lang.Object) rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(blockFrame12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(lengthAdjustmentType18);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        categoryAxis1.setTickLabelsVisible(false);
        java.lang.String str9 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) (-16777216));
        categoryAxis1.setTickMarksVisible(true);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape8);
        statisticalBarRenderer4.setSeriesShape((int) (short) 0, shape8);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("", "", "", "java.awt.Color[r=0,g=255,b=255]", shape8, (java.awt.Paint) color11);
        java.awt.Shape shape13 = legendItem12.getShape();
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.clone(shape13);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getTickMarkOutsideLength();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = categoryAxis2.hasListener(eventListener4);
        java.lang.String str6 = categoryAxis2.getLabelURL();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis2.setTickLabelFont((java.lang.Comparable) 0, font8);
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE12", font8);
        java.awt.Paint paint11 = labelBlock10.getPaint();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("VerticalAlignment.CENTER", "java.awt.Color[r=64,g=64,b=64]", "NOID", "Layer.FOREGROUND", "Layer.FOREGROUND");
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setTickLabelsVisible(false);
        categoryAxis1.setVisible(false);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition5);
        statisticalBarRenderer0.setSeriesVisibleInLegend((int) (byte) 10, (java.lang.Boolean) true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setRange(0.0d, Double.NaN);
        org.jfree.data.Range range4 = null;
        try {
            numberAxis0.setRange(range4, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        java.awt.Stroke stroke21 = categoryPlot18.getRangeCrosshairStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot18.getDomainAxis(3);
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot18.setRangeAxisLocation(axisLocation24, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = categoryPlot18.getDomainAxis((int) ' ');
        org.jfree.chart.axis.CategoryAnchor categoryAnchor29 = categoryPlot18.getDomainGridlinePosition();
        boolean boolean30 = categoryPlot18.isSubplot();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNull(categoryAxis28);
        org.junit.Assert.assertNotNull(categoryAnchor29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.configureRangeAxes();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setRange(0.0d, Double.NaN);
        org.jfree.data.Range range24 = categoryPlot18.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis20);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(range24);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot18.getRangeAxisEdge(0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        categoryPlot18.removeChangeListener(plotChangeListener25);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer27 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean28 = statisticalBarRenderer27.getAutoPopulateSeriesStroke();
        statisticalBarRenderer27.setIncludeBaseInRange(false);
        java.awt.Shape shape32 = statisticalBarRenderer27.lookupSeriesShape((int) (byte) 10);
        categoryPlot18.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer27);
        java.awt.Stroke stroke34 = statisticalBarRenderer27.getErrorIndicatorStroke();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        java.awt.Color color1 = java.awt.Color.BLUE;
        int int2 = color1.getRGB();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke7 = categoryAxis6.getTickMarkStroke();
        java.awt.Stroke stroke8 = categoryAxis6.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color4, stroke8);
        valueMarker9.setValue((double) 192);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        valueMarker9.setOutlineStroke(stroke12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke17 = categoryAxis16.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (short) 100, (java.awt.Paint) color1, stroke12, (java.awt.Paint) color14, stroke17, (float) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = valueMarker19.getLabelAnchor();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16776961) + "'", int2 == (-16776961));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        numberAxis0.setUpArrow(shape1);
        java.awt.Shape shape3 = numberAxis0.getLeftArrow();
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape3, "VerticalAlignment.CENTER", "Layer.FOREGROUND");
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        statisticalBarRenderer0.setSeriesItemLabelsVisible((int) (byte) 0, (java.lang.Boolean) true);
        java.awt.Paint paint12 = statisticalBarRenderer0.getSeriesFillPaint((int) '4');
        java.awt.Paint paint15 = statisticalBarRenderer0.getItemFillPaint((int) (short) -1, (-1));
        java.awt.Paint paint17 = statisticalBarRenderer0.getSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint19 = statisticalBarRenderer0.getSeriesFillPaint((int) '#');
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNull(paint19);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot18.getRangeAxisEdge(0);
        categoryPlot18.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis27 = categoryPlot18.getRangeAxis();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = categoryPlot18.getDrawingSupplier();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(drawingSupplier28);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesItemLabelPaint(0, (java.awt.Paint) color9, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer12.getAutoPopulateSeriesStroke();
        statisticalBarRenderer12.setIncludeBaseInRange(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        statisticalBarRenderer12.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition17);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = statisticalBarRenderer12.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = statisticalBarRenderer0.getNegativeItemLabelPositionFallback();
        java.awt.Paint paint23 = statisticalBarRenderer0.lookupSeriesFillPaint(255);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator19);
        org.junit.Assert.assertNull(itemLabelPosition21);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor3);
        float float5 = categoryLabelPosition4.getWidthRatio();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = categoryLabelPosition4.getLabelAnchor();
        boolean boolean7 = horizontalAlignment1.equals((java.lang.Object) categoryLabelPosition4);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition4);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.95f + "'", float5 == 0.95f);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) 10L);
        org.jfree.data.Range range5 = defaultStatisticalCategoryDataset0.getRangeBounds(true);
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = statisticalBarRenderer0.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint6 = categoryAxis4.getTickLabelPaint((java.lang.Comparable) "hi!");
        double double7 = categoryAxis4.getLowerMargin();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset8 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset8);
        defaultStatisticalCategoryDataset8.validateObject();
        int int11 = defaultStatisticalCategoryDataset8.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        int int14 = categoryAxis13.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape20);
        statisticalBarRenderer16.setSeriesShape((int) (short) 0, shape20);
        statisticalBarRenderer16.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset8, categoryAxis13, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer16);
        categoryPlot26.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener29 = null;
        categoryPlot26.addChangeListener(plotChangeListener29);
        float float31 = categoryPlot26.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor32 = categoryPlot26.getDomainGridlinePosition();
        java.awt.Stroke stroke33 = categoryPlot26.getOutlineStroke();
        categoryAxis4.setAxisLineStroke(stroke33);
        statisticalBarRenderer0.setSeriesStroke((int) (short) 10, stroke33, true);
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 1.0f + "'", float31 == 1.0f);
        org.junit.Assert.assertNotNull(categoryAnchor32);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.awt.Font font2 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("ItemLabelAnchor.INSIDE12", font2);
        java.awt.Paint paint4 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font2, paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) 10L, (double) 'a');
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment2, 100.0d, (double) (-16776961));
        columnArrangement8.clear();
        columnArrangement8.clear();
        org.junit.Assert.assertNotNull(verticalAlignment2);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        int int2 = plotRenderingInfo1.getSubplotCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        double double1 = blockContainer0.getContentYOffset();
        double double2 = blockContainer0.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = blockContainer0.getMargin();
        double double5 = rectangleInsets3.calculateTopOutset((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=0,g=255,b=255]", "", "hi!", "");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo9 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=0,g=255,b=255]", "", "hi!", "");
        basicProjectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo9);
        java.awt.Font font12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace14 = color13.getColorSpace();
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("hi!", font12, (java.awt.Paint) color13, 1.0f);
        java.awt.Font font17 = textFragment16.getFont();
        java.lang.String str18 = textFragment16.getText();
        boolean boolean19 = basicProjectInfo9.equals((java.lang.Object) str18);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        java.lang.String str4 = chartEntity3.getURLText();
        java.lang.String str5 = chartEntity3.getShapeType();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "poly" + "'", str5.equals("poly"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        statisticalBarRenderer0.setSeriesItemLabelsVisible((int) (byte) 0, (java.lang.Boolean) true);
        java.awt.Paint paint12 = statisticalBarRenderer0.getSeriesFillPaint((int) '4');
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape21);
        statisticalBarRenderer17.setSeriesShape((int) (short) 0, shape21);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke26 = categoryAxis25.getTickMarkStroke();
        java.awt.Stroke stroke27 = categoryAxis25.getAxisLineStroke();
        java.awt.Color color28 = java.awt.Color.cyan;
        java.lang.String str29 = color28.toString();
        org.jfree.chart.LegendItem legendItem30 = new org.jfree.chart.LegendItem("", "", "", "hi!", shape21, stroke27, (java.awt.Paint) color28);
        java.lang.String str31 = legendItem30.getURLText();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer32 = legendItem30.getFillPaintTransformer();
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer32);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "java.awt.Color[r=0,g=255,b=255]" + "'", str29.equals("java.awt.Color[r=0,g=255,b=255]"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNotNull(gradientPaintTransformer32);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getTickMarkOutsideLength();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = categoryAxis2.hasListener(eventListener4);
        java.lang.String str6 = categoryAxis2.getLabelURL();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis2.setTickLabelFont((java.lang.Comparable) 0, font8);
        java.awt.Paint paint10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.axis.AxisState axisState12 = new org.jfree.chart.axis.AxisState((double) 0.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge14);
        axisState12.moveCursor(0.0d, rectangleEdge14);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor20 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition21 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor19, textBlockAnchor20);
        float float22 = categoryLabelPosition21.getWidthRatio();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = categoryLabelPosition21.getLabelAnchor();
        boolean boolean24 = horizontalAlignment18.equals((java.lang.Object) categoryLabelPosition21);
        org.jfree.chart.util.VerticalAlignment verticalAlignment25 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement28 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment18, verticalAlignment25, 1.0d, (double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font8, paint10, rectangleEdge14, horizontalAlignment17, verticalAlignment25, rectangleInsets29);
        org.jfree.chart.event.TitleChangeListener titleChangeListener31 = null;
        textTitle30.addChangeListener(titleChangeListener31);
        textTitle30.setText("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment35 = textTitle30.getHorizontalAlignment();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(textBlockAnchor20);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.95f + "'", float22 == 0.95f);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(verticalAlignment25);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(horizontalAlignment35);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
        float float3 = categoryLabelPosition2.getWidthRatio();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = categoryLabelPosition2.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType5 = categoryLabelPosition2.getWidthType();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint9 = categoryAxis7.getTickLabelPaint((java.lang.Comparable) "hi!");
        double double10 = categoryAxis7.getLowerMargin();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset11 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset11);
        defaultStatisticalCategoryDataset11.validateObject();
        int int14 = defaultStatisticalCategoryDataset11.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        int int17 = categoryAxis16.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity(shape23);
        statisticalBarRenderer19.setSeriesShape((int) (short) 0, shape23);
        statisticalBarRenderer19.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset11, categoryAxis16, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer19);
        categoryPlot29.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        categoryPlot29.addChangeListener(plotChangeListener32);
        float float34 = categoryPlot29.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor35 = categoryPlot29.getDomainGridlinePosition();
        java.awt.Stroke stroke36 = categoryPlot29.getOutlineStroke();
        categoryAxis7.setAxisLineStroke(stroke36);
        boolean boolean38 = categoryLabelWidthType5.equals((java.lang.Object) stroke36);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.95f + "'", float3 == 0.95f);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(categoryLabelWidthType5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 1.0f + "'", float34 == 1.0f);
        org.junit.Assert.assertNotNull(categoryAnchor35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("RectangleEdge.TOP");
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 0, (double) (byte) 10);
        double double3 = size2D2.height;
        size2D2.height = 4.0d;
        size2D2.width = (short) 100;
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        numberAxis0.setUpArrow(shape1);
        double double3 = numberAxis0.getLowerBound();
        numberAxis0.setPositiveArrowVisible(true);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot18.getRangeAxisEdge(0);
        categoryPlot18.setRangeGridlinesVisible(true);
        java.awt.Paint paint27 = null;
        try {
            categoryPlot18.setDomainGridlinePaint(paint27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        float float23 = categoryPlot18.getBackgroundAlpha();
        java.awt.Image image24 = categoryPlot18.getBackgroundImage();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertNull(image24);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        boolean boolean19 = statisticalBarRenderer8.getAutoPopulateSeriesFillPaint();
        java.awt.Paint paint21 = statisticalBarRenderer8.getSeriesFillPaint(500);
        java.lang.Boolean boolean23 = statisticalBarRenderer8.getSeriesItemLabelsVisible((int) (short) -1);
        java.awt.Shape shape26 = statisticalBarRenderer8.getItemShape((int) ' ', (int) (short) 1);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke32 = categoryAxis31.getTickMarkStroke();
        java.awt.Stroke stroke33 = categoryAxis31.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color29, stroke33);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = valueMarker34.getLabelAnchor();
        java.awt.Shape shape38 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape26, rectangleAnchor35, (double) (-16776961), 0.0d);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNull(boolean23);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertNotNull(shape38);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesItemLabelPaint(0, (java.awt.Paint) color9, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer12.getAutoPopulateSeriesStroke();
        statisticalBarRenderer12.setIncludeBaseInRange(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        statisticalBarRenderer12.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition17);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = statisticalBarRenderer12.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0);
        org.jfree.chart.axis.AxisState axisState23 = new org.jfree.chart.axis.AxisState((double) 0.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge25);
        axisState23.moveCursor(0.0d, rectangleEdge25);
        legendTitle21.setLegendItemGraphicEdge(rectangleEdge25);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.data.Range range31 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = new org.jfree.chart.block.RectangleConstraint((double) (short) 0, range31);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType33 = rectangleConstraint32.getWidthConstraintType();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType34 = rectangleConstraint32.getHeightConstraintType();
        org.jfree.chart.util.Size2D size2D35 = legendTitle21.arrange(graphics2D29, rectangleConstraint32);
        org.jfree.chart.block.BlockContainer blockContainer36 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = blockContainer36.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame38 = blockContainer36.getFrame();
        legendTitle21.setWrapper(blockContainer36);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator19);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(lengthConstraintType33);
        org.junit.Assert.assertNotNull(lengthConstraintType34);
        org.junit.Assert.assertNotNull(size2D35);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(blockFrame38);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        statisticalBarRenderer0.setAutoPopulateSeriesShape(false);
        java.util.EventListener eventListener9 = null;
        boolean boolean10 = statisticalBarRenderer0.hasListener(eventListener9);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape15);
        statisticalBarRenderer11.setSeriesShape((int) (short) 0, shape15);
        java.lang.Object obj18 = statisticalBarRenderer11.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition();
        statisticalBarRenderer11.setBasePositiveItemLabelPosition(itemLabelPosition19);
        statisticalBarRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition19);
        java.lang.Object obj22 = statisticalBarRenderer0.clone();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        try {
            org.jfree.data.Range range24 = statisticalBarRenderer0.findRangeBounds(categoryDataset23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setFixedDimension((double) 2.0f);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4);
        defaultStatisticalCategoryDataset4.validateObject();
        int int7 = defaultStatisticalCategoryDataset4.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        int int10 = categoryAxis9.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity(shape16);
        statisticalBarRenderer12.setSeriesShape((int) (short) 0, shape16);
        statisticalBarRenderer12.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, categoryAxis9, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer12);
        categoryPlot22.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        categoryPlot22.addChangeListener(plotChangeListener25);
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot22.setRangeAxisLocation(0, axisLocation28);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        categoryPlot22.setRangeAxis(valueAxis30);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity37 = new org.jfree.chart.entity.ChartEntity(shape36);
        statisticalBarRenderer32.setSeriesShape((int) (short) 0, shape36);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = statisticalBarRenderer32.getBasePositiveItemLabelPosition();
        statisticalBarRenderer32.setSeriesItemLabelsVisible((int) (byte) 0, (java.lang.Boolean) true);
        java.awt.Paint paint44 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        statisticalBarRenderer32.setSeriesItemLabelPaint(192, paint44);
        categoryPlot22.setRangeGridlinePaint(paint44);
        categoryPlot22.setRangeCrosshairVisible(true);
        boolean boolean49 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot22);
        categoryAxis1.setAxisLineVisible(true);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        java.awt.Stroke stroke7 = categoryAxis5.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color3, stroke7);
        java.awt.image.ColorModel colorModel9 = null;
        java.awt.Rectangle rectangle10 = null;
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = blockContainer11.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame13 = blockContainer11.getFrame();
        double double14 = blockContainer11.getWidth();
        java.awt.geom.Rectangle2D rectangle2D15 = blockContainer11.getBounds();
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color3.createContext(colorModel9, rectangle10, rectangle2D15, affineTransform16, renderingHints17);
        textTitle0.draw(graphics2D1, rectangle2D15);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D15, rectangleAnchor20, (double) 10, (double) '4');
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape23, 0.2d, (float) (byte) 100, (float) (byte) 100);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(blockFrame13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape27);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 0, (double) (byte) 10);
        size2D2.height = (byte) 0;
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke5 = categoryAxis4.getTickMarkStroke();
        categoryAxis4.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        java.lang.Object obj9 = categoryAxis4.clone();
        java.awt.Font font11 = categoryAxis4.getTickLabelFont((java.lang.Comparable) 1.0d);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder((double) 10.0f, (double) 100, 10.0d, (double) 2, (java.awt.Paint) color16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font11, (java.awt.Paint) color16);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity(shape23);
        statisticalBarRenderer19.setSeriesShape((int) (short) 0, shape23);
        statisticalBarRenderer19.setAutoPopulateSeriesShape(false);
        java.util.EventListener eventListener28 = null;
        boolean boolean29 = statisticalBarRenderer19.hasListener(eventListener28);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_BLUE;
        statisticalBarRenderer19.setErrorIndicatorPaint((java.awt.Paint) color30);
        textBlock0.addLine("", font11, (java.awt.Paint) color30);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("");
        float float36 = categoryAxis35.getTickMarkOutsideLength();
        categoryAxis35.setCategoryLabelPositionOffset((int) (byte) 0);
        java.awt.Font font39 = categoryAxis35.getLabelFont();
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint43 = categoryAxis41.getTickLabelPaint((java.lang.Comparable) "hi!");
        textBlock0.addLine("", font39, paint43);
        org.jfree.data.Range range45 = null;
        org.jfree.data.Range range46 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint47 = new org.jfree.chart.block.RectangleConstraint(range45, range46);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType48 = rectangleConstraint47.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint49 = rectangleConstraint47.toUnconstrainedWidth();
        boolean boolean50 = textBlock0.equals((java.lang.Object) rectangleConstraint47);
        java.lang.String str51 = rectangleConstraint47.toString();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 2.0f + "'", float36 == 2.0f);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(lengthConstraintType48);
        org.junit.Assert.assertNotNull(rectangleConstraint49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str51.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setFixedDimension((double) 2.0f);
        float float4 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        int int5 = categoryAxis1.getMaximumCategoryLabelLines();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape11);
        statisticalBarRenderer7.setSeriesShape((int) (short) 0, shape11);
        java.awt.Color color15 = java.awt.Color.PINK;
        statisticalBarRenderer7.setSeriesItemLabelPaint(500, (java.awt.Paint) color15);
        java.awt.Paint paint19 = statisticalBarRenderer7.getItemPaint(0, (int) (short) -1);
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) '4', paint19);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=0,g=255,b=255]", "", "hi!", "");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo9 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=0,g=255,b=255]", "", "hi!", "");
        basicProjectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo9);
        java.lang.String str11 = basicProjectInfo9.getLicenceName();
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        org.jfree.chart.renderer.RendererState rendererState4 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo3);
        java.lang.Class<?> wildcardClass5 = rendererState4.getClass();
        java.awt.Color color6 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass7 = color6.getClass();
        java.lang.Object obj8 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ItemLabelAnchor.OUTSIDE1", (java.lang.Class) wildcardClass5, (java.lang.Class) wildcardClass7);
        java.lang.ClassLoader classLoader9 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass5);
        boolean boolean10 = plotRenderingInfo1.equals((java.lang.Object) classLoader9);
        java.awt.geom.Rectangle2D rectangle2D11 = plotRenderingInfo1.getPlotArea();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset12 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12);
        defaultStatisticalCategoryDataset12.validateObject();
        int int15 = defaultStatisticalCategoryDataset12.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        int int18 = categoryAxis17.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity25 = new org.jfree.chart.entity.ChartEntity(shape24);
        statisticalBarRenderer20.setSeriesShape((int) (short) 0, shape24);
        statisticalBarRenderer20.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12, categoryAxis17, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer20);
        categoryPlot30.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener33 = null;
        categoryPlot30.addChangeListener(plotChangeListener33);
        double[] doubleArray39 = new double[] { (-1L), (short) 10 };
        double[] doubleArray42 = new double[] { (-1L), (short) 10 };
        double[] doubleArray45 = new double[] { (-1L), (short) 10 };
        double[] doubleArray48 = new double[] { (-1L), (short) 10 };
        double[][] doubleArray49 = new double[][] { doubleArray39, doubleArray42, doubleArray45, doubleArray48 };
        org.jfree.data.category.CategoryDataset categoryDataset50 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=0,g=255,b=255]", "Size2D[width=0.0, height=10.0]", doubleArray49);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = categoryPlot30.getRendererForDataset(categoryDataset50);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment52 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor54 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition55 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor53, textBlockAnchor54);
        float float56 = categoryLabelPosition55.getWidthRatio();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor57 = categoryLabelPosition55.getLabelAnchor();
        boolean boolean58 = horizontalAlignment52.equals((java.lang.Object) categoryLabelPosition55);
        boolean boolean59 = categoryPlot30.equals((java.lang.Object) boolean58);
        org.jfree.chart.block.BlockBorder blockBorder60 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets61 = blockBorder60.getInsets();
        categoryPlot30.setInsets(rectangleInsets61);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo64 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo64);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo66 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo66);
        plotRenderingInfo65.addSubplotInfo(plotRenderingInfo67);
        java.awt.geom.Point2D point2D69 = null;
        categoryPlot30.zoomDomainAxes((double) 4, plotRenderingInfo67, point2D69);
        java.lang.Object obj71 = null;
        boolean boolean72 = plotRenderingInfo67.equals(obj71);
        plotRenderingInfo1.addSubplotInfo(plotRenderingInfo67);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(classLoader9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(rectangle2D11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(categoryDataset50);
        org.junit.Assert.assertNull(categoryItemRenderer51);
        org.junit.Assert.assertNotNull(horizontalAlignment52);
        org.junit.Assert.assertNotNull(rectangleAnchor53);
        org.junit.Assert.assertNotNull(textBlockAnchor54);
        org.junit.Assert.assertTrue("'" + float56 + "' != '" + 0.95f + "'", float56 == 0.95f);
        org.junit.Assert.assertNotNull(textBlockAnchor57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(blockBorder60);
        org.junit.Assert.assertNotNull(rectangleInsets61);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.util.StrokeList strokeList7 = new org.jfree.chart.util.StrokeList();
        strokeList7.clear();
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        boolean boolean10 = strokeList7.equals((java.lang.Object) textAnchor9);
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D4, (float) (byte) 0, (float) '#', textAnchor9, 0.2d, (float) (byte) 1, (float) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor16 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition17 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor15, textBlockAnchor16);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = categoryLabelPosition17.getLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor19 = categoryLabelPosition17.getRotationAnchor();
        org.jfree.chart.axis.NumberTick numberTick21 = new org.jfree.chart.axis.NumberTick(tickType0, (double) 0.5f, "{0}", textAnchor9, textAnchor19, (double) (short) 100);
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor26 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition27 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor25, textBlockAnchor26);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor28 = categoryLabelPosition27.getLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor29 = categoryLabelPosition27.getRotationAnchor();
        org.jfree.chart.axis.NumberTick numberTick31 = new org.jfree.chart.axis.NumberTick(tickType0, (double) 255, "RectangleAnchor.TOP_LEFT", textAnchor24, textAnchor29, (double) 4);
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(textBlockAnchor16);
        org.junit.Assert.assertNotNull(textBlockAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(textBlockAnchor26);
        org.junit.Assert.assertNotNull(textBlockAnchor28);
        org.junit.Assert.assertNotNull(textAnchor29);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setTickLabelsVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis1.getTickLabelInsets();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        java.lang.Object obj6 = categoryAxis1.clone();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape9);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis1, shape9, "", "NOID");
        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape9, paint14);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean17 = statisticalBarRenderer16.getAutoPopulateSeriesStroke();
        statisticalBarRenderer16.setIncludeBaseInRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke22 = categoryAxis21.getTickMarkStroke();
        statisticalBarRenderer16.setBaseOutlineStroke(stroke22);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        statisticalBarRenderer16.setSeriesItemLabelPaint(0, (java.awt.Paint) color25, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer28 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean29 = statisticalBarRenderer28.getAutoPopulateSeriesStroke();
        statisticalBarRenderer28.setIncludeBaseInRange(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = null;
        statisticalBarRenderer28.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition33);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator35 = statisticalBarRenderer28.getLegendItemLabelGenerator();
        statisticalBarRenderer16.setLegendItemURLGenerator(categorySeriesLabelGenerator35);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = statisticalBarRenderer16.getNegativeItemLabelPositionFallback();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer38 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean39 = statisticalBarRenderer38.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition40 = statisticalBarRenderer38.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint42 = statisticalBarRenderer38.lookupSeriesOutlinePaint((int) (short) 0);
        statisticalBarRenderer16.setBaseFillPaint(paint42);
        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker((double) 2.0f);
        org.jfree.chart.text.TextAnchor textAnchor46 = valueMarker45.getLabelTextAnchor();
        java.awt.Stroke stroke47 = valueMarker45.getStroke();
        statisticalBarRenderer16.setBaseOutlineStroke(stroke47, true);
        legendGraphic15.setLineStroke(stroke47);
        java.awt.Paint paint51 = legendGraphic15.getFillPaint();
        boolean boolean52 = legendGraphic15.isShapeOutlineVisible();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator35);
        org.junit.Assert.assertNull(itemLabelPosition37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(itemLabelPosition40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("-1,100,-100,100,-100,1,100,1,100,100,1,100,1,-100,100,-100,100,-1,-100,-1,-100,-100,-1,-100,-1,-100");
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        boolean boolean19 = statisticalBarRenderer8.getAutoPopulateSeriesFillPaint();
        java.awt.Paint paint21 = statisticalBarRenderer8.getSeriesFillPaint(500);
        java.lang.Boolean boolean23 = statisticalBarRenderer8.getSeriesItemLabelsVisible((int) (short) -1);
        java.awt.Paint paint25 = statisticalBarRenderer8.lookupSeriesFillPaint(255);
        statisticalBarRenderer8.setAutoPopulateSeriesOutlineStroke(true);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNull(boolean23);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        int int3 = categoryAxis1.getCategoryLabelPositionOffset();
        float float4 = categoryAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Font font2 = null;
        try {
            labelBlock1.setFont(font2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = statisticalBarRenderer0.getLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = statisticalBarRenderer0.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem4 = legendItemCollection2.get((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(legendItemCollection2);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint3 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) "hi!");
        double double4 = categoryAxis1.getFixedDimension();
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace9 = color8.getColorSpace();
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("hi!", font7, (java.awt.Paint) color8, 1.0f);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape20);
        statisticalBarRenderer16.setSeriesShape((int) (short) 0, shape20);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke25 = categoryAxis24.getTickMarkStroke();
        java.awt.Stroke stroke26 = categoryAxis24.getAxisLineStroke();
        java.awt.Color color27 = java.awt.Color.cyan;
        java.lang.String str28 = color27.toString();
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("", "", "", "hi!", shape20, stroke26, (java.awt.Paint) color27);
        java.awt.image.ColorModel colorModel30 = null;
        java.awt.Rectangle rectangle31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        java.awt.geom.AffineTransform affineTransform33 = null;
        java.awt.RenderingHints renderingHints34 = null;
        java.awt.PaintContext paintContext35 = color27.createContext(colorModel30, rectangle31, rectangle2D32, affineTransform33, renderingHints34);
        org.jfree.chart.text.TextBlock textBlock36 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font7, (java.awt.Paint) color27);
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color27);
        categoryAxis1.setCategoryLabelPositionOffset(255);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "java.awt.Color[r=0,g=255,b=255]" + "'", str28.equals("java.awt.Color[r=0,g=255,b=255]"));
        org.junit.Assert.assertNotNull(paintContext35);
        org.junit.Assert.assertNotNull(textBlock36);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        boolean boolean19 = statisticalBarRenderer8.getAutoPopulateSeriesFillPaint();
        statisticalBarRenderer8.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean24 = statisticalBarRenderer23.getAutoPopulateSeriesStroke();
        statisticalBarRenderer23.setIncludeBaseInRange(false);
        java.awt.Shape shape28 = statisticalBarRenderer23.lookupSeriesShape((int) (byte) 10);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean31 = statisticalBarRenderer30.getAutoPopulateSeriesStroke();
        statisticalBarRenderer30.setIncludeBaseInRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke36 = categoryAxis35.getTickMarkStroke();
        statisticalBarRenderer30.setBaseOutlineStroke(stroke36);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer38 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape42 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity43 = new org.jfree.chart.entity.ChartEntity(shape42);
        statisticalBarRenderer38.setSeriesShape((int) (short) 0, shape42);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition45 = statisticalBarRenderer38.getBasePositiveItemLabelPosition();
        java.awt.Paint paint47 = statisticalBarRenderer38.lookupSeriesPaint(0);
        boolean boolean48 = statisticalBarRenderer38.getBaseSeriesVisible();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition51 = statisticalBarRenderer38.getNegativeItemLabelPosition((int) (short) 100, 0);
        statisticalBarRenderer30.setBasePositiveItemLabelPosition(itemLabelPosition51, true);
        statisticalBarRenderer23.setSeriesPositiveItemLabelPosition(10, itemLabelPosition51, true);
        statisticalBarRenderer8.setSeriesNegativeItemLabelPosition((int) (byte) 0, itemLabelPosition51);
        java.awt.Shape shape59 = statisticalBarRenderer8.getItemShape(10, (int) '4');
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(itemLabelPosition45);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition51);
        org.junit.Assert.assertNotNull(shape59);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getHeightConstraintType();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Comparable comparable5 = null;
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, comparable5);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleConstraint2, (org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset4);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        float float10 = categoryAxis9.getTickMarkOutsideLength();
        categoryAxis9.setCategoryLabelPositionOffset((int) (byte) 0);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape18);
        statisticalBarRenderer14.setSeriesShape((int) (short) 0, shape18);
        statisticalBarRenderer14.setAutoPopulateSeriesShape(false);
        java.util.EventListener eventListener23 = null;
        boolean boolean24 = statisticalBarRenderer14.hasListener(eventListener23);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity(shape29);
        statisticalBarRenderer25.setSeriesShape((int) (short) 0, shape29);
        java.lang.Object obj32 = statisticalBarRenderer25.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = new org.jfree.chart.labels.ItemLabelPosition();
        statisticalBarRenderer25.setBasePositiveItemLabelPosition(itemLabelPosition33);
        statisticalBarRenderer14.setBaseNegativeItemLabelPosition(itemLabelPosition33);
        java.lang.Object obj36 = statisticalBarRenderer14.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, categoryAxis9, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer14);
        categoryPlot37.mapDatasetToRangeAxis((int) (byte) 0, (int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot37.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertNotNull(rectangleEdge41);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        numberAxis0.setUpArrow(shape1);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3);
        defaultStatisticalCategoryDataset3.validateObject();
        int int6 = defaultStatisticalCategoryDataset3.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        int int9 = categoryAxis8.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape15);
        statisticalBarRenderer11.setSeriesShape((int) (short) 0, shape15);
        statisticalBarRenderer11.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, categoryAxis8, valueAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer11);
        boolean boolean22 = statisticalBarRenderer11.getAutoPopulateSeriesFillPaint();
        java.awt.Paint paint24 = statisticalBarRenderer11.getSeriesFillPaint(500);
        java.lang.Boolean boolean26 = statisticalBarRenderer11.getSeriesItemLabelsVisible((int) (short) -1);
        java.awt.Shape shape29 = statisticalBarRenderer11.getItemShape((int) ' ', (int) (short) 1);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity(shape29);
        numberAxis0.setRightArrow(shape29);
        org.jfree.data.Range range32 = null;
        try {
            numberAxis0.setRangeWithMargins(range32, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNull(boolean26);
        org.junit.Assert.assertNotNull(shape29);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        java.util.EventListener eventListener3 = null;
        boolean boolean4 = categoryAxis1.hasListener(eventListener3);
        categoryAxis1.setVisible(true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis1);
        org.jfree.chart.axis.Axis axis8 = axisChangeEvent7.getAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        axisChangeEvent7.setChart(jFreeChart9);
        org.jfree.chart.axis.Axis axis11 = axisChangeEvent7.getAxis();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axis8);
        org.junit.Assert.assertNotNull(axis11);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        java.lang.Object obj6 = categoryAxis1.clone();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape9);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis1, shape9, "", "NOID");
        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape9, paint14);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean17 = statisticalBarRenderer16.getAutoPopulateSeriesStroke();
        statisticalBarRenderer16.setIncludeBaseInRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke22 = categoryAxis21.getTickMarkStroke();
        statisticalBarRenderer16.setBaseOutlineStroke(stroke22);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        statisticalBarRenderer16.setSeriesItemLabelPaint(0, (java.awt.Paint) color25, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer28 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean29 = statisticalBarRenderer28.getAutoPopulateSeriesStroke();
        statisticalBarRenderer28.setIncludeBaseInRange(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = null;
        statisticalBarRenderer28.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition33);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator35 = statisticalBarRenderer28.getLegendItemLabelGenerator();
        statisticalBarRenderer16.setLegendItemURLGenerator(categorySeriesLabelGenerator35);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = statisticalBarRenderer16.getNegativeItemLabelPositionFallback();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer38 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean39 = statisticalBarRenderer38.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition40 = statisticalBarRenderer38.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint42 = statisticalBarRenderer38.lookupSeriesOutlinePaint((int) (short) 0);
        statisticalBarRenderer16.setBaseFillPaint(paint42);
        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker((double) 2.0f);
        org.jfree.chart.text.TextAnchor textAnchor46 = valueMarker45.getLabelTextAnchor();
        java.awt.Stroke stroke47 = valueMarker45.getStroke();
        statisticalBarRenderer16.setBaseOutlineStroke(stroke47, true);
        legendGraphic15.setLineStroke(stroke47);
        java.awt.Paint paint51 = legendGraphic15.getFillPaint();
        boolean boolean52 = legendGraphic15.isShapeFilled();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator35);
        org.junit.Assert.assertNull(itemLabelPosition37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(itemLabelPosition40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isInverted();
        boolean boolean2 = numberAxis0.getAutoRangeStickyZero();
        numberAxis0.setLowerMargin(0.0d);
        numberAxis0.setNegativeArrowVisible(true);
        numberAxis0.setInverted(false);
        boolean boolean9 = numberAxis0.isNegativeArrowVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        java.awt.Stroke stroke21 = categoryPlot18.getRangeCrosshairStroke();
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot18.getRangeAxisLocation((-1));
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke26 = categoryAxis25.getTickMarkStroke();
        java.awt.Stroke stroke27 = categoryAxis25.getAxisLineStroke();
        categoryPlot18.setOutlineStroke(stroke27);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateY();
        blockParams0.setGenerateEntities(true);
        blockParams0.setTranslateY((double) 0L);
        blockParams0.setTranslateY(0.05d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        float float23 = categoryPlot18.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor24 = categoryPlot18.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("");
        float float28 = categoryAxis27.getTickMarkOutsideLength();
        java.lang.String str30 = categoryAxis27.getCategoryLabelToolTip((java.lang.Comparable) '4');
        categoryAxis27.setLabel("");
        categoryAxis27.setTickMarkOutsideLength((float) 4);
        categoryPlot18.setDomainAxis((int) '#', categoryAxis27);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot18.getDomainAxisEdge((int) (short) 10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent38 = null;
        categoryPlot18.markerChanged(markerChangeEvent38);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertNotNull(categoryAnchor24);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 2.0f + "'", float28 == 2.0f);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(rectangleEdge37);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        java.lang.Object obj6 = categoryAxis1.clone();
        java.awt.Font font8 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 1.0d);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset9 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset9);
        defaultStatisticalCategoryDataset9.validateObject();
        int int12 = defaultStatisticalCategoryDataset9.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        int int15 = categoryAxis14.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape21);
        statisticalBarRenderer17.setSeriesShape((int) (short) 0, shape21);
        statisticalBarRenderer17.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset9, categoryAxis14, valueAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer17);
        categoryPlot27.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener30 = null;
        categoryPlot27.addChangeListener(plotChangeListener30);
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot27.setRangeAxisLocation(0, axisLocation33);
        categoryPlot27.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double39 = rectangleInsets37.calculateTopInset((-1.0d));
        double double41 = rectangleInsets37.calculateBottomOutset((double) 10L);
        categoryPlot27.setInsets(rectangleInsets37, true);
        boolean boolean44 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot27);
        java.awt.Paint paint46 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) "ItemLabelAnchor.OUTSIDE1");
        java.awt.Paint paint47 = categoryAxis1.getTickMarkPaint();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(paint47);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) 500);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        float float23 = categoryPlot18.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor24 = categoryPlot18.getDomainGridlinePosition();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent25 = null;
        categoryPlot18.rendererChanged(rendererChangeEvent25);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent27 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot18);
        java.awt.Paint paint28 = categoryPlot18.getNoDataMessagePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = categoryPlot18.getAxisOffset();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertNotNull(categoryAnchor24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        float float23 = categoryPlot18.getBackgroundAlpha();
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot18.getDomainMarkers(layer24);
        categoryPlot18.clearAnnotations();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertNull(collection25);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 10);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("poly", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!", font1, (java.awt.Paint) color2, 1.0f);
        float float6 = textFragment5.getBaselineOffset();
        java.awt.Graphics2D graphics2D7 = null;
        try {
            org.jfree.chart.util.Size2D size2D8 = textFragment5.calculateDimensions(graphics2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        strokeList0.clear();
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        boolean boolean3 = strokeList0.equals((java.lang.Object) textAnchor2);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4);
        defaultStatisticalCategoryDataset4.validateObject();
        boolean boolean7 = textAnchor2.equals((java.lang.Object) defaultStatisticalCategoryDataset4);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset8 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset8);
        defaultStatisticalCategoryDataset8.validateObject();
        int int11 = defaultStatisticalCategoryDataset8.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        int int14 = categoryAxis13.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape20);
        statisticalBarRenderer16.setSeriesShape((int) (short) 0, shape20);
        statisticalBarRenderer16.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset8, categoryAxis13, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer16);
        categoryPlot26.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener29 = null;
        categoryPlot26.addChangeListener(plotChangeListener29);
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot26.setRangeAxisLocation(0, axisLocation32);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        categoryPlot26.setRangeAxis(valueAxis34);
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot26);
        boolean boolean37 = defaultStatisticalCategoryDataset4.hasListener((java.util.EventListener) categoryPlot26);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range5 = statisticalBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, (double) (short) 0);
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4);
        int int10 = defaultStatisticalCategoryDataset4.getColumnIndex((java.lang.Comparable) 4.0d);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4);
        java.lang.Number number12 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertEquals((double) number8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.0d + "'", number12.equals(0.0d));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot18.getRangeAxisEdge(0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        categoryPlot18.removeChangeListener(plotChangeListener25);
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot18.setRangeAxisLocation(axisLocation27, true);
        double double30 = categoryPlot18.getRangeCrosshairValue();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        java.util.List list32 = categoryPlot18.getCategoriesForAxis(categoryAxis31);
        boolean boolean33 = categoryPlot18.isDomainZoomable();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesItemLabelPaint(0, (java.awt.Paint) color9, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer12.getAutoPopulateSeriesStroke();
        statisticalBarRenderer12.setIncludeBaseInRange(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        statisticalBarRenderer12.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition17);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = statisticalBarRenderer12.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0);
        org.jfree.chart.axis.AxisState axisState23 = new org.jfree.chart.axis.AxisState((double) 0.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge25);
        axisState23.moveCursor(0.0d, rectangleEdge25);
        legendTitle21.setLegendItemGraphicEdge(rectangleEdge25);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = legendTitle21.getLegendItemGraphicLocation();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator19);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke3 = categoryAxis2.getTickMarkStroke();
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        java.lang.Object obj7 = categoryAxis2.clone();
        java.awt.Font font9 = categoryAxis2.getTickLabelFont((java.lang.Comparable) 1.0d);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) 10.0f, (double) 100, 10.0d, (double) 2, (java.awt.Paint) color14);
        org.jfree.chart.text.TextBlock textBlock16 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font9, (java.awt.Paint) color14);
        org.jfree.chart.text.TextLine textLine17 = textBlock16.getLastLine();
        java.awt.Color color18 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass19 = color18.getClass();
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("");
        boolean boolean23 = textLine21.equals((java.lang.Object) (-1L));
        org.jfree.chart.text.TextFragment textFragment24 = null;
        textLine21.removeFragment(textFragment24);
        boolean boolean26 = color18.equals((java.lang.Object) textLine21);
        textBlock16.addLine(textLine21);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer28 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean29 = statisticalBarRenderer28.getAutoPopulateSeriesStroke();
        statisticalBarRenderer28.setIncludeBaseInRange(false);
        statisticalBarRenderer28.setAutoPopulateSeriesPaint(true);
        java.awt.Stroke stroke34 = statisticalBarRenderer28.getBaseOutlineStroke();
        boolean boolean35 = textLine21.equals((java.lang.Object) statisticalBarRenderer28);
        boolean boolean37 = statisticalBarRenderer28.isSeriesVisibleInLegend(0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(textBlock16);
        org.junit.Assert.assertNotNull(textLine17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setRange(0.0d, Double.NaN);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("", "", "", "java.awt.Color[r=0,g=255,b=255]", shape12, (java.awt.Paint) color15);
        numberAxis0.setRightArrow(shape12);
        org.jfree.data.Range range18 = null;
        try {
            numberAxis0.setRange(range18, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        float float23 = categoryPlot18.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor24 = categoryPlot18.getDomainGridlinePosition();
        java.awt.Stroke stroke25 = categoryPlot18.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = null;
        try {
            categoryPlot18.addDomainMarker(categoryMarker26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertNotNull(categoryAnchor24);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        statisticalBarRenderer0.setSeriesItemLabelsVisible((int) (byte) 0, (java.lang.Boolean) true);
        java.awt.Paint paint12 = statisticalBarRenderer0.getSeriesFillPaint((int) '4');
        java.awt.Paint paint15 = statisticalBarRenderer0.getItemFillPaint((int) (short) -1, (-1));
        java.awt.Paint paint17 = statisticalBarRenderer0.getSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = statisticalBarRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape21 = statisticalBarRenderer0.getItemShape(128, 128);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        statisticalBarRenderer0.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = new org.jfree.chart.labels.ItemLabelPosition();
        double double10 = itemLabelPosition9.getAngle();
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition(192, itemLabelPosition9, false);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset13 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset13);
        defaultStatisticalCategoryDataset13.validateObject();
        int int16 = defaultStatisticalCategoryDataset13.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        int int19 = categoryAxis18.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity26 = new org.jfree.chart.entity.ChartEntity(shape25);
        statisticalBarRenderer21.setSeriesShape((int) (short) 0, shape25);
        statisticalBarRenderer21.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset13, categoryAxis18, valueAxis20, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer21);
        categoryPlot31.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener34 = null;
        categoryPlot31.addChangeListener(plotChangeListener34);
        float float36 = categoryPlot31.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor37 = categoryPlot31.getDomainGridlinePosition();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        categoryPlot31.rendererChanged(rendererChangeEvent38);
        boolean boolean40 = statisticalBarRenderer0.hasListener((java.util.EventListener) categoryPlot31);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 1.0f + "'", float36 == 1.0f);
        org.junit.Assert.assertNotNull(categoryAnchor37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        boolean boolean19 = statisticalBarRenderer8.getAutoPopulateSeriesFillPaint();
        java.awt.Paint paint21 = statisticalBarRenderer8.getSeriesFillPaint(500);
        java.lang.Boolean boolean23 = statisticalBarRenderer8.getSeriesItemLabelsVisible((int) (short) -1);
        java.awt.Paint paint25 = statisticalBarRenderer8.lookupSeriesFillPaint(255);
        java.awt.Font font26 = statisticalBarRenderer8.getBaseItemLabelFont();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNull(boolean23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(font26);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.expand(range0, (double) 128, (double) (-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        java.awt.Stroke stroke21 = categoryPlot18.getRangeCrosshairStroke();
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot18.getRangeAxisLocation((-1));
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = categoryPlot18.getOrientation();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(plotOrientation24);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        double[] doubleArray27 = new double[] { (-1L), (short) 10 };
        double[] doubleArray30 = new double[] { (-1L), (short) 10 };
        double[] doubleArray33 = new double[] { (-1L), (short) 10 };
        double[] doubleArray36 = new double[] { (-1L), (short) 10 };
        double[][] doubleArray37 = new double[][] { doubleArray27, doubleArray30, doubleArray33, doubleArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=0,g=255,b=255]", "Size2D[width=0.0, height=10.0]", doubleArray37);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = categoryPlot18.getRendererForDataset(categoryDataset38);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment40 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor42 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition43 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor41, textBlockAnchor42);
        float float44 = categoryLabelPosition43.getWidthRatio();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor45 = categoryLabelPosition43.getLabelAnchor();
        boolean boolean46 = horizontalAlignment40.equals((java.lang.Object) categoryLabelPosition43);
        boolean boolean47 = categoryPlot18.equals((java.lang.Object) boolean46);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo50 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo50);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        org.jfree.chart.renderer.RendererState rendererState54 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo53);
        java.lang.Class<?> wildcardClass55 = rendererState54.getClass();
        java.awt.Color color56 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass57 = color56.getClass();
        java.lang.Object obj58 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ItemLabelAnchor.OUTSIDE1", (java.lang.Class) wildcardClass55, (java.lang.Class) wildcardClass57);
        java.lang.ClassLoader classLoader59 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass55);
        boolean boolean60 = plotRenderingInfo51.equals((java.lang.Object) classLoader59);
        java.awt.geom.Rectangle2D rectangle2D61 = plotRenderingInfo51.getDataArea();
        java.awt.geom.Point2D point2D62 = null;
        categoryPlot18.zoomDomainAxes((double) (-1.0f), (double) 128, plotRenderingInfo51, point2D62);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNull(categoryItemRenderer39);
        org.junit.Assert.assertNotNull(horizontalAlignment40);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(textBlockAnchor42);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 0.95f + "'", float44 == 0.95f);
        org.junit.Assert.assertNotNull(textBlockAnchor45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNull(obj58);
        org.junit.Assert.assertNotNull(classLoader59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(rectangle2D61);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        float float23 = categoryPlot18.getBackgroundAlpha();
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot18.getDomainMarkers(layer24);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity31 = new org.jfree.chart.entity.ChartEntity(shape30);
        statisticalBarRenderer26.setSeriesShape((int) (short) 0, shape30);
        java.lang.Object obj33 = statisticalBarRenderer26.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = new org.jfree.chart.labels.ItemLabelPosition();
        statisticalBarRenderer26.setBasePositiveItemLabelPosition(itemLabelPosition34);
        int int36 = categoryPlot18.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer26);
        statisticalBarRenderer26.removeAnnotations();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        strokeList0.clear();
        java.awt.Stroke stroke3 = strokeList0.getStroke((int) (byte) 1);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        try {
            strokeList0.setStroke((-16776961), stroke5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        statisticalBarRenderer0.setAutoPopulateSeriesShape(false);
        java.lang.Boolean boolean10 = statisticalBarRenderer0.getSeriesVisible(2);
        java.awt.Paint paint13 = statisticalBarRenderer0.getItemOutlinePaint(1, 192);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("TextAnchor.CENTER_LEFT");
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        java.lang.Object obj6 = categoryAxis1.clone();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape9);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis1, shape9, "", "NOID");
        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape9, paint14);
        java.awt.Paint paint16 = legendGraphic15.getLinePaint();
        java.awt.Shape shape17 = legendGraphic15.getLine();
        java.lang.String str18 = legendGraphic15.getID();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNull(shape17);
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=0,g=255,b=255] version VerticalAlignment.TOP.\nRectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY java.awt.Color[r=0,g=255,b=255]:None\njava.awt.Color[r=0,g=255,b=255] LICENCE TERMS:\n");
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        statisticalBarRenderer8.setBaseSeriesVisibleInLegend(true, false);
        double double22 = statisticalBarRenderer8.getUpperClip();
        java.lang.Boolean boolean24 = statisticalBarRenderer8.getSeriesVisible(0);
        statisticalBarRenderer8.setSeriesItemLabelsVisible((int) (short) 100, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator29 = null;
        statisticalBarRenderer8.setSeriesToolTipGenerator(500, categoryToolTipGenerator29, true);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNull(boolean24);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot18.setRangeAxisLocation(0, axisLocation24);
        categoryPlot18.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double30 = rectangleInsets28.calculateTopInset((-1.0d));
        double double32 = rectangleInsets28.calculateBottomOutset((double) 10L);
        categoryPlot18.setInsets(rectangleInsets28, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        float float38 = categoryAxis37.getTickMarkOutsideLength();
        java.util.EventListener eventListener39 = null;
        boolean boolean40 = categoryAxis37.hasListener(eventListener39);
        java.lang.String str41 = categoryAxis37.getLabelURL();
        java.awt.Font font43 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis37.setTickLabelFont((java.lang.Comparable) 0, font43);
        java.awt.Paint paint45 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.axis.AxisState axisState47 = new org.jfree.chart.axis.AxisState((double) 0.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge49);
        axisState47.moveCursor(0.0d, rectangleEdge49);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment52 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment53 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor55 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition56 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor54, textBlockAnchor55);
        float float57 = categoryLabelPosition56.getWidthRatio();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor58 = categoryLabelPosition56.getLabelAnchor();
        boolean boolean59 = horizontalAlignment53.equals((java.lang.Object) categoryLabelPosition56);
        org.jfree.chart.util.VerticalAlignment verticalAlignment60 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement63 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment53, verticalAlignment60, 1.0d, (double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.title.TextTitle textTitle65 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font43, paint45, rectangleEdge49, horizontalAlignment52, verticalAlignment60, rectangleInsets64);
        categoryPlot18.setAxisOffset(rectangleInsets64);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 2.0f + "'", float38 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertNotNull(horizontalAlignment52);
        org.junit.Assert.assertNotNull(horizontalAlignment53);
        org.junit.Assert.assertNotNull(rectangleAnchor54);
        org.junit.Assert.assertNotNull(textBlockAnchor55);
        org.junit.Assert.assertTrue("'" + float57 + "' != '" + 0.95f + "'", float57 == 0.95f);
        org.junit.Assert.assertNotNull(textBlockAnchor58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(verticalAlignment60);
        org.junit.Assert.assertNotNull(rectangleInsets64);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke3 = categoryAxis2.getTickMarkStroke();
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        java.lang.Object obj7 = categoryAxis2.clone();
        java.awt.Font font9 = categoryAxis2.getTickLabelFont((java.lang.Comparable) 1.0d);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) 10.0f, (double) 100, 10.0d, (double) 2, (java.awt.Paint) color14);
        org.jfree.chart.text.TextBlock textBlock16 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font9, (java.awt.Paint) color14);
        org.jfree.chart.text.TextLine textLine17 = textBlock16.getLastLine();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions21 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition24 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor22, textBlockAnchor23);
        float float25 = categoryLabelPosition24.getWidthRatio();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions26 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions21, categoryLabelPosition24);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor28 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition29 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor27, textBlockAnchor28);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions30 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions21, categoryLabelPosition29);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor31 = categoryLabelPosition29.getLabelAnchor();
        try {
            java.awt.Shape shape35 = textBlock16.calculateBounds(graphics2D18, (float) 0L, (float) (short) 0, textBlockAnchor31, 10.0f, (float) 255, (double) 500);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(textBlock16);
        org.junit.Assert.assertNotNull(textLine17);
        org.junit.Assert.assertNotNull(categoryLabelPositions21);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.95f + "'", float25 == 0.95f);
        org.junit.Assert.assertNotNull(categoryLabelPositions26);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(textBlockAnchor28);
        org.junit.Assert.assertNotNull(categoryLabelPositions30);
        org.junit.Assert.assertNotNull(textBlockAnchor31);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        boolean boolean3 = categoryAxis1.isAxisLineVisible();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        statisticalBarRenderer0.setAutoPopulateSeriesShape(false);
        java.lang.Boolean boolean10 = statisticalBarRenderer0.getSeriesVisible(2);
        boolean boolean12 = statisticalBarRenderer0.isSeriesVisible((int) '#');
        statisticalBarRenderer0.setBaseItemLabelsVisible(true, true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        statisticalBarRenderer0.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false, true);
        statisticalBarRenderer0.setSeriesCreateEntities(15, (java.lang.Boolean) true, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj1 = shapeList0.clone();
        java.awt.Shape shape3 = shapeList0.getShape((int) (byte) 100);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(shape3);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Paint paint9 = statisticalBarRenderer0.lookupSeriesPaint(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType11 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer12 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType11);
        statisticalBarRenderer0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer12);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke16 = categoryAxis15.getTickMarkStroke();
        categoryAxis15.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        java.lang.Object obj20 = categoryAxis15.clone();
        java.awt.Font font22 = categoryAxis15.getTickLabelFont((java.lang.Comparable) 1.0d);
        boolean boolean23 = standardGradientPaintTransformer12.equals((java.lang.Object) font22);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(gradientPaintTransformType11);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot18.setRangeAxisLocation(0, axisLocation24);
        categoryPlot18.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double30 = rectangleInsets28.calculateTopInset((-1.0d));
        double double32 = rectangleInsets28.calculateBottomOutset((double) 10L);
        categoryPlot18.setInsets(rectangleInsets28, true);
        java.lang.String str35 = categoryPlot18.getPlotType();
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str38 = layer37.toString();
        java.util.Collection collection39 = categoryPlot18.getRangeMarkers(100, layer37);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D42 = null;
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke47 = categoryAxis46.getTickMarkStroke();
        java.awt.Stroke stroke48 = categoryAxis46.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker49 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color44, stroke48);
        java.awt.image.ColorModel colorModel50 = null;
        java.awt.Rectangle rectangle51 = null;
        org.jfree.chart.block.BlockContainer blockContainer52 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = blockContainer52.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame54 = blockContainer52.getFrame();
        double double55 = blockContainer52.getWidth();
        java.awt.geom.Rectangle2D rectangle2D56 = blockContainer52.getBounds();
        java.awt.geom.AffineTransform affineTransform57 = null;
        java.awt.RenderingHints renderingHints58 = null;
        java.awt.PaintContext paintContext59 = color44.createContext(colorModel50, rectangle51, rectangle2D56, affineTransform57, renderingHints58);
        textTitle41.draw(graphics2D42, rectangle2D56);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor61 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape64 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D56, rectangleAnchor61, (double) 10, (double) '4');
        java.awt.geom.Point2D point2D65 = null;
        org.jfree.chart.plot.PlotState plotState66 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo67 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo68 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo67);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo70 = null;
        org.jfree.chart.renderer.RendererState rendererState71 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo70);
        java.lang.Class<?> wildcardClass72 = rendererState71.getClass();
        java.awt.Color color73 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass74 = color73.getClass();
        java.lang.Object obj75 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ItemLabelAnchor.OUTSIDE1", (java.lang.Class) wildcardClass72, (java.lang.Class) wildcardClass74);
        java.lang.ClassLoader classLoader76 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass72);
        boolean boolean77 = plotRenderingInfo68.equals((java.lang.Object) classLoader76);
        java.awt.geom.Rectangle2D rectangle2D78 = plotRenderingInfo68.getPlotArea();
        categoryPlot18.draw(graphics2D40, rectangle2D56, point2D65, plotState66, plotRenderingInfo68);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Category Plot" + "'", str35.equals("Category Plot"));
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Layer.FOREGROUND" + "'", str38.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection39);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertNotNull(blockFrame54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(paintContext59);
        org.junit.Assert.assertNotNull(rectangleAnchor61);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertNotNull(color73);
        org.junit.Assert.assertNotNull(wildcardClass74);
        org.junit.Assert.assertNull(obj75);
        org.junit.Assert.assertNotNull(classLoader76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNull(rectangle2D78);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition5);
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass8 = color7.getClass();
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("");
        boolean boolean12 = textLine10.equals((java.lang.Object) (-1L));
        org.jfree.chart.text.TextFragment textFragment13 = null;
        textLine10.removeFragment(textFragment13);
        boolean boolean15 = color7.equals((java.lang.Object) textLine10);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace17 = color16.getColorSpace();
        float[] floatArray24 = new float[] { 'a', 100.0f, 100L, (byte) 10, 0.5f, ' ' };
        float[] floatArray25 = color7.getComponents(colorSpace17, floatArray24);
        statisticalBarRenderer0.setBaseFillPaint((java.awt.Paint) color7, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity37 = new org.jfree.chart.entity.ChartEntity(shape36);
        statisticalBarRenderer32.setSeriesShape((int) (short) 0, shape36);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = statisticalBarRenderer32.getBasePositiveItemLabelPosition();
        java.awt.Paint paint41 = statisticalBarRenderer32.lookupSeriesPaint(0);
        org.jfree.chart.block.BlockBorder blockBorder42 = new org.jfree.chart.block.BlockBorder((double) (short) 1, (double) 192, 0.0d, (double) 500, paint41);
        statisticalBarRenderer0.setBaseFillPaint(paint41);
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(colorSpace17);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        statisticalBarRenderer0.setAutoPopulateSeriesShape(false);
        java.util.EventListener eventListener9 = null;
        boolean boolean10 = statisticalBarRenderer0.hasListener(eventListener9);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape15);
        statisticalBarRenderer11.setSeriesShape((int) (short) 0, shape15);
        java.lang.Object obj18 = statisticalBarRenderer11.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition();
        statisticalBarRenderer11.setBasePositiveItemLabelPosition(itemLabelPosition19);
        statisticalBarRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition19);
        java.awt.Paint paint24 = statisticalBarRenderer0.getItemOutlinePaint(0, (int) (byte) 0);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator25 = null;
        statisticalBarRenderer0.setBaseURLGenerator(categoryURLGenerator25);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder19 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot18.setDatasetRenderingOrder(datasetRenderingOrder19);
        java.lang.String str21 = datasetRenderingOrder19.toString();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(datasetRenderingOrder19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str21.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot18.getRangeAxisEdge(0);
        categoryPlot18.setRangeGridlinesVisible(true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint28 = defaultDrawingSupplier27.getNextPaint();
        java.awt.Stroke stroke29 = defaultDrawingSupplier27.getNextStroke();
        categoryPlot18.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier27);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getTickMarkOutsideLength();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = categoryAxis2.hasListener(eventListener4);
        java.lang.String str6 = categoryAxis2.getLabelURL();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis2.setTickLabelFont((java.lang.Comparable) 0, font8);
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE12", font8);
        labelBlock10.setURLText("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        labelBlock10.setPaint(paint13);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.util.StrokeList strokeList7 = new org.jfree.chart.util.StrokeList();
        strokeList7.clear();
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        boolean boolean10 = strokeList7.equals((java.lang.Object) textAnchor9);
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D4, (float) (byte) 0, (float) '#', textAnchor9, 0.2d, (float) (byte) 1, (float) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor16 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition17 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor15, textBlockAnchor16);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = categoryLabelPosition17.getLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor19 = categoryLabelPosition17.getRotationAnchor();
        org.jfree.chart.axis.NumberTick numberTick21 = new org.jfree.chart.axis.NumberTick(tickType0, (double) 0.5f, "{0}", textAnchor9, textAnchor19, (double) (short) 100);
        org.jfree.chart.ui.Licences licences22 = new org.jfree.chart.ui.Licences();
        java.lang.String str23 = licences22.getLGPL();
        java.lang.String str24 = licences22.getLGPL();
        java.lang.String str25 = licences22.getGPL();
        boolean boolean26 = numberTick21.equals((java.lang.Object) licences22);
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(textBlockAnchor16);
        org.junit.Assert.assertNotNull(textBlockAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot18.setRangeAxisLocation(0, axisLocation24);
        categoryPlot18.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double30 = rectangleInsets28.calculateTopInset((-1.0d));
        double double32 = rectangleInsets28.calculateBottomOutset((double) 10L);
        categoryPlot18.setInsets(rectangleInsets28, true);
        java.lang.String str35 = categoryPlot18.getPlotType();
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str38 = layer37.toString();
        java.util.Collection collection39 = categoryPlot18.getRangeMarkers(100, layer37);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor40 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot18.setDomainGridlinePosition(categoryAnchor40);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Category Plot" + "'", str35.equals("Category Plot"));
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Layer.FOREGROUND" + "'", str38.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection39);
        org.junit.Assert.assertNotNull(categoryAnchor40);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range5 = statisticalBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, (double) (short) 0);
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4);
        int int10 = defaultStatisticalCategoryDataset4.getColumnIndex((java.lang.Comparable) 4.0d);
        java.lang.Number number11 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertEquals((double) number8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.0d + "'", number11.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset13);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke23 = categoryAxis22.getTickMarkStroke();
        java.awt.Stroke stroke24 = categoryAxis22.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color20, stroke24);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = valueMarker25.getLabelAnchor();
        java.awt.Paint paint27 = valueMarker25.getLabelPaint();
        java.awt.Paint paint28 = valueMarker25.getPaint();
        categoryPlot18.setOutlinePaint(paint28);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape34 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity35 = new org.jfree.chart.entity.ChartEntity(shape34);
        statisticalBarRenderer30.setSeriesShape((int) (short) 0, shape34);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke39 = categoryAxis38.getTickMarkStroke();
        statisticalBarRenderer30.setBaseOutlineStroke(stroke39);
        java.awt.Color color41 = java.awt.Color.cyan;
        statisticalBarRenderer30.setErrorIndicatorPaint((java.awt.Paint) color41);
        java.awt.Color color43 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass44 = color43.getClass();
        org.jfree.chart.text.TextLine textLine46 = new org.jfree.chart.text.TextLine("");
        boolean boolean48 = textLine46.equals((java.lang.Object) (-1L));
        org.jfree.chart.text.TextFragment textFragment49 = null;
        textLine46.removeFragment(textFragment49);
        boolean boolean51 = color43.equals((java.lang.Object) textLine46);
        java.awt.Color color52 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace53 = color52.getColorSpace();
        float[] floatArray60 = new float[] { 'a', 100.0f, 100L, (byte) 10, 0.5f, ' ' };
        float[] floatArray61 = color43.getComponents(colorSpace53, floatArray60);
        float[] floatArray62 = color41.getComponents(floatArray60);
        categoryPlot18.setOutlinePaint((java.awt.Paint) color41);
        int int64 = categoryPlot18.getRangeAxisCount();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(colorSpace53);
        org.junit.Assert.assertNotNull(floatArray60);
        org.junit.Assert.assertNotNull(floatArray61);
        org.junit.Assert.assertNotNull(floatArray62);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        java.awt.Stroke stroke5 = categoryAxis3.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color1, stroke5);
        valueMarker6.setValue((double) 192);
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker6.setLabelTextAnchor(textAnchor9);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(textAnchor9);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        boolean boolean2 = shapeList0.equals((java.lang.Object) "ItemLabelAnchor.INSIDE1");
        shapeList0.clear();
        int int4 = shapeList0.size();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot18.setRangeAxisLocation(0, axisLocation24);
        categoryPlot18.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double30 = rectangleInsets28.calculateTopInset((-1.0d));
        double double32 = rectangleInsets28.calculateBottomOutset((double) 10L);
        categoryPlot18.setInsets(rectangleInsets28, true);
        java.lang.String str35 = categoryPlot18.getPlotType();
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str38 = layer37.toString();
        java.util.Collection collection39 = categoryPlot18.getRangeMarkers(100, layer37);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("");
        float float43 = categoryAxis42.getTickMarkOutsideLength();
        categoryAxis42.setCategoryLabelPositionOffset((int) (byte) 0);
        java.lang.Object obj46 = categoryAxis42.clone();
        java.awt.Paint paint47 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        categoryAxis42.setTickMarkPaint(paint47);
        categoryPlot18.setDomainAxis(2, categoryAxis42);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Category Plot" + "'", str35.equals("Category Plot"));
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Layer.FOREGROUND" + "'", str38.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection39);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 2.0f + "'", float43 == 2.0f);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertNotNull(paint47);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        strokeList0.clear();
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        boolean boolean3 = strokeList0.equals((java.lang.Object) textAnchor2);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4);
        defaultStatisticalCategoryDataset4.validateObject();
        boolean boolean7 = textAnchor2.equals((java.lang.Object) defaultStatisticalCategoryDataset4);
        try {
            java.lang.Comparable comparable9 = defaultStatisticalCategoryDataset4.getColumnKey(500);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 500, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        java.util.EventListener eventListener3 = null;
        boolean boolean4 = categoryAxis1.hasListener(eventListener3);
        java.lang.String str5 = categoryAxis1.getLabelURL();
        int int6 = categoryAxis1.getMaximumCategoryLabelLines();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape8);
        statisticalBarRenderer4.setSeriesShape((int) (short) 0, shape8);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("", "", "", "java.awt.Color[r=0,g=255,b=255]", shape8, (java.awt.Paint) color11);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = legendItem12.getFillPaintTransformer();
        java.awt.Paint paint14 = legendItem12.getOutlinePaint();
        int int15 = legendItem12.getSeriesIndex();
        legendItem12.setSeriesIndex(3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        float float23 = categoryPlot18.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor24 = categoryPlot18.getDomainGridlinePosition();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent25 = null;
        categoryPlot18.rendererChanged(rendererChangeEvent25);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent27 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot18);
        java.awt.Paint paint28 = categoryPlot18.getNoDataMessagePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke31 = categoryAxis30.getTickMarkStroke();
        categoryAxis30.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        java.lang.Object obj35 = categoryAxis30.clone();
        java.awt.Shape shape38 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity39 = new org.jfree.chart.entity.ChartEntity(shape38);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity42 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis30, shape38, "", "NOID");
        categoryPlot18.setDomainAxis(categoryAxis30);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertNotNull(categoryAnchor24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNotNull(shape38);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        boolean boolean19 = statisticalBarRenderer8.getAutoPopulateSeriesFillPaint();
        java.awt.Paint paint21 = statisticalBarRenderer8.getSeriesFillPaint(500);
        java.lang.Boolean boolean23 = statisticalBarRenderer8.getSeriesItemLabelsVisible((int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator25 = null;
        statisticalBarRenderer8.setSeriesURLGenerator(4, categoryURLGenerator25, true);
        java.awt.Stroke stroke29 = statisticalBarRenderer8.getSeriesStroke((int) (short) 10);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNull(boolean23);
        org.junit.Assert.assertNull(stroke29);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        categoryAxis1.setTickLabelsVisible(false);
        java.lang.String str9 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) (-16777216));
        java.lang.Object obj10 = categoryAxis1.clone();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("ClassContext");
        java.util.Enumeration<java.lang.String> strEnumeration3 = jFreeChartResources0.getKeys();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(strEnumeration3);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot18.getRangeAxisEdge(0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        categoryPlot18.removeChangeListener(plotChangeListener25);
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot18.setRangeAxisLocation(axisLocation27, true);
        java.util.List list30 = categoryPlot18.getCategories();
        org.jfree.chart.event.PlotChangeListener plotChangeListener31 = null;
        categoryPlot18.addChangeListener(plotChangeListener31);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(list30);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textAnchor0, jFreeChart1);
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getTextAlignment();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        textTitle0.setPaint((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double6 = rectangleInsets4.calculateTopInset((-1.0d));
        double double8 = rectangleInsets4.calculateRightOutset((double) 'a');
        textTitle0.setMargin(rectangleInsets4);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = textTitle0.getPosition();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        statisticalBarRenderer8.setBaseSeriesVisibleInLegend(true, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke25 = categoryAxis24.getTickMarkStroke();
        try {
            statisticalBarRenderer8.setSeriesOutlineStroke((-16776961), stroke25, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        boolean boolean3 = rectangleInsets1.equals((java.lang.Object) color2);
        java.awt.Color color4 = color2.darker();
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.setWidth((double) (byte) -1);
        size2D0.height = 0;
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Font font3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("hi!", font3, (java.awt.Paint) color4, 1.0f);
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("RectangleEdge.BOTTOM", font1, (java.awt.Paint) color4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor9, textBlockAnchor10);
        float float12 = categoryLabelPosition11.getWidthRatio();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = categoryLabelPosition11.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType14 = categoryLabelPosition11.getWidthType();
        boolean boolean15 = labelBlock8.equals((java.lang.Object) categoryLabelWidthType14);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = textTitle16.getPosition();
        boolean boolean18 = labelBlock8.equals((java.lang.Object) textTitle16);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.95f + "'", float12 == 0.95f);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertNotNull(categoryLabelWidthType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        java.awt.Stroke stroke5 = categoryAxis3.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color1, stroke5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = valueMarker6.getLabelAnchor();
        java.awt.Paint paint8 = valueMarker6.getLabelPaint();
        java.awt.Stroke stroke9 = valueMarker6.getStroke();
        java.awt.Stroke stroke10 = valueMarker6.getStroke();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getHeightConstraintType();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Comparable comparable5 = null;
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, comparable5);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleConstraint2, (org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset4);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        float float10 = categoryAxis9.getTickMarkOutsideLength();
        categoryAxis9.setCategoryLabelPositionOffset((int) (byte) 0);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape18);
        statisticalBarRenderer14.setSeriesShape((int) (short) 0, shape18);
        statisticalBarRenderer14.setAutoPopulateSeriesShape(false);
        java.util.EventListener eventListener23 = null;
        boolean boolean24 = statisticalBarRenderer14.hasListener(eventListener23);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity(shape29);
        statisticalBarRenderer25.setSeriesShape((int) (short) 0, shape29);
        java.lang.Object obj32 = statisticalBarRenderer25.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = new org.jfree.chart.labels.ItemLabelPosition();
        statisticalBarRenderer25.setBasePositiveItemLabelPosition(itemLabelPosition33);
        statisticalBarRenderer14.setBaseNegativeItemLabelPosition(itemLabelPosition33);
        java.lang.Object obj36 = statisticalBarRenderer14.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, categoryAxis9, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer14);
        categoryPlot37.mapDatasetToRangeAxis((int) (byte) 0, (int) ' ');
        categoryPlot37.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(obj36);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        java.awt.Color color0 = java.awt.Color.RED;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        categoryAxis1.setCategoryLabelPositionOffset((int) (byte) 0);
        java.lang.Object obj5 = categoryAxis1.clone();
        java.awt.Font font6 = categoryAxis1.getTickLabelFont();
        categoryAxis1.setVisible(true);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        defaultStatisticalCategoryDataset0.addChangeListener(datasetChangeListener3);
        double double6 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.data.Range range8 = defaultStatisticalCategoryDataset0.getRangeBounds(false);
        try {
            java.lang.Number number11 = defaultStatisticalCategoryDataset0.getMeanValue((int) (byte) -1, 500);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        org.jfree.chart.renderer.RendererState rendererState3 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo2);
        java.lang.Class<?> wildcardClass4 = rendererState3.getClass();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass6 = color5.getClass();
        java.lang.Object obj7 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ItemLabelAnchor.OUTSIDE1", (java.lang.Class) wildcardClass4, (java.lang.Class) wildcardClass6);
        java.io.InputStream inputStream8 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ItemLabelAnchor.OUTSIDE1", (java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNull(inputStream8);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape26);
        statisticalBarRenderer22.setSeriesShape((int) (short) 0, shape26);
        java.lang.Object obj29 = statisticalBarRenderer22.clone();
        java.awt.Paint paint31 = statisticalBarRenderer22.lookupSeriesFillPaint(192);
        categoryPlot18.setRenderer((int) (short) 0, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22, false);
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        categoryPlot18.setFixedRangeAxisSpace(axisSpace34);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        categoryPlot18.setRangeAxis(255, valueAxis37);
        categoryPlot18.clearRangeMarkers();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier40 = categoryPlot18.getDrawingSupplier();
        categoryPlot18.clearRangeAxes();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(drawingSupplier40);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        boolean boolean7 = statisticalBarRenderer0.getIncludeBaseInRange();
        java.awt.Color color9 = java.awt.Color.CYAN;
        statisticalBarRenderer0.setSeriesPaint((int) '#', (java.awt.Paint) color9, false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        float float23 = categoryPlot18.getBackgroundAlpha();
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot18.getDomainMarkers(layer24);
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot18.getRangeAxisLocation(0);
        java.lang.String str28 = axisLocation27.toString();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str28.equals("AxisLocation.TOP_OR_LEFT"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=64,g=64,b=64]", font1);
        java.awt.Graphics2D graphics2D3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = textFragment2.calculateDimensions(graphics2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        java.lang.Object obj6 = categoryAxis1.clone();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape9);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis1, shape9, "", "NOID");
        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape9, paint14);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean17 = statisticalBarRenderer16.getAutoPopulateSeriesStroke();
        statisticalBarRenderer16.setIncludeBaseInRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke22 = categoryAxis21.getTickMarkStroke();
        statisticalBarRenderer16.setBaseOutlineStroke(stroke22);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        statisticalBarRenderer16.setSeriesItemLabelPaint(0, (java.awt.Paint) color25, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer28 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean29 = statisticalBarRenderer28.getAutoPopulateSeriesStroke();
        statisticalBarRenderer28.setIncludeBaseInRange(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = null;
        statisticalBarRenderer28.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition33);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator35 = statisticalBarRenderer28.getLegendItemLabelGenerator();
        statisticalBarRenderer16.setLegendItemURLGenerator(categorySeriesLabelGenerator35);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = statisticalBarRenderer16.getNegativeItemLabelPositionFallback();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer38 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean39 = statisticalBarRenderer38.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition40 = statisticalBarRenderer38.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint42 = statisticalBarRenderer38.lookupSeriesOutlinePaint((int) (short) 0);
        statisticalBarRenderer16.setBaseFillPaint(paint42);
        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker((double) 2.0f);
        org.jfree.chart.text.TextAnchor textAnchor46 = valueMarker45.getLabelTextAnchor();
        java.awt.Stroke stroke47 = valueMarker45.getStroke();
        statisticalBarRenderer16.setBaseOutlineStroke(stroke47, true);
        legendGraphic15.setLineStroke(stroke47);
        boolean boolean51 = legendGraphic15.isShapeFilled();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator35);
        org.junit.Assert.assertNull(itemLabelPosition37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(itemLabelPosition40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape26);
        statisticalBarRenderer22.setSeriesShape((int) (short) 0, shape26);
        java.lang.Object obj29 = statisticalBarRenderer22.clone();
        java.awt.Paint paint31 = statisticalBarRenderer22.lookupSeriesFillPaint(192);
        categoryPlot18.setRenderer((int) (short) 0, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22, false);
        java.awt.Paint paint34 = categoryPlot18.getOutlinePaint();
        java.awt.Graphics2D graphics2D35 = null;
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke40 = categoryAxis39.getTickMarkStroke();
        java.awt.Stroke stroke41 = categoryAxis39.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color37, stroke41);
        java.awt.image.ColorModel colorModel43 = null;
        java.awt.Rectangle rectangle44 = null;
        org.jfree.chart.block.BlockContainer blockContainer45 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = blockContainer45.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame47 = blockContainer45.getFrame();
        double double48 = blockContainer45.getWidth();
        java.awt.geom.Rectangle2D rectangle2D49 = blockContainer45.getBounds();
        java.awt.geom.AffineTransform affineTransform50 = null;
        java.awt.RenderingHints renderingHints51 = null;
        java.awt.PaintContext paintContext52 = color37.createContext(colorModel43, rectangle44, rectangle2D49, affineTransform50, renderingHints51);
        try {
            categoryPlot18.drawOutline(graphics2D35, rectangle2D49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(blockFrame47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(paintContext52);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke3 = categoryAxis2.getTickMarkStroke();
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        java.lang.Object obj7 = categoryAxis2.clone();
        java.awt.Font font9 = categoryAxis2.getTickLabelFont((java.lang.Comparable) 1.0d);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) 10.0f, (double) 100, 10.0d, (double) 2, (java.awt.Paint) color14);
        org.jfree.chart.text.TextBlock textBlock16 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font9, (java.awt.Paint) color14);
        org.jfree.chart.text.TextLine textLine17 = textBlock16.getLastLine();
        java.awt.Color color18 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass19 = color18.getClass();
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("");
        boolean boolean23 = textLine21.equals((java.lang.Object) (-1L));
        org.jfree.chart.text.TextFragment textFragment24 = null;
        textLine21.removeFragment(textFragment24);
        boolean boolean26 = color18.equals((java.lang.Object) textLine21);
        textBlock16.addLine(textLine21);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer28 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean29 = statisticalBarRenderer28.getAutoPopulateSeriesStroke();
        statisticalBarRenderer28.setIncludeBaseInRange(false);
        statisticalBarRenderer28.setAutoPopulateSeriesPaint(true);
        java.awt.Stroke stroke34 = statisticalBarRenderer28.getBaseOutlineStroke();
        boolean boolean35 = textLine21.equals((java.lang.Object) statisticalBarRenderer28);
        statisticalBarRenderer28.setBaseSeriesVisibleInLegend(true, true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(textBlock16);
        org.junit.Assert.assertNotNull(textLine17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        java.awt.Font font3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("hi!", font3, (java.awt.Paint) color4, 1.0f);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity(shape16);
        statisticalBarRenderer12.setSeriesShape((int) (short) 0, shape16);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke21 = categoryAxis20.getTickMarkStroke();
        java.awt.Stroke stroke22 = categoryAxis20.getAxisLineStroke();
        java.awt.Color color23 = java.awt.Color.cyan;
        java.lang.String str24 = color23.toString();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "", "", "hi!", shape16, stroke22, (java.awt.Paint) color23);
        java.awt.image.ColorModel colorModel26 = null;
        java.awt.Rectangle rectangle27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.awt.geom.AffineTransform affineTransform29 = null;
        java.awt.RenderingHints renderingHints30 = null;
        java.awt.PaintContext paintContext31 = color23.createContext(colorModel26, rectangle27, rectangle2D28, affineTransform29, renderingHints30);
        org.jfree.chart.text.TextBlock textBlock32 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font3, (java.awt.Paint) color23);
        org.jfree.chart.title.TextTitle textTitle33 = new org.jfree.chart.title.TextTitle("RectangleAnchor.TOP_LEFT", font3);
        textTitle33.setToolTipText("ItemLabelAnchor.INSIDE1");
        java.lang.Object obj36 = textTitle33.clone();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "java.awt.Color[r=0,g=255,b=255]" + "'", str24.equals("java.awt.Color[r=0,g=255,b=255]"));
        org.junit.Assert.assertNotNull(paintContext31);
        org.junit.Assert.assertNotNull(textBlock32);
        org.junit.Assert.assertNotNull(obj36);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame2 = blockContainer0.getFrame();
        double double3 = blockContainer0.getWidth();
        java.awt.geom.Rectangle2D rectangle2D4 = blockContainer0.getBounds();
        boolean boolean5 = blockContainer0.isEmpty();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(blockFrame2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesItemLabelPaint(0, (java.awt.Paint) color9, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer12.getAutoPopulateSeriesStroke();
        statisticalBarRenderer12.setIncludeBaseInRange(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        statisticalBarRenderer12.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition17);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = statisticalBarRenderer12.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke26 = categoryAxis25.getTickMarkStroke();
        java.awt.Stroke stroke27 = categoryAxis25.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color23, stroke27);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = valueMarker28.getLabelAnchor();
        java.awt.Paint paint30 = valueMarker28.getLabelPaint();
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        valueMarker28.setPaint((java.awt.Paint) color31);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker28.setLabelAnchor(rectangleAnchor33);
        legendTitle21.setLegendItemGraphicAnchor(rectangleAnchor33);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator19);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        java.lang.Object obj0 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1);
        defaultStatisticalCategoryDataset1.validateObject();
        int int4 = defaultStatisticalCategoryDataset1.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        int int7 = categoryAxis6.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape13);
        statisticalBarRenderer9.setSeriesShape((int) (short) 0, shape13);
        statisticalBarRenderer9.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1, categoryAxis6, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer9);
        java.util.List list20 = defaultStatisticalCategoryDataset1.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset22 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1, 500);
        org.jfree.data.general.PieDataset pieDataset24 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1, (java.lang.Comparable) "GradientPaintTransformType.CENTER_VERTICAL");
        try {
            org.jfree.data.general.DatasetChangeEvent datasetChangeEvent25 = new org.jfree.data.general.DatasetChangeEvent(obj0, (org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(pieDataset22);
        org.junit.Assert.assertNotNull(pieDataset24);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        java.awt.Stroke stroke21 = categoryPlot18.getRangeCrosshairStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot18.getDomainAxis(3);
        categoryPlot18.clearRangeAxes();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(categoryAxis23);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        java.awt.Stroke stroke7 = categoryAxis5.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color3, stroke7);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = valueMarker8.getLabelAnchor();
        java.awt.Paint paint10 = valueMarker8.getLabelPaint();
        java.awt.Stroke stroke11 = valueMarker8.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 1L, (java.awt.Paint) color1, stroke11);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot18.getRangeAxisEdge(0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        categoryPlot18.removeChangeListener(plotChangeListener25);
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot18.setRangeAxisLocation((int) (short) 0, axisLocation28);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(axisLocation28);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("VerticalAlignment.TOP", "", "Size2D[width=0.0, height=10.0]", "java.awt.Color[r=0,g=255,b=255]");
        java.lang.String str5 = basicProjectInfo4.getName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "VerticalAlignment.TOP" + "'", str5.equals("VerticalAlignment.TOP"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesItemLabelPaint(0, (java.awt.Paint) color9, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer12.getAutoPopulateSeriesStroke();
        statisticalBarRenderer12.setIncludeBaseInRange(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        statisticalBarRenderer12.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition17);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = statisticalBarRenderer12.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0);
        org.jfree.chart.axis.AxisState axisState23 = new org.jfree.chart.axis.AxisState((double) 0.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge25);
        axisState23.moveCursor(0.0d, rectangleEdge25);
        legendTitle21.setLegendItemGraphicEdge(rectangleEdge25);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.data.Range range31 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = new org.jfree.chart.block.RectangleConstraint((double) (short) 0, range31);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType33 = rectangleConstraint32.getWidthConstraintType();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType34 = rectangleConstraint32.getHeightConstraintType();
        org.jfree.chart.util.Size2D size2D35 = legendTitle21.arrange(graphics2D29, rectangleConstraint32);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor37 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition38 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor36, textBlockAnchor37);
        legendTitle21.setLegendItemGraphicLocation(rectangleAnchor36);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge40);
        legendTitle21.setLegendItemGraphicEdge(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator19);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(lengthConstraintType33);
        org.junit.Assert.assertNotNull(lengthConstraintType34);
        org.junit.Assert.assertNotNull(size2D35);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(textBlockAnchor37);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        statisticalBarRenderer0.setSeriesItemLabelsVisible((int) (byte) 0, (java.lang.Boolean) true);
        java.awt.Stroke stroke13 = statisticalBarRenderer0.getItemOutlineStroke((int) ' ', 3);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset14 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number15 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset14);
        java.util.List list16 = defaultStatisticalCategoryDataset14.getColumnKeys();
        org.jfree.data.Range range17 = statisticalBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset14);
        org.jfree.data.general.DatasetGroup datasetGroup18 = new org.jfree.data.general.DatasetGroup();
        java.lang.String str19 = datasetGroup18.getID();
        java.lang.Object obj20 = datasetGroup18.clone();
        defaultStatisticalCategoryDataset14.setGroup(datasetGroup18);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertEquals((double) number15, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "NOID" + "'", str19.equals("NOID"));
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        statisticalBarRenderer0.setAutoPopulateSeriesShape(false);
        java.util.EventListener eventListener9 = null;
        boolean boolean10 = statisticalBarRenderer0.hasListener(eventListener9);
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape26);
        statisticalBarRenderer22.setSeriesShape((int) (short) 0, shape26);
        java.lang.Object obj29 = statisticalBarRenderer22.clone();
        java.awt.Paint paint31 = statisticalBarRenderer22.lookupSeriesFillPaint(192);
        categoryPlot18.setRenderer((int) (short) 0, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22, false);
        java.awt.Paint paint34 = categoryPlot18.getOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = categoryPlot18.getDomainAxis();
        java.lang.String str36 = categoryPlot18.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset38 = categoryPlot18.getDataset(10);
        categoryPlot18.mapDatasetToRangeAxis(192, 255);
        org.jfree.chart.util.SortOrder sortOrder42 = null;
        try {
            categoryPlot18.setRowRenderingOrder(sortOrder42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(categoryAxis35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Category Plot" + "'", str36.equals("Category Plot"));
        org.junit.Assert.assertNull(categoryDataset38);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape8);
        statisticalBarRenderer4.setSeriesShape((int) (short) 0, shape8);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke13 = categoryAxis12.getTickMarkStroke();
        java.awt.Stroke stroke14 = categoryAxis12.getAxisLineStroke();
        java.awt.Color color15 = java.awt.Color.cyan;
        java.lang.String str16 = color15.toString();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "", "", "hi!", shape8, stroke14, (java.awt.Paint) color15);
        legendItem17.setSeriesIndex((int) (byte) -1);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset20 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Comparable comparable21 = null;
        org.jfree.data.general.PieDataset pieDataset22 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset20, comparable21);
        org.jfree.data.general.PieDataset pieDataset26 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset22, (java.lang.Comparable) (short) 0, 97.0d, 0);
        legendItem17.setDataset((org.jfree.data.general.Dataset) pieDataset26);
        org.jfree.data.general.PieDataset pieDataset30 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset26, (java.lang.Comparable) (-16777216), (double) (short) 10);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "java.awt.Color[r=0,g=255,b=255]" + "'", str16.equals("java.awt.Color[r=0,g=255,b=255]"));
        org.junit.Assert.assertNotNull(pieDataset22);
        org.junit.Assert.assertNotNull(pieDataset26);
        org.junit.Assert.assertNotNull(pieDataset30);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.lang.Object obj2 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 10L, (double) 'a');
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset5 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5);
        defaultStatisticalCategoryDataset5.validateObject();
        int int8 = defaultStatisticalCategoryDataset5.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        int int11 = categoryAxis10.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape17);
        statisticalBarRenderer13.setSeriesShape((int) (short) 0, shape17);
        statisticalBarRenderer13.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5, categoryAxis10, valueAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer13);
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass25 = color24.getClass();
        org.jfree.chart.text.TextLine textLine27 = new org.jfree.chart.text.TextLine("");
        boolean boolean29 = textLine27.equals((java.lang.Object) (-1L));
        org.jfree.chart.text.TextFragment textFragment30 = null;
        textLine27.removeFragment(textFragment30);
        boolean boolean32 = color24.equals((java.lang.Object) textLine27);
        int int33 = color24.getBlue();
        categoryPlot23.setOutlinePaint((java.awt.Paint) color24);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment35 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment36 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement39 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment35, verticalAlignment36, (double) 10L, (double) 'a');
        org.jfree.chart.block.BlockContainer blockContainer40 = new org.jfree.chart.block.BlockContainer();
        double double41 = blockContainer40.getContentYOffset();
        double double42 = blockContainer40.getWidth();
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke47 = categoryAxis46.getTickMarkStroke();
        java.awt.Stroke stroke48 = categoryAxis46.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker49 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color44, stroke48);
        flowArrangement39.add((org.jfree.chart.block.Block) blockContainer40, (java.lang.Object) stroke48);
        categoryPlot23.setRangeGridlineStroke(stroke48);
        boolean boolean52 = flowArrangement4.equals((java.lang.Object) categoryPlot23);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment53 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment54 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement57 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment53, verticalAlignment54, (double) 10L, (double) 'a');
        org.jfree.chart.block.BlockContainer blockContainer58 = new org.jfree.chart.block.BlockContainer();
        double double59 = blockContainer58.getContentYOffset();
        double double60 = blockContainer58.getWidth();
        java.awt.Color color62 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke65 = categoryAxis64.getTickMarkStroke();
        java.awt.Stroke stroke66 = categoryAxis64.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker67 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color62, stroke66);
        flowArrangement57.add((org.jfree.chart.block.Block) blockContainer58, (java.lang.Object) stroke66);
        java.awt.Graphics2D graphics2D69 = null;
        org.jfree.data.Range range71 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint72 = new org.jfree.chart.block.RectangleConstraint((double) (-1), range71);
        try {
            org.jfree.chart.util.Size2D size2D73 = flowArrangement4.arrange(blockContainer58, graphics2D69, rectangleConstraint72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 192 + "'", int33 == 192);
        org.junit.Assert.assertNotNull(verticalAlignment36);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(verticalAlignment54);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(stroke66);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 2.0f);
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement3 = blockContainer2.getArrangement();
        boolean boolean4 = valueMarker1.equals((java.lang.Object) arrangement3);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset5 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5);
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5, (java.lang.Comparable) 10L);
        double double9 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset8);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer11 = new org.jfree.chart.title.LegendItemBlockContainer(arrangement3, (org.jfree.data.general.Dataset) pieDataset8, (java.lang.Comparable) '#');
        java.lang.String str12 = legendItemBlockContainer11.getURLText();
        boolean boolean13 = legendItemBlockContainer11.isEmpty();
        org.jfree.data.general.Dataset dataset14 = legendItemBlockContainer11.getDataset();
        org.junit.Assert.assertNotNull(arrangement3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertEquals((double) number6, Double.NaN, 0);
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dataset14);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot18.setRangeAxisLocation(0, axisLocation24);
        int int26 = categoryPlot18.getBackgroundImageAlignment();
        java.lang.String str27 = categoryPlot18.getNoDataMessage();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 15 + "'", int26 == 15);
        org.junit.Assert.assertNull(str27);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.data.Range range0 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1);
        defaultStatisticalCategoryDataset1.validateObject();
        int int4 = defaultStatisticalCategoryDataset1.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        int int7 = categoryAxis6.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape13);
        statisticalBarRenderer9.setSeriesShape((int) (short) 0, shape13);
        statisticalBarRenderer9.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1, categoryAxis6, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer9);
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity28 = new org.jfree.chart.entity.ChartEntity(shape27);
        statisticalBarRenderer23.setSeriesShape((int) (short) 0, shape27);
        java.lang.Object obj30 = statisticalBarRenderer23.clone();
        java.awt.Paint paint32 = statisticalBarRenderer23.lookupSeriesFillPaint(192);
        categoryPlot19.setRenderer((int) (short) 0, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer23, false);
        java.awt.Paint paint35 = categoryPlot19.getOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = categoryPlot19.getDomainAxis();
        java.lang.String str37 = categoryPlot19.getPlotType();
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        int int39 = categoryPlot19.getRangeAxisIndex(valueAxis38);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.data.Range range41 = categoryPlot19.getDataRange(valueAxis40);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = categoryPlot19.getAxisOffset();
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis();
        numberAxis43.setRange(0.0d, Double.NaN);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer51 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape55 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity56 = new org.jfree.chart.entity.ChartEntity(shape55);
        statisticalBarRenderer51.setSeriesShape((int) (short) 0, shape55);
        java.awt.Color color58 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem59 = new org.jfree.chart.LegendItem("", "", "", "java.awt.Color[r=0,g=255,b=255]", shape55, (java.awt.Paint) color58);
        numberAxis43.setRightArrow(shape55);
        int int61 = categoryPlot19.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis43);
        org.jfree.data.Range range62 = numberAxis43.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint63 = new org.jfree.chart.block.RectangleConstraint(range0, range62);
        java.lang.String str64 = range62.toString();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(categoryAxis36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Category Plot" + "'", str37.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(range62);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "Range[0.0,1.0]" + "'", str64.equals("Range[0.0,1.0]"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        java.util.EventListener eventListener3 = null;
        boolean boolean4 = categoryAxis1.hasListener(eventListener3);
        categoryAxis1.setCategoryLabelPositionOffset(100);
        org.jfree.chart.plot.Plot plot7 = categoryAxis1.getPlot();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(plot7);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = shapeList0.getShape((int) (byte) 0);
        java.lang.Object obj3 = null;
        boolean boolean4 = shapeList0.equals(obj3);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset5 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5);
        defaultStatisticalCategoryDataset5.validateObject();
        int int8 = defaultStatisticalCategoryDataset5.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        int int11 = categoryAxis10.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape17);
        statisticalBarRenderer13.setSeriesShape((int) (short) 0, shape17);
        statisticalBarRenderer13.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5, categoryAxis10, valueAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer13);
        categoryPlot23.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        categoryPlot23.addChangeListener(plotChangeListener26);
        float float28 = categoryPlot23.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor29 = categoryPlot23.getDomainGridlinePosition();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        categoryPlot23.rendererChanged(rendererChangeEvent30);
        org.jfree.data.category.CategoryDataset categoryDataset33 = categoryPlot23.getDataset(2);
        boolean boolean34 = shapeList0.equals((java.lang.Object) 2);
        java.lang.Object obj35 = shapeList0.clone();
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 1.0f + "'", float28 == 1.0f);
        org.junit.Assert.assertNotNull(categoryAnchor29);
        org.junit.Assert.assertNull(categoryDataset33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(obj35);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isInverted();
        boolean boolean2 = numberAxis0.getAutoRangeStickyZero();
        numberAxis0.setLowerMargin(0.0d);
        numberAxis0.setNegativeArrowVisible(true);
        numberAxis0.setInverted(false);
        try {
            numberAxis0.setRangeWithMargins((double) '4', (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (52.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        org.jfree.data.Range range4 = defaultStatisticalCategoryDataset0.getRangeBounds(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        float float7 = categoryAxis6.getTickMarkOutsideLength();
        java.lang.String str9 = categoryAxis6.getCategoryLabelToolTip((java.lang.Comparable) '4');
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        numberAxis10.setUpArrow(shape11);
        java.awt.Shape shape13 = numberAxis10.getLeftArrow();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape18);
        statisticalBarRenderer14.setSeriesShape((int) (short) 0, shape18);
        statisticalBarRenderer14.setAutoPopulateSeriesShape(false);
        java.util.EventListener eventListener23 = null;
        boolean boolean24 = statisticalBarRenderer14.hasListener(eventListener23);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer14);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        java.lang.Object obj6 = categoryAxis1.clone();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape9);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis1, shape9, "", "NOID");
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke18 = categoryAxis17.getTickMarkStroke();
        java.awt.Stroke stroke19 = categoryAxis17.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color15, stroke19);
        valueMarker20.setValue((double) 192);
        java.awt.Stroke stroke23 = valueMarker20.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = valueMarker20.getLabelOffset();
        double double26 = rectangleInsets24.calculateBottomInset(10.0d);
        categoryAxis1.setTickLabelInsets(rectangleInsets24);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity4 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment5, verticalAlignment6, (double) 10L, (double) 'a');
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset10 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset10);
        defaultStatisticalCategoryDataset10.validateObject();
        int int13 = defaultStatisticalCategoryDataset10.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("");
        int int16 = categoryAxis15.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity23 = new org.jfree.chart.entity.ChartEntity(shape22);
        statisticalBarRenderer18.setSeriesShape((int) (short) 0, shape22);
        statisticalBarRenderer18.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset10, categoryAxis15, valueAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer18);
        java.awt.Color color29 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass30 = color29.getClass();
        org.jfree.chart.text.TextLine textLine32 = new org.jfree.chart.text.TextLine("");
        boolean boolean34 = textLine32.equals((java.lang.Object) (-1L));
        org.jfree.chart.text.TextFragment textFragment35 = null;
        textLine32.removeFragment(textFragment35);
        boolean boolean37 = color29.equals((java.lang.Object) textLine32);
        int int38 = color29.getBlue();
        categoryPlot28.setOutlinePaint((java.awt.Paint) color29);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment40 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment41 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement44 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment40, verticalAlignment41, (double) 10L, (double) 'a');
        org.jfree.chart.block.BlockContainer blockContainer45 = new org.jfree.chart.block.BlockContainer();
        double double46 = blockContainer45.getContentYOffset();
        double double47 = blockContainer45.getWidth();
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke52 = categoryAxis51.getTickMarkStroke();
        java.awt.Stroke stroke53 = categoryAxis51.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker54 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color49, stroke53);
        flowArrangement44.add((org.jfree.chart.block.Block) blockContainer45, (java.lang.Object) stroke53);
        categoryPlot28.setRangeGridlineStroke(stroke53);
        boolean boolean57 = flowArrangement9.equals((java.lang.Object) categoryPlot28);
        boolean boolean58 = legendItemEntity4.equals((java.lang.Object) flowArrangement9);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 192 + "'", int38 == 192);
        org.junit.Assert.assertNotNull(verticalAlignment41);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesItemLabelPaint(0, (java.awt.Paint) color9, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint15 = categoryAxis13.getTickLabelPaint((java.lang.Comparable) "hi!");
        statisticalBarRenderer0.setBaseFillPaint(paint15, true);
        statisticalBarRenderer0.setItemMargin((double) 500);
        java.awt.Paint paint21 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        statisticalBarRenderer0.setSeriesPaint((int) (byte) 1, paint21);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke25 = categoryAxis24.getTickMarkStroke();
        categoryAxis24.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        java.lang.Object obj29 = categoryAxis24.clone();
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity(shape32);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity36 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis24, shape32, "", "NOID");
        java.awt.Paint paint37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic38 = new org.jfree.chart.title.LegendGraphic(shape32, paint37);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer39 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean40 = statisticalBarRenderer39.getAutoPopulateSeriesStroke();
        statisticalBarRenderer39.setIncludeBaseInRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke45 = categoryAxis44.getTickMarkStroke();
        statisticalBarRenderer39.setBaseOutlineStroke(stroke45);
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        statisticalBarRenderer39.setSeriesItemLabelPaint(0, (java.awt.Paint) color48, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer51 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean52 = statisticalBarRenderer51.getAutoPopulateSeriesStroke();
        statisticalBarRenderer51.setIncludeBaseInRange(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition56 = null;
        statisticalBarRenderer51.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition56);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator58 = statisticalBarRenderer51.getLegendItemLabelGenerator();
        statisticalBarRenderer39.setLegendItemURLGenerator(categorySeriesLabelGenerator58);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition60 = statisticalBarRenderer39.getNegativeItemLabelPositionFallback();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer61 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean62 = statisticalBarRenderer61.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition63 = statisticalBarRenderer61.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint65 = statisticalBarRenderer61.lookupSeriesOutlinePaint((int) (short) 0);
        statisticalBarRenderer39.setBaseFillPaint(paint65);
        org.jfree.chart.plot.ValueMarker valueMarker68 = new org.jfree.chart.plot.ValueMarker((double) 2.0f);
        org.jfree.chart.text.TextAnchor textAnchor69 = valueMarker68.getLabelTextAnchor();
        java.awt.Stroke stroke70 = valueMarker68.getStroke();
        statisticalBarRenderer39.setBaseOutlineStroke(stroke70, true);
        legendGraphic38.setLineStroke(stroke70);
        java.awt.Paint paint74 = legendGraphic38.getFillPaint();
        statisticalBarRenderer0.setBaseFillPaint(paint74, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator58);
        org.junit.Assert.assertNull(itemLabelPosition60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNull(itemLabelPosition63);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(textAnchor69);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(paint74);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getTickMarkOutsideLength();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = categoryAxis2.hasListener(eventListener4);
        java.lang.String str6 = categoryAxis2.getLabelURL();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis2.setTickLabelFont((java.lang.Comparable) 0, font8);
        java.awt.Paint paint10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.axis.AxisState axisState12 = new org.jfree.chart.axis.AxisState((double) 0.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge14);
        axisState12.moveCursor(0.0d, rectangleEdge14);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor20 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition21 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor19, textBlockAnchor20);
        float float22 = categoryLabelPosition21.getWidthRatio();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = categoryLabelPosition21.getLabelAnchor();
        boolean boolean24 = horizontalAlignment18.equals((java.lang.Object) categoryLabelPosition21);
        org.jfree.chart.util.VerticalAlignment verticalAlignment25 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement28 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment18, verticalAlignment25, 1.0d, (double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font8, paint10, rectangleEdge14, horizontalAlignment17, verticalAlignment25, rectangleInsets29);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment31 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment32 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement35 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment31, verticalAlignment32, (double) 10L, (double) 'a');
        org.jfree.chart.block.ColumnArrangement columnArrangement38 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment17, verticalAlignment32, (double) (byte) -1, (double) 100);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset39 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range40 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset39);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer42 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement38, (org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset39, (java.lang.Comparable) "VerticalAlignment.TOP");
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(textBlockAnchor20);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.95f + "'", float22 == 0.95f);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(verticalAlignment25);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(verticalAlignment32);
        org.junit.Assert.assertNull(range40);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        float float4 = categoryAxis3.getTickMarkOutsideLength();
        java.util.EventListener eventListener5 = null;
        boolean boolean6 = categoryAxis3.hasListener(eventListener5);
        java.lang.String str7 = categoryAxis3.getLabelURL();
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis3.setTickLabelFont((java.lang.Comparable) 0, font9);
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("ItemLabelAnchor.INSIDE12", font9);
        labelBlock11.setURLText("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("");
        float float16 = categoryAxis15.getTickMarkOutsideLength();
        categoryAxis15.setCategoryLabelPositionOffset((int) (byte) 0);
        java.awt.Font font19 = categoryAxis15.getLabelFont();
        labelBlock11.setFont(font19);
        java.awt.Paint paint21 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment22 = new org.jfree.chart.text.TextFragment("ItemLabelAnchor.INSIDE8", font19, paint21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 2.0f + "'", float16 == 2.0f);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot18.getRangeAxisEdge(0);
        categoryPlot18.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis27 = categoryPlot18.getRangeAxis();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke35 = categoryAxis34.getTickMarkStroke();
        java.awt.Stroke stroke36 = categoryAxis34.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color32, stroke36);
        java.awt.image.ColorModel colorModel38 = null;
        java.awt.Rectangle rectangle39 = null;
        org.jfree.chart.block.BlockContainer blockContainer40 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = blockContainer40.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame42 = blockContainer40.getFrame();
        double double43 = blockContainer40.getWidth();
        java.awt.geom.Rectangle2D rectangle2D44 = blockContainer40.getBounds();
        java.awt.geom.AffineTransform affineTransform45 = null;
        java.awt.RenderingHints renderingHints46 = null;
        java.awt.PaintContext paintContext47 = color32.createContext(colorModel38, rectangle39, rectangle2D44, affineTransform45, renderingHints46);
        textTitle29.draw(graphics2D30, rectangle2D44);
        java.awt.geom.Point2D point2D49 = null;
        org.jfree.chart.plot.PlotState plotState50 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo51 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo51);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.chart.renderer.RendererState rendererState55 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo54);
        java.lang.Class<?> wildcardClass56 = rendererState55.getClass();
        java.awt.Color color57 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass58 = color57.getClass();
        java.lang.Object obj59 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ItemLabelAnchor.OUTSIDE1", (java.lang.Class) wildcardClass56, (java.lang.Class) wildcardClass58);
        java.lang.ClassLoader classLoader60 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass56);
        boolean boolean61 = plotRenderingInfo52.equals((java.lang.Object) classLoader60);
        java.awt.geom.Rectangle2D rectangle2D62 = plotRenderingInfo52.getPlotArea();
        categoryPlot18.draw(graphics2D28, rectangle2D44, point2D49, plotState50, plotRenderingInfo52);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(blockFrame42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(paintContext47);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertNull(obj59);
        org.junit.Assert.assertNotNull(classLoader60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNull(rectangle2D62);
    }
}

