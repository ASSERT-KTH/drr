import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        try {
            org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("hi!", font1, (java.awt.Paint) color2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", graphics2D1, (float) (byte) 1, (float) (byte) 1, (double) ' ', (float) (byte) 10, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test008");
//        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
//        org.junit.Assert.assertNull(classLoader0);
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass1 = color0.getClass();
        java.awt.color.ColorSpace colorSpace2 = null;
        float[] floatArray5 = new float[] { '#', 'a' };
        try {
            float[] floatArray6 = color0.getColorComponents(colorSpace2, floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Paint paint2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        try {
            org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("", font1, paint2, rectangleEdge3, horizontalAlignment4, verticalAlignment5, rectangleInsets6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            rectangleInsets0.trim(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) (byte) -1, (float) (short) -1, 0.0f);
        org.junit.Assert.assertNull(shape4);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = null;
        java.awt.Paint paint7 = null;
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Stroke stroke10 = null;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Color color14 = java.awt.Color.BLUE;
        int int15 = color14.getRGB();
        try {
            org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem(attributedString0, "", "hi!", "hi!", true, shape5, false, paint7, false, (java.awt.Paint) color9, stroke10, false, shape12, stroke13, (java.awt.Paint) color14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-16776961) + "'", int15 == (-16776961));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            rectangleInsets0.trim(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.awt.Shape shape0 = null;
        try {
            java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, (double) 'a', (double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.combine(range0, range1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        try {
            java.awt.Color color1 = java.awt.Color.decode("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape1 = null;
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape1, (double) 2, (float) (-1), (float) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = null;
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.Range range3 = null;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint(range3, range4);
        try {
            org.jfree.chart.util.Size2D size2D6 = borderArrangement0.arrange(blockContainer1, graphics2D2, rectangleConstraint5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 10L, (double) 'a');
        org.jfree.chart.block.BlockContainer blockContainer5 = null;
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.Range range7 = null;
        org.jfree.data.Range range8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(range7, range8);
        try {
            org.jfree.chart.util.Size2D size2D10 = flowArrangement4.arrange(blockContainer5, graphics2D6, rectangleConstraint9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 100.0f, (double) (short) 100, (double) 0.0f, 2.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 100.0f, (double) (short) 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass6 = color5.getClass();
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("");
        boolean boolean10 = textLine8.equals((java.lang.Object) (-1L));
        org.jfree.chart.text.TextFragment textFragment11 = null;
        textLine8.removeFragment(textFragment11);
        boolean boolean13 = color5.equals((java.lang.Object) textLine8);
        java.awt.Stroke stroke14 = null;
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem(attributedString0, "java.awt.Color[r=0,g=255,b=255]", "java.awt.Color[r=0,g=255,b=255]", "java.awt.Color[r=0,g=255,b=255]", shape4, (java.awt.Paint) color5, stroke14, paint15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 1, (double) (-16776961));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (short) 100, (double) 2, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke3 = categoryAxis2.getTickMarkStroke();
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        categoryAxis2.setTickLabelsVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        try {
            axisCollection0.add((org.jfree.chart.axis.Axis) categoryAxis2, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'edge' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        java.awt.Stroke stroke3 = categoryAxis1.getAxisLineStroke();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.Plot plot5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace9 = categoryAxis1.reserveSpace(graphics2D4, plot5, rectangle2D6, rectangleEdge7, axisSpace8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 0.5f, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        try {
            statisticalBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        java.awt.Stroke stroke5 = categoryAxis3.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color1, stroke5);
        valueMarker6.setValue((double) 192);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = null;
        try {
            valueMarker6.setLabelOffsetType(lengthAdjustmentType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder0.getInsets();
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        categoryAxis1.setCategoryLabelPositionOffset((int) (byte) 0);
        java.awt.Paint paint5 = null;
        try {
            categoryAxis1.setLabelPaint(paint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke7 = categoryAxis6.getTickMarkStroke();
        try {
            statisticalBarRenderer0.setSeriesOutlineStroke((int) (short) -1, stroke7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition5);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = statisticalBarRenderer0.getLegendItemLabelGenerator();
        org.jfree.chart.event.RendererChangeListener rendererChangeListener8 = null;
        try {
            statisticalBarRenderer0.addChangeListener(rendererChangeListener8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator7);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) '4');
        java.lang.Object obj3 = objectList1.get(1);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("hi!");
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        try {
            statisticalBarRenderer0.setPlot(categoryPlot7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) 1, (float) (short) 0);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createInsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor2);
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        try {
            java.lang.Number number3 = defaultStatisticalCategoryDataset0.getMeanValue((int) (byte) 10, (-16776961));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = null;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, (float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.awt.Color color0 = java.awt.Color.darkGray;
        float[] floatArray3 = new float[] { 100L, 2.0f };
        try {
            float[] floatArray4 = color0.getRGBComponents(floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition5);
        java.awt.Stroke stroke7 = null;
        try {
            statisticalBarRenderer0.setBaseOutlineStroke(stroke7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) '4');
        int int2 = objectList1.size();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor2);
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke11 = categoryAxis10.getTickMarkStroke();
        java.awt.Stroke stroke12 = categoryAxis10.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color8, stroke12);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint17 = categoryAxis15.getTickLabelPaint((java.lang.Comparable) "hi!");
        try {
            org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "hi!", "", shape6, stroke12, paint17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.awt.Color color1 = java.awt.Color.getColor("hi!");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        try {
            statisticalBarRenderer0.setSeriesItemLabelsVisible((-16776961), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 0, (double) 0L, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint3 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) "hi!");
        double double4 = categoryAxis1.getFixedDimension();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge9);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        try {
            org.jfree.chart.axis.AxisState axisState13 = categoryAxis1.draw(graphics2D5, 4.0d, rectangle2D7, rectangle2D8, rectangleEdge10, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape9);
        statisticalBarRenderer5.setSeriesShape((int) (short) 0, shape9);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape9, (double) (byte) 1, 0.0d);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color18 = java.awt.Color.BLUE;
        int int19 = color18.getRGB();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity25 = new org.jfree.chart.entity.ChartEntity(shape24);
        statisticalBarRenderer20.setSeriesShape((int) (short) 0, shape24);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke29 = categoryAxis28.getTickMarkStroke();
        statisticalBarRenderer20.setBaseOutlineStroke(stroke29);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean33 = statisticalBarRenderer32.getAutoPopulateSeriesStroke();
        statisticalBarRenderer32.setIncludeBaseInRange(false);
        java.awt.Shape shape37 = statisticalBarRenderer32.lookupSeriesShape((int) (byte) 10);
        java.awt.Stroke stroke38 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color39 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass40 = color39.getClass();
        org.jfree.chart.text.TextLine textLine42 = new org.jfree.chart.text.TextLine("");
        boolean boolean44 = textLine42.equals((java.lang.Object) (-1L));
        org.jfree.chart.text.TextFragment textFragment45 = null;
        textLine42.removeFragment(textFragment45);
        boolean boolean47 = color39.equals((java.lang.Object) textLine42);
        try {
            org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem(attributedString0, "VerticalAlignment.TOP", "Size2D[width=0.0, height=10.0]", "", false, shape14, false, (java.awt.Paint) color16, false, (java.awt.Paint) color18, stroke29, false, shape37, stroke38, (java.awt.Paint) color39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-16776961) + "'", int19 == (-16776961));
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 1.0f, (double) 100L);
        java.lang.Number number3 = meanAndStandardDeviation2.getMean();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 1.0d + "'", number3.equals(1.0d));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 0, (double) (byte) 10);
        size2D2.setWidth((double) (short) 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE12" + "'", str1.equals("ItemLabelAnchor.INSIDE12"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint3 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) "hi!");
        double double4 = categoryAxis1.getFixedDimension();
        categoryAxis1.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(0.0d);
        axisState1.cursorRight((double) (short) -1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        boolean boolean3 = rectangleInsets1.equals((java.lang.Object) color2);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets1.createAdjustedRectangle(rectangle2D4, lengthAdjustmentType5, lengthAdjustmentType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) 10L, (double) 'a');
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment2, 100.0d, (double) (-16776961));
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer();
        double double10 = blockContainer9.getContentYOffset();
        double double11 = blockContainer9.getWidth();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.Range range13 = null;
        org.jfree.data.Range range14 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint(range13, range14);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType16 = rectangleConstraint15.getWidthConstraintType();
        try {
            org.jfree.chart.util.Size2D size2D17 = columnArrangement8.arrange(blockContainer9, graphics2D12, rectangleConstraint15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType16);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        java.lang.String str1 = lengthConstraintType0.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "LengthConstraintType.NONE" + "'", str1.equals("LengthConstraintType.NONE"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, (float) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape8);
        statisticalBarRenderer4.setSeriesShape((int) (short) 0, shape8);
        java.awt.Paint paint11 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke16 = categoryAxis15.getTickMarkStroke();
        java.awt.Stroke stroke17 = categoryAxis15.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color13, stroke17);
        java.awt.Color color19 = java.awt.Color.BLUE;
        int int20 = color19.getRGB();
        try {
            org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem(attributedString0, "ItemLabelAnchor.INSIDE12", "", "", shape8, paint11, stroke17, (java.awt.Paint) color19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-16776961) + "'", int20 == (-16776961));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        boolean boolean3 = rectangleInsets1.equals((java.lang.Object) color2);
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass5 = color4.getClass();
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("");
        boolean boolean9 = textLine7.equals((java.lang.Object) (-1L));
        org.jfree.chart.text.TextFragment textFragment10 = null;
        textLine7.removeFragment(textFragment10);
        boolean boolean12 = color4.equals((java.lang.Object) textLine7);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace14 = color13.getColorSpace();
        float[] floatArray21 = new float[] { 'a', 100.0f, 100L, (byte) 10, 0.5f, ' ' };
        float[] floatArray22 = color4.getComponents(colorSpace14, floatArray21);
        float[] floatArray23 = color2.getRGBColorComponents(floatArray22);
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        statisticalBarRenderer0.notifyListeners(rendererChangeEvent2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE1" + "'", str1.equals("ItemLabelAnchor.OUTSIDE1"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range5 = statisticalBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4);
        int int7 = defaultStatisticalCategoryDataset4.getColumnIndex((java.lang.Comparable) 0.0d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = null;
        try {
            categoryPlot18.addDomainMarker(categoryMarker19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getFirstTextFragment();
        textBlock0.addLine(textLine1);
        org.jfree.chart.text.TextFragment textFragment4 = textLine1.getLastTextFragment();
        org.junit.Assert.assertNull(textFragment2);
        org.junit.Assert.assertNull(textFragment4);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor2);
        float float4 = categoryLabelPosition3.getWidthRatio();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition3);
        java.lang.Object obj6 = null;
        boolean boolean7 = categoryLabelPositions0.equals(obj6);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.95f + "'", float4 == 0.95f);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets1.createOutsetRectangle(rectangle2D2, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        statisticalBarRenderer0.setAutoPopulateSeriesPaint(true);
        java.lang.Boolean boolean7 = statisticalBarRenderer0.getSeriesCreateEntities((int) (short) -1);
        java.awt.Paint paint9 = statisticalBarRenderer0.lookupSeriesFillPaint((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        double double1 = blockContainer0.getContentYOffset();
        double double2 = blockContainer0.getWidth();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.Size2D size2D4 = blockContainer0.arrange(graphics2D3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(size2D4);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D5, (float) 0L, 0.0f, textAnchor8, (double) '#', (float) 10L, 0.0f);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Size2D[width=0.0, height=10.0]", graphics2D1, 0.95f, (float) 10L, textAnchor8, (double) (byte) 100, (float) (byte) -1, (float) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass3 = color2.getClass();
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("");
        boolean boolean7 = textLine5.equals((java.lang.Object) (-1L));
        org.jfree.chart.text.TextFragment textFragment8 = null;
        textLine5.removeFragment(textFragment8);
        boolean boolean10 = color2.equals((java.lang.Object) textLine5);
        int int11 = color2.getBlue();
        org.jfree.chart.text.TextMeasurer textMeasurer14 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("LengthConstraintType.NONE", font1, (java.awt.Paint) color2, (float) (-1L), (int) (short) 0, textMeasurer14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 192 + "'", int11 == 192);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        statisticalBarRenderer0.setAutoPopulateSeriesShape(false);
        java.util.EventListener eventListener9 = null;
        boolean boolean10 = statisticalBarRenderer0.hasListener(eventListener9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_BLUE;
        statisticalBarRenderer0.setErrorIndicatorPaint((java.awt.Paint) color11);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator13, true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        boolean boolean19 = statisticalBarRenderer8.getAutoPopulateSeriesFillPaint();
        try {
            statisticalBarRenderer8.setSeriesItemLabelsVisible((int) (byte) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(0.0d);
        axisState1.setCursor((double) 100);
        org.jfree.chart.axis.AxisState axisState4 = new org.jfree.chart.axis.AxisState();
        java.util.List list5 = axisState4.getTicks();
        axisState1.setTicks(list5);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE8" + "'", str1.equals("ItemLabelAnchor.INSIDE8"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint3 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) "hi!");
        double double4 = categoryAxis1.getFixedDimension();
        java.lang.Object obj5 = categoryAxis1.clone();
        categoryAxis1.setLabelAngle((double) 192);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range5 = statisticalBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4);
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset11 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset11);
        defaultStatisticalCategoryDataset11.validateObject();
        int int14 = defaultStatisticalCategoryDataset11.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        int int17 = categoryAxis16.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity(shape23);
        statisticalBarRenderer19.setSeriesShape((int) (short) 0, shape23);
        statisticalBarRenderer19.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset11, categoryAxis16, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer19);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("");
        float float32 = categoryAxis31.getTickMarkOutsideLength();
        java.util.EventListener eventListener33 = null;
        boolean boolean34 = categoryAxis31.hasListener(eventListener33);
        categoryAxis31.setVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = categoryAxis31.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        double[] doubleArray43 = new double[] { (-1L), (short) 10 };
        double[] doubleArray46 = new double[] { (-1L), (short) 10 };
        double[] doubleArray49 = new double[] { (-1L), (short) 10 };
        double[] doubleArray52 = new double[] { (-1L), (short) 10 };
        double[][] doubleArray53 = new double[][] { doubleArray43, doubleArray46, doubleArray49, doubleArray52 };
        org.jfree.data.category.CategoryDataset categoryDataset54 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=0,g=255,b=255]", "Size2D[width=0.0, height=10.0]", doubleArray53);
        try {
            statisticalBarRenderer0.drawItem(graphics2D8, categoryItemRendererState9, rectangle2D10, categoryPlot29, categoryAxis31, valueAxis38, categoryDataset54, (int) 'a', 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires StatisticalCategoryDataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 2.0f + "'", float32 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(categoryDataset54);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        defaultStatisticalCategoryDataset0.addChangeListener(datasetChangeListener3);
        double double6 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.data.Range range8 = defaultStatisticalCategoryDataset0.getRangeBounds(false);
        int int10 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) false);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createOutsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 10.0f, (double) 100, 10.0d, (double) 2, (java.awt.Paint) color4);
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("");
        boolean boolean8 = color4.equals((java.lang.Object) textLine7);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.awt.Shape shape1 = null;
        try {
            org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity4 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 2.0d, shape1, "hi!", "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesItemLabelPaint(0, (java.awt.Paint) color9, false);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset15 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset15);
        defaultStatisticalCategoryDataset15.validateObject();
        int int18 = defaultStatisticalCategoryDataset15.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        int int21 = categoryAxis20.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity28 = new org.jfree.chart.entity.ChartEntity(shape27);
        statisticalBarRenderer23.setSeriesShape((int) (short) 0, shape27);
        statisticalBarRenderer23.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset15, categoryAxis20, valueAxis22, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer23);
        java.awt.Color color34 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass35 = color34.getClass();
        org.jfree.chart.text.TextLine textLine37 = new org.jfree.chart.text.TextLine("");
        boolean boolean39 = textLine37.equals((java.lang.Object) (-1L));
        org.jfree.chart.text.TextFragment textFragment40 = null;
        textLine37.removeFragment(textFragment40);
        boolean boolean42 = color34.equals((java.lang.Object) textLine37);
        int int43 = color34.getBlue();
        categoryPlot33.setOutlinePaint((java.awt.Paint) color34);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint48 = categoryAxis46.getTickLabelPaint((java.lang.Comparable) "hi!");
        double double49 = categoryAxis46.getFixedDimension();
        java.lang.Object obj50 = categoryAxis46.clone();
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset52 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number53 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset52);
        java.util.List list54 = defaultStatisticalCategoryDataset52.getColumnKeys();
        try {
            statisticalBarRenderer0.drawItem(graphics2D12, categoryItemRendererState13, rectangle2D14, categoryPlot33, categoryAxis46, valueAxis51, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset52, (int) (short) 100, (int) (byte) -1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 192 + "'", int43 == 192);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(obj50);
        org.junit.Assert.assertEquals((double) number53, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list54);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = rendererState1.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection2);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockContainer1.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame3 = blockContainer1.getFrame();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4);
        defaultStatisticalCategoryDataset4.validateObject();
        int int7 = defaultStatisticalCategoryDataset4.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        int int10 = categoryAxis9.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity(shape16);
        statisticalBarRenderer12.setSeriesShape((int) (short) 0, shape16);
        statisticalBarRenderer12.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, categoryAxis9, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer12);
        categoryPlot22.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        categoryPlot22.addChangeListener(plotChangeListener25);
        float float27 = categoryPlot22.getBackgroundAlpha();
        int int28 = categoryPlot22.getWeight();
        try {
            borderArrangement0.add((org.jfree.chart.block.Block) blockContainer1, (java.lang.Object) categoryPlot22);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.CategoryPlot cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 1.0f + "'", float27 == 1.0f);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        java.lang.Object obj6 = categoryAxis1.clone();
        java.awt.Font font8 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 1.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double11 = rectangleInsets9.calculateTopInset((-1.0d));
        double double13 = rectangleInsets9.calculateBottomOutset((double) 10L);
        categoryAxis1.setLabelInsets(rectangleInsets9);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        centerArrangement0.clear();
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = blockContainer2.getMargin();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.Range range6 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType7 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.Range range9 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType10 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((double) 0L, range6, lengthConstraintType7, 0.2d, range9, lengthConstraintType10);
        double double12 = rectangleConstraint11.getWidth();
        try {
            org.jfree.chart.util.Size2D size2D13 = centerArrangement0.arrange(blockContainer2, graphics2D4, rectangleConstraint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(lengthConstraintType7);
        org.junit.Assert.assertNotNull(lengthConstraintType10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.data.Range range5 = rectangleConstraint4.getHeightRange();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        float float23 = categoryPlot18.getBackgroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot18.getRangeAxis(0);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertNull(valueAxis25);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType4 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor3, categoryLabelWidthType4, (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, (float) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator4 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator5 = null;
        java.lang.String str6 = chartEntity3.getImageMapAreaTag(toolTipTagFragmentGenerator4, uRLTagFragmentGenerator5);
        chartEntity3.setURLText("ItemLabelAnchor.INSIDE12");
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        java.awt.Stroke stroke5 = categoryAxis3.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color1, stroke5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = valueMarker6.getLabelAnchor();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        valueMarker6.setLabelPaint((java.awt.Paint) color8);
        try {
            valueMarker6.setAlpha((float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.awt.Color color1 = java.awt.Color.cyan;
        int int2 = color1.getGreen();
        java.lang.String str3 = color1.toString();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        java.awt.Stroke stroke7 = categoryAxis5.getAxisLineStroke();
        java.awt.Paint paint8 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean10 = statisticalBarRenderer9.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = statisticalBarRenderer9.getPositiveItemLabelPositionFallback();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment12, verticalAlignment13, (double) 10L, (double) 'a');
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer();
        double double18 = blockContainer17.getContentYOffset();
        double double19 = blockContainer17.getWidth();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke24 = categoryAxis23.getTickMarkStroke();
        java.awt.Stroke stroke25 = categoryAxis23.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color21, stroke25);
        flowArrangement16.add((org.jfree.chart.block.Block) blockContainer17, (java.lang.Object) stroke25);
        statisticalBarRenderer9.setErrorIndicatorStroke(stroke25);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(0.2d, (java.awt.Paint) color1, stroke7, paint8, stroke25, (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=0,g=255,b=255]" + "'", str3.equals("java.awt.Color[r=0,g=255,b=255]"));
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        defaultStatisticalCategoryDataset0.addChangeListener(datasetChangeListener3);
        double double6 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        double double8 = defaultStatisticalCategoryDataset0.getRangeLowerBound(false);
        try {
            java.lang.Number number11 = defaultStatisticalCategoryDataset0.getMeanValue((int) (short) 100, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.awt.Color color2 = java.awt.Color.getColor("NOID", (int) (byte) -1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition5);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = statisticalBarRenderer0.getLegendItemLabelGenerator();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(0, categoryURLGenerator9, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator7);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        statisticalBarRenderer0.setAutoPopulateSeriesPaint(true);
        boolean boolean6 = statisticalBarRenderer0.getBaseItemLabelsVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range5 = statisticalBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4);
        try {
            java.lang.Number number8 = defaultStatisticalCategoryDataset4.getValue((int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 2.0f, (double) ' ', (double) 100.0f, (double) 10.0f);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        java.awt.Font font3 = categoryAxis1.getLabelFont();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke9 = categoryAxis8.getTickMarkStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke9);
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation14 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 1.0f, (double) 100L);
        boolean boolean16 = meanAndStandardDeviation14.equals((java.lang.Object) 0L);
        java.awt.Font font17 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        boolean boolean18 = meanAndStandardDeviation14.equals((java.lang.Object) font17);
        java.awt.Color color19 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass20 = color19.getClass();
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine("");
        boolean boolean24 = textLine22.equals((java.lang.Object) (-1L));
        org.jfree.chart.text.TextFragment textFragment25 = null;
        textLine22.removeFragment(textFragment25);
        boolean boolean27 = color19.equals((java.lang.Object) textLine22);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace29 = color28.getColorSpace();
        float[] floatArray36 = new float[] { 'a', 100.0f, 100L, (byte) 10, 0.5f, ' ' };
        float[] floatArray37 = color19.getComponents(colorSpace29, floatArray36);
        org.jfree.chart.text.TextFragment textFragment38 = new org.jfree.chart.text.TextFragment("", font17, (java.awt.Paint) color19);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color19);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(colorSpace29);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            blockContainer0.setBounds(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        boolean boolean9 = statisticalBarRenderer0.getItemVisible((int) '#', (int) (short) -1);
        statisticalBarRenderer0.setSeriesCreateEntities((int) (short) 0, (java.lang.Boolean) true, true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor2);
        float float4 = categoryLabelPosition3.getWidthRatio();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = categoryLabelPosition3.getLabelAnchor();
        boolean boolean6 = horizontalAlignment0.equals((java.lang.Object) categoryLabelPosition3);
        org.jfree.chart.text.TextBlock textBlock7 = new org.jfree.chart.text.TextBlock();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset9 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset9);
        defaultStatisticalCategoryDataset9.validateObject();
        int int12 = defaultStatisticalCategoryDataset9.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        int int15 = categoryAxis14.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape21);
        statisticalBarRenderer17.setSeriesShape((int) (short) 0, shape21);
        statisticalBarRenderer17.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset9, categoryAxis14, valueAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer17);
        java.awt.Font font29 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis14.setTickLabelFont((java.lang.Comparable) 100.0d, font29);
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        textBlock7.addLine("LengthConstraintType.NONE", font29, paint31);
        boolean boolean33 = horizontalAlignment0.equals((java.lang.Object) paint31);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.95f + "'", float4 == 0.95f);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj1 = shapeList0.clone();
        java.lang.Object obj2 = shapeList0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("ItemLabelAnchor.INSIDE12", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 10L, (double) 'a');
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer();
        double double6 = blockContainer5.getContentYOffset();
        double double7 = blockContainer5.getWidth();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke12 = categoryAxis11.getTickMarkStroke();
        java.awt.Stroke stroke13 = categoryAxis11.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color9, stroke13);
        flowArrangement4.add((org.jfree.chart.block.Block) blockContainer5, (java.lang.Object) stroke13);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            blockContainer5.draw(graphics2D16, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Paint paint9 = statisticalBarRenderer0.lookupSeriesPaint(0);
        java.awt.Paint paint11 = statisticalBarRenderer0.lookupSeriesFillPaint(0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape9);
        statisticalBarRenderer5.setSeriesShape((int) (short) 0, shape9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "", "java.awt.Color[r=0,g=255,b=255]", shape9, (java.awt.Paint) color12);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity14 = new org.jfree.chart.entity.LegendItemEntity(shape9);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape9, (double) 0, (float) 1, (float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke3 = categoryAxis2.getTickMarkStroke();
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        java.lang.Object obj7 = categoryAxis2.clone();
        java.awt.Font font9 = categoryAxis2.getTickLabelFont((java.lang.Comparable) 1.0d);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) 10.0f, (double) 100, 10.0d, (double) 2, (java.awt.Paint) color14);
        org.jfree.chart.text.TextBlock textBlock16 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font9, (java.awt.Paint) color14);
        org.jfree.chart.text.TextLine textLine17 = textBlock16.getLastLine();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor21 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        try {
            textBlock16.draw(graphics2D18, 0.0f, (float) 0, textBlockAnchor21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(textBlock16);
        org.junit.Assert.assertNotNull(textLine17);
        org.junit.Assert.assertNotNull(textBlockAnchor21);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        boolean boolean3 = rectangleInsets1.equals((java.lang.Object) color2);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            rectangleInsets1.trim(rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, (double) (byte) 1, 0.0d);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.clone(shape4);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        java.lang.String str4 = chartEntity3.getURLText();
        java.lang.String str5 = chartEntity3.getShapeCoords();
        java.lang.String str6 = chartEntity3.getToolTipText();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1,100,-100,100,-100,1,100,1,100,100,1,100,1,-100,100,-100,100,-1,-100,-1,-100,-100,-1,-100,-1,-100" + "'", str5.equals("-1,100,-100,100,-100,1,100,1,100,100,1,100,1,-100,100,-100,100,-1,-100,-1,-100,-100,-1,-100,-1,-100"));
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape9);
        statisticalBarRenderer5.setSeriesShape((int) (short) 0, shape9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "", "", "java.awt.Color[r=0,g=255,b=255]", shape9, (java.awt.Paint) color12);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity14 = new org.jfree.chart.entity.LegendItemEntity(shape9);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape9, (double) 500, (float) 1L, (float) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        java.lang.String str4 = chartEntity3.getURLText();
        java.lang.String str5 = chartEntity3.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ChartEntity: tooltip = null" + "'", str5.equals("ChartEntity: tooltip = null"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        defaultStatisticalCategoryDataset0.addChangeListener(datasetChangeListener3);
        double double6 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.data.Range range8 = defaultStatisticalCategoryDataset0.getRangeBounds(false);
        try {
            java.lang.Comparable comparable10 = defaultStatisticalCategoryDataset0.getRowKey((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("NOID");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name NOID, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape26);
        statisticalBarRenderer22.setSeriesShape((int) (short) 0, shape26);
        java.lang.Object obj29 = statisticalBarRenderer22.clone();
        java.awt.Paint paint31 = statisticalBarRenderer22.lookupSeriesFillPaint(192);
        categoryPlot18.setRenderer((int) (short) 0, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22, false);
        java.awt.Paint paint34 = categoryPlot18.getOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = categoryPlot18.getDomainAxis();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation36 = null;
        try {
            categoryPlot18.addAnnotation(categoryAnnotation36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(categoryAxis35);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape8);
        statisticalBarRenderer4.setSeriesShape((int) (short) 0, shape8);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("", "", "", "java.awt.Color[r=0,g=255,b=255]", shape8, (java.awt.Paint) color11);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = legendItem12.getFillPaintTransformer();
        org.jfree.data.general.Dataset dataset14 = legendItem12.getDataset();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
        org.junit.Assert.assertNull(dataset14);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot18.setRangeAxisLocation(0, axisLocation24);
        categoryPlot18.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double30 = rectangleInsets28.calculateTopInset((-1.0d));
        double double32 = rectangleInsets28.calculateBottomOutset((double) 10L);
        categoryPlot18.setInsets(rectangleInsets28, true);
        org.jfree.chart.util.SortOrder sortOrder35 = null;
        try {
            categoryPlot18.setRowRenderingOrder(sortOrder35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        boolean boolean19 = statisticalBarRenderer8.getAutoPopulateSeriesFillPaint();
        java.awt.Paint paint21 = statisticalBarRenderer8.getSeriesFillPaint(500);
        boolean boolean22 = statisticalBarRenderer8.getBaseItemLabelsVisible();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "hi!" + "'", str0.equals("hi!"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        java.lang.String str4 = chartEntity3.getToolTipText();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot18.setRangeAxisLocation(0, axisLocation24);
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation24, plotOrientation26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation24);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        java.awt.Stroke stroke23 = categoryPlot18.getDomainGridlineStroke();
        float float24 = categoryPlot18.getBackgroundAlpha();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        java.lang.Object obj6 = categoryAxis1.clone();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = null;
        try {
            categoryAxis1.setCategoryLabelPositions(categoryLabelPositions7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        categoryAxis1.setFixedDimension((double) ' ');
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("ChartEntity: tooltip = null", "NOID");
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = statisticalBarRenderer0.removeAnnotation(categoryAnnotation4);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation6 = null;
        try {
            statisticalBarRenderer0.addAnnotation(categoryAnnotation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.lang.Object obj0 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        java.util.EventListener eventListener3 = null;
        boolean boolean4 = categoryAxis1.hasListener(eventListener3);
        categoryAxis1.setVisible(true);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset10 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset10);
        defaultStatisticalCategoryDataset10.validateObject();
        int int13 = defaultStatisticalCategoryDataset10.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("");
        int int16 = categoryAxis15.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity23 = new org.jfree.chart.entity.ChartEntity(shape22);
        statisticalBarRenderer18.setSeriesShape((int) (short) 0, shape22);
        statisticalBarRenderer18.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset10, categoryAxis15, valueAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer18);
        java.awt.Color color29 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass30 = color29.getClass();
        org.jfree.chart.text.TextLine textLine32 = new org.jfree.chart.text.TextLine("");
        boolean boolean34 = textLine32.equals((java.lang.Object) (-1L));
        org.jfree.chart.text.TextFragment textFragment35 = null;
        textLine32.removeFragment(textFragment35);
        boolean boolean37 = color29.equals((java.lang.Object) textLine32);
        int int38 = color29.getBlue();
        categoryPlot28.setOutlinePaint((java.awt.Paint) color29);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment40 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment41 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement44 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment40, verticalAlignment41, (double) 10L, (double) 'a');
        org.jfree.chart.block.BlockContainer blockContainer45 = new org.jfree.chart.block.BlockContainer();
        double double46 = blockContainer45.getContentYOffset();
        double double47 = blockContainer45.getWidth();
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke52 = categoryAxis51.getTickMarkStroke();
        java.awt.Stroke stroke53 = categoryAxis51.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker54 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color49, stroke53);
        flowArrangement44.add((org.jfree.chart.block.Block) blockContainer45, (java.lang.Object) stroke53);
        categoryPlot28.setRangeGridlineStroke(stroke53);
        categoryPlot28.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = categoryPlot28.getDomainAxisEdge((-16776961));
        try {
            double double61 = categoryAxis1.getCategoryStart(10, 3, rectangle2D9, rectangleEdge60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 192 + "'", int38 == 192);
        org.junit.Assert.assertNotNull(verticalAlignment41);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(rectangleEdge60);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.lang.String str1 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VerticalAlignment.TOP" + "'", str1.equals("VerticalAlignment.TOP"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer1.getAutoPopulateSeriesStroke();
        statisticalBarRenderer1.setIncludeBaseInRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke7 = categoryAxis6.getTickMarkStroke();
        statisticalBarRenderer1.setBaseOutlineStroke(stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        statisticalBarRenderer1.setSeriesItemLabelPaint(0, (java.awt.Paint) color10, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean14 = statisticalBarRenderer13.getAutoPopulateSeriesStroke();
        statisticalBarRenderer13.setIncludeBaseInRange(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        statisticalBarRenderer13.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition18);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator20 = statisticalBarRenderer13.getLegendItemLabelGenerator();
        statisticalBarRenderer1.setLegendItemURLGenerator(categorySeriesLabelGenerator20);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = statisticalBarRenderer1.getNegativeItemLabelPositionFallback();
        boolean boolean23 = standardCategorySeriesLabelGenerator0.equals((java.lang.Object) statisticalBarRenderer1);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset24 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset24);
        java.util.List list26 = defaultStatisticalCategoryDataset24.getColumnKeys();
        try {
            java.lang.String str28 = standardCategorySeriesLabelGenerator0.generateLabel((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset24, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator20);
        org.junit.Assert.assertNull(itemLabelPosition22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertEquals((double) number25, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list26);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        java.util.EventListener eventListener3 = null;
        boolean boolean4 = categoryAxis1.hasListener(eventListener3);
        categoryAxis1.setVisible(true);
        categoryAxis1.setTickMarksVisible(false);
        float float9 = categoryAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        statisticalBarRenderer0.setBaseSeriesVisible(true, true);
        statisticalBarRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        org.junit.Assert.assertNotNull(shape4);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        java.lang.Class class0 = null;
//        try {
//            java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape8);
        statisticalBarRenderer4.setSeriesShape((int) (short) 0, shape8);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke13 = categoryAxis12.getTickMarkStroke();
        java.awt.Stroke stroke14 = categoryAxis12.getAxisLineStroke();
        java.awt.Color color15 = java.awt.Color.cyan;
        java.lang.String str16 = color15.toString();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "", "", "hi!", shape8, stroke14, (java.awt.Paint) color15);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer18 = legendItem17.getFillPaintTransformer();
        java.lang.String str19 = legendItem17.getToolTipText();
        java.lang.String str20 = legendItem17.getURLText();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "java.awt.Color[r=0,g=255,b=255]" + "'", str16.equals("java.awt.Color[r=0,g=255,b=255]"));
        org.junit.Assert.assertNotNull(gradientPaintTransformer18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toUnconstrainedWidth();
        double double5 = rectangleConstraint4.getHeight();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        double double1 = size2D0.width;
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesItemLabelPaint(0, (java.awt.Paint) color9, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer12.getAutoPopulateSeriesStroke();
        statisticalBarRenderer12.setIncludeBaseInRange(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        statisticalBarRenderer12.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition17);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = statisticalBarRenderer12.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        java.awt.Stroke stroke22 = statisticalBarRenderer0.lookupSeriesStroke(10);
        boolean boolean24 = statisticalBarRenderer0.isSeriesVisible((int) '4');
        boolean boolean25 = statisticalBarRenderer0.getIncludeBaseInRange();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape8);
        statisticalBarRenderer4.setSeriesShape((int) (short) 0, shape8);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("", "", "", "java.awt.Color[r=0,g=255,b=255]", shape8, (java.awt.Paint) color11);
        java.awt.Shape shape13 = legendItem12.getShape();
        java.lang.String str14 = legendItem12.getToolTipText();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        java.lang.String str2 = rectangleInsets1.toString();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str2.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor4, textBlockAnchor5);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = categoryLabelPosition6.getLabelAnchor();
        boolean boolean8 = itemLabelAnchor3.equals((java.lang.Object) textBlockAnchor7);
        boolean boolean9 = categoryLabelPosition2.equals((java.lang.Object) boolean8);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        float float23 = categoryPlot18.getBackgroundAlpha();
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot18.getDomainMarkers(layer24);
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot18.getRangeAxisLocation(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation28 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge29 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation27, plotOrientation28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(axisLocation27);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        try {
            keyedObjects0.removeValue((java.lang.Comparable) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        double[][] doubleArray2 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=0,g=255,b=255]", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) '4');
        java.lang.Object obj5 = categoryAxis1.clone();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.TickLabelEntity tickLabelEntity3 = new org.jfree.chart.entity.TickLabelEntity(shape0, "LengthConstraintType.NONE", "Size2D[width=0.0, height=10.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("", "", "", "java.awt.Color[r=0,g=255,b=255]", shape12, (java.awt.Paint) color15);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset17 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset17);
        defaultStatisticalCategoryDataset17.validateObject();
        int int20 = defaultStatisticalCategoryDataset17.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        int int23 = categoryAxis22.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity(shape29);
        statisticalBarRenderer25.setSeriesShape((int) (short) 0, shape29);
        statisticalBarRenderer25.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset17, categoryAxis22, valueAxis24, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer25);
        categoryPlot35.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener38 = null;
        categoryPlot35.addChangeListener(plotChangeListener38);
        java.awt.Stroke stroke40 = categoryPlot35.getDomainGridlineStroke();
        java.awt.Color color41 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        try {
            org.jfree.chart.LegendItem legendItem42 = new org.jfree.chart.LegendItem(attributedString0, "Category Plot", "ClassContext", "ChartEntity: tooltip = null", shape12, stroke40, (java.awt.Paint) color41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(color41);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE10" + "'", str1.equals("ItemLabelAnchor.INSIDE10"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke9 = categoryAxis8.getTickMarkStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke9);
        java.awt.Color color11 = java.awt.Color.cyan;
        statisticalBarRenderer0.setErrorIndicatorPaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = statisticalBarRenderer0.getSeriesOutlineStroke(100);
        java.awt.Paint paint17 = statisticalBarRenderer0.getItemFillPaint(10, (int) ' ');
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(stroke14);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) 10L, (double) 'a');
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment2, 100.0d, (double) (-16776961));
        columnArrangement8.clear();
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = blockContainer10.getMargin();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.Range range13 = null;
        org.jfree.data.Range range14 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint(range13, range14);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType16 = rectangleConstraint15.getHeightConstraintType();
        try {
            org.jfree.chart.util.Size2D size2D17 = columnArrangement8.arrange(blockContainer10, graphics2D12, rectangleConstraint15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(lengthConstraintType16);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.awt.geom.Point2D point2D2 = null;
        try {
            int int3 = plotRenderingInfo1.getSubplotIndex(point2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape8);
        statisticalBarRenderer4.setSeriesShape((int) (short) 0, shape8);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("", "", "", "java.awt.Color[r=0,g=255,b=255]", shape8, (java.awt.Paint) color11);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity13 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        legendItemEntity13.setSeriesKey((java.lang.Comparable) 0.5f);
        java.lang.Comparable comparable16 = legendItemEntity13.getSeriesKey();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 0.5f + "'", comparable16.equals(0.5f));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("VerticalAlignment.TOP", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        categoryAxis1.setCategoryLabelPositionOffset((int) (byte) 0);
        java.awt.Stroke stroke5 = null;
        try {
            categoryAxis1.setAxisLineStroke(stroke5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape10);
        statisticalBarRenderer6.setSeriesShape((int) (short) 0, shape10);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke15 = categoryAxis14.getTickMarkStroke();
        java.awt.Stroke stroke16 = categoryAxis14.getAxisLineStroke();
        java.awt.Color color17 = java.awt.Color.cyan;
        java.lang.String str18 = color17.toString();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("", "", "", "hi!", shape10, stroke16, (java.awt.Paint) color17);
        try {
            strokeList0.setStroke((-16776961), stroke16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "java.awt.Color[r=0,g=255,b=255]" + "'", str18.equals("java.awt.Color[r=0,g=255,b=255]"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateY();
        double double2 = blockParams0.getTranslateX();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.awt.Color color0 = java.awt.Color.darkGray;
        int int1 = color0.getTransparency();
        java.lang.String str2 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=64,g=64,b=64]" + "'", str2.equals("java.awt.Color[r=64,g=64,b=64]"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=0,g=255,b=255]");
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        java.awt.Paint paint0 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        java.awt.Stroke stroke5 = categoryAxis3.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color1, stroke5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = valueMarker6.getLabelAnchor();
        java.awt.Paint paint8 = valueMarker6.getLabelPaint();
        valueMarker6.setValue((double) 500);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) 10L, (double) 'a');
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment2, 100.0d, (double) (-16776961));
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = blockContainer9.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame11 = blockContainer9.getFrame();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = null;
        try {
            org.jfree.chart.util.Size2D size2D14 = columnArrangement8.arrange(blockContainer9, graphics2D12, rectangleConstraint13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(blockFrame11);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = statisticalBarRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Shape shape4 = null;
        statisticalBarRenderer0.setSeriesShape(100, shape4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        float float8 = categoryAxis7.getTickMarkOutsideLength();
        java.awt.Stroke stroke9 = categoryAxis7.getAxisLineStroke();
        statisticalBarRenderer0.setBaseStroke(stroke9, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        statisticalBarRenderer0.setBaseURLGenerator(categoryURLGenerator12, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 2.0f + "'", float8 == 2.0f);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.chart.util.Size2D size2D7 = new org.jfree.chart.util.Size2D((double) 0, (double) (byte) 10);
        double double8 = size2D7.height;
        java.lang.Object obj9 = size2D7.clone();
        try {
            org.jfree.chart.util.Size2D size2D10 = rectangleConstraint4.calculateConstrainedSize(size2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!", font1, (java.awt.Paint) color2, 1.0f);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        try {
            textFragment5.draw(graphics2D6, 0.95f, 0.95f, textAnchor9, (float) 192, (float) (short) 100, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertNotNull(textAnchor9);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        java.lang.Object obj7 = statisticalBarRenderer0.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = new org.jfree.chart.labels.ItemLabelPosition();
        statisticalBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition8);
        statisticalBarRenderer0.setSeriesItemLabelsVisible(1, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 100, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("ChartEntity: tooltip = null");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name ChartEntity: tooltip = null, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!", font1, (java.awt.Paint) color2, 1.0f);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        try {
            textFragment5.draw(graphics2D6, (float) (-16776961), (float) 0, textAnchor9, (float) (short) 100, 0.0f, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertNotNull(textAnchor9);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setTickLabelsVisible(false);
        categoryAxis1.setLabelToolTip("");
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!", font1, (java.awt.Paint) color2, 1.0f);
        java.awt.Font font6 = textFragment5.getFont();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape11);
        statisticalBarRenderer7.setSeriesShape((int) (short) 0, shape11);
        statisticalBarRenderer7.setAutoPopulateSeriesShape(false);
        java.util.EventListener eventListener16 = null;
        boolean boolean17 = statisticalBarRenderer7.hasListener(eventListener16);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity23 = new org.jfree.chart.entity.ChartEntity(shape22);
        statisticalBarRenderer18.setSeriesShape((int) (short) 0, shape22);
        java.lang.Object obj25 = statisticalBarRenderer18.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition();
        statisticalBarRenderer18.setBasePositiveItemLabelPosition(itemLabelPosition26);
        statisticalBarRenderer7.setBaseNegativeItemLabelPosition(itemLabelPosition26);
        java.lang.Boolean boolean30 = statisticalBarRenderer7.getSeriesVisibleInLegend(2);
        boolean boolean31 = textFragment5.equals((java.lang.Object) boolean30);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNull(boolean30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = statisticalBarRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation3 = null;
        org.jfree.chart.util.Layer layer4 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            statisticalBarRenderer0.addAnnotation(categoryAnnotation3, layer4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertNotNull(layer4);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Paint paint9 = statisticalBarRenderer0.lookupSeriesPaint(0);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset10 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset10);
        defaultStatisticalCategoryDataset10.validateObject();
        int int13 = defaultStatisticalCategoryDataset10.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("");
        int int16 = categoryAxis15.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity23 = new org.jfree.chart.entity.ChartEntity(shape22);
        statisticalBarRenderer18.setSeriesShape((int) (short) 0, shape22);
        statisticalBarRenderer18.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset10, categoryAxis15, valueAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer18);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot28.setDatasetRenderingOrder(datasetRenderingOrder29);
        statisticalBarRenderer0.setPlot(categoryPlot28);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        java.awt.Color color19 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass20 = color19.getClass();
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine("");
        boolean boolean24 = textLine22.equals((java.lang.Object) (-1L));
        org.jfree.chart.text.TextFragment textFragment25 = null;
        textLine22.removeFragment(textFragment25);
        boolean boolean27 = color19.equals((java.lang.Object) textLine22);
        int int28 = color19.getBlue();
        categoryPlot18.setOutlinePaint((java.awt.Paint) color19);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment30 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment31 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement34 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment30, verticalAlignment31, (double) 10L, (double) 'a');
        org.jfree.chart.block.BlockContainer blockContainer35 = new org.jfree.chart.block.BlockContainer();
        double double36 = blockContainer35.getContentYOffset();
        double double37 = blockContainer35.getWidth();
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke42 = categoryAxis41.getTickMarkStroke();
        java.awt.Stroke stroke43 = categoryAxis41.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color39, stroke43);
        flowArrangement34.add((org.jfree.chart.block.Block) blockContainer35, (java.lang.Object) stroke43);
        categoryPlot18.setRangeGridlineStroke(stroke43);
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        try {
            categoryPlot18.setRangeAxis((-16776961), valueAxis48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 192 + "'", int28 == 192);
        org.junit.Assert.assertNotNull(verticalAlignment31);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke43);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=0,g=255,b=255]", "", "hi!", "");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo9 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=0,g=255,b=255]", "", "hi!", "");
        basicProjectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo9);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo15 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=0,g=255,b=255]", "", "hi!", "");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo20 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=0,g=255,b=255]", "", "hi!", "");
        basicProjectInfo15.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo20);
        basicProjectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo20);
        org.jfree.chart.ui.Library[] libraryArray23 = basicProjectInfo20.getLibraries();
        java.lang.String str24 = basicProjectInfo20.getVersion();
        org.jfree.chart.ui.Library[] libraryArray25 = basicProjectInfo20.getLibraries();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean27 = statisticalBarRenderer26.getAutoPopulateSeriesStroke();
        statisticalBarRenderer26.setIncludeBaseInRange(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = null;
        statisticalBarRenderer26.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition31);
        statisticalBarRenderer26.setSeriesVisibleInLegend((int) (byte) 10, (java.lang.Boolean) true);
        boolean boolean36 = basicProjectInfo20.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(libraryArray23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(libraryArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!", font1, (java.awt.Paint) color2, 1.0f);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        try {
            textFragment5.draw(graphics2D6, 0.0f, (float) 0, textAnchor9, (float) 15, (float) ' ', 0.05d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertNotNull(textAnchor9);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape26);
        statisticalBarRenderer22.setSeriesShape((int) (short) 0, shape26);
        java.lang.Object obj29 = statisticalBarRenderer22.clone();
        java.awt.Paint paint31 = statisticalBarRenderer22.lookupSeriesFillPaint(192);
        categoryPlot18.setRenderer((int) (short) 0, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22, false);
        java.awt.Paint paint34 = categoryPlot18.getOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = categoryPlot18.getDomainAxis();
        java.lang.String str36 = categoryPlot18.getPlotType();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation37 = null;
        try {
            boolean boolean38 = categoryPlot18.removeAnnotation(categoryAnnotation37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(categoryAxis35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Category Plot" + "'", str36.equals("Category Plot"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint5 = categoryAxis3.getTickLabelPaint((java.lang.Comparable) "hi!");
        double double6 = categoryAxis3.getLowerMargin();
        keyedObjects0.setObject((java.lang.Comparable) false, (java.lang.Object) double6);
        java.util.List list8 = keyedObjects0.getKeys();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getTickLabelFont();
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=0,g=255,b=255]", "", "hi!", "");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo9 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=0,g=255,b=255]", "", "hi!", "");
        basicProjectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo9);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo15 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=0,g=255,b=255]", "", "hi!", "");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo20 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=0,g=255,b=255]", "", "hi!", "");
        basicProjectInfo15.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo20);
        basicProjectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo20);
        org.jfree.chart.ui.Library[] libraryArray23 = basicProjectInfo20.getLibraries();
        java.lang.String str24 = basicProjectInfo20.getVersion();
        org.jfree.chart.ui.Library[] libraryArray25 = basicProjectInfo20.getLibraries();
        java.lang.String str26 = basicProjectInfo20.getLicenceName();
        org.junit.Assert.assertNotNull(libraryArray23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(libraryArray25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        categoryAxis3.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        java.lang.Object obj8 = categoryAxis3.clone();
        java.awt.Font font10 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 1.0d);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder((double) 10.0f, (double) 100, 10.0d, (double) 2, (java.awt.Paint) color15);
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font10, (java.awt.Paint) color15);
        org.jfree.chart.text.TextLine textLine18 = new org.jfree.chart.text.TextLine("", font10);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(textBlock17);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = null;
        double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.awt.Color color1 = java.awt.Color.getColor("{0}");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        categoryAxis1.setCategoryLabelPositionOffset((int) (byte) 0);
        java.lang.Object obj5 = categoryAxis1.clone();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset7 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset7);
        defaultStatisticalCategoryDataset7.validateObject();
        int int10 = defaultStatisticalCategoryDataset7.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        int int13 = categoryAxis12.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity(shape19);
        statisticalBarRenderer15.setSeriesShape((int) (short) 0, shape19);
        statisticalBarRenderer15.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset7, categoryAxis12, valueAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer15);
        categoryPlot25.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener28 = null;
        categoryPlot25.addChangeListener(plotChangeListener28);
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset31 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset31);
        defaultStatisticalCategoryDataset31.validateObject();
        int int34 = defaultStatisticalCategoryDataset31.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        int int37 = categoryAxis36.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer39 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape43 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity44 = new org.jfree.chart.entity.ChartEntity(shape43);
        statisticalBarRenderer39.setSeriesShape((int) (short) 0, shape43);
        statisticalBarRenderer39.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset31, categoryAxis36, valueAxis38, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer39);
        java.awt.Color color50 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass51 = color50.getClass();
        org.jfree.chart.text.TextLine textLine53 = new org.jfree.chart.text.TextLine("");
        boolean boolean55 = textLine53.equals((java.lang.Object) (-1L));
        org.jfree.chart.text.TextFragment textFragment56 = null;
        textLine53.removeFragment(textFragment56);
        boolean boolean58 = color50.equals((java.lang.Object) textLine53);
        int int59 = color50.getBlue();
        categoryPlot49.setOutlinePaint((java.awt.Paint) color50);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment61 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment62 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement65 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment61, verticalAlignment62, (double) 10L, (double) 'a');
        org.jfree.chart.block.BlockContainer blockContainer66 = new org.jfree.chart.block.BlockContainer();
        double double67 = blockContainer66.getContentYOffset();
        double double68 = blockContainer66.getWidth();
        java.awt.Color color70 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis72 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke73 = categoryAxis72.getTickMarkStroke();
        java.awt.Stroke stroke74 = categoryAxis72.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker75 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color70, stroke74);
        flowArrangement65.add((org.jfree.chart.block.Block) blockContainer66, (java.lang.Object) stroke74);
        categoryPlot49.setRangeGridlineStroke(stroke74);
        categoryPlot49.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge81 = categoryPlot49.getDomainAxisEdge((-16776961));
        org.jfree.chart.axis.AxisSpace axisSpace82 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace83 = categoryAxis1.reserveSpace(graphics2D6, (org.jfree.chart.plot.Plot) categoryPlot25, rectangle2D30, rectangleEdge81, axisSpace82);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 192 + "'", int59 == 192);
        org.junit.Assert.assertNotNull(verticalAlignment62);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(rectangleEdge81);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape8);
        statisticalBarRenderer4.setSeriesShape((int) (short) 0, shape8);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke13 = categoryAxis12.getTickMarkStroke();
        java.awt.Stroke stroke14 = categoryAxis12.getAxisLineStroke();
        java.awt.Color color15 = java.awt.Color.cyan;
        java.lang.String str16 = color15.toString();
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "", "", "hi!", shape8, stroke14, (java.awt.Paint) color15);
        int int18 = legendItem17.getSeriesIndex();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "java.awt.Color[r=0,g=255,b=255]" + "'", str16.equals("java.awt.Color[r=0,g=255,b=255]"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = rectangleConstraint2.getHeightConstraintType();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        boolean boolean19 = statisticalBarRenderer8.getAutoPopulateSeriesFillPaint();
        java.awt.Paint paint21 = statisticalBarRenderer8.getSeriesFillPaint(500);
        java.lang.Boolean boolean23 = statisticalBarRenderer8.getSeriesItemLabelsVisible((int) (short) -1);
        statisticalBarRenderer8.setBaseItemLabelsVisible(false, true);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset28 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset28);
        defaultStatisticalCategoryDataset28.validateObject();
        int int31 = defaultStatisticalCategoryDataset28.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        int int34 = categoryAxis33.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer36 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape40 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity41 = new org.jfree.chart.entity.ChartEntity(shape40);
        statisticalBarRenderer36.setSeriesShape((int) (short) 0, shape40);
        statisticalBarRenderer36.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset28, categoryAxis33, valueAxis35, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer36);
        categoryPlot46.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener49 = null;
        categoryPlot46.addChangeListener(plotChangeListener49);
        float float51 = categoryPlot46.getBackgroundAlpha();
        int int52 = categoryPlot46.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace53 = null;
        categoryPlot46.setFixedRangeAxisSpace(axisSpace53);
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        try {
            statisticalBarRenderer8.drawRangeGridline(graphics2D27, categoryPlot46, valueAxis55, rectangle2D56, (double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNull(boolean23);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertTrue("'" + float51 + "' != '" + 1.0f + "'", float51 == 1.0f);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        java.awt.Color color19 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass20 = color19.getClass();
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine("");
        boolean boolean24 = textLine22.equals((java.lang.Object) (-1L));
        org.jfree.chart.text.TextFragment textFragment25 = null;
        textLine22.removeFragment(textFragment25);
        boolean boolean27 = color19.equals((java.lang.Object) textLine22);
        int int28 = color19.getBlue();
        categoryPlot18.setOutlinePaint((java.awt.Paint) color19);
        org.jfree.chart.plot.Plot plot30 = categoryPlot18.getParent();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer31 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean32 = statisticalBarRenderer31.getAutoPopulateSeriesStroke();
        statisticalBarRenderer31.setIncludeBaseInRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke37 = categoryAxis36.getTickMarkStroke();
        statisticalBarRenderer31.setBaseOutlineStroke(stroke37);
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        statisticalBarRenderer31.setSeriesItemLabelPaint(0, (java.awt.Paint) color40, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint46 = categoryAxis44.getTickLabelPaint((java.lang.Comparable) "hi!");
        statisticalBarRenderer31.setBaseFillPaint(paint46, true);
        statisticalBarRenderer31.setItemMargin((double) 500);
        int int51 = categoryPlot18.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer31);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 192 + "'", int28 == 192);
        org.junit.Assert.assertNull(plot30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.shift(range0, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getHeightConstraintType();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Comparable comparable5 = null;
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, comparable5);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleConstraint2, (org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset4);
        int int9 = defaultStatisticalCategoryDataset4.getColumnIndex((java.lang.Comparable) (byte) 10);
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range5 = statisticalBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4);
        org.jfree.data.Range range7 = defaultStatisticalCategoryDataset4.getRangeBounds(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        java.lang.String str2 = rectangleEdge0.toString();
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleEdge.BOTTOM" + "'", str2.equals("RectangleEdge.BOTTOM"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke9 = categoryAxis8.getTickMarkStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke9);
        java.awt.Color color11 = java.awt.Color.cyan;
        statisticalBarRenderer0.setErrorIndicatorPaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = statisticalBarRenderer0.getSeriesOutlineStroke(100);
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(stroke14);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        boolean boolean9 = statisticalBarRenderer0.getItemCreateEntity(192, (int) (short) 0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = statisticalBarRenderer0.getSeriesItemLabelGenerator((int) (byte) -1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator11);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape8);
        statisticalBarRenderer4.setSeriesShape((int) (short) 0, shape8);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("", "", "", "java.awt.Color[r=0,g=255,b=255]", shape8, (java.awt.Paint) color11);
        java.awt.Paint paint13 = legendItem12.getOutlinePaint();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            rectangleInsets0.trim(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        statisticalBarRenderer8.setBaseSeriesVisibleInLegend(true, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation22 = null;
        try {
            statisticalBarRenderer8.addAnnotation(categoryAnnotation22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator4 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator5 = null;
        java.lang.String str6 = chartEntity3.getImageMapAreaTag(toolTipTagFragmentGenerator4, uRLTagFragmentGenerator5);
        java.lang.String str7 = chartEntity3.getToolTipText();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        statisticalBarRenderer0.setAutoPopulateSeriesShape(false);
        java.util.EventListener eventListener9 = null;
        boolean boolean10 = statisticalBarRenderer0.hasListener(eventListener9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_BLUE;
        statisticalBarRenderer0.setErrorIndicatorPaint((java.awt.Paint) color11);
        boolean boolean15 = statisticalBarRenderer0.getItemCreateEntity(15, 2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = statisticalBarRenderer0.getSeriesNegativeItemLabelPosition(2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.POSITIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        java.awt.Stroke stroke5 = categoryAxis3.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color1, stroke5);
        valueMarker6.setValue((double) 192);
        org.jfree.data.Range range9 = null;
        org.jfree.data.Range range10 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint(range9, range10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType12 = rectangleConstraint11.getHeightConstraintType();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset13 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Comparable comparable14 = null;
        org.jfree.data.general.PieDataset pieDataset15 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset13, comparable14);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleConstraint11, (org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset13);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        float float19 = categoryAxis18.getTickMarkOutsideLength();
        categoryAxis18.setCategoryLabelPositionOffset((int) (byte) 0);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity28 = new org.jfree.chart.entity.ChartEntity(shape27);
        statisticalBarRenderer23.setSeriesShape((int) (short) 0, shape27);
        statisticalBarRenderer23.setAutoPopulateSeriesShape(false);
        java.util.EventListener eventListener32 = null;
        boolean boolean33 = statisticalBarRenderer23.hasListener(eventListener32);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer34 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape38 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity39 = new org.jfree.chart.entity.ChartEntity(shape38);
        statisticalBarRenderer34.setSeriesShape((int) (short) 0, shape38);
        java.lang.Object obj41 = statisticalBarRenderer34.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition42 = new org.jfree.chart.labels.ItemLabelPosition();
        statisticalBarRenderer34.setBasePositiveItemLabelPosition(itemLabelPosition42);
        statisticalBarRenderer23.setBaseNegativeItemLabelPosition(itemLabelPosition42);
        java.lang.Object obj45 = statisticalBarRenderer23.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset13, categoryAxis18, valueAxis22, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer23);
        valueMarker6.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot46);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(lengthConstraintType12);
        org.junit.Assert.assertNotNull(pieDataset15);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNotNull(obj45);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockContainer4.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame6 = blockContainer4.getFrame();
        double double7 = blockContainer4.getWidth();
        java.awt.geom.Rectangle2D rectangle2D8 = blockContainer4.getBounds();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        plotRenderingInfo12.addSubplotInfo(plotRenderingInfo14);
        java.lang.Object obj16 = plotRenderingInfo12.clone();
        try {
            org.jfree.chart.axis.AxisState axisState17 = categoryAxis1.draw(graphics2D2, Double.NaN, rectangle2D8, rectangle2D9, rectangleEdge10, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(blockFrame6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        java.awt.Font font20 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis5.setTickLabelFont((java.lang.Comparable) 100.0d, font20);
        categoryAxis5.setCategoryMargin((double) 255);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.function.Function2D function2D0 = null;
        java.lang.Comparable comparable4 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 0.0d, 0.2d, (int) '4', comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesItemLabelPaint(0, (java.awt.Paint) color9, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer12.getAutoPopulateSeriesStroke();
        statisticalBarRenderer12.setIncludeBaseInRange(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        statisticalBarRenderer12.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition17);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = statisticalBarRenderer12.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset22 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset22);
        defaultStatisticalCategoryDataset22.validateObject();
        int int25 = defaultStatisticalCategoryDataset22.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("");
        int int28 = categoryAxis27.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape34 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity35 = new org.jfree.chart.entity.ChartEntity(shape34);
        statisticalBarRenderer30.setSeriesShape((int) (short) 0, shape34);
        statisticalBarRenderer30.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset22, categoryAxis27, valueAxis29, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer30);
        boolean boolean41 = statisticalBarRenderer30.getAutoPopulateSeriesFillPaint();
        java.awt.Paint paint43 = statisticalBarRenderer30.getSeriesFillPaint(500);
        java.lang.Boolean boolean45 = statisticalBarRenderer30.getSeriesItemLabelsVisible((int) (short) -1);
        java.awt.Shape shape48 = statisticalBarRenderer30.getItemShape((int) ' ', (int) (short) 1);
        org.jfree.chart.entity.ChartEntity chartEntity49 = new org.jfree.chart.entity.ChartEntity(shape48);
        try {
            statisticalBarRenderer0.setSeriesShape((-1), shape48, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator19);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(paint43);
        org.junit.Assert.assertNull(boolean45);
        org.junit.Assert.assertNotNull(shape48);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 0, 10.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesItemLabelPaint(0, (java.awt.Paint) color9, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint15 = categoryAxis13.getTickLabelPaint((java.lang.Comparable) "hi!");
        statisticalBarRenderer0.setBaseFillPaint(paint15, true);
        statisticalBarRenderer0.setItemMargin((double) 500);
        java.awt.Paint paint21 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        statisticalBarRenderer0.setSeriesPaint((int) (byte) 1, paint21);
        statisticalBarRenderer0.setItemLabelAnchorOffset((double) 10.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=64,g=64,b=64]", font1);
        float float3 = textFragment2.getBaselineOffset();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        categoryAxis1.setCategoryLabelPositionOffset((int) (byte) 0);
        java.lang.String str5 = categoryAxis1.getLabel();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        double double2 = rectangleInsets1.getTop();
        double double4 = rectangleInsets1.calculateTopInset((double) (-1));
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        categoryAxis1.setCategoryLabelPositionOffset((int) (byte) 0);
        java.awt.Font font5 = categoryAxis1.getLabelFont();
        org.jfree.chart.event.AxisChangeListener axisChangeListener6 = null;
        categoryAxis1.addChangeListener(axisChangeListener6);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        java.awt.Stroke stroke3 = categoryAxis1.getAxisLineStroke();
        java.lang.String str4 = categoryAxis1.getLabelURL();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = statisticalBarRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Shape shape4 = null;
        statisticalBarRenderer0.setSeriesShape(100, shape4);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = statisticalBarRenderer0.getBaseToolTipGenerator();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState8 = null;
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D10 = blockContainer9.getBounds();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset11 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset11);
        defaultStatisticalCategoryDataset11.validateObject();
        int int14 = defaultStatisticalCategoryDataset11.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        int int17 = categoryAxis16.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity(shape23);
        statisticalBarRenderer19.setSeriesShape((int) (short) 0, shape23);
        statisticalBarRenderer19.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset11, categoryAxis16, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer19);
        categoryPlot29.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer33 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape37 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity38 = new org.jfree.chart.entity.ChartEntity(shape37);
        statisticalBarRenderer33.setSeriesShape((int) (short) 0, shape37);
        java.lang.Object obj40 = statisticalBarRenderer33.clone();
        java.awt.Paint paint42 = statisticalBarRenderer33.lookupSeriesFillPaint(192);
        categoryPlot29.setRenderer((int) (short) 0, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer33, false);
        java.awt.Paint paint45 = categoryPlot29.getOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("");
        float float48 = categoryAxis47.getTickMarkOutsideLength();
        java.util.EventListener eventListener49 = null;
        boolean boolean50 = categoryAxis47.hasListener(eventListener49);
        categoryAxis47.setVisible(true);
        categoryAxis47.setCategoryMargin((double) (byte) 10);
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset56 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number57 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset56);
        org.jfree.data.general.PieDataset pieDataset59 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset56, (java.lang.Comparable) 10L);
        try {
            statisticalBarRenderer0.drawItem(graphics2D7, categoryItemRendererState8, rectangle2D10, categoryPlot29, categoryAxis47, valueAxis55, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset56, (-1), (int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 2.0f + "'", float48 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertEquals((double) number57, Double.NaN, 0);
        org.junit.Assert.assertNotNull(pieDataset59);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=0,g=255,b=255]", "", "hi!", "");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo9 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=0,g=255,b=255]", "", "hi!", "");
        basicProjectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo9);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo15 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=0,g=255,b=255]", "", "hi!", "");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo20 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=0,g=255,b=255]", "", "hi!", "");
        basicProjectInfo15.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo20);
        basicProjectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo20);
        org.jfree.chart.ui.Library[] libraryArray23 = basicProjectInfo20.getLibraries();
        java.lang.String str24 = basicProjectInfo20.getVersion();
        java.lang.Object obj25 = null;
        boolean boolean26 = basicProjectInfo20.equals(obj25);
        org.junit.Assert.assertNotNull(libraryArray23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        org.jfree.chart.renderer.RendererState rendererState3 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo2);
        java.lang.Class<?> wildcardClass4 = rendererState3.getClass();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass6 = color5.getClass();
        java.lang.Object obj7 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ItemLabelAnchor.OUTSIDE1", (java.lang.Class) wildcardClass4, (java.lang.Class) wildcardClass6);
        java.net.URL uRL8 = org.jfree.chart.util.ObjectUtilities.getResource("RectangleEdge.BOTTOM", (java.lang.Class) wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNull(uRL8);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        double double2 = rectangleInsets1.getTop();
        double double3 = rectangleInsets1.getBottom();
        double double5 = rectangleInsets1.trimHeight(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.block.CenterArrangement centerArrangement4 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.Block block5 = null;
        org.jfree.chart.util.StrokeList strokeList6 = new org.jfree.chart.util.StrokeList();
        strokeList6.clear();
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        boolean boolean9 = strokeList6.equals((java.lang.Object) textAnchor8);
        centerArrangement4.add(block5, (java.lang.Object) textAnchor8);
        try {
            java.awt.geom.Rectangle2D rectangle2D11 = org.jfree.chart.text.TextUtilities.drawAlignedString("java.awt.Color[r=64,g=64,b=64]", graphics2D1, (float) 4, 100.0f, textAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        statisticalBarRenderer0.setAutoPopulateSeriesShape(false);
        java.lang.Boolean boolean10 = statisticalBarRenderer0.getSeriesVisible(2);
        int int11 = statisticalBarRenderer0.getPassCount();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = null;
        org.jfree.chart.renderer.RendererState rendererState2 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo1);
        java.lang.Class<?> wildcardClass3 = rendererState2.getClass();
        java.lang.ClassLoader classLoader4 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass3);
        java.io.InputStream inputStream5 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("NOID", (java.lang.Class) wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(classLoader4);
        org.junit.Assert.assertNull(inputStream5);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        int int3 = java.awt.Color.HSBtoRGB((float) (-1), 2.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        boolean boolean4 = textBlockAnchor2.equals((java.lang.Object) (short) 0);
        org.jfree.chart.block.CenterArrangement centerArrangement5 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.Block block6 = null;
        org.jfree.chart.util.StrokeList strokeList7 = new org.jfree.chart.util.StrokeList();
        strokeList7.clear();
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        boolean boolean10 = strokeList7.equals((java.lang.Object) textAnchor9);
        centerArrangement5.add(block6, (java.lang.Object) textAnchor9);
        org.jfree.chart.axis.CategoryTick categoryTick13 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) (-1.0d), textBlock1, textBlockAnchor2, textAnchor9, (double) 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor14 = categoryTick13.getRotationAnchor();
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(textAnchor14);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.expand(range0, (double) (byte) 10, (double) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor2);
        float float4 = categoryLabelPosition3.getWidthRatio();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition8 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor6, textBlockAnchor7);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition8);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = categoryLabelPositions9.getLabelPosition(rectangleEdge10);
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rectangleEdge10, jFreeChart12, chartChangeEventType13);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.95f + "'", float4 == 0.95f);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(categoryLabelPosition11);
        org.junit.Assert.assertNotNull(chartChangeEventType13);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        org.jfree.chart.axis.AxisSpace axisSpace19 = categoryPlot18.getFixedDomainAxisSpace();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(axisSpace19);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 1.0f, (double) 100L);
        boolean boolean4 = meanAndStandardDeviation2.equals((java.lang.Object) 0L);
        java.lang.Number number5 = meanAndStandardDeviation2.getMean();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.0d + "'", number5.equals(1.0d));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        java.awt.Stroke stroke23 = categoryPlot18.getDomainGridlineStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        java.awt.geom.Point2D point2D28 = null;
        categoryPlot18.zoomDomainAxes((double) (short) 0, 0.0d, plotRenderingInfo27, point2D28);
        int int30 = plotRenderingInfo27.getSubplotCount();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 0.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge3);
        axisState1.moveCursor(0.0d, rectangleEdge3);
        double double6 = axisState1.getMax();
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        statisticalBarRenderer2.setSeriesShape((int) (short) 0, shape6);
        java.lang.Object obj9 = statisticalBarRenderer2.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = new org.jfree.chart.labels.ItemLabelPosition();
        statisticalBarRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition10);
        double double12 = statisticalBarRenderer2.getItemLabelAnchorOffset();
        boolean boolean13 = rectangleEdge0.equals((java.lang.Object) double12);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = shapeList0.getShape((int) (byte) 0);
        java.lang.Object obj3 = shapeList0.clone();
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextFillPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { (short) 100, 1L, (byte) -1, 0.5f };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (short) 100, 1L, (byte) -1, 0.5f };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (short) 100, 1L, (byte) -1, 0.5f };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (short) 100, 1L, (byte) -1, 0.5f };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (short) 100, 1L, (byte) -1, 0.5f };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (short) 100, 1L, (byte) -1, 0.5f };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ItemLabelAnchor.INSIDE12", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", numberArray32);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass1 = color0.getClass();
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("");
        boolean boolean5 = textLine3.equals((java.lang.Object) (-1L));
        org.jfree.chart.text.TextFragment textFragment6 = null;
        textLine3.removeFragment(textFragment6);
        boolean boolean8 = color0.equals((java.lang.Object) textLine3);
        int int9 = color0.getBlue();
        int int10 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 192 + "'", int9 == 192);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor2);
        float float4 = categoryLabelPosition3.getWidthRatio();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition3);
        org.jfree.chart.text.TextAnchor textAnchor6 = categoryLabelPosition3.getRotationAnchor();
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.95f + "'", float4 == 0.95f);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame2 = blockContainer0.getFrame();
        double double3 = blockContainer0.getWidth();
        double double4 = blockContainer0.getHeight();
        double double5 = blockContainer0.getHeight();
        blockContainer0.setMargin((double) 3, 0.0d, (double) 'a', 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(blockFrame2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.AxisState axisState2 = new org.jfree.chart.axis.AxisState();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke7 = categoryAxis6.getTickMarkStroke();
        java.awt.Stroke stroke8 = categoryAxis6.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color4, stroke8);
        java.awt.image.ColorModel colorModel10 = null;
        java.awt.Rectangle rectangle11 = null;
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockContainer12.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame14 = blockContainer12.getFrame();
        double double15 = blockContainer12.getWidth();
        java.awt.geom.Rectangle2D rectangle2D16 = blockContainer12.getBounds();
        java.awt.geom.AffineTransform affineTransform17 = null;
        java.awt.RenderingHints renderingHints18 = null;
        java.awt.PaintContext paintContext19 = color4.createContext(colorModel10, rectangle11, rectangle2D16, affineTransform17, renderingHints18);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge20);
        try {
            java.util.List list22 = categoryAxis0.refreshTicks(graphics2D1, axisState2, (java.awt.geom.Rectangle2D) rectangle11, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(blockFrame14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(paintContext19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        boolean boolean19 = statisticalBarRenderer8.getAutoPopulateSeriesFillPaint();
        java.awt.Paint paint21 = statisticalBarRenderer8.getSeriesFillPaint(500);
        statisticalBarRenderer8.setItemLabelAnchorOffset((double) (byte) -1);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator26 = statisticalBarRenderer8.getToolTipGenerator(15, 0);
        boolean boolean27 = statisticalBarRenderer8.getBaseSeriesVisible();
        java.awt.Paint paint28 = statisticalBarRenderer8.getBasePaint();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNull(categoryToolTipGenerator26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("ClassContext", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "RectangleEdge.BOTTOM", "");
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        java.lang.Object obj1 = null;
        boolean boolean2 = categoryLabelPositions0.equals(obj1);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = textBlock0.getLastLine();
        org.junit.Assert.assertNull(textLine1);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range5 = statisticalBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4);
        java.awt.Paint paint7 = statisticalBarRenderer0.getSeriesItemLabelPaint(2);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace10 = color9.getColorSpace();
        int int11 = color9.getRed();
        try {
            statisticalBarRenderer0.setSeriesPaint((int) (byte) -1, (java.awt.Paint) color9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(colorSpace10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 128 + "'", int11 == 128);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setFixedDimension((double) 2.0f);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis1);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        java.util.Collection collection24 = categoryPlot18.getDomainMarkers(15, layer22);
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset26 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset26);
        defaultStatisticalCategoryDataset26.validateObject();
        int int29 = defaultStatisticalCategoryDataset26.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("");
        int int32 = categoryAxis31.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer34 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape38 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity39 = new org.jfree.chart.entity.ChartEntity(shape38);
        statisticalBarRenderer34.setSeriesShape((int) (short) 0, shape38);
        statisticalBarRenderer34.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset26, categoryAxis31, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer34);
        categoryPlot44.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener47 = null;
        categoryPlot44.addChangeListener(plotChangeListener47);
        org.jfree.chart.axis.AxisLocation axisLocation50 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot44.setRangeAxisLocation(0, axisLocation50);
        categoryPlot44.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double56 = rectangleInsets54.calculateTopInset((-1.0d));
        double double58 = rectangleInsets54.calculateBottomOutset((double) 10L);
        categoryPlot44.setInsets(rectangleInsets54, true);
        java.lang.String str61 = categoryPlot44.getPlotType();
        org.jfree.chart.util.Layer layer63 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str64 = layer63.toString();
        java.util.Collection collection65 = categoryPlot44.getRangeMarkers(100, layer63);
        try {
            categoryPlot18.addDomainMarker(categoryMarker25, layer63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(axisLocation50);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "Category Plot" + "'", str61.equals("Category Plot"));
        org.junit.Assert.assertNotNull(layer63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "Layer.FOREGROUND" + "'", str64.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection65);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        boolean boolean4 = textBlockAnchor2.equals((java.lang.Object) (short) 0);
        org.jfree.chart.block.CenterArrangement centerArrangement5 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.Block block6 = null;
        org.jfree.chart.util.StrokeList strokeList7 = new org.jfree.chart.util.StrokeList();
        strokeList7.clear();
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        boolean boolean10 = strokeList7.equals((java.lang.Object) textAnchor9);
        centerArrangement5.add(block6, (java.lang.Object) textAnchor9);
        org.jfree.chart.axis.CategoryTick categoryTick13 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) (-1.0d), textBlock1, textBlockAnchor2, textAnchor9, (double) 0.0f);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = categoryTick13.getLabelAnchor();
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke6);
        boolean boolean8 = statisticalBarRenderer0.getBaseSeriesVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        try {
            java.awt.Color color1 = java.awt.Color.decode("Layer.FOREGROUND");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Layer.FOREGROUND\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 10L, (double) 'a');
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer();
        double double6 = blockContainer5.getContentYOffset();
        double double7 = blockContainer5.getWidth();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke12 = categoryAxis11.getTickMarkStroke();
        java.awt.Stroke stroke13 = categoryAxis11.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color9, stroke13);
        flowArrangement4.add((org.jfree.chart.block.Block) blockContainer5, (java.lang.Object) stroke13);
        org.jfree.chart.block.BlockContainer blockContainer16 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = blockContainer16.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame18 = blockContainer16.getFrame();
        double double19 = blockContainer16.getWidth();
        double double20 = blockContainer16.getHeight();
        boolean boolean21 = blockContainer16.isEmpty();
        boolean boolean22 = blockContainer16.isEmpty();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset23 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset23);
        defaultStatisticalCategoryDataset23.validateObject();
        int int26 = defaultStatisticalCategoryDataset23.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        int int29 = categoryAxis28.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer31 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity36 = new org.jfree.chart.entity.ChartEntity(shape35);
        statisticalBarRenderer31.setSeriesShape((int) (short) 0, shape35);
        statisticalBarRenderer31.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset23, categoryAxis28, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer31);
        categoryPlot41.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener44 = null;
        categoryPlot41.addChangeListener(plotChangeListener44);
        org.jfree.chart.axis.AxisLocation axisLocation47 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot41.setRangeAxisLocation(0, axisLocation47);
        categoryPlot41.setRangeCrosshairVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double53 = rectangleInsets51.calculateTopInset((-1.0d));
        double double55 = rectangleInsets51.calculateBottomOutset((double) 10L);
        categoryPlot41.setInsets(rectangleInsets51, true);
        double double59 = rectangleInsets51.trimHeight((double) 100);
        try {
            blockContainer5.add((org.jfree.chart.block.Block) blockContainer16, (java.lang.Object) rectangleInsets51);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.util.RectangleInsets cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(blockFrame18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 100.0d + "'", double59 == 100.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("Category Plot", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE1" + "'", str1.equals("ItemLabelAnchor.INSIDE1"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateX((double) 500);
        boolean boolean3 = blockParams0.getGenerateEntities();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range5 = statisticalBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4);
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Paint paint8 = statisticalBarRenderer0.getBaseItemLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        java.awt.Shape shape5 = statisticalBarRenderer0.lookupSeriesShape((int) (byte) 10);
        statisticalBarRenderer0.setBaseSeriesVisible(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean9 = statisticalBarRenderer8.getAutoPopulateSeriesStroke();
        statisticalBarRenderer8.setIncludeBaseInRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke14 = categoryAxis13.getTickMarkStroke();
        statisticalBarRenderer8.setBaseOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        statisticalBarRenderer8.setSeriesItemLabelPaint(0, (java.awt.Paint) color17, false);
        statisticalBarRenderer0.setBaseFillPaint((java.awt.Paint) color17, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        statisticalBarRenderer0.setAutoPopulateSeriesShape(false);
        java.awt.Font font11 = statisticalBarRenderer0.getItemLabelFont(255, 0);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset12 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12);
        defaultStatisticalCategoryDataset12.validateObject();
        int int15 = defaultStatisticalCategoryDataset12.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        int int18 = categoryAxis17.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity25 = new org.jfree.chart.entity.ChartEntity(shape24);
        statisticalBarRenderer20.setSeriesShape((int) (short) 0, shape24);
        statisticalBarRenderer20.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12, categoryAxis17, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer20);
        categoryPlot30.setRangeCrosshairLockedOnData(false);
        java.awt.Stroke stroke33 = categoryPlot30.getRangeCrosshairStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = categoryPlot30.getDomainAxis(3);
        statisticalBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot30);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNull(categoryAxis35);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesItemLabelPaint(0, (java.awt.Paint) color9, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer12.getAutoPopulateSeriesStroke();
        statisticalBarRenderer12.setIncludeBaseInRange(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        statisticalBarRenderer12.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition17);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = statisticalBarRenderer12.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        java.awt.Stroke stroke22 = statisticalBarRenderer0.lookupSeriesStroke(10);
        boolean boolean24 = statisticalBarRenderer0.isSeriesVisible((int) '4');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator25 = null;
        statisticalBarRenderer0.setBaseURLGenerator(categoryURLGenerator25, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        java.awt.Stroke stroke5 = categoryAxis3.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color1, stroke5);
        valueMarker6.setValue((double) 192);
        java.awt.Stroke stroke9 = valueMarker6.getStroke();
        org.jfree.chart.block.BlockBorder blockBorder10 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = blockBorder10.getInsets();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        boolean boolean13 = rectangleInsets11.equals((java.lang.Object) color12);
        valueMarker6.setOutlinePaint((java.awt.Paint) color12);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(blockBorder10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape1, Double.NaN, (float) (byte) 100, (float) 0);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) (-1L));
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset2, (java.lang.Comparable) "-1,100,-100,100,-100,1,100,1,100,100,1,100,1,-100,100,-100,100,-1,-100,-1,-100,-100,-1,-100,-1,-100", 0.0d);
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertNotNull(pieDataset5);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        java.awt.Stroke stroke5 = categoryAxis3.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color1, stroke5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = valueMarker6.getLabelAnchor();
        java.awt.Paint paint8 = valueMarker6.getLabelPaint();
        java.awt.Stroke stroke9 = valueMarker6.getStroke();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape14);
        statisticalBarRenderer10.setSeriesShape((int) (short) 0, shape14);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke19 = categoryAxis18.getTickMarkStroke();
        statisticalBarRenderer10.setBaseOutlineStroke(stroke19);
        java.awt.Color color21 = java.awt.Color.cyan;
        statisticalBarRenderer10.setErrorIndicatorPaint((java.awt.Paint) color21);
        valueMarker6.setOutlinePaint((java.awt.Paint) color21);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        boolean boolean19 = statisticalBarRenderer8.getAutoPopulateSeriesFillPaint();
        java.awt.Paint paint21 = statisticalBarRenderer8.getSeriesFillPaint(500);
        java.lang.Boolean boolean23 = statisticalBarRenderer8.getSeriesItemLabelsVisible((int) (short) -1);
        java.awt.Shape shape26 = statisticalBarRenderer8.getItemShape((int) ' ', (int) (short) 1);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer28 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean29 = statisticalBarRenderer28.getAutoPopulateSeriesStroke();
        statisticalBarRenderer28.setIncludeBaseInRange(false);
        statisticalBarRenderer28.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = new org.jfree.chart.labels.ItemLabelPosition();
        double double38 = itemLabelPosition37.getAngle();
        statisticalBarRenderer28.setSeriesPositiveItemLabelPosition(192, itemLabelPosition37, false);
        statisticalBarRenderer8.setSeriesNegativeItemLabelPosition(0, itemLabelPosition37);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNull(boolean23);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 2.0f);
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement3 = blockContainer2.getArrangement();
        boolean boolean4 = valueMarker1.equals((java.lang.Object) arrangement3);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset5 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5);
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5, (java.lang.Comparable) 10L);
        double double9 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset8);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer11 = new org.jfree.chart.title.LegendItemBlockContainer(arrangement3, (org.jfree.data.general.Dataset) pieDataset8, (java.lang.Comparable) '#');
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = blockContainer13.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame15 = blockContainer13.getFrame();
        double double16 = blockContainer13.getWidth();
        java.awt.geom.Rectangle2D rectangle2D17 = blockContainer13.getBounds();
        org.jfree.chart.block.BlockBorder blockBorder18 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockBorder18.getInsets();
        try {
            java.lang.Object obj20 = legendItemBlockContainer11.draw(graphics2D12, rectangle2D17, (java.lang.Object) rectangleInsets19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(arrangement3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertEquals((double) number6, Double.NaN, 0);
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(blockFrame15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(blockBorder18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset((double) (-1.0f));
        double double4 = rectangleInsets0.calculateTopInset((double) 10.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = categoryLabelPosition2.getLabelAnchor();
        double double4 = categoryLabelPosition2.getAngle();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(0.0d);
        axisState1.cursorDown((double) 0L);
        double double4 = axisState1.getCursor();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getTickMarkOutsideLength();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = categoryAxis2.hasListener(eventListener4);
        java.lang.String str6 = categoryAxis2.getLabelURL();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis2.setTickLabelFont((java.lang.Comparable) 0, font8);
        java.awt.Paint paint10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.axis.AxisState axisState12 = new org.jfree.chart.axis.AxisState((double) 0.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge14);
        axisState12.moveCursor(0.0d, rectangleEdge14);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor20 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition21 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor19, textBlockAnchor20);
        float float22 = categoryLabelPosition21.getWidthRatio();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = categoryLabelPosition21.getLabelAnchor();
        boolean boolean24 = horizontalAlignment18.equals((java.lang.Object) categoryLabelPosition21);
        org.jfree.chart.util.VerticalAlignment verticalAlignment25 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement28 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment18, verticalAlignment25, 1.0d, (double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font8, paint10, rectangleEdge14, horizontalAlignment17, verticalAlignment25, rectangleInsets29);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.data.Range range33 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType34 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.Range range36 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType37 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = new org.jfree.chart.block.RectangleConstraint((double) 0L, range33, lengthConstraintType34, 0.2d, range36, lengthConstraintType37);
        double double39 = rectangleConstraint38.getWidth();
        try {
            org.jfree.chart.util.Size2D size2D40 = textTitle30.arrange(graphics2D31, rectangleConstraint38);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(textBlockAnchor20);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.95f + "'", float22 == 0.95f);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(verticalAlignment25);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(lengthConstraintType34);
        org.junit.Assert.assertNotNull(lengthConstraintType37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        double double1 = blockContainer0.getContentYOffset();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset2);
        defaultStatisticalCategoryDataset2.validateObject();
        org.jfree.data.general.DatasetChangeListener datasetChangeListener5 = null;
        defaultStatisticalCategoryDataset2.addChangeListener(datasetChangeListener5);
        double double8 = defaultStatisticalCategoryDataset2.getRangeUpperBound(false);
        boolean boolean9 = blockContainer0.equals((java.lang.Object) defaultStatisticalCategoryDataset2);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset12 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12);
        defaultStatisticalCategoryDataset12.validateObject();
        int int15 = defaultStatisticalCategoryDataset12.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        int int18 = categoryAxis17.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity25 = new org.jfree.chart.entity.ChartEntity(shape24);
        statisticalBarRenderer20.setSeriesShape((int) (short) 0, shape24);
        statisticalBarRenderer20.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12, categoryAxis17, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer20);
        categoryPlot30.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener33 = null;
        categoryPlot30.addChangeListener(plotChangeListener33);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot30.setRangeAxisLocation(0, axisLocation36);
        try {
            java.lang.Object obj38 = blockContainer0.draw(graphics2D10, rectangle2D11, (java.lang.Object) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(axisLocation36);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape1, "ClassContext");
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getHeightConstraintType();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Comparable comparable5 = null;
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, comparable5);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleConstraint2, (org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset4);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        float float10 = categoryAxis9.getTickMarkOutsideLength();
        categoryAxis9.setCategoryLabelPositionOffset((int) (byte) 0);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape18);
        statisticalBarRenderer14.setSeriesShape((int) (short) 0, shape18);
        statisticalBarRenderer14.setAutoPopulateSeriesShape(false);
        java.util.EventListener eventListener23 = null;
        boolean boolean24 = statisticalBarRenderer14.hasListener(eventListener23);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity(shape29);
        statisticalBarRenderer25.setSeriesShape((int) (short) 0, shape29);
        java.lang.Object obj32 = statisticalBarRenderer25.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = new org.jfree.chart.labels.ItemLabelPosition();
        statisticalBarRenderer25.setBasePositiveItemLabelPosition(itemLabelPosition33);
        statisticalBarRenderer14.setBaseNegativeItemLabelPosition(itemLabelPosition33);
        java.lang.Object obj36 = statisticalBarRenderer14.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, categoryAxis9, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer14);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator39 = null;
        statisticalBarRenderer14.setSeriesItemLabelGenerator(15, categoryItemLabelGenerator39, false);
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(obj36);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot18.getRangeAxisEdge(0);
        categoryPlot18.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis27 = categoryPlot18.getRangeAxis();
        categoryPlot18.setWeight(500);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNull(valueAxis27);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.configureRangeAxes();
        java.awt.Paint paint20 = categoryPlot18.getRangeGridlinePaint();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor2);
        float float4 = categoryLabelPosition3.getWidthRatio();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition8 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor6, textBlockAnchor7);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition12 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor10, textBlockAnchor11);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = categoryLabelPosition12.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions14 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions9, categoryLabelPosition12);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.95f + "'", float4 == 0.95f);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(textBlockAnchor11);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertNotNull(categoryLabelPositions14);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (-1L), 2.0f);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        java.awt.Stroke stroke5 = categoryAxis3.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color1, stroke5);
        valueMarker6.setValue((double) 192);
        java.awt.Stroke stroke9 = valueMarker6.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = valueMarker6.getLabelOffset();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset11 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset11);
        defaultStatisticalCategoryDataset11.validateObject();
        int int14 = defaultStatisticalCategoryDataset11.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        int int17 = categoryAxis16.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity(shape23);
        statisticalBarRenderer19.setSeriesShape((int) (short) 0, shape23);
        statisticalBarRenderer19.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset11, categoryAxis16, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer19);
        categoryPlot29.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        categoryPlot29.addChangeListener(plotChangeListener32);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot29.getRangeAxisEdge(0);
        valueMarker6.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot29);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(rectangleEdge35);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range5 = statisticalBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, (double) (short) 0);
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertEquals((double) number8, Double.NaN, 0);
        org.junit.Assert.assertNull(range9);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D1 = blockContainer0.getBounds();
        org.jfree.chart.block.Arrangement arrangement2 = blockContainer0.getArrangement();
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNotNull(arrangement2);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        java.awt.Stroke stroke7 = categoryAxis5.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color3, stroke7);
        java.awt.image.ColorModel colorModel9 = null;
        java.awt.Rectangle rectangle10 = null;
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = blockContainer11.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame13 = blockContainer11.getFrame();
        double double14 = blockContainer11.getWidth();
        java.awt.geom.Rectangle2D rectangle2D15 = blockContainer11.getBounds();
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color3.createContext(colorModel9, rectangle10, rectangle2D15, affineTransform16, renderingHints17);
        textTitle0.draw(graphics2D1, rectangle2D15);
        textTitle0.setURLText("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(blockFrame13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(paintContext18);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesItemLabelPaint(0, (java.awt.Paint) color9, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer12.getAutoPopulateSeriesStroke();
        statisticalBarRenderer12.setIncludeBaseInRange(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        statisticalBarRenderer12.setSeriesPositiveItemLabelPosition((int) (short) 1, itemLabelPosition17);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = statisticalBarRenderer12.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        java.awt.Stroke stroke22 = statisticalBarRenderer0.lookupSeriesStroke(10);
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color23, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.Image image4 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo("java.awt.Color[r=0,g=255,b=255]", "VerticalAlignment.TOP", "hi!", image4, "", "ClassContext", "");
        projectInfo8.addOptionalLibrary("NOID");
        boolean boolean11 = categoryAnchor0.equals((java.lang.Object) "NOID");
        java.lang.String str12 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str12.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.awt.Color color1 = java.awt.Color.BLUE;
        int int2 = color1.getRGB();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke7 = categoryAxis6.getTickMarkStroke();
        java.awt.Stroke stroke8 = categoryAxis6.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color4, stroke8);
        valueMarker9.setValue((double) 192);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        valueMarker9.setOutlineStroke(stroke12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke17 = categoryAxis16.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (short) 100, (java.awt.Paint) color1, stroke12, (java.awt.Paint) color14, stroke17, (float) 0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = null;
        valueMarker19.notifyListeners(markerChangeEvent20);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16776961) + "'", int2 == (-16776961));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        boolean boolean8 = statisticalBarRenderer0.isSeriesItemLabelsVisible((int) (byte) 0);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        int int11 = color10.getAlpha();
        statisticalBarRenderer0.setSeriesFillPaint(500, (java.awt.Paint) color10, true);
        statisticalBarRenderer0.setItemLabelAnchorOffset((double) (byte) 1);
        java.awt.Paint paint16 = null;
        try {
            statisticalBarRenderer0.setBaseFillPaint(paint16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 0, (double) (byte) 10);
        double double3 = size2D2.height;
        double double4 = size2D2.width;
        java.lang.String str5 = size2D2.toString();
        java.lang.String str6 = size2D2.toString();
        size2D2.width = 10;
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Size2D[width=0.0, height=10.0]" + "'", str5.equals("Size2D[width=0.0, height=10.0]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Size2D[width=0.0, height=10.0]" + "'", str6.equals("Size2D[width=0.0, height=10.0]"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 10.0f, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint3 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) "hi!");
        double double4 = categoryAxis1.getFixedDimension();
        java.awt.Paint paint5 = categoryAxis1.getTickMarkPaint();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame2 = blockContainer0.getFrame();
        double double3 = blockContainer0.getWidth();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.Range range5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint(range5, (double) 'a');
        double double8 = rectangleConstraint7.getHeight();
        try {
            org.jfree.chart.util.Size2D size2D9 = blockContainer0.arrange(graphics2D4, rectangleConstraint7);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(blockFrame2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 97.0d + "'", double8 == 97.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        java.awt.Color color19 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass20 = color19.getClass();
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine("");
        boolean boolean24 = textLine22.equals((java.lang.Object) (-1L));
        org.jfree.chart.text.TextFragment textFragment25 = null;
        textLine22.removeFragment(textFragment25);
        boolean boolean27 = color19.equals((java.lang.Object) textLine22);
        int int28 = color19.getBlue();
        categoryPlot18.setOutlinePaint((java.awt.Paint) color19);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment30 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment31 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement34 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment30, verticalAlignment31, (double) 10L, (double) 'a');
        org.jfree.chart.block.BlockContainer blockContainer35 = new org.jfree.chart.block.BlockContainer();
        double double36 = blockContainer35.getContentYOffset();
        double double37 = blockContainer35.getWidth();
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke42 = categoryAxis41.getTickMarkStroke();
        java.awt.Stroke stroke43 = categoryAxis41.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color39, stroke43);
        flowArrangement34.add((org.jfree.chart.block.Block) blockContainer35, (java.lang.Object) stroke43);
        categoryPlot18.setRangeGridlineStroke(stroke43);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = categoryPlot18.getDomainAxisEdge((-16776961));
        org.jfree.chart.axis.ValueAxis valueAxis52 = categoryPlot18.getRangeAxis(15);
        java.awt.Paint paint53 = categoryPlot18.getNoDataMessagePaint();
        org.jfree.chart.plot.Marker marker55 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset56 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range57 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset56);
        defaultStatisticalCategoryDataset56.validateObject();
        int int59 = defaultStatisticalCategoryDataset56.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = new org.jfree.chart.axis.CategoryAxis("");
        int int62 = categoryAxis61.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer64 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape68 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity69 = new org.jfree.chart.entity.ChartEntity(shape68);
        statisticalBarRenderer64.setSeriesShape((int) (short) 0, shape68);
        statisticalBarRenderer64.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot74 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset56, categoryAxis61, valueAxis63, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer64);
        categoryPlot74.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.util.Layer layer78 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str79 = layer78.toString();
        java.util.Collection collection80 = categoryPlot74.getDomainMarkers(15, layer78);
        try {
            categoryPlot18.addRangeMarker(15, marker55, layer78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 192 + "'", int28 == 192);
        org.junit.Assert.assertNotNull(verticalAlignment31);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertNull(valueAxis52);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNull(range57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertNotNull(shape68);
        org.junit.Assert.assertNotNull(layer78);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "Layer.FOREGROUND" + "'", str79.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection80);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.CENTER_VERTICAL" + "'", str1.equals("GradientPaintTransformType.CENTER_VERTICAL"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint4 = categoryAxis2.getTickLabelPaint((java.lang.Comparable) "hi!");
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset6 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset6);
        defaultStatisticalCategoryDataset6.validateObject();
        int int9 = defaultStatisticalCategoryDataset6.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        int int12 = categoryAxis11.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape18);
        statisticalBarRenderer14.setSeriesShape((int) (short) 0, shape18);
        statisticalBarRenderer14.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset6, categoryAxis11, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer14);
        boolean boolean25 = statisticalBarRenderer14.getAutoPopulateSeriesFillPaint();
        java.awt.Paint paint27 = statisticalBarRenderer14.getSeriesFillPaint(500);
        java.lang.Boolean boolean29 = statisticalBarRenderer14.getSeriesItemLabelsVisible((int) (short) -1);
        java.awt.Paint paint31 = statisticalBarRenderer14.lookupSeriesFillPaint(255);
        java.awt.Color color32 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer33 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape37 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity38 = new org.jfree.chart.entity.ChartEntity(shape37);
        statisticalBarRenderer33.setSeriesShape((int) (short) 0, shape37);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition40 = statisticalBarRenderer33.getBasePositiveItemLabelPosition();
        statisticalBarRenderer33.setSeriesItemLabelsVisible((int) (byte) 0, (java.lang.Boolean) true);
        java.awt.Stroke stroke46 = statisticalBarRenderer33.getItemOutlineStroke((int) ' ', 3);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double49 = rectangleInsets47.calculateTopInset((-1.0d));
        double double51 = rectangleInsets47.calculateRightOutset((double) 'a');
        org.jfree.chart.block.LineBorder lineBorder52 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color32, stroke46, rectangleInsets47);
        java.awt.Stroke stroke53 = lineBorder52.getStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker55 = new org.jfree.chart.plot.ValueMarker(0.2d, paint4, stroke5, paint31, stroke53, (float) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertNull(boolean29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(itemLabelPosition40);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(stroke53);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = statisticalBarRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Shape shape4 = null;
        statisticalBarRenderer0.setSeriesShape(100, shape4);
        boolean boolean6 = statisticalBarRenderer0.getAutoPopulateSeriesShape();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(2, categoryURLGenerator8);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = statisticalBarRenderer0.getLegendItemURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator10);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke7 = categoryAxis6.getTickMarkStroke();
        java.awt.Stroke stroke8 = categoryAxis6.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color4, stroke8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = valueMarker9.getLabelAnchor();
        java.awt.Paint paint11 = valueMarker9.getLabelPaint();
        java.awt.Stroke stroke12 = valueMarker9.getStroke();
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape18);
        statisticalBarRenderer14.setSeriesShape((int) (short) 0, shape18);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = statisticalBarRenderer14.getBasePositiveItemLabelPosition();
        statisticalBarRenderer14.setSeriesItemLabelsVisible((int) (byte) 0, (java.lang.Boolean) true);
        java.awt.Stroke stroke27 = statisticalBarRenderer14.getItemOutlineStroke((int) ' ', 3);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double30 = rectangleInsets28.calculateTopInset((-1.0d));
        double double32 = rectangleInsets28.calculateRightOutset((double) 'a');
        org.jfree.chart.block.LineBorder lineBorder33 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color13, stroke27, rectangleInsets28);
        java.awt.Stroke stroke34 = lineBorder33.getStroke();
        java.awt.Color color36 = java.awt.Color.BLUE;
        int int37 = color36.getRGB();
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke42 = categoryAxis41.getTickMarkStroke();
        java.awt.Stroke stroke43 = categoryAxis41.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color39, stroke43);
        valueMarker44.setValue((double) 192);
        java.awt.Stroke stroke47 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        valueMarker44.setOutlineStroke(stroke47);
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke52 = categoryAxis51.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker54 = new org.jfree.chart.plot.ValueMarker((double) (short) 100, (java.awt.Paint) color36, stroke47, (java.awt.Paint) color49, stroke52, (float) 0);
        java.awt.Stroke[] strokeArray55 = new java.awt.Stroke[] { stroke12, stroke34, stroke52 };
        java.awt.Shape shape58 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer59 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape63 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity64 = new org.jfree.chart.entity.ChartEntity(shape63);
        statisticalBarRenderer59.setSeriesShape((int) (short) 0, shape63);
        java.awt.Shape[] shapeArray66 = new java.awt.Shape[] { shape58, shape63 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier67 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray2, strokeArray55, shapeArray66);
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-16776961) + "'", int37 == (-16776961));
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(strokeArray55);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertNotNull(shapeArray66);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke3 = categoryAxis2.getTickMarkStroke();
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        java.lang.Object obj7 = categoryAxis2.clone();
        java.awt.Font font9 = categoryAxis2.getTickLabelFont((java.lang.Comparable) 1.0d);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) 10.0f, (double) 100, 10.0d, (double) 2, (java.awt.Paint) color14);
        org.jfree.chart.text.TextBlock textBlock16 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font9, (java.awt.Paint) color14);
        org.jfree.chart.text.TextLine textLine17 = textBlock16.getLastLine();
        java.awt.Color color18 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass19 = color18.getClass();
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("");
        boolean boolean23 = textLine21.equals((java.lang.Object) (-1L));
        org.jfree.chart.text.TextFragment textFragment24 = null;
        textLine21.removeFragment(textFragment24);
        boolean boolean26 = color18.equals((java.lang.Object) textLine21);
        textBlock16.addLine(textLine21);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition();
        double double32 = itemLabelPosition31.getAngle();
        org.jfree.chart.text.TextAnchor textAnchor33 = itemLabelPosition31.getTextAnchor();
        try {
            textLine21.draw(graphics2D28, (float) (byte) 10, (float) (short) 100, textAnchor33, (float) (byte) 1, 10.0f, (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(textBlock16);
        org.junit.Assert.assertNotNull(textLine17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor33);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 0.0d, (double) (-1), 100, (java.lang.Comparable) "ItemLabelAnchor.INSIDE1");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        defaultStatisticalCategoryDataset0.addChangeListener(datasetChangeListener3);
        java.lang.Object obj5 = defaultStatisticalCategoryDataset0.clone();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getHeightConstraintType();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Comparable comparable5 = null;
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, comparable5);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleConstraint2, (org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset4);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        float float10 = categoryAxis9.getTickMarkOutsideLength();
        categoryAxis9.setCategoryLabelPositionOffset((int) (byte) 0);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape18);
        statisticalBarRenderer14.setSeriesShape((int) (short) 0, shape18);
        statisticalBarRenderer14.setAutoPopulateSeriesShape(false);
        java.util.EventListener eventListener23 = null;
        boolean boolean24 = statisticalBarRenderer14.hasListener(eventListener23);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity(shape29);
        statisticalBarRenderer25.setSeriesShape((int) (short) 0, shape29);
        java.lang.Object obj32 = statisticalBarRenderer25.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = new org.jfree.chart.labels.ItemLabelPosition();
        statisticalBarRenderer25.setBasePositiveItemLabelPosition(itemLabelPosition33);
        statisticalBarRenderer14.setBaseNegativeItemLabelPosition(itemLabelPosition33);
        java.lang.Object obj36 = statisticalBarRenderer14.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, categoryAxis9, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer14);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener38 = null;
        defaultStatisticalCategoryDataset4.removeChangeListener(datasetChangeListener38);
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(obj36);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        java.awt.Stroke stroke7 = categoryAxis5.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color3, stroke7);
        java.awt.image.ColorModel colorModel9 = null;
        java.awt.Rectangle rectangle10 = null;
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = blockContainer11.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame13 = blockContainer11.getFrame();
        double double14 = blockContainer11.getWidth();
        java.awt.geom.Rectangle2D rectangle2D15 = blockContainer11.getBounds();
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color3.createContext(colorModel9, rectangle10, rectangle2D15, affineTransform16, renderingHints17);
        textTitle0.draw(graphics2D1, rectangle2D15);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge20);
        double double22 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D15, rectangleEdge21);
        boolean boolean23 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge21);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(blockFrame13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        boolean boolean19 = statisticalBarRenderer8.getAutoPopulateSeriesFillPaint();
        java.awt.Font font21 = statisticalBarRenderer8.getSeriesItemLabelFont(0);
        statisticalBarRenderer8.setSeriesVisible(3, (java.lang.Boolean) false);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState26 = null;
        org.jfree.chart.block.BlockContainer blockContainer27 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = blockContainer27.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame29 = blockContainer27.getFrame();
        double double30 = blockContainer27.getWidth();
        java.awt.geom.Rectangle2D rectangle2D31 = blockContainer27.getBounds();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset32 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset32);
        defaultStatisticalCategoryDataset32.validateObject();
        int int35 = defaultStatisticalCategoryDataset32.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        int int38 = categoryAxis37.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer40 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape44 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity45 = new org.jfree.chart.entity.ChartEntity(shape44);
        statisticalBarRenderer40.setSeriesShape((int) (short) 0, shape44);
        statisticalBarRenderer40.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset32, categoryAxis37, valueAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer40);
        categoryPlot50.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener53 = null;
        categoryPlot50.addChangeListener(plotChangeListener53);
        org.jfree.chart.axis.AxisLocation axisLocation56 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot50.setRangeAxisLocation(0, axisLocation56);
        categoryPlot50.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = new org.jfree.chart.axis.CategoryAxis("");
        float float62 = categoryAxis61.getTickMarkOutsideLength();
        java.util.EventListener eventListener63 = null;
        boolean boolean64 = categoryAxis61.hasListener(eventListener63);
        categoryAxis61.setVisible(true);
        categoryAxis61.setTickMarksVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis69 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset70 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range71 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset70);
        defaultStatisticalCategoryDataset70.validateObject();
        org.jfree.data.Range range74 = defaultStatisticalCategoryDataset70.getRangeBounds(false);
        try {
            statisticalBarRenderer8.drawItem(graphics2D25, categoryItemRendererState26, rectangle2D31, categoryPlot50, categoryAxis61, valueAxis69, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset70, (int) (byte) 1, (int) (short) 10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(font21);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(blockFrame29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(axisLocation56);
        org.junit.Assert.assertTrue("'" + float62 + "' != '" + 2.0f + "'", float62 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNull(range71);
        org.junit.Assert.assertNull(range74);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.StrokeList strokeList4 = new org.jfree.chart.util.StrokeList();
        strokeList4.clear();
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        boolean boolean7 = strokeList4.equals((java.lang.Object) textAnchor6);
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) (byte) 0, (float) '#', textAnchor6, 0.2d, (float) (byte) 1, (float) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke15 = categoryAxis14.getTickMarkStroke();
        categoryAxis14.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        java.lang.Object obj19 = categoryAxis14.clone();
        java.awt.Font font21 = categoryAxis14.getTickLabelFont((java.lang.Comparable) 1.0d);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder27 = new org.jfree.chart.block.BlockBorder((double) 10.0f, (double) 100, 10.0d, (double) 2, (java.awt.Paint) color26);
        org.jfree.chart.text.TextBlock textBlock28 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font21, (java.awt.Paint) color26);
        org.jfree.chart.text.TextLine textLine29 = textBlock28.getLastLine();
        boolean boolean30 = textAnchor6.equals((java.lang.Object) textLine29);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(textBlock28);
        org.junit.Assert.assertNotNull(textLine29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.Axis axis1 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset2);
        defaultStatisticalCategoryDataset2.validateObject();
        int int5 = defaultStatisticalCategoryDataset2.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        int int8 = categoryAxis7.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape14);
        statisticalBarRenderer10.setSeriesShape((int) (short) 0, shape14);
        statisticalBarRenderer10.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset2, categoryAxis7, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer10);
        java.awt.Color color21 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass22 = color21.getClass();
        org.jfree.chart.text.TextLine textLine24 = new org.jfree.chart.text.TextLine("");
        boolean boolean26 = textLine24.equals((java.lang.Object) (-1L));
        org.jfree.chart.text.TextFragment textFragment27 = null;
        textLine24.removeFragment(textFragment27);
        boolean boolean29 = color21.equals((java.lang.Object) textLine24);
        int int30 = color21.getBlue();
        categoryPlot20.setOutlinePaint((java.awt.Paint) color21);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment32 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment33 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement36 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment32, verticalAlignment33, (double) 10L, (double) 'a');
        org.jfree.chart.block.BlockContainer blockContainer37 = new org.jfree.chart.block.BlockContainer();
        double double38 = blockContainer37.getContentYOffset();
        double double39 = blockContainer37.getWidth();
        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke44 = categoryAxis43.getTickMarkStroke();
        java.awt.Stroke stroke45 = categoryAxis43.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color41, stroke45);
        flowArrangement36.add((org.jfree.chart.block.Block) blockContainer37, (java.lang.Object) stroke45);
        categoryPlot20.setRangeGridlineStroke(stroke45);
        categoryPlot20.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = categoryPlot20.getDomainAxisEdge((-16776961));
        try {
            axisCollection0.add(axis1, rectangleEdge52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 192 + "'", int30 == 192);
        org.junit.Assert.assertNotNull(verticalAlignment33);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(rectangleEdge52);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.awt.Font font2 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=64,g=64,b=64]", font2);
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("NOID", font2);
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        borderArrangement0.clear();
        org.jfree.chart.block.Block block2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        float float5 = categoryAxis4.getTickMarkOutsideLength();
        java.awt.Stroke stroke6 = categoryAxis4.getAxisLineStroke();
        try {
            borderArrangement0.add(block2, (java.lang.Object) categoryAxis4);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.axis.CategoryAxis cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 2.0f + "'", float5 == 2.0f);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot18.getRangeAxisEdge(0);
        categoryPlot18.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis27 = categoryPlot18.getRangeAxis();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke33 = categoryAxis32.getTickMarkStroke();
        java.awt.Stroke stroke34 = categoryAxis32.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color30, stroke34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = valueMarker35.getLabelAnchor();
        java.awt.Paint paint37 = valueMarker35.getLabelPaint();
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        valueMarker35.setPaint((java.awt.Paint) color38);
        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str41 = layer40.toString();
        categoryPlot18.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker35, layer40);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(layer40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Layer.FOREGROUND" + "'", str41.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot18.getRangeAxisEdge(0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        categoryPlot18.removeChangeListener(plotChangeListener25);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer27 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean28 = statisticalBarRenderer27.getAutoPopulateSeriesStroke();
        statisticalBarRenderer27.setIncludeBaseInRange(false);
        java.awt.Shape shape32 = statisticalBarRenderer27.lookupSeriesShape((int) (byte) 10);
        categoryPlot18.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer27);
        java.awt.Paint paint34 = statisticalBarRenderer27.getBasePaint();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        boolean boolean9 = statisticalBarRenderer0.getItemCreateEntity(192, (int) (short) 0);
        java.awt.Paint paint10 = statisticalBarRenderer0.getErrorIndicatorPaint();
        boolean boolean11 = statisticalBarRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        statisticalBarRenderer0.setSeriesFillPaint(3, (java.awt.Paint) color13);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator15 = statisticalBarRenderer0.getLegendItemLabelGenerator();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator15);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        double double1 = blockContainer0.getContentYOffset();
        double double2 = blockContainer0.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = blockContainer0.getPadding();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        boolean boolean19 = statisticalBarRenderer8.getAutoPopulateSeriesFillPaint();
        java.awt.Font font21 = statisticalBarRenderer8.getSeriesItemLabelFont(0);
        java.awt.Shape shape24 = statisticalBarRenderer8.getItemShape(1, 0);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(font21);
        org.junit.Assert.assertNotNull(shape24);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.awt.Color color1 = java.awt.Color.BLUE;
        int int2 = color1.getRGB();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke7 = categoryAxis6.getTickMarkStroke();
        java.awt.Stroke stroke8 = categoryAxis6.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color4, stroke8);
        valueMarker9.setValue((double) 192);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        valueMarker9.setOutlineStroke(stroke12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke17 = categoryAxis16.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (short) 100, (java.awt.Paint) color1, stroke12, (java.awt.Paint) color14, stroke17, (float) 0);
        java.awt.Color color20 = color14.brighter();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16776961) + "'", int2 == (-16776961));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        statisticalBarRenderer0.setAutoPopulateSeriesShape(false);
        java.util.EventListener eventListener9 = null;
        boolean boolean10 = statisticalBarRenderer0.hasListener(eventListener9);
        java.awt.Stroke stroke13 = statisticalBarRenderer0.getItemOutlineStroke(15, 128);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        statisticalBarRenderer0.setAutoPopulateSeriesShape(false);
        java.util.EventListener eventListener9 = null;
        boolean boolean10 = statisticalBarRenderer0.hasListener(eventListener9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_BLUE;
        statisticalBarRenderer0.setErrorIndicatorPaint((java.awt.Paint) color11);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator((int) '#', categoryToolTipGenerator14);
        boolean boolean16 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        java.lang.Object obj7 = statisticalBarRenderer0.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = new org.jfree.chart.labels.ItemLabelPosition();
        statisticalBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition8);
        double double10 = statisticalBarRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = statisticalBarRenderer0.getSeriesURLGenerator(0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNull(categoryURLGenerator12);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        java.lang.Object obj6 = categoryAxis1.clone();
        boolean boolean7 = categoryAxis1.isVisible();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.util.List list2 = defaultStatisticalCategoryDataset0.getColumnKeys();
        double double4 = defaultStatisticalCategoryDataset0.getRangeLowerBound(false);
        try {
            java.lang.Comparable comparable6 = defaultStatisticalCategoryDataset0.getRowKey((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        boolean boolean8 = statisticalBarRenderer0.isSeriesItemLabelsVisible((int) (byte) 0);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        int int11 = color10.getAlpha();
        statisticalBarRenderer0.setSeriesFillPaint(500, (java.awt.Paint) color10, true);
        java.awt.Font font17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace19 = color18.getColorSpace();
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("hi!", font17, (java.awt.Paint) color18, 1.0f);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity31 = new org.jfree.chart.entity.ChartEntity(shape30);
        statisticalBarRenderer26.setSeriesShape((int) (short) 0, shape30);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke35 = categoryAxis34.getTickMarkStroke();
        java.awt.Stroke stroke36 = categoryAxis34.getAxisLineStroke();
        java.awt.Color color37 = java.awt.Color.cyan;
        java.lang.String str38 = color37.toString();
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("", "", "", "hi!", shape30, stroke36, (java.awt.Paint) color37);
        java.awt.image.ColorModel colorModel40 = null;
        java.awt.Rectangle rectangle41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        java.awt.geom.AffineTransform affineTransform43 = null;
        java.awt.RenderingHints renderingHints44 = null;
        java.awt.PaintContext paintContext45 = color37.createContext(colorModel40, rectangle41, rectangle2D42, affineTransform43, renderingHints44);
        org.jfree.chart.text.TextBlock textBlock46 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font17, (java.awt.Paint) color37);
        statisticalBarRenderer0.setSeriesItemLabelFont(10, font17, true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(colorSpace19);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "java.awt.Color[r=0,g=255,b=255]" + "'", str38.equals("java.awt.Color[r=0,g=255,b=255]"));
        org.junit.Assert.assertNotNull(paintContext45);
        org.junit.Assert.assertNotNull(textBlock46);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setFixedDimension((double) 2.0f);
        java.awt.Font font4 = categoryAxis1.getTickLabelFont();
        categoryAxis1.setAxisLineVisible(true);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Comparable comparable2 = null;
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1, comparable2);
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset3, (java.lang.Comparable) (short) 0, 97.0d, 0);
        org.jfree.data.category.CategoryDataset categoryDataset8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 1L, (org.jfree.data.KeyedValues) pieDataset7);
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset7);
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertNotNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str1.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        statisticalBarRenderer0.setBaseSeriesVisible(true, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = statisticalBarRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        double[] doubleArray27 = new double[] { (-1L), (short) 10 };
        double[] doubleArray30 = new double[] { (-1L), (short) 10 };
        double[] doubleArray33 = new double[] { (-1L), (short) 10 };
        double[] doubleArray36 = new double[] { (-1L), (short) 10 };
        double[][] doubleArray37 = new double[][] { doubleArray27, doubleArray30, doubleArray33, doubleArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=0,g=255,b=255]", "Size2D[width=0.0, height=10.0]", doubleArray37);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = categoryPlot18.getRendererForDataset(categoryDataset38);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment40 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor42 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition43 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor41, textBlockAnchor42);
        float float44 = categoryLabelPosition43.getWidthRatio();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor45 = categoryLabelPosition43.getLabelAnchor();
        boolean boolean46 = horizontalAlignment40.equals((java.lang.Object) categoryLabelPosition43);
        boolean boolean47 = categoryPlot18.equals((java.lang.Object) boolean46);
        org.jfree.chart.block.BlockBorder blockBorder48 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = blockBorder48.getInsets();
        categoryPlot18.setInsets(rectangleInsets49);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        categoryPlot18.setRenderer(categoryItemRenderer51, false);
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        categoryPlot18.setRangeAxis(valueAxis54);
        org.jfree.chart.axis.ValueAxis valueAxis57 = categoryPlot18.getRangeAxis((int) '#');
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNull(categoryItemRenderer39);
        org.junit.Assert.assertNotNull(horizontalAlignment40);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(textBlockAnchor42);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 0.95f + "'", float44 == 0.95f);
        org.junit.Assert.assertNotNull(textBlockAnchor45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(blockBorder48);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNull(valueAxis57);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalBarRenderer0.getBaseNegativeItemLabelPosition();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape10);
        statisticalBarRenderer6.setSeriesShape((int) (short) 0, shape10);
        statisticalBarRenderer6.setAutoPopulateSeriesShape(false);
        java.util.EventListener eventListener15 = null;
        boolean boolean16 = statisticalBarRenderer6.hasListener(eventListener15);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape21);
        statisticalBarRenderer17.setSeriesShape((int) (short) 0, shape21);
        java.lang.Object obj24 = statisticalBarRenderer17.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = new org.jfree.chart.labels.ItemLabelPosition();
        statisticalBarRenderer17.setBasePositiveItemLabelPosition(itemLabelPosition25);
        statisticalBarRenderer6.setBaseNegativeItemLabelPosition(itemLabelPosition25);
        try {
            statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (short) -1, itemLabelPosition25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape8);
        statisticalBarRenderer4.setSeriesShape((int) (short) 0, shape8);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("", "", "", "java.awt.Color[r=0,g=255,b=255]", shape8, (java.awt.Paint) color11);
        java.awt.Shape shape13 = legendItem12.getShape();
        legendItem12.setSeriesIndex((int) '4');
        java.lang.String str16 = legendItem12.getLabel();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape8);
        statisticalBarRenderer4.setSeriesShape((int) (short) 0, shape8);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("", "", "", "java.awt.Color[r=0,g=255,b=255]", shape8, (java.awt.Paint) color11);
        java.text.AttributedString attributedString13 = legendItem12.getAttributedLabel();
        int int14 = legendItem12.getSeriesIndex();
        java.awt.Stroke stroke15 = legendItem12.getOutlineStroke();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(attributedString13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 0.0f);
        java.util.List list2 = axisState1.getTicks();
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor2);
        float float4 = categoryLabelPosition3.getWidthRatio();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition3);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition9 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor7, textBlockAnchor8);
        float float10 = categoryLabelPosition9.getWidthRatio();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions11 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions6, categoryLabelPosition9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor12, textBlockAnchor13);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions15 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions6, categoryLabelPosition14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition17 = categoryLabelPositions15.getLabelPosition(rectangleEdge16);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions18 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition17);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.95f + "'", float4 == 0.95f);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.95f + "'", float10 == 0.95f);
        org.junit.Assert.assertNotNull(categoryLabelPositions11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertNotNull(categoryLabelPositions15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(categoryLabelPosition17);
        org.junit.Assert.assertNotNull(categoryLabelPositions18);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        statisticalBarRenderer0.setAutoPopulateSeriesShape(false);
        java.util.EventListener eventListener9 = null;
        boolean boolean10 = statisticalBarRenderer0.hasListener(eventListener9);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape15);
        statisticalBarRenderer11.setSeriesShape((int) (short) 0, shape15);
        java.lang.Object obj18 = statisticalBarRenderer11.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition();
        statisticalBarRenderer11.setBasePositiveItemLabelPosition(itemLabelPosition19);
        statisticalBarRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition19);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation22 = null;
        boolean boolean23 = statisticalBarRenderer0.removeAnnotation(categoryAnnotation22);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        boolean boolean8 = statisticalBarRenderer0.isSeriesItemLabelsVisible((int) (byte) 0);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        int int11 = color10.getAlpha();
        statisticalBarRenderer0.setSeriesFillPaint(500, (java.awt.Paint) color10, true);
        java.awt.Paint paint14 = statisticalBarRenderer0.getBaseOutlinePaint();
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        try {
            statisticalBarRenderer0.setSeriesFillPaint((int) (short) -1, (java.awt.Paint) color16, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        java.util.List list1 = axisState0.getTicks();
        axisState0.cursorRight((double) 10L);
        axisState0.cursorRight(0.0d);
        axisState0.cursorDown((double) 4);
        axisState0.setMax((double) (short) 10);
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        statisticalBarRenderer0.setSeriesItemLabelsVisible((int) (byte) 0, (java.lang.Boolean) true);
        java.awt.Paint paint12 = statisticalBarRenderer0.getSeriesFillPaint((int) '4');
        java.awt.Paint paint15 = statisticalBarRenderer0.getItemFillPaint((int) (short) -1, (-1));
        java.awt.Paint paint17 = statisticalBarRenderer0.getSeriesFillPaint((int) (byte) -1);
        boolean boolean18 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        double[] doubleArray6 = new double[] { (-1L), (short) 10 };
        double[] doubleArray9 = new double[] { (-1L), (short) 10 };
        double[] doubleArray12 = new double[] { (-1L), (short) 10 };
        double[] doubleArray15 = new double[] { (-1L), (short) 10 };
        double[][] doubleArray16 = new double[][] { doubleArray6, doubleArray9, doubleArray12, doubleArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=0,g=255,b=255]", "Size2D[width=0.0, height=10.0]", doubleArray16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=64,g=64,b=64]", doubleArray16);
        try {
            java.lang.Number number19 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset18);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(categoryDataset18);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement1 = blockContainer0.getArrangement();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        statisticalBarRenderer2.setSeriesShape((int) (short) 0, shape6);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = statisticalBarRenderer2.getBasePositiveItemLabelPosition();
        java.awt.Paint paint11 = statisticalBarRenderer2.lookupSeriesPaint(0);
        boolean boolean12 = blockContainer0.equals((java.lang.Object) statisticalBarRenderer2);
        org.junit.Assert.assertNotNull(arrangement1);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke9 = categoryAxis8.getTickMarkStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke9);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator11);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        boolean boolean10 = statisticalBarRenderer0.getItemVisible(0, (-1));
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        statisticalBarRenderer0.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = new org.jfree.chart.labels.ItemLabelPosition();
        double double10 = itemLabelPosition9.getAngle();
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition(192, itemLabelPosition9, false);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset14 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset14);
        defaultStatisticalCategoryDataset14.validateObject();
        int int17 = defaultStatisticalCategoryDataset14.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("");
        int int20 = categoryAxis19.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape26);
        statisticalBarRenderer22.setSeriesShape((int) (short) 0, shape26);
        statisticalBarRenderer22.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset14, categoryAxis19, valueAxis21, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22);
        categoryPlot32.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener35 = null;
        categoryPlot32.addChangeListener(plotChangeListener35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot32.setRangeAxisLocation(0, axisLocation38);
        org.jfree.chart.util.SortOrder sortOrder40 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot32.setColumnRenderingOrder(sortOrder40);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = categoryPlot32.getAxisOffset();
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D45 = null;
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke50 = categoryAxis49.getTickMarkStroke();
        java.awt.Stroke stroke51 = categoryAxis49.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker52 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color47, stroke51);
        java.awt.image.ColorModel colorModel53 = null;
        java.awt.Rectangle rectangle54 = null;
        org.jfree.chart.block.BlockContainer blockContainer55 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = blockContainer55.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame57 = blockContainer55.getFrame();
        double double58 = blockContainer55.getWidth();
        java.awt.geom.Rectangle2D rectangle2D59 = blockContainer55.getBounds();
        java.awt.geom.AffineTransform affineTransform60 = null;
        java.awt.RenderingHints renderingHints61 = null;
        java.awt.PaintContext paintContext62 = color47.createContext(colorModel53, rectangle54, rectangle2D59, affineTransform60, renderingHints61);
        textTitle44.draw(graphics2D45, rectangle2D59);
        try {
            statisticalBarRenderer0.drawRangeGridline(graphics2D13, categoryPlot32, valueAxis43, rectangle2D59, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(sortOrder40);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertNotNull(blockFrame57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertNotNull(paintContext62);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape8);
        statisticalBarRenderer4.setSeriesShape((int) (short) 0, shape8);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("", "", "", "java.awt.Color[r=0,g=255,b=255]", shape8, (java.awt.Paint) color11);
        java.text.AttributedString attributedString13 = legendItem12.getAttributedLabel();
        int int14 = legendItem12.getSeriesIndex();
        boolean boolean15 = legendItem12.isShapeOutlineVisible();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(attributedString13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 10);
        axisState1.cursorRight((double) 100.0f);
        axisState1.setMax((double) 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        float float3 = categoryAxis2.getTickMarkOutsideLength();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = categoryAxis2.hasListener(eventListener4);
        java.lang.String str6 = categoryAxis2.getLabelURL();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis2.setTickLabelFont((java.lang.Comparable) 0, font8);
        java.awt.Paint paint10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.axis.AxisState axisState12 = new org.jfree.chart.axis.AxisState((double) 0.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge14);
        axisState12.moveCursor(0.0d, rectangleEdge14);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor20 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition21 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor19, textBlockAnchor20);
        float float22 = categoryLabelPosition21.getWidthRatio();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = categoryLabelPosition21.getLabelAnchor();
        boolean boolean24 = horizontalAlignment18.equals((java.lang.Object) categoryLabelPosition21);
        org.jfree.chart.util.VerticalAlignment verticalAlignment25 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement28 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment18, verticalAlignment25, 1.0d, (double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font8, paint10, rectangleEdge14, horizontalAlignment17, verticalAlignment25, rectangleInsets29);
        java.awt.Paint paint31 = textTitle30.getPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis33.setFixedDimension((double) 2.0f);
        java.awt.Font font36 = categoryAxis33.getTickLabelFont();
        categoryAxis33.setCategoryMargin((double) (short) 10);
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.axis.AxisState axisState41 = new org.jfree.chart.axis.AxisState((double) 10);
        axisState41.cursorRight((double) 100.0f);
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D45 = null;
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke50 = categoryAxis49.getTickMarkStroke();
        java.awt.Stroke stroke51 = categoryAxis49.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker52 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color47, stroke51);
        java.awt.image.ColorModel colorModel53 = null;
        java.awt.Rectangle rectangle54 = null;
        org.jfree.chart.block.BlockContainer blockContainer55 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = blockContainer55.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame57 = blockContainer55.getFrame();
        double double58 = blockContainer55.getWidth();
        java.awt.geom.Rectangle2D rectangle2D59 = blockContainer55.getBounds();
        java.awt.geom.AffineTransform affineTransform60 = null;
        java.awt.RenderingHints renderingHints61 = null;
        java.awt.PaintContext paintContext62 = color47.createContext(colorModel53, rectangle54, rectangle2D59, affineTransform60, renderingHints61);
        textTitle44.draw(graphics2D45, rectangle2D59);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge64);
        double double66 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D59, rectangleEdge65);
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge67);
        java.util.List list69 = categoryAxis33.refreshTicks(graphics2D39, axisState41, rectangle2D59, rectangleEdge68);
        textTitle30.setPosition(rectangleEdge68);
        java.lang.String str71 = textTitle30.getText();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(textBlockAnchor20);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.95f + "'", float22 == 0.95f);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(verticalAlignment25);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertNotNull(blockFrame57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertNotNull(paintContext62);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertNotNull(rectangleEdge65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge67);
        org.junit.Assert.assertNotNull(rectangleEdge68);
        org.junit.Assert.assertNotNull(list69);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str71.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("Layer.FOREGROUND", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint5 = categoryAxis3.getTickLabelPaint((java.lang.Comparable) "hi!");
        double double6 = categoryAxis3.getLowerMargin();
        keyedObjects0.setObject((java.lang.Comparable) false, (java.lang.Object) double6);
        keyedObjects0.setObject((java.lang.Comparable) (-1.0d), (java.lang.Object) 'a');
        try {
            keyedObjects0.removeValue((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.BACKGROUND;
        org.junit.Assert.assertNotNull(layer0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        boolean boolean19 = statisticalBarRenderer8.getAutoPopulateSeriesFillPaint();
        java.awt.Paint paint21 = statisticalBarRenderer8.getSeriesFillPaint(500);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator23 = statisticalBarRenderer8.getSeriesURLGenerator(0);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNull(categoryURLGenerator23);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        float float23 = categoryPlot18.getBackgroundAlpha();
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot18.getDomainMarkers(layer24);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity31 = new org.jfree.chart.entity.ChartEntity(shape30);
        statisticalBarRenderer26.setSeriesShape((int) (short) 0, shape30);
        java.lang.Object obj33 = statisticalBarRenderer26.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = new org.jfree.chart.labels.ItemLabelPosition();
        statisticalBarRenderer26.setBasePositiveItemLabelPosition(itemLabelPosition34);
        int int36 = categoryPlot18.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer26);
        org.jfree.chart.plot.Plot plot37 = categoryPlot18.getParent();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNull(plot37);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range5 = statisticalBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, (double) (short) 0);
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4);
        org.jfree.data.KeyToGroupMap keyToGroupMap9 = null;
        try {
            org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, keyToGroupMap9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertEquals((double) number8, Double.NaN, 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 10L, (double) 'a');
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer();
        double double6 = blockContainer5.getContentYOffset();
        double double7 = blockContainer5.getWidth();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke12 = categoryAxis11.getTickMarkStroke();
        java.awt.Stroke stroke13 = categoryAxis11.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color9, stroke13);
        flowArrangement4.add((org.jfree.chart.block.Block) blockContainer5, (java.lang.Object) stroke13);
        java.util.List list16 = blockContainer5.getBlocks();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.data.Range range18 = null;
        org.jfree.data.Range range19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint(range18, range19);
        try {
            org.jfree.chart.util.Size2D size2D21 = blockContainer5.arrange(graphics2D17, rectangleConstraint20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        boolean boolean19 = statisticalBarRenderer8.getAutoPopulateSeriesFillPaint();
        java.awt.Paint paint21 = statisticalBarRenderer8.getSeriesFillPaint(500);
        java.lang.Boolean boolean23 = statisticalBarRenderer8.getSeriesItemLabelsVisible((int) (short) -1);
        java.awt.Shape shape26 = statisticalBarRenderer8.getItemShape((int) ' ', (int) (short) 1);
        statisticalBarRenderer8.setItemMargin(0.0d);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNull(boolean23);
        org.junit.Assert.assertNotNull(shape26);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str1 = rectangleEdge0.toString();
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleEdge.TOP" + "'", str1.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 0.0d, (double) 0.5f, (int) (short) 10, (java.lang.Comparable) (-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        java.awt.Stroke stroke5 = categoryAxis3.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color1, stroke5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = valueMarker6.getLabelAnchor();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        valueMarker6.setLabelPaint((java.awt.Paint) color8);
        org.jfree.chart.JFreeChart jFreeChart10 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color8, jFreeChart10);
        java.lang.Object obj12 = chartChangeEvent11.getSource();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(0.0d);
        axisState1.cursorDown((double) 0L);
        axisState1.cursorRight(100.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj1 = shapeList0.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint5 = categoryAxis3.getTickLabelPaint((java.lang.Comparable) "hi!");
        double double6 = categoryAxis3.getFixedDimension();
        java.lang.Object obj7 = categoryAxis3.clone();
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis3.setTickLabelFont((java.lang.Comparable) 'a', font9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryAxis3.getLabelInsets();
        boolean boolean12 = shapeList0.equals((java.lang.Object) categoryAxis3);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState();
        java.util.List list2 = axisState1.getTicks();
        axisState1.cursorUp((double) 192);
        org.jfree.data.KeyedObject keyedObject5 = new org.jfree.data.KeyedObject((java.lang.Comparable) "RectangleEdge.BOTTOM", (java.lang.Object) 192);
        java.lang.Object obj6 = keyedObject5.getObject();
        java.lang.Comparable comparable7 = keyedObject5.getKey();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + obj6 + "' != '" + 192 + "'", obj6.equals(192));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + "RectangleEdge.BOTTOM" + "'", comparable7.equals("RectangleEdge.BOTTOM"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1);
        defaultStatisticalCategoryDataset1.validateObject();
        int int4 = defaultStatisticalCategoryDataset1.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        int int7 = categoryAxis6.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape13);
        statisticalBarRenderer9.setSeriesShape((int) (short) 0, shape13);
        statisticalBarRenderer9.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1, categoryAxis6, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer9);
        boolean boolean20 = statisticalBarRenderer9.getAutoPopulateSeriesFillPaint();
        java.awt.Font font22 = statisticalBarRenderer9.getSeriesItemLabelFont(0);
        java.awt.Paint paint23 = statisticalBarRenderer9.getBaseItemLabelPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        float float26 = categoryAxis25.getTickMarkOutsideLength();
        java.awt.Stroke stroke27 = categoryAxis25.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1, paint23, stroke27);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(font22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 2.0f + "'", float26 == 2.0f);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        boolean boolean19 = statisticalBarRenderer8.getAutoPopulateSeriesFillPaint();
        java.awt.Font font21 = statisticalBarRenderer8.getSeriesItemLabelFont(0);
        statisticalBarRenderer8.setSeriesVisible(3, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator26 = null;
        statisticalBarRenderer8.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator26, true);
        java.awt.Font font29 = null;
        try {
            statisticalBarRenderer8.setBaseItemLabelFont(font29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(font21);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        double[] doubleArray27 = new double[] { (-1L), (short) 10 };
        double[] doubleArray30 = new double[] { (-1L), (short) 10 };
        double[] doubleArray33 = new double[] { (-1L), (short) 10 };
        double[] doubleArray36 = new double[] { (-1L), (short) 10 };
        double[][] doubleArray37 = new double[][] { doubleArray27, doubleArray30, doubleArray33, doubleArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=0,g=255,b=255]", "Size2D[width=0.0, height=10.0]", doubleArray37);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = categoryPlot18.getRendererForDataset(categoryDataset38);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment40 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor42 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition43 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor41, textBlockAnchor42);
        float float44 = categoryLabelPosition43.getWidthRatio();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor45 = categoryLabelPosition43.getLabelAnchor();
        boolean boolean46 = horizontalAlignment40.equals((java.lang.Object) categoryLabelPosition43);
        boolean boolean47 = categoryPlot18.equals((java.lang.Object) boolean46);
        org.jfree.chart.block.BlockBorder blockBorder48 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = blockBorder48.getInsets();
        categoryPlot18.setInsets(rectangleInsets49);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        categoryPlot18.setRenderer(categoryItemRenderer51, false);
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        categoryPlot18.setRangeAxis(valueAxis54);
        int int56 = categoryPlot18.getDatasetCount();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNull(categoryItemRenderer39);
        org.junit.Assert.assertNotNull(horizontalAlignment40);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(textBlockAnchor42);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 0.95f + "'", float44 == 0.95f);
        org.junit.Assert.assertNotNull(textBlockAnchor45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(blockBorder48);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        int int3 = java.awt.Color.HSBtoRGB((float) ' ', (float) 1, 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str1.equals("ChartChangeEventType.NEW_DATASET"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot18.getRangeAxisEdge(0);
        categoryPlot18.setRangeGridlinesVisible(true);
        float float27 = categoryPlot18.getBackgroundImageAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot18.getRangeAxis(0);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.5f + "'", float27 == 0.5f);
        org.junit.Assert.assertNull(valueAxis29);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.util.List list1 = keyedObjects0.getKeys();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        java.awt.Stroke stroke5 = categoryAxis3.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color1, stroke5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = valueMarker6.getLabelAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor11, textBlockAnchor12);
        float float14 = categoryLabelPosition13.getWidthRatio();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = categoryLabelPosition13.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType16 = categoryLabelPosition13.getWidthType();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition18 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor7, textBlockAnchor8, textAnchor9, (double) 2, categoryLabelWidthType16, (float) 10);
        java.lang.String str19 = rectangleAnchor7.toString();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.95f + "'", float14 == 0.95f);
        org.junit.Assert.assertNotNull(textBlockAnchor15);
        org.junit.Assert.assertNotNull(categoryLabelWidthType16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleAnchor.TOP_LEFT" + "'", str19.equals("RectangleAnchor.TOP_LEFT"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke9 = categoryAxis8.getTickMarkStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke9);
        java.awt.Stroke stroke12 = statisticalBarRenderer0.lookupSeriesStroke(1);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator13, false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        java.awt.Stroke stroke7 = categoryAxis5.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color3, stroke7);
        java.awt.image.ColorModel colorModel9 = null;
        java.awt.Rectangle rectangle10 = null;
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = blockContainer11.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame13 = blockContainer11.getFrame();
        double double14 = blockContainer11.getWidth();
        java.awt.geom.Rectangle2D rectangle2D15 = blockContainer11.getBounds();
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color3.createContext(colorModel9, rectangle10, rectangle2D15, affineTransform16, renderingHints17);
        textTitle0.draw(graphics2D1, rectangle2D15);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset20 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset20);
        defaultStatisticalCategoryDataset20.validateObject();
        int int23 = defaultStatisticalCategoryDataset20.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        int int26 = categoryAxis25.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer28 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity(shape32);
        statisticalBarRenderer28.setSeriesShape((int) (short) 0, shape32);
        statisticalBarRenderer28.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset20, categoryAxis25, valueAxis27, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer28);
        java.awt.Font font40 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        categoryAxis25.setTickLabelFont((java.lang.Comparable) 100.0d, font40);
        textTitle0.setFont(font40);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(blockFrame13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(font40);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = blockResult0.getEntityCollection();
        org.jfree.chart.entity.EntityCollection entityCollection2 = null;
        blockResult0.setEntityCollection(entityCollection2);
        org.junit.Assert.assertNull(entityCollection1);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        java.awt.Color color19 = java.awt.Color.LIGHT_GRAY;
        java.lang.Class<?> wildcardClass20 = color19.getClass();
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine("");
        boolean boolean24 = textLine22.equals((java.lang.Object) (-1L));
        org.jfree.chart.text.TextFragment textFragment25 = null;
        textLine22.removeFragment(textFragment25);
        boolean boolean27 = color19.equals((java.lang.Object) textLine22);
        int int28 = color19.getBlue();
        categoryPlot18.setOutlinePaint((java.awt.Paint) color19);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment30 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment31 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement34 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment30, verticalAlignment31, (double) 10L, (double) 'a');
        org.jfree.chart.block.BlockContainer blockContainer35 = new org.jfree.chart.block.BlockContainer();
        double double36 = blockContainer35.getContentYOffset();
        double double37 = blockContainer35.getWidth();
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke42 = categoryAxis41.getTickMarkStroke();
        java.awt.Stroke stroke43 = categoryAxis41.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color39, stroke43);
        flowArrangement34.add((org.jfree.chart.block.Block) blockContainer35, (java.lang.Object) stroke43);
        categoryPlot18.setRangeGridlineStroke(stroke43);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = categoryPlot18.getDomainAxisEdge((-16776961));
        org.jfree.chart.axis.ValueAxis valueAxis52 = categoryPlot18.getRangeAxis(15);
        boolean boolean53 = categoryPlot18.isRangeZoomable();
        java.awt.Paint paint54 = categoryPlot18.getRangeGridlinePaint();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 192 + "'", int28 == 192);
        org.junit.Assert.assertNotNull(verticalAlignment31);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertNull(valueAxis52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(paint54);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtLeft();
        java.util.List list2 = axisCollection0.getAxesAtRight();
        java.util.List list3 = axisCollection0.getAxesAtTop();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke5 = categoryAxis4.getTickMarkStroke();
        java.awt.Stroke stroke6 = categoryAxis4.getAxisLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color2, stroke6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = valueMarker7.getLabelAnchor();
        java.awt.Paint paint9 = valueMarker7.getLabelPaint();
        java.awt.Paint paint10 = valueMarker7.getPaint();
        boolean boolean11 = gradientPaintTransformType0.equals((java.lang.Object) paint10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke14 = categoryAxis13.getTickMarkStroke();
        categoryAxis13.addCategoryLabelToolTip((java.lang.Comparable) (byte) 0, "");
        java.lang.Object obj18 = categoryAxis13.clone();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape21);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity25 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis13, shape21, "", "NOID");
        boolean boolean26 = gradientPaintTransformType0.equals((java.lang.Object) axisLabelEntity25);
        java.lang.Object obj27 = axisLabelEntity25.clone();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("CategoryAnchor.MIDDLE", graphics2D1, (-1.0f), (-1.0f), textAnchor4, 10.0d, (float) (-1), (float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) 0, range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        double double4 = rectangleConstraint2.getWidth();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = null;
        textBlock0.draw(graphics2D1, (float) (short) 1, 0.5f, textBlockAnchor4);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        float float9 = categoryAxis8.getTickMarkOutsideLength();
        java.util.EventListener eventListener10 = null;
        boolean boolean11 = categoryAxis8.hasListener(eventListener10);
        java.lang.String str12 = categoryAxis8.getLabelURL();
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis8.setTickLabelFont((java.lang.Comparable) 0, font14);
        java.awt.Paint paint16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.axis.AxisState axisState18 = new org.jfree.chart.axis.AxisState((double) 0.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge20);
        axisState18.moveCursor(0.0d, rectangleEdge20);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor26 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition27 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor25, textBlockAnchor26);
        float float28 = categoryLabelPosition27.getWidthRatio();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor29 = categoryLabelPosition27.getLabelAnchor();
        boolean boolean30 = horizontalAlignment24.equals((java.lang.Object) categoryLabelPosition27);
        org.jfree.chart.util.VerticalAlignment verticalAlignment31 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement34 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment24, verticalAlignment31, 1.0d, (double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font14, paint16, rectangleEdge20, horizontalAlignment23, verticalAlignment31, rectangleInsets35);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment37 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement41 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment37, verticalAlignment38, (double) 10L, (double) 'a');
        org.jfree.chart.block.ColumnArrangement columnArrangement44 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment23, verticalAlignment38, (double) (byte) -1, (double) 100);
        textBlock0.setLineAlignment(horizontalAlignment23);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(textBlockAnchor26);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.95f + "'", float28 == 0.95f);
        org.junit.Assert.assertNotNull(textBlockAnchor29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(verticalAlignment31);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(verticalAlignment38);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("VerticalAlignment.TOP", "", "Size2D[width=0.0, height=10.0]", "java.awt.Color[r=0,g=255,b=255]");
        java.lang.String str5 = basicProjectInfo4.getInfo();
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo4.getOptionalLibraries();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=0,g=255,b=255]" + "'", str5.equals("java.awt.Color[r=0,g=255,b=255]"));
        org.junit.Assert.assertNotNull(libraryArray6);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape26);
        statisticalBarRenderer22.setSeriesShape((int) (short) 0, shape26);
        java.lang.Object obj29 = statisticalBarRenderer22.clone();
        java.awt.Paint paint31 = statisticalBarRenderer22.lookupSeriesFillPaint(192);
        categoryPlot18.setRenderer((int) (short) 0, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22, false);
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        categoryPlot18.setFixedRangeAxisSpace(axisSpace34);
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        categoryPlot18.setRangeAxis(valueAxis36);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape26);
        statisticalBarRenderer22.setSeriesShape((int) (short) 0, shape26);
        java.lang.Object obj29 = statisticalBarRenderer22.clone();
        java.awt.Paint paint31 = statisticalBarRenderer22.lookupSeriesFillPaint(192);
        categoryPlot18.setRenderer((int) (short) 0, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22, false);
        boolean boolean34 = categoryPlot18.isDomainZoomable();
        categoryPlot18.setRangeCrosshairValue(1.0d);
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer38 = new org.jfree.chart.text.G2TextMeasurer(graphics2D37);
        boolean boolean39 = categoryPlot18.equals((java.lang.Object) graphics2D37);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Font font3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("hi!", font3, (java.awt.Paint) color4, 1.0f);
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("RectangleEdge.BOTTOM", font1, (java.awt.Paint) color4);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        try {
            java.lang.Object obj12 = labelBlock8.draw(graphics2D9, rectangle2D10, (java.lang.Object) horizontalAlignment11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        statisticalBarRenderer0.setSeriesShape((int) (short) 0, shape4);
        statisticalBarRenderer0.setAutoPopulateSeriesShape(false);
        java.util.EventListener eventListener9 = null;
        boolean boolean10 = statisticalBarRenderer0.hasListener(eventListener9);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape15);
        statisticalBarRenderer11.setSeriesShape((int) (short) 0, shape15);
        java.lang.Object obj18 = statisticalBarRenderer11.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition();
        statisticalBarRenderer11.setBasePositiveItemLabelPosition(itemLabelPosition19);
        statisticalBarRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition19);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator22);
        java.lang.Object obj24 = statisticalBarRenderer0.clone();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = statisticalBarRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Shape shape4 = null;
        statisticalBarRenderer0.setSeriesShape(100, shape4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        float float8 = categoryAxis7.getTickMarkOutsideLength();
        java.awt.Stroke stroke9 = categoryAxis7.getAxisLineStroke();
        statisticalBarRenderer0.setBaseStroke(stroke9, false);
        java.awt.Stroke stroke13 = statisticalBarRenderer0.getSeriesStroke(0);
        java.lang.Object obj14 = statisticalBarRenderer0.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 2.0f + "'", float8 == 2.0f);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape26);
        statisticalBarRenderer22.setSeriesShape((int) (short) 0, shape26);
        java.lang.Object obj29 = statisticalBarRenderer22.clone();
        java.awt.Paint paint31 = statisticalBarRenderer22.lookupSeriesFillPaint(192);
        categoryPlot18.setRenderer((int) (short) 0, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22, false);
        boolean boolean34 = categoryPlot18.isDomainZoomable();
        categoryPlot18.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        categoryPlot18.setRangeAxis(15, valueAxis38);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.validateObject();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        int int6 = categoryAxis5.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        statisticalBarRenderer8.setSeriesShape((int) (short) 0, shape12);
        statisticalBarRenderer8.setBaseSeriesVisible(true, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis5, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot18.addChangeListener(plotChangeListener21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot18.setRangeAxisLocation(0, axisLocation24);
        org.jfree.chart.util.SortOrder sortOrder26 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot18.setColumnRenderingOrder(sortOrder26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot18.getAxisOffset();
        org.jfree.chart.plot.Plot plot29 = categoryPlot18.getParent();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(sortOrder26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNull(plot29);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getHeightConstraintType();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Comparable comparable5 = null;
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, comparable5);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleConstraint2, (org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset4);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        float float10 = categoryAxis9.getTickMarkOutsideLength();
        categoryAxis9.setCategoryLabelPositionOffset((int) (byte) 0);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape18);
        statisticalBarRenderer14.setSeriesShape((int) (short) 0, shape18);
        statisticalBarRenderer14.setAutoPopulateSeriesShape(false);
        java.util.EventListener eventListener23 = null;
        boolean boolean24 = statisticalBarRenderer14.hasListener(eventListener23);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity(shape29);
        statisticalBarRenderer25.setSeriesShape((int) (short) 0, shape29);
        java.lang.Object obj32 = statisticalBarRenderer25.clone();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = new org.jfree.chart.labels.ItemLabelPosition();
        statisticalBarRenderer25.setBasePositiveItemLabelPosition(itemLabelPosition33);
        statisticalBarRenderer14.setBaseNegativeItemLabelPosition(itemLabelPosition33);
        java.lang.Object obj36 = statisticalBarRenderer14.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, categoryAxis9, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer14);
        boolean boolean38 = categoryPlot37.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) 0, range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = rectangleConstraint2.getHeightConstraintType();
        org.jfree.chart.util.Size2D size2D7 = new org.jfree.chart.util.Size2D((double) 0, (double) (byte) 10);
        double double8 = size2D7.height;
        double double9 = size2D7.width;
        java.lang.String str10 = size2D7.toString();
        java.lang.String str11 = size2D7.toString();
        try {
            org.jfree.chart.util.Size2D size2D12 = rectangleConstraint2.calculateConstrainedSize(size2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Size2D[width=0.0, height=10.0]" + "'", str10.equals("Size2D[width=0.0, height=10.0]"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Size2D[width=0.0, height=10.0]" + "'", str11.equals("Size2D[width=0.0, height=10.0]"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockContainer0.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame2 = blockContainer0.getFrame();
        double double3 = blockContainer0.getWidth();
        double double4 = blockContainer0.getHeight();
        boolean boolean5 = blockContainer0.isEmpty();
        java.lang.Object obj6 = blockContainer0.clone();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(blockFrame2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj6);
    }
}

