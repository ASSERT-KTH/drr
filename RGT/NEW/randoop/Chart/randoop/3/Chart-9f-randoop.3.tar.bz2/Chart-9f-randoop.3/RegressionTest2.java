import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setNotify(false);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 1.0d);
        int int8 = timeSeries1.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries10.setMaximumItemAge((long) (byte) 1);
        timeSeries10.setNotify(true);
        java.util.List list15 = timeSeries10.getItems();
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        java.util.Collection collection17 = timeSeries10.getTimePeriods();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "hi!" + "'", comparable4.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(collection17);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        long long3 = day2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-2206022400001L) + "'", long3 == (-2206022400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean5 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean12 = spreadsheetDate8.isOnOrAfter(serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str15 = spreadsheetDate14.getDescription();
        int int16 = spreadsheetDate14.getDayOfWeek();
        boolean boolean17 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str20 = spreadsheetDate19.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str23 = spreadsheetDate22.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean27 = spreadsheetDate22.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SerialDate serialDate28 = spreadsheetDate19.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean34 = spreadsheetDate30.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int35 = spreadsheetDate33.toSerial();
        boolean boolean36 = spreadsheetDate19.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate33);
        boolean boolean37 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SerialDate serialDate38 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 7 + "'", int16 == 7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 35 + "'", int35 == 35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(serialDate38);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        long long4 = day3.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
        try {
            org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(9999, serialDate6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2206022400001L) + "'", long4 == (-2206022400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setNotify(false);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 1560190010308L);
        java.util.Date date10 = fixedMillisecond6.getStart();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        long long12 = month11.getMiddleMillisecond();
        org.jfree.data.time.Year year13 = month11.getYear();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "hi!" + "'", comparable4.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1310400001L) + "'", long12 == (-1310400001L));
        org.junit.Assert.assertNotNull(year13);
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test006");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries1.fireSeriesChanged();
//        timeSeries1.setMaximumItemCount(10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries1.addChangeListener(seriesChangeListener5);
//        timeSeries1.setMaximumItemCount(10);
//        timeSeries1.setMaximumItemAge((long) (byte) 1);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries12.fireSeriesChanged();
//        timeSeries12.setMaximumItemCount(10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries12.addChangeListener(seriesChangeListener16);
//        java.lang.String str18 = timeSeries12.getDomainDescription();
//        org.jfree.data.time.Year year20 = org.jfree.data.time.Year.parseYear("2019");
//        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) year20);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        long long24 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond23);
//        int int26 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((int) (byte) 10, 11);
//        java.util.Collection collection30 = timeSeries1.getTimePeriods();
//        java.beans.PropertyChangeListener propertyChangeListener31 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener31);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate34);
//        long long36 = day35.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day35.next();
//        org.jfree.data.time.SerialDate serialDate38 = day35.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate39 = day35.getSerialDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(10L);
//        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day35, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
//        java.lang.Comparable comparable43 = timeSeries1.getKey();
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560190092926L + "'", long24 == 1560190092926L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(collection30);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-2206022400001L) + "'", long36 == (-2206022400001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(timeSeries42);
//        org.junit.Assert.assertTrue("'" + comparable43 + "' != '" + 1.0d + "'", comparable43.equals(1.0d));
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemCount(10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.addChangeListener(seriesChangeListener5);
        timeSeries1.setMaximumItemCount(10);
        timeSeries1.setMaximumItemAge((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries12.fireSeriesChanged();
        timeSeries12.setMaximumItemCount(10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries12.addChangeListener(seriesChangeListener16);
        java.lang.String str18 = timeSeries12.getDomainDescription();
        org.jfree.data.time.Year year20 = org.jfree.data.time.Year.parseYear("2019");
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) year20);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year20.next();
        int int24 = year20.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year20.previous();
        int int26 = year20.getYear();
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str4 = spreadsheetDate3.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        boolean boolean8 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        java.lang.String str9 = spreadsheetDate6.getDescription();
        int int10 = spreadsheetDate6.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate6.getPreviousDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, (org.jfree.data.time.SerialDate) spreadsheetDate6);
        try {
            org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) -1, serialDate13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(10, (int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str5 = spreadsheetDate4.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate7);
        boolean boolean9 = spreadsheetDate4.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean16 = spreadsheetDate12.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        int int17 = spreadsheetDate15.toSerial();
        boolean boolean18 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        int int20 = day19.getMonth();
        long long21 = day19.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
        java.lang.Number number23 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, number23);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 35 + "'", int17 == 35);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 35L + "'", long21 == 35L);
        org.junit.Assert.assertNotNull(serialDate22);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-457));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -457");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getFirstMillisecond();
        java.lang.String str3 = year0.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long9 = timeSeries8.getMaximumItemAge();
        boolean boolean10 = year0.equals((java.lang.Object) timeSeries8);
        long long11 = timeSeries8.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries2.fireSeriesChanged();
        timeSeries2.setMaximumItemCount(10);
        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) 10);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.lang.String str8 = year7.toString();
        boolean boolean9 = fixedMillisecond0.equals((java.lang.Object) year7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (double) (short) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int15 = spreadsheetDate13.getDayOfWeek();
        java.lang.String str16 = spreadsheetDate13.getDescription();
        boolean boolean17 = timeSeriesDataItem11.equals((java.lang.Object) spreadsheetDate13);
        int int18 = spreadsheetDate13.getMonth();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 7 + "'", int15 == 7);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long2 = timeSeries1.getMaximumItemAge();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long6 = timeSeries5.getMaximumItemAge();
        java.lang.String str7 = timeSeries5.getDescription();
        timeSeries5.setDomainDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries5);
        java.lang.String str11 = timeSeries5.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) 0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 11);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass20 = year19.getClass();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem18, (java.lang.Class) wildcardClass20);
        java.lang.String str22 = timeSeries21.getDomainDescription();
        try {
            org.jfree.data.time.TimeSeries timeSeries25 = timeSeries21.createCopy(100, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Time" + "'", str22.equals("Time"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries2.setNotify(false);
        java.lang.Comparable comparable5 = timeSeries2.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 1560190010308L);
        java.util.Calendar calendar11 = null;
        fixedMillisecond7.peg(calendar11);
        long long13 = fixedMillisecond7.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries16.setNotify(false);
        timeSeries16.removeAgedItems(true);
        int int21 = timeSeries16.getItemCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str24 = spreadsheetDate23.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean28 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        timeSeries16.setKey((java.lang.Comparable) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addDays(2, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean36 = spreadsheetDate32.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        int int37 = spreadsheetDate35.toSerial();
        boolean boolean38 = spreadsheetDate26.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        int int39 = fixedMillisecond7.compareTo((java.lang.Object) spreadsheetDate35);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, (org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean46 = spreadsheetDate42.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate45);
        int int47 = spreadsheetDate45.toSerial();
        boolean boolean48 = spreadsheetDate35.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "hi!" + "'", comparable5.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2L + "'", long13 == 2L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 35 + "'", int37 == 35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 35 + "'", int47 == 35);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test017");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getMiddleMillisecond(calendar2);
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 24234L);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560190093638L + "'", long1 == 1560190093638L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560190093638L + "'", long3 == 1560190093638L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560190093638L + "'", long4 == 1560190093638L);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setNotify(false);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 1560190010308L);
        java.util.Date date10 = fixedMillisecond6.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date10);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries14.setNotify(false);
        java.lang.Comparable comparable17 = timeSeries14.getKey();
        timeSeries14.setMaximumItemCount(3);
        int int20 = month12.compareTo((java.lang.Object) timeSeries14);
        timeSeries14.clear();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "hi!" + "'", comparable4.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + "hi!" + "'", comparable17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test019");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
//        long long2 = timeSeries1.getMaximumItemAge();
//        java.lang.String str3 = timeSeries1.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
//        long long6 = timeSeries5.getMaximumItemAge();
//        java.lang.String str7 = timeSeries5.getDescription();
//        timeSeries5.setDomainDescription("2019");
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries5);
//        java.lang.String str11 = timeSeries5.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries5.createCopy((int) (short) 10, 35);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        long long16 = month15.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month15.previous();
//        int int18 = month15.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
//        timeSeries20.setDescription("ERROR : Relative To String");
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries24.fireSeriesChanged();
//        timeSeries24.setMaximumItemCount(10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries24.addChangeListener(seriesChangeListener28);
//        timeSeries24.setMaximumItemCount(10);
//        timeSeries24.setMaximumItemAge((long) (byte) 1);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries35.fireSeriesChanged();
//        timeSeries35.setMaximumItemCount(10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener39 = null;
//        timeSeries35.addChangeListener(seriesChangeListener39);
//        java.lang.String str41 = timeSeries35.getDomainDescription();
//        org.jfree.data.time.Year year43 = org.jfree.data.time.Year.parseYear("2019");
//        timeSeries35.delete((org.jfree.data.time.RegularTimePeriod) year43);
//        timeSeries24.delete((org.jfree.data.time.RegularTimePeriod) year43);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
//        long long47 = fixedMillisecond46.getFirstMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent48 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond46);
//        int int49 = timeSeries24.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries20.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
//        java.lang.Class class52 = timeSeries51.getTimePeriodClass();
//        java.lang.String str53 = timeSeries51.getRangeDescription();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
//        org.junit.Assert.assertNull(str3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertNull(str11);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 24234L + "'", long16 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Time" + "'", str41.equals("Time"));
//        org.junit.Assert.assertNotNull(year43);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560190093684L + "'", long47 == 1560190093684L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
//        org.junit.Assert.assertNull(timeSeriesDataItem50);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertNotNull(class52);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Value" + "'", str53.equals("Value"));
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries2.setNotify(false);
        timeSeries2.removeAgedItems(true);
        int int7 = timeSeries2.getItemCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str10 = spreadsheetDate9.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean14 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        timeSeries2.setKey((java.lang.Comparable) spreadsheetDate12);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addDays(2, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean22 = spreadsheetDate18.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        int int23 = spreadsheetDate21.toSerial();
        boolean boolean24 = spreadsheetDate12.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        spreadsheetDate21.setDescription("Fourth");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 35 + "'", int23 == 35);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean5 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) spreadsheetDate4);
        java.lang.Object obj7 = seriesChangeEvent6.getSource();
        java.lang.String str8 = seriesChangeEvent6.toString();
        java.lang.String str9 = seriesChangeEvent6.toString();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=3-February-1900]" + "'", str8.equals("org.jfree.data.general.SeriesChangeEvent[source=3-February-1900]"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=3-February-1900]" + "'", str9.equals("org.jfree.data.general.SeriesChangeEvent[source=3-February-1900]"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.lang.String str3 = fixedMillisecond1.toString();
        long long4 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar5 = null;
        fixedMillisecond1.peg(calendar5);
        java.lang.Object obj7 = null;
        int int8 = fixedMillisecond1.compareTo(obj7);
        long long9 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str3.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-452L) + "'", long4 == (-452L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-452L) + "'", long9 == (-452L));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long2 = timeSeries1.getMaximumItemAge();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long6 = timeSeries5.getMaximumItemAge();
        java.lang.String str7 = timeSeries5.getDescription();
        timeSeries5.setDomainDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries5.addChangeListener(seriesChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.previous();
        java.lang.String str16 = fixedMillisecond14.toString();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long19 = timeSeries18.getMaximumItemAge();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        java.lang.Number number22 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        int int23 = fixedMillisecond14.compareTo((java.lang.Object) number22);
        boolean boolean24 = timeSeries5.equals((java.lang.Object) fixedMillisecond14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
        long long28 = day27.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day27.next();
        org.jfree.data.time.SerialDate serialDate30 = day27.getSerialDate();
        java.lang.Number number31 = timeSeries5.getValue((org.jfree.data.time.RegularTimePeriod) day27);
        timeSeries5.removeAgedItems(false);
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries5.removePropertyChangeListener(propertyChangeListener34);
        timeSeries5.setDomainDescription("Fourth");
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str16.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-2206022400001L) + "'", long28 == (-2206022400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNull(number31);
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test025");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
//        long long2 = timeSeries1.getMaximumItemAge();
//        java.lang.String str3 = timeSeries1.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
//        long long6 = timeSeries5.getMaximumItemAge();
//        java.lang.String str7 = timeSeries5.getDescription();
//        timeSeries5.setDomainDescription("2019");
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries5);
//        java.lang.String str11 = timeSeries5.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries5.createCopy((int) (short) 10, 35);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        long long16 = month15.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month15.previous();
//        int int18 = month15.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
//        timeSeries20.setDescription("ERROR : Relative To String");
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries24.fireSeriesChanged();
//        timeSeries24.setMaximumItemCount(10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries24.addChangeListener(seriesChangeListener28);
//        timeSeries24.setMaximumItemCount(10);
//        timeSeries24.setMaximumItemAge((long) (byte) 1);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries35.fireSeriesChanged();
//        timeSeries35.setMaximumItemCount(10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener39 = null;
//        timeSeries35.addChangeListener(seriesChangeListener39);
//        java.lang.String str41 = timeSeries35.getDomainDescription();
//        org.jfree.data.time.Year year43 = org.jfree.data.time.Year.parseYear("2019");
//        timeSeries35.delete((org.jfree.data.time.RegularTimePeriod) year43);
//        timeSeries24.delete((org.jfree.data.time.RegularTimePeriod) year43);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
//        long long47 = fixedMillisecond46.getFirstMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent48 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond46);
//        int int49 = timeSeries24.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries20.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
//        java.lang.Class class52 = timeSeries51.getTimePeriodClass();
//        int int53 = timeSeries51.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        long long55 = fixedMillisecond54.getFirstMillisecond();
//        try {
//            timeSeries51.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, (double) 1560190040675L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
//        org.junit.Assert.assertNull(str3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertNull(str11);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 24234L + "'", long16 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Time" + "'", str41.equals("Time"));
//        org.junit.Assert.assertNotNull(year43);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560190093901L + "'", long47 == 1560190093901L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
//        org.junit.Assert.assertNull(timeSeriesDataItem50);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertNotNull(class52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560190093903L + "'", long55 == 1560190093903L);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setNotify(false);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        java.util.List list8 = timeSeries1.getItems();
        timeSeries1.setRangeDescription("Last");
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries12.setNotify(false);
        java.lang.Comparable comparable15 = timeSeries12.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond17.next();
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond17.getMiddleMillisecond(calendar20);
        int int22 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        java.lang.Class<?> wildcardClass23 = timeSeries1.getClass();
        java.lang.Comparable comparable24 = timeSeries1.getKey();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "hi!" + "'", comparable4.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + "hi!" + "'", comparable15.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2L + "'", long21 == 2L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + "hi!" + "'", comparable24.equals("hi!"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setNotify(false);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 1560190010308L);
        java.util.Date date10 = fixedMillisecond6.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        int int12 = day11.getMonth();
        java.lang.String str13 = day11.toString();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "hi!" + "'", comparable4.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-1969" + "'", str13.equals("31-December-1969"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(6, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Class<?> wildcardClass2 = seriesException1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond4.previous();
        java.lang.String str6 = fixedMillisecond4.toString();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries8.setNotify(false);
        java.lang.Comparable comparable11 = timeSeries8.getKey();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries8.removePropertyChangeListener(propertyChangeListener12);
        int int14 = fixedMillisecond4.compareTo((java.lang.Object) propertyChangeListener12);
        org.jfree.data.general.SeriesException seriesException16 = new org.jfree.data.general.SeriesException("ERROR : Relative To String");
        boolean boolean17 = fixedMillisecond4.equals((java.lang.Object) seriesException16);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException16);
        java.lang.String str19 = seriesException16.toString();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str6.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + "hi!" + "'", comparable11.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: ERROR : Relative To String" + "'", str19.equals("org.jfree.data.general.SeriesException: ERROR : Relative To String"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setNotify(false);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 1560190010308L);
        java.util.Date date10 = fixedMillisecond6.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.previous();
        java.lang.String str13 = day11.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day11.previous();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = day11.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "hi!" + "'", comparable4.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-1969" + "'", str13.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((-435), true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long2 = timeSeries1.getMaximumItemAge();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long6 = timeSeries5.getMaximumItemAge();
        java.lang.String str7 = timeSeries5.getDescription();
        timeSeries5.setDomainDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries5);
        int int11 = timeSeries5.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long14 = timeSeries13.getMaximumItemAge();
        java.lang.String str15 = timeSeries13.getDescription();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long18 = timeSeries17.getMaximumItemAge();
        java.lang.String str19 = timeSeries17.getDescription();
        timeSeries17.setDomainDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries13.addAndOrUpdate(timeSeries17);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries17.addChangeListener(seriesChangeListener23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond26.previous();
        java.lang.String str28 = fixedMillisecond26.toString();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long31 = timeSeries30.getMaximumItemAge();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.lang.String str33 = year32.toString();
        java.lang.Number number34 = timeSeries30.getValue((org.jfree.data.time.RegularTimePeriod) year32);
        int int35 = fixedMillisecond26.compareTo((java.lang.Object) number34);
        boolean boolean36 = timeSeries17.equals((java.lang.Object) fixedMillisecond26);
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries5.addAndOrUpdate(timeSeries17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries42.fireSeriesChanged();
        timeSeries42.setMaximumItemCount(10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener46 = null;
        timeSeries42.addChangeListener(seriesChangeListener46);
        timeSeries42.setMaximumItemCount(10);
        timeSeries42.setMaximumItemAge((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries53.fireSeriesChanged();
        timeSeries53.setMaximumItemCount(10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener57 = null;
        timeSeries53.addChangeListener(seriesChangeListener57);
        java.lang.String str59 = timeSeries53.getDomainDescription();
        org.jfree.data.time.Year year61 = org.jfree.data.time.Year.parseYear("2019");
        timeSeries53.delete((org.jfree.data.time.RegularTimePeriod) year61);
        timeSeries42.delete((org.jfree.data.time.RegularTimePeriod) year61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = year61.next();
        int int65 = year61.getYear();
        int int66 = day40.compareTo((java.lang.Object) int65);
        long long67 = day40.getSerialIndex();
        int int68 = day40.getMonth();
        int int69 = timeSeries37.getIndex((org.jfree.data.time.RegularTimePeriod) day40);
        boolean boolean70 = timeSeries37.getNotify();
        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries72.setNotify(false);
        java.lang.Comparable comparable75 = timeSeries72.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond77 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = timeSeries72.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond77);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem80 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond77, (double) 1560190010308L);
        java.util.Date date81 = fixedMillisecond77.getStart();
        long long82 = fixedMillisecond77.getFirstMillisecond();
        int int83 = timeSeries37.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond77);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = fixedMillisecond77.next();
        java.util.Calendar calendar85 = null;
        long long86 = fixedMillisecond77.getMiddleMillisecond(calendar85);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str28.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2019" + "'", str33.equals("2019"));
        org.junit.Assert.assertNull(number34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Time" + "'", str59.equals("Time"));
        org.junit.Assert.assertNotNull(year61);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 2019 + "'", int65 == 2019);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 35L + "'", long67 == 35L);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 2 + "'", int68 == 2);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + comparable75 + "' != '" + "hi!" + "'", comparable75.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem78);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 2L + "'", long82 == 2L);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-1) + "'", int83 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod84);
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 2L + "'", long86 == 2L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        long long2 = year1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        long long4 = year1.getLastMillisecond();
        long long5 = year1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1900L + "'", long2 == 1900L);
        org.junit.Assert.assertNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2177424000001L) + "'", long4 == (-2177424000001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2208960000000L) + "'", long5 == (-2208960000000L));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries2.fireSeriesChanged();
        timeSeries2.setMaximumItemCount(10);
        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) 10);
        java.util.Date date7 = fixedMillisecond0.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond0.next();
        java.util.Date date9 = fixedMillisecond0.getStart();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long2 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.lang.String str4 = year3.toString();
        java.lang.Number number5 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year3);
        java.util.Date date6 = year3.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries9.fireSeriesChanged();
        timeSeries9.setMaximumItemCount(10);
        boolean boolean13 = fixedMillisecond7.equals((java.lang.Object) 10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        boolean boolean16 = fixedMillisecond7.equals((java.lang.Object) year14);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries20.fireSeriesChanged();
        timeSeries20.setMaximumItemCount(10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries20.addChangeListener(seriesChangeListener24);
        java.lang.String str26 = timeSeries20.getDomainDescription();
        org.jfree.data.time.Year year28 = org.jfree.data.time.Year.parseYear("2019");
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) year28);
        java.lang.Class<?> wildcardClass30 = year28.getClass();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year14, "", "2019", (java.lang.Class) wildcardClass30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean39 = spreadsheetDate35.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str42 = spreadsheetDate41.getDescription();
        boolean boolean44 = spreadsheetDate33.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate35, (org.jfree.data.time.SerialDate) spreadsheetDate41, 11);
        java.util.Date date45 = spreadsheetDate35.toDate();
        java.util.TimeZone timeZone46 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date45, timeZone46);
        org.jfree.data.general.SeriesException seriesException49 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: hi!");
        java.lang.Class<?> wildcardClass50 = seriesException49.getClass();
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries52.setNotify(false);
        java.lang.Comparable comparable55 = timeSeries52.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries52.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57, (double) 1560190010308L);
        java.util.Date date61 = fixedMillisecond57.getStart();
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date61, timeZone62);
        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month(date45, timeZone62);
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date6, timeZone62);
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertNotNull(year28);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertTrue("'" + comparable55 + "' != '" + "hi!" + "'", comparable55.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem58);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNull(regularTimePeriod63);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean7 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) spreadsheetDate6);
        org.jfree.data.time.SerialDate serialDate9 = serialDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str12 = spreadsheetDate11.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str15 = spreadsheetDate14.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate14.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SerialDate serialDate20 = spreadsheetDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean21 = spreadsheetDate6.isAfter(serialDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str25 = spreadsheetDate24.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str28 = spreadsheetDate27.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean32 = spreadsheetDate27.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SerialDate serialDate33 = spreadsheetDate24.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, (org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str37 = spreadsheetDate36.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str40 = spreadsheetDate39.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate42);
        boolean boolean44 = spreadsheetDate39.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.SerialDate serialDate45 = spreadsheetDate36.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate39);
        java.lang.Class<?> wildcardClass46 = serialDate45.getClass();
        boolean boolean47 = spreadsheetDate27.isAfter(serialDate45);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean55 = spreadsheetDate51.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate54);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str58 = spreadsheetDate57.getDescription();
        boolean boolean60 = spreadsheetDate49.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate51, (org.jfree.data.time.SerialDate) spreadsheetDate57, 11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str63 = spreadsheetDate62.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate65);
        boolean boolean67 = spreadsheetDate62.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate65);
        java.lang.String str68 = spreadsheetDate65.getDescription();
        org.jfree.data.time.SerialDate serialDate69 = spreadsheetDate57.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate65);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str72 = spreadsheetDate71.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate74);
        boolean boolean76 = spreadsheetDate71.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate74);
        java.lang.String str77 = spreadsheetDate74.getDescription();
        int int78 = spreadsheetDate74.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate80 = spreadsheetDate74.getPreviousDayOfWeek(5);
        boolean boolean81 = spreadsheetDate57.isBefore(serialDate80);
        boolean boolean82 = spreadsheetDate27.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate57);
        boolean boolean83 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNull(str68);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertNull(str72);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertNull(str77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 3 + "'", int78 == 3);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        timeSeries1.setDomainDescription("Nearest");
        timeSeries1.clear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str7 = spreadsheetDate6.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate6.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        java.lang.String str12 = spreadsheetDate9.getDescription();
        int int13 = spreadsheetDate9.getDayOfMonth();
        java.lang.Object obj14 = null;
        boolean boolean15 = spreadsheetDate9.equals(obj14);
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate9.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
        timeSeries1.add(regularTimePeriod19, (java.lang.Number) 28799999L, true);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str3 = spreadsheetDate2.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean7 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.lang.String str8 = spreadsheetDate5.getDescription();
        int int9 = spreadsheetDate5.getDayOfMonth();
        java.lang.Object obj10 = null;
        boolean boolean11 = spreadsheetDate5.equals(obj10);
        int int12 = spreadsheetDate5.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean18 = spreadsheetDate14.isOnOrAfter(serialDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str21 = spreadsheetDate20.getDescription();
        int int22 = spreadsheetDate20.getDayOfWeek();
        boolean boolean23 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean24 = spreadsheetDate5.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        try {
            org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) ' ', (org.jfree.data.time.SerialDate) spreadsheetDate14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 7 + "'", int22 == 7);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test039");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond0);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560190095399L + "'", long1 == 1560190095399L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560190095399L + "'", long4 == 1560190095399L);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        long long3 = day2.getLastMillisecond();
        long long4 = day2.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries7.fireSeriesChanged();
        timeSeries7.setMaximumItemCount(10);
        boolean boolean11 = fixedMillisecond5.equals((java.lang.Object) 10);
        boolean boolean12 = day2.equals((java.lang.Object) fixedMillisecond5);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long15 = timeSeries14.getMaximumItemAge();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.lang.String str17 = year16.toString();
        java.lang.Number number18 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) year16);
        java.util.Date date19 = year16.getEnd();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date19);
        java.util.Date date22 = day21.getStart();
        boolean boolean23 = fixedMillisecond5.equals((java.lang.Object) day21);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-2206022400001L) + "'", long3 == (-2206022400001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2206022400001L) + "'", long4 == (-2206022400001L));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setNotify(false);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 1560190010308L);
        java.util.Calendar calendar10 = null;
        fixedMillisecond6.peg(calendar10);
        long long12 = fixedMillisecond6.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries15.setNotify(false);
        timeSeries15.removeAgedItems(true);
        int int20 = timeSeries15.getItemCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str23 = spreadsheetDate22.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean27 = spreadsheetDate22.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        timeSeries15.setKey((java.lang.Comparable) spreadsheetDate25);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addDays(2, (org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean35 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate34);
        int int36 = spreadsheetDate34.toSerial();
        boolean boolean37 = spreadsheetDate25.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate34);
        int int38 = fixedMillisecond6.compareTo((java.lang.Object) spreadsheetDate34);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate45 = spreadsheetDate41.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate44);
        int int46 = spreadsheetDate44.getMonth();
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addDays(1, (org.jfree.data.time.SerialDate) spreadsheetDate44);
        serialDate47.setDescription("Value");
        boolean boolean50 = spreadsheetDate34.isBefore(serialDate47);
        int int51 = spreadsheetDate34.getDayOfWeek();
        boolean boolean53 = spreadsheetDate34.equals((java.lang.Object) 1);
        int int54 = spreadsheetDate34.getMonth();
        spreadsheetDate34.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries58.fireSeriesChanged();
        timeSeries58.setMaximumItemCount(10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener62 = null;
        timeSeries58.addChangeListener(seriesChangeListener62);
        java.lang.String str64 = timeSeries58.getDomainDescription();
        org.jfree.data.time.Year year66 = org.jfree.data.time.Year.parseYear("2019");
        timeSeries58.delete((org.jfree.data.time.RegularTimePeriod) year66);
        java.lang.Class<?> wildcardClass68 = year66.getClass();
        org.jfree.data.time.TimeSeries timeSeries69 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", (java.lang.Class) wildcardClass68);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "hi!" + "'", comparable4.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 35 + "'", int36 == 35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 7 + "'", int51 == 7);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2 + "'", int54 == 2);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "Time" + "'", str64.equals("Time"));
        org.junit.Assert.assertNotNull(year66);
        org.junit.Assert.assertNotNull(wildcardClass68);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries2.setNotify(false);
        java.lang.Comparable comparable5 = timeSeries2.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 1560190010308L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries13.fireSeriesChanged();
        timeSeries13.setMaximumItemCount(10);
        boolean boolean17 = fixedMillisecond11.equals((java.lang.Object) 10);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.lang.String str19 = year18.toString();
        boolean boolean20 = fixedMillisecond11.equals((java.lang.Object) year18);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries24.fireSeriesChanged();
        timeSeries24.setMaximumItemCount(10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
        timeSeries24.addChangeListener(seriesChangeListener28);
        java.lang.String str30 = timeSeries24.getDomainDescription();
        org.jfree.data.time.Year year32 = org.jfree.data.time.Year.parseYear("2019");
        timeSeries24.delete((org.jfree.data.time.RegularTimePeriod) year32);
        java.lang.Class<?> wildcardClass34 = year32.getClass();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year18, "", "2019", (java.lang.Class) wildcardClass34);
        int int36 = timeSeriesDataItem10.compareTo((java.lang.Object) year18);
        long long37 = year18.getLastMillisecond();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(10, year18);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "hi!" + "'", comparable5.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Time" + "'", str30.equals("Time"));
        org.junit.Assert.assertNotNull(year32);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1577865599999L + "'", long37 == 1577865599999L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.lang.String str3 = fixedMillisecond1.toString();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long6 = timeSeries5.getMaximumItemAge();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.lang.String str8 = year7.toString();
        java.lang.Number number9 = timeSeries5.getValue((org.jfree.data.time.RegularTimePeriod) year7);
        int int10 = fixedMillisecond1.compareTo((java.lang.Object) number9);
        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Class<?> wildcardClass13 = seriesException12.getClass();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, (java.lang.Class) wildcardClass13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond16.previous();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond16);
        java.util.Calendar calendar19 = null;
        fixedMillisecond16.peg(calendar19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond16.next();
        java.lang.Number number22 = timeSeries14.getValue(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str3.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNull(number22);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.lang.String str3 = fixedMillisecond1.toString();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries5.setNotify(false);
        java.lang.Comparable comparable8 = timeSeries5.getKey();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries5.removePropertyChangeListener(propertyChangeListener9);
        int int11 = fixedMillisecond1.compareTo((java.lang.Object) propertyChangeListener9);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond1.getMiddleMillisecond(calendar12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond1.previous();
        long long15 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str3.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + "hi!" + "'", comparable8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-452L) + "'", long13 == (-452L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-452L) + "'", long15 == (-452L));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        java.lang.String str2 = timeSeries1.getDescription();
        boolean boolean4 = timeSeries1.equals((java.lang.Object) "org.jfree.data.general.SeriesException: hi!");
        java.util.Collection collection5 = timeSeries1.getTimePeriods();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(collection5);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test046");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
//        long long2 = timeSeries1.getMaximumItemAge();
//        java.lang.String str3 = timeSeries1.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
//        long long6 = timeSeries5.getMaximumItemAge();
//        java.lang.String str7 = timeSeries5.getDescription();
//        timeSeries5.setDomainDescription("2019");
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries5);
//        java.lang.String str11 = timeSeries5.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries5.createCopy((int) (short) 10, 35);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        long long16 = month15.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month15.previous();
//        int int18 = month15.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
//        timeSeries20.setDescription("ERROR : Relative To String");
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries24.fireSeriesChanged();
//        timeSeries24.setMaximumItemCount(10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries24.addChangeListener(seriesChangeListener28);
//        timeSeries24.setMaximumItemCount(10);
//        timeSeries24.setMaximumItemAge((long) (byte) 1);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries35.fireSeriesChanged();
//        timeSeries35.setMaximumItemCount(10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener39 = null;
//        timeSeries35.addChangeListener(seriesChangeListener39);
//        java.lang.String str41 = timeSeries35.getDomainDescription();
//        org.jfree.data.time.Year year43 = org.jfree.data.time.Year.parseYear("2019");
//        timeSeries35.delete((org.jfree.data.time.RegularTimePeriod) year43);
//        timeSeries24.delete((org.jfree.data.time.RegularTimePeriod) year43);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
//        long long47 = fixedMillisecond46.getFirstMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent48 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond46);
//        int int49 = timeSeries24.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries20.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
//        java.lang.Class class52 = timeSeries51.getTimePeriodClass();
//        int int53 = timeSeries51.getItemCount();
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries51.getDataItem((int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
//        org.junit.Assert.assertNull(str3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertNull(str11);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 24234L + "'", long16 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Time" + "'", str41.equals("Time"));
//        org.junit.Assert.assertNotNull(year43);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560190095876L + "'", long47 == 1560190095876L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
//        org.junit.Assert.assertNull(timeSeriesDataItem50);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertNotNull(class52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test047");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
//        long long2 = timeSeries1.getMaximumItemAge();
//        java.lang.String str3 = timeSeries1.getDescription();
//        timeSeries1.setDomainDescription("2019");
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
//        timeSeries7.setNotify(false);
//        java.lang.Comparable comparable10 = timeSeries7.getKey();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) 1.0d);
//        int int14 = year11.getYear();
//        boolean boolean16 = year11.equals((java.lang.Object) 1.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year11.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries24.fireSeriesChanged();
//        timeSeries24.setMaximumItemCount(10);
//        boolean boolean28 = fixedMillisecond22.equals((java.lang.Object) 10);
//        long long29 = fixedMillisecond22.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year11, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
//        java.lang.String str33 = month32.toString();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        java.lang.String str35 = year34.toString();
//        long long36 = year34.getFirstMillisecond();
//        java.lang.String str37 = year34.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) 0);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
//        timeSeries41.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
//        timeSeries45.setNotify(false);
//        java.lang.Comparable comparable48 = timeSeries45.getKey();
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries45.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year49, (java.lang.Number) 1.0d);
//        int int52 = year49.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year49, (java.lang.Number) (-1L));
//        boolean boolean55 = timeSeriesDataItem39.equals((java.lang.Object) timeSeriesDataItem54);
//        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
//        long long58 = timeSeries57.getMaximumItemAge();
//        java.lang.String str59 = timeSeries57.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
//        long long62 = timeSeries61.getMaximumItemAge();
//        java.lang.String str63 = timeSeries61.getDescription();
//        timeSeries61.setDomainDescription("2019");
//        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries57.addAndOrUpdate(timeSeries61);
//        int int67 = timeSeries61.getItemCount();
//        java.util.List list68 = timeSeries61.getItems();
//        java.util.List list69 = timeSeries61.getItems();
//        boolean boolean70 = timeSeriesDataItem39.equals((java.lang.Object) list69);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = timeSeriesDataItem39.getPeriod();
//        boolean boolean72 = month32.equals((java.lang.Object) timeSeriesDataItem39);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        java.lang.String str75 = spreadsheetDate74.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate77);
//        boolean boolean79 = spreadsheetDate74.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate77);
//        java.lang.String str80 = spreadsheetDate77.getDescription();
//        java.util.Date date81 = spreadsheetDate77.toDate();
//        org.jfree.data.time.SerialDate serialDate82 = org.jfree.data.time.SerialDate.createInstance(date81);
//        int int83 = timeSeriesDataItem39.compareTo((java.lang.Object) serialDate82);
//        try {
//            timeSeries1.add(timeSeriesDataItem39, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
//        org.junit.Assert.assertNull(str3);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + "hi!" + "'", comparable10.equals("hi!"));
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560190095892L + "'", long29 == 1560190095892L);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "June 2019" + "'", str33.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2019" + "'", str35.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1546329600000L + "'", long36 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "2019" + "'", str37.equals("2019"));
//        org.junit.Assert.assertTrue("'" + comparable48 + "' != '" + "hi!" + "'", comparable48.equals("hi!"));
//        org.junit.Assert.assertNull(timeSeriesDataItem51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 9223372036854775807L + "'", long58 == 9223372036854775807L);
//        org.junit.Assert.assertNull(str59);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 9223372036854775807L + "'", long62 == 9223372036854775807L);
//        org.junit.Assert.assertNull(str63);
//        org.junit.Assert.assertNotNull(timeSeries66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
//        org.junit.Assert.assertNotNull(list68);
//        org.junit.Assert.assertNotNull(list69);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertNull(str75);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
//        org.junit.Assert.assertNull(str80);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(serialDate82);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test049");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries1.fireSeriesChanged();
//        timeSeries1.setMaximumItemCount(10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries1.addChangeListener(seriesChangeListener5);
//        timeSeries1.setMaximumItemCount(10);
//        timeSeries1.setMaximumItemAge((long) (byte) 1);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries12.fireSeriesChanged();
//        timeSeries12.setMaximumItemCount(10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries12.addChangeListener(seriesChangeListener16);
//        java.lang.String str18 = timeSeries12.getDomainDescription();
//        org.jfree.data.time.Year year20 = org.jfree.data.time.Year.parseYear("2019");
//        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) year20);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        long long24 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond23);
//        int int26 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((int) (byte) 10, 11);
//        java.util.Collection collection30 = timeSeries1.getTimePeriods();
//        java.beans.PropertyChangeListener propertyChangeListener31 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener31);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries1.getDataItem((-435));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560190095929L + "'", long24 == 1560190095929L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(collection30);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long2 = timeSeries1.getMaximumItemAge();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long6 = timeSeries5.getMaximumItemAge();
        java.lang.String str7 = timeSeries5.getDescription();
        timeSeries5.setDomainDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries5.addChangeListener(seriesChangeListener11);
        java.lang.Class class13 = timeSeries5.getTimePeriodClass();
        try {
            java.lang.Number number15 = timeSeries5.getValue((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(class13);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long2 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.lang.String str4 = year3.toString();
        java.lang.Number number5 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year3);
        java.util.Date date6 = year3.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6);
        java.util.Date date9 = day8.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.lang.String str13 = year12.toString();
        long long14 = year12.getFirstMillisecond();
        java.lang.String str15 = year12.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 0);
        int int18 = fixedMillisecond11.compareTo((java.lang.Object) year12);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long21 = timeSeries20.getMaximumItemAge();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        java.lang.String str23 = year22.toString();
        java.lang.Number number24 = timeSeries20.getValue((org.jfree.data.time.RegularTimePeriod) year22);
        java.util.Date date25 = year22.getEnd();
        int int26 = year12.compareTo((java.lang.Object) date25);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond29.next();
        long long31 = fixedMillisecond29.getSerialIndex();
        java.util.Date date32 = fixedMillisecond29.getTime();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str35 = spreadsheetDate34.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str38 = spreadsheetDate37.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate40);
        boolean boolean42 = spreadsheetDate37.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.jfree.data.time.SerialDate serialDate43 = spreadsheetDate34.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean49 = spreadsheetDate45.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate48);
        int int50 = spreadsheetDate48.toSerial();
        boolean boolean51 = spreadsheetDate34.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate48);
        java.util.Date date52 = spreadsheetDate34.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str55 = spreadsheetDate54.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate57);
        boolean boolean59 = spreadsheetDate54.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate57);
        java.lang.String str60 = spreadsheetDate57.getDescription();
        java.util.Date date61 = spreadsheetDate57.toDate();
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date61, timeZone62);
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date52, timeZone62);
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(date32, timeZone62);
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date25, timeZone62);
        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(date9, timeZone62);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
        org.junit.Assert.assertNull(number24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-452L) + "'", long31 == (-452L));
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 35 + "'", int50 == 35);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNull(str60);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(timeZone62);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long2 = timeSeries1.getMaximumItemAge();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long6 = timeSeries5.getMaximumItemAge();
        java.lang.String str7 = timeSeries5.getDescription();
        timeSeries5.setDomainDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries5);
        java.lang.String str11 = timeSeries5.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) 0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 11);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate21);
        long long23 = day22.getMiddleMillisecond();
        boolean boolean24 = timeSeries19.equals((java.lang.Object) day22);
        timeSeries19.clear();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-2206065600001L) + "'", long23 == (-2206065600001L));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int3 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str6 = spreadsheetDate5.getDescription();
        int int7 = spreadsheetDate5.getDayOfWeek();
        int int8 = spreadsheetDate5.getYYYY();
        int int9 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate15 = spreadsheetDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int16 = spreadsheetDate14.getMonth();
        boolean boolean17 = spreadsheetDate5.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean23 = spreadsheetDate19.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        int int24 = spreadsheetDate22.toSerial();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate29);
        int int31 = spreadsheetDate29.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str34 = spreadsheetDate33.getDescription();
        int int35 = spreadsheetDate33.getDayOfWeek();
        int int36 = spreadsheetDate33.getYYYY();
        int int37 = spreadsheetDate29.compare((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addYears(3, (org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, serialDate38);
        boolean boolean40 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate22, serialDate38);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate22);
        int int42 = spreadsheetDate22.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 7 + "'", int7 == 7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1900 + "'", int8 == 1900);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 35 + "'", int24 == 35);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 7 + "'", int31 == 7);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 7 + "'", int35 == 7);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1900 + "'", int36 == 1900);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 7 + "'", int42 == 7);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 1L);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries5.setNotify(false);
        java.lang.Comparable comparable8 = timeSeries5.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (double) 1560190010308L);
        java.util.Date date14 = fixedMillisecond10.getStart();
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond10.getLastMillisecond(calendar15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (double) 5);
        timeSeries1.setKey((java.lang.Comparable) 1560190057677L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + "hi!" + "'", comparable8.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2L + "'", long16 == 2L);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Time");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: hi!");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Throwable[] throwableArray5 = seriesException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test056");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries1.fireSeriesChanged();
//        timeSeries1.setMaximumItemCount(10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries1.addChangeListener(seriesChangeListener5);
//        timeSeries1.setMaximumItemCount(10);
//        timeSeries1.setMaximumItemAge((long) (byte) 1);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries12.fireSeriesChanged();
//        timeSeries12.setMaximumItemCount(10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries12.addChangeListener(seriesChangeListener16);
//        java.lang.String str18 = timeSeries12.getDomainDescription();
//        org.jfree.data.time.Year year20 = org.jfree.data.time.Year.parseYear("2019");
//        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) year20);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        long long24 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond23);
//        int int26 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((int) (byte) 10, 11);
//        java.util.Collection collection30 = timeSeries1.getTimePeriods();
//        java.beans.PropertyChangeListener propertyChangeListener31 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener31);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate34);
//        long long36 = day35.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day35.next();
//        org.jfree.data.time.SerialDate serialDate38 = day35.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate39 = day35.getSerialDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(10L);
//        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day35, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
//        timeSeries42.removeAgedItems(false);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560190097076L + "'", long24 == 1560190097076L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(collection30);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-2206022400001L) + "'", long36 == (-2206022400001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(timeSeries42);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.String str6 = year5.toString();
        java.lang.Number number7 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year5);
        timeSeries3.clear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str11 = spreadsheetDate10.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str14 = spreadsheetDate13.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean18 = spreadsheetDate13.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate10.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean25 = spreadsheetDate21.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate24);
        int int26 = spreadsheetDate24.toSerial();
        boolean boolean27 = spreadsheetDate10.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate24);
        java.util.Date date28 = spreadsheetDate10.toDate();
        boolean boolean29 = timeSeries3.equals((java.lang.Object) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addMonths(9, serialDate30);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 35 + "'", int26 == 35);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 2958465);
        java.lang.String str3 = month2.toString();
        long long4 = month2.getLastMillisecond();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.String str6 = year5.toString();
        long long7 = year5.getFirstMillisecond();
        java.lang.String str8 = year5.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year5.next();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long14 = timeSeries13.getMaximumItemAge();
        boolean boolean15 = year5.equals((java.lang.Object) timeSeries13);
        boolean boolean16 = month2.equals((java.lang.Object) boolean15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month2.previous();
        java.util.Calendar calendar18 = null;
        try {
            month2.peg(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January 2958465" + "'", str3.equals("January 2958465"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 93297973593599999L + "'", long4 == 93297973593599999L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries2.setNotify(false);
        java.lang.Comparable comparable5 = timeSeries2.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 1560190010308L);
        java.util.Calendar calendar11 = null;
        fixedMillisecond7.peg(calendar11);
        long long13 = fixedMillisecond7.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries16.setNotify(false);
        timeSeries16.removeAgedItems(true);
        int int21 = timeSeries16.getItemCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str24 = spreadsheetDate23.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean28 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        timeSeries16.setKey((java.lang.Comparable) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addDays(2, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean36 = spreadsheetDate32.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        int int37 = spreadsheetDate35.toSerial();
        boolean boolean38 = spreadsheetDate26.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        int int39 = fixedMillisecond7.compareTo((java.lang.Object) spreadsheetDate35);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, (org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate42);
        int int44 = spreadsheetDate42.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str47 = spreadsheetDate46.getDescription();
        int int48 = spreadsheetDate46.getDayOfWeek();
        int int49 = spreadsheetDate46.getYYYY();
        int int50 = spreadsheetDate42.compare((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate56 = spreadsheetDate52.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate55);
        int int57 = spreadsheetDate55.getMonth();
        boolean boolean58 = spreadsheetDate46.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate55);
        java.lang.String str59 = spreadsheetDate46.toString();
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(serialDate61);
        boolean boolean63 = spreadsheetDate35.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate46, serialDate61);
        serialDate61.setDescription("org.jfree.data.time.TimePeriodFormatException: ERROR : Relative To String");
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "hi!" + "'", comparable5.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2L + "'", long13 == 2L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 35 + "'", int37 == 35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 7 + "'", int44 == 7);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 7 + "'", int48 == 7);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1900 + "'", int49 == 1900);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2 + "'", int57 == 2);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "3-February-1900" + "'", str59.equals("3-February-1900"));
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long5 = timeSeries4.getMaximumItemAge();
        java.lang.String str6 = timeSeries4.getDescription();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long9 = timeSeries8.getMaximumItemAge();
        java.lang.String str10 = timeSeries8.getDescription();
        timeSeries8.setDomainDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
        boolean boolean14 = day2.equals((java.lang.Object) timeSeries4);
        long long15 = day2.getLastMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = day2.equals((java.lang.Object) day18);
        int int20 = day18.getMonth();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-2206022400001L) + "'", long15 == (-2206022400001L));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setNotify(false);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 1560190010308L);
        java.util.Date date10 = fixedMillisecond6.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date10);
        java.lang.Class<?> wildcardClass13 = date10.getClass();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "hi!" + "'", comparable4.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries2.setNotify(false);
        java.lang.Comparable comparable5 = timeSeries2.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 1560190010308L);
        java.util.Date date11 = fixedMillisecond7.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(3, year12);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries15.setNotify(false);
        java.lang.Comparable comparable18 = timeSeries15.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (double) 1560190010308L);
        java.util.Calendar calendar24 = null;
        fixedMillisecond20.peg(calendar24);
        long long26 = fixedMillisecond20.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries29.setNotify(false);
        timeSeries29.removeAgedItems(true);
        int int34 = timeSeries29.getItemCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str37 = spreadsheetDate36.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate39);
        boolean boolean41 = spreadsheetDate36.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate39);
        timeSeries29.setKey((java.lang.Comparable) spreadsheetDate39);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addDays(2, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean49 = spreadsheetDate45.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate48);
        int int50 = spreadsheetDate48.toSerial();
        boolean boolean51 = spreadsheetDate39.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate48);
        int int52 = fixedMillisecond20.compareTo((java.lang.Object) spreadsheetDate48);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate55);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate59 = spreadsheetDate55.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate58);
        int int60 = spreadsheetDate58.getMonth();
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.addDays(1, (org.jfree.data.time.SerialDate) spreadsheetDate58);
        serialDate61.setDescription("Value");
        boolean boolean64 = spreadsheetDate48.isBefore(serialDate61);
        int int65 = month13.compareTo((java.lang.Object) spreadsheetDate48);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate67);
        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean71 = spreadsheetDate67.isOnOrAfter(serialDate70);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate73 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str74 = spreadsheetDate73.getDescription();
        int int75 = spreadsheetDate73.getDayOfWeek();
        boolean boolean76 = spreadsheetDate67.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate73);
        boolean boolean77 = spreadsheetDate48.equals((java.lang.Object) spreadsheetDate67);
        int int78 = spreadsheetDate48.getMonth();
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "hi!" + "'", comparable5.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + "hi!" + "'", comparable18.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2L + "'", long26 == 2L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 35 + "'", int50 == 35);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2 + "'", int60 == 2);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNull(str74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 7 + "'", int75 == 7);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 2 + "'", int78 == 2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setNotify(false);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 1560190010308L);
        java.util.Calendar calendar10 = null;
        fixedMillisecond6.peg(calendar10);
        long long12 = fixedMillisecond6.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries15.setNotify(false);
        timeSeries15.removeAgedItems(true);
        int int20 = timeSeries15.getItemCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str23 = spreadsheetDate22.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean27 = spreadsheetDate22.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        timeSeries15.setKey((java.lang.Comparable) spreadsheetDate25);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addDays(2, (org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean35 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate34);
        int int36 = spreadsheetDate34.toSerial();
        boolean boolean37 = spreadsheetDate25.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate34);
        int int38 = fixedMillisecond6.compareTo((java.lang.Object) spreadsheetDate34);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate45 = spreadsheetDate41.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate44);
        int int46 = spreadsheetDate44.getMonth();
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addDays(1, (org.jfree.data.time.SerialDate) spreadsheetDate44);
        serialDate47.setDescription("Value");
        boolean boolean50 = spreadsheetDate34.isBefore(serialDate47);
        int int51 = spreadsheetDate34.getDayOfWeek();
        boolean boolean53 = spreadsheetDate34.equals((java.lang.Object) 1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate55);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate59 = spreadsheetDate55.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate58);
        int int60 = spreadsheetDate58.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str63 = spreadsheetDate62.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate65);
        boolean boolean67 = spreadsheetDate62.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate65);
        java.lang.String str68 = spreadsheetDate65.getDescription();
        int int69 = spreadsheetDate65.getDayOfMonth();
        boolean boolean70 = spreadsheetDate58.isOn((org.jfree.data.time.SerialDate) spreadsheetDate65);
        boolean boolean71 = spreadsheetDate34.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate65);
        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate34);
        int int73 = day72.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = day72.previous();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "hi!" + "'", comparable4.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 35 + "'", int36 == 35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 7 + "'", int51 == 7);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 35 + "'", int60 == 35);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNull(str68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 3 + "'", int69 == 3);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 3 + "'", int73 == 3);
        org.junit.Assert.assertNotNull(regularTimePeriod74);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemCount(10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.addChangeListener(seriesChangeListener5);
        java.lang.String str7 = timeSeries1.getDomainDescription();
        timeSeries1.fireSeriesChanged();
        java.util.Collection collection9 = timeSeries1.getTimePeriods();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str3 = spreadsheetDate2.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str6 = spreadsheetDate5.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate5.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean12 = month0.equals((java.lang.Object) spreadsheetDate5);
        int int13 = spreadsheetDate5.getYYYY();
        java.util.Date date14 = spreadsheetDate5.toDate();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int16 = spreadsheetDate5.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate17 = null;
        try {
            boolean boolean18 = spreadsheetDate5.isBefore(serialDate17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 7 + "'", int16 == 7);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 2958465);
        int int3 = month2.getMonth();
        long long4 = month2.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 93297973593599999L + "'", long4 == 93297973593599999L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) ' ', 520764324);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2-February-1900");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2-February-1900" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: 2-February-1900"));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test070");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
//        long long2 = timeSeries1.getMaximumItemAge();
//        java.lang.String str3 = timeSeries1.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
//        long long6 = timeSeries5.getMaximumItemAge();
//        java.lang.String str7 = timeSeries5.getDescription();
//        timeSeries5.setDomainDescription("2019");
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries5);
//        java.lang.String str11 = timeSeries5.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries5.createCopy((int) (short) 10, 35);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        long long16 = month15.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month15.previous();
//        int int18 = month15.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
//        timeSeries20.setDescription("ERROR : Relative To String");
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries24.fireSeriesChanged();
//        timeSeries24.setMaximumItemCount(10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries24.addChangeListener(seriesChangeListener28);
//        timeSeries24.setMaximumItemCount(10);
//        timeSeries24.setMaximumItemAge((long) (byte) 1);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries35.fireSeriesChanged();
//        timeSeries35.setMaximumItemCount(10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener39 = null;
//        timeSeries35.addChangeListener(seriesChangeListener39);
//        java.lang.String str41 = timeSeries35.getDomainDescription();
//        org.jfree.data.time.Year year43 = org.jfree.data.time.Year.parseYear("2019");
//        timeSeries35.delete((org.jfree.data.time.RegularTimePeriod) year43);
//        timeSeries24.delete((org.jfree.data.time.RegularTimePeriod) year43);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
//        long long47 = fixedMillisecond46.getFirstMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent48 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond46);
//        int int49 = timeSeries24.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries20.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
//        java.lang.Class class52 = timeSeries51.getTimePeriodClass();
//        int int53 = timeSeries51.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries55.fireSeriesChanged();
//        timeSeries55.setMaximumItemCount(10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener59 = null;
//        timeSeries55.addChangeListener(seriesChangeListener59);
//        timeSeries55.setMaximumItemCount(10);
//        timeSeries55.setMaximumItemAge((long) (byte) 1);
//        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries66.fireSeriesChanged();
//        timeSeries66.setMaximumItemCount(10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener70 = null;
//        timeSeries66.addChangeListener(seriesChangeListener70);
//        java.lang.String str72 = timeSeries66.getDomainDescription();
//        org.jfree.data.time.Year year74 = org.jfree.data.time.Year.parseYear("2019");
//        timeSeries66.delete((org.jfree.data.time.RegularTimePeriod) year74);
//        timeSeries55.delete((org.jfree.data.time.RegularTimePeriod) year74);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = year74.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = year74.previous();
//        int int80 = year74.compareTo((java.lang.Object) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = year74.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = year74.next();
//        try {
//            timeSeries51.add(regularTimePeriod82, (double) 10.0f);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
//        org.junit.Assert.assertNull(str3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertNull(str11);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 24234L + "'", long16 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Time" + "'", str41.equals("Time"));
//        org.junit.Assert.assertNotNull(year43);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560190098233L + "'", long47 == 1560190098233L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
//        org.junit.Assert.assertNull(timeSeriesDataItem50);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertNotNull(class52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "Time" + "'", str72.equals("Time"));
//        org.junit.Assert.assertNotNull(year74);
//        org.junit.Assert.assertNotNull(regularTimePeriod77);
//        org.junit.Assert.assertNotNull(regularTimePeriod78);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod81);
//        org.junit.Assert.assertNotNull(regularTimePeriod82);
//    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test071");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
//        long long2 = timeSeries1.getMaximumItemAge();
//        java.lang.String str3 = timeSeries1.getDescription();
//        java.lang.Class class4 = timeSeries1.getTimePeriodClass();
//        java.lang.Class<?> wildcardClass5 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        long long7 = fixedMillisecond6.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries9.fireSeriesChanged();
//        timeSeries9.setMaximumItemCount(10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries9.addChangeListener(seriesChangeListener13);
//        timeSeries9.setMaximumItemCount(10);
//        timeSeries9.setMaximumItemAge((long) (byte) 1);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries20.fireSeriesChanged();
//        timeSeries20.setMaximumItemCount(10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
//        timeSeries20.addChangeListener(seriesChangeListener24);
//        java.lang.String str26 = timeSeries20.getDomainDescription();
//        org.jfree.data.time.Year year28 = org.jfree.data.time.Year.parseYear("2019");
//        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) year28);
//        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) year28);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (org.jfree.data.time.RegularTimePeriod) year28);
//        int int32 = year28.getYear();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
//        org.junit.Assert.assertNull(str3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190098252L + "'", long7 == 1560190098252L);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
//        org.junit.Assert.assertNotNull(year28);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 1L);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries5.setNotify(false);
        timeSeries5.removeAgedItems(true);
        timeSeries5.removeAgedItems(true);
        java.util.Collection collection12 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        int int13 = timeSeries5.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long2 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.lang.String str4 = year3.toString();
        java.lang.Number number5 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year3);
        timeSeries1.clear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str9 = spreadsheetDate8.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str12 = spreadsheetDate11.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = spreadsheetDate11.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean23 = spreadsheetDate19.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        int int24 = spreadsheetDate22.toSerial();
        boolean boolean25 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        java.util.Date date26 = spreadsheetDate8.toDate();
        boolean boolean27 = timeSeries1.equals((java.lang.Object) spreadsheetDate8);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean35 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) spreadsheetDate34);
        org.jfree.data.time.SerialDate serialDate37 = serialDate29.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean38 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        int int39 = spreadsheetDate34.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 35 + "'", int24 == 35);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 3 + "'", int39 == 3);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long2 = timeSeries1.getMaximumItemAge();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long6 = timeSeries5.getMaximumItemAge();
        java.lang.String str7 = timeSeries5.getDescription();
        timeSeries5.setDomainDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries5);
        int int11 = timeSeries5.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long14 = timeSeries13.getMaximumItemAge();
        java.lang.String str15 = timeSeries13.getDescription();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long18 = timeSeries17.getMaximumItemAge();
        java.lang.String str19 = timeSeries17.getDescription();
        timeSeries17.setDomainDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries13.addAndOrUpdate(timeSeries17);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries17.addChangeListener(seriesChangeListener23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond26.previous();
        java.lang.String str28 = fixedMillisecond26.toString();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long31 = timeSeries30.getMaximumItemAge();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.lang.String str33 = year32.toString();
        java.lang.Number number34 = timeSeries30.getValue((org.jfree.data.time.RegularTimePeriod) year32);
        int int35 = fixedMillisecond26.compareTo((java.lang.Object) number34);
        boolean boolean36 = timeSeries17.equals((java.lang.Object) fixedMillisecond26);
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries5.addAndOrUpdate(timeSeries17);
        boolean boolean38 = timeSeries5.getNotify();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str28.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2019" + "'", str33.equals("2019"));
        org.junit.Assert.assertNull(number34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long2 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.lang.String str4 = year3.toString();
        java.lang.Number number5 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year3);
        java.util.Date date6 = year3.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries1.setMaximumItemAge((long) (byte) 1);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.lang.String str5 = year4.toString();
        long long6 = year4.getFirstMillisecond();
        java.lang.String str7 = year4.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (java.lang.Number) 0);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries11.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries15.setNotify(false);
        java.lang.Comparable comparable18 = timeSeries15.getKey();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 1.0d);
        int int22 = year19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (-1L));
        boolean boolean25 = timeSeriesDataItem9.equals((java.lang.Object) timeSeriesDataItem24);
        java.lang.Object obj26 = timeSeriesDataItem9.clone();
        java.lang.Number number27 = null;
        timeSeriesDataItem9.setValue(number27);
        try {
            timeSeries1.add(timeSeriesDataItem9, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + "hi!" + "'", comparable18.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setNotify(false);
        timeSeries1.removeAgedItems(true);
        long long6 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long9 = timeSeries8.getMaximumItemAge();
        java.lang.String str10 = timeSeries8.getDescription();
        timeSeries8.setDomainDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries14.fireSeriesChanged();
        timeSeries14.setMaximumItemCount(10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries14.addChangeListener(seriesChangeListener18);
        timeSeries14.setMaximumItemCount(10);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        java.lang.String str23 = year22.toString();
        long long24 = year22.getFirstMillisecond();
        java.lang.String str25 = year22.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year22, (double) 1);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries8.addAndOrUpdate(timeSeries14);
        timeSeries28.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries28.createCopy((int) '#', (int) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries1.addAndOrUpdate(timeSeries28);
        java.util.List list34 = timeSeries1.getItems();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        long long36 = month35.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month35.previous();
        int int38 = month35.getMonth();
        org.jfree.data.time.Year year39 = month35.getYear();
        java.lang.Object obj40 = null;
        int int41 = month35.compareTo(obj40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month35.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = month35.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month35, (double) 1560190036669L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 24234L + "'", long36 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertNotNull(year39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long2 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.lang.String str4 = year3.toString();
        java.lang.Number number5 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year3);
        timeSeries1.clear();
        java.lang.String str7 = timeSeries1.getDescription();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        long long9 = month8.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.previous();
        int int11 = month8.getMonth();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.lang.Class<?> wildcardClass13 = year12.getClass();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month8, (org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month8.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month8.previous();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries18.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries18.createCopy(10, 12);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long25 = timeSeries24.getMaximumItemAge();
        java.lang.String str26 = timeSeries24.getDescription();
        java.lang.Class class27 = timeSeries24.getTimePeriodClass();
        java.lang.Class<?> wildcardClass28 = timeSeries24.getClass();
        boolean boolean29 = timeSeries18.equals((java.lang.Object) wildcardClass28);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, (java.lang.Class) wildcardClass28);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 24234L + "'", long9 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        long long3 = month0.getLastMillisecond();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: hi!");
        java.lang.Class<?> wildcardClass6 = seriesException5.getClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries8.setNotify(false);
        java.lang.Comparable comparable11 = timeSeries8.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) 1560190010308L);
        java.util.Date date17 = fixedMillisecond13.getStart();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date17, timeZone18);
        int int20 = month0.compareTo((java.lang.Object) date17);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        long long22 = month21.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
        int int24 = month21.getMonth();
        org.jfree.data.time.Year year25 = month21.getYear();
        java.lang.Object obj26 = null;
        int int27 = month21.compareTo(obj26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month21.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month21.next();
        int int30 = month21.getYearValue();
        int int31 = month0.compareTo((java.lang.Object) month21);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + "hi!" + "'", comparable11.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertNotNull(year25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long2 = timeSeries1.getMaximumItemAge();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long6 = timeSeries5.getMaximumItemAge();
        java.lang.String str7 = timeSeries5.getDescription();
        timeSeries5.setDomainDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries5.addChangeListener(seriesChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.previous();
        java.lang.String str16 = fixedMillisecond14.toString();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long19 = timeSeries18.getMaximumItemAge();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        java.lang.Number number22 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        int int23 = fixedMillisecond14.compareTo((java.lang.Object) number22);
        boolean boolean24 = timeSeries5.equals((java.lang.Object) fixedMillisecond14);
        try {
            timeSeries5.delete((int) (short) 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str16.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(9);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str3 = spreadsheetDate2.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean7 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.lang.String str8 = spreadsheetDate5.getDescription();
        int int9 = spreadsheetDate5.getDayOfMonth();
        java.lang.Object obj10 = null;
        boolean boolean11 = spreadsheetDate5.equals(obj10);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate5.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate20 = spreadsheetDate16.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate19);
        int int21 = spreadsheetDate19.getMonth();
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(1, (org.jfree.data.time.SerialDate) spreadsheetDate19);
        int int23 = spreadsheetDate5.compare(serialDate22);
        try {
            org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-457), serialDate22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.Year year2 = month0.getYear();
        long long3 = year2.getFirstMillisecond();
        int int4 = year2.getYear();
        java.lang.String str5 = year2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        timeSeries7.clear();
        java.lang.Object obj9 = timeSeries7.clone();
        boolean boolean10 = year2.equals((java.lang.Object) timeSeries7);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setNotify(false);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 1560190010308L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond6.getMiddleMillisecond(calendar10);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "hi!" + "'", comparable4.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2L + "'", long11 == 2L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        int int3 = month0.getMonth();
        org.jfree.data.time.Year year4 = month0.getYear();
        long long5 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries7.setNotify(false);
        timeSeries7.removeAgedItems(true);
        int int12 = timeSeries7.getItemCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str15 = spreadsheetDate14.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate14.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        timeSeries7.setKey((java.lang.Comparable) spreadsheetDate17);
        boolean boolean21 = month0.equals((java.lang.Object) timeSeries7);
        long long22 = month0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long2 = timeSeries1.getMaximumItemAge();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long6 = timeSeries5.getMaximumItemAge();
        java.lang.String str7 = timeSeries5.getDescription();
        timeSeries5.setDomainDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries5.addChangeListener(seriesChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.previous();
        java.lang.String str16 = fixedMillisecond14.toString();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long19 = timeSeries18.getMaximumItemAge();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        java.lang.Number number22 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        int int23 = fixedMillisecond14.compareTo((java.lang.Object) number22);
        boolean boolean24 = timeSeries5.equals((java.lang.Object) fixedMillisecond14);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries5.addChangeListener(seriesChangeListener25);
        boolean boolean27 = timeSeries5.isEmpty();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str16.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long2 = timeSeries1.getMaximumItemAge();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long6 = timeSeries5.getMaximumItemAge();
        java.lang.String str7 = timeSeries5.getDescription();
        timeSeries5.setDomainDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries5);
        java.lang.String str11 = timeSeries5.getDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries5.createCopy((int) (short) 10, 35);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries16.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries16.createCopy((int) (short) 100, 2019);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate22);
        long long24 = day23.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day23.next();
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) day23, 0.0d, true);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        long long30 = month29.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.previous();
        long long32 = month29.getLastMillisecond();
        java.lang.Object obj33 = null;
        int int34 = month29.compareTo(obj33);
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day23, (org.jfree.data.time.RegularTimePeriod) month29);
        java.util.Calendar calendar36 = null;
        try {
            long long37 = month29.getLastMillisecond(calendar36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-2206022400001L) + "'", long24 == (-2206022400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 24234L + "'", long30 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1561964399999L + "'", long32 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(timeSeries35);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (-2206108800000L));
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        long long5 = month4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.previous();
        int int7 = month4.getMonth();
        org.jfree.data.time.Year year8 = month4.getYear();
        boolean boolean9 = timeSeriesDataItem3.equals((java.lang.Object) month4);
        java.lang.Object obj10 = timeSeriesDataItem3.clone();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 24234L + "'", long5 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long2 = timeSeries1.getMaximumItemAge();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long6 = timeSeries5.getMaximumItemAge();
        java.lang.String str7 = timeSeries5.getDescription();
        timeSeries5.setDomainDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries5.addChangeListener(seriesChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.previous();
        java.lang.String str16 = fixedMillisecond14.toString();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long19 = timeSeries18.getMaximumItemAge();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        java.lang.Number number22 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        int int23 = fixedMillisecond14.compareTo((java.lang.Object) number22);
        boolean boolean24 = timeSeries5.equals((java.lang.Object) fixedMillisecond14);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries26.setNotify(false);
        java.lang.Comparable comparable29 = timeSeries26.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries26.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (double) 1560190009632L);
        boolean boolean35 = fixedMillisecond14.equals((java.lang.Object) timeSeriesDataItem34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond14.previous();
        java.util.Date date37 = fixedMillisecond14.getTime();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str16.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + "hi!" + "'", comparable29.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries5.setNotify(false);
        java.lang.Comparable comparable8 = timeSeries5.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 1.0d);
        int int12 = year9.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (-1L));
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long17 = timeSeries16.getMaximumItemAge();
        java.lang.String str18 = timeSeries16.getDescription();
        java.lang.Class class19 = timeSeries16.getTimePeriodClass();
        java.lang.Class<?> wildcardClass20 = timeSeries16.getClass();
        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1L), (java.lang.Class) wildcardClass20);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long25 = timeSeries24.getMaximumItemAge();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        java.lang.String str27 = year26.toString();
        java.lang.Number number28 = timeSeries24.getValue((org.jfree.data.time.RegularTimePeriod) year26);
        java.util.Date date29 = year26.getEnd();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
        java.lang.Number number31 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day30, number31);
        boolean boolean33 = timeSeries22.isEmpty();
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + "hi!" + "'", comparable8.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2019" + "'", str27.equals("2019"));
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        java.lang.String str2 = year1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1900" + "'", str2.equals("1900"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((int) (short) 100, 2019);
        boolean boolean6 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries8.fireSeriesChanged();
        timeSeries8.setMaximumItemCount(10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries8.addChangeListener(seriesChangeListener12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        long long15 = month14.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month14.previous();
        long long17 = month14.getLastMillisecond();
        java.lang.Object obj18 = null;
        int int19 = month14.compareTo(obj18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) 8);
        java.lang.Object obj22 = timeSeries8.clone();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.addAndOrUpdate(timeSeries8);
        java.lang.String str24 = timeSeries1.getRangeDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate30 = spreadsheetDate26.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate29);
        int int31 = spreadsheetDate29.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str34 = spreadsheetDate33.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate36);
        boolean boolean38 = spreadsheetDate33.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate36);
        java.lang.String str39 = spreadsheetDate36.getDescription();
        int int40 = spreadsheetDate36.getDayOfMonth();
        boolean boolean41 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day42.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day42.next();
        java.lang.Number number45 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day42, number45);
        timeSeries1.setDescription("2019");
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 24234L + "'", long15 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Value" + "'", str24.equals("Value"));
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 35 + "'", int31 == 35);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 3 + "'", int40 == 3);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(timeSeriesDataItem46);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 2958465);
        long long3 = month2.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35501581L + "'", long3 == 35501581L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean7 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str10 = spreadsheetDate9.getDescription();
        boolean boolean12 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, (org.jfree.data.time.SerialDate) spreadsheetDate9, 11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str15 = spreadsheetDate14.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate14.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str20 = spreadsheetDate17.getDescription();
        org.jfree.data.time.SerialDate serialDate21 = spreadsheetDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean30 = spreadsheetDate26.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str33 = spreadsheetDate32.getDescription();
        boolean boolean35 = spreadsheetDate24.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate26, (org.jfree.data.time.SerialDate) spreadsheetDate32, 11);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate32);
        boolean boolean37 = spreadsheetDate17.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean5 = spreadsheetDate1.isOnOrAfter(serialDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str8 = spreadsheetDate7.getDescription();
        int int9 = spreadsheetDate7.getDayOfWeek();
        boolean boolean10 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str13 = spreadsheetDate12.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str16 = spreadsheetDate15.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean20 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate21 = spreadsheetDate12.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean27 = spreadsheetDate23.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        int int28 = spreadsheetDate26.toSerial();
        boolean boolean29 = spreadsheetDate12.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean30 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate26);
        java.lang.String str31 = spreadsheetDate26.getDescription();
        java.lang.String str32 = spreadsheetDate26.getDescription();
        org.jfree.data.time.SerialDate serialDate34 = spreadsheetDate26.getFollowingDayOfWeek(2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 35 + "'", int28 == 35);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(serialDate34);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10, 8, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test097");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        boolean boolean7 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        java.lang.String str10 = spreadsheetDate9.getDescription();
//        boolean boolean12 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, (org.jfree.data.time.SerialDate) spreadsheetDate9, 11);
//        org.jfree.data.time.SerialDate serialDate14 = spreadsheetDate3.getNearestDayOfWeek((int) (byte) 1);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
//        long long17 = timeSeries16.getMaximumItemAge();
//        java.lang.String str18 = timeSeries16.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
//        long long21 = timeSeries20.getMaximumItemAge();
//        java.lang.String str22 = timeSeries20.getDescription();
//        timeSeries20.setDomainDescription("2019");
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries16.addAndOrUpdate(timeSeries20);
//        java.lang.String str26 = timeSeries20.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries20.createCopy((int) (short) 10, 35);
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
//        long long31 = month30.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month30.previous();
//        int int33 = month30.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
//        timeSeries35.setDescription("ERROR : Relative To String");
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries39.fireSeriesChanged();
//        timeSeries39.setMaximumItemCount(10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener43 = null;
//        timeSeries39.addChangeListener(seriesChangeListener43);
//        timeSeries39.setMaximumItemCount(10);
//        timeSeries39.setMaximumItemAge((long) (byte) 1);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries50.fireSeriesChanged();
//        timeSeries50.setMaximumItemCount(10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener54 = null;
//        timeSeries50.addChangeListener(seriesChangeListener54);
//        java.lang.String str56 = timeSeries50.getDomainDescription();
//        org.jfree.data.time.Year year58 = org.jfree.data.time.Year.parseYear("2019");
//        timeSeries50.delete((org.jfree.data.time.RegularTimePeriod) year58);
//        timeSeries39.delete((org.jfree.data.time.RegularTimePeriod) year58);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond();
//        long long62 = fixedMillisecond61.getFirstMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent63 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond61);
//        int int64 = timeSeries39.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond61);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries35.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond61);
//        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) month30, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond61);
//        boolean boolean67 = spreadsheetDate3.equals((java.lang.Object) month30);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = month30.previous();
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
//        org.junit.Assert.assertNull(str18);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
//        org.junit.Assert.assertNull(str22);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertNull(str26);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 24234L + "'", long31 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Time" + "'", str56.equals("Time"));
//        org.junit.Assert.assertNotNull(year58);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560190100569L + "'", long62 == 1560190100569L);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
//        org.junit.Assert.assertNull(timeSeriesDataItem65);
//        org.junit.Assert.assertNotNull(timeSeries66);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.lang.String str3 = year2.toString();
        long long4 = year2.getFirstMillisecond();
        java.lang.String str5 = year2.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (java.lang.Number) 0);
        int int8 = fixedMillisecond1.compareTo((java.lang.Object) year2);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long11 = timeSeries10.getMaximumItemAge();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.lang.String str13 = year12.toString();
        java.lang.Number number14 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) year12);
        java.util.Date date15 = year12.getEnd();
        int int16 = year2.compareTo((java.lang.Object) date15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
        long long21 = fixedMillisecond19.getSerialIndex();
        java.util.Date date22 = fixedMillisecond19.getTime();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str25 = spreadsheetDate24.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str28 = spreadsheetDate27.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean32 = spreadsheetDate27.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SerialDate serialDate33 = spreadsheetDate24.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean39 = spreadsheetDate35.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        int int40 = spreadsheetDate38.toSerial();
        boolean boolean41 = spreadsheetDate24.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        java.util.Date date42 = spreadsheetDate24.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str45 = spreadsheetDate44.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate47);
        boolean boolean49 = spreadsheetDate44.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate47);
        java.lang.String str50 = spreadsheetDate47.getDescription();
        java.util.Date date51 = spreadsheetDate47.toDate();
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date51, timeZone52);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date42, timeZone52);
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month(date22, timeZone52);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date15, timeZone52);
        java.util.TimeZone timeZone57 = null;
        try {
            org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date15, timeZone57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-452L) + "'", long21 == (-452L));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 35 + "'", int40 == 35);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone52);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long2 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.lang.String str4 = year3.toString();
        java.lang.Number number5 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year3);
        java.util.Date date6 = year3.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        int int8 = day7.getDayOfMonth();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day7.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate4.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str9 = spreadsheetDate8.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean13 = spreadsheetDate8.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        java.lang.String str14 = spreadsheetDate11.getDescription();
        int int15 = spreadsheetDate11.getDayOfMonth();
        boolean boolean16 = spreadsheetDate4.isOn((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.previous();
        long long19 = day17.getFirstMillisecond();
        int int20 = day17.getDayOfMonth();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-2206108800000L) + "'", long19 == (-2206108800000L));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str5 = spreadsheetDate4.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate7);
        boolean boolean9 = spreadsheetDate4.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean16 = spreadsheetDate12.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        int int17 = spreadsheetDate15.toSerial();
        boolean boolean18 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        int int20 = spreadsheetDate15.getYYYY();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 35 + "'", int17 == 35);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1900 + "'", int20 == 1900);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test102");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
//        long long2 = timeSeries1.getMaximumItemAge();
//        java.lang.String str3 = timeSeries1.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
//        long long6 = timeSeries5.getMaximumItemAge();
//        java.lang.String str7 = timeSeries5.getDescription();
//        timeSeries5.setDomainDescription("2019");
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries5);
//        java.lang.String str11 = timeSeries5.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries5.createCopy((int) (short) 10, 35);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries16.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries16.createCopy((int) (short) 100, 2019);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        long long24 = day23.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day23.next();
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) day23, 0.0d, true);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        long long30 = month29.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.previous();
//        long long32 = month29.getLastMillisecond();
//        java.lang.Object obj33 = null;
//        int int34 = month29.compareTo(obj33);
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day23, (org.jfree.data.time.RegularTimePeriod) month29);
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries37.fireSeriesChanged();
//        timeSeries37.setMaximumItemCount(10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
//        timeSeries37.addChangeListener(seriesChangeListener41);
//        timeSeries37.setMaximumItemCount(10);
//        timeSeries37.setMaximumItemAge((long) (byte) 1);
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries48.fireSeriesChanged();
//        timeSeries48.setMaximumItemCount(10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener52 = null;
//        timeSeries48.addChangeListener(seriesChangeListener52);
//        java.lang.String str54 = timeSeries48.getDomainDescription();
//        org.jfree.data.time.Year year56 = org.jfree.data.time.Year.parseYear("2019");
//        timeSeries48.delete((org.jfree.data.time.RegularTimePeriod) year56);
//        timeSeries37.delete((org.jfree.data.time.RegularTimePeriod) year56);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond();
//        long long60 = fixedMillisecond59.getFirstMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent61 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond59);
//        int int62 = timeSeries37.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59);
//        try {
//            timeSeries35.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59, (double) 1560190063047L, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
//        org.junit.Assert.assertNull(str3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertNull(str11);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-2206022400001L) + "'", long24 == (-2206022400001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 24234L + "'", long30 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1561964399999L + "'", long32 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Time" + "'", str54.equals("Time"));
//        org.junit.Assert.assertNotNull(year56);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560190100915L + "'", long60 == 1560190100915L);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean6 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        java.lang.String str7 = spreadsheetDate4.getDescription();
        int int8 = spreadsheetDate4.getDayOfMonth();
        java.lang.Object obj9 = null;
        boolean boolean10 = spreadsheetDate4.equals(obj9);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate4.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean20 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str23 = spreadsheetDate22.getDescription();
        boolean boolean25 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate16, (org.jfree.data.time.SerialDate) spreadsheetDate22, 11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str28 = spreadsheetDate27.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean32 = spreadsheetDate27.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        java.lang.String str33 = spreadsheetDate30.getDescription();
        org.jfree.data.time.SerialDate serialDate34 = spreadsheetDate22.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries36.setNotify(false);
        timeSeries36.removeAgedItems(true);
        int int41 = timeSeries36.getItemCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str44 = spreadsheetDate43.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean48 = spreadsheetDate43.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate46);
        timeSeries36.setKey((java.lang.Comparable) spreadsheetDate46);
        int int50 = spreadsheetDate46.getDayOfMonth();
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries53.setNotify(false);
        timeSeries53.removeAgedItems(true);
        int int58 = timeSeries53.getItemCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str61 = spreadsheetDate60.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate63);
        boolean boolean65 = spreadsheetDate60.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate63);
        timeSeries53.setKey((java.lang.Comparable) spreadsheetDate63);
        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.addDays(2, (org.jfree.data.time.SerialDate) spreadsheetDate63);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate69);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate72 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean73 = spreadsheetDate69.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate72);
        int int74 = spreadsheetDate72.toSerial();
        boolean boolean75 = spreadsheetDate63.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate72);
        boolean boolean76 = spreadsheetDate22.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate46, (org.jfree.data.time.SerialDate) spreadsheetDate63);
        int int77 = spreadsheetDate4.compare((org.jfree.data.time.SerialDate) spreadsheetDate63);
        org.jfree.data.time.SerialDate serialDate78 = null;
        try {
            boolean boolean79 = spreadsheetDate4.isOnOrBefore(serialDate78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 3 + "'", int50 == 3);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 35 + "'", int74 == 35);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries1.setMaximumItemAge((long) (byte) 1);
        java.lang.Class class4 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        int int7 = month5.getMonth();
        int int8 = month5.getYearValue();
        long long9 = month5.getFirstMillisecond();
        int int10 = month5.getMonth();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month5);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559372400000L + "'", long9 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        java.lang.Class<?> wildcardClass2 = timeSeries1.getClass();
        int int3 = timeSeries1.getItemCount();
        timeSeries1.removeAgedItems(true);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int3 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str6 = spreadsheetDate5.getDescription();
        int int7 = spreadsheetDate5.getDayOfWeek();
        int int8 = spreadsheetDate5.getYYYY();
        int int9 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries13.setNotify(false);
        timeSeries13.removeAgedItems(true);
        int int18 = timeSeries13.getItemCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str21 = spreadsheetDate20.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate23);
        boolean boolean25 = spreadsheetDate20.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate23);
        timeSeries13.setKey((java.lang.Comparable) spreadsheetDate23);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addDays(2, (org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, (org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean34 = spreadsheetDate30.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int35 = spreadsheetDate33.toSerial();
        boolean boolean36 = spreadsheetDate5.isInRange(serialDate28, (org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int37 = spreadsheetDate5.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 7 + "'", int7 == 7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1900 + "'", int8 == 1900);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 35 + "'", int35 == 35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 3 + "'", int37 == 3);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setNotify(false);
        timeSeries1.removeAgedItems(true);
        timeSeries1.removeAgedItems(true);
        timeSeries1.setRangeDescription("ERROR : Relative To String");
        timeSeries1.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ERROR : Relative To String");
        java.lang.Object obj12 = timeSeries1.clone();
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-435) + "'", int1 == (-435));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate4.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str9 = spreadsheetDate8.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean13 = spreadsheetDate8.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        java.lang.String str14 = spreadsheetDate11.getDescription();
        int int15 = spreadsheetDate11.getDayOfMonth();
        boolean boolean16 = spreadsheetDate4.isOn((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day17.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) 1560190015457L);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long24 = timeSeries23.getMaximumItemAge();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        java.lang.String str26 = year25.toString();
        java.lang.Number number27 = timeSeries23.getValue((org.jfree.data.time.RegularTimePeriod) year25);
        java.util.Date date28 = year25.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date28);
        boolean boolean31 = timeSeriesDataItem21.equals((java.lang.Object) day30);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2019" + "'", str26.equals("2019"));
        org.junit.Assert.assertNull(number27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-452L) + "'", long3 == (-452L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-452L) + "'", long5 == (-452L));
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test111");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries2.fireSeriesChanged();
//        timeSeries2.setMaximumItemCount(10);
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) 10);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        java.lang.String str8 = year7.toString();
//        boolean boolean9 = fixedMillisecond0.equals((java.lang.Object) year7);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (double) (short) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year7.previous();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries14.fireSeriesChanged();
//        timeSeries14.setMaximumItemCount(10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries14.addChangeListener(seriesChangeListener18);
//        timeSeries14.setMaximumItemCount(10);
//        timeSeries14.setMaximumItemAge((long) (byte) 1);
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries25.fireSeriesChanged();
//        timeSeries25.setMaximumItemCount(10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
//        timeSeries25.addChangeListener(seriesChangeListener29);
//        java.lang.String str31 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.Year year33 = org.jfree.data.time.Year.parseYear("2019");
//        timeSeries25.delete((org.jfree.data.time.RegularTimePeriod) year33);
//        timeSeries14.delete((org.jfree.data.time.RegularTimePeriod) year33);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        long long37 = fixedMillisecond36.getFirstMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent38 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond36);
//        int int39 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36);
//        int int40 = year7.compareTo((java.lang.Object) int39);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int40);
//        timeSeries41.removeAgedItems(true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Time" + "'", str31.equals("Time"));
//        org.junit.Assert.assertNotNull(year33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560190101212L + "'", long37 == 1560190101212L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long2 = timeSeries1.getMaximumItemAge();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long6 = timeSeries5.getMaximumItemAge();
        java.lang.String str7 = timeSeries5.getDescription();
        timeSeries5.setDomainDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries5);
        timeSeries1.setMaximumItemCount((int) (short) 100);
        boolean boolean13 = timeSeries1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries1.addChangeListener(seriesChangeListener14);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean8 = spreadsheetDate4.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str11 = spreadsheetDate10.getDescription();
        boolean boolean13 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate4, (org.jfree.data.time.SerialDate) spreadsheetDate10, 11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str16 = spreadsheetDate15.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str19 = spreadsheetDate18.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean23 = spreadsheetDate18.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate24 = spreadsheetDate15.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean30 = spreadsheetDate26.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        int int31 = spreadsheetDate29.toSerial();
        boolean boolean32 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate29);
        boolean boolean34 = spreadsheetDate4.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        try {
            org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(9999, (org.jfree.data.time.SerialDate) spreadsheetDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 35 + "'", int31 == 35);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int8 = spreadsheetDate6.getMonth();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays(1, (org.jfree.data.time.SerialDate) spreadsheetDate6);
        try {
            org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-451), (org.jfree.data.time.SerialDate) spreadsheetDate6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries1.setMaximumItemAge((long) (byte) 1);
        timeSeries1.setNotify(true);
        timeSeries1.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener8);
        try {
            timeSeries1.delete((-435), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -435");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long5 = timeSeries4.getMaximumItemAge();
        java.lang.String str6 = timeSeries4.getDescription();
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        java.util.Date date8 = null;
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date8, timeZone9);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560190014451L, "Nearest", "hi!", class7);
        timeSeries11.setMaximumItemCount(12);
        java.util.Collection collection14 = timeSeries11.getTimePeriods();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(collection14);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries1.fireSeriesChanged();
        java.lang.Class<?> wildcardClass3 = timeSeries1.getClass();
        java.lang.String str4 = timeSeries1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean10 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        timeSeries1.setKey((java.lang.Comparable) spreadsheetDate9);
        int int12 = spreadsheetDate9.toSerial();
        int int13 = spreadsheetDate9.toSerial();
        java.lang.String str14 = spreadsheetDate9.getDescription();
        java.util.Date date15 = spreadsheetDate9.toDate();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date15);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 35 + "'", int12 == 35);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 35 + "'", int13 == 35);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(serialDate16);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.lang.String str3 = year2.toString();
        long long4 = year2.getFirstMillisecond();
        java.lang.String str5 = year2.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (java.lang.Number) 0);
        int int8 = fixedMillisecond1.compareTo((java.lang.Object) year2);
        java.util.Date date9 = fixedMillisecond1.getTime();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long12 = timeSeries11.getMaximumItemAge();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        java.lang.String str14 = year13.toString();
        java.lang.Number number15 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) year13);
        java.util.Date date16 = year13.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries19.fireSeriesChanged();
        timeSeries19.setMaximumItemCount(10);
        boolean boolean23 = fixedMillisecond17.equals((java.lang.Object) 10);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.lang.String str25 = year24.toString();
        boolean boolean26 = fixedMillisecond17.equals((java.lang.Object) year24);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries30.fireSeriesChanged();
        timeSeries30.setMaximumItemCount(10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener34 = null;
        timeSeries30.addChangeListener(seriesChangeListener34);
        java.lang.String str36 = timeSeries30.getDomainDescription();
        org.jfree.data.time.Year year38 = org.jfree.data.time.Year.parseYear("2019");
        timeSeries30.delete((org.jfree.data.time.RegularTimePeriod) year38);
        java.lang.Class<?> wildcardClass40 = year38.getClass();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year24, "", "2019", (java.lang.Class) wildcardClass40);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean49 = spreadsheetDate45.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str52 = spreadsheetDate51.getDescription();
        boolean boolean54 = spreadsheetDate43.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate45, (org.jfree.data.time.SerialDate) spreadsheetDate51, 11);
        java.util.Date date55 = spreadsheetDate45.toDate();
        java.util.TimeZone timeZone56 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date55, timeZone56);
        org.jfree.data.general.SeriesException seriesException59 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: hi!");
        java.lang.Class<?> wildcardClass60 = seriesException59.getClass();
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries62.setNotify(false);
        java.lang.Comparable comparable65 = timeSeries62.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries62.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond67);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond67, (double) 1560190010308L);
        java.util.Date date71 = fixedMillisecond67.getStart();
        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass60, date71, timeZone72);
        org.jfree.data.time.Month month74 = new org.jfree.data.time.Month(date55, timeZone72);
        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day(date16, timeZone72);
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year(date9, timeZone72);
        org.jfree.data.time.FixedMillisecond fixedMillisecond77 = new org.jfree.data.time.FixedMillisecond(date9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Time" + "'", str36.equals("Time"));
        org.junit.Assert.assertNotNull(year38);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertTrue("'" + comparable65 + "' != '" + "hi!" + "'", comparable65.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem68);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(timeZone72);
        org.junit.Assert.assertNull(regularTimePeriod73);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str5 = spreadsheetDate4.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate7);
        boolean boolean9 = spreadsheetDate4.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean16 = spreadsheetDate12.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        int int17 = spreadsheetDate15.toSerial();
        boolean boolean18 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        int int20 = day19.getMonth();
        long long21 = day19.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
        java.lang.Object obj23 = null;
        boolean boolean24 = day19.equals(obj23);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 35 + "'", int17 == 35);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 35L + "'", long21 == 35L);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries2.setNotify(false);
        java.lang.Comparable comparable5 = timeSeries2.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 1560190010308L);
        java.util.Date date11 = fixedMillisecond7.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(3, year12);
        java.lang.Object obj14 = null;
        int int15 = year12.compareTo(obj14);
        java.lang.String str16 = year12.toString();
        java.lang.String str17 = year12.toString();
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "hi!" + "'", comparable5.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969" + "'", str16.equals("1969"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1969" + "'", str17.equals("1969"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str4 = spreadsheetDate3.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str7 = spreadsheetDate6.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate6.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate6);
        boolean boolean13 = month1.equals((java.lang.Object) spreadsheetDate6);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries15.setNotify(false);
        timeSeries15.removeAgedItems(true);
        int int20 = timeSeries15.getItemCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str23 = spreadsheetDate22.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean27 = spreadsheetDate22.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        timeSeries15.setKey((java.lang.Comparable) spreadsheetDate25);
        boolean boolean29 = spreadsheetDate6.isOn((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str32 = spreadsheetDate31.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean36 = spreadsheetDate31.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate34);
        java.lang.String str37 = spreadsheetDate34.getDescription();
        int int38 = spreadsheetDate34.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate40 = spreadsheetDate34.getPreviousDayOfWeek(5);
        int int41 = spreadsheetDate25.compareTo((java.lang.Object) spreadsheetDate34);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str45 = spreadsheetDate44.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str48 = spreadsheetDate47.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate50);
        boolean boolean52 = spreadsheetDate47.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.jfree.data.time.SerialDate serialDate53 = spreadsheetDate44.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate47);
        boolean boolean54 = month42.equals((java.lang.Object) spreadsheetDate47);
        int int55 = spreadsheetDate47.getYYYY();
        org.jfree.data.time.SerialDate serialDate56 = spreadsheetDate25.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate47);
        int int57 = spreadsheetDate47.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.addMonths(10, (org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = day59.next();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 3 + "'", int38 == 3);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1900 + "'", int55 == 1900);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 7 + "'", int57 == 7);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Time");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getFirstMillisecond();
        java.lang.String str3 = year0.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long9 = timeSeries8.getMaximumItemAge();
        boolean boolean10 = year0.equals((java.lang.Object) timeSeries8);
        boolean boolean11 = timeSeries8.isEmpty();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries3.setNotify(false);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 1560190010308L);
        java.util.Date date12 = fixedMillisecond8.getStart();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(3, year13);
        java.lang.Object obj15 = null;
        int int16 = year13.compareTo(obj15);
        long long17 = year13.getFirstMillisecond();
        try {
            org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) '4', year13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + "hi!" + "'", comparable6.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-31507200000L) + "'", long17 == (-31507200000L));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setNotify(false);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 1.0d);
        int int8 = timeSeries1.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries10.setMaximumItemAge((long) (byte) 1);
        timeSeries10.setNotify(true);
        java.util.List list15 = timeSeries10.getItems();
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries1.setNotify(false);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "hi!" + "'", comparable4.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNotNull(collection16);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries2.setMaximumItemAge((long) (byte) 1);
        int int5 = timeSeries2.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries8.setNotify(false);
        timeSeries8.removeAgedItems(true);
        int int13 = timeSeries8.getItemCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str16 = spreadsheetDate15.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean20 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        timeSeries8.setKey((java.lang.Comparable) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(2, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean28 = spreadsheetDate24.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        int int29 = spreadsheetDate27.toSerial();
        boolean boolean30 = spreadsheetDate18.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        timeSeries2.setKey((java.lang.Comparable) spreadsheetDate18);
        try {
            org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addMonths((-451), (org.jfree.data.time.SerialDate) spreadsheetDate18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 35 + "'", int29 == 35);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setNotify(false);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 1560190010308L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries12.fireSeriesChanged();
        timeSeries12.setMaximumItemCount(10);
        boolean boolean16 = fixedMillisecond10.equals((java.lang.Object) 10);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.lang.String str18 = year17.toString();
        boolean boolean19 = fixedMillisecond10.equals((java.lang.Object) year17);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries23.fireSeriesChanged();
        timeSeries23.setMaximumItemCount(10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries23.addChangeListener(seriesChangeListener27);
        java.lang.String str29 = timeSeries23.getDomainDescription();
        org.jfree.data.time.Year year31 = org.jfree.data.time.Year.parseYear("2019");
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) year31);
        java.lang.Class<?> wildcardClass33 = year31.getClass();
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year17, "", "2019", (java.lang.Class) wildcardClass33);
        int int35 = timeSeriesDataItem9.compareTo((java.lang.Object) year17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = timeSeriesDataItem9.getPeriod();
        java.util.Date date37 = regularTimePeriod36.getEnd();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "hi!" + "'", comparable4.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Time" + "'", str29.equals("Time"));
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries1.fireSeriesChanged();
        java.lang.Class<?> wildcardClass3 = timeSeries1.getClass();
        java.lang.String str4 = timeSeries1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean10 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        timeSeries1.setKey((java.lang.Comparable) spreadsheetDate9);
        int int12 = spreadsheetDate9.toSerial();
        int int13 = spreadsheetDate9.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str16 = spreadsheetDate15.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str19 = spreadsheetDate18.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean23 = spreadsheetDate18.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate24 = spreadsheetDate15.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean25 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        try {
            org.jfree.data.time.SerialDate serialDate27 = spreadsheetDate9.getNearestDayOfWeek(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 35 + "'", int12 == 35);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 35 + "'", int13 == 35);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemCount(10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.addChangeListener(seriesChangeListener5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long9 = timeSeries8.getMaximumItemAge();
        java.lang.String str10 = timeSeries8.getDescription();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long13 = timeSeries12.getMaximumItemAge();
        java.lang.String str14 = timeSeries12.getDescription();
        timeSeries12.setDomainDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries8.addAndOrUpdate(timeSeries12);
        timeSeries8.setMaximumItemCount((int) (short) 100);
        java.util.Collection collection20 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        int int21 = timeSeries8.getItemCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean29 = spreadsheetDate25.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str32 = spreadsheetDate31.getDescription();
        boolean boolean34 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate31, 11);
        java.util.Date date35 = spreadsheetDate25.toDate();
        boolean boolean36 = timeSeries8.equals((java.lang.Object) date35);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        long long3 = day2.getLastMillisecond();
        long long4 = day2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.next();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long8 = timeSeries7.getMaximumItemAge();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
        long long13 = day12.getLastMillisecond();
        long long14 = day12.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries17.fireSeriesChanged();
        timeSeries17.setMaximumItemCount(10);
        boolean boolean21 = fixedMillisecond15.equals((java.lang.Object) 10);
        boolean boolean22 = day12.equals((java.lang.Object) fixedMillisecond15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day12, (double) 2147483647);
        int int25 = day2.compareTo((java.lang.Object) day12);
        org.jfree.data.time.SerialDate serialDate26 = day12.getSerialDate();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-2206022400001L) + "'", long3 == (-2206022400001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2206022400001L) + "'", long4 == (-2206022400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-2206022400001L) + "'", long13 == (-2206022400001L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-2206022400001L) + "'", long14 == (-2206022400001L));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(serialDate26);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("ERROR : Relative To String");
        java.lang.Class<?> wildcardClass2 = seriesException1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemCount(10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.addChangeListener(seriesChangeListener5);
        timeSeries1.setMaximumItemCount(10);
        timeSeries1.setMaximumItemAge((long) (byte) 1);
        timeSeries1.setMaximumItemAge((long) 9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries1.addChangeListener(seriesChangeListener13);
        java.lang.String str15 = timeSeries1.getDescription();
        timeSeries1.setRangeDescription("Wed Dec 31 16:00:00 PST 1969");
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long5 = timeSeries4.getMaximumItemAge();
        java.lang.String str6 = timeSeries4.getDescription();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long9 = timeSeries8.getMaximumItemAge();
        java.lang.String str10 = timeSeries8.getDescription();
        timeSeries8.setDomainDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries8);
        boolean boolean14 = day2.equals((java.lang.Object) timeSeries4);
        long long15 = day2.getLastMillisecond();
        java.lang.String str16 = day2.toString();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-2206022400001L) + "'", long15 == (-2206022400001L));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "3-February-1900" + "'", str16.equals("3-February-1900"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries1.setMaximumItemAge((long) (byte) 1);
        timeSeries1.setNotify(true);
        timeSeries1.setDescription("");
        timeSeries1.removeAgedItems(true);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setNotify(false);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 1560190010308L);
        java.util.Calendar calendar10 = null;
        fixedMillisecond6.peg(calendar10);
        long long12 = fixedMillisecond6.getLastMillisecond();
        java.util.Calendar calendar13 = null;
        fixedMillisecond6.peg(calendar13);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "hi!" + "'", comparable4.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        long long3 = month0.getLastMillisecond();
        int int4 = month0.getYearValue();
        org.jfree.data.time.Year year5 = month0.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year6);
        boolean boolean9 = timeSeries7.equals((java.lang.Object) 1L);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries11.setNotify(false);
        java.lang.Comparable comparable14 = timeSeries11.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries11.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) 1560190010308L);
        java.util.Date date20 = fixedMillisecond16.getStart();
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond16.getLastMillisecond(calendar21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) 5);
        java.lang.Class class25 = timeSeries7.getTimePeriodClass();
        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize(class25);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5, class25);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long33 = timeSeries32.getMaximumItemAge();
        java.lang.String str34 = timeSeries32.getDescription();
        java.lang.Class class35 = timeSeries32.getTimePeriodClass();
        java.util.Date date36 = null;
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date36, timeZone37);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560190014451L, "Nearest", "hi!", class35);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str43 = spreadsheetDate42.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str46 = spreadsheetDate45.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate48);
        boolean boolean50 = spreadsheetDate45.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SerialDate serialDate51 = spreadsheetDate42.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate45);
        boolean boolean52 = month40.equals((java.lang.Object) spreadsheetDate45);
        java.lang.Number number53 = timeSeries39.getValue((org.jfree.data.time.RegularTimePeriod) month40);
        long long54 = month40.getSerialIndex();
        try {
            timeSeries27.add((org.jfree.data.time.RegularTimePeriod) month40, (double) (-2206108800000L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + "hi!" + "'", comparable14.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2L + "'", long22 == 2L);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775807L + "'", long33 == 9223372036854775807L);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNull(number53);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 24234L + "'", long54 == 24234L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 1L);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries5.setNotify(false);
        java.lang.Comparable comparable8 = timeSeries5.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (double) 1560190010308L);
        java.util.Date date14 = fixedMillisecond10.getStart();
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond10.getLastMillisecond(calendar15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (double) 5);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries21.setNotify(false);
        java.lang.Comparable comparable24 = timeSeries21.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (double) 1560190010308L);
        java.util.Date date30 = fixedMillisecond26.getStart();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(3, year31);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries34.setNotify(false);
        java.lang.Comparable comparable37 = timeSeries34.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries34.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (double) 1560190010308L);
        java.util.Calendar calendar43 = null;
        fixedMillisecond39.peg(calendar43);
        long long45 = fixedMillisecond39.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries48.setNotify(false);
        timeSeries48.removeAgedItems(true);
        int int53 = timeSeries48.getItemCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str56 = spreadsheetDate55.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate58);
        boolean boolean60 = spreadsheetDate55.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate58);
        timeSeries48.setKey((java.lang.Comparable) spreadsheetDate58);
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.addDays(2, (org.jfree.data.time.SerialDate) spreadsheetDate58);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate64);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean68 = spreadsheetDate64.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate67);
        int int69 = spreadsheetDate67.toSerial();
        boolean boolean70 = spreadsheetDate58.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate67);
        int int71 = fixedMillisecond39.compareTo((java.lang.Object) spreadsheetDate67);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate74);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate78 = spreadsheetDate74.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate77);
        int int79 = spreadsheetDate77.getMonth();
        org.jfree.data.time.SerialDate serialDate80 = org.jfree.data.time.SerialDate.addDays(1, (org.jfree.data.time.SerialDate) spreadsheetDate77);
        serialDate80.setDescription("Value");
        boolean boolean83 = spreadsheetDate67.isBefore(serialDate80);
        int int84 = month32.compareTo((java.lang.Object) spreadsheetDate67);
        long long85 = month32.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem87 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month32, (double) 1.0f);
        timeSeries1.removeAgedItems(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + "hi!" + "'", comparable8.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2L + "'", long16 == 2L);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + "hi!" + "'", comparable24.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + "hi!" + "'", comparable37.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 2L + "'", long45 == 2L);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 35 + "'", int69 == 35);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertNotNull(serialDate78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 2 + "'", int79 == 2);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + (-23731200001L) + "'", long85 == (-23731200001L));
        org.junit.Assert.assertNotNull(timeSeriesDataItem87);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setNotify(false);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 1.0d);
        int int8 = timeSeries1.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries10.setMaximumItemAge((long) (byte) 1);
        timeSeries10.setNotify(true);
        java.util.List list15 = timeSeries10.getItems();
        java.util.Collection collection16 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries1.setRangeDescription("Nearest");
        java.lang.String str19 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener20);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "hi!" + "'", comparable4.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Nearest" + "'", str19.equals("Nearest"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.lang.String str3 = spreadsheetDate1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries5.setNotify(false);
        timeSeries5.removeAgedItems(true);
        int int10 = timeSeries5.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long13 = timeSeries12.getMaximumItemAge();
        java.lang.String str14 = timeSeries12.getDescription();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long17 = timeSeries16.getMaximumItemAge();
        java.lang.String str18 = timeSeries16.getDescription();
        timeSeries16.setDomainDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries12.addAndOrUpdate(timeSeries16);
        java.lang.String str22 = timeSeries16.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond24.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) 0L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        boolean boolean31 = spreadsheetDate1.equals((java.lang.Object) fixedMillisecond24);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.lang.String str3 = year2.toString();
        long long4 = year2.getFirstMillisecond();
        java.lang.String str5 = year2.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (java.lang.Number) 0);
        int int8 = fixedMillisecond1.compareTo((java.lang.Object) year2);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long11 = timeSeries10.getMaximumItemAge();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.lang.String str13 = year12.toString();
        java.lang.Number number14 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) year12);
        java.util.Date date15 = year12.getEnd();
        int int16 = year2.compareTo((java.lang.Object) date15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day17);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        long long3 = month0.getLastMillisecond();
        int int4 = month0.getYearValue();
        org.jfree.data.time.Year year5 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries2.setNotify(false);
        java.lang.Comparable comparable5 = timeSeries2.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 1560190010308L);
        java.util.Calendar calendar11 = null;
        fixedMillisecond7.peg(calendar11);
        long long13 = fixedMillisecond7.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries16.setNotify(false);
        timeSeries16.removeAgedItems(true);
        int int21 = timeSeries16.getItemCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str24 = spreadsheetDate23.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean28 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        timeSeries16.setKey((java.lang.Comparable) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addDays(2, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean36 = spreadsheetDate32.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        int int37 = spreadsheetDate35.toSerial();
        boolean boolean38 = spreadsheetDate26.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        int int39 = fixedMillisecond7.compareTo((java.lang.Object) spreadsheetDate35);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, (org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long43 = timeSeries42.getMaximumItemAge();
        java.lang.String str44 = timeSeries42.getDescription();
        java.lang.Class class45 = timeSeries42.getTimePeriodClass();
        java.util.Date date46 = null;
        java.util.TimeZone timeZone47 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date46, timeZone47);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate35, class45);
        java.lang.Class class50 = org.jfree.data.time.RegularTimePeriod.downsize(class45);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "hi!" + "'", comparable5.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2L + "'", long13 == 2L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 35 + "'", int37 == 35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 9223372036854775807L + "'", long43 == 9223372036854775807L);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(class45);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(class50);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setNotify(false);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 1560190010308L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries12.fireSeriesChanged();
        timeSeries12.setMaximumItemCount(10);
        boolean boolean16 = fixedMillisecond10.equals((java.lang.Object) 10);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.lang.String str18 = year17.toString();
        boolean boolean19 = fixedMillisecond10.equals((java.lang.Object) year17);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries23.fireSeriesChanged();
        timeSeries23.setMaximumItemCount(10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries23.addChangeListener(seriesChangeListener27);
        java.lang.String str29 = timeSeries23.getDomainDescription();
        org.jfree.data.time.Year year31 = org.jfree.data.time.Year.parseYear("2019");
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) year31);
        java.lang.Class<?> wildcardClass33 = year31.getClass();
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year17, "", "2019", (java.lang.Class) wildcardClass33);
        int int35 = timeSeriesDataItem9.compareTo((java.lang.Object) year17);
        int int36 = year17.getYear();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "hi!" + "'", comparable4.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Time" + "'", str29.equals("Time"));
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        java.lang.String str2 = timeSeries1.getDescription();
        boolean boolean3 = timeSeries1.getNotify();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.lang.String str5 = year4.toString();
        long long6 = year4.getFirstMillisecond();
        java.lang.String str7 = year4.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (java.lang.Number) 0);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries11.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries15.setNotify(false);
        java.lang.Comparable comparable18 = timeSeries15.getKey();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 1.0d);
        int int22 = year19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (-1L));
        boolean boolean25 = timeSeriesDataItem9.equals((java.lang.Object) timeSeriesDataItem24);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long28 = timeSeries27.getMaximumItemAge();
        java.lang.String str29 = timeSeries27.getDescription();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long32 = timeSeries31.getMaximumItemAge();
        java.lang.String str33 = timeSeries31.getDescription();
        timeSeries31.setDomainDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries27.addAndOrUpdate(timeSeries31);
        int int37 = timeSeries31.getItemCount();
        java.util.List list38 = timeSeries31.getItems();
        java.util.List list39 = timeSeries31.getItems();
        boolean boolean40 = timeSeriesDataItem9.equals((java.lang.Object) list39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = timeSeriesDataItem9.getPeriod();
        try {
            timeSeries1.add(timeSeriesDataItem9);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + "hi!" + "'", comparable18.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 9223372036854775807L + "'", long28 == 9223372036854775807L);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(list38);
        org.junit.Assert.assertNotNull(list39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.lang.String str3 = year2.toString();
        long long4 = year2.getFirstMillisecond();
        java.lang.String str5 = year2.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (java.lang.Number) 0);
        int int8 = fixedMillisecond1.compareTo((java.lang.Object) year2);
        long long9 = year2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year2.previous();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test149");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries1.fireSeriesChanged();
//        timeSeries1.setMaximumItemCount(10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries1.addChangeListener(seriesChangeListener5);
//        timeSeries1.setMaximumItemCount(10);
//        timeSeries1.setMaximumItemAge((long) (byte) 1);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries12.fireSeriesChanged();
//        timeSeries12.setMaximumItemCount(10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries12.addChangeListener(seriesChangeListener16);
//        java.lang.String str18 = timeSeries12.getDomainDescription();
//        org.jfree.data.time.Year year20 = org.jfree.data.time.Year.parseYear("2019");
//        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) year20);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        long long24 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond23);
//        int int26 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((int) (byte) 10, 11);
//        java.util.Collection collection30 = timeSeries1.getTimePeriods();
//        java.beans.PropertyChangeListener propertyChangeListener31 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener31);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate34);
//        long long36 = day35.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day35.next();
//        org.jfree.data.time.SerialDate serialDate38 = day35.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate39 = day35.getSerialDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(10L);
//        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day35, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
//        java.lang.String str43 = day35.toString();
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560190103578L + "'", long24 == 1560190103578L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(collection30);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-2206022400001L) + "'", long36 == (-2206022400001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(timeSeries42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "3-February-1900" + "'", str43.equals("3-February-1900"));
//    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test150");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries1.fireSeriesChanged();
//        timeSeries1.setMaximumItemCount(10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries1.addChangeListener(seriesChangeListener5);
//        timeSeries1.setMaximumItemCount(10);
//        timeSeries1.setMaximumItemAge((long) (byte) 1);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries12.fireSeriesChanged();
//        timeSeries12.setMaximumItemCount(10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries12.addChangeListener(seriesChangeListener16);
//        java.lang.String str18 = timeSeries12.getDomainDescription();
//        org.jfree.data.time.Year year20 = org.jfree.data.time.Year.parseYear("2019");
//        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) year20);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        long long24 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond23);
//        int int26 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (java.lang.Number) 1562097599999L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) (-23731200001L));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560190103654L + "'", long24 == 1560190103654L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long5 = timeSeries4.getMaximumItemAge();
        java.lang.String str6 = timeSeries4.getDescription();
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        java.lang.Class<?> wildcardClass8 = timeSeries4.getClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L, "Time", "Time", (java.lang.Class) wildcardClass8);
        java.lang.String str13 = timeSeries12.getRangeDescription();
        java.util.Collection collection14 = timeSeries12.getTimePeriods();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
        org.junit.Assert.assertNotNull(collection14);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.lang.String str3 = year2.toString();
        long long4 = year2.getFirstMillisecond();
        java.lang.String str5 = year2.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (java.lang.Number) 0);
        int int8 = fixedMillisecond1.compareTo((java.lang.Object) year2);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long11 = timeSeries10.getMaximumItemAge();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.lang.String str13 = year12.toString();
        java.lang.Number number14 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) year12);
        java.util.Date date15 = year12.getEnd();
        int int16 = year2.compareTo((java.lang.Object) date15);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries21.setNotify(false);
        java.lang.Comparable comparable24 = timeSeries21.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (double) 1560190010308L);
        java.util.Calendar calendar30 = null;
        fixedMillisecond26.peg(calendar30);
        long long32 = fixedMillisecond26.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries35.setNotify(false);
        timeSeries35.removeAgedItems(true);
        int int40 = timeSeries35.getItemCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str43 = spreadsheetDate42.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate45);
        boolean boolean47 = spreadsheetDate42.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate45);
        timeSeries35.setKey((java.lang.Comparable) spreadsheetDate45);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addDays(2, (org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean55 = spreadsheetDate51.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate54);
        int int56 = spreadsheetDate54.toSerial();
        boolean boolean57 = spreadsheetDate45.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate54);
        int int58 = fixedMillisecond26.compareTo((java.lang.Object) spreadsheetDate54);
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, (org.jfree.data.time.SerialDate) spreadsheetDate54);
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long62 = timeSeries61.getMaximumItemAge();
        java.lang.String str63 = timeSeries61.getDescription();
        java.lang.Class class64 = timeSeries61.getTimePeriodClass();
        java.util.Date date65 = null;
        java.util.TimeZone timeZone66 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance(class64, date65, timeZone66);
        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate54, class64);
        org.jfree.data.time.TimeSeries timeSeries69 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date15, "ERROR : Relative To String", "", class64);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + "hi!" + "'", comparable24.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2L + "'", long32 == 2L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 35 + "'", int56 == 35);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 9223372036854775807L + "'", long62 == 9223372036854775807L);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertNotNull(class64);
        org.junit.Assert.assertNull(regularTimePeriod67);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((int) (short) 100, 2019);
        boolean boolean6 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries8.fireSeriesChanged();
        timeSeries8.setMaximumItemCount(10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries8.addChangeListener(seriesChangeListener12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        long long15 = month14.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month14.previous();
        long long17 = month14.getLastMillisecond();
        java.lang.Object obj18 = null;
        int int19 = month14.compareTo(obj18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) 8);
        java.lang.Object obj22 = timeSeries8.clone();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.addAndOrUpdate(timeSeries8);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        long long25 = month24.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month24.previous();
        long long27 = month24.getLastMillisecond();
        int int28 = month24.getYearValue();
        org.jfree.data.time.Year year29 = month24.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year29.next();
        java.util.Date date31 = regularTimePeriod30.getStart();
        try {
            timeSeries23.add(regularTimePeriod30, (java.lang.Number) 1560190045877L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 24234L + "'", long15 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertNotNull(year29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(date31);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setNotify(false);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 1560190010308L);
        java.util.Calendar calendar10 = null;
        fixedMillisecond6.peg(calendar10);
        long long12 = fixedMillisecond6.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries15.setNotify(false);
        timeSeries15.removeAgedItems(true);
        int int20 = timeSeries15.getItemCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str23 = spreadsheetDate22.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean27 = spreadsheetDate22.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        timeSeries15.setKey((java.lang.Comparable) spreadsheetDate25);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addDays(2, (org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean35 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate34);
        int int36 = spreadsheetDate34.toSerial();
        boolean boolean37 = spreadsheetDate25.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate34);
        int int38 = fixedMillisecond6.compareTo((java.lang.Object) spreadsheetDate34);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate45 = spreadsheetDate41.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate44);
        int int46 = spreadsheetDate44.getMonth();
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addDays(1, (org.jfree.data.time.SerialDate) spreadsheetDate44);
        serialDate47.setDescription("Value");
        boolean boolean50 = spreadsheetDate34.isBefore(serialDate47);
        int int51 = spreadsheetDate34.getDayOfWeek();
        boolean boolean53 = spreadsheetDate34.equals((java.lang.Object) 1);
        int int54 = spreadsheetDate34.getMonth();
        spreadsheetDate34.setDescription("");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate58);
        int int60 = spreadsheetDate58.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str63 = spreadsheetDate62.getDescription();
        int int64 = spreadsheetDate62.getDayOfWeek();
        int int65 = spreadsheetDate62.getYYYY();
        int int66 = spreadsheetDate58.compare((org.jfree.data.time.SerialDate) spreadsheetDate62);
        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries70.setNotify(false);
        timeSeries70.removeAgedItems(true);
        int int75 = timeSeries70.getItemCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str78 = spreadsheetDate77.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate80 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate80);
        boolean boolean82 = spreadsheetDate77.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate80);
        timeSeries70.setKey((java.lang.Comparable) spreadsheetDate80);
        org.jfree.data.time.SerialDate serialDate84 = org.jfree.data.time.SerialDate.addDays(2, (org.jfree.data.time.SerialDate) spreadsheetDate80);
        org.jfree.data.time.SerialDate serialDate85 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, (org.jfree.data.time.SerialDate) spreadsheetDate80);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate87 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day88 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate87);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate90 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean91 = spreadsheetDate87.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate90);
        int int92 = spreadsheetDate90.toSerial();
        boolean boolean93 = spreadsheetDate62.isInRange(serialDate85, (org.jfree.data.time.SerialDate) spreadsheetDate90);
        int int94 = spreadsheetDate34.compare(serialDate85);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "hi!" + "'", comparable4.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 35 + "'", int36 == 35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 7 + "'", int51 == 7);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2 + "'", int54 == 2);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 7 + "'", int60 == 7);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 7 + "'", int64 == 7);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1900 + "'", int65 == 1900);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNull(str78);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertNotNull(serialDate85);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 35 + "'", int92 == 35);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 1 + "'", int94 == 1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean6 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        java.lang.String str7 = spreadsheetDate4.getDescription();
        java.util.Date date8 = spreadsheetDate4.toDate();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date8, timeZone9);
        long long11 = day10.getFirstMillisecond();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-2206108800000L) + "'", long11 == (-2206108800000L));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2147483647, 30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("June 2019");
        org.jfree.data.time.Year year2 = month1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month1.next();
        org.junit.Assert.assertNotNull(month1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond1);
        java.lang.Object obj4 = seriesChangeEvent3.getSource();
        java.lang.String str5 = seriesChangeEvent3.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Wed Dec 31 15:59:59 PST 1969]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=Wed Dec 31 15:59:59 PST 1969]"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str3 = spreadsheetDate2.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean7 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.lang.String str8 = spreadsheetDate5.getDescription();
        int int9 = spreadsheetDate5.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate5.getPreviousDayOfWeek(5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean17 = spreadsheetDate13.isOnOrAfter(serialDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str20 = spreadsheetDate19.getDescription();
        int int21 = spreadsheetDate19.getDayOfWeek();
        boolean boolean22 = spreadsheetDate13.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean23 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries26.setNotify(false);
        java.lang.Comparable comparable29 = timeSeries26.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries26.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (double) 1560190010308L);
        java.util.Date date35 = fixedMillisecond31.getStart();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
        boolean boolean37 = spreadsheetDate5.equals((java.lang.Object) date35);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 7 + "'", int21 == 7);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + "hi!" + "'", comparable29.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setNotify(false);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        java.util.List list8 = timeSeries1.getItems();
        timeSeries1.setRangeDescription("Last");
        timeSeries1.removeAgedItems(false);
        timeSeries1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=Wed Dec 31 15:59:59 PST 1969]");
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "hi!" + "'", comparable4.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
        long long2 = year1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year1.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1900L + "'", long2 == 1900L);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemCount(10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.addChangeListener(seriesChangeListener5);
        timeSeries1.setMaximumItemCount(10);
        timeSeries1.setMaximumItemAge((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries12.fireSeriesChanged();
        timeSeries12.setMaximumItemCount(10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries12.addChangeListener(seriesChangeListener16);
        java.lang.String str18 = timeSeries12.getDomainDescription();
        org.jfree.data.time.Year year20 = org.jfree.data.time.Year.parseYear("2019");
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) year20);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year20.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year20.previous();
        java.util.Calendar calendar25 = null;
        try {
            long long26 = year20.getFirstMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setNotify(false);
        timeSeries1.removeAgedItems(true);
        long long6 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long9 = timeSeries8.getMaximumItemAge();
        java.lang.String str10 = timeSeries8.getDescription();
        timeSeries8.setDomainDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries14.fireSeriesChanged();
        timeSeries14.setMaximumItemCount(10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries14.addChangeListener(seriesChangeListener18);
        timeSeries14.setMaximumItemCount(10);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        java.lang.String str23 = year22.toString();
        long long24 = year22.getFirstMillisecond();
        java.lang.String str25 = year22.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year22, (double) 1);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries8.addAndOrUpdate(timeSeries14);
        timeSeries28.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries28.createCopy((int) '#', (int) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries1.addAndOrUpdate(timeSeries28);
        java.util.List list34 = timeSeries1.getItems();
        timeSeries1.setRangeDescription("ERROR : Relative To String");
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener37);
        timeSeries1.fireSeriesChanged();
        try {
            timeSeries1.delete(2019, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertNotNull(list34);
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test164");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries4.fireSeriesChanged();
//        timeSeries4.setMaximumItemCount(10);
//        boolean boolean8 = fixedMillisecond2.equals((java.lang.Object) 10);
//        long long9 = fixedMillisecond2.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        timeSeries1.setMaximumItemCount(3);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190104730L + "'", long9 == 1560190104730L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long2 = timeSeries1.getMaximumItemAge();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long6 = timeSeries5.getMaximumItemAge();
        java.lang.String str7 = timeSeries5.getDescription();
        timeSeries5.setDomainDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries5);
        int int11 = timeSeries5.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long14 = timeSeries13.getMaximumItemAge();
        java.lang.String str15 = timeSeries13.getDescription();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long18 = timeSeries17.getMaximumItemAge();
        java.lang.String str19 = timeSeries17.getDescription();
        timeSeries17.setDomainDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries13.addAndOrUpdate(timeSeries17);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries17.addChangeListener(seriesChangeListener23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond26.previous();
        java.lang.String str28 = fixedMillisecond26.toString();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long31 = timeSeries30.getMaximumItemAge();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.lang.String str33 = year32.toString();
        java.lang.Number number34 = timeSeries30.getValue((org.jfree.data.time.RegularTimePeriod) year32);
        int int35 = fixedMillisecond26.compareTo((java.lang.Object) number34);
        boolean boolean36 = timeSeries17.equals((java.lang.Object) fixedMillisecond26);
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries5.addAndOrUpdate(timeSeries17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries42.fireSeriesChanged();
        timeSeries42.setMaximumItemCount(10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener46 = null;
        timeSeries42.addChangeListener(seriesChangeListener46);
        timeSeries42.setMaximumItemCount(10);
        timeSeries42.setMaximumItemAge((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries53.fireSeriesChanged();
        timeSeries53.setMaximumItemCount(10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener57 = null;
        timeSeries53.addChangeListener(seriesChangeListener57);
        java.lang.String str59 = timeSeries53.getDomainDescription();
        org.jfree.data.time.Year year61 = org.jfree.data.time.Year.parseYear("2019");
        timeSeries53.delete((org.jfree.data.time.RegularTimePeriod) year61);
        timeSeries42.delete((org.jfree.data.time.RegularTimePeriod) year61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = year61.next();
        int int65 = year61.getYear();
        int int66 = day40.compareTo((java.lang.Object) int65);
        long long67 = day40.getSerialIndex();
        int int68 = day40.getMonth();
        int int69 = timeSeries37.getIndex((org.jfree.data.time.RegularTimePeriod) day40);
        timeSeries37.setMaximumItemCount((int) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str28.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2019" + "'", str33.equals("2019"));
        org.junit.Assert.assertNull(number34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Time" + "'", str59.equals("Time"));
        org.junit.Assert.assertNotNull(year61);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 2019 + "'", int65 == 2019);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 35L + "'", long67 == 35L);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 2 + "'", int68 == 2);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        timeSeries1.setDomainDescription("Nearest");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries5.setNotify(false);
        java.lang.Comparable comparable8 = timeSeries5.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.util.List list12 = timeSeries5.getItems();
        timeSeries5.setRangeDescription("Last");
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries16.setNotify(false);
        java.lang.Comparable comparable19 = timeSeries16.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond21.next();
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond21.getMiddleMillisecond(calendar24);
        int int26 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries29.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries29.createCopy(10, 12);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries1.addAndOrUpdate(timeSeries33);
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate42 = spreadsheetDate38.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate41);
        int int43 = spreadsheetDate41.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str46 = spreadsheetDate45.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate48);
        boolean boolean50 = spreadsheetDate45.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate48);
        java.lang.String str51 = spreadsheetDate48.getDescription();
        int int52 = spreadsheetDate48.getDayOfMonth();
        boolean boolean53 = spreadsheetDate41.isOn((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SerialDate serialDate55 = day54.getSerialDate();
        long long56 = day54.getSerialIndex();
        int int57 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day54);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + "hi!" + "'", comparable8.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + "hi!" + "'", comparable19.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2L + "'", long25 == 2L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 35 + "'", int43 == 35);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 35L + "'", long56 == 35L);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long2 = timeSeries1.getMaximumItemAge();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long6 = timeSeries5.getMaximumItemAge();
        java.lang.String str7 = timeSeries5.getDescription();
        timeSeries5.setDomainDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries5);
        int int11 = timeSeries5.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long14 = timeSeries13.getMaximumItemAge();
        java.lang.String str15 = timeSeries13.getDescription();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long18 = timeSeries17.getMaximumItemAge();
        java.lang.String str19 = timeSeries17.getDescription();
        timeSeries17.setDomainDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries13.addAndOrUpdate(timeSeries17);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries17.addChangeListener(seriesChangeListener23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond26.previous();
        java.lang.String str28 = fixedMillisecond26.toString();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long31 = timeSeries30.getMaximumItemAge();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.lang.String str33 = year32.toString();
        java.lang.Number number34 = timeSeries30.getValue((org.jfree.data.time.RegularTimePeriod) year32);
        int int35 = fixedMillisecond26.compareTo((java.lang.Object) number34);
        boolean boolean36 = timeSeries17.equals((java.lang.Object) fixedMillisecond26);
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries5.addAndOrUpdate(timeSeries17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries42.fireSeriesChanged();
        timeSeries42.setMaximumItemCount(10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener46 = null;
        timeSeries42.addChangeListener(seriesChangeListener46);
        timeSeries42.setMaximumItemCount(10);
        timeSeries42.setMaximumItemAge((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries53.fireSeriesChanged();
        timeSeries53.setMaximumItemCount(10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener57 = null;
        timeSeries53.addChangeListener(seriesChangeListener57);
        java.lang.String str59 = timeSeries53.getDomainDescription();
        org.jfree.data.time.Year year61 = org.jfree.data.time.Year.parseYear("2019");
        timeSeries53.delete((org.jfree.data.time.RegularTimePeriod) year61);
        timeSeries42.delete((org.jfree.data.time.RegularTimePeriod) year61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = year61.next();
        int int65 = year61.getYear();
        int int66 = day40.compareTo((java.lang.Object) int65);
        long long67 = day40.getSerialIndex();
        int int68 = day40.getMonth();
        int int69 = timeSeries37.getIndex((org.jfree.data.time.RegularTimePeriod) day40);
        int int70 = day40.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str28.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2019" + "'", str33.equals("2019"));
        org.junit.Assert.assertNull(number34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Time" + "'", str59.equals("Time"));
        org.junit.Assert.assertNotNull(year61);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 2019 + "'", int65 == 2019);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 35L + "'", long67 == 35L);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 2 + "'", int68 == 2);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 3 + "'", int70 == 3);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 1L);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries5.setNotify(false);
        timeSeries5.removeAgedItems(true);
        timeSeries5.removeAgedItems(true);
        java.util.Collection collection12 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(collection12);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("ERROR : Relative To String");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        java.lang.String str4 = seriesException3.toString();
        java.lang.Throwable[] throwableArray5 = seriesException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("2-February-1900");
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
        java.lang.String str10 = timePeriodFormatException8.toString();
        seriesException3.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str4.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2-February-1900" + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: 2-February-1900"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str3 = spreadsheetDate2.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str6 = spreadsheetDate5.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate5.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean12 = month0.equals((java.lang.Object) spreadsheetDate5);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries14.setNotify(false);
        timeSeries14.removeAgedItems(true);
        int int19 = timeSeries14.getItemCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str22 = spreadsheetDate21.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean26 = spreadsheetDate21.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate24);
        timeSeries14.setKey((java.lang.Comparable) spreadsheetDate24);
        boolean boolean28 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str31 = spreadsheetDate30.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate33);
        boolean boolean35 = spreadsheetDate30.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate33);
        java.lang.String str36 = spreadsheetDate33.getDescription();
        int int37 = spreadsheetDate33.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate39 = spreadsheetDate33.getPreviousDayOfWeek(5);
        int int40 = spreadsheetDate24.compareTo((java.lang.Object) spreadsheetDate33);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str44 = spreadsheetDate43.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str47 = spreadsheetDate46.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate49);
        boolean boolean51 = spreadsheetDate46.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate49);
        org.jfree.data.time.SerialDate serialDate52 = spreadsheetDate43.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean53 = month41.equals((java.lang.Object) spreadsheetDate46);
        int int54 = spreadsheetDate46.getYYYY();
        org.jfree.data.time.SerialDate serialDate55 = spreadsheetDate24.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate46);
        java.lang.String str56 = spreadsheetDate24.toString();
        int int57 = spreadsheetDate24.getDayOfWeek();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 3 + "'", int37 == 3);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1900 + "'", int54 == 1900);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "3-February-1900" + "'", str56.equals("3-February-1900"));
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 7 + "'", int57 == 7);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long2 = timeSeries1.getMaximumItemAge();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long6 = timeSeries5.getMaximumItemAge();
        java.lang.String str7 = timeSeries5.getDescription();
        timeSeries5.setDomainDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries5.addChangeListener(seriesChangeListener11);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener13);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Jul");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(1900);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(5, year2);
        java.util.Date date4 = month3.getStart();
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setNotify(false);
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 1560190010308L);
        java.util.Calendar calendar10 = null;
        fixedMillisecond6.peg(calendar10);
        long long12 = fixedMillisecond6.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries15.setNotify(false);
        timeSeries15.removeAgedItems(true);
        int int20 = timeSeries15.getItemCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str23 = spreadsheetDate22.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean27 = spreadsheetDate22.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        timeSeries15.setKey((java.lang.Comparable) spreadsheetDate25);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addDays(2, (org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean35 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate34);
        int int36 = spreadsheetDate34.toSerial();
        boolean boolean37 = spreadsheetDate25.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate34);
        int int38 = fixedMillisecond6.compareTo((java.lang.Object) spreadsheetDate34);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate45 = spreadsheetDate41.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate44);
        int int46 = spreadsheetDate44.getMonth();
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addDays(1, (org.jfree.data.time.SerialDate) spreadsheetDate44);
        serialDate47.setDescription("Value");
        boolean boolean50 = spreadsheetDate34.isBefore(serialDate47);
        int int51 = spreadsheetDate34.getDayOfWeek();
        boolean boolean53 = spreadsheetDate34.equals((java.lang.Object) 1);
        int int54 = spreadsheetDate34.getMonth();
        spreadsheetDate34.setDescription("");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate58);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate62 = spreadsheetDate58.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate61);
        int int63 = spreadsheetDate58.getDayOfWeek();
        boolean boolean64 = spreadsheetDate34.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate58);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + "hi!" + "'", comparable4.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 35 + "'", int36 == 35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 7 + "'", int51 == 7);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2 + "'", int54 == 2);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 7 + "'", int63 == 7);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test177");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
//        timeSeries2.fireSeriesChanged();
//        timeSeries2.setMaximumItemCount(10);
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) 10);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        java.lang.String str8 = year7.toString();
//        boolean boolean9 = fixedMillisecond0.equals((java.lang.Object) year7);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond0.getLastMillisecond(calendar10);
//        long long12 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1560190020289L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeriesDataItem14.getPeriod();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod15, (java.lang.Number) 1560190015730L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560190105713L + "'", long11 == 1560190105713L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560190105713L + "'", long12 == 1560190105713L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        java.lang.String str2 = timeSeries1.getDescription();
        java.lang.Comparable comparable3 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond5);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond5.getMiddleMillisecond(calendar8);
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + 1.0d + "'", comparable3.equals(1.0d));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-452L) + "'", long9 == (-452L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int8 = day7.getDayOfMonth();
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Class<?> wildcardClass11 = seriesException10.getClass();
        boolean boolean12 = day7.equals((java.lang.Object) wildcardClass11);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = day7.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str5 = spreadsheetDate4.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate7);
        boolean boolean9 = spreadsheetDate4.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean16 = spreadsheetDate12.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        int int17 = spreadsheetDate15.toSerial();
        boolean boolean18 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        int int20 = spreadsheetDate15.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(9);
        boolean boolean26 = spreadsheetDate22.isOnOrAfter(serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str29 = spreadsheetDate28.getDescription();
        int int30 = spreadsheetDate28.getDayOfWeek();
        boolean boolean31 = spreadsheetDate22.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate28);
        int int32 = spreadsheetDate22.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate35);
        int int37 = spreadsheetDate35.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str40 = spreadsheetDate39.getDescription();
        int int41 = spreadsheetDate39.getDayOfWeek();
        int int42 = spreadsheetDate39.getYYYY();
        int int43 = spreadsheetDate35.compare((org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.SerialDate serialDate49 = spreadsheetDate45.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate48);
        int int50 = spreadsheetDate48.getMonth();
        boolean boolean51 = spreadsheetDate39.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate48);
        java.lang.Class<?> wildcardClass52 = spreadsheetDate48.getClass();
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.addMonths((int) 'a', (org.jfree.data.time.SerialDate) spreadsheetDate48);
        boolean boolean54 = spreadsheetDate22.isAfter(serialDate53);
        boolean boolean55 = spreadsheetDate15.isAfter(serialDate53);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 35 + "'", int17 == 35);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1900 + "'", int20 == 1900);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 7 + "'", int30 == 7);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 3 + "'", int32 == 3);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 7 + "'", int37 == 7);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 7 + "'", int41 == 7);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1900 + "'", int42 == 1900);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2 + "'", int50 == 2);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((int) (short) 100, 2019);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries5.addChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.String str9 = year8.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, 0.0d);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond13.previous();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond13);
        java.util.Calendar calendar16 = null;
        fixedMillisecond13.peg(calendar16);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        timeSeries5.fireSeriesChanged();
        try {
            org.jfree.data.time.TimeSeries timeSeries22 = timeSeries5.createCopy(520764324, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(timeSeries18);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemCount(10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.addChangeListener(seriesChangeListener5);
        java.lang.String str7 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year9 = org.jfree.data.time.Year.parseYear("2019");
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year9);
        long long11 = year9.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries1.setNotify(false);
        timeSeries1.removeAgedItems(true);
        timeSeries1.removeAgedItems(true);
        timeSeries1.setRangeDescription("ERROR : Relative To String");
        timeSeries1.setMaximumItemCount(3);
        timeSeries1.setDescription("");
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        int int3 = month0.getMonth();
        org.jfree.data.time.Year year4 = month0.getYear();
        long long5 = month0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries7.setNotify(false);
        timeSeries7.removeAgedItems(true);
        int int12 = timeSeries7.getItemCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str15 = spreadsheetDate14.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate14.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        timeSeries7.setKey((java.lang.Comparable) spreadsheetDate17);
        boolean boolean21 = month0.equals((java.lang.Object) timeSeries7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond23.next();
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond23.getFirstMillisecond(calendar25);
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond23.getLastMillisecond(calendar27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        java.lang.String str30 = year29.toString();
        long long31 = year29.getFirstMillisecond();
        java.lang.String str32 = year29.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) 0);
        java.lang.Object obj35 = timeSeriesDataItem34.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = timeSeriesDataItem34.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, regularTimePeriod36);
        java.util.Calendar calendar38 = null;
        fixedMillisecond23.peg(calendar38);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-452L) + "'", long26 == (-452L));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-452L) + "'", long28 == (-452L));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2019" + "'", str30.equals("2019"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1546329600000L + "'", long31 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(timeSeries37);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (-2206108800000L));
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!");
        timeSeries6.setNotify(false);
        java.lang.Comparable comparable9 = timeSeries6.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 1560190010308L);
        java.util.Date date15 = fixedMillisecond11.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(3, year16);
        int int18 = fixedMillisecond1.compareTo((java.lang.Object) 3);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + "hi!" + "'", comparable9.equals("hi!"));
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("1969");
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.lang.String str3 = year2.toString();
        long long4 = year2.getFirstMillisecond();
        java.lang.String str5 = year2.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (java.lang.Number) 0);
        int int8 = fixedMillisecond1.compareTo((java.lang.Object) year2);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long11 = timeSeries10.getMaximumItemAge();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.lang.String str13 = year12.toString();
        java.lang.Number number14 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) year12);
        java.util.Date date15 = year12.getEnd();
        int int16 = year2.compareTo((java.lang.Object) date15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (-452));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
        long long21 = fixedMillisecond19.getSerialIndex();
        java.util.Date date22 = fixedMillisecond19.getTime();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str25 = spreadsheetDate24.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str28 = spreadsheetDate27.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean32 = spreadsheetDate27.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SerialDate serialDate33 = spreadsheetDate24.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        boolean boolean39 = spreadsheetDate35.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        int int40 = spreadsheetDate38.toSerial();
        boolean boolean41 = spreadsheetDate24.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        java.util.Date date42 = spreadsheetDate24.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        java.lang.String str45 = spreadsheetDate44.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) '#');
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate47);
        boolean boolean49 = spreadsheetDate44.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate47);
        java.lang.String str50 = spreadsheetDate47.getDescription();
        java.util.Date date51 = spreadsheetDate47.toDate();
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date51, timeZone52);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date42, timeZone52);
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month(date22, timeZone52);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date15, timeZone52);
        long long57 = day56.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-452L) + "'", long21 == (-452L));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 35 + "'", int40 == 35);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 43830L + "'", long57 == 43830L);
    }
}

