import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(9);
        long long5 = year4.getMiddleMillisecond();
        long long6 = year4.getSerialIndex();
        java.util.Date date7 = year4.getEnd();
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone8);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date11, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.previous();
        java.util.Date date17 = year15.getStart();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date17, timeZone19);
        java.util.TimeZone timeZone21 = null;
        try {
            org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date17, timeZone21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61867512000001L) + "'", long5 == (-61867512000001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9L + "'", long6 == 9L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod20);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.lang.Object obj2 = null;
        boolean boolean3 = month0.equals(obj2);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean3, "", "Value");
        boolean boolean7 = timeSeries6.isEmpty();
        timeSeries6.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean12 = timeSeries11.getNotify();
        java.util.List list13 = timeSeries11.getItems();
        java.lang.String str14 = timeSeries11.getDescription();
        java.lang.String str15 = timeSeries11.getRangeDescription();
        timeSeries11.setDomainDescription("hi!");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month18, (double) 1559372400000L, false);
        long long22 = month18.getLastMillisecond();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month23.previous();
        java.lang.Class<?> wildcardClass25 = regularTimePeriod24.getClass();
        int int26 = month18.compareTo((java.lang.Object) regularTimePeriod24);
        long long27 = month18.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 0.0d);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        int int32 = timeSeriesDataItem29.compareTo((java.lang.Object) fixedMillisecond31);
        timeSeries6.add(timeSeriesDataItem29);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean36 = timeSeries35.getNotify();
        java.util.List list37 = timeSeries35.getItems();
        java.lang.String str38 = timeSeries35.getDescription();
        java.lang.String str39 = timeSeries35.getRangeDescription();
        java.lang.Comparable comparable40 = timeSeries35.getKey();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        long long42 = month41.getFirstMillisecond();
        java.util.Date date43 = month41.getEnd();
        timeSeries35.add((org.jfree.data.time.RegularTimePeriod) month41, (double) (-1));
        java.lang.Number number46 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) month41);
        timeSeries6.setNotify(false);
        java.lang.Comparable comparable49 = timeSeries6.getKey();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Value" + "'", str15.equals("Value"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1561964399999L + "'", long22 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 24234L + "'", long27 == 24234L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Value" + "'", str39.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable40 + "' != '" + 100.0f + "'", comparable40.equals(100.0f));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1559372400000L + "'", long42 == 1559372400000L);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + 0.0d + "'", number46.equals(0.0d));
        org.junit.Assert.assertTrue("'" + comparable49 + "' != '" + false + "'", comparable49.equals(false));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(9);
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean9 = timeSeries8.getNotify();
        long long10 = timeSeries8.getMaximumItemAge();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(9);
        long long13 = year12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year5, (org.jfree.data.time.RegularTimePeriod) year12);
        timeSeries16.removeAgedItems((long) 10, true);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
        timeSeries16.setKey((java.lang.Comparable) year20);
        int int23 = timeSeries16.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61883280000000L) + "'", long6 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61867512000001L) + "'", long13 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2147483647 + "'", int23 == 2147483647);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean5 = timeSeries4.getNotify();
        long long6 = timeSeries4.getMaximumItemAge();
        java.util.Collection collection7 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean10 = timeSeries9.getNotify();
        java.util.List list11 = timeSeries9.getItems();
        java.lang.String str12 = timeSeries9.getDescription();
        java.lang.String str13 = timeSeries9.getRangeDescription();
        timeSeries9.setDomainDescription("hi!");
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 1559372400000L, false);
        long long20 = month16.getLastMillisecond();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.previous();
        java.lang.Class<?> wildcardClass23 = regularTimePeriod22.getClass();
        int int24 = month16.compareTo((java.lang.Object) regularTimePeriod22);
        long long25 = month16.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month16.previous();
        java.lang.Number number27 = null;
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month16, number27);
        timeSeries4.removeAgedItems(0L, false);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean34 = timeSeries33.getNotify();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean37 = timeSeries36.getNotify();
        long long38 = timeSeries36.getMaximumItemAge();
        java.util.Collection collection39 = timeSeries33.getTimePeriodsUniqueToOtherSeries(timeSeries36);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean42 = timeSeries41.getNotify();
        long long43 = timeSeries41.getMaximumItemAge();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year45, 0.0d);
        long long48 = year45.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year45.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year45, (double) 9L);
        timeSeries33.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean56 = timeSeries55.getNotify();
        java.util.List list57 = timeSeries55.getItems();
        java.lang.String str58 = timeSeries55.getDescription();
        java.lang.String str59 = timeSeries55.getRangeDescription();
        timeSeries55.setDomainDescription("hi!");
        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month();
        timeSeries55.add((org.jfree.data.time.RegularTimePeriod) month62, (double) 1559372400000L, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) month62, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond67);
        org.jfree.data.time.Month month69 = new org.jfree.data.time.Month();
        long long70 = month69.getFirstMillisecond();
        java.lang.Object obj71 = null;
        boolean boolean72 = month69.equals(obj71);
        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean72, "", "Value");
        org.jfree.data.time.FixedMillisecond fixedMillisecond76 = new org.jfree.data.time.FixedMillisecond();
        timeSeries75.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond76, (double) 2019, false);
        boolean boolean80 = fixedMillisecond67.equals((java.lang.Object) 2019);
        boolean boolean81 = timeSeries4.equals((java.lang.Object) boolean80);
        double double82 = timeSeries4.getMaxY();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 9223372036854775807L + "'", long38 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 9223372036854775807L + "'", long43 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-62135740800000L) + "'", long48 == (-62135740800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(list57);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Value" + "'", str59.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries68);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1559372400000L + "'", long70 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertEquals((double) double82, Double.NaN, 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, 0.0d);
        long long7 = day4.getFirstMillisecond();
        java.util.Date date8 = day4.getStart();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date8);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561878000000L + "'", long7 == 1561878000000L);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.util.Date date2 = regularTimePeriod1.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        long long3 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, 0.0d);
        long long8 = year5.getFirstMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        long long10 = month9.getFirstMillisecond();
        java.lang.Object obj11 = null;
        boolean boolean12 = month9.equals(obj11);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean12, "", "Value");
        boolean boolean16 = timeSeries15.isEmpty();
        timeSeries15.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean21 = timeSeries20.getNotify();
        java.util.List list22 = timeSeries20.getItems();
        java.lang.String str23 = timeSeries20.getDescription();
        java.lang.String str24 = timeSeries20.getRangeDescription();
        timeSeries20.setDomainDescription("hi!");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) month27, (double) 1559372400000L, false);
        long long31 = month27.getLastMillisecond();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month32.previous();
        java.lang.Class<?> wildcardClass34 = regularTimePeriod33.getClass();
        int int35 = month27.compareTo((java.lang.Object) regularTimePeriod33);
        long long36 = month27.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) 0.0d);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        int int41 = timeSeriesDataItem38.compareTo((java.lang.Object) fixedMillisecond40);
        timeSeries15.add(timeSeriesDataItem38);
        boolean boolean43 = year5.equals((java.lang.Object) timeSeries15);
        java.lang.Comparable comparable44 = timeSeries15.getKey();
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        long long46 = month45.getFirstMillisecond();
        java.lang.Object obj47 = null;
        boolean boolean48 = month45.equals(obj47);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean48, "", "Value");
        timeSeries51.removeAgedItems((long) (short) 100, false);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(9);
        long long57 = year56.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries51.getDataItem((org.jfree.data.time.RegularTimePeriod) year56);
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries15.addAndOrUpdate(timeSeries51);
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean62 = timeSeries61.getNotify();
        long long63 = timeSeries61.getMaximumItemAge();
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries61.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year65, 0.0d);
        long long68 = year65.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = year65.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem71 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod69, (java.lang.Number) (short) -1);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries15.addOrUpdate(timeSeriesDataItem71);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62135740800000L) + "'", long8 == (-62135740800000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1559372400000L + "'", long10 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Value" + "'", str24.equals("Value"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1561964399999L + "'", long31 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 24234L + "'", long36 == 24234L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + comparable44 + "' != '" + false + "'", comparable44.equals(false));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1559372400000L + "'", long46 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-61867512000001L) + "'", long57 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem58);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 9223372036854775807L + "'", long63 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem67);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-62135740800000L) + "'", long68 == (-62135740800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod69);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        long long5 = day4.getSerialIndex();
        long long6 = day4.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43646L + "'", long5 == 43646L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561878000000L + "'", long6 == 1561878000000L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.lang.Object obj2 = null;
        boolean boolean3 = month0.equals(obj2);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean3, "", "Value");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries8.setKey((java.lang.Comparable) (-1));
        timeSeries8.setKey((java.lang.Comparable) 8);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries8.addChangeListener(seriesChangeListener13);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean17 = timeSeries16.getNotify();
        java.util.List list18 = timeSeries16.getItems();
        java.lang.String str19 = timeSeries16.getDescription();
        java.lang.String str20 = timeSeries16.getRangeDescription();
        timeSeries16.setDomainDescription("hi!");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) month23, (double) 1559372400000L, false);
        long long27 = month23.getLastMillisecond();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month28.previous();
        java.lang.Class<?> wildcardClass30 = regularTimePeriod29.getClass();
        int int31 = month23.compareTo((java.lang.Object) regularTimePeriod29);
        long long32 = month23.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month23, (java.lang.Number) 0.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries8.addOrUpdate(timeSeriesDataItem34);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year37, (java.lang.Number) (short) 10);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year41, (java.lang.Number) (short) 10);
        timeSeriesDataItem43.setSelected(true);
        int int46 = timeSeriesDataItem39.compareTo((java.lang.Object) true);
        int int47 = timeSeriesDataItem34.compareTo((java.lang.Object) timeSeriesDataItem39);
        java.lang.Object obj48 = timeSeriesDataItem39.clone();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries6.addOrUpdate(timeSeriesDataItem39);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Value" + "'", str20.equals("Value"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 24234L + "'", long32 == 24234L);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertNull(timeSeriesDataItem49);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean5 = timeSeries4.getNotify();
        java.util.List list6 = timeSeries4.getItems();
        java.lang.String str7 = timeSeries4.getDescription();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month10.next();
        java.lang.String str13 = month10.toString();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month8, (org.jfree.data.time.RegularTimePeriod) month10);
        int int15 = timeSeries1.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean18 = timeSeries17.getNotify();
        java.util.List list19 = timeSeries17.getItems();
        java.lang.String str20 = timeSeries17.getDescription();
        java.lang.String str21 = timeSeries17.getRangeDescription();
        timeSeries17.setDomainDescription("hi!");
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) month24, (double) 1559372400000L, false);
        long long28 = month24.getLastMillisecond();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.previous();
        java.lang.Class<?> wildcardClass31 = regularTimePeriod30.getClass();
        int int32 = month24.compareTo((java.lang.Object) regularTimePeriod30);
        long long33 = month24.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (java.lang.Number) 0.0d);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        long long37 = month36.getFirstMillisecond();
        java.util.Date date38 = month36.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month36.previous();
        java.lang.Class<?> wildcardClass40 = month36.getClass();
        int int41 = timeSeriesDataItem35.compareTo((java.lang.Object) month36);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean44 = timeSeries43.getNotify();
        java.util.List list45 = timeSeries43.getItems();
        java.lang.String str46 = timeSeries43.getDescription();
        java.lang.String str47 = timeSeries43.getRangeDescription();
        timeSeries43.setDomainDescription("hi!");
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
        timeSeries43.add((org.jfree.data.time.RegularTimePeriod) month50, (double) 1559372400000L, false);
        long long54 = month50.getLastMillisecond();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = month55.previous();
        java.lang.Class<?> wildcardClass57 = regularTimePeriod56.getClass();
        int int58 = month50.compareTo((java.lang.Object) regularTimePeriod56);
        int int59 = month50.getMonth();
        boolean boolean60 = timeSeriesDataItem35.equals((java.lang.Object) month50);
        timeSeries1.setKey((java.lang.Comparable) timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "June 2019" + "'", str13.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Value" + "'", str21.equals("Value"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1561964399999L + "'", long28 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 24234L + "'", long33 == 24234L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1559372400000L + "'", long37 == 1559372400000L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Value" + "'", str47.equals("Value"));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1561964399999L + "'", long54 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 6 + "'", int59 == 6);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.lang.Object obj2 = null;
        boolean boolean3 = month0.equals(obj2);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean3, "", "Value");
        boolean boolean7 = timeSeries6.isEmpty();
        timeSeries6.setDescription("");
        timeSeries6.setDescription("Value");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = null;
        try {
            timeSeries6.add(timeSeriesDataItem12, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.lang.Object obj2 = null;
        boolean boolean3 = month0.equals(obj2);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean3, "", "Value");
        long long7 = timeSeries6.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 5);
        long long10 = fixedMillisecond9.getSerialIndex();
        boolean boolean11 = timeSeries6.equals((java.lang.Object) fixedMillisecond9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond9.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 5L + "'", long10 == 5L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.lang.Class<?> wildcardClass2 = regularTimePeriod1.getClass();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        long long4 = month3.getFirstMillisecond();
        java.util.Date date5 = month3.getEnd();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date5, timeZone6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date5);
        long long10 = year9.getLastMillisecond();
        java.util.Calendar calendar11 = null;
        try {
            year9.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        java.lang.String str4 = timeSeries1.getDescription();
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month8, (double) 1559372400000L, false);
        long long12 = month8.getLastMillisecond();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
        java.lang.Class<?> wildcardClass15 = regularTimePeriod14.getClass();
        int int16 = month8.compareTo((java.lang.Object) regularTimePeriod14);
        long long17 = month8.getSerialIndex();
        java.util.Date date18 = month8.getEnd();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        java.lang.String str20 = year19.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 24234L + "'", long17 == 24234L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, 0.0d);
        long long7 = day4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 1556694000000L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561878000000L + "'", long7 == 1561878000000L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(9);
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean9 = timeSeries8.getNotify();
        long long10 = timeSeries8.getMaximumItemAge();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(9);
        long long13 = year12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year5, (org.jfree.data.time.RegularTimePeriod) year12);
        timeSeries16.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean20 = timeSeries19.getNotify();
        long long21 = timeSeries19.getMaximumItemAge();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year23, 0.0d);
        java.lang.Comparable comparable26 = timeSeries19.getKey();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean29 = timeSeries28.getNotify();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean32 = timeSeries31.getNotify();
        long long33 = timeSeries31.getMaximumItemAge();
        java.util.Collection collection34 = timeSeries28.getTimePeriodsUniqueToOtherSeries(timeSeries31);
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries19.addAndOrUpdate(timeSeries31);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        long long37 = month36.getFirstMillisecond();
        java.lang.Object obj38 = null;
        boolean boolean39 = month36.equals(obj38);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean39, "", "Value");
        timeSeries42.removeAgedItems((long) (short) 100, false);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(9);
        long long48 = year47.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries42.getDataItem((org.jfree.data.time.RegularTimePeriod) year47);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year47, (double) 2147483647);
        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries16.addAndOrUpdate(timeSeries31);
        timeSeries31.removeAgedItems(1560182626221L, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61883280000000L) + "'", long6 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61867512000001L) + "'", long13 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + comparable26 + "' != '" + 100.0f + "'", comparable26.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775807L + "'", long33 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1559372400000L + "'", long37 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-61867512000001L) + "'", long48 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem49);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertNotNull(timeSeries52);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.lang.Class<?> wildcardClass2 = regularTimePeriod1.getClass();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        long long4 = month3.getFirstMillisecond();
        java.util.Date date5 = month3.getEnd();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date5, timeZone6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date5);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getFirstMillisecond(calendar9);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond8);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        long long13 = month12.getFirstMillisecond();
        java.util.Date date14 = month12.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14);
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 10.0f, true);
        int int20 = day16.getDayOfMonth();
        long long21 = day16.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1559372400000L + "'", long13 == 1559372400000L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 30 + "'", int20 == 30);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1561878000000L + "'", long21 == 1561878000000L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean4 = timeSeries3.getNotify();
        java.util.List list5 = timeSeries3.getItems();
        java.lang.String str6 = timeSeries3.getDescription();
        java.lang.String str7 = timeSeries3.getRangeDescription();
        timeSeries3.setDomainDescription("hi!");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month10, (double) 1559372400000L, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (double) 6);
        java.util.Calendar calendar16 = null;
        try {
            month10.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertNull(timeSeriesDataItem15);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries1.removeAgedItems(false);
        timeSeries1.clear();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean7 = timeSeries6.getNotify();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean10 = timeSeries9.getNotify();
        long long11 = timeSeries9.getMaximumItemAge();
        java.util.Collection collection12 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean15 = timeSeries14.getNotify();
        long long16 = timeSeries14.getMaximumItemAge();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, 0.0d);
        long long21 = year18.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year18.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (double) 9L);
        timeSeries6.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean29 = timeSeries28.getNotify();
        java.util.List list30 = timeSeries28.getItems();
        java.lang.String str31 = timeSeries28.getDescription();
        java.lang.String str32 = timeSeries28.getRangeDescription();
        timeSeries28.setDomainDescription("hi!");
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) month35, (double) 1559372400000L, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) month35, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        long long43 = month42.getFirstMillisecond();
        java.lang.Object obj44 = null;
        boolean boolean45 = month42.equals(obj44);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean45, "", "Value");
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
        timeSeries48.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49, (double) 2019, false);
        boolean boolean53 = fixedMillisecond40.equals((java.lang.Object) 2019);
        java.util.Calendar calendar54 = null;
        long long55 = fixedMillisecond40.getMiddleMillisecond(calendar54);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) 100, true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62135740800000L) + "'", long21 == (-62135740800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Value" + "'", str32.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1559372400000L + "'", long43 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 5L + "'", long55 == 5L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem6);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem6);
        timeSeries8.setDomainDescription("Mon Jun 10 09:04:07 PDT 2019");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getFirstMillisecond(calendar2);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182673318L + "'", long1 == 1560182673318L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560182673318L + "'", long3 == 1560182673318L);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        long long3 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(9);
        long long6 = year5.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, 0.0d);
        java.util.Collection collection9 = timeSeries1.getTimePeriods();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        boolean boolean12 = fixedMillisecond10.equals((java.lang.Object) "Value");
        org.jfree.data.time.Month month14 = org.jfree.data.time.Month.parseMonth("May 2019");
        int int15 = month14.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) month14);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61867512000001L) + "'", long6 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(month14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(timeSeries16);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        long long3 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, 0.0d);
        java.lang.Comparable comparable8 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean11 = timeSeries10.getNotify();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean14 = timeSeries13.getNotify();
        long long15 = timeSeries13.getMaximumItemAge();
        java.util.Collection collection16 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.addAndOrUpdate(timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean20 = timeSeries19.getNotify();
        java.util.List list21 = timeSeries19.getItems();
        java.lang.String str22 = timeSeries19.getDescription();
        timeSeries19.clear();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries19.createCopy(0, 0);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        long long28 = month27.getFirstMillisecond();
        java.lang.Object obj29 = null;
        boolean boolean30 = month27.equals(obj29);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean30, "", "Value");
        timeSeries33.removeAgedItems((long) (short) 100, false);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(9);
        long long39 = year38.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries33.getDataItem((org.jfree.data.time.RegularTimePeriod) year38);
        long long41 = year38.getMiddleMillisecond();
        long long42 = year38.getSerialIndex();
        java.lang.Number number43 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year38, number43);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year38, (java.lang.Number) 1577865599999L);
        java.util.Calendar calendar47 = null;
        try {
            long long48 = year38.getMiddleMillisecond(calendar47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0f + "'", comparable8.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1559372400000L + "'", long28 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-61867512000001L) + "'", long39 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-61867512000001L) + "'", long41 == (-61867512000001L));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 9L + "'", long42 == 9L);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        java.lang.String str4 = timeSeries1.getDescription();
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month8, (double) 1559372400000L, false);
        long long12 = month8.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month8.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month8.next();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.lang.Object obj2 = null;
        boolean boolean3 = month0.equals(obj2);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean3, "", "Value");
        boolean boolean7 = timeSeries6.isEmpty();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        long long9 = month8.getFirstMillisecond();
        java.lang.Object obj10 = null;
        boolean boolean11 = month8.equals(obj10);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean11, "", "Value");
        timeSeries14.removeAgedItems((long) (short) 100, false);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(9);
        long long20 = year19.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) year19);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month22.previous();
        java.lang.Class<?> wildcardClass24 = regularTimePeriod23.getClass();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        long long26 = month25.getFirstMillisecond();
        java.util.Date date27 = month25.getEnd();
        java.util.TimeZone timeZone28 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date27, timeZone28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond(date27);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date27);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean34 = timeSeries33.getNotify();
        java.util.List list35 = timeSeries33.getItems();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(9);
        long long38 = year37.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean41 = timeSeries40.getNotify();
        long long42 = timeSeries40.getMaximumItemAge();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(9);
        long long45 = year44.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year44, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) year37, (org.jfree.data.time.RegularTimePeriod) year44);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
        long long50 = month49.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries48.getDataItem((org.jfree.data.time.RegularTimePeriod) month49);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent53 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj54 = seriesChangeEvent53.getSource();
        java.lang.Object obj55 = seriesChangeEvent53.getSource();
        java.lang.String str56 = seriesChangeEvent53.toString();
        boolean boolean57 = month49.equals((java.lang.Object) str56);
        boolean boolean58 = day31.equals((java.lang.Object) boolean57);
        int int59 = day31.getYear();
        java.lang.String str60 = day31.toString();
        org.jfree.data.time.SerialDate serialDate61 = day31.getSerialDate();
        int int62 = year19.compareTo((java.lang.Object) day31);
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = year64.previous();
        java.util.Date date66 = year64.getStart();
        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) day31, (org.jfree.data.time.RegularTimePeriod) year64);
        timeSeries67.clear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559372400000L + "'", long9 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61867512000001L) + "'", long20 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1559372400000L + "'", long26 == 1559372400000L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-61883280000000L) + "'", long38 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 9223372036854775807L + "'", long42 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-61867512000001L) + "'", long45 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1559372400000L + "'", long50 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertTrue("'" + obj54 + "' != '" + 100L + "'", obj54.equals(100L));
        org.junit.Assert.assertTrue("'" + obj55 + "' != '" + 100L + "'", obj55.equals(100L));
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str56.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "30-June-2019" + "'", str60.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(timeSeries67);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean5 = timeSeries4.getNotify();
        long long6 = timeSeries4.getMaximumItemAge();
        java.util.Collection collection7 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries4);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries1);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        java.lang.String str12 = month9.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month9);
        java.lang.String str14 = timeSeries1.getDescription();
        timeSeries1.setRangeDescription("Mon Jun 10 09:04:07 PDT 2019");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "June 2019" + "'", str12.equals("June 2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNull(str14);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.util.List list3 = timeSeries1.getItems();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(9);
//        long long6 = year5.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        boolean boolean9 = timeSeries8.getNotify();
//        long long10 = timeSeries8.getMaximumItemAge();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(9);
//        long long13 = year12.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year5, (org.jfree.data.time.RegularTimePeriod) year12);
//        timeSeries16.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        boolean boolean20 = timeSeries19.getNotify();
//        long long21 = timeSeries19.getMaximumItemAge();
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) (short) 1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year23, 0.0d);
//        java.lang.Comparable comparable26 = timeSeries19.getKey();
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        boolean boolean29 = timeSeries28.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        boolean boolean32 = timeSeries31.getNotify();
//        long long33 = timeSeries31.getMaximumItemAge();
//        java.util.Collection collection34 = timeSeries28.getTimePeriodsUniqueToOtherSeries(timeSeries31);
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries19.addAndOrUpdate(timeSeries31);
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
//        long long37 = month36.getFirstMillisecond();
//        java.lang.Object obj38 = null;
//        boolean boolean39 = month36.equals(obj38);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean39, "", "Value");
//        timeSeries42.removeAgedItems((long) (short) 100, false);
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(9);
//        long long48 = year47.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries42.getDataItem((org.jfree.data.time.RegularTimePeriod) year47);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year47, (double) 2147483647);
//        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries16.addAndOrUpdate(timeSeries31);
//        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
//        long long54 = month53.getFirstMillisecond();
//        java.lang.Object obj55 = null;
//        boolean boolean56 = month53.equals(obj55);
//        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean56, "", "Value");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries59.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60, (double) 2019, false);
//        java.lang.Object obj64 = null;
//        boolean boolean65 = fixedMillisecond60.equals(obj64);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries52.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60, (java.lang.Number) 2147483647);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond();
//        long long69 = fixedMillisecond68.getMiddleMillisecond();
//        java.util.Date date70 = fixedMillisecond68.getStart();
//        timeSeries52.setKey((java.lang.Comparable) fixedMillisecond68);
//        long long72 = timeSeries52.getMaximumItemAge();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(list3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61883280000000L) + "'", long6 == (-61883280000000L));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61867512000001L) + "'", long13 == (-61867512000001L));
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertTrue("'" + comparable26 + "' != '" + 100.0f + "'", comparable26.equals(100.0f));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775807L + "'", long33 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(collection34);
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1559372400000L + "'", long37 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-61867512000001L) + "'", long48 == (-61867512000001L));
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNull(timeSeriesDataItem51);
//        org.junit.Assert.assertNotNull(timeSeries52);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1559372400000L + "'", long54 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem67);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1560182673713L + "'", long69 == 1560182673713L);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 9223372036854775807L + "'", long72 == 9223372036854775807L);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries1.removeAgedItems(false);
        timeSeries1.clear();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean7 = timeSeries6.getNotify();
        java.util.List list8 = timeSeries6.getItems();
        java.lang.String str9 = timeSeries6.getDescription();
        java.lang.String str10 = timeSeries6.getRangeDescription();
        timeSeries6.setDomainDescription("hi!");
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) month13, (double) 1559372400000L, false);
        long long17 = month13.getLastMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month18.previous();
        java.lang.Class<?> wildcardClass20 = regularTimePeriod19.getClass();
        int int21 = month13.compareTo((java.lang.Object) regularTimePeriod19);
        long long22 = month13.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) 0.0d);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        int int27 = timeSeriesDataItem24.compareTo((java.lang.Object) fixedMillisecond26);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (java.lang.Number) 1561878000000L);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean32 = timeSeries31.getNotify();
        java.util.List list33 = timeSeries31.getItems();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(9);
        long long36 = year35.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean39 = timeSeries38.getNotify();
        long long40 = timeSeries38.getMaximumItemAge();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(9);
        long long43 = year42.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year42, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries31.createCopy((org.jfree.data.time.RegularTimePeriod) year35, (org.jfree.data.time.RegularTimePeriod) year42);
        int int47 = year35.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year35, (double) 1560182620936L);
        boolean boolean50 = fixedMillisecond26.equals((java.lang.Object) year35);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-61883280000000L) + "'", long36 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 9223372036854775807L + "'", long40 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-61867512000001L) + "'", long43 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertNotNull(timeSeries46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 9 + "'", int47 == 9);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        java.lang.String str4 = timeSeries1.getDescription();
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month8, (double) 1559372400000L, false);
        long long12 = month8.getLastMillisecond();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
        java.lang.Class<?> wildcardClass15 = regularTimePeriod14.getClass();
        int int16 = month8.compareTo((java.lang.Object) regularTimePeriod14);
        long long17 = month8.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 0.0d);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        long long21 = month20.getFirstMillisecond();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month20.previous();
        java.lang.Class<?> wildcardClass24 = month20.getClass();
        int int25 = timeSeriesDataItem19.compareTo((java.lang.Object) month20);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean28 = timeSeries27.getNotify();
        java.util.List list29 = timeSeries27.getItems();
        java.lang.String str30 = timeSeries27.getDescription();
        java.lang.String str31 = timeSeries27.getRangeDescription();
        timeSeries27.setDomainDescription("hi!");
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) month34, (double) 1559372400000L, false);
        long long38 = month34.getLastMillisecond();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = month39.previous();
        java.lang.Class<?> wildcardClass41 = regularTimePeriod40.getClass();
        int int42 = month34.compareTo((java.lang.Object) regularTimePeriod40);
        int int43 = month34.getMonth();
        boolean boolean44 = timeSeriesDataItem19.equals((java.lang.Object) month34);
        java.lang.Object obj45 = null;
        boolean boolean46 = timeSeriesDataItem19.equals(obj45);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 24234L + "'", long17 == 24234L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1559372400000L + "'", long21 == 1559372400000L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Value" + "'", str31.equals("Value"));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1561964399999L + "'", long38 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.lang.Object obj2 = null;
        boolean boolean3 = month0.equals(obj2);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean3, "", "Value");
        timeSeries6.removeAgedItems(false);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        long long10 = month9.getFirstMillisecond();
        java.lang.Object obj11 = null;
        boolean boolean12 = month9.equals(obj11);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean12, "", "Value");
        timeSeries15.removeAgedItems((long) (short) 100, false);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(9);
        long long21 = year20.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month23.previous();
        java.lang.Class<?> wildcardClass25 = regularTimePeriod24.getClass();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        long long27 = month26.getFirstMillisecond();
        java.util.Date date28 = month26.getEnd();
        java.util.TimeZone timeZone29 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date28, timeZone29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(date28);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date28);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean35 = timeSeries34.getNotify();
        java.util.List list36 = timeSeries34.getItems();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(9);
        long long39 = year38.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean42 = timeSeries41.getNotify();
        long long43 = timeSeries41.getMaximumItemAge();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(9);
        long long46 = year45.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year45, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) year38, (org.jfree.data.time.RegularTimePeriod) year45);
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
        long long51 = month50.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries49.getDataItem((org.jfree.data.time.RegularTimePeriod) month50);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent54 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj55 = seriesChangeEvent54.getSource();
        java.lang.Object obj56 = seriesChangeEvent54.getSource();
        java.lang.String str57 = seriesChangeEvent54.toString();
        boolean boolean58 = month50.equals((java.lang.Object) str57);
        boolean boolean59 = day32.equals((java.lang.Object) boolean58);
        int int60 = day32.getYear();
        java.lang.String str61 = day32.toString();
        org.jfree.data.time.SerialDate serialDate62 = day32.getSerialDate();
        int int63 = year20.compareTo((java.lang.Object) day32);
        long long64 = day32.getFirstMillisecond();
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day32, (java.lang.Number) 1560182635650L, false);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = timeSeries6.getDataItem((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1559372400000L + "'", long10 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61867512000001L) + "'", long21 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559372400000L + "'", long27 == 1559372400000L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-61883280000000L) + "'", long39 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 9223372036854775807L + "'", long43 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-61867512000001L) + "'", long46 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem48);
        org.junit.Assert.assertNotNull(timeSeries49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1559372400000L + "'", long51 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem52);
        org.junit.Assert.assertTrue("'" + obj55 + "' != '" + 100L + "'", obj55.equals(100L));
        org.junit.Assert.assertTrue("'" + obj56 + "' != '" + 100L + "'", obj56.equals(100L));
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str57.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "30-June-2019" + "'", str61.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1561878000000L + "'", long64 == 1561878000000L);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        java.lang.String str4 = timeSeries1.getDescription();
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month8, (double) 1559372400000L, false);
        long long12 = month8.getLastMillisecond();
        org.jfree.data.time.Year year13 = month8.getYear();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.next();
        java.lang.Class<?> wildcardClass16 = year14.getClass();
        boolean boolean17 = year13.equals((java.lang.Object) year14);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = year14.getFirstMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182599736L);
//        boolean boolean2 = timeSeries1.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean6 = fixedMillisecond4.equals((java.lang.Object) "Value");
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond4.getFirstMillisecond(calendar7);
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond4.peg(calendar9);
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond3.next();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560182674185L + "'", long8 == 1560182674185L);
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.lang.Class<?> wildcardClass2 = regularTimePeriod1.getClass();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        long long4 = month3.getFirstMillisecond();
        java.util.Date date5 = month3.getEnd();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date5, timeZone6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean12 = timeSeries11.getNotify();
        java.util.List list13 = timeSeries11.getItems();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(9);
        long long16 = year15.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean19 = timeSeries18.getNotify();
        long long20 = timeSeries18.getMaximumItemAge();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(9);
        long long23 = year22.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year22, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) year15, (org.jfree.data.time.RegularTimePeriod) year22);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        long long28 = month27.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries26.getDataItem((org.jfree.data.time.RegularTimePeriod) month27);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj32 = seriesChangeEvent31.getSource();
        java.lang.Object obj33 = seriesChangeEvent31.getSource();
        java.lang.String str34 = seriesChangeEvent31.toString();
        boolean boolean35 = month27.equals((java.lang.Object) str34);
        boolean boolean36 = day9.equals((java.lang.Object) boolean35);
        int int37 = day9.getYear();
        java.util.Date date38 = day9.getEnd();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date38);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61883280000000L) + "'", long16 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61867512000001L) + "'", long23 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1559372400000L + "'", long28 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + obj32 + "' != '" + 100L + "'", obj32.equals(100L));
        org.junit.Assert.assertTrue("'" + obj33 + "' != '" + 100L + "'", obj33.equals(100L));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str34.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
        org.junit.Assert.assertNotNull(date38);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, 0.0d);
        int int7 = day4.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate8 = day4.getSerialDate();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 30 + "'", int7 == 30);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries1.setKey((java.lang.Comparable) (-1));
        timeSeries1.setKey((java.lang.Comparable) 8);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean10 = timeSeries9.getNotify();
        java.util.List list11 = timeSeries9.getItems();
        java.lang.String str12 = timeSeries9.getDescription();
        java.lang.String str13 = timeSeries9.getRangeDescription();
        timeSeries9.setDomainDescription("hi!");
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 1559372400000L, false);
        long long20 = month16.getLastMillisecond();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.previous();
        java.lang.Class<?> wildcardClass23 = regularTimePeriod22.getClass();
        int int24 = month16.compareTo((java.lang.Object) regularTimePeriod22);
        long long25 = month16.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month16, (java.lang.Number) 0.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries1.addOrUpdate(timeSeriesDataItem27);
        boolean boolean29 = timeSeries1.getNotify();
        java.lang.Object obj30 = null;
        boolean boolean31 = timeSeries1.equals(obj30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries34 = timeSeries1.createCopy(regularTimePeriod32, regularTimePeriod33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        long long2 = timeSeries1.getMaximumItemAge();
        java.util.Collection collection3 = timeSeries1.getTimePeriods();
        java.lang.Class<?> wildcardClass4 = timeSeries1.getClass();
        try {
            timeSeries1.delete((int) (short) 1, 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        long long4 = month0.getMiddleMillisecond();
        org.jfree.data.time.Year year5 = month0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.previous();
        java.lang.Class<?> wildcardClass3 = regularTimePeriod2.getClass();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        long long5 = month4.getFirstMillisecond();
        java.util.Date date6 = month4.getEnd();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date6, timeZone7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date6);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date6);
        int int11 = year0.compareTo((java.lang.Object) day10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day10.previous();
        long long13 = day10.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        long long16 = timeSeries15.getMaximumItemAge();
        java.util.Collection collection17 = timeSeries15.getTimePeriods();
        int int18 = day10.compareTo((java.lang.Object) collection17);
        int int19 = day10.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561878000000L + "'", long13 == 1561878000000L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = seriesChangeEvent1.getSummary();
        java.lang.String str4 = seriesChangeEvent1.toString();
        java.lang.String str5 = seriesChangeEvent1.toString();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(seriesChangeInfo3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str5.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182599736L);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        long long6 = month5.getFirstMillisecond();
        java.util.Date date7 = month5.getEnd();
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date7, timeZone8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean14 = timeSeries13.getNotify();
        java.util.List list15 = timeSeries13.getItems();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(9);
        long long18 = year17.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean21 = timeSeries20.getNotify();
        long long22 = timeSeries20.getMaximumItemAge();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(9);
        long long25 = year24.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year24, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year24);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        long long30 = month29.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries28.getDataItem((org.jfree.data.time.RegularTimePeriod) month29);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj34 = seriesChangeEvent33.getSource();
        java.lang.Object obj35 = seriesChangeEvent33.getSource();
        java.lang.String str36 = seriesChangeEvent33.toString();
        boolean boolean37 = month29.equals((java.lang.Object) str36);
        boolean boolean38 = day11.equals((java.lang.Object) boolean37);
        int int39 = day11.getYear();
        java.util.Date date40 = day11.getEnd();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month41.previous();
        java.lang.Class<?> wildcardClass43 = regularTimePeriod42.getClass();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
        long long45 = month44.getFirstMillisecond();
        java.util.Date date46 = month44.getEnd();
        java.util.TimeZone timeZone47 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date46, timeZone47);
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond(date46);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date46);
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean53 = timeSeries52.getNotify();
        java.util.List list54 = timeSeries52.getItems();
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(9);
        long long57 = year56.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean60 = timeSeries59.getNotify();
        long long61 = timeSeries59.getMaximumItemAge();
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year(9);
        long long64 = year63.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries59.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year63, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries52.createCopy((org.jfree.data.time.RegularTimePeriod) year56, (org.jfree.data.time.RegularTimePeriod) year63);
        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month();
        long long69 = month68.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries67.getDataItem((org.jfree.data.time.RegularTimePeriod) month68);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent72 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj73 = seriesChangeEvent72.getSource();
        java.lang.Object obj74 = seriesChangeEvent72.getSource();
        java.lang.String str75 = seriesChangeEvent72.toString();
        boolean boolean76 = month68.equals((java.lang.Object) str75);
        boolean boolean77 = day50.equals((java.lang.Object) boolean76);
        boolean boolean79 = day50.equals((java.lang.Object) 1);
        long long80 = day50.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries81 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) day50);
        org.jfree.data.time.SerialDate serialDate82 = day50.getSerialDate();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1559372400000L + "'", long6 == 1559372400000L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-61883280000000L) + "'", long18 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9223372036854775807L + "'", long22 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-61867512000001L) + "'", long25 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1559372400000L + "'", long30 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertTrue("'" + obj34 + "' != '" + 100L + "'", obj34.equals(100L));
        org.junit.Assert.assertTrue("'" + obj35 + "' != '" + 100L + "'", obj35.equals(100L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str36.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1559372400000L + "'", long45 == 1559372400000L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(list54);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-61883280000000L) + "'", long57 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 9223372036854775807L + "'", long61 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-61867512000001L) + "'", long64 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem66);
        org.junit.Assert.assertNotNull(timeSeries67);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1559372400000L + "'", long69 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem70);
        org.junit.Assert.assertTrue("'" + obj73 + "' != '" + 100L + "'", obj73.equals(100L));
        org.junit.Assert.assertTrue("'" + obj74 + "' != '" + 100L + "'", obj74.equals(100L));
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str75.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 43646L + "'", long80 == 43646L);
        org.junit.Assert.assertNotNull(timeSeries81);
        org.junit.Assert.assertNotNull(serialDate82);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year3.previous();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.previous();
        java.lang.Class<?> wildcardClass9 = regularTimePeriod8.getClass();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        long long11 = month10.getFirstMillisecond();
        java.util.Date date12 = month10.getEnd();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date12, timeZone13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date12);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean19 = timeSeries18.getNotify();
        java.util.List list20 = timeSeries18.getItems();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(9);
        long long23 = year22.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean26 = timeSeries25.getNotify();
        long long27 = timeSeries25.getMaximumItemAge();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(9);
        long long30 = year29.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year29, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) year22, (org.jfree.data.time.RegularTimePeriod) year29);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        long long35 = month34.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries33.getDataItem((org.jfree.data.time.RegularTimePeriod) month34);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent38 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj39 = seriesChangeEvent38.getSource();
        java.lang.Object obj40 = seriesChangeEvent38.getSource();
        java.lang.String str41 = seriesChangeEvent38.toString();
        boolean boolean42 = month34.equals((java.lang.Object) str41);
        boolean boolean43 = day16.equals((java.lang.Object) boolean42);
        int int44 = day16.getYear();
        java.util.Date date45 = day16.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day16.previous();
        int int47 = year3.compareTo((java.lang.Object) day16);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
        long long51 = month50.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean54 = timeSeries53.getNotify();
        java.util.List list55 = timeSeries53.getItems();
        java.lang.String str56 = timeSeries53.getDescription();
        java.lang.String str57 = timeSeries53.getRangeDescription();
        timeSeries53.setDomainDescription("hi!");
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month();
        timeSeries53.add((org.jfree.data.time.RegularTimePeriod) month60, (double) 1559372400000L, false);
        long long64 = month60.getLastMillisecond();
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = month65.previous();
        java.lang.Class<?> wildcardClass67 = regularTimePeriod66.getClass();
        int int68 = month60.compareTo((java.lang.Object) regularTimePeriod66);
        long long69 = month60.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = month60.previous();
        boolean boolean72 = month60.equals((java.lang.Object) "org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries49.createCopy((org.jfree.data.time.RegularTimePeriod) month50, (org.jfree.data.time.RegularTimePeriod) month60);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = month50.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = month50.previous();
        boolean boolean76 = day16.equals((java.lang.Object) month50);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month50, (double) 1.0f);
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year(9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem82 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year80, (java.lang.Number) (short) 10);
        boolean boolean83 = timeSeriesDataItem82.isSelected();
        timeSeriesDataItem82.setValue((java.lang.Number) Double.NaN);
        try {
            timeSeries1.add(timeSeriesDataItem82);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1559372400000L + "'", long11 == 1559372400000L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61883280000000L) + "'", long23 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 9223372036854775807L + "'", long27 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-61867512000001L) + "'", long30 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1559372400000L + "'", long35 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + obj39 + "' != '" + 100L + "'", obj39.equals(100L));
        org.junit.Assert.assertTrue("'" + obj40 + "' != '" + 100L + "'", obj40.equals(100L));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str41.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1559372400000L + "'", long51 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(list55);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Value" + "'", str57.equals("Value"));
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1561964399999L + "'", long64 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 24234L + "'", long69 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(timeSeries73);
        org.junit.Assert.assertNotNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        java.lang.String str4 = timeSeries1.getDescription();
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.lang.Comparable comparable6 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        long long10 = month9.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean13 = timeSeries12.getNotify();
        java.util.List list14 = timeSeries12.getItems();
        java.lang.String str15 = timeSeries12.getDescription();
        java.lang.String str16 = timeSeries12.getRangeDescription();
        timeSeries12.setDomainDescription("hi!");
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) month19, (double) 1559372400000L, false);
        long long23 = month19.getLastMillisecond();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month24.previous();
        java.lang.Class<?> wildcardClass26 = regularTimePeriod25.getClass();
        int int27 = month19.compareTo((java.lang.Object) regularTimePeriod25);
        long long28 = month19.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month19.previous();
        boolean boolean31 = month19.equals((java.lang.Object) "org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) month9, (org.jfree.data.time.RegularTimePeriod) month19);
        java.lang.Number number33 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month19);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 100.0f + "'", comparable6.equals(100.0f));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1559372400000L + "'", long10 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Value" + "'", str16.equals("Value"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1561964399999L + "'", long23 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 24234L + "'", long28 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertNull(number33);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.lang.Object obj2 = null;
        boolean boolean3 = month0.equals(obj2);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean3, "", "Value");
        boolean boolean7 = timeSeries6.isEmpty();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        long long9 = month8.getFirstMillisecond();
        java.lang.Object obj10 = null;
        boolean boolean11 = month8.equals(obj10);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean11, "", "Value");
        timeSeries14.removeAgedItems((long) (short) 100, false);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(9);
        long long20 = year19.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) year19);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month22.previous();
        java.lang.Class<?> wildcardClass24 = regularTimePeriod23.getClass();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        long long26 = month25.getFirstMillisecond();
        java.util.Date date27 = month25.getEnd();
        java.util.TimeZone timeZone28 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date27, timeZone28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond(date27);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date27);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean34 = timeSeries33.getNotify();
        java.util.List list35 = timeSeries33.getItems();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(9);
        long long38 = year37.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean41 = timeSeries40.getNotify();
        long long42 = timeSeries40.getMaximumItemAge();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(9);
        long long45 = year44.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year44, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) year37, (org.jfree.data.time.RegularTimePeriod) year44);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
        long long50 = month49.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries48.getDataItem((org.jfree.data.time.RegularTimePeriod) month49);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent53 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj54 = seriesChangeEvent53.getSource();
        java.lang.Object obj55 = seriesChangeEvent53.getSource();
        java.lang.String str56 = seriesChangeEvent53.toString();
        boolean boolean57 = month49.equals((java.lang.Object) str56);
        boolean boolean58 = day31.equals((java.lang.Object) boolean57);
        int int59 = day31.getYear();
        java.lang.String str60 = day31.toString();
        org.jfree.data.time.SerialDate serialDate61 = day31.getSerialDate();
        int int62 = year19.compareTo((java.lang.Object) day31);
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = year64.previous();
        java.util.Date date66 = year64.getStart();
        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) day31, (org.jfree.data.time.RegularTimePeriod) year64);
        int int68 = day31.getYear();
        java.util.Calendar calendar69 = null;
        try {
            day31.peg(calendar69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559372400000L + "'", long9 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61867512000001L) + "'", long20 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1559372400000L + "'", long26 == 1559372400000L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-61883280000000L) + "'", long38 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 9223372036854775807L + "'", long42 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-61867512000001L) + "'", long45 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1559372400000L + "'", long50 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertTrue("'" + obj54 + "' != '" + 100L + "'", obj54.equals(100L));
        org.junit.Assert.assertTrue("'" + obj55 + "' != '" + 100L + "'", obj55.equals(100L));
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str56.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "30-June-2019" + "'", str60.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(timeSeries67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 2019 + "'", int68 == 2019);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.previous();
        java.lang.Class<?> wildcardClass3 = regularTimePeriod2.getClass();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        long long5 = month4.getFirstMillisecond();
        java.util.Date date6 = month4.getEnd();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date6, timeZone7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date6);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date6);
        int int11 = year0.compareTo((java.lang.Object) day10);
        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate12);
        int int15 = day14.getDayOfMonth();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean18 = timeSeries17.getNotify();
        java.util.List list19 = timeSeries17.getItems();
        boolean boolean20 = day14.equals((java.lang.Object) timeSeries17);
        java.lang.String str21 = day14.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 30 + "'", int15 == 30);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "30-June-2019" + "'", str21.equals("30-June-2019"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean5 = timeSeries4.getNotify();
        long long6 = timeSeries4.getMaximumItemAge();
        java.util.Collection collection7 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean10 = timeSeries9.getNotify();
        long long11 = timeSeries9.getMaximumItemAge();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year13, 0.0d);
        long long16 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year13, (double) 9L);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        long long23 = month22.getFirstMillisecond();
        java.lang.Object obj24 = null;
        boolean boolean25 = month22.equals(obj24);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean25, "", "Value");
        long long29 = timeSeries28.getMaximumItemAge();
        boolean boolean31 = timeSeries28.equals((java.lang.Object) 1L);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries1.addAndOrUpdate(timeSeries28);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
        timeSeries32.addChangeListener(seriesChangeListener33);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries32.addChangeListener(seriesChangeListener35);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62135740800000L) + "'", long16 == (-62135740800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1559372400000L + "'", long23 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 9223372036854775807L + "'", long29 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(timeSeries32);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        long long3 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, 0.0d);
        java.lang.Comparable comparable8 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean11 = timeSeries10.getNotify();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean14 = timeSeries13.getNotify();
        long long15 = timeSeries13.getMaximumItemAge();
        java.util.Collection collection16 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.addAndOrUpdate(timeSeries13);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        long long19 = month18.getFirstMillisecond();
        java.lang.Object obj20 = null;
        boolean boolean21 = month18.equals(obj20);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean21, "", "Value");
        timeSeries24.removeAgedItems((long) (short) 100, false);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(9);
        long long30 = year29.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries24.getDataItem((org.jfree.data.time.RegularTimePeriod) year29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year29, (double) 2147483647);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year29.previous();
        java.util.Calendar calendar35 = null;
        try {
            year29.peg(calendar35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0f + "'", comparable8.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1559372400000L + "'", long19 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-61867512000001L) + "'", long30 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        long long6 = timeSeries5.getMaximumItemAge();
        java.util.Collection collection7 = timeSeries5.getTimePeriods();
        java.util.Collection collection8 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        boolean boolean9 = timeSeries5.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean5 = timeSeries4.getNotify();
        long long6 = timeSeries4.getMaximumItemAge();
        java.util.Collection collection7 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean10 = timeSeries9.getNotify();
        java.util.List list11 = timeSeries9.getItems();
        java.lang.String str12 = timeSeries9.getDescription();
        java.lang.String str13 = timeSeries9.getRangeDescription();
        timeSeries9.setDomainDescription("hi!");
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 1559372400000L, false);
        long long20 = month16.getLastMillisecond();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.previous();
        java.lang.Class<?> wildcardClass23 = regularTimePeriod22.getClass();
        int int24 = month16.compareTo((java.lang.Object) regularTimePeriod22);
        long long25 = month16.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month16.previous();
        java.lang.Number number27 = null;
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month16, number27);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries4.addChangeListener(seriesChangeListener29);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month31.previous();
        java.lang.Class<?> wildcardClass33 = regularTimePeriod32.getClass();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        long long35 = month34.getFirstMillisecond();
        java.util.Date date36 = month34.getEnd();
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date36, timeZone37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(date36);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean43 = timeSeries42.getNotify();
        java.util.List list44 = timeSeries42.getItems();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(9);
        long long47 = year46.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean50 = timeSeries49.getNotify();
        long long51 = timeSeries49.getMaximumItemAge();
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(9);
        long long54 = year53.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries49.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year53, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries42.createCopy((org.jfree.data.time.RegularTimePeriod) year46, (org.jfree.data.time.RegularTimePeriod) year53);
        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month();
        long long59 = month58.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries57.getDataItem((org.jfree.data.time.RegularTimePeriod) month58);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent62 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj63 = seriesChangeEvent62.getSource();
        java.lang.Object obj64 = seriesChangeEvent62.getSource();
        java.lang.String str65 = seriesChangeEvent62.toString();
        boolean boolean66 = month58.equals((java.lang.Object) str65);
        boolean boolean67 = day40.equals((java.lang.Object) boolean66);
        int int68 = day40.getYear();
        java.util.Date date69 = day40.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = day40.next();
        java.lang.Number number71 = null;
        timeSeries4.update((org.jfree.data.time.RegularTimePeriod) day40, number71);
        org.jfree.data.time.Month month73 = new org.jfree.data.time.Month();
        long long74 = month73.getFirstMillisecond();
        java.lang.Object obj75 = null;
        boolean boolean76 = month73.equals(obj75);
        org.jfree.data.time.TimeSeries timeSeries79 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean76, "", "Value");
        org.jfree.data.time.FixedMillisecond fixedMillisecond80 = new org.jfree.data.time.FixedMillisecond();
        timeSeries79.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond80, (double) 2019, false);
        java.lang.Object obj84 = null;
        boolean boolean85 = fixedMillisecond80.equals(obj84);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem87 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond80, (double) 1560182635650L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1559372400000L + "'", long35 == 1559372400000L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-61883280000000L) + "'", long47 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 9223372036854775807L + "'", long51 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-61867512000001L) + "'", long54 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem56);
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1559372400000L + "'", long59 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem60);
        org.junit.Assert.assertTrue("'" + obj63 + "' != '" + 100L + "'", obj63.equals(100L));
        org.junit.Assert.assertTrue("'" + obj64 + "' != '" + 100L + "'", obj64.equals(100L));
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str65.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 2019 + "'", int68 == 2019);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 1559372400000L + "'", long74 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        long long5 = day4.getSerialIndex();
        int int6 = day4.getMonth();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43646L + "'", long5 == 43646L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        long long2 = timeSeries1.getMaximumItemAge();
        java.lang.Object obj3 = null;
        boolean boolean4 = timeSeries1.equals(obj3);
        boolean boolean5 = timeSeries1.isEmpty();
        timeSeries1.setMaximumItemAge((long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182599736L);
//        boolean boolean2 = timeSeries1.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean6 = fixedMillisecond4.equals((java.lang.Object) "Value");
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond4.getFirstMillisecond(calendar7);
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond4.peg(calendar9);
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
//        timeSeries1.setDescription("Wed Dec 31 16:00:00 PST 1969");
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) (short) 10);
//        boolean boolean18 = timeSeriesDataItem17.isSelected();
//        timeSeriesDataItem17.setValue((java.lang.Number) (byte) 10);
//        timeSeriesDataItem17.setSelected(false);
//        timeSeries1.add(timeSeriesDataItem17);
//        java.lang.Object obj24 = timeSeries1.clone();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        boolean boolean27 = timeSeries26.getNotify();
//        java.util.List list28 = timeSeries26.getItems();
//        java.lang.String str29 = timeSeries26.getDescription();
//        java.lang.String str30 = timeSeries26.getRangeDescription();
//        timeSeries26.setDomainDescription("hi!");
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) month33, (double) 1559372400000L, false);
//        long long37 = month33.getLastMillisecond();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month38.previous();
//        java.lang.Class<?> wildcardClass40 = regularTimePeriod39.getClass();
//        int int41 = month33.compareTo((java.lang.Object) regularTimePeriod39);
//        long long42 = month33.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month33, (java.lang.Number) 0.0d);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
//        int int47 = timeSeriesDataItem44.compareTo((java.lang.Object) fixedMillisecond46);
//        java.util.Date date48 = fixedMillisecond46.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem49, "Mon Jun 10 09:04:07 PDT 2019", "Mon Jun 10 09:03:37 PDT 2019");
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560182676488L + "'", long8 == 1560182676488L);
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(obj24);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertNotNull(list28);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Value" + "'", str30.equals("Value"));
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1561964399999L + "'", long37 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(wildcardClass40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 24234L + "'", long42 == 24234L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem49);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean5 = timeSeries4.getNotify();
        long long6 = timeSeries4.getMaximumItemAge();
        java.util.Collection collection7 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean10 = timeSeries9.getNotify();
        java.util.List list11 = timeSeries9.getItems();
        java.lang.String str12 = timeSeries9.getDescription();
        java.lang.String str13 = timeSeries9.getRangeDescription();
        timeSeries9.setDomainDescription("hi!");
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 1559372400000L, false);
        long long20 = month16.getLastMillisecond();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.previous();
        java.lang.Class<?> wildcardClass23 = regularTimePeriod22.getClass();
        int int24 = month16.compareTo((java.lang.Object) regularTimePeriod22);
        long long25 = month16.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month16.previous();
        java.lang.Number number27 = null;
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month16, number27);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries4.addChangeListener(seriesChangeListener29);
        java.lang.String str31 = timeSeries4.getRangeDescription();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Value" + "'", str31.equals("Value"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.lang.Object obj2 = null;
        boolean boolean3 = month0.equals(obj2);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean3, "", "Value");
        boolean boolean7 = timeSeries6.isEmpty();
        timeSeries6.setDescription("");
        timeSeries6.setDescription("Value");
        java.lang.Comparable comparable12 = timeSeries6.getKey();
        timeSeries6.setDescription("Mon Jun 10 09:03:32 PDT 2019");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + false + "'", comparable12.equals(false));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        long long3 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, 0.0d);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 5);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 1560182596196L);
        java.lang.String str12 = fixedMillisecond9.toString();
        long long13 = fixedMillisecond9.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond9.next();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str12.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 5L + "'", long13 == 5L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.lang.Object obj2 = null;
        boolean boolean3 = month0.equals(obj2);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean3, "", "Value");
        boolean boolean7 = timeSeries6.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener8);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        long long3 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, 0.0d);
        java.lang.Comparable comparable8 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean11 = timeSeries10.getNotify();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean14 = timeSeries13.getNotify();
        long long15 = timeSeries13.getMaximumItemAge();
        java.util.Collection collection16 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.addAndOrUpdate(timeSeries13);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        long long19 = month18.getFirstMillisecond();
        java.lang.Object obj20 = null;
        boolean boolean21 = month18.equals(obj20);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean21, "", "Value");
        timeSeries24.removeAgedItems((long) (short) 100, false);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(9);
        long long30 = year29.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries24.getDataItem((org.jfree.data.time.RegularTimePeriod) year29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year29, (double) 2147483647);
        long long34 = timeSeries13.getMaximumItemAge();
        int int35 = timeSeries13.getMaximumItemCount();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener36 = null;
        timeSeries13.addChangeListener(seriesChangeListener36);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0f + "'", comparable8.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1559372400000L + "'", long19 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-61867512000001L) + "'", long30 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 9223372036854775807L + "'", long34 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2147483647 + "'", int35 == 2147483647);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        long long3 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, 0.0d);
        boolean boolean9 = timeSeries1.equals((java.lang.Object) (byte) 100);
        java.lang.String str10 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
        java.lang.String str2 = seriesException1.toString();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("Value");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries8.setKey((java.lang.Comparable) (-1));
        timeSeries8.setKey((java.lang.Comparable) 8);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries8.addChangeListener(seriesChangeListener13);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean17 = timeSeries16.getNotify();
        java.util.List list18 = timeSeries16.getItems();
        java.lang.String str19 = timeSeries16.getDescription();
        java.lang.String str20 = timeSeries16.getRangeDescription();
        timeSeries16.setDomainDescription("hi!");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) month23, (double) 1559372400000L, false);
        long long27 = month23.getLastMillisecond();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month28.previous();
        java.lang.Class<?> wildcardClass30 = regularTimePeriod29.getClass();
        int int31 = month23.compareTo((java.lang.Object) regularTimePeriod29);
        long long32 = month23.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month23, (java.lang.Number) 0.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries8.addOrUpdate(timeSeriesDataItem34);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year37, (java.lang.Number) (short) 10);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year41, (java.lang.Number) (short) 10);
        timeSeriesDataItem43.setSelected(true);
        int int46 = timeSeriesDataItem39.compareTo((java.lang.Object) true);
        int int47 = timeSeriesDataItem34.compareTo((java.lang.Object) timeSeriesDataItem39);
        java.lang.Object obj48 = timeSeriesDataItem39.clone();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(9);
        long long51 = year50.getMiddleMillisecond();
        long long52 = year50.getSerialIndex();
        org.jfree.data.general.SeriesException seriesException54 = new org.jfree.data.general.SeriesException("");
        boolean boolean55 = year50.equals((java.lang.Object) seriesException54);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException57 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        seriesException54.addSuppressed((java.lang.Throwable) timePeriodFormatException57);
        int int59 = timeSeriesDataItem39.compareTo((java.lang.Object) seriesException54);
        seriesException5.addSuppressed((java.lang.Throwable) seriesException54);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: Value" + "'", str2.equals("org.jfree.data.general.SeriesException: Value"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Value" + "'", str20.equals("Value"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 24234L + "'", long32 == 24234L);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-61867512000001L) + "'", long51 == (-61867512000001L));
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 9L + "'", long52 == 9L);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.previous();
        java.lang.Class<?> wildcardClass3 = regularTimePeriod2.getClass();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        long long5 = month4.getFirstMillisecond();
        java.util.Date date6 = month4.getEnd();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date6, timeZone7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date6);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date6);
        int int11 = year0.compareTo((java.lang.Object) day10);
        long long12 = year0.getMiddleMillisecond();
        int int13 = year0.getYear();
        long long14 = year0.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean2 = fixedMillisecond0.equals((java.lang.Object) "Value");
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getFirstMillisecond(calendar3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond0.next();
//        long long6 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560182677125L + "'", long4 == 1560182677125L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560182677125L + "'", long6 == 1560182677125L);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.lang.Class<?> wildcardClass2 = regularTimePeriod1.getClass();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        long long4 = month3.getFirstMillisecond();
        java.util.Date date5 = month3.getEnd();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date5, timeZone6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date5);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond8.getFirstMillisecond(calendar11);
        long long13 = fixedMillisecond8.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.lang.Class<?> wildcardClass2 = regularTimePeriod1.getClass();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        long long4 = month3.getFirstMillisecond();
        java.util.Date date5 = month3.getEnd();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date5, timeZone6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date5);
        java.util.Date date9 = fixedMillisecond8.getEnd();
        java.util.TimeZone timeZone10 = null;
        try {
            org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date9, timeZone10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.String str4 = seriesChangeEvent1.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = seriesChangeEvent1.getSummary();
        java.lang.String str6 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 100L + "'", obj2.equals(100L));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 100L + "'", obj3.equals(100L));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertNull(seriesChangeInfo5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str6.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(9);
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean9 = timeSeries8.getNotify();
        long long10 = timeSeries8.getMaximumItemAge();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(9);
        long long13 = year12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year5, (org.jfree.data.time.RegularTimePeriod) year12);
        timeSeries16.fireSeriesChanged();
        java.lang.Object obj18 = timeSeries16.clone();
        try {
            timeSeries16.update((int) (byte) 100, (java.lang.Number) 1560182669359L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61883280000000L) + "'", long6 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61867512000001L) + "'", long13 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        java.lang.String str4 = timeSeries1.getDescription();
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.lang.String str6 = timeSeries1.getDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries1.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        java.lang.Class<?> wildcardClass12 = regularTimePeriod11.getClass();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        long long14 = month13.getFirstMillisecond();
        java.util.Date date15 = month13.getEnd();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date15, timeZone16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date15);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date15);
        int int20 = year9.compareTo((java.lang.Object) day19);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (-1L));
        timeSeries1.fireSeriesChanged();
        java.lang.String str24 = timeSeries1.getDomainDescription();
        timeSeries1.setDomainDescription("Wed Dec 31 16:00:00 PST 1969");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1559372400000L + "'", long14 == 1559372400000L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Time" + "'", str24.equals("Time"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        long long3 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, 0.0d);
        java.lang.Comparable comparable8 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean11 = timeSeries10.getNotify();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean14 = timeSeries13.getNotify();
        long long15 = timeSeries13.getMaximumItemAge();
        java.util.Collection collection16 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.addAndOrUpdate(timeSeries13);
        java.util.List list18 = timeSeries1.getItems();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        long long20 = month19.getFirstMillisecond();
        java.lang.Object obj21 = null;
        boolean boolean22 = month19.equals(obj21);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean22, "", "Value");
        boolean boolean26 = timeSeries25.isEmpty();
        timeSeries25.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean31 = timeSeries30.getNotify();
        java.util.List list32 = timeSeries30.getItems();
        java.lang.String str33 = timeSeries30.getDescription();
        java.lang.String str34 = timeSeries30.getRangeDescription();
        timeSeries30.setDomainDescription("hi!");
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        timeSeries30.add((org.jfree.data.time.RegularTimePeriod) month37, (double) 1559372400000L, false);
        long long41 = month37.getLastMillisecond();
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = month42.previous();
        java.lang.Class<?> wildcardClass44 = regularTimePeriod43.getClass();
        int int45 = month37.compareTo((java.lang.Object) regularTimePeriod43);
        long long46 = month37.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month37, (java.lang.Number) 0.0d);
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        int int51 = timeSeriesDataItem48.compareTo((java.lang.Object) fixedMillisecond50);
        timeSeries25.add(timeSeriesDataItem48);
        timeSeriesDataItem48.setValue((java.lang.Number) 2);
        try {
            timeSeries1.add(timeSeriesDataItem48);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0f + "'", comparable8.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1559372400000L + "'", long20 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Value" + "'", str34.equals("Value"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1561964399999L + "'", long41 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 24234L + "'", long46 == 24234L);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        long long3 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, 0.0d);
        java.lang.Comparable comparable8 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean11 = timeSeries10.getNotify();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean14 = timeSeries13.getNotify();
        long long15 = timeSeries13.getMaximumItemAge();
        java.util.Collection collection16 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.addAndOrUpdate(timeSeries13);
        java.lang.Class class18 = timeSeries13.getTimePeriodClass();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.previous();
        long long21 = month19.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) (-62135740800000L));
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean26 = timeSeries25.getNotify();
        java.util.List list27 = timeSeries25.getItems();
        boolean boolean28 = timeSeriesDataItem23.equals((java.lang.Object) list27);
        timeSeries13.setKey((java.lang.Comparable) boolean28);
        timeSeries13.fireSeriesChanged();
        timeSeries13.setMaximumItemAge(1560182669587L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0f + "'", comparable8.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1559372400000L + "'", long21 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        java.lang.String str4 = timeSeries1.getDescription();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.Year year7 = month5.getYear();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(year7);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.util.List list3 = timeSeries1.getItems();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(9);
//        long long6 = year5.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        boolean boolean9 = timeSeries8.getNotify();
//        long long10 = timeSeries8.getMaximumItemAge();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(9);
//        long long13 = year12.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year5, (org.jfree.data.time.RegularTimePeriod) year12);
//        timeSeries16.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        boolean boolean20 = timeSeries19.getNotify();
//        long long21 = timeSeries19.getMaximumItemAge();
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) (short) 1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year23, 0.0d);
//        java.lang.Comparable comparable26 = timeSeries19.getKey();
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        boolean boolean29 = timeSeries28.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        boolean boolean32 = timeSeries31.getNotify();
//        long long33 = timeSeries31.getMaximumItemAge();
//        java.util.Collection collection34 = timeSeries28.getTimePeriodsUniqueToOtherSeries(timeSeries31);
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries19.addAndOrUpdate(timeSeries31);
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
//        long long37 = month36.getFirstMillisecond();
//        java.lang.Object obj38 = null;
//        boolean boolean39 = month36.equals(obj38);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean39, "", "Value");
//        timeSeries42.removeAgedItems((long) (short) 100, false);
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(9);
//        long long48 = year47.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries42.getDataItem((org.jfree.data.time.RegularTimePeriod) year47);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year47, (double) 2147483647);
//        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries16.addAndOrUpdate(timeSeries31);
//        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
//        long long54 = month53.getFirstMillisecond();
//        java.lang.Object obj55 = null;
//        boolean boolean56 = month53.equals(obj55);
//        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean56, "", "Value");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries59.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60, (double) 2019, false);
//        java.lang.Object obj64 = null;
//        boolean boolean65 = fixedMillisecond60.equals(obj64);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries52.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60, (java.lang.Number) 2147483647);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond();
//        long long69 = fixedMillisecond68.getMiddleMillisecond();
//        java.util.Date date70 = fixedMillisecond68.getStart();
//        timeSeries52.setKey((java.lang.Comparable) fixedMillisecond68);
//        timeSeries52.setNotify(false);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(list3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61883280000000L) + "'", long6 == (-61883280000000L));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61867512000001L) + "'", long13 == (-61867512000001L));
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertTrue("'" + comparable26 + "' != '" + 100.0f + "'", comparable26.equals(100.0f));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775807L + "'", long33 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(collection34);
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1559372400000L + "'", long37 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-61867512000001L) + "'", long48 == (-61867512000001L));
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNull(timeSeriesDataItem51);
//        org.junit.Assert.assertNotNull(timeSeries52);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1559372400000L + "'", long54 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem67);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1560182677405L + "'", long69 == 1560182677405L);
//        org.junit.Assert.assertNotNull(date70);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.lang.Object obj2 = null;
        boolean boolean3 = month0.equals(obj2);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean3, "", "Value");
        timeSeries6.removeAgedItems((long) (short) 100, false);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(9);
        long long12 = year11.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) year11);
        java.lang.Object obj14 = null;
        int int15 = year11.compareTo(obj14);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61867512000001L) + "'", long12 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.util.Date date2 = regularTimePeriod1.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        java.util.TimeZone timeZone5 = null;
        java.util.Locale locale6 = null;
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date2, timeZone5, locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean5 = timeSeries4.getNotify();
        long long6 = timeSeries4.getMaximumItemAge();
        java.util.Collection collection7 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean10 = timeSeries9.getNotify();
        long long11 = timeSeries9.getMaximumItemAge();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year13, 0.0d);
        long long16 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year13, (double) 9L);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean24 = timeSeries23.getNotify();
        java.util.List list25 = timeSeries23.getItems();
        java.lang.String str26 = timeSeries23.getDescription();
        java.lang.String str27 = timeSeries23.getRangeDescription();
        timeSeries23.setDomainDescription("hi!");
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) month30, (double) 1559372400000L, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month30, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month37.previous();
        java.lang.Class<?> wildcardClass39 = regularTimePeriod38.getClass();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
        long long41 = month40.getFirstMillisecond();
        java.util.Date date42 = month40.getEnd();
        java.util.TimeZone timeZone43 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date42, timeZone43);
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond(date42);
        java.util.Calendar calendar46 = null;
        long long47 = fixedMillisecond45.getFirstMillisecond(calendar46);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond45);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
        long long50 = month49.getFirstMillisecond();
        java.util.Date date51 = month49.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond(date51);
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date51);
        timeSeries48.add((org.jfree.data.time.RegularTimePeriod) day53, (java.lang.Number) 10.0f, true);
        org.jfree.data.time.SerialDate serialDate57 = day53.getSerialDate();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day53);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62135740800000L) + "'", long16 == (-62135740800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Value" + "'", str27.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1559372400000L + "'", long41 == 1559372400000L);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1561964399999L + "'", long47 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1559372400000L + "'", long50 == 1559372400000L);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(timeSeriesDataItem58);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.lang.Class<?> wildcardClass2 = regularTimePeriod1.getClass();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        long long4 = month3.getFirstMillisecond();
        java.util.Date date5 = month3.getEnd();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date5, timeZone6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean12 = timeSeries11.getNotify();
        java.util.List list13 = timeSeries11.getItems();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(9);
        long long16 = year15.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean19 = timeSeries18.getNotify();
        long long20 = timeSeries18.getMaximumItemAge();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(9);
        long long23 = year22.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year22, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) year15, (org.jfree.data.time.RegularTimePeriod) year22);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        long long28 = month27.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries26.getDataItem((org.jfree.data.time.RegularTimePeriod) month27);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj32 = seriesChangeEvent31.getSource();
        java.lang.Object obj33 = seriesChangeEvent31.getSource();
        java.lang.String str34 = seriesChangeEvent31.toString();
        boolean boolean35 = month27.equals((java.lang.Object) str34);
        boolean boolean36 = day9.equals((java.lang.Object) boolean35);
        boolean boolean38 = day9.equals((java.lang.Object) 1);
        boolean boolean40 = day9.equals((java.lang.Object) 1560182615319L);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61883280000000L) + "'", long16 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61867512000001L) + "'", long23 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1559372400000L + "'", long28 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + obj32 + "' != '" + 100L + "'", obj32.equals(100L));
        org.junit.Assert.assertTrue("'" + obj33 + "' != '" + 100L + "'", obj33.equals(100L));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str34.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.lang.Class<?> wildcardClass2 = regularTimePeriod1.getClass();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        long long4 = month3.getFirstMillisecond();
        java.util.Date date5 = month3.getEnd();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date5, timeZone6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date5);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getFirstMillisecond(calendar9);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond8);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        long long13 = month12.getFirstMillisecond();
        java.util.Date date14 = month12.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14);
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 10.0f, true);
        timeSeries11.setMaximumItemAge(1L);
        java.lang.String str22 = timeSeries11.getDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1559372400000L + "'", long13 == 1559372400000L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.lang.Class<?> wildcardClass2 = regularTimePeriod1.getClass();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        long long4 = month3.getFirstMillisecond();
        java.util.Date date5 = month3.getEnd();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date5, timeZone6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.previous();
        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        long long15 = month14.getFirstMillisecond();
        java.util.Date date16 = month14.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date16, timeZone17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date16);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date16);
        int int21 = year10.compareTo((java.lang.Object) day20);
        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
        int int23 = day9.compareTo((java.lang.Object) day20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day20.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1559372400000L + "'", long15 == 1559372400000L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        java.lang.String str4 = timeSeries1.getDescription();
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.lang.String str6 = timeSeries1.getDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries1.addChangeListener(seriesChangeListener7);
        java.lang.Comparable comparable9 = timeSeries1.getKey();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100.0f + "'", comparable9.equals(100.0f));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, 0.0d);
        long long7 = day4.getFirstMillisecond();
        java.util.Date date8 = day4.getStart();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = day9.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561878000000L + "'", long7 == 1561878000000L);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) (short) 10);
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        timeSeriesDataItem3.setValue((java.lang.Number) Double.NaN);
        boolean boolean7 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean10 = timeSeries9.getNotify();
        java.util.List list11 = timeSeries9.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(9);
        long long14 = year13.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean17 = timeSeries16.getNotify();
        long long18 = timeSeries16.getMaximumItemAge();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(9);
        long long21 = year20.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year20, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) year13, (org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        long long26 = month25.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries24.getDataItem((org.jfree.data.time.RegularTimePeriod) month25);
        java.lang.String str28 = timeSeries24.getRangeDescription();
        java.lang.Class<?> wildcardClass29 = timeSeries24.getClass();
        boolean boolean30 = timeSeriesDataItem3.equals((java.lang.Object) wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61883280000000L) + "'", long14 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61867512000001L) + "'", long21 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1559372400000L + "'", long26 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Value" + "'", str28.equals("Value"));
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        long long3 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, 0.0d);
        java.lang.Comparable comparable8 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean11 = timeSeries10.getNotify();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean14 = timeSeries13.getNotify();
        long long15 = timeSeries13.getMaximumItemAge();
        java.util.Collection collection16 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.addAndOrUpdate(timeSeries13);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.next();
        long long20 = year18.getMiddleMillisecond();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (-1.0f));
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean25 = timeSeries24.getNotify();
        java.util.List list26 = timeSeries24.getItems();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(9);
        long long29 = year28.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean32 = timeSeries31.getNotify();
        long long33 = timeSeries31.getMaximumItemAge();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(9);
        long long36 = year35.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year35, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) year28, (org.jfree.data.time.RegularTimePeriod) year35);
        timeSeries39.setKey((java.lang.Comparable) (short) 10);
        java.beans.PropertyChangeListener propertyChangeListener42 = null;
        timeSeries39.addPropertyChangeListener(propertyChangeListener42);
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries1.addAndOrUpdate(timeSeries39);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        long long47 = timeSeries46.getMaximumItemAge();
        java.util.Collection collection48 = timeSeries46.getTimePeriods();
        timeSeries46.setDomainDescription("Value");
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries44.addAndOrUpdate(timeSeries46);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0f + "'", comparable8.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1562097599999L + "'", long20 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61883280000000L) + "'", long29 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775807L + "'", long33 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-61867512000001L) + "'", long36 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 9223372036854775807L + "'", long47 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection48);
        org.junit.Assert.assertNotNull(timeSeries51);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.util.Date date2 = month0.getEnd();
        long long3 = month0.getSerialIndex();
        java.lang.String str4 = month0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        long long3 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, 0.0d);
        long long8 = year5.getFirstMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        long long10 = month9.getFirstMillisecond();
        java.lang.Object obj11 = null;
        boolean boolean12 = month9.equals(obj11);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean12, "", "Value");
        boolean boolean16 = timeSeries15.isEmpty();
        timeSeries15.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean21 = timeSeries20.getNotify();
        java.util.List list22 = timeSeries20.getItems();
        java.lang.String str23 = timeSeries20.getDescription();
        java.lang.String str24 = timeSeries20.getRangeDescription();
        timeSeries20.setDomainDescription("hi!");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) month27, (double) 1559372400000L, false);
        long long31 = month27.getLastMillisecond();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month32.previous();
        java.lang.Class<?> wildcardClass34 = regularTimePeriod33.getClass();
        int int35 = month27.compareTo((java.lang.Object) regularTimePeriod33);
        long long36 = month27.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) 0.0d);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        int int41 = timeSeriesDataItem38.compareTo((java.lang.Object) fixedMillisecond40);
        timeSeries15.add(timeSeriesDataItem38);
        boolean boolean43 = year5.equals((java.lang.Object) timeSeries15);
        java.lang.Comparable comparable44 = timeSeries15.getKey();
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        long long46 = month45.getFirstMillisecond();
        java.lang.Object obj47 = null;
        boolean boolean48 = month45.equals(obj47);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean48, "", "Value");
        timeSeries51.removeAgedItems((long) (short) 100, false);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(9);
        long long57 = year56.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries51.getDataItem((org.jfree.data.time.RegularTimePeriod) year56);
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries15.addAndOrUpdate(timeSeries51);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries51.getDataItem((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62135740800000L) + "'", long8 == (-62135740800000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1559372400000L + "'", long10 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Value" + "'", str24.equals("Value"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1561964399999L + "'", long31 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 24234L + "'", long36 == 24234L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + comparable44 + "' != '" + false + "'", comparable44.equals(false));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1559372400000L + "'", long46 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-61867512000001L) + "'", long57 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem58);
        org.junit.Assert.assertNotNull(timeSeries59);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        long long3 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, 0.0d);
        long long8 = year5.getFirstMillisecond();
        int int10 = year5.compareTo((java.lang.Object) 3);
        long long11 = year5.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62135740800000L) + "'", long8 == (-62135740800000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62119972800001L) + "'", long11 == (-62119972800001L));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries1.setKey((java.lang.Comparable) (-1));
        timeSeries1.setKey((java.lang.Comparable) 8);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries9.setKey((java.lang.Comparable) (-1));
        timeSeries9.setKey((java.lang.Comparable) 8);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries9.addChangeListener(seriesChangeListener14);
        double double16 = timeSeries9.getMinY();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.addAndOrUpdate(timeSeries9);
        boolean boolean18 = timeSeries1.isEmpty();
        timeSeries1.setDomainDescription("org.jfree.data.general.SeriesException: org.jfree.data.event.SeriesChangeEvent[source=true]");
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        java.lang.String str4 = timeSeries1.getDescription();
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean10 = timeSeries9.getNotify();
        java.util.List list11 = timeSeries9.getItems();
        java.lang.String str12 = timeSeries9.getDescription();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        long long14 = month13.getFirstMillisecond();
        java.util.Date date15 = month13.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
        int int17 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries1.addAndOrUpdate(timeSeries9);
        try {
            timeSeries18.delete(2019, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1559372400000L + "'", long14 == 1559372400000L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(timeSeries18);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        java.lang.String str4 = timeSeries1.getDescription();
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month8, (double) 1559372400000L, false);
        long long12 = month8.getLastMillisecond();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
        java.lang.Class<?> wildcardClass15 = regularTimePeriod14.getClass();
        int int16 = month8.compareTo((java.lang.Object) regularTimePeriod14);
        long long17 = month8.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 0.0d);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        int int22 = timeSeriesDataItem19.compareTo((java.lang.Object) fixedMillisecond21);
        java.util.Date date23 = fixedMillisecond21.getEnd();
        java.util.TimeZone timeZone24 = null;
        java.util.Locale locale25 = null;
        try {
            org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date23, timeZone24, locale25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 24234L + "'", long17 == 24234L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(date23);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Mon Jun 10 09:03:38 PDT 2019");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getFirstMillisecond();
//        java.lang.Object obj2 = null;
//        boolean boolean3 = month0.equals(obj2);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean3, "", "Value");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 2019, false);
//        java.lang.Object obj11 = null;
//        boolean boolean12 = fixedMillisecond7.equals(obj11);
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond7.getFirstMillisecond(calendar13);
//        long long15 = fixedMillisecond7.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560182679486L + "'", long14 == 1560182679486L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182679486L + "'", long15 == 1560182679486L);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182663029L, "org.jfree.data.event.SeriesChangeEvent[source=true]", "Mon Jun 10 09:03:22 PDT 2019");
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        java.lang.String str4 = timeSeries1.getDescription();
        timeSeries1.clear();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.createCopy(0, 0);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) (short) 10);
        timeSeriesDataItem12.setValue((java.lang.Number) (short) -1);
        timeSeriesDataItem12.setSelected(false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries8.addOrUpdate(timeSeriesDataItem12);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month18.previous();
        org.jfree.data.time.Year year20 = month18.getYear();
        long long21 = month18.getMiddleMillisecond();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) month18);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560668399999L + "'", long21 == 1560668399999L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Mon Jun 10 09:04:29 PDT 2019");
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Mon Jun 10 09:03:52 PDT 2019");
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(9);
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean9 = timeSeries8.getNotify();
        long long10 = timeSeries8.getMaximumItemAge();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(9);
        long long13 = year12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year5, (org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        long long18 = month17.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        timeSeries16.setRangeDescription("May 2019");
        boolean boolean22 = timeSeries16.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61883280000000L) + "'", long6 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61867512000001L) + "'", long13 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1559372400000L + "'", long18 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries1.setKey((java.lang.Comparable) (-1));
        timeSeries1.setKey((java.lang.Comparable) 8);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries9.setKey((java.lang.Comparable) (-1));
        timeSeries9.setKey((java.lang.Comparable) 8);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries9.addChangeListener(seriesChangeListener14);
        double double16 = timeSeries9.getMinY();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 5);
        long long20 = fixedMillisecond19.getFirstMillisecond();
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 24234L, true);
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond19.getFirstMillisecond(calendar24);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray28 = timePeriodFormatException27.getSuppressed();
        java.lang.Throwable[] throwableArray29 = timePeriodFormatException27.getSuppressed();
        int int30 = fixedMillisecond19.compareTo((java.lang.Object) timePeriodFormatException27);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 5L + "'", long20 == 5L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 5L + "'", long25 == 5L);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.lang.Object obj2 = null;
        boolean boolean3 = month0.equals(obj2);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean3, "", "Value");
        timeSeries6.removeAgedItems((long) (short) 100, false);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(9);
        long long12 = year11.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) year11);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.previous();
        java.lang.Class<?> wildcardClass16 = regularTimePeriod15.getClass();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        long long18 = month17.getFirstMillisecond();
        java.util.Date date19 = month17.getEnd();
        java.util.TimeZone timeZone20 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date19, timeZone20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date19);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date19);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean26 = timeSeries25.getNotify();
        java.util.List list27 = timeSeries25.getItems();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(9);
        long long30 = year29.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean33 = timeSeries32.getNotify();
        long long34 = timeSeries32.getMaximumItemAge();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(9);
        long long37 = year36.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year36, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) year29, (org.jfree.data.time.RegularTimePeriod) year36);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        long long42 = month41.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries40.getDataItem((org.jfree.data.time.RegularTimePeriod) month41);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj46 = seriesChangeEvent45.getSource();
        java.lang.Object obj47 = seriesChangeEvent45.getSource();
        java.lang.String str48 = seriesChangeEvent45.toString();
        boolean boolean49 = month41.equals((java.lang.Object) str48);
        boolean boolean50 = day23.equals((java.lang.Object) boolean49);
        int int51 = day23.getYear();
        java.lang.String str52 = day23.toString();
        org.jfree.data.time.SerialDate serialDate53 = day23.getSerialDate();
        int int54 = year11.compareTo((java.lang.Object) day23);
        long long55 = day23.getFirstMillisecond();
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = month56.previous();
        java.lang.Class<?> wildcardClass58 = regularTimePeriod57.getClass();
        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month();
        long long60 = month59.getFirstMillisecond();
        java.util.Date date61 = month59.getEnd();
        java.util.TimeZone timeZone62 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date61, timeZone62);
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond(date61);
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date61);
        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean68 = timeSeries67.getNotify();
        java.util.List list69 = timeSeries67.getItems();
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(9);
        long long72 = year71.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean75 = timeSeries74.getNotify();
        long long76 = timeSeries74.getMaximumItemAge();
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year(9);
        long long79 = year78.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem81 = timeSeries74.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year78, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries82 = timeSeries67.createCopy((org.jfree.data.time.RegularTimePeriod) year71, (org.jfree.data.time.RegularTimePeriod) year78);
        org.jfree.data.time.Month month83 = new org.jfree.data.time.Month();
        long long84 = month83.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem85 = timeSeries82.getDataItem((org.jfree.data.time.RegularTimePeriod) month83);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent87 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj88 = seriesChangeEvent87.getSource();
        java.lang.Object obj89 = seriesChangeEvent87.getSource();
        java.lang.String str90 = seriesChangeEvent87.toString();
        boolean boolean91 = month83.equals((java.lang.Object) str90);
        boolean boolean92 = day65.equals((java.lang.Object) boolean91);
        int int93 = day65.getYear();
        int int94 = day65.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = day65.previous();
        long long96 = day65.getLastMillisecond();
        boolean boolean97 = day23.equals((java.lang.Object) long96);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61867512000001L) + "'", long12 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1559372400000L + "'", long18 == 1559372400000L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-61883280000000L) + "'", long30 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 9223372036854775807L + "'", long34 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-61867512000001L) + "'", long37 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1559372400000L + "'", long42 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + obj46 + "' != '" + 100L + "'", obj46.equals(100L));
        org.junit.Assert.assertTrue("'" + obj47 + "' != '" + 100L + "'", obj47.equals(100L));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str48.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "30-June-2019" + "'", str52.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1561878000000L + "'", long55 == 1561878000000L);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1559372400000L + "'", long60 == 1559372400000L);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(list69);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-61883280000000L) + "'", long72 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 9223372036854775807L + "'", long76 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + (-61867512000001L) + "'", long79 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem81);
        org.junit.Assert.assertNotNull(timeSeries82);
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 1559372400000L + "'", long84 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem85);
        org.junit.Assert.assertTrue("'" + obj88 + "' != '" + 100L + "'", obj88.equals(100L));
        org.junit.Assert.assertTrue("'" + obj89 + "' != '" + 100L + "'", obj89.equals(100L));
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str90.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 2019 + "'", int93 == 2019);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 6 + "'", int94 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod95);
        org.junit.Assert.assertTrue("'" + long96 + "' != '" + 1561964399999L + "'", long96 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        java.lang.String str4 = timeSeries1.getDescription();
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month8, (double) 1559372400000L, false);
        timeSeries1.setMaximumItemAge(1560182651045L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        long long3 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, 0.0d);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 5);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 1560182596196L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries1.getNextTimePeriod();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries1.removeChangeListener(seriesChangeListener13);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries1.setKey((java.lang.Comparable) (-1));
        timeSeries1.setKey((java.lang.Comparable) 8);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries9.setKey((java.lang.Comparable) (-1));
        timeSeries9.setKey((java.lang.Comparable) 8);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries9.addChangeListener(seriesChangeListener14);
        double double16 = timeSeries9.getMinY();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.addAndOrUpdate(timeSeries9);
        java.lang.Class<?> wildcardClass18 = timeSeries1.getClass();
        java.lang.Comparable comparable19 = timeSeries1.getKey();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries1.addChangeListener(seriesChangeListener20);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + 8 + "'", comparable19.equals(8));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.lang.Class<?> wildcardClass2 = regularTimePeriod1.getClass();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        long long4 = month3.getFirstMillisecond();
        java.util.Date date5 = month3.getEnd();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date5, timeZone6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (double) 1560182603095L);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj14 = seriesChangeEvent13.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        seriesChangeEvent13.setSummary(seriesChangeInfo15);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo17 = null;
        seriesChangeEvent13.setSummary(seriesChangeInfo17);
        java.lang.String str19 = seriesChangeEvent13.toString();
        java.lang.String str20 = seriesChangeEvent13.toString();
        int int21 = year9.compareTo((java.lang.Object) str20);
        long long22 = year9.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + obj14 + "' != '" + 100L + "'", obj14.equals(100L));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str19.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str20.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1562097599999L + "'", long22 == 1562097599999L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182599736L);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        long long6 = month5.getFirstMillisecond();
        java.util.Date date7 = month5.getEnd();
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date7, timeZone8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean14 = timeSeries13.getNotify();
        java.util.List list15 = timeSeries13.getItems();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(9);
        long long18 = year17.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean21 = timeSeries20.getNotify();
        long long22 = timeSeries20.getMaximumItemAge();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(9);
        long long25 = year24.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year24, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year24);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        long long30 = month29.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries28.getDataItem((org.jfree.data.time.RegularTimePeriod) month29);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj34 = seriesChangeEvent33.getSource();
        java.lang.Object obj35 = seriesChangeEvent33.getSource();
        java.lang.String str36 = seriesChangeEvent33.toString();
        boolean boolean37 = month29.equals((java.lang.Object) str36);
        boolean boolean38 = day11.equals((java.lang.Object) boolean37);
        int int39 = day11.getYear();
        java.util.Date date40 = day11.getEnd();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month41.previous();
        java.lang.Class<?> wildcardClass43 = regularTimePeriod42.getClass();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
        long long45 = month44.getFirstMillisecond();
        java.util.Date date46 = month44.getEnd();
        java.util.TimeZone timeZone47 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date46, timeZone47);
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond(date46);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date46);
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean53 = timeSeries52.getNotify();
        java.util.List list54 = timeSeries52.getItems();
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(9);
        long long57 = year56.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean60 = timeSeries59.getNotify();
        long long61 = timeSeries59.getMaximumItemAge();
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year(9);
        long long64 = year63.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries59.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year63, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries52.createCopy((org.jfree.data.time.RegularTimePeriod) year56, (org.jfree.data.time.RegularTimePeriod) year63);
        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month();
        long long69 = month68.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries67.getDataItem((org.jfree.data.time.RegularTimePeriod) month68);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent72 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj73 = seriesChangeEvent72.getSource();
        java.lang.Object obj74 = seriesChangeEvent72.getSource();
        java.lang.String str75 = seriesChangeEvent72.toString();
        boolean boolean76 = month68.equals((java.lang.Object) str75);
        boolean boolean77 = day50.equals((java.lang.Object) boolean76);
        boolean boolean79 = day50.equals((java.lang.Object) 1);
        long long80 = day50.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries81 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) day50);
        int int82 = timeSeries1.getItemCount();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1559372400000L + "'", long6 == 1559372400000L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-61883280000000L) + "'", long18 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9223372036854775807L + "'", long22 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-61867512000001L) + "'", long25 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1559372400000L + "'", long30 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertTrue("'" + obj34 + "' != '" + 100L + "'", obj34.equals(100L));
        org.junit.Assert.assertTrue("'" + obj35 + "' != '" + 100L + "'", obj35.equals(100L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str36.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1559372400000L + "'", long45 == 1559372400000L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(list54);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-61883280000000L) + "'", long57 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 9223372036854775807L + "'", long61 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-61867512000001L) + "'", long64 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem66);
        org.junit.Assert.assertNotNull(timeSeries67);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1559372400000L + "'", long69 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem70);
        org.junit.Assert.assertTrue("'" + obj73 + "' != '" + 100L + "'", obj73.equals(100L));
        org.junit.Assert.assertTrue("'" + obj74 + "' != '" + 100L + "'", obj74.equals(100L));
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str75.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 43646L + "'", long80 == 43646L);
        org.junit.Assert.assertNotNull(timeSeries81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem6);
        timeSeries7.setMaximumItemCount(9);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) true);
        java.lang.String str2 = seriesChangeEvent1.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo3);
        java.lang.String str5 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=true]" + "'", str2.equals("org.jfree.data.event.SeriesChangeEvent[source=true]"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=true]" + "'", str5.equals("org.jfree.data.event.SeriesChangeEvent[source=true]"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.lang.Object obj2 = null;
        boolean boolean3 = month0.equals(obj2);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean3, "", "Value");
        boolean boolean7 = timeSeries6.isEmpty();
        timeSeries6.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        java.util.Date date13 = year11.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (short) 0);
        java.lang.String str16 = timeSeries6.getDomainDescription();
        timeSeries6.fireSeriesChanged();
        java.lang.Class class18 = timeSeries6.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(class18);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.previous();
        java.lang.Class<?> wildcardClass3 = regularTimePeriod2.getClass();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        long long5 = month4.getFirstMillisecond();
        java.util.Date date6 = month4.getEnd();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date6, timeZone7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date6);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date6);
        int int11 = year0.compareTo((java.lang.Object) day10);
        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate12);
        java.util.Date date15 = day14.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.lang.Class<?> wildcardClass2 = regularTimePeriod1.getClass();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        long long4 = month3.getFirstMillisecond();
        java.util.Date date5 = month3.getEnd();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date5, timeZone6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date5);
        java.util.TimeZone timeZone10 = null;
        try {
            org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date5, timeZone10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean5 = timeSeries4.getNotify();
        long long6 = timeSeries4.getMaximumItemAge();
        java.util.Collection collection7 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries4);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries1);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        java.lang.String str12 = month9.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month9);
        java.lang.String str14 = timeSeries1.getDescription();
        timeSeries1.setNotify(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "June 2019" + "'", str12.equals("June 2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNull(str14);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182599736L);
//        boolean boolean2 = timeSeries1.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean6 = fixedMillisecond4.equals((java.lang.Object) "Value");
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond4.getFirstMillisecond(calendar7);
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond4.peg(calendar9);
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
//        timeSeries1.setDescription("Wed Dec 31 16:00:00 PST 1969");
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) (short) 10);
//        boolean boolean18 = timeSeriesDataItem17.isSelected();
//        timeSeriesDataItem17.setValue((java.lang.Number) (byte) 10);
//        timeSeriesDataItem17.setSelected(false);
//        timeSeries1.add(timeSeriesDataItem17);
//        java.lang.Object obj24 = timeSeries1.clone();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        boolean boolean27 = timeSeries26.getNotify();
//        java.util.List list28 = timeSeries26.getItems();
//        java.lang.String str29 = timeSeries26.getDescription();
//        java.lang.String str30 = timeSeries26.getRangeDescription();
//        timeSeries26.setDomainDescription("hi!");
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) month33, (double) 1559372400000L, false);
//        long long37 = month33.getLastMillisecond();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month38.previous();
//        java.lang.Class<?> wildcardClass40 = regularTimePeriod39.getClass();
//        int int41 = month33.compareTo((java.lang.Object) regularTimePeriod39);
//        long long42 = month33.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month33, (java.lang.Number) 0.0d);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
//        int int47 = timeSeriesDataItem44.compareTo((java.lang.Object) fixedMillisecond46);
//        java.util.Date date48 = fixedMillisecond46.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = timeSeriesDataItem49.getPeriod();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560182681658L + "'", long8 == 1560182681658L);
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(obj24);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertNotNull(list28);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Value" + "'", str30.equals("Value"));
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1561964399999L + "'", long37 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(wildcardClass40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 24234L + "'", long42 == 24234L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getFirstMillisecond();
//        java.lang.Object obj2 = null;
//        boolean boolean3 = month0.equals(obj2);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean3, "", "Value");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 2019, false);
//        java.lang.Object obj11 = null;
//        boolean boolean12 = fixedMillisecond7.equals(obj11);
//        java.lang.String str13 = fixedMillisecond7.toString();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond7.getMiddleMillisecond(calendar14);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Mon Jun 10 09:04:41 PDT 2019" + "'", str13.equals("Mon Jun 10 09:04:41 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182681829L + "'", long15 == 1560182681829L);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        long long6 = timeSeries5.getMaximumItemAge();
        java.util.Collection collection7 = timeSeries5.getTimePeriods();
        java.util.Collection collection8 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        java.util.Collection collection9 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean12 = timeSeries11.getNotify();
        java.util.List list13 = timeSeries11.getItems();
        java.lang.String str14 = timeSeries11.getDescription();
        java.lang.String str15 = timeSeries11.getRangeDescription();
        timeSeries11.setDomainDescription("hi!");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month18, (double) 1559372400000L, false);
        long long22 = month18.getLastMillisecond();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month23.previous();
        java.lang.Class<?> wildcardClass25 = regularTimePeriod24.getClass();
        int int26 = month18.compareTo((java.lang.Object) regularTimePeriod24);
        long long27 = month18.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 0.0d);
        int int31 = timeSeriesDataItem29.compareTo((java.lang.Object) (short) 0);
        java.lang.Object obj32 = timeSeriesDataItem29.clone();
        timeSeries1.add(timeSeriesDataItem29);
        java.lang.Object obj34 = timeSeriesDataItem29.clone();
        timeSeriesDataItem29.setValue((java.lang.Number) 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Value" + "'", str15.equals("Value"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1561964399999L + "'", long22 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 24234L + "'", long27 == 24234L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(obj34);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean5 = timeSeries4.getNotify();
        long long6 = timeSeries4.getMaximumItemAge();
        java.util.Collection collection7 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean10 = timeSeries9.getNotify();
        long long11 = timeSeries9.getMaximumItemAge();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year13, 0.0d);
        long long16 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year13, (double) 9L);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean24 = timeSeries23.getNotify();
        java.util.List list25 = timeSeries23.getItems();
        java.lang.String str26 = timeSeries23.getDescription();
        java.lang.String str27 = timeSeries23.getRangeDescription();
        timeSeries23.setDomainDescription("hi!");
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) month30, (double) 1559372400000L, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month30, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean39 = timeSeries38.getNotify();
        long long40 = timeSeries38.getMaximumItemAge();
        java.util.Collection collection41 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries38);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        long long43 = month42.getFirstMillisecond();
        java.util.Date date44 = month42.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond(date44);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date44);
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date44);
        long long48 = fixedMillisecond47.getSerialIndex();
        try {
            timeSeries36.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62135740800000L) + "'", long16 == (-62135740800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Value" + "'", str27.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 9223372036854775807L + "'", long40 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1559372400000L + "'", long43 == 1559372400000L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1561964399999L + "'", long48 == 1561964399999L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        long long2 = timeSeries1.getMaximumItemAge();
        java.util.Collection collection3 = timeSeries1.getTimePeriods();
        java.lang.Class<?> wildcardClass4 = timeSeries1.getClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        long long8 = month7.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean11 = timeSeries10.getNotify();
        java.util.List list12 = timeSeries10.getItems();
        java.lang.String str13 = timeSeries10.getDescription();
        java.lang.String str14 = timeSeries10.getRangeDescription();
        timeSeries10.setDomainDescription("hi!");
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month17, (double) 1559372400000L, false);
        long long21 = month17.getLastMillisecond();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month22.previous();
        java.lang.Class<?> wildcardClass24 = regularTimePeriod23.getClass();
        int int25 = month17.compareTo((java.lang.Object) regularTimePeriod23);
        long long26 = month17.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month17.previous();
        boolean boolean29 = month17.equals((java.lang.Object) "org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) month7, (org.jfree.data.time.RegularTimePeriod) month17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month7.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month7.previous();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) 11, false);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1559372400000L + "'", long8 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1561964399999L + "'", long21 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 24234L + "'", long26 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        boolean boolean2 = fixedMillisecond0.equals((java.lang.Object) "Value");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) year3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        java.lang.String str4 = timeSeries1.getDescription();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        long long6 = month5.getFirstMillisecond();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date7);
        int int9 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        boolean boolean10 = timeSeries1.getNotify();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries1.getTimePeriod(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1559372400000L + "'", long6 == 1559372400000L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean5 = timeSeries4.getNotify();
        long long6 = timeSeries4.getMaximumItemAge();
        java.util.Collection collection7 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean10 = timeSeries9.getNotify();
        long long11 = timeSeries9.getMaximumItemAge();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year13, 0.0d);
        long long16 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year13, (double) 9L);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        long long23 = month22.getFirstMillisecond();
        java.lang.Object obj24 = null;
        boolean boolean25 = month22.equals(obj24);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean25, "", "Value");
        long long29 = timeSeries28.getMaximumItemAge();
        boolean boolean31 = timeSeries28.equals((java.lang.Object) 1L);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries1.addAndOrUpdate(timeSeries28);
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener33);
        timeSeries1.clear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62135740800000L) + "'", long16 == (-62135740800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1559372400000L + "'", long23 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 9223372036854775807L + "'", long29 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(timeSeries32);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        long long2 = fixedMillisecond0.getFirstMillisecond();
//        long long3 = fixedMillisecond0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182682636L + "'", long1 == 1560182682636L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182682636L + "'", long2 == 1560182682636L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560182682636L + "'", long3 == 1560182682636L);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(9);
        long long5 = year4.getMiddleMillisecond();
        long long6 = year4.getSerialIndex();
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("");
        boolean boolean9 = year4.equals((java.lang.Object) seriesException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        seriesException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException8);
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=true]");
        java.lang.Throwable[] throwableArray16 = seriesException15.getSuppressed();
        seriesException8.addSuppressed((java.lang.Throwable) seriesException15);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61867512000001L) + "'", long5 == (-61867512000001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9L + "'", long6 == 9L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(9);
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean9 = timeSeries8.getNotify();
        long long10 = timeSeries8.getMaximumItemAge();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(9);
        long long13 = year12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year5, (org.jfree.data.time.RegularTimePeriod) year12);
        timeSeries16.fireSeriesChanged();
        java.lang.Object obj18 = timeSeries16.clone();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries16.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.next();
        java.lang.Class<?> wildcardClass23 = year21.getClass();
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.previous();
        java.lang.Class<?> wildcardClass27 = regularTimePeriod26.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean30 = timeSeries29.getNotify();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean33 = timeSeries32.getNotify();
        long long34 = timeSeries32.getMaximumItemAge();
        java.util.Collection collection35 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries32);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean38 = timeSeries37.getNotify();
        long long39 = timeSeries37.getMaximumItemAge();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year41, 0.0d);
        long long44 = year41.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year41.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year41, (double) 9L);
        timeSeries29.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean52 = timeSeries51.getNotify();
        java.util.List list53 = timeSeries51.getItems();
        java.lang.String str54 = timeSeries51.getDescription();
        java.lang.String str55 = timeSeries51.getRangeDescription();
        timeSeries51.setDomainDescription("hi!");
        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month();
        timeSeries51.add((org.jfree.data.time.RegularTimePeriod) month58, (double) 1559372400000L, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeries timeSeries64 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) month58, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond63);
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month();
        long long66 = month65.getFirstMillisecond();
        java.lang.Object obj67 = null;
        boolean boolean68 = month65.equals(obj67);
        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean68, "", "Value");
        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond();
        timeSeries71.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond72, (double) 2019, false);
        boolean boolean76 = fixedMillisecond63.equals((java.lang.Object) 2019);
        java.util.Date date77 = fixedMillisecond63.getEnd();
        java.util.TimeZone timeZone78 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date77, timeZone78);
        java.util.TimeZone timeZone80 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date77, timeZone80);
        boolean boolean82 = timeSeries16.equals((java.lang.Object) date77);
        java.lang.String str83 = timeSeries16.getDescription();
        org.jfree.data.time.TimeSeries timeSeries85 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean86 = timeSeries85.getNotify();
        java.util.List list87 = timeSeries85.getItems();
        java.lang.String str88 = timeSeries85.getDescription();
        java.lang.String str89 = timeSeries85.getRangeDescription();
        timeSeries85.setDomainDescription("hi!");
        org.jfree.data.time.Month month92 = new org.jfree.data.time.Month();
        timeSeries85.add((org.jfree.data.time.RegularTimePeriod) month92, (double) 1559372400000L, false);
        java.util.Collection collection96 = timeSeries85.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries97 = timeSeries16.addAndOrUpdate(timeSeries85);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61883280000000L) + "'", long6 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61867512000001L) + "'", long13 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 9223372036854775807L + "'", long34 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 9223372036854775807L + "'", long39 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-62135740800000L) + "'", long44 == (-62135740800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(list53);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Value" + "'", str55.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries64);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1559372400000L + "'", long66 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertNull(regularTimePeriod79);
        org.junit.Assert.assertNull(regularTimePeriod81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNull(str83);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertNotNull(list87);
        org.junit.Assert.assertNull(str88);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "Value" + "'", str89.equals("Value"));
        org.junit.Assert.assertNotNull(collection96);
        org.junit.Assert.assertNotNull(timeSeries97);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean5 = timeSeries4.getNotify();
        long long6 = timeSeries4.getMaximumItemAge();
        java.util.Collection collection7 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries4);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries1);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries1.getTimePeriod((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection7);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.lang.Class<?> wildcardClass2 = regularTimePeriod1.getClass();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        long long4 = month3.getFirstMillisecond();
        java.util.Date date5 = month3.getEnd();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date5, timeZone6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date5);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getFirstMillisecond(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 1559372400000L);
        java.lang.Number number13 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, number13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month15.previous();
        java.lang.Class<?> wildcardClass17 = regularTimePeriod16.getClass();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        long long19 = month18.getFirstMillisecond();
        java.util.Date date20 = month18.getEnd();
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date20, timeZone21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(date20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond23.next();
        java.util.Date date25 = regularTimePeriod24.getStart();
        boolean boolean26 = fixedMillisecond8.equals((java.lang.Object) date25);
        java.util.Calendar calendar27 = null;
        fixedMillisecond8.peg(calendar27);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1559372400000L + "'", long19 == 1559372400000L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        boolean boolean4 = fixedMillisecond1.equals((java.lang.Object) "Mon Jun 10 09:03:37 PDT 2019");
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean5 = timeSeries4.getNotify();
        long long6 = timeSeries4.getMaximumItemAge();
        java.util.Collection collection7 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean10 = timeSeries9.getNotify();
        java.util.List list11 = timeSeries9.getItems();
        java.lang.String str12 = timeSeries9.getDescription();
        java.lang.String str13 = timeSeries9.getRangeDescription();
        timeSeries9.setDomainDescription("hi!");
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 1559372400000L, false);
        long long20 = month16.getLastMillisecond();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.previous();
        java.lang.Class<?> wildcardClass23 = regularTimePeriod22.getClass();
        int int24 = month16.compareTo((java.lang.Object) regularTimePeriod22);
        long long25 = month16.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month16.previous();
        java.lang.Number number27 = null;
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month16, number27);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries4.addChangeListener(seriesChangeListener29);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month31.previous();
        java.lang.Class<?> wildcardClass33 = regularTimePeriod32.getClass();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        long long35 = month34.getFirstMillisecond();
        java.util.Date date36 = month34.getEnd();
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date36, timeZone37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(date36);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean43 = timeSeries42.getNotify();
        java.util.List list44 = timeSeries42.getItems();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(9);
        long long47 = year46.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean50 = timeSeries49.getNotify();
        long long51 = timeSeries49.getMaximumItemAge();
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(9);
        long long54 = year53.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries49.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year53, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries42.createCopy((org.jfree.data.time.RegularTimePeriod) year46, (org.jfree.data.time.RegularTimePeriod) year53);
        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month();
        long long59 = month58.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries57.getDataItem((org.jfree.data.time.RegularTimePeriod) month58);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent62 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj63 = seriesChangeEvent62.getSource();
        java.lang.Object obj64 = seriesChangeEvent62.getSource();
        java.lang.String str65 = seriesChangeEvent62.toString();
        boolean boolean66 = month58.equals((java.lang.Object) str65);
        boolean boolean67 = day40.equals((java.lang.Object) boolean66);
        int int68 = day40.getYear();
        java.util.Date date69 = day40.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = day40.next();
        java.lang.Number number71 = null;
        timeSeries4.update((org.jfree.data.time.RegularTimePeriod) day40, number71);
        try {
            java.lang.Number number74 = timeSeries4.getValue((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1559372400000L + "'", long35 == 1559372400000L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-61883280000000L) + "'", long47 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 9223372036854775807L + "'", long51 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-61867512000001L) + "'", long54 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem56);
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1559372400000L + "'", long59 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem60);
        org.junit.Assert.assertTrue("'" + obj63 + "' != '" + 100L + "'", obj63.equals(100L));
        org.junit.Assert.assertTrue("'" + obj64 + "' != '" + 100L + "'", obj64.equals(100L));
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str65.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 2019 + "'", int68 == 2019);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(9);
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean9 = timeSeries8.getNotify();
        long long10 = timeSeries8.getMaximumItemAge();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(9);
        long long13 = year12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year5, (org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        long long18 = month17.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        java.lang.String str20 = timeSeries16.getRangeDescription();
        java.lang.Class<?> wildcardClass21 = timeSeries16.getClass();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean24 = timeSeries23.getNotify();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean27 = timeSeries26.getNotify();
        long long28 = timeSeries26.getMaximumItemAge();
        java.util.Collection collection29 = timeSeries23.getTimePeriodsUniqueToOtherSeries(timeSeries26);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean32 = timeSeries31.getNotify();
        long long33 = timeSeries31.getMaximumItemAge();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year35, 0.0d);
        long long38 = year35.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year35.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year35, (double) 9L);
        java.lang.Comparable comparable42 = timeSeries23.getKey();
        java.util.Collection collection43 = timeSeries16.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        java.util.List list44 = timeSeries23.getItems();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61883280000000L) + "'", long6 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61867512000001L) + "'", long13 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1559372400000L + "'", long18 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Value" + "'", str20.equals("Value"));
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 9223372036854775807L + "'", long28 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775807L + "'", long33 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-62135740800000L) + "'", long38 == (-62135740800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + comparable42 + "' != '" + 100.0f + "'", comparable42.equals(100.0f));
        org.junit.Assert.assertNotNull(collection43);
        org.junit.Assert.assertNotNull(list44);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean5 = timeSeries4.getNotify();
        long long6 = timeSeries4.getMaximumItemAge();
        java.util.Collection collection7 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean10 = timeSeries9.getNotify();
        java.util.List list11 = timeSeries9.getItems();
        java.lang.String str12 = timeSeries9.getDescription();
        java.lang.String str13 = timeSeries9.getRangeDescription();
        timeSeries9.setDomainDescription("hi!");
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 1559372400000L, false);
        long long20 = month16.getLastMillisecond();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.previous();
        java.lang.Class<?> wildcardClass23 = regularTimePeriod22.getClass();
        int int24 = month16.compareTo((java.lang.Object) regularTimePeriod22);
        long long25 = month16.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month16.previous();
        java.lang.Number number27 = null;
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month16, number27);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year30, (java.lang.Number) (short) 10);
        boolean boolean33 = month16.equals((java.lang.Object) year30);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        long long3 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(9);
        long long6 = year5.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, 0.0d);
        java.util.List list9 = timeSeries1.getItems();
        java.lang.String str10 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener11);
        timeSeries1.removeAgedItems(0L, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61867512000001L) + "'", long6 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean5 = timeSeries4.getNotify();
        long long6 = timeSeries4.getMaximumItemAge();
        java.util.Collection collection7 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean10 = timeSeries9.getNotify();
        long long11 = timeSeries9.getMaximumItemAge();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year13, 0.0d);
        long long16 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year13, (double) 9L);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean24 = timeSeries23.getNotify();
        java.util.List list25 = timeSeries23.getItems();
        java.lang.String str26 = timeSeries23.getDescription();
        java.lang.String str27 = timeSeries23.getRangeDescription();
        timeSeries23.setDomainDescription("hi!");
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) month30, (double) 1559372400000L, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month30, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        long long38 = month37.getFirstMillisecond();
        java.lang.Object obj39 = null;
        boolean boolean40 = month37.equals(obj39);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean40, "", "Value");
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
        timeSeries43.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 2019, false);
        boolean boolean48 = fixedMillisecond35.equals((java.lang.Object) 2019);
        java.util.Date date49 = fixedMillisecond35.getEnd();
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month(date49);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(date49);
        long long52 = month51.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62135740800000L) + "'", long16 == (-62135740800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Value" + "'", str27.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1559372400000L + "'", long38 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-2649600000L) + "'", long52 == (-2649600000L));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.lang.Object obj2 = null;
        boolean boolean3 = month0.equals(obj2);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean3, "", "Value");
        timeSeries6.removeAgedItems(false);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year10.previous();
        java.lang.String str14 = year10.toString();
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 9223372036854775807L, false);
        java.lang.String str18 = timeSeries6.getRangeDescription();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9" + "'", str14.equals("9"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Value" + "'", str18.equals("Value"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.previous();
        java.lang.Class<?> wildcardClass3 = regularTimePeriod2.getClass();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        long long5 = month4.getFirstMillisecond();
        java.util.Date date6 = month4.getEnd();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date6, timeZone7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date6);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date6);
        int int11 = year0.compareTo((java.lang.Object) day10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day10.previous();
        long long13 = day10.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        long long16 = timeSeries15.getMaximumItemAge();
        java.util.Collection collection17 = timeSeries15.getTimePeriods();
        int int18 = day10.compareTo((java.lang.Object) collection17);
        int int19 = day10.getDayOfMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561878000000L + "'", long13 == 1561878000000L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 30 + "'", int19 == 30);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182599736L);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        long long6 = month5.getFirstMillisecond();
        java.util.Date date7 = month5.getEnd();
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date7, timeZone8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean14 = timeSeries13.getNotify();
        java.util.List list15 = timeSeries13.getItems();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(9);
        long long18 = year17.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean21 = timeSeries20.getNotify();
        long long22 = timeSeries20.getMaximumItemAge();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(9);
        long long25 = year24.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year24, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) year17, (org.jfree.data.time.RegularTimePeriod) year24);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        long long30 = month29.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries28.getDataItem((org.jfree.data.time.RegularTimePeriod) month29);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj34 = seriesChangeEvent33.getSource();
        java.lang.Object obj35 = seriesChangeEvent33.getSource();
        java.lang.String str36 = seriesChangeEvent33.toString();
        boolean boolean37 = month29.equals((java.lang.Object) str36);
        boolean boolean38 = day11.equals((java.lang.Object) boolean37);
        int int39 = day11.getYear();
        java.util.Date date40 = day11.getEnd();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month41.previous();
        java.lang.Class<?> wildcardClass43 = regularTimePeriod42.getClass();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
        long long45 = month44.getFirstMillisecond();
        java.util.Date date46 = month44.getEnd();
        java.util.TimeZone timeZone47 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date46, timeZone47);
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond(date46);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date46);
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean53 = timeSeries52.getNotify();
        java.util.List list54 = timeSeries52.getItems();
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(9);
        long long57 = year56.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean60 = timeSeries59.getNotify();
        long long61 = timeSeries59.getMaximumItemAge();
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year(9);
        long long64 = year63.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries59.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year63, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries52.createCopy((org.jfree.data.time.RegularTimePeriod) year56, (org.jfree.data.time.RegularTimePeriod) year63);
        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month();
        long long69 = month68.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries67.getDataItem((org.jfree.data.time.RegularTimePeriod) month68);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent72 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj73 = seriesChangeEvent72.getSource();
        java.lang.Object obj74 = seriesChangeEvent72.getSource();
        java.lang.String str75 = seriesChangeEvent72.toString();
        boolean boolean76 = month68.equals((java.lang.Object) str75);
        boolean boolean77 = day50.equals((java.lang.Object) boolean76);
        boolean boolean79 = day50.equals((java.lang.Object) 1);
        long long80 = day50.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries81 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) day50);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1559372400000L + "'", long6 == 1559372400000L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-61883280000000L) + "'", long18 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9223372036854775807L + "'", long22 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-61867512000001L) + "'", long25 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1559372400000L + "'", long30 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertTrue("'" + obj34 + "' != '" + 100L + "'", obj34.equals(100L));
        org.junit.Assert.assertTrue("'" + obj35 + "' != '" + 100L + "'", obj35.equals(100L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str36.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1559372400000L + "'", long45 == 1559372400000L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(list54);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-61883280000000L) + "'", long57 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 9223372036854775807L + "'", long61 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-61867512000001L) + "'", long64 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem66);
        org.junit.Assert.assertNotNull(timeSeries67);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1559372400000L + "'", long69 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem70);
        org.junit.Assert.assertTrue("'" + obj73 + "' != '" + 100L + "'", obj73.equals(100L));
        org.junit.Assert.assertTrue("'" + obj74 + "' != '" + 100L + "'", obj74.equals(100L));
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str75.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 43646L + "'", long80 == 43646L);
        org.junit.Assert.assertNotNull(timeSeries81);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        java.lang.String str4 = timeSeries1.getDescription();
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.lang.String str6 = timeSeries1.getDescription();
        timeSeries1.setKey((java.lang.Comparable) (short) 10);
        org.jfree.data.time.Month month10 = org.jfree.data.time.Month.parseMonth("May 2019");
        int int11 = month10.getYearValue();
        int int12 = month10.getYearValue();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
        java.lang.Class<?> wildcardClass15 = regularTimePeriod14.getClass();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        long long17 = month16.getFirstMillisecond();
        java.util.Date date18 = month16.getEnd();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date18, timeZone19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date18);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date18);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month10, (org.jfree.data.time.RegularTimePeriod) month23);
        timeSeries24.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(month10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries24);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=true]");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("Wed Dec 31 16:00:00 PST 1969");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean3 = timeSeries2.getNotify();
        long long4 = timeSeries2.getMaximumItemAge();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, 0.0d);
        java.lang.Comparable comparable9 = timeSeries2.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean12 = timeSeries11.getNotify();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean15 = timeSeries14.getNotify();
        long long16 = timeSeries14.getMaximumItemAge();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries2.addAndOrUpdate(timeSeries14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        long long20 = month19.getFirstMillisecond();
        java.lang.Object obj21 = null;
        boolean boolean22 = month19.equals(obj21);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean22, "", "Value");
        timeSeries25.removeAgedItems((long) (short) 100, false);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(9);
        long long31 = year30.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries25.getDataItem((org.jfree.data.time.RegularTimePeriod) year30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year30, (double) 2147483647);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(5, year30);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month35.next();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100.0f + "'", comparable9.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1559372400000L + "'", long20 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-61867512000001L) + "'", long31 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean2 = fixedMillisecond0.equals((java.lang.Object) "Value");
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        timeSeries5.setKey((java.lang.Comparable) (-1));
//        timeSeries5.setKey((java.lang.Comparable) 8);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries5.addChangeListener(seriesChangeListener10);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        timeSeries13.setKey((java.lang.Comparable) (-1));
//        timeSeries13.setKey((java.lang.Comparable) 8);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries13.addChangeListener(seriesChangeListener18);
//        double double20 = timeSeries13.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries5.addAndOrUpdate(timeSeries13);
//        java.lang.Class<?> wildcardClass22 = timeSeries5.getClass();
//        timeSeries5.setDomainDescription("");
//        boolean boolean25 = fixedMillisecond0.equals((java.lang.Object) "");
//        long long26 = fixedMillisecond0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560182685724L + "'", long3 == 1560182685724L);
//        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182685724L + "'", long26 == 1560182685724L);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        long long3 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, 0.0d);
        java.lang.Comparable comparable8 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean11 = timeSeries10.getNotify();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean14 = timeSeries13.getNotify();
        long long15 = timeSeries13.getMaximumItemAge();
        java.util.Collection collection16 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.addAndOrUpdate(timeSeries13);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        long long19 = month18.getFirstMillisecond();
        java.lang.Object obj20 = null;
        boolean boolean21 = month18.equals(obj20);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean21, "", "Value");
        timeSeries24.removeAgedItems((long) (short) 100, false);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(9);
        long long30 = year29.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries24.getDataItem((org.jfree.data.time.RegularTimePeriod) year29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year29, (double) 2147483647);
        long long34 = timeSeries13.getMaximumItemAge();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries13.addChangeListener(seriesChangeListener35);
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timeSeries13.removePropertyChangeListener(propertyChangeListener37);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0f + "'", comparable8.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1559372400000L + "'", long19 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-61867512000001L) + "'", long30 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 9223372036854775807L + "'", long34 == 9223372036854775807L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.previous();
        java.lang.Class<?> wildcardClass3 = regularTimePeriod2.getClass();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        long long5 = month4.getFirstMillisecond();
        java.util.Date date6 = month4.getEnd();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date6, timeZone7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date6);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date6);
        int int11 = year0.compareTo((java.lang.Object) day10);
        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate12);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = day14.getFirstMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(serialDate12);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        long long2 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182685852L + "'", long1 == 1560182685852L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182685852L + "'", long2 == 1560182685852L);
//        org.junit.Assert.assertNotNull(date3);
//    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182599736L);
//        boolean boolean2 = timeSeries1.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean6 = fixedMillisecond4.equals((java.lang.Object) "Value");
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond4.getFirstMillisecond(calendar7);
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond4.peg(calendar9);
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
//        timeSeries1.setRangeDescription("Mon Jun 10 09:03:37 PDT 2019");
//        java.util.List list14 = timeSeries1.getItems();
//        java.lang.String str15 = timeSeries1.getRangeDescription();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560182685866L + "'", long8 == 1560182685866L);
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertNotNull(list14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Mon Jun 10 09:03:37 PDT 2019" + "'", str15.equals("Mon Jun 10 09:03:37 PDT 2019"));
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.lang.Class<?> wildcardClass2 = regularTimePeriod1.getClass();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        long long4 = month3.getFirstMillisecond();
        java.util.Date date5 = month3.getEnd();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date5, timeZone6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean12 = timeSeries11.getNotify();
        java.util.List list13 = timeSeries11.getItems();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(9);
        long long16 = year15.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean19 = timeSeries18.getNotify();
        long long20 = timeSeries18.getMaximumItemAge();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(9);
        long long23 = year22.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year22, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) year15, (org.jfree.data.time.RegularTimePeriod) year22);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        long long28 = month27.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries26.getDataItem((org.jfree.data.time.RegularTimePeriod) month27);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj32 = seriesChangeEvent31.getSource();
        java.lang.Object obj33 = seriesChangeEvent31.getSource();
        java.lang.String str34 = seriesChangeEvent31.toString();
        boolean boolean35 = month27.equals((java.lang.Object) str34);
        boolean boolean36 = day9.equals((java.lang.Object) boolean35);
        int int37 = day9.getYear();
        int int38 = day9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day9.previous();
        java.lang.String str40 = day9.toString();
        int int41 = day9.getMonth();
        java.util.Calendar calendar42 = null;
        try {
            long long43 = day9.getFirstMillisecond(calendar42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61883280000000L) + "'", long16 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61867512000001L) + "'", long23 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1559372400000L + "'", long28 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + obj32 + "' != '" + 100L + "'", obj32.equals(100L));
        org.junit.Assert.assertTrue("'" + obj33 + "' != '" + 100L + "'", obj33.equals(100L));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str34.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "30-June-2019" + "'", str40.equals("30-June-2019"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean3 = timeSeries2.getNotify();
        java.util.List list4 = timeSeries2.getItems();
        java.lang.String str5 = timeSeries2.getDescription();
        java.lang.String str6 = timeSeries2.getRangeDescription();
        java.lang.String str7 = timeSeries2.getDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries2.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.previous();
        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        long long15 = month14.getFirstMillisecond();
        java.util.Date date16 = month14.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date16, timeZone17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date16);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date16);
        int int21 = year10.compareTo((java.lang.Object) day20);
        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) (-1L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year10.previous();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (short) 10, year10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1559372400000L + "'", long15 == 1559372400000L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1.0f, seriesChangeInfo1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("May 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        java.lang.String str4 = timeSeries1.getDescription();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month5);
        double double7 = timeSeries1.getMaxY();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.lang.Object obj2 = null;
        boolean boolean3 = month0.equals(obj2);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean3, "", "Value");
        timeSeries6.removeAgedItems((long) (short) 100, false);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(9);
        long long12 = year11.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) year11);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.previous();
        java.lang.Class<?> wildcardClass16 = regularTimePeriod15.getClass();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        long long18 = month17.getFirstMillisecond();
        java.util.Date date19 = month17.getEnd();
        java.util.TimeZone timeZone20 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date19, timeZone20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date19);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date19);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean26 = timeSeries25.getNotify();
        java.util.List list27 = timeSeries25.getItems();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(9);
        long long30 = year29.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean33 = timeSeries32.getNotify();
        long long34 = timeSeries32.getMaximumItemAge();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(9);
        long long37 = year36.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year36, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) year29, (org.jfree.data.time.RegularTimePeriod) year36);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        long long42 = month41.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries40.getDataItem((org.jfree.data.time.RegularTimePeriod) month41);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj46 = seriesChangeEvent45.getSource();
        java.lang.Object obj47 = seriesChangeEvent45.getSource();
        java.lang.String str48 = seriesChangeEvent45.toString();
        boolean boolean49 = month41.equals((java.lang.Object) str48);
        boolean boolean50 = day23.equals((java.lang.Object) boolean49);
        int int51 = day23.getYear();
        java.lang.String str52 = day23.toString();
        org.jfree.data.time.SerialDate serialDate53 = day23.getSerialDate();
        int int54 = year11.compareTo((java.lang.Object) day23);
        long long55 = day23.getFirstMillisecond();
        long long56 = day23.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61867512000001L) + "'", long12 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1559372400000L + "'", long18 == 1559372400000L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-61883280000000L) + "'", long30 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 9223372036854775807L + "'", long34 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-61867512000001L) + "'", long37 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1559372400000L + "'", long42 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + obj46 + "' != '" + 100L + "'", obj46.equals(100L));
        org.junit.Assert.assertTrue("'" + obj47 + "' != '" + 100L + "'", obj47.equals(100L));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str48.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "30-June-2019" + "'", str52.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1561878000000L + "'", long55 == 1561878000000L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 43646L + "'", long56 == 43646L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(9);
        long long5 = year4.getMiddleMillisecond();
        long long6 = year4.getSerialIndex();
        java.util.Date date7 = year4.getEnd();
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone8);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.previous();
        java.util.Date date14 = regularTimePeriod13.getStart();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14);
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date14, timeZone17);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61867512000001L) + "'", long5 == (-61867512000001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9L + "'", long6 == 9L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod18);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(9);
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean9 = timeSeries8.getNotify();
        long long10 = timeSeries8.getMaximumItemAge();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(9);
        long long13 = year12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year5, (org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        long long18 = month17.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj22 = seriesChangeEvent21.getSource();
        java.lang.Object obj23 = seriesChangeEvent21.getSource();
        java.lang.String str24 = seriesChangeEvent21.toString();
        boolean boolean25 = month17.equals((java.lang.Object) str24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month17.previous();
        long long27 = month17.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61883280000000L) + "'", long6 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61867512000001L) + "'", long13 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1559372400000L + "'", long18 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + obj22 + "' != '" + 100L + "'", obj22.equals(100L));
        org.junit.Assert.assertTrue("'" + obj23 + "' != '" + 100L + "'", obj23.equals(100L));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str24.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Value");
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        java.lang.String str4 = timeSeries1.getDescription();
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month8, (double) 1559372400000L, false);
        long long12 = month8.getLastMillisecond();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
        java.lang.Class<?> wildcardClass15 = regularTimePeriod14.getClass();
        int int16 = month8.compareTo((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        java.util.Date date20 = year18.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        int int22 = month8.compareTo((java.lang.Object) year21);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        long long3 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, 0.0d);
        java.lang.Comparable comparable8 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean11 = timeSeries10.getNotify();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean14 = timeSeries13.getNotify();
        long long15 = timeSeries13.getMaximumItemAge();
        java.util.Collection collection16 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.addAndOrUpdate(timeSeries13);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.next();
        long long20 = year18.getMiddleMillisecond();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (-1.0f));
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeries1.getTimePeriod((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0f + "'", comparable8.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1562097599999L + "'", long20 == 1562097599999L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries1.setKey((java.lang.Comparable) (-1));
        timeSeries1.setKey((java.lang.Comparable) 8);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean10 = timeSeries9.getNotify();
        java.util.List list11 = timeSeries9.getItems();
        java.lang.String str12 = timeSeries9.getDescription();
        java.lang.String str13 = timeSeries9.getRangeDescription();
        timeSeries9.setDomainDescription("hi!");
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 1559372400000L, false);
        long long20 = month16.getLastMillisecond();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.previous();
        java.lang.Class<?> wildcardClass23 = regularTimePeriod22.getClass();
        int int24 = month16.compareTo((java.lang.Object) regularTimePeriod22);
        long long25 = month16.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month16, (java.lang.Number) 0.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries1.addOrUpdate(timeSeriesDataItem27);
        boolean boolean29 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemAge(1560182669669L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        java.lang.String str4 = timeSeries1.getDescription();
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.lang.String str6 = timeSeries1.getDescription();
        timeSeries1.setKey((java.lang.Comparable) (short) 10);
        org.jfree.data.time.Month month10 = org.jfree.data.time.Month.parseMonth("May 2019");
        int int11 = month10.getYearValue();
        int int12 = month10.getYearValue();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
        java.lang.Class<?> wildcardClass15 = regularTimePeriod14.getClass();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        long long17 = month16.getFirstMillisecond();
        java.util.Date date18 = month16.getEnd();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date18, timeZone19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date18);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date18);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month10, (org.jfree.data.time.RegularTimePeriod) month23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month23.next();
        long long26 = month23.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(month10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1561964399999L + "'", long26 == 1561964399999L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) (short) 10);
        timeSeriesDataItem3.setValue((java.lang.Number) (short) -1);
        timeSeriesDataItem3.setSelected(true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries1.setKey((java.lang.Comparable) (-1));
        timeSeries1.setKey((java.lang.Comparable) 8);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean10 = timeSeries9.getNotify();
        java.util.List list11 = timeSeries9.getItems();
        java.lang.String str12 = timeSeries9.getDescription();
        java.lang.String str13 = timeSeries9.getRangeDescription();
        timeSeries9.setDomainDescription("hi!");
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 1559372400000L, false);
        long long20 = month16.getLastMillisecond();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.previous();
        java.lang.Class<?> wildcardClass23 = regularTimePeriod22.getClass();
        int int24 = month16.compareTo((java.lang.Object) regularTimePeriod22);
        long long25 = month16.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month16, (java.lang.Number) 0.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries1.addOrUpdate(timeSeriesDataItem27);
        timeSeries1.removeAgedItems(0L, true);
        try {
            timeSeries1.delete((int) (short) 0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        java.lang.Class<?> wildcardClass4 = month0.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(regularTimePeriod8);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries1.setKey((java.lang.Comparable) (-1));
        int int4 = timeSeries1.getMaximumItemCount();
        try {
            timeSeries1.delete((int) '#', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries(comparable0, "org.jfree.data.event.SeriesChangeEvent[source=true]", "org.jfree.data.event.SeriesChangeEvent[source=org.jfree.data.event.SeriesChangeEvent[source=100]]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean5 = timeSeries4.getNotify();
        long long6 = timeSeries4.getMaximumItemAge();
        java.util.Collection collection7 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean10 = timeSeries9.getNotify();
        long long11 = timeSeries9.getMaximumItemAge();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year13, 0.0d);
        long long16 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year13, (double) 9L);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean24 = timeSeries23.getNotify();
        java.util.List list25 = timeSeries23.getItems();
        java.lang.String str26 = timeSeries23.getDescription();
        java.lang.String str27 = timeSeries23.getRangeDescription();
        timeSeries23.setDomainDescription("hi!");
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) month30, (double) 1559372400000L, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month30, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        long long38 = month37.getFirstMillisecond();
        java.lang.Object obj39 = null;
        boolean boolean40 = month37.equals(obj39);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean40, "", "Value");
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
        timeSeries43.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 2019, false);
        boolean boolean48 = fixedMillisecond35.equals((java.lang.Object) 2019);
        java.util.Date date49 = fixedMillisecond35.getEnd();
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month(date49);
        int int51 = month50.getYearValue();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62135740800000L) + "'", long16 == (-62135740800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Value" + "'", str27.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1559372400000L + "'", long38 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1969 + "'", int51 == 1969);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) "org.jfree.data.event.SeriesChangeEvent[source=100]");
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.String str3 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=org.jfree.data.event.SeriesChangeEvent[source=100]]" + "'", str2.equals("org.jfree.data.event.SeriesChangeEvent[source=org.jfree.data.event.SeriesChangeEvent[source=100]]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=org.jfree.data.event.SeriesChangeEvent[source=100]]" + "'", str3.equals("org.jfree.data.event.SeriesChangeEvent[source=org.jfree.data.event.SeriesChangeEvent[source=100]]"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean9 = timeSeries8.getNotify();
        long long10 = timeSeries8.getMaximumItemAge();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, 0.0d);
        boolean boolean16 = timeSeries8.equals((java.lang.Object) (byte) 100);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries8.addPropertyChangeListener(propertyChangeListener17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        long long20 = month19.getFirstMillisecond();
        java.util.Date date21 = month19.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21);
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day23);
        timeSeries8.setNotify(true);
        int int27 = day4.compareTo((java.lang.Object) true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day4.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1559372400000L + "'", long20 == 1559372400000L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        java.lang.String str4 = timeSeries1.getDescription();
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.lang.String str6 = timeSeries1.getDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries1.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        java.lang.Class<?> wildcardClass12 = regularTimePeriod11.getClass();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        long long14 = month13.getFirstMillisecond();
        java.util.Date date15 = month13.getEnd();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date15, timeZone16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date15);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date15);
        int int20 = year9.compareTo((java.lang.Object) day19);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (-1L));
        java.util.Calendar calendar23 = null;
        try {
            year9.peg(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1559372400000L + "'", long14 == 1559372400000L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean5 = timeSeries4.getNotify();
        long long6 = timeSeries4.getMaximumItemAge();
        java.util.Collection collection7 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean10 = timeSeries9.getNotify();
        java.util.List list11 = timeSeries9.getItems();
        java.lang.String str12 = timeSeries9.getDescription();
        java.lang.String str13 = timeSeries9.getRangeDescription();
        timeSeries9.setDomainDescription("hi!");
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 1559372400000L, false);
        long long20 = month16.getLastMillisecond();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.previous();
        java.lang.Class<?> wildcardClass23 = regularTimePeriod22.getClass();
        int int24 = month16.compareTo((java.lang.Object) regularTimePeriod22);
        long long25 = month16.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month16.previous();
        java.lang.Number number27 = null;
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month16, number27);
        org.jfree.data.time.Year year29 = month16.getYear();
        java.util.Date date30 = year29.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(year29);
        org.junit.Assert.assertNotNull(date30);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        java.lang.String str4 = timeSeries1.getDescription();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        long long6 = month5.getFirstMillisecond();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date7);
        int int9 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        long long11 = month10.getFirstMillisecond();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries1.addOrUpdate(regularTimePeriod13, (double) 1560182639870L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1559372400000L + "'", long6 == 1559372400000L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1559372400000L + "'", long11 == 1559372400000L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.lang.Class<?> wildcardClass2 = regularTimePeriod1.getClass();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        long long4 = month3.getFirstMillisecond();
        java.util.Date date5 = month3.getEnd();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date5, timeZone6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean12 = timeSeries11.getNotify();
        java.util.List list13 = timeSeries11.getItems();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(9);
        long long16 = year15.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean19 = timeSeries18.getNotify();
        long long20 = timeSeries18.getMaximumItemAge();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(9);
        long long23 = year22.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year22, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) year15, (org.jfree.data.time.RegularTimePeriod) year22);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        long long28 = month27.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries26.getDataItem((org.jfree.data.time.RegularTimePeriod) month27);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj32 = seriesChangeEvent31.getSource();
        java.lang.Object obj33 = seriesChangeEvent31.getSource();
        java.lang.String str34 = seriesChangeEvent31.toString();
        boolean boolean35 = month27.equals((java.lang.Object) str34);
        boolean boolean36 = day9.equals((java.lang.Object) boolean35);
        boolean boolean38 = day9.equals((java.lang.Object) 1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent40 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) true);
        java.lang.String str41 = seriesChangeEvent40.toString();
        int int42 = day9.compareTo((java.lang.Object) str41);
        long long43 = day9.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61883280000000L) + "'", long16 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61867512000001L) + "'", long23 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1559372400000L + "'", long28 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + obj32 + "' != '" + 100L + "'", obj32.equals(100L));
        org.junit.Assert.assertTrue("'" + obj33 + "' != '" + 100L + "'", obj33.equals(100L));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str34.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=true]" + "'", str41.equals("org.jfree.data.event.SeriesChangeEvent[source=true]"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 43646L + "'", long43 == 43646L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.lang.Class<?> wildcardClass2 = regularTimePeriod1.getClass();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        long long4 = month3.getFirstMillisecond();
        java.util.Date date5 = month3.getEnd();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date5, timeZone6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date5);
        java.util.Date date9 = fixedMillisecond8.getEnd();
        long long10 = fixedMillisecond8.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test164");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        boolean boolean2 = timeSeries1.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        boolean boolean5 = timeSeries4.getNotify();
//        long long6 = timeSeries4.getMaximumItemAge();
//        java.util.Collection collection7 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries4);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        boolean boolean10 = timeSeries9.getNotify();
//        java.util.List list11 = timeSeries9.getItems();
//        java.lang.String str12 = timeSeries9.getDescription();
//        java.lang.String str13 = timeSeries9.getRangeDescription();
//        timeSeries9.setDomainDescription("hi!");
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 1559372400000L, false);
//        long long20 = month16.getLastMillisecond();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.previous();
//        java.lang.Class<?> wildcardClass23 = regularTimePeriod22.getClass();
//        int int24 = month16.compareTo((java.lang.Object) regularTimePeriod22);
//        long long25 = month16.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month16.previous();
//        java.lang.Number number27 = null;
//        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month16, number27);
//        timeSeries4.removeAgedItems(0L, false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean34 = fixedMillisecond32.equals((java.lang.Object) "Value");
//        java.lang.Number number35 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
//        long long36 = fixedMillisecond32.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(collection7);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(list11);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNull(number35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560182687382L + "'", long36 == 1560182687382L);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(9);
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean9 = timeSeries8.getNotify();
        long long10 = timeSeries8.getMaximumItemAge();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(9);
        long long13 = year12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year5, (org.jfree.data.time.RegularTimePeriod) year12);
        timeSeries16.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean20 = timeSeries19.getNotify();
        long long21 = timeSeries19.getMaximumItemAge();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year23, 0.0d);
        java.lang.Comparable comparable26 = timeSeries19.getKey();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean29 = timeSeries28.getNotify();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean32 = timeSeries31.getNotify();
        long long33 = timeSeries31.getMaximumItemAge();
        java.util.Collection collection34 = timeSeries28.getTimePeriodsUniqueToOtherSeries(timeSeries31);
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries19.addAndOrUpdate(timeSeries31);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        long long37 = month36.getFirstMillisecond();
        java.lang.Object obj38 = null;
        boolean boolean39 = month36.equals(obj38);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean39, "", "Value");
        timeSeries42.removeAgedItems((long) (short) 100, false);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(9);
        long long48 = year47.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries42.getDataItem((org.jfree.data.time.RegularTimePeriod) year47);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year47, (double) 2147483647);
        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries16.addAndOrUpdate(timeSeries31);
        java.lang.String str53 = timeSeries31.getDescription();
        timeSeries31.setMaximumItemCount(0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61883280000000L) + "'", long6 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61867512000001L) + "'", long13 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + comparable26 + "' != '" + 100.0f + "'", comparable26.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775807L + "'", long33 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1559372400000L + "'", long37 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-61867512000001L) + "'", long48 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem49);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertNotNull(timeSeries52);
        org.junit.Assert.assertNull(str53);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.previous();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.previous();
        java.lang.Class<?> wildcardClass7 = regularTimePeriod6.getClass();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        long long9 = month8.getFirstMillisecond();
        java.util.Date date10 = month8.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date10, timeZone11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date10);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean17 = timeSeries16.getNotify();
        java.util.List list18 = timeSeries16.getItems();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(9);
        long long21 = year20.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean24 = timeSeries23.getNotify();
        long long25 = timeSeries23.getMaximumItemAge();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(9);
        long long28 = year27.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year27, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) year27);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        long long33 = month32.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries31.getDataItem((org.jfree.data.time.RegularTimePeriod) month32);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj37 = seriesChangeEvent36.getSource();
        java.lang.Object obj38 = seriesChangeEvent36.getSource();
        java.lang.String str39 = seriesChangeEvent36.toString();
        boolean boolean40 = month32.equals((java.lang.Object) str39);
        boolean boolean41 = day14.equals((java.lang.Object) boolean40);
        int int42 = day14.getYear();
        java.util.Date date43 = day14.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day14.previous();
        int int45 = year1.compareTo((java.lang.Object) day14);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
        long long49 = month48.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean52 = timeSeries51.getNotify();
        java.util.List list53 = timeSeries51.getItems();
        java.lang.String str54 = timeSeries51.getDescription();
        java.lang.String str55 = timeSeries51.getRangeDescription();
        timeSeries51.setDomainDescription("hi!");
        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month();
        timeSeries51.add((org.jfree.data.time.RegularTimePeriod) month58, (double) 1559372400000L, false);
        long long62 = month58.getLastMillisecond();
        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = month63.previous();
        java.lang.Class<?> wildcardClass65 = regularTimePeriod64.getClass();
        int int66 = month58.compareTo((java.lang.Object) regularTimePeriod64);
        long long67 = month58.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = month58.previous();
        boolean boolean70 = month58.equals((java.lang.Object) "org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries71 = timeSeries47.createCopy((org.jfree.data.time.RegularTimePeriod) month48, (org.jfree.data.time.RegularTimePeriod) month58);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = month48.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = month48.previous();
        boolean boolean74 = day14.equals((java.lang.Object) month48);
        java.util.Calendar calendar75 = null;
        try {
            day14.peg(calendar75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559372400000L + "'", long9 == 1559372400000L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61883280000000L) + "'", long21 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-61867512000001L) + "'", long28 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1559372400000L + "'", long33 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + obj37 + "' != '" + 100L + "'", obj37.equals(100L));
        org.junit.Assert.assertTrue("'" + obj38 + "' != '" + 100L + "'", obj38.equals(100L));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str39.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1559372400000L + "'", long49 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(list53);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Value" + "'", str55.equals("Value"));
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1561964399999L + "'", long62 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 24234L + "'", long67 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(timeSeries71);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.lang.Class<?> wildcardClass2 = regularTimePeriod1.getClass();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        long long4 = month3.getFirstMillisecond();
        java.util.Date date5 = month3.getEnd();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date5, timeZone6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.previous();
        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        long long15 = month14.getFirstMillisecond();
        java.util.Date date16 = month14.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date16, timeZone17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date16);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date16);
        int int21 = year10.compareTo((java.lang.Object) day20);
        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
        int int23 = day9.compareTo((java.lang.Object) day20);
        org.jfree.data.time.SerialDate serialDate24 = day20.getSerialDate();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1559372400000L + "'", long15 == 1559372400000L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(serialDate24);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean4 = timeSeries3.getNotify();
        java.util.List list5 = timeSeries3.getItems();
        java.lang.String str6 = timeSeries3.getDescription();
        java.lang.String str7 = timeSeries3.getRangeDescription();
        timeSeries3.setDomainDescription("hi!");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month10, (double) 1559372400000L, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (double) 6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (short) 100);
        long long18 = month10.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1559372400000L + "'", long18 == 1559372400000L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("May 2019");
        int int2 = month1.getMonth();
        org.junit.Assert.assertNotNull(month1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        long long2 = timeSeries1.getMaximumItemAge();
        java.util.Collection collection3 = timeSeries1.getTimePeriods();
        java.lang.Class<?> wildcardClass4 = timeSeries1.getClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean7 = timeSeries6.getNotify();
        java.util.List list8 = timeSeries6.getItems();
        java.lang.String str9 = timeSeries6.getDescription();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        long long11 = month10.getFirstMillisecond();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date12);
        int int14 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        int int16 = fixedMillisecond13.compareTo((java.lang.Object) 1559372400000L);
        java.lang.Number number17 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1559372400000L + "'", long11 == 1559372400000L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNull(number17);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean5 = timeSeries4.getNotify();
        long long6 = timeSeries4.getMaximumItemAge();
        java.util.Collection collection7 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries4);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries1);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean11 = timeSeries10.getNotify();
        java.util.List list12 = timeSeries10.getItems();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(9);
        long long15 = year14.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean18 = timeSeries17.getNotify();
        long long19 = timeSeries17.getMaximumItemAge();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(9);
        long long22 = year21.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year21, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) year14, (org.jfree.data.time.RegularTimePeriod) year21);
        timeSeries25.fireSeriesChanged();
        java.lang.Object obj27 = timeSeries25.clone();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean30 = timeSeries29.getNotify();
        long long31 = timeSeries29.getMaximumItemAge();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year33, 0.0d);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) 5);
        timeSeries29.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (java.lang.Number) 1560182596196L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (java.lang.Number) 1560182612123L);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (java.lang.Number) 1560182679486L, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61883280000000L) + "'", long15 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-61867512000001L) + "'", long22 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(9);
        long long2 = year1.getMiddleMillisecond();
        long long3 = year1.getSerialIndex();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        boolean boolean6 = year1.equals((java.lang.Object) seriesException5);
        long long7 = year1.getSerialIndex();
        long long8 = year1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61867512000001L) + "'", long2 == (-61867512000001L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9L + "'", long3 == 9L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9L + "'", long7 == 9L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61851744000001L) + "'", long8 == (-61851744000001L));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.event.SeriesChangeEvent[source=true]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.lang.Class<?> wildcardClass2 = regularTimePeriod1.getClass();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        long long4 = month3.getFirstMillisecond();
        java.util.Date date5 = month3.getEnd();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date5, timeZone6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries10.removeAgedItems(false);
        timeSeries10.clear();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean16 = timeSeries15.getNotify();
        java.util.List list17 = timeSeries15.getItems();
        java.lang.String str18 = timeSeries15.getDescription();
        java.lang.String str19 = timeSeries15.getRangeDescription();
        timeSeries15.setDomainDescription("hi!");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month22, (double) 1559372400000L, false);
        long long26 = month22.getLastMillisecond();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month27.previous();
        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
        int int30 = month22.compareTo((java.lang.Object) regularTimePeriod28);
        long long31 = month22.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 0.0d);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        int int36 = timeSeriesDataItem33.compareTo((java.lang.Object) fixedMillisecond35);
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (java.lang.Number) 1561878000000L);
        int int39 = fixedMillisecond8.compareTo((java.lang.Object) fixedMillisecond35);
        long long40 = fixedMillisecond35.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Value" + "'", str19.equals("Value"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1561964399999L + "'", long26 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 24234L + "'", long31 == 24234L);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean5 = timeSeries4.getNotify();
        long long6 = timeSeries4.getMaximumItemAge();
        java.util.Collection collection7 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean10 = timeSeries9.getNotify();
        long long11 = timeSeries9.getMaximumItemAge();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year13, 0.0d);
        long long16 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year13, (double) 9L);
        java.lang.Comparable comparable20 = timeSeries1.getKey();
        timeSeries1.removeAgedItems(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62135740800000L) + "'", long16 == (-62135740800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + 100.0f + "'", comparable20.equals(100.0f));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.Year year2 = month0.getYear();
        long long3 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean5 = timeSeries4.getNotify();
        long long6 = timeSeries4.getMaximumItemAge();
        java.util.Collection collection7 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries4);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries1);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        java.lang.String str12 = month9.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.Year year14 = month9.getYear();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean17 = timeSeries16.getNotify();
        long long18 = timeSeries16.getMaximumItemAge();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year20, 0.0d);
        java.lang.Comparable comparable23 = timeSeries16.getKey();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean26 = timeSeries25.getNotify();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean29 = timeSeries28.getNotify();
        long long30 = timeSeries28.getMaximumItemAge();
        java.util.Collection collection31 = timeSeries25.getTimePeriodsUniqueToOtherSeries(timeSeries28);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries16.addAndOrUpdate(timeSeries28);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean35 = timeSeries34.getNotify();
        java.util.List list36 = timeSeries34.getItems();
        java.lang.String str37 = timeSeries34.getDescription();
        timeSeries34.clear();
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries34.createCopy(0, 0);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        long long43 = month42.getFirstMillisecond();
        java.lang.Object obj44 = null;
        boolean boolean45 = month42.equals(obj44);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean45, "", "Value");
        timeSeries48.removeAgedItems((long) (short) 100, false);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(9);
        long long54 = year53.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries48.getDataItem((org.jfree.data.time.RegularTimePeriod) year53);
        long long56 = year53.getMiddleMillisecond();
        long long57 = year53.getSerialIndex();
        java.lang.Number number58 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries34.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year53, number58);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) 1577865599999L);
        boolean boolean62 = month9.equals((java.lang.Object) timeSeriesDataItem61);
        java.util.Calendar calendar63 = null;
        try {
            long long64 = month9.getFirstMillisecond(calendar63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "June 2019" + "'", str12.equals("June 2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + 100.0f + "'", comparable23.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1559372400000L + "'", long43 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-61867512000001L) + "'", long54 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem55);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-61867512000001L) + "'", long56 == (-61867512000001L));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 9L + "'", long57 == 9L);
        org.junit.Assert.assertNull(timeSeriesDataItem59);
        org.junit.Assert.assertNull(timeSeriesDataItem61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.previous();
        java.lang.Class<?> wildcardClass3 = regularTimePeriod2.getClass();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        long long5 = month4.getFirstMillisecond();
        java.util.Date date6 = month4.getEnd();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date6, timeZone7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date6);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date6);
        int int11 = year0.compareTo((java.lang.Object) day10);
        long long12 = year0.getMiddleMillisecond();
        int int13 = year0.getYear();
        long long14 = year0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.lang.Object obj2 = null;
        boolean boolean3 = month0.equals(obj2);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean3, "", "Value");
        boolean boolean7 = timeSeries6.isEmpty();
        timeSeries6.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean12 = timeSeries11.getNotify();
        java.util.List list13 = timeSeries11.getItems();
        java.lang.String str14 = timeSeries11.getDescription();
        java.lang.String str15 = timeSeries11.getRangeDescription();
        timeSeries11.setDomainDescription("hi!");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month18, (double) 1559372400000L, false);
        long long22 = month18.getLastMillisecond();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month23.previous();
        java.lang.Class<?> wildcardClass25 = regularTimePeriod24.getClass();
        int int26 = month18.compareTo((java.lang.Object) regularTimePeriod24);
        long long27 = month18.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 0.0d);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        int int32 = timeSeriesDataItem29.compareTo((java.lang.Object) fixedMillisecond31);
        timeSeries6.add(timeSeriesDataItem29);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean36 = timeSeries35.getNotify();
        java.util.List list37 = timeSeries35.getItems();
        java.lang.String str38 = timeSeries35.getDescription();
        java.lang.String str39 = timeSeries35.getRangeDescription();
        java.lang.Comparable comparable40 = timeSeries35.getKey();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        long long42 = month41.getFirstMillisecond();
        java.util.Date date43 = month41.getEnd();
        timeSeries35.add((org.jfree.data.time.RegularTimePeriod) month41, (double) (-1));
        java.lang.Number number46 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) month41);
        long long47 = month41.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Value" + "'", str15.equals("Value"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1561964399999L + "'", long22 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 24234L + "'", long27 == 24234L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Value" + "'", str39.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable40 + "' != '" + 100.0f + "'", comparable40.equals(100.0f));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1559372400000L + "'", long42 == 1559372400000L);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + 0.0d + "'", number46.equals(0.0d));
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1559372400000L + "'", long47 == 1559372400000L);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.lang.Class<?> wildcardClass2 = year0.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.previous();
        java.lang.Class<?> wildcardClass6 = regularTimePeriod5.getClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean9 = timeSeries8.getNotify();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean12 = timeSeries11.getNotify();
        long long13 = timeSeries11.getMaximumItemAge();
        java.util.Collection collection14 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean17 = timeSeries16.getNotify();
        long long18 = timeSeries16.getMaximumItemAge();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year20, 0.0d);
        long long23 = year20.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year20.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year20, (double) 9L);
        timeSeries8.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean31 = timeSeries30.getNotify();
        java.util.List list32 = timeSeries30.getItems();
        java.lang.String str33 = timeSeries30.getDescription();
        java.lang.String str34 = timeSeries30.getRangeDescription();
        timeSeries30.setDomainDescription("hi!");
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        timeSeries30.add((org.jfree.data.time.RegularTimePeriod) month37, (double) 1559372400000L, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) month37, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
        long long45 = month44.getFirstMillisecond();
        java.lang.Object obj46 = null;
        boolean boolean47 = month44.equals(obj46);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean47, "", "Value");
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond();
        timeSeries50.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51, (double) 2019, false);
        boolean boolean55 = fixedMillisecond42.equals((java.lang.Object) 2019);
        java.util.Date date56 = fixedMillisecond42.getEnd();
        java.util.TimeZone timeZone57 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date56, timeZone57);
        java.util.TimeZone timeZone59 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date56, timeZone59);
        java.util.TimeZone timeZone61 = null;
        try {
            org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date56, timeZone61);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62135740800000L) + "'", long23 == (-62135740800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Value" + "'", str34.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1559372400000L + "'", long45 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNull(regularTimePeriod60);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.previous();
        java.lang.Class<?> wildcardClass3 = regularTimePeriod2.getClass();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        long long5 = month4.getFirstMillisecond();
        java.util.Date date6 = month4.getEnd();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date6, timeZone7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date6);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date6);
        int int11 = year0.compareTo((java.lang.Object) day10);
        long long12 = year0.getLastMillisecond();
        int int13 = year0.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        boolean boolean2 = timeSeries1.getNotify();
//        long long3 = timeSeries1.getMaximumItemAge();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (short) 1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, 0.0d);
//        long long8 = year5.getFirstMillisecond();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        long long10 = month9.getFirstMillisecond();
//        java.lang.Object obj11 = null;
//        boolean boolean12 = month9.equals(obj11);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean12, "", "Value");
//        boolean boolean16 = timeSeries15.isEmpty();
//        timeSeries15.setDescription("");
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        boolean boolean21 = timeSeries20.getNotify();
//        java.util.List list22 = timeSeries20.getItems();
//        java.lang.String str23 = timeSeries20.getDescription();
//        java.lang.String str24 = timeSeries20.getRangeDescription();
//        timeSeries20.setDomainDescription("hi!");
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) month27, (double) 1559372400000L, false);
//        long long31 = month27.getLastMillisecond();
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month32.previous();
//        java.lang.Class<?> wildcardClass34 = regularTimePeriod33.getClass();
//        int int35 = month27.compareTo((java.lang.Object) regularTimePeriod33);
//        long long36 = month27.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) 0.0d);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
//        int int41 = timeSeriesDataItem38.compareTo((java.lang.Object) fixedMillisecond40);
//        timeSeries15.add(timeSeriesDataItem38);
//        boolean boolean43 = year5.equals((java.lang.Object) timeSeries15);
//        java.lang.Comparable comparable44 = timeSeries15.getKey();
//        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries15.createCopy(0, (int) (byte) 0);
//        timeSeries47.setRangeDescription("Mon Jun 10 09:03:52 PDT 2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean52 = fixedMillisecond50.equals((java.lang.Object) "Value");
//        java.util.Calendar calendar53 = null;
//        long long54 = fixedMillisecond50.getFirstMillisecond(calendar53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = fixedMillisecond50.next();
//        java.util.Calendar calendar56 = null;
//        long long57 = fixedMillisecond50.getMiddleMillisecond(calendar56);
//        boolean boolean58 = timeSeries47.equals((java.lang.Object) fixedMillisecond50);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62135740800000L) + "'", long8 == (-62135740800000L));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1559372400000L + "'", long10 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(list22);
//        org.junit.Assert.assertNull(str23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Value" + "'", str24.equals("Value"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1561964399999L + "'", long31 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 24234L + "'", long36 == 24234L);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + comparable44 + "' != '" + false + "'", comparable44.equals(false));
//        org.junit.Assert.assertNotNull(timeSeries47);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560182688511L + "'", long54 == 1560182688511L);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560182688511L + "'", long57 == 1560182688511L);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        java.lang.String str4 = timeSeries1.getDescription();
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.lang.String str6 = timeSeries1.getDescription();
        timeSeries1.setKey((java.lang.Comparable) (short) 10);
        boolean boolean9 = timeSeries1.getNotify();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.lang.Class<?> wildcardClass2 = regularTimePeriod1.getClass();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        long long4 = month3.getFirstMillisecond();
        java.util.Date date5 = month3.getEnd();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date5, timeZone6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date5);
        java.util.Date date9 = fixedMillisecond8.getEnd();
        java.util.TimeZone timeZone10 = null;
        java.util.Locale locale11 = null;
        try {
            org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date9, timeZone10, locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
        java.lang.String str2 = seriesException1.toString();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("Value");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException5);
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("Value");
        seriesException5.addSuppressed((java.lang.Throwable) seriesException8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: Value" + "'", str2.equals("org.jfree.data.general.SeriesException: Value"));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182599736L);
//        boolean boolean2 = timeSeries1.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean6 = fixedMillisecond4.equals((java.lang.Object) "Value");
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond4.getFirstMillisecond(calendar7);
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond4.peg(calendar9);
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
//        timeSeries1.setDescription("Wed Dec 31 16:00:00 PST 1969");
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) (short) 10);
//        boolean boolean18 = timeSeriesDataItem17.isSelected();
//        timeSeriesDataItem17.setValue((java.lang.Number) (byte) 10);
//        timeSeriesDataItem17.setSelected(false);
//        timeSeries1.add(timeSeriesDataItem17);
//        timeSeries1.setDescription("December 1969");
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560182688692L + "'", long8 == 1560182688692L);
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean5 = timeSeries4.getNotify();
        java.util.List list6 = timeSeries4.getItems();
        java.lang.String str7 = timeSeries4.getDescription();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month10.next();
        java.lang.String str13 = month10.toString();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month8, (org.jfree.data.time.RegularTimePeriod) month10);
        timeSeries14.setMaximumItemCount(100);
        boolean boolean17 = timeSeries14.isEmpty();
        timeSeries14.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "June 2019" + "'", str13.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) (short) 10);
        java.lang.Object obj4 = timeSeriesDataItem3.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeriesDataItem3.getPeriod();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(30);
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries1, seriesChangeInfo3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        long long6 = timeSeries5.getMaximumItemAge();
        java.util.Collection collection7 = timeSeries5.getTimePeriods();
        java.util.Collection collection8 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        timeSeries5.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean13 = timeSeries12.getNotify();
        java.util.List list14 = timeSeries12.getItems();
        java.lang.String str15 = timeSeries12.getDescription();
        java.lang.String str16 = timeSeries12.getRangeDescription();
        timeSeries12.setDomainDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean21 = timeSeries20.getNotify();
        java.util.List list22 = timeSeries20.getItems();
        java.lang.String str23 = timeSeries20.getDescription();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        long long25 = month24.getFirstMillisecond();
        java.util.Date date26 = month24.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(date26);
        int int28 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries12.addAndOrUpdate(timeSeries20);
        java.util.Collection collection30 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = timeSeries29.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Value" + "'", str16.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1559372400000L + "'", long25 == 1559372400000L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(collection30);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 5L + "'", long5 == 5L);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        java.lang.String str4 = timeSeries1.getDescription();
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.lang.String str6 = timeSeries1.getDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries1.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        java.lang.Class<?> wildcardClass12 = regularTimePeriod11.getClass();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        long long14 = month13.getFirstMillisecond();
        java.util.Date date15 = month13.getEnd();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date15, timeZone16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date15);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date15);
        int int20 = year9.compareTo((java.lang.Object) day19);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) (-1L));
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean25 = timeSeries24.getNotify();
        java.util.List list26 = timeSeries24.getItems();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(9);
        long long29 = year28.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean32 = timeSeries31.getNotify();
        long long33 = timeSeries31.getMaximumItemAge();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(9);
        long long36 = year35.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year35, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) year28, (org.jfree.data.time.RegularTimePeriod) year35);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
        long long41 = month40.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries39.getDataItem((org.jfree.data.time.RegularTimePeriod) month40);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent44 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj45 = seriesChangeEvent44.getSource();
        java.lang.Object obj46 = seriesChangeEvent44.getSource();
        java.lang.String str47 = seriesChangeEvent44.toString();
        boolean boolean48 = month40.equals((java.lang.Object) str47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month40.previous();
        java.lang.String str50 = month40.toString();
        boolean boolean51 = year9.equals((java.lang.Object) month40);
        long long52 = year9.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1559372400000L + "'", long14 == 1559372400000L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61883280000000L) + "'", long29 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775807L + "'", long33 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-61867512000001L) + "'", long36 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1559372400000L + "'", long41 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + obj45 + "' != '" + 100L + "'", obj45.equals(100L));
        org.junit.Assert.assertTrue("'" + obj46 + "' != '" + 100L + "'", obj46.equals(100L));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str47.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "June 2019" + "'", str50.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 2019L + "'", long52 == 2019L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(9);
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean9 = timeSeries8.getNotify();
        long long10 = timeSeries8.getMaximumItemAge();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(9);
        long long13 = year12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year5, (org.jfree.data.time.RegularTimePeriod) year12);
        timeSeries16.setKey((java.lang.Comparable) (short) 10);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener19);
        timeSeries16.setMaximumItemAge(10L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61883280000000L) + "'", long6 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61867512000001L) + "'", long13 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(timeSeries16);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Mon Jun 10 09:03:58 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.util.Date date2 = month0.getEnd();
        long long3 = month0.getSerialIndex();
        long long4 = month0.getLastMillisecond();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        timeSeries1.setNotify(true);
        java.lang.Class class6 = timeSeries1.getTimePeriodClass();
        try {
            timeSeries1.delete(7, 2, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(class6);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        long long3 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, 0.0d);
        java.lang.Comparable comparable8 = timeSeries1.getKey();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean11 = timeSeries10.getNotify();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean14 = timeSeries13.getNotify();
        long long15 = timeSeries13.getMaximumItemAge();
        java.util.Collection collection16 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.addAndOrUpdate(timeSeries13);
        java.util.List list18 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean21 = timeSeries20.getNotify();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean24 = timeSeries23.getNotify();
        long long25 = timeSeries23.getMaximumItemAge();
        java.util.Collection collection26 = timeSeries20.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean29 = timeSeries28.getNotify();
        long long30 = timeSeries28.getMaximumItemAge();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year32, 0.0d);
        long long35 = year32.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year32.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year32, (double) 9L);
        timeSeries20.removeAgedItems(false);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        long long42 = month41.getFirstMillisecond();
        java.lang.Object obj43 = null;
        boolean boolean44 = month41.equals(obj43);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean44, "", "Value");
        long long48 = timeSeries47.getMaximumItemAge();
        boolean boolean50 = timeSeries47.equals((java.lang.Object) 1L);
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries20.addAndOrUpdate(timeSeries47);
        java.lang.String str52 = timeSeries47.getDescription();
        timeSeries47.setRangeDescription("Value");
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries1.addAndOrUpdate(timeSeries47);
        timeSeries1.setDomainDescription("");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100.0f + "'", comparable8.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62135740800000L) + "'", long35 == (-62135740800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1559372400000L + "'", long42 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 9223372036854775807L + "'", long48 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertNotNull(timeSeries55);
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test200");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getFirstMillisecond();
//        java.lang.Object obj2 = null;
//        boolean boolean3 = month0.equals(obj2);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean3, "", "Value");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 2019, false);
//        java.lang.Object obj11 = null;
//        boolean boolean12 = fixedMillisecond7.equals(obj11);
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond7.getFirstMillisecond(calendar13);
//        java.util.Date date15 = fixedMillisecond7.getEnd();
//        java.util.TimeZone timeZone16 = null;
//        try {
//            org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15, timeZone16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560182689304L + "'", long14 == 1560182689304L);
//        org.junit.Assert.assertNotNull(date15);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(9);
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean9 = timeSeries8.getNotify();
        long long10 = timeSeries8.getMaximumItemAge();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(9);
        long long13 = year12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year5, (org.jfree.data.time.RegularTimePeriod) year12);
        timeSeries1.removeAgedItems(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61883280000000L) + "'", long6 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61867512000001L) + "'", long13 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(timeSeries16);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries1.setKey((java.lang.Comparable) (-1));
        timeSeries1.setKey((java.lang.Comparable) 8);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean10 = timeSeries9.getNotify();
        java.util.List list11 = timeSeries9.getItems();
        java.lang.String str12 = timeSeries9.getDescription();
        java.lang.String str13 = timeSeries9.getRangeDescription();
        timeSeries9.setDomainDescription("hi!");
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 1559372400000L, false);
        long long20 = month16.getLastMillisecond();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.previous();
        java.lang.Class<?> wildcardClass23 = regularTimePeriod22.getClass();
        int int24 = month16.compareTo((java.lang.Object) regularTimePeriod22);
        long long25 = month16.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month16, (java.lang.Number) 0.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries1.addOrUpdate(timeSeriesDataItem27);
        timeSeries1.removeAgedItems(0L, true);
        int int32 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2147483647 + "'", int32 == 2147483647);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(9999, 4, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        long long6 = timeSeries5.getMaximumItemAge();
        java.util.Collection collection7 = timeSeries5.getTimePeriods();
        java.util.Collection collection8 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        timeSeries5.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean13 = timeSeries12.getNotify();
        java.util.List list14 = timeSeries12.getItems();
        java.lang.String str15 = timeSeries12.getDescription();
        java.lang.String str16 = timeSeries12.getRangeDescription();
        timeSeries12.setDomainDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean21 = timeSeries20.getNotify();
        java.util.List list22 = timeSeries20.getItems();
        java.lang.String str23 = timeSeries20.getDescription();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        long long25 = month24.getFirstMillisecond();
        java.util.Date date26 = month24.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(date26);
        int int28 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries12.addAndOrUpdate(timeSeries20);
        java.util.Collection collection30 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        timeSeries29.setMaximumItemAge(1560182673713L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Value" + "'", str16.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1559372400000L + "'", long25 == 1559372400000L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(collection30);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean3 = timeSeries2.getNotify();
        long long4 = timeSeries2.getMaximumItemAge();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, 0.0d);
        java.lang.Comparable comparable9 = timeSeries2.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean12 = timeSeries11.getNotify();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean15 = timeSeries14.getNotify();
        long long16 = timeSeries14.getMaximumItemAge();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries2.addAndOrUpdate(timeSeries14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        long long20 = month19.getFirstMillisecond();
        java.lang.Object obj21 = null;
        boolean boolean22 = month19.equals(obj21);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean22, "", "Value");
        timeSeries25.removeAgedItems((long) (short) 100, false);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(9);
        long long31 = year30.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries25.getDataItem((org.jfree.data.time.RegularTimePeriod) year30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year30, (double) 2147483647);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(5, year30);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month35);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year38, (java.lang.Number) (short) 10);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year42, (java.lang.Number) (short) 10);
        timeSeriesDataItem44.setSelected(true);
        int int47 = timeSeriesDataItem40.compareTo((java.lang.Object) true);
        boolean boolean48 = timeSeriesDataItem40.isSelected();
        timeSeriesDataItem40.setSelected(false);
        timeSeries36.add(timeSeriesDataItem40, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100.0f + "'", comparable9.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1559372400000L + "'", long20 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-61867512000001L) + "'", long31 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries1.setKey((java.lang.Comparable) (-1));
        timeSeries1.setKey((java.lang.Comparable) 8);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.addChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean10 = timeSeries9.getNotify();
        java.util.List list11 = timeSeries9.getItems();
        java.lang.String str12 = timeSeries9.getDescription();
        java.lang.String str13 = timeSeries9.getRangeDescription();
        timeSeries9.setDomainDescription("hi!");
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month16, (double) 1559372400000L, false);
        long long20 = month16.getLastMillisecond();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.previous();
        java.lang.Class<?> wildcardClass23 = regularTimePeriod22.getClass();
        int int24 = month16.compareTo((java.lang.Object) regularTimePeriod22);
        long long25 = month16.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month16, (java.lang.Number) 0.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries1.addOrUpdate(timeSeriesDataItem27);
        boolean boolean29 = timeSeries1.getNotify();
        java.lang.Object obj30 = null;
        boolean boolean31 = timeSeries1.equals(obj30);
        timeSeries1.removeAgedItems((-62119972800001L), true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.lang.Class<?> wildcardClass2 = regularTimePeriod1.getClass();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        long long4 = month3.getFirstMillisecond();
        java.util.Date date5 = month3.getEnd();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date5, timeZone6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean12 = timeSeries11.getNotify();
        java.util.List list13 = timeSeries11.getItems();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(9);
        long long16 = year15.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean19 = timeSeries18.getNotify();
        long long20 = timeSeries18.getMaximumItemAge();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(9);
        long long23 = year22.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year22, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) year15, (org.jfree.data.time.RegularTimePeriod) year22);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        long long28 = month27.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries26.getDataItem((org.jfree.data.time.RegularTimePeriod) month27);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj32 = seriesChangeEvent31.getSource();
        java.lang.Object obj33 = seriesChangeEvent31.getSource();
        java.lang.String str34 = seriesChangeEvent31.toString();
        boolean boolean35 = month27.equals((java.lang.Object) str34);
        boolean boolean36 = day9.equals((java.lang.Object) boolean35);
        int int37 = day9.getYear();
        int int38 = day9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day9.previous();
        java.lang.String str40 = day9.toString();
        org.jfree.data.time.SerialDate serialDate41 = day9.getSerialDate();
        org.jfree.data.time.SerialDate serialDate42 = day9.getSerialDate();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61883280000000L) + "'", long16 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61867512000001L) + "'", long23 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1559372400000L + "'", long28 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + obj32 + "' != '" + 100L + "'", obj32.equals(100L));
        org.junit.Assert.assertTrue("'" + obj33 + "' != '" + 100L + "'", obj33.equals(100L));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str34.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "30-June-2019" + "'", str40.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean5 = timeSeries4.getNotify();
        long long6 = timeSeries4.getMaximumItemAge();
        java.util.Collection collection7 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean10 = timeSeries9.getNotify();
        long long11 = timeSeries9.getMaximumItemAge();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year13, 0.0d);
        long long16 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year13, (double) 9L);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean24 = timeSeries23.getNotify();
        java.util.List list25 = timeSeries23.getItems();
        java.lang.String str26 = timeSeries23.getDescription();
        java.lang.String str27 = timeSeries23.getRangeDescription();
        timeSeries23.setDomainDescription("hi!");
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) month30, (double) 1559372400000L, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month30, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        long long37 = fixedMillisecond35.getMiddleMillisecond();
        long long38 = fixedMillisecond35.getLastMillisecond();
        java.util.Date date39 = fixedMillisecond35.getTime();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean42 = timeSeries41.getNotify();
        java.util.List list43 = timeSeries41.getItems();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(9);
        long long46 = year45.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean49 = timeSeries48.getNotify();
        long long50 = timeSeries48.getMaximumItemAge();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(9);
        long long53 = year52.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries48.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year52, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries41.createCopy((org.jfree.data.time.RegularTimePeriod) year45, (org.jfree.data.time.RegularTimePeriod) year52);
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month();
        long long58 = month57.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries56.getDataItem((org.jfree.data.time.RegularTimePeriod) month57);
        java.lang.String str60 = timeSeries56.getRangeDescription();
        boolean boolean61 = fixedMillisecond35.equals((java.lang.Object) timeSeries56);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent62 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) boolean61);
        java.lang.String str63 = seriesChangeEvent62.toString();
        java.lang.String str64 = seriesChangeEvent62.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62135740800000L) + "'", long16 == (-62135740800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Value" + "'", str27.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 5L + "'", long37 == 5L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 5L + "'", long38 == 5L);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-61883280000000L) + "'", long46 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 9223372036854775807L + "'", long50 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-61867512000001L) + "'", long53 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem55);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1559372400000L + "'", long58 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "Value" + "'", str60.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=false]" + "'", str63.equals("org.jfree.data.event.SeriesChangeEvent[source=false]"));
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=false]" + "'", str64.equals("org.jfree.data.event.SeriesChangeEvent[source=false]"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        long long3 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, 0.0d);
        boolean boolean9 = timeSeries1.equals((java.lang.Object) (byte) 100);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean14 = timeSeries13.getNotify();
        long long15 = timeSeries13.getMaximumItemAge();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year17, 0.0d);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 5);
        timeSeries13.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 1560182596196L);
        boolean boolean24 = timeSeries13.getNotify();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries1.addAndOrUpdate(timeSeries13);
        timeSeries13.setNotify(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(timeSeries25);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 28799999L + "'", long5 == 28799999L);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test211");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182599736L);
//        boolean boolean2 = timeSeries1.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean6 = fixedMillisecond4.equals((java.lang.Object) "Value");
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond4.getFirstMillisecond(calendar7);
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond4.peg(calendar9);
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        long long13 = month12.getFirstMillisecond();
//        java.util.Date date14 = month12.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day16, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem18);
//        timeSeries1.add(timeSeriesDataItem18, true);
//        java.lang.Object obj23 = timeSeriesDataItem18.clone();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560182690149L + "'", long8 == 1560182690149L);
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1559372400000L + "'", long13 == 1559372400000L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(obj23);
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.previous();
        java.lang.Class<?> wildcardClass3 = regularTimePeriod2.getClass();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        long long5 = month4.getFirstMillisecond();
        java.util.Date date6 = month4.getEnd();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date6, timeZone7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date6);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date6);
        int int11 = year0.compareTo((java.lang.Object) day10);
        int int12 = day10.getYear();
        int int13 = day10.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.lang.Number number3 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, number3);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        java.lang.String str4 = timeSeries1.getDescription();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.time.Year year7 = month5.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        int int9 = year7.getYear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        long long3 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, 0.0d);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 5);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 1560182596196L);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond9.getLastMillisecond(calendar12);
        java.util.Date date14 = fixedMillisecond9.getTime();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 5L + "'", long13 == 5L);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.lang.Class<?> wildcardClass2 = regularTimePeriod1.getClass();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        long long4 = month3.getFirstMillisecond();
        java.util.Date date5 = month3.getEnd();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date5, timeZone6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean12 = timeSeries11.getNotify();
        java.util.List list13 = timeSeries11.getItems();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(9);
        long long16 = year15.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean19 = timeSeries18.getNotify();
        long long20 = timeSeries18.getMaximumItemAge();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(9);
        long long23 = year22.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year22, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) year15, (org.jfree.data.time.RegularTimePeriod) year22);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        long long28 = month27.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries26.getDataItem((org.jfree.data.time.RegularTimePeriod) month27);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj32 = seriesChangeEvent31.getSource();
        java.lang.Object obj33 = seriesChangeEvent31.getSource();
        java.lang.String str34 = seriesChangeEvent31.toString();
        boolean boolean35 = month27.equals((java.lang.Object) str34);
        boolean boolean36 = day9.equals((java.lang.Object) boolean35);
        boolean boolean38 = day9.equals((java.lang.Object) 1);
        int int39 = day9.getDayOfMonth();
        long long40 = day9.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate41 = day9.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day9.previous();
        java.util.Calendar calendar43 = null;
        try {
            long long44 = day9.getFirstMillisecond(calendar43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61883280000000L) + "'", long16 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61867512000001L) + "'", long23 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1559372400000L + "'", long28 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + obj32 + "' != '" + 100L + "'", obj32.equals(100L));
        org.junit.Assert.assertTrue("'" + obj33 + "' != '" + 100L + "'", obj33.equals(100L));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str34.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 30 + "'", int39 == 30);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1561878000000L + "'", long40 == 1561878000000L);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        long long6 = timeSeries5.getMaximumItemAge();
        java.util.Collection collection7 = timeSeries5.getTimePeriods();
        java.util.Collection collection8 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        timeSeries5.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean13 = timeSeries12.getNotify();
        java.util.List list14 = timeSeries12.getItems();
        java.lang.String str15 = timeSeries12.getDescription();
        java.lang.String str16 = timeSeries12.getRangeDescription();
        timeSeries12.setDomainDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean21 = timeSeries20.getNotify();
        java.util.List list22 = timeSeries20.getItems();
        java.lang.String str23 = timeSeries20.getDescription();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        long long25 = month24.getFirstMillisecond();
        java.util.Date date26 = month24.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(date26);
        int int28 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries12.addAndOrUpdate(timeSeries20);
        java.util.Collection collection30 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        java.lang.String str31 = timeSeries29.getDomainDescription();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Value" + "'", str16.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1559372400000L + "'", long25 == 1559372400000L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Time" + "'", str31.equals("Time"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        long long3 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, 0.0d);
        long long8 = year5.getFirstMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        long long10 = month9.getFirstMillisecond();
        java.lang.Object obj11 = null;
        boolean boolean12 = month9.equals(obj11);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean12, "", "Value");
        boolean boolean16 = timeSeries15.isEmpty();
        timeSeries15.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean21 = timeSeries20.getNotify();
        java.util.List list22 = timeSeries20.getItems();
        java.lang.String str23 = timeSeries20.getDescription();
        java.lang.String str24 = timeSeries20.getRangeDescription();
        timeSeries20.setDomainDescription("hi!");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) month27, (double) 1559372400000L, false);
        long long31 = month27.getLastMillisecond();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month32.previous();
        java.lang.Class<?> wildcardClass34 = regularTimePeriod33.getClass();
        int int35 = month27.compareTo((java.lang.Object) regularTimePeriod33);
        long long36 = month27.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) 0.0d);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) (short) 0);
        int int41 = timeSeriesDataItem38.compareTo((java.lang.Object) fixedMillisecond40);
        timeSeries15.add(timeSeriesDataItem38);
        boolean boolean43 = year5.equals((java.lang.Object) timeSeries15);
        java.lang.Comparable comparable44 = timeSeries15.getKey();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean47 = timeSeries46.getNotify();
        long long48 = timeSeries46.getMaximumItemAge();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year50, 0.0d);
        long long53 = year50.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year50.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod54, (java.lang.Number) (short) -1);
        try {
            timeSeries15.add(regularTimePeriod54, (double) 1560182608424L, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62135740800000L) + "'", long8 == (-62135740800000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1559372400000L + "'", long10 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Value" + "'", str24.equals("Value"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1561964399999L + "'", long31 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 24234L + "'", long36 == 24234L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + comparable44 + "' != '" + false + "'", comparable44.equals(false));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 9223372036854775807L + "'", long48 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem52);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-62135740800000L) + "'", long53 == (-62135740800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod54);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("June 2019");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: June 2019" + "'", str2.equals("org.jfree.data.general.SeriesException: June 2019"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        java.lang.String str4 = timeSeries1.getDescription();
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.lang.String str6 = timeSeries1.getDescription();
        timeSeries1.setKey((java.lang.Comparable) (short) 10);
        org.jfree.data.time.Month month10 = org.jfree.data.time.Month.parseMonth("May 2019");
        int int11 = month10.getYearValue();
        int int12 = month10.getYearValue();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
        java.lang.Class<?> wildcardClass15 = regularTimePeriod14.getClass();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        long long17 = month16.getFirstMillisecond();
        java.util.Date date18 = month16.getEnd();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date18, timeZone19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date18);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date18);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month10, (org.jfree.data.time.RegularTimePeriod) month23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month23.next();
        java.lang.String str26 = month23.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(month10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "June 2019" + "'", str26.equals("June 2019"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean3 = timeSeries2.getNotify();
        long long4 = timeSeries2.getMaximumItemAge();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, 0.0d);
        java.lang.Comparable comparable9 = timeSeries2.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean12 = timeSeries11.getNotify();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean15 = timeSeries14.getNotify();
        long long16 = timeSeries14.getMaximumItemAge();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries2.addAndOrUpdate(timeSeries14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        long long20 = month19.getFirstMillisecond();
        java.lang.Object obj21 = null;
        boolean boolean22 = month19.equals(obj21);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean22, "", "Value");
        timeSeries25.removeAgedItems((long) (short) 100, false);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(9);
        long long31 = year30.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries25.getDataItem((org.jfree.data.time.RegularTimePeriod) year30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year30, (double) 2147483647);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(5, year30);
        long long36 = year30.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean39 = timeSeries38.getNotify();
        java.util.List list40 = timeSeries38.getItems();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(9);
        long long43 = year42.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean46 = timeSeries45.getNotify();
        long long47 = timeSeries45.getMaximumItemAge();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(9);
        long long50 = year49.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries45.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year49, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries38.createCopy((org.jfree.data.time.RegularTimePeriod) year42, (org.jfree.data.time.RegularTimePeriod) year49);
        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month();
        long long55 = month54.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries53.getDataItem((org.jfree.data.time.RegularTimePeriod) month54);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent58 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj59 = seriesChangeEvent58.getSource();
        java.lang.Object obj60 = seriesChangeEvent58.getSource();
        java.lang.String str61 = seriesChangeEvent58.toString();
        boolean boolean62 = month54.equals((java.lang.Object) str61);
        boolean boolean64 = month54.equals((java.lang.Object) 1L);
        long long65 = month54.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = month54.previous();
        int int67 = year30.compareTo((java.lang.Object) regularTimePeriod66);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100.0f + "'", comparable9.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1559372400000L + "'", long20 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-61867512000001L) + "'", long31 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-61883280000000L) + "'", long36 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-61883280000000L) + "'", long43 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 9223372036854775807L + "'", long47 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-61867512000001L) + "'", long50 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem52);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1559372400000L + "'", long55 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem56);
        org.junit.Assert.assertTrue("'" + obj59 + "' != '" + 100L + "'", obj59.equals(100L));
        org.junit.Assert.assertTrue("'" + obj60 + "' != '" + 100L + "'", obj60.equals(100L));
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str61.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 24234L + "'", long65 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean5 = timeSeries4.getNotify();
        long long6 = timeSeries4.getMaximumItemAge();
        java.util.Collection collection7 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean10 = timeSeries9.getNotify();
        long long11 = timeSeries9.getMaximumItemAge();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year13, 0.0d);
        long long16 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year13, (double) 9L);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean24 = timeSeries23.getNotify();
        java.util.List list25 = timeSeries23.getItems();
        java.lang.String str26 = timeSeries23.getDescription();
        java.lang.String str27 = timeSeries23.getRangeDescription();
        timeSeries23.setDomainDescription("hi!");
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) month30, (double) 1559372400000L, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month30, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        long long38 = month37.getFirstMillisecond();
        java.lang.Object obj39 = null;
        boolean boolean40 = month37.equals(obj39);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean40, "", "Value");
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
        timeSeries43.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 2019, false);
        boolean boolean48 = fixedMillisecond35.equals((java.lang.Object) 2019);
        java.util.Date date49 = fixedMillisecond35.getEnd();
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month(date49);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(date49);
        java.util.TimeZone timeZone52 = null;
        try {
            org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date49, timeZone52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62135740800000L) + "'", long16 == (-62135740800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Value" + "'", str27.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1559372400000L + "'", long38 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(date49);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        java.lang.String str4 = timeSeries1.getDescription();
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month8, (double) 1559372400000L, false);
        long long12 = month8.getLastMillisecond();
        org.jfree.data.time.Year year13 = month8.getYear();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.next();
        java.lang.Class<?> wildcardClass16 = year14.getClass();
        boolean boolean17 = year13.equals((java.lang.Object) year14);
        java.util.Calendar calendar18 = null;
        try {
            year13.peg(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.lang.Object obj2 = null;
        boolean boolean3 = month0.equals(obj2);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean3, "", "Value");
        boolean boolean7 = timeSeries6.isEmpty();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        long long9 = month8.getFirstMillisecond();
        java.lang.Object obj10 = null;
        boolean boolean11 = month8.equals(obj10);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean11, "", "Value");
        timeSeries14.removeAgedItems((long) (short) 100, false);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(9);
        long long20 = year19.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) year19);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month22.previous();
        java.lang.Class<?> wildcardClass24 = regularTimePeriod23.getClass();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        long long26 = month25.getFirstMillisecond();
        java.util.Date date27 = month25.getEnd();
        java.util.TimeZone timeZone28 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date27, timeZone28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond(date27);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date27);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean34 = timeSeries33.getNotify();
        java.util.List list35 = timeSeries33.getItems();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(9);
        long long38 = year37.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean41 = timeSeries40.getNotify();
        long long42 = timeSeries40.getMaximumItemAge();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(9);
        long long45 = year44.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year44, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) year37, (org.jfree.data.time.RegularTimePeriod) year44);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
        long long50 = month49.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries48.getDataItem((org.jfree.data.time.RegularTimePeriod) month49);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent53 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj54 = seriesChangeEvent53.getSource();
        java.lang.Object obj55 = seriesChangeEvent53.getSource();
        java.lang.String str56 = seriesChangeEvent53.toString();
        boolean boolean57 = month49.equals((java.lang.Object) str56);
        boolean boolean58 = day31.equals((java.lang.Object) boolean57);
        int int59 = day31.getYear();
        java.lang.String str60 = day31.toString();
        org.jfree.data.time.SerialDate serialDate61 = day31.getSerialDate();
        int int62 = year19.compareTo((java.lang.Object) day31);
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = year64.previous();
        java.util.Date date66 = year64.getStart();
        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) day31, (org.jfree.data.time.RegularTimePeriod) year64);
        int int68 = day31.getYear();
        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean71 = timeSeries70.getNotify();
        java.util.List list72 = timeSeries70.getItems();
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(9);
        long long75 = year74.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries77 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean78 = timeSeries77.getNotify();
        long long79 = timeSeries77.getMaximumItemAge();
        org.jfree.data.time.Year year81 = new org.jfree.data.time.Year(9);
        long long82 = year81.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem84 = timeSeries77.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year81, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries85 = timeSeries70.createCopy((org.jfree.data.time.RegularTimePeriod) year74, (org.jfree.data.time.RegularTimePeriod) year81);
        org.jfree.data.time.Month month86 = new org.jfree.data.time.Month();
        long long87 = month86.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem88 = timeSeries85.getDataItem((org.jfree.data.time.RegularTimePeriod) month86);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent90 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj91 = seriesChangeEvent90.getSource();
        java.lang.Object obj92 = seriesChangeEvent90.getSource();
        java.lang.String str93 = seriesChangeEvent90.toString();
        boolean boolean94 = month86.equals((java.lang.Object) str93);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = month86.previous();
        java.lang.String str96 = month86.toString();
        long long97 = month86.getSerialIndex();
        int int98 = day31.compareTo((java.lang.Object) month86);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559372400000L + "'", long9 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61867512000001L) + "'", long20 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1559372400000L + "'", long26 == 1559372400000L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-61883280000000L) + "'", long38 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 9223372036854775807L + "'", long42 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-61867512000001L) + "'", long45 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1559372400000L + "'", long50 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertTrue("'" + obj54 + "' != '" + 100L + "'", obj54.equals(100L));
        org.junit.Assert.assertTrue("'" + obj55 + "' != '" + 100L + "'", obj55.equals(100L));
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str56.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "30-June-2019" + "'", str60.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(timeSeries67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 2019 + "'", int68 == 2019);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(list72);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-61883280000000L) + "'", long75 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 9223372036854775807L + "'", long79 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-61867512000001L) + "'", long82 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem84);
        org.junit.Assert.assertNotNull(timeSeries85);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 1559372400000L + "'", long87 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem88);
        org.junit.Assert.assertTrue("'" + obj91 + "' != '" + 100L + "'", obj91.equals(100L));
        org.junit.Assert.assertTrue("'" + obj92 + "' != '" + 100L + "'", obj92.equals(100L));
        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str93.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod95);
        org.junit.Assert.assertTrue("'" + str96 + "' != '" + "June 2019" + "'", str96.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long97 + "' != '" + 24234L + "'", long97 == 24234L);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 0 + "'", int98 == 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(9);
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean9 = timeSeries8.getNotify();
        long long10 = timeSeries8.getMaximumItemAge();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(9);
        long long13 = year12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year5, (org.jfree.data.time.RegularTimePeriod) year12);
        timeSeries16.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean20 = timeSeries19.getNotify();
        long long21 = timeSeries19.getMaximumItemAge();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year23, 0.0d);
        java.lang.Comparable comparable26 = timeSeries19.getKey();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean29 = timeSeries28.getNotify();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean32 = timeSeries31.getNotify();
        long long33 = timeSeries31.getMaximumItemAge();
        java.util.Collection collection34 = timeSeries28.getTimePeriodsUniqueToOtherSeries(timeSeries31);
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries19.addAndOrUpdate(timeSeries31);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        long long37 = month36.getFirstMillisecond();
        java.lang.Object obj38 = null;
        boolean boolean39 = month36.equals(obj38);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean39, "", "Value");
        timeSeries42.removeAgedItems((long) (short) 100, false);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(9);
        long long48 = year47.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries42.getDataItem((org.jfree.data.time.RegularTimePeriod) year47);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year47, (double) 2147483647);
        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries16.addAndOrUpdate(timeSeries31);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent54 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj55 = seriesChangeEvent54.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo56 = null;
        seriesChangeEvent54.setSummary(seriesChangeInfo56);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo58 = null;
        seriesChangeEvent54.setSummary(seriesChangeInfo58);
        java.lang.String str60 = seriesChangeEvent54.toString();
        boolean boolean61 = timeSeries31.equals((java.lang.Object) seriesChangeEvent54);
        java.lang.Object obj62 = seriesChangeEvent54.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo63 = null;
        seriesChangeEvent54.setSummary(seriesChangeInfo63);
        java.lang.Object obj65 = seriesChangeEvent54.getSource();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61883280000000L) + "'", long6 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61867512000001L) + "'", long13 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + comparable26 + "' != '" + 100.0f + "'", comparable26.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775807L + "'", long33 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1559372400000L + "'", long37 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-61867512000001L) + "'", long48 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem49);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertNotNull(timeSeries52);
        org.junit.Assert.assertTrue("'" + obj55 + "' != '" + 100L + "'", obj55.equals(100L));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str60.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + obj62 + "' != '" + 100L + "'", obj62.equals(100L));
        org.junit.Assert.assertTrue("'" + obj65 + "' != '" + 100L + "'", obj65.equals(100L));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean5 = timeSeries4.getNotify();
        long long6 = timeSeries4.getMaximumItemAge();
        java.util.Collection collection7 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean10 = timeSeries9.getNotify();
        long long11 = timeSeries9.getMaximumItemAge();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year13, 0.0d);
        long long16 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year13, (double) 9L);
        java.lang.Comparable comparable20 = timeSeries1.getKey();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.previous();
        java.lang.Class<?> wildcardClass23 = regularTimePeriod22.getClass();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        long long25 = month24.getFirstMillisecond();
        java.util.Date date26 = month24.getEnd();
        java.util.TimeZone timeZone27 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date26, timeZone27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date26);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond29.getFirstMillisecond(calendar30);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries34 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, regularTimePeriod33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62135740800000L) + "'", long16 == (-62135740800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + 100.0f + "'", comparable20.equals(100.0f));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1559372400000L + "'", long25 == 1559372400000L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1561964399999L + "'", long31 == 1561964399999L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(9);
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean9 = timeSeries8.getNotify();
        long long10 = timeSeries8.getMaximumItemAge();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(9);
        long long13 = year12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year5, (org.jfree.data.time.RegularTimePeriod) year12);
        timeSeries16.setKey((java.lang.Comparable) (short) 10);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        long long20 = month19.getFirstMillisecond();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        long long23 = month19.getLastMillisecond();
        long long24 = month19.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month19.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 1560182603095L);
        java.lang.String str28 = month19.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) (-9999));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61883280000000L) + "'", long6 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61867512000001L) + "'", long13 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1559372400000L + "'", long20 == 1559372400000L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1561964399999L + "'", long23 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1559372400000L + "'", long24 == 1559372400000L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "June 2019" + "'", str28.equals("June 2019"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        java.lang.String str4 = timeSeries1.getDescription();
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean10 = timeSeries9.getNotify();
        java.util.List list11 = timeSeries9.getItems();
        java.lang.String str12 = timeSeries9.getDescription();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        long long14 = month13.getFirstMillisecond();
        java.util.Date date15 = month13.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
        int int17 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries1.addAndOrUpdate(timeSeries9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries18.addChangeListener(seriesChangeListener19);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener21);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1559372400000L + "'", long14 == 1559372400000L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(timeSeries18);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(9);
        long long2 = year1.getMiddleMillisecond();
        long long3 = year1.getSerialIndex();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        boolean boolean6 = year1.equals((java.lang.Object) seriesException5);
        long long7 = year1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year1.next();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61867512000001L) + "'", long2 == (-61867512000001L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9L + "'", long3 == 9L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9L + "'", long7 == 9L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.previous();
        java.lang.Class<?> wildcardClass3 = regularTimePeriod2.getClass();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        long long5 = month4.getFirstMillisecond();
        java.util.Date date6 = month4.getEnd();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date6, timeZone7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date6);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date6);
        int int11 = year0.compareTo((java.lang.Object) day10);
        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
        long long13 = day10.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561878000000L + "'", long13 == 1561878000000L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        java.lang.String str4 = timeSeries1.getDescription();
        timeSeries1.clear();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.createCopy(0, 0);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 0);
        java.lang.Object obj10 = seriesChangeEvent9.getSource();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + obj10 + "' != '" + 0 + "'", obj10.equals(0));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(9);
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean9 = timeSeries8.getNotify();
        long long10 = timeSeries8.getMaximumItemAge();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(9);
        long long13 = year12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year5, (org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        long long18 = month17.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        java.lang.String str20 = timeSeries16.getRangeDescription();
        java.lang.Class<?> wildcardClass21 = timeSeries16.getClass();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean24 = timeSeries23.getNotify();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean27 = timeSeries26.getNotify();
        long long28 = timeSeries26.getMaximumItemAge();
        java.util.Collection collection29 = timeSeries23.getTimePeriodsUniqueToOtherSeries(timeSeries26);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean32 = timeSeries31.getNotify();
        long long33 = timeSeries31.getMaximumItemAge();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year35, 0.0d);
        long long38 = year35.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year35.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year35, (double) 9L);
        java.lang.Comparable comparable42 = timeSeries23.getKey();
        java.util.Collection collection43 = timeSeries16.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener44 = null;
        timeSeries23.removeChangeListener(seriesChangeListener44);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61883280000000L) + "'", long6 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61867512000001L) + "'", long13 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1559372400000L + "'", long18 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Value" + "'", str20.equals("Value"));
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 9223372036854775807L + "'", long28 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775807L + "'", long33 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-62135740800000L) + "'", long38 == (-62135740800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + comparable42 + "' != '" + 100.0f + "'", comparable42.equals(100.0f));
        org.junit.Assert.assertNotNull(collection43);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.lang.Class<?> wildcardClass2 = regularTimePeriod1.getClass();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        long long4 = month3.getFirstMillisecond();
        java.util.Date date5 = month3.getEnd();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date5, timeZone6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean12 = timeSeries11.getNotify();
        java.util.List list13 = timeSeries11.getItems();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(9);
        long long16 = year15.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean19 = timeSeries18.getNotify();
        long long20 = timeSeries18.getMaximumItemAge();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(9);
        long long23 = year22.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year22, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) year15, (org.jfree.data.time.RegularTimePeriod) year22);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        long long28 = month27.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries26.getDataItem((org.jfree.data.time.RegularTimePeriod) month27);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj32 = seriesChangeEvent31.getSource();
        java.lang.Object obj33 = seriesChangeEvent31.getSource();
        java.lang.String str34 = seriesChangeEvent31.toString();
        boolean boolean35 = month27.equals((java.lang.Object) str34);
        boolean boolean36 = day9.equals((java.lang.Object) boolean35);
        int int37 = day9.getYear();
        org.jfree.data.time.SerialDate serialDate38 = day9.getSerialDate();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61883280000000L) + "'", long16 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61867512000001L) + "'", long23 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1559372400000L + "'", long28 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + obj32 + "' != '" + 100L + "'", obj32.equals(100L));
        org.junit.Assert.assertTrue("'" + obj33 + "' != '" + 100L + "'", obj33.equals(100L));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str34.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
        org.junit.Assert.assertNotNull(serialDate38);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod1, (double) (-61883280000000L));
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean5 = timeSeries4.getNotify();
        long long6 = timeSeries4.getMaximumItemAge();
        java.util.Collection collection7 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean10 = timeSeries9.getNotify();
        long long11 = timeSeries9.getMaximumItemAge();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year13, 0.0d);
        long long16 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year13, (double) 9L);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean24 = timeSeries23.getNotify();
        java.util.List list25 = timeSeries23.getItems();
        java.lang.String str26 = timeSeries23.getDescription();
        java.lang.String str27 = timeSeries23.getRangeDescription();
        timeSeries23.setDomainDescription("hi!");
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) month30, (double) 1559372400000L, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month30, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        long long37 = fixedMillisecond35.getMiddleMillisecond();
        java.util.Calendar calendar38 = null;
        fixedMillisecond35.peg(calendar38);
        long long40 = fixedMillisecond35.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62135740800000L) + "'", long16 == (-62135740800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Value" + "'", str27.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 5L + "'", long37 == 5L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 5L + "'", long40 == 5L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean2 = timeSeries1.getNotify();
        java.util.List list3 = timeSeries1.getItems();
        java.lang.String str4 = timeSeries1.getDescription();
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.setDomainDescription("hi!");
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month8, (double) 1559372400000L, false);
        long long12 = month8.getLastMillisecond();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
        java.lang.Class<?> wildcardClass15 = regularTimePeriod14.getClass();
        int int16 = month8.compareTo((java.lang.Object) regularTimePeriod14);
        long long17 = month8.getSerialIndex();
        java.util.Date date18 = month8.getEnd();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean21 = timeSeries20.getNotify();
        java.util.List list22 = timeSeries20.getItems();
        java.lang.String str23 = timeSeries20.getDescription();
        timeSeries20.clear();
        int int25 = month8.compareTo((java.lang.Object) timeSeries20);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        long long27 = month26.getFirstMillisecond();
        java.lang.Object obj28 = null;
        boolean boolean29 = month26.equals(obj28);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean29, "", "Value");
        boolean boolean33 = timeSeries32.isEmpty();
        boolean boolean34 = timeSeries32.getNotify();
        int int35 = month8.compareTo((java.lang.Object) timeSeries32);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 24234L + "'", long17 == 24234L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559372400000L + "'", long27 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod1, (double) (-61851744000001L));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries6.setKey((java.lang.Comparable) (-1));
        timeSeries6.setKey((java.lang.Comparable) 8);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries6.addChangeListener(seriesChangeListener11);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean15 = timeSeries14.getNotify();
        java.util.List list16 = timeSeries14.getItems();
        java.lang.String str17 = timeSeries14.getDescription();
        java.lang.String str18 = timeSeries14.getRangeDescription();
        timeSeries14.setDomainDescription("hi!");
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) month21, (double) 1559372400000L, false);
        long long25 = month21.getLastMillisecond();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month26.previous();
        java.lang.Class<?> wildcardClass28 = regularTimePeriod27.getClass();
        int int29 = month21.compareTo((java.lang.Object) regularTimePeriod27);
        long long30 = month21.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) 0.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries6.addOrUpdate(timeSeriesDataItem32);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year35, (java.lang.Number) (short) 10);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) (short) 10);
        timeSeriesDataItem41.setSelected(true);
        int int44 = timeSeriesDataItem37.compareTo((java.lang.Object) true);
        int int45 = timeSeriesDataItem32.compareTo((java.lang.Object) timeSeriesDataItem37);
        java.lang.Object obj46 = timeSeriesDataItem37.clone();
        java.lang.Number number47 = timeSeriesDataItem37.getValue();
        int int48 = timeSeriesDataItem3.compareTo((java.lang.Object) timeSeriesDataItem37);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Value" + "'", str18.equals("Value"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1561964399999L + "'", long25 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 24234L + "'", long30 == 24234L);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertTrue("'" + number47 + "' != '" + (short) 10 + "'", number47.equals((short) 10));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) true);
        java.lang.String str2 = seriesChangeEvent1.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo3);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = seriesChangeEvent1.getSummary();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=true]" + "'", str2.equals("org.jfree.data.event.SeriesChangeEvent[source=true]"));
        org.junit.Assert.assertNull(seriesChangeInfo5);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean3 = timeSeries2.getNotify();
        java.util.List list4 = timeSeries2.getItems();
        java.lang.String str5 = timeSeries2.getDescription();
        java.lang.String str6 = timeSeries2.getRangeDescription();
        java.lang.String str7 = timeSeries2.getDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries2.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.previous();
        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        long long15 = month14.getFirstMillisecond();
        java.util.Date date16 = month14.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date16, timeZone17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date16);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date16);
        int int21 = year10.compareTo((java.lang.Object) day20);
        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) (-1L));
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean26 = timeSeries25.getNotify();
        java.util.List list27 = timeSeries25.getItems();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(9);
        long long30 = year29.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        boolean boolean33 = timeSeries32.getNotify();
        long long34 = timeSeries32.getMaximumItemAge();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(9);
        long long37 = year36.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year36, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) year29, (org.jfree.data.time.RegularTimePeriod) year36);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        long long42 = month41.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries40.getDataItem((org.jfree.data.time.RegularTimePeriod) month41);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100L);
        java.lang.Object obj46 = seriesChangeEvent45.getSource();
        java.lang.Object obj47 = seriesChangeEvent45.getSource();
        java.lang.String str48 = seriesChangeEvent45.toString();
        boolean boolean49 = month41.equals((java.lang.Object) str48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = month41.previous();
        java.lang.String str51 = month41.toString();
        boolean boolean52 = year10.equals((java.lang.Object) month41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = month41.next();
        org.jfree.data.time.Year year54 = month41.getYear();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month(5, year54);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1559372400000L + "'", long15 == 1559372400000L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-61883280000000L) + "'", long30 == (-61883280000000L));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 9223372036854775807L + "'", long34 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-61867512000001L) + "'", long37 == (-61867512000001L));
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1559372400000L + "'", long42 == 1559372400000L);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + obj46 + "' != '" + 100L + "'", obj46.equals(100L));
        org.junit.Assert.assertTrue("'" + obj47 + "' != '" + 100L + "'", obj47.equals(100L));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str48.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "June 2019" + "'", str51.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(year54);
    }
}

