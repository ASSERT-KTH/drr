import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) -1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long5 = fixedMillisecond4.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        spreadsheetDate13.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str27 = spreadsheetDate26.toString();
        boolean boolean28 = spreadsheetDate24.isOn((org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean29 = spreadsheetDate20.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        int int30 = spreadsheetDate26.getDayOfMonth();
        boolean boolean31 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean32 = fixedMillisecond4.equals((java.lang.Object) spreadsheetDate13);
        boolean boolean33 = day2.equals((java.lang.Object) fixedMillisecond4);
        java.lang.Class<?> wildcardClass34 = fixedMillisecond4.getClass();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long40 = fixedMillisecond39.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str45 = spreadsheetDate44.toString();
        boolean boolean46 = spreadsheetDate42.isOn((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str49 = spreadsheetDate48.toString();
        spreadsheetDate48.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str56 = spreadsheetDate55.toString();
        boolean boolean57 = spreadsheetDate53.isOn((org.jfree.data.time.SerialDate) spreadsheetDate55);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str62 = spreadsheetDate61.toString();
        boolean boolean63 = spreadsheetDate59.isOn((org.jfree.data.time.SerialDate) spreadsheetDate61);
        boolean boolean64 = spreadsheetDate55.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate61);
        int int65 = spreadsheetDate61.getDayOfMonth();
        boolean boolean66 = spreadsheetDate42.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate48, (org.jfree.data.time.SerialDate) spreadsheetDate61);
        boolean boolean67 = fixedMillisecond39.equals((java.lang.Object) spreadsheetDate48);
        boolean boolean68 = day37.equals((java.lang.Object) fixedMillisecond39);
        java.lang.Class<?> wildcardClass69 = fixedMillisecond39.getClass();
        java.lang.Class class70 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass69);
        java.lang.Object obj71 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass69);
        java.io.InputStream inputStream72 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ERROR : Relative To String", (java.lang.Class) wildcardClass69);
        java.lang.Object obj73 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("2019", (java.lang.Class) wildcardClass34, (java.lang.Class) wildcardClass69);
        java.io.InputStream inputStream74 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ClassContext", (java.lang.Class) wildcardClass34);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "9-April-1900" + "'", str27.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 100L + "'", long40 == 100L);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "9-April-1900" + "'", str45.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "9-April-1900" + "'", str49.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "9-April-1900" + "'", str56.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "9-April-1900" + "'", str62.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 9 + "'", int65 == 9);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(wildcardClass69);
        org.junit.Assert.assertNotNull(class70);
        org.junit.Assert.assertNull(obj71);
        org.junit.Assert.assertNull(inputStream72);
        org.junit.Assert.assertNull(obj73);
        org.junit.Assert.assertNull(inputStream74);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date2, timeZone5);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date2, timeZone7);
        java.lang.String str9 = year8.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969" + "'", str9.equals("1969"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(30, 9999, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        timeSeries2.setDomainDescription("October 0");
        java.lang.Object obj5 = timeSeries2.clone();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        boolean boolean8 = timeSeries2.equals((java.lang.Object) year6);
        java.util.Date date9 = year6.getEnd();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Last", "", "ERROR : Relative To String", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class8);
        timeSeries9.setDomainDescription("October 0");
        java.lang.Object obj12 = timeSeries9.clone();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries9);
        timeSeries13.setRangeDescription("Sep");
        java.lang.String str16 = timeSeries13.getDescription();
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        int int3 = timeSeries2.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries2.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date8 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date8);
        java.util.Date date11 = month10.getEnd();
        java.lang.String str12 = month10.toString();
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) month10, (double) 1577865599999L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "December 1969" + "'", str12.equals("December 1969"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Sep");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long3 = fixedMillisecond2.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        boolean boolean9 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str12 = spreadsheetDate11.toString();
        spreadsheetDate11.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str19 = spreadsheetDate18.toString();
        boolean boolean20 = spreadsheetDate16.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        boolean boolean26 = spreadsheetDate22.isOn((org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean27 = spreadsheetDate18.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate24);
        int int28 = spreadsheetDate24.getDayOfMonth();
        boolean boolean29 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, (org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean30 = fixedMillisecond2.equals((java.lang.Object) spreadsheetDate11);
        boolean boolean31 = day0.equals((java.lang.Object) fixedMillisecond2);
        java.lang.Class<?> wildcardClass32 = fixedMillisecond2.getClass();
        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize(class33);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-April-1900" + "'", str12.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-April-1900" + "'", str19.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 9 + "'", int28 == 9);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(class33);
        org.junit.Assert.assertNotNull(class34);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("31-December-1969");
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((-457));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.String str10 = timeSeries6.getDescription();
        java.lang.Comparable comparable11 = timeSeries6.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long14 = fixedMillisecond13.getMiddleMillisecond();
        long long15 = fixedMillisecond13.getFirstMillisecond();
        long long16 = fixedMillisecond13.getLastMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        java.lang.Object obj19 = null;
        boolean boolean20 = spreadsheetDate18.equals(obj19);
        boolean boolean21 = fixedMillisecond13.equals(obj19);
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        java.util.Calendar calendar23 = null;
        fixedMillisecond13.peg(calendar23);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int28 = month27.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) 1.0d);
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class32);
        int int34 = timeSeries33.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries33.removeChangeListener(seriesChangeListener35);
        java.util.Collection collection37 = timeSeries33.getTimePeriods();
        int int38 = timeSeriesDataItem30.compareTo((java.lang.Object) timeSeries33);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int42 = month41.getMonth();
        java.lang.String str43 = month41.toString();
        java.lang.String str44 = month41.toString();
        boolean boolean45 = timeSeriesDataItem30.equals((java.lang.Object) month41);
        int int46 = fixedMillisecond13.compareTo((java.lang.Object) timeSeriesDataItem30);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + "Overwritten values from: 1.0" + "'", comparable11.equals("Overwritten values from: 1.0"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 10 + "'", int42 == 10);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "October 0" + "'", str43.equals("October 0"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "October 0" + "'", str44.equals("October 0"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        timeSeries2.clear();
        java.lang.Comparable comparable5 = timeSeries2.getKey();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year7 = month6.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date10 = fixedMillisecond9.getTime();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (double) 43629L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeriesDataItem13.getPeriod();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 1.0f + "'", comparable5.equals(1.0f));
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) -1, 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj13 = null;
        boolean boolean14 = month12.equals(obj13);
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        long long16 = month12.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date19 = fixedMillisecond18.getTime();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        boolean boolean21 = month12.equals((java.lang.Object) day20);
        int int22 = day20.getDayOfMonth();
        int int23 = day20.getMonth();
        long long24 = day20.getLastMillisecond();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 31 + "'", int22 == 31);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 12 + "'", int23 == 12);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28799999L + "'", long24 == 28799999L);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class8);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries13.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj20 = null;
        boolean boolean21 = month19.equals(obj20);
        int int22 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) month19);
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class24);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries25.addAndOrUpdate(timeSeries28);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries29);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year32 = month31.getYear();
        int int33 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) year32);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) month19, (org.jfree.data.time.RegularTimePeriod) year32);
        int int35 = timeSeries34.getItemCount();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(year32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        timeSeries2.setDomainDescription("October 0");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        timeSeries2.delete(regularTimePeriod6);
        java.lang.Class<?> wildcardClass8 = timeSeries2.getClass();
        java.util.Collection collection9 = timeSeries2.getTimePeriods();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(collection9);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long4 = fixedMillisecond3.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str9 = spreadsheetDate8.toString();
        boolean boolean10 = spreadsheetDate6.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str13 = spreadsheetDate12.toString();
        spreadsheetDate12.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str20 = spreadsheetDate19.toString();
        boolean boolean21 = spreadsheetDate17.isOn((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str26 = spreadsheetDate25.toString();
        boolean boolean27 = spreadsheetDate23.isOn((org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean28 = spreadsheetDate19.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        int int29 = spreadsheetDate25.getDayOfMonth();
        boolean boolean30 = spreadsheetDate6.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, (org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean31 = fixedMillisecond3.equals((java.lang.Object) spreadsheetDate12);
        boolean boolean32 = day1.equals((java.lang.Object) fixedMillisecond3);
        java.lang.Class<?> wildcardClass33 = fixedMillisecond3.getClass();
        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
        java.net.URL uRL35 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass33);
        java.lang.ClassLoader classLoader36 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass33);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader36);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-April-1900" + "'", str9.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "9-April-1900" + "'", str13.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "9-April-1900" + "'", str20.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "9-April-1900" + "'", str26.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 9 + "'", int29 == 9);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(class34);
        org.junit.Assert.assertNull(uRL35);
        org.junit.Assert.assertNotNull(classLoader36);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        long long7 = timeSeries6.getMaximumItemAge();
        java.lang.Class class8 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj12 = null;
        boolean boolean13 = month11.equals(obj12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) 10.0f);
        timeSeriesDataItem15.setValue((java.lang.Number) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem15.getPeriod();
        long long19 = regularTimePeriod18.getMiddleMillisecond();
        try {
            timeSeries6.update(regularTimePeriod18, (java.lang.Number) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62126582400001L) + "'", long19 == (-62126582400001L));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 0, 2958465, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long5 = fixedMillisecond4.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        spreadsheetDate13.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str27 = spreadsheetDate26.toString();
        boolean boolean28 = spreadsheetDate24.isOn((org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean29 = spreadsheetDate20.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        int int30 = spreadsheetDate26.getDayOfMonth();
        boolean boolean31 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean32 = fixedMillisecond4.equals((java.lang.Object) spreadsheetDate13);
        boolean boolean33 = day2.equals((java.lang.Object) fixedMillisecond4);
        java.lang.Class<?> wildcardClass34 = fixedMillisecond4.getClass();
        java.io.InputStream inputStream35 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("9-April-1900", (java.lang.Class) wildcardClass34);
        java.lang.Class class36 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
        java.lang.Object obj37 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("October", class36);
        java.lang.ClassLoader classLoader38 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class36);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "9-April-1900" + "'", str27.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNull(inputStream35);
        org.junit.Assert.assertNotNull(class36);
        org.junit.Assert.assertNull(obj37);
        org.junit.Assert.assertNotNull(classLoader38);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str5 = spreadsheetDate4.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str16 = spreadsheetDate15.toString();
        boolean boolean17 = spreadsheetDate13.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str23 = spreadsheetDate22.toString();
        boolean boolean24 = spreadsheetDate20.isOn((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str27 = spreadsheetDate26.toString();
        spreadsheetDate26.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str34 = spreadsheetDate33.toString();
        boolean boolean35 = spreadsheetDate31.isOn((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str40 = spreadsheetDate39.toString();
        boolean boolean41 = spreadsheetDate37.isOn((org.jfree.data.time.SerialDate) spreadsheetDate39);
        boolean boolean42 = spreadsheetDate33.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate39);
        int int43 = spreadsheetDate39.getDayOfMonth();
        boolean boolean44 = spreadsheetDate20.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate26, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        int int45 = spreadsheetDate15.compare((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SerialDate serialDate46 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addMonths(2, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.addMonths(0, serialDate47);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addMonths((int) '4', serialDate47);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "9-April-1900" + "'", str16.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "9-April-1900" + "'", str23.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "9-April-1900" + "'", str27.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "9-April-1900" + "'", str34.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "9-April-1900" + "'", str40.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 9 + "'", int43 == 9);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate49);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
        java.lang.Object obj18 = timeSeries17.clone();
        java.util.Collection collection19 = timeSeries17.getTimePeriods();
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(collection20);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("ThreadContext");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("ThreadContext");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("January");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str5 = spreadsheetDate4.toString();
//        boolean boolean6 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str9 = spreadsheetDate8.toString();
//        spreadsheetDate8.setDescription("9-April-1900");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str16 = spreadsheetDate15.toString();
//        boolean boolean17 = spreadsheetDate13.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str22 = spreadsheetDate21.toString();
//        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        boolean boolean24 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        int int25 = spreadsheetDate21.getDayOfMonth();
//        boolean boolean26 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate21);
//        boolean boolean27 = day0.equals((java.lang.Object) spreadsheetDate8);
//        long long28 = day0.getLastMillisecond();
//        long long29 = day0.getLastMillisecond();
//        long long30 = day0.getFirstMillisecond();
//        int int31 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-April-1900" + "'", str9.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "9-April-1900" + "'", str16.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 9 + "'", int25 == 9);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560495599999L + "'", long28 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560495599999L + "'", long29 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560409200000L + "'", long30 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 6 + "'", int31 == 6);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getLastMillisecond();
        long long3 = year1.getLastMillisecond();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(2, year1);
        long long5 = year1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 1.0d);
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str13 = spreadsheetDate12.toString();
        boolean boolean14 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean15 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int16 = month2.compareTo((java.lang.Object) spreadsheetDate8);
        java.util.Date date17 = spreadsheetDate8.toDate();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "9-April-1900" + "'", str13.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class2);
        boolean boolean4 = timeSeries3.getNotify();
        timeSeries3.clear();
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year8 = month7.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date11 = fixedMillisecond10.getTime();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        try {
            org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(100, year8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 1.0f + "'", comparable6.equals(1.0f));
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeSeries12);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str3 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        boolean boolean9 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        spreadsheetDate24.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str32 = spreadsheetDate31.toString();
        boolean boolean33 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        boolean boolean39 = spreadsheetDate35.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int41 = spreadsheetDate37.getDayOfMonth();
        boolean boolean42 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int43 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addMonths(2, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int46 = spreadsheetDate2.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate47 = null;
        try {
            int int48 = spreadsheetDate2.compare(serialDate47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9 + "'", int41 == 9);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
        timeSeries17.clear();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj22 = null;
        boolean boolean23 = month21.equals(obj22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) 10.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeriesDataItem25.getPeriod();
        try {
            timeSeries17.add(timeSeriesDataItem25, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str5 = spreadsheetDate4.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str16 = spreadsheetDate15.toString();
        boolean boolean17 = spreadsheetDate13.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str23 = spreadsheetDate22.toString();
        boolean boolean24 = spreadsheetDate20.isOn((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str27 = spreadsheetDate26.toString();
        spreadsheetDate26.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str34 = spreadsheetDate33.toString();
        boolean boolean35 = spreadsheetDate31.isOn((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str40 = spreadsheetDate39.toString();
        boolean boolean41 = spreadsheetDate37.isOn((org.jfree.data.time.SerialDate) spreadsheetDate39);
        boolean boolean42 = spreadsheetDate33.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate39);
        int int43 = spreadsheetDate39.getDayOfMonth();
        boolean boolean44 = spreadsheetDate20.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate26, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        int int45 = spreadsheetDate15.compare((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SerialDate serialDate46 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str52 = spreadsheetDate51.toString();
        boolean boolean53 = spreadsheetDate49.isOn((org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str58 = spreadsheetDate57.toString();
        boolean boolean59 = spreadsheetDate55.isOn((org.jfree.data.time.SerialDate) spreadsheetDate57);
        boolean boolean60 = spreadsheetDate51.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate57);
        boolean boolean61 = spreadsheetDate20.isOn((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate57);
        int int63 = spreadsheetDate57.getMonth();
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.addYears(12, (org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "9-April-1900" + "'", str16.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "9-April-1900" + "'", str23.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "9-April-1900" + "'", str27.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "9-April-1900" + "'", str34.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "9-April-1900" + "'", str40.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 9 + "'", int43 == 9);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "9-April-1900" + "'", str52.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "9-April-1900" + "'", str58.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 4 + "'", int63 == 4);
        org.junit.Assert.assertNotNull(serialDate64);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str9 = spreadsheetDate8.toString();
        boolean boolean10 = spreadsheetDate6.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str15 = spreadsheetDate14.toString();
        boolean boolean16 = spreadsheetDate12.isOn((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean17 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str22 = spreadsheetDate21.toString();
        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str26 = spreadsheetDate25.toString();
        spreadsheetDate25.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str33 = spreadsheetDate32.toString();
        boolean boolean34 = spreadsheetDate30.isOn((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str39 = spreadsheetDate38.toString();
        boolean boolean40 = spreadsheetDate36.isOn((org.jfree.data.time.SerialDate) spreadsheetDate38);
        boolean boolean41 = spreadsheetDate32.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        int int42 = spreadsheetDate38.getDayOfMonth();
        boolean boolean43 = spreadsheetDate19.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate38);
        int int44 = spreadsheetDate14.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate45 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addDays(100, (org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str49 = spreadsheetDate48.toString();
        spreadsheetDate48.setDescription("9-April-1900");
        int int52 = spreadsheetDate48.toSerial();
        boolean boolean53 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate48);
        spreadsheetDate19.setDescription("Overwritten values from: 1.0");
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-April-1900" + "'", str9.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "9-April-1900" + "'", str15.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "9-April-1900" + "'", str26.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-April-1900" + "'", str33.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "9-April-1900" + "'", str39.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "9-April-1900" + "'", str49.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 100 + "'", int52 == 100);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(serialDate56);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 1.0d);
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str13 = spreadsheetDate12.toString();
        boolean boolean14 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean15 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int16 = month2.compareTo((java.lang.Object) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str27 = spreadsheetDate26.toString();
        boolean boolean28 = spreadsheetDate24.isOn((org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean29 = spreadsheetDate20.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        int int30 = spreadsheetDate26.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str33 = spreadsheetDate32.toString();
        boolean boolean34 = spreadsheetDate26.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str43 = spreadsheetDate42.toString();
        boolean boolean44 = spreadsheetDate40.isOn((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str49 = spreadsheetDate48.toString();
        boolean boolean50 = spreadsheetDate46.isOn((org.jfree.data.time.SerialDate) spreadsheetDate48);
        boolean boolean51 = spreadsheetDate42.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str56 = spreadsheetDate55.toString();
        boolean boolean57 = spreadsheetDate53.isOn((org.jfree.data.time.SerialDate) spreadsheetDate55);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str60 = spreadsheetDate59.toString();
        spreadsheetDate59.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str67 = spreadsheetDate66.toString();
        boolean boolean68 = spreadsheetDate64.isOn((org.jfree.data.time.SerialDate) spreadsheetDate66);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate72 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str73 = spreadsheetDate72.toString();
        boolean boolean74 = spreadsheetDate70.isOn((org.jfree.data.time.SerialDate) spreadsheetDate72);
        boolean boolean75 = spreadsheetDate66.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate72);
        int int76 = spreadsheetDate72.getDayOfMonth();
        boolean boolean77 = spreadsheetDate53.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate59, (org.jfree.data.time.SerialDate) spreadsheetDate72);
        int int78 = spreadsheetDate48.compare((org.jfree.data.time.SerialDate) spreadsheetDate53);
        org.jfree.data.time.SerialDate serialDate79 = spreadsheetDate37.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate53);
        org.jfree.data.time.SerialDate serialDate80 = org.jfree.data.time.SerialDate.addDays(100, (org.jfree.data.time.SerialDate) spreadsheetDate53);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate82 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str83 = spreadsheetDate82.toString();
        spreadsheetDate82.setDescription("9-April-1900");
        int int86 = spreadsheetDate82.toSerial();
        boolean boolean87 = spreadsheetDate53.isOn((org.jfree.data.time.SerialDate) spreadsheetDate82);
        spreadsheetDate53.setDescription("Overwritten values from: 1.0");
        boolean boolean90 = spreadsheetDate8.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate32, (org.jfree.data.time.SerialDate) spreadsheetDate53);
        int int91 = spreadsheetDate53.getYYYY();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "9-April-1900" + "'", str13.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "9-April-1900" + "'", str27.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-April-1900" + "'", str33.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "9-April-1900" + "'", str43.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "9-April-1900" + "'", str49.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "9-April-1900" + "'", str56.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "9-April-1900" + "'", str60.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "9-April-1900" + "'", str67.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "9-April-1900" + "'", str73.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 9 + "'", int76 == 9);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertNotNull(serialDate79);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "9-April-1900" + "'", str83.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 100 + "'", int86 == 100);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 1900 + "'", int91 == 1900);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        spreadsheetDate7.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str15 = spreadsheetDate14.toString();
        boolean boolean16 = spreadsheetDate12.isOn((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean23 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int24 = spreadsheetDate20.getDayOfMonth();
        boolean boolean25 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, (org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str28 = spreadsheetDate27.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str33 = spreadsheetDate32.toString();
        boolean boolean34 = spreadsheetDate30.isOn((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str39 = spreadsheetDate38.toString();
        boolean boolean40 = spreadsheetDate36.isOn((org.jfree.data.time.SerialDate) spreadsheetDate38);
        boolean boolean41 = spreadsheetDate32.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str46 = spreadsheetDate45.toString();
        boolean boolean47 = spreadsheetDate43.isOn((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str50 = spreadsheetDate49.toString();
        spreadsheetDate49.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str57 = spreadsheetDate56.toString();
        boolean boolean58 = spreadsheetDate54.isOn((org.jfree.data.time.SerialDate) spreadsheetDate56);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str63 = spreadsheetDate62.toString();
        boolean boolean64 = spreadsheetDate60.isOn((org.jfree.data.time.SerialDate) spreadsheetDate62);
        boolean boolean65 = spreadsheetDate56.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate62);
        int int66 = spreadsheetDate62.getDayOfMonth();
        boolean boolean67 = spreadsheetDate43.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate49, (org.jfree.data.time.SerialDate) spreadsheetDate62);
        int int68 = spreadsheetDate38.compare((org.jfree.data.time.SerialDate) spreadsheetDate43);
        org.jfree.data.time.SerialDate serialDate69 = spreadsheetDate27.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate43);
        java.lang.String str70 = spreadsheetDate27.getDescription();
        int int71 = spreadsheetDate27.toSerial();
        boolean boolean72 = spreadsheetDate20.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "9-April-1900" + "'", str15.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 9 + "'", int24 == 9);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "9-April-1900" + "'", str28.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-April-1900" + "'", str33.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "9-April-1900" + "'", str39.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "9-April-1900" + "'", str46.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "9-April-1900" + "'", str50.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "9-April-1900" + "'", str57.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "9-April-1900" + "'", str63.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 9 + "'", int66 == 9);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 100 + "'", int71 == 100);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.String str10 = timeSeries6.getDescription();
        java.lang.String str11 = timeSeries6.getDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries6.addChangeListener(seriesChangeListener12);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = year1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        java.lang.String str4 = year1.toString();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-458) + "'", int1 == (-458));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
        boolean boolean18 = timeSeries16.isEmpty();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        int int2 = spreadsheetDate1.getYYYY();
        java.lang.Class<?> wildcardClass3 = spreadsheetDate1.getClass();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str6 = spreadsheetDate5.toString();
        spreadsheetDate5.setDescription("9-April-1900");
        int int9 = spreadsheetDate5.toSerial();
        int int10 = spreadsheetDate5.getDayOfWeek();
        boolean boolean11 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "9-April-1900" + "'", str6.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class8);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries13.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj20 = null;
        boolean boolean21 = month19.equals(obj20);
        int int22 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) month19);
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class24);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries25.addAndOrUpdate(timeSeries28);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries29);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year32 = month31.getYear();
        int int33 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) year32);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) month19, (org.jfree.data.time.RegularTimePeriod) year32);
        try {
            timeSeries34.delete((int) (short) 0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(year32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(timeSeries34);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj3 = null;
        boolean boolean4 = month2.equals(obj3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 10.0f);
        timeSeriesDataItem6.setValue((java.lang.Number) 12);
        timeSeriesDataItem6.setValue((java.lang.Number) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str5 = spreadsheetDate4.toString();
        boolean boolean6 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str11 = spreadsheetDate10.toString();
        boolean boolean12 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean13 = spreadsheetDate4.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str18 = spreadsheetDate17.toString();
        boolean boolean19 = spreadsheetDate15.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str22 = spreadsheetDate21.toString();
        spreadsheetDate21.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str29 = spreadsheetDate28.toString();
        boolean boolean30 = spreadsheetDate26.isOn((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str35 = spreadsheetDate34.toString();
        boolean boolean36 = spreadsheetDate32.isOn((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean37 = spreadsheetDate28.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate34);
        int int38 = spreadsheetDate34.getDayOfMonth();
        boolean boolean39 = spreadsheetDate15.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate21, (org.jfree.data.time.SerialDate) spreadsheetDate34);
        int int40 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str43 = spreadsheetDate42.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str48 = spreadsheetDate47.toString();
        boolean boolean49 = spreadsheetDate45.isOn((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str54 = spreadsheetDate53.toString();
        boolean boolean55 = spreadsheetDate51.isOn((org.jfree.data.time.SerialDate) spreadsheetDate53);
        boolean boolean56 = spreadsheetDate47.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate53);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str61 = spreadsheetDate60.toString();
        boolean boolean62 = spreadsheetDate58.isOn((org.jfree.data.time.SerialDate) spreadsheetDate60);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str65 = spreadsheetDate64.toString();
        spreadsheetDate64.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str72 = spreadsheetDate71.toString();
        boolean boolean73 = spreadsheetDate69.isOn((org.jfree.data.time.SerialDate) spreadsheetDate71);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str78 = spreadsheetDate77.toString();
        boolean boolean79 = spreadsheetDate75.isOn((org.jfree.data.time.SerialDate) spreadsheetDate77);
        boolean boolean80 = spreadsheetDate71.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate77);
        int int81 = spreadsheetDate77.getDayOfMonth();
        boolean boolean82 = spreadsheetDate58.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate64, (org.jfree.data.time.SerialDate) spreadsheetDate77);
        int int83 = spreadsheetDate53.compare((org.jfree.data.time.SerialDate) spreadsheetDate58);
        org.jfree.data.time.SerialDate serialDate84 = spreadsheetDate42.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate58);
        org.jfree.data.time.SerialDate serialDate85 = spreadsheetDate15.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate58);
        java.lang.String str86 = spreadsheetDate15.toString();
        try {
            org.jfree.data.time.SerialDate serialDate87 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) '#', (org.jfree.data.time.SerialDate) spreadsheetDate15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-April-1900" + "'", str11.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "9-April-1900" + "'", str18.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "9-April-1900" + "'", str29.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "9-April-1900" + "'", str35.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 9 + "'", int38 == 9);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "9-April-1900" + "'", str43.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "9-April-1900" + "'", str48.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "9-April-1900" + "'", str54.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "9-April-1900" + "'", str61.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "9-April-1900" + "'", str65.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "9-April-1900" + "'", str72.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "9-April-1900" + "'", str78.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 9 + "'", int81 == 9);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertNotNull(serialDate85);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "9-April-1900" + "'", str86.equals("9-April-1900"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("ClassContext");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        java.lang.String str3 = seriesException1.toString();
        java.lang.String str4 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str3.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str4.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Last", "", "ERROR : Relative To String", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries4.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries4.getDescription();
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str17 = spreadsheetDate16.toString();
        boolean boolean18 = spreadsheetDate14.isOn((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        spreadsheetDate20.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str28 = spreadsheetDate27.toString();
        boolean boolean29 = spreadsheetDate25.isOn((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str34 = spreadsheetDate33.toString();
        boolean boolean35 = spreadsheetDate31.isOn((org.jfree.data.time.SerialDate) spreadsheetDate33);
        boolean boolean36 = spreadsheetDate27.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int37 = spreadsheetDate33.getDayOfMonth();
        boolean boolean38 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate20, (org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int39 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str42 = spreadsheetDate41.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str47 = spreadsheetDate46.toString();
        boolean boolean48 = spreadsheetDate44.isOn((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str53 = spreadsheetDate52.toString();
        boolean boolean54 = spreadsheetDate50.isOn((org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean55 = spreadsheetDate46.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str60 = spreadsheetDate59.toString();
        boolean boolean61 = spreadsheetDate57.isOn((org.jfree.data.time.SerialDate) spreadsheetDate59);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str64 = spreadsheetDate63.toString();
        spreadsheetDate63.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str71 = spreadsheetDate70.toString();
        boolean boolean72 = spreadsheetDate68.isOn((org.jfree.data.time.SerialDate) spreadsheetDate70);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str77 = spreadsheetDate76.toString();
        boolean boolean78 = spreadsheetDate74.isOn((org.jfree.data.time.SerialDate) spreadsheetDate76);
        boolean boolean79 = spreadsheetDate70.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate76);
        int int80 = spreadsheetDate76.getDayOfMonth();
        boolean boolean81 = spreadsheetDate57.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate63, (org.jfree.data.time.SerialDate) spreadsheetDate76);
        int int82 = spreadsheetDate52.compare((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SerialDate serialDate83 = spreadsheetDate41.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SerialDate serialDate84 = spreadsheetDate14.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate57);
        int int85 = spreadsheetDate14.getYYYY();
        int int86 = spreadsheetDate14.getYYYY();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "9-April-1900" + "'", str17.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "9-April-1900" + "'", str28.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "9-April-1900" + "'", str34.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 9 + "'", int37 == 9);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "9-April-1900" + "'", str42.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "9-April-1900" + "'", str47.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "9-April-1900" + "'", str53.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "9-April-1900" + "'", str60.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "9-April-1900" + "'", str64.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "9-April-1900" + "'", str71.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "9-April-1900" + "'", str77.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 9 + "'", int80 == 9);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1900 + "'", int85 == 1900);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 1900 + "'", int86 == 1900);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("7-April-1900");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long5 = fixedMillisecond4.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        spreadsheetDate13.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str27 = spreadsheetDate26.toString();
        boolean boolean28 = spreadsheetDate24.isOn((org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean29 = spreadsheetDate20.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        int int30 = spreadsheetDate26.getDayOfMonth();
        boolean boolean31 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean32 = fixedMillisecond4.equals((java.lang.Object) spreadsheetDate13);
        boolean boolean33 = day2.equals((java.lang.Object) fixedMillisecond4);
        java.lang.Class<?> wildcardClass34 = fixedMillisecond4.getClass();
        java.io.InputStream inputStream35 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("9-April-1900", (java.lang.Class) wildcardClass34);
        java.lang.Class class36 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
        java.net.URL uRL37 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesException: ClassContext", class36);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "9-April-1900" + "'", str27.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNull(inputStream35);
        org.junit.Assert.assertNotNull(class36);
        org.junit.Assert.assertNull(uRL37);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str17 = spreadsheetDate16.toString();
        boolean boolean18 = spreadsheetDate14.isOn((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        spreadsheetDate20.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str28 = spreadsheetDate27.toString();
        boolean boolean29 = spreadsheetDate25.isOn((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str34 = spreadsheetDate33.toString();
        boolean boolean35 = spreadsheetDate31.isOn((org.jfree.data.time.SerialDate) spreadsheetDate33);
        boolean boolean36 = spreadsheetDate27.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int37 = spreadsheetDate33.getDayOfMonth();
        boolean boolean38 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate20, (org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int39 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str42 = spreadsheetDate41.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str47 = spreadsheetDate46.toString();
        boolean boolean48 = spreadsheetDate44.isOn((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str53 = spreadsheetDate52.toString();
        boolean boolean54 = spreadsheetDate50.isOn((org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean55 = spreadsheetDate46.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str60 = spreadsheetDate59.toString();
        boolean boolean61 = spreadsheetDate57.isOn((org.jfree.data.time.SerialDate) spreadsheetDate59);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str64 = spreadsheetDate63.toString();
        spreadsheetDate63.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str71 = spreadsheetDate70.toString();
        boolean boolean72 = spreadsheetDate68.isOn((org.jfree.data.time.SerialDate) spreadsheetDate70);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str77 = spreadsheetDate76.toString();
        boolean boolean78 = spreadsheetDate74.isOn((org.jfree.data.time.SerialDate) spreadsheetDate76);
        boolean boolean79 = spreadsheetDate70.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate76);
        int int80 = spreadsheetDate76.getDayOfMonth();
        boolean boolean81 = spreadsheetDate57.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate63, (org.jfree.data.time.SerialDate) spreadsheetDate76);
        int int82 = spreadsheetDate52.compare((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SerialDate serialDate83 = spreadsheetDate41.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SerialDate serialDate84 = spreadsheetDate14.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate57);
        int int85 = spreadsheetDate14.getYYYY();
        int int86 = spreadsheetDate14.getMonth();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "9-April-1900" + "'", str17.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "9-April-1900" + "'", str28.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "9-April-1900" + "'", str34.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 9 + "'", int37 == 9);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "9-April-1900" + "'", str42.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "9-April-1900" + "'", str47.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "9-April-1900" + "'", str53.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "9-April-1900" + "'", str60.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "9-April-1900" + "'", str64.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "9-April-1900" + "'", str71.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "9-April-1900" + "'", str77.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 9 + "'", int80 == 9);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1900 + "'", int85 == 1900);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 4 + "'", int86 == 4);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        timeSeries2.setDomainDescription("October 0");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        timeSeries2.delete(regularTimePeriod6);
        timeSeries2.removeAgedItems(true);
        timeSeries2.setMaximumItemAge(100L);
        try {
            timeSeries2.removeAgedItems((long) (-458), true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj13 = null;
        boolean boolean14 = month12.equals(obj13);
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        long long16 = month12.getSerialIndex();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = month12.getLastMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str5 = spreadsheetDate4.toString();
        boolean boolean6 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str9 = spreadsheetDate8.toString();
        spreadsheetDate8.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str16 = spreadsheetDate15.toString();
        boolean boolean17 = spreadsheetDate13.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str22 = spreadsheetDate21.toString();
        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean24 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        int int25 = spreadsheetDate21.getDayOfMonth();
        boolean boolean26 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean27 = day0.equals((java.lang.Object) spreadsheetDate8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day0.previous();
        java.util.Date date29 = regularTimePeriod28.getEnd();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-April-1900" + "'", str9.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "9-April-1900" + "'", str16.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 9 + "'", int25 == 9);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        int int2 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str7 = spreadsheetDate6.toString();
        boolean boolean8 = spreadsheetDate4.isOn((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str13 = spreadsheetDate12.toString();
        boolean boolean14 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean15 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str20 = spreadsheetDate19.toString();
        boolean boolean21 = spreadsheetDate17.isOn((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str24 = spreadsheetDate23.toString();
        spreadsheetDate23.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str31 = spreadsheetDate30.toString();
        boolean boolean32 = spreadsheetDate28.isOn((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str37 = spreadsheetDate36.toString();
        boolean boolean38 = spreadsheetDate34.isOn((org.jfree.data.time.SerialDate) spreadsheetDate36);
        boolean boolean39 = spreadsheetDate30.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate36);
        int int40 = spreadsheetDate36.getDayOfMonth();
        boolean boolean41 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, (org.jfree.data.time.SerialDate) spreadsheetDate36);
        int int42 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean43 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        java.lang.Object obj44 = null;
        boolean boolean45 = spreadsheetDate12.equals(obj44);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9-April-1900" + "'", str7.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "9-April-1900" + "'", str13.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "9-April-1900" + "'", str20.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "9-April-1900" + "'", str24.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "9-April-1900" + "'", str31.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "9-April-1900" + "'", str37.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 9 + "'", int40 == 9);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date2, timeZone5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date11 = fixedMillisecond10.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date11);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date11, timeZone14);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date11, timeZone16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date2, timeZone16);
        java.util.Calendar calendar19 = null;
        try {
            long long20 = year18.getFirstMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(timeZone16);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        timeSeries2.fireSeriesChanged();
        int int5 = timeSeries2.getMaximumItemCount();
        java.lang.Object obj6 = timeSeries2.clone();
        timeSeries2.setDescription("");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNotNull(obj6);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year19 = month18.getYear();
//        long long20 = year19.getSerialIndex();
//        java.lang.String str21 = year19.toString();
//        timeSeries16.setKey((java.lang.Comparable) year19);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str28 = spreadsheetDate27.toString();
//        boolean boolean29 = spreadsheetDate25.isOn((org.jfree.data.time.SerialDate) spreadsheetDate27);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str32 = spreadsheetDate31.toString();
//        spreadsheetDate31.setDescription("9-April-1900");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str39 = spreadsheetDate38.toString();
//        boolean boolean40 = spreadsheetDate36.isOn((org.jfree.data.time.SerialDate) spreadsheetDate38);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str45 = spreadsheetDate44.toString();
//        boolean boolean46 = spreadsheetDate42.isOn((org.jfree.data.time.SerialDate) spreadsheetDate44);
//        boolean boolean47 = spreadsheetDate38.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate44);
//        int int48 = spreadsheetDate44.getDayOfMonth();
//        boolean boolean49 = spreadsheetDate25.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate31, (org.jfree.data.time.SerialDate) spreadsheetDate44);
//        boolean boolean50 = day23.equals((java.lang.Object) spreadsheetDate31);
//        long long51 = day23.getLastMillisecond();
//        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year53 = month52.getYear();
//        long long54 = year53.getSerialIndex();
//        long long55 = year53.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) day23, (org.jfree.data.time.RegularTimePeriod) year53);
//        java.util.Calendar calendar57 = null;
//        try {
//            long long58 = year53.getFirstMillisecond(calendar57);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "9-April-1900" + "'", str28.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "9-April-1900" + "'", str39.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "9-April-1900" + "'", str45.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 9 + "'", int48 == 9);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560495599999L + "'", long51 == 1560495599999L);
//        org.junit.Assert.assertNotNull(year53);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 2019L + "'", long54 == 2019L);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1577865599999L + "'", long55 == 1577865599999L);
//        org.junit.Assert.assertNotNull(timeSeries56);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        long long4 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getMiddleMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.previous();
        org.jfree.data.time.Year year11 = month9.getYear();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(year11);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener18);
        java.lang.Object obj20 = timeSeries9.clone();
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class22);
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class25);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries23.addAndOrUpdate(timeSeries26);
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries27.createCopy(0, (int) (short) 1);
        timeSeries30.setMaximumItemCount(5);
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries9.addAndOrUpdate(timeSeries30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long36 = fixedMillisecond35.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond35.previous();
        boolean boolean39 = fixedMillisecond35.equals((java.lang.Object) 'a');
        int int40 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        timeSeries9.removeAgedItems(true);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 100L + "'", long36 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str3 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        boolean boolean9 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        spreadsheetDate24.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str32 = spreadsheetDate31.toString();
        boolean boolean33 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        boolean boolean39 = spreadsheetDate35.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int41 = spreadsheetDate37.getDayOfMonth();
        boolean boolean42 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int43 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays(100, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str48 = spreadsheetDate47.toString();
        spreadsheetDate47.setDescription("9-April-1900");
        int int51 = spreadsheetDate47.toSerial();
        boolean boolean52 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SerialDate serialDate54 = spreadsheetDate47.getNearestDayOfWeek(4);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(serialDate54);
        long long56 = day55.getFirstMillisecond();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long62 = fixedMillisecond61.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str67 = spreadsheetDate66.toString();
        boolean boolean68 = spreadsheetDate64.isOn((org.jfree.data.time.SerialDate) spreadsheetDate66);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str71 = spreadsheetDate70.toString();
        spreadsheetDate70.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str78 = spreadsheetDate77.toString();
        boolean boolean79 = spreadsheetDate75.isOn((org.jfree.data.time.SerialDate) spreadsheetDate77);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate81 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate83 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str84 = spreadsheetDate83.toString();
        boolean boolean85 = spreadsheetDate81.isOn((org.jfree.data.time.SerialDate) spreadsheetDate83);
        boolean boolean86 = spreadsheetDate77.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate83);
        int int87 = spreadsheetDate83.getDayOfMonth();
        boolean boolean88 = spreadsheetDate64.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate70, (org.jfree.data.time.SerialDate) spreadsheetDate83);
        boolean boolean89 = fixedMillisecond61.equals((java.lang.Object) spreadsheetDate70);
        boolean boolean90 = day59.equals((java.lang.Object) fixedMillisecond61);
        java.lang.Class<?> wildcardClass91 = fixedMillisecond61.getClass();
        java.io.InputStream inputStream92 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("9-April-1900", (java.lang.Class) wildcardClass91);
        java.net.URL uRL93 = org.jfree.chart.util.ObjectUtilities.getResource("April", (java.lang.Class) wildcardClass91);
        org.jfree.data.time.TimeSeries timeSeries94 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day55, (java.lang.Class) wildcardClass91);
        long long95 = day55.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9 + "'", int41 == 9);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "9-April-1900" + "'", str48.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 100 + "'", int51 == 100);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-2200665600000L) + "'", long56 == (-2200665600000L));
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 100L + "'", long62 == 100L);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "9-April-1900" + "'", str67.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "9-April-1900" + "'", str71.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "9-April-1900" + "'", str78.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "9-April-1900" + "'", str84.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 9 + "'", int87 == 9);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(wildcardClass91);
        org.junit.Assert.assertNull(inputStream92);
        org.junit.Assert.assertNull(uRL93);
        org.junit.Assert.assertTrue("'" + long95 + "' != '" + 98L + "'", long95 == 98L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        boolean boolean7 = timeSeries2.getNotify();
        timeSeries2.setDomainDescription("hi!");
        java.lang.String str10 = timeSeries2.getRangeDescription();
        java.lang.Object obj11 = timeSeries2.clone();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 1.0d);
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class7);
        int int9 = timeSeries8.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries8.removeChangeListener(seriesChangeListener10);
        java.util.Collection collection12 = timeSeries8.getTimePeriods();
        int int13 = timeSeriesDataItem5.compareTo((java.lang.Object) timeSeries8);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int17 = month16.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month16, (java.lang.Number) 1.0d);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class21);
        int int23 = timeSeries22.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries22.removeChangeListener(seriesChangeListener24);
        java.util.Collection collection26 = timeSeries22.getTimePeriods();
        int int27 = timeSeriesDataItem19.compareTo((java.lang.Object) timeSeries22);
        java.lang.Number number28 = timeSeriesDataItem19.getValue();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year30 = month29.getYear();
        int int31 = timeSeriesDataItem19.compareTo((java.lang.Object) month29);
        int int32 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) month29);
        java.lang.String str33 = timeSeries8.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 1.0d + "'", number28.equals(1.0d));
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Value" + "'", str33.equals("Value"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj13 = null;
        boolean boolean14 = month12.equals(obj13);
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        long long16 = month12.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date19 = fixedMillisecond18.getTime();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        boolean boolean21 = month12.equals((java.lang.Object) day20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day20, 0.0d);
        long long24 = day20.getLastMillisecond();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28799999L + "'", long24 == 28799999L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        org.jfree.data.time.Year year5 = org.jfree.data.time.Year.parseYear("2019");
        java.lang.Number number6 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        long long10 = month9.getSerialIndex();
        long long11 = month9.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month9.previous();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries2.removeChangeListener(seriesChangeListener14);
        try {
            timeSeries2.delete((-459), 13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -459");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year5 = month4.getYear();
        long long6 = year5.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (double) (short) 10);
        timeSeries2.clear();
        timeSeries2.removeAgedItems(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class8);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries13.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj20 = null;
        boolean boolean21 = month19.equals(obj20);
        int int22 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) month19);
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class24);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries25.addAndOrUpdate(timeSeries28);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries29);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year32 = month31.getYear();
        int int33 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) year32);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) month19, (org.jfree.data.time.RegularTimePeriod) year32);
        int int35 = timeSeries6.getMaximumItemCount();
        java.lang.String str36 = timeSeries6.getRangeDescription();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj40 = null;
        boolean boolean41 = month39.equals(obj40);
        try {
            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) month39, (java.lang.Number) 1577865599999L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(year32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2147483647 + "'", int35 == 2147483647);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Value" + "'", str36.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date2, timeZone5);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date2, timeZone7);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date12 = fixedMillisecond11.getTime();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date12);
        java.util.Date date15 = month14.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date18 = fixedMillisecond17.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date18);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date18, timeZone21);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date18, timeZone23);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date15, timeZone23);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date2, timeZone23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(date2);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(timeZone23);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class3);
        timeSeries4.setDomainDescription("October 0");
        java.lang.Object obj7 = timeSeries4.clone();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        long long11 = month10.getSerialIndex();
        java.lang.Number number12 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) month10);
        int int13 = year1.compareTo((java.lang.Object) timeSeries4);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
        java.lang.Object obj18 = timeSeries17.clone();
        java.util.Collection collection19 = timeSeries17.getTimePeriods();
        java.lang.Comparable comparable20 = timeSeries17.getKey();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + "Overwritten values from: Overwritten values from: 1.0" + "'", comparable20.equals("Overwritten values from: Overwritten values from: 1.0"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year5 = month4.getYear();
        long long6 = year5.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (double) (short) 10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date11 = fixedMillisecond10.getTime();
        java.util.Date date12 = fixedMillisecond10.getTime();
        timeSeries2.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) 2019);
        timeSeries2.setDomainDescription("Overwritten values from: 1.0");
        java.util.Collection collection17 = timeSeries2.getTimePeriods();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(collection17);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str3 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        boolean boolean9 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        spreadsheetDate24.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str32 = spreadsheetDate31.toString();
        boolean boolean33 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        boolean boolean39 = spreadsheetDate35.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int41 = spreadsheetDate37.getDayOfMonth();
        boolean boolean42 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int43 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays(100, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str48 = spreadsheetDate47.toString();
        spreadsheetDate47.setDescription("9-April-1900");
        int int51 = spreadsheetDate47.toSerial();
        boolean boolean52 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate47);
        spreadsheetDate18.setDescription("Overwritten values from: 1.0");
        java.lang.String str55 = spreadsheetDate18.getDescription();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9 + "'", int41 == 9);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "9-April-1900" + "'", str48.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 100 + "'", int51 == 100);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Overwritten values from: 1.0" + "'", str55.equals("Overwritten values from: 1.0"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        int int2 = month0.getYearValue();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) 2);
        boolean boolean5 = month0.equals((java.lang.Object) fixedMillisecond4);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Overwritten values from: Overwritten values from: 1.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
        timeSeries17.clear();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        boolean boolean21 = timeSeries17.equals((java.lang.Object) regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int3 = month2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date2, timeZone5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.TimeZone timeZone8 = null;
        try {
            org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date2, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class3);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class6);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries4.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries8.createCopy(0, (int) (short) 1);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class13);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class16);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries14.addAndOrUpdate(timeSeries17);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries11.addAndOrUpdate(timeSeries18);
        java.lang.Class class20 = timeSeries19.getTimePeriodClass();
        boolean boolean21 = month0.equals((java.lang.Object) class20);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertNull(class20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        spreadsheetDate7.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str15 = spreadsheetDate14.toString();
        boolean boolean16 = spreadsheetDate12.isOn((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean23 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int24 = spreadsheetDate20.getDayOfMonth();
        boolean boolean25 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, (org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int26 = spreadsheetDate20.getYYYY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long29 = fixedMillisecond28.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str34 = spreadsheetDate33.toString();
        boolean boolean35 = spreadsheetDate31.isOn((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        spreadsheetDate37.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str45 = spreadsheetDate44.toString();
        boolean boolean46 = spreadsheetDate42.isOn((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str51 = spreadsheetDate50.toString();
        boolean boolean52 = spreadsheetDate48.isOn((org.jfree.data.time.SerialDate) spreadsheetDate50);
        boolean boolean53 = spreadsheetDate44.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate50);
        int int54 = spreadsheetDate50.getDayOfMonth();
        boolean boolean55 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate37, (org.jfree.data.time.SerialDate) spreadsheetDate50);
        boolean boolean56 = fixedMillisecond28.equals((java.lang.Object) spreadsheetDate37);
        boolean boolean57 = spreadsheetDate20.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate37);
        java.lang.String str58 = spreadsheetDate20.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "9-April-1900" + "'", str15.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 9 + "'", int24 == 9);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1900 + "'", int26 == 1900);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "9-April-1900" + "'", str34.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "9-April-1900" + "'", str45.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "9-April-1900" + "'", str51.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 9 + "'", int54 == 9);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "9-April-1900" + "'", str58.equals("9-April-1900"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("ClassContext");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        java.lang.String str4 = seriesException3.toString();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("ThreadContext");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("January");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str4.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str9 = spreadsheetDate8.toString();
        boolean boolean10 = spreadsheetDate6.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str15 = spreadsheetDate14.toString();
        boolean boolean16 = spreadsheetDate12.isOn((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean17 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str22 = spreadsheetDate21.toString();
        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str26 = spreadsheetDate25.toString();
        spreadsheetDate25.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str33 = spreadsheetDate32.toString();
        boolean boolean34 = spreadsheetDate30.isOn((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str39 = spreadsheetDate38.toString();
        boolean boolean40 = spreadsheetDate36.isOn((org.jfree.data.time.SerialDate) spreadsheetDate38);
        boolean boolean41 = spreadsheetDate32.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        int int42 = spreadsheetDate38.getDayOfMonth();
        boolean boolean43 = spreadsheetDate19.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate38);
        int int44 = spreadsheetDate14.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate45 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addDays(100, (org.jfree.data.time.SerialDate) spreadsheetDate19);
        int int47 = spreadsheetDate19.toSerial();
        java.lang.Class<?> wildcardClass48 = spreadsheetDate19.getClass();
        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
        java.lang.Object obj50 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Sep", class49);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-April-1900" + "'", str9.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "9-April-1900" + "'", str15.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "9-April-1900" + "'", str26.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-April-1900" + "'", str33.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "9-April-1900" + "'", str39.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 100 + "'", int47 == 100);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(class49);
        org.junit.Assert.assertNull(obj50);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str5 = spreadsheetDate4.toString();
        boolean boolean6 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str9 = spreadsheetDate8.toString();
        spreadsheetDate8.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str16 = spreadsheetDate15.toString();
        boolean boolean17 = spreadsheetDate13.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str22 = spreadsheetDate21.toString();
        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean24 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        int int25 = spreadsheetDate21.getDayOfMonth();
        boolean boolean26 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean27 = day0.equals((java.lang.Object) spreadsheetDate8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day0.previous();
        int int29 = day0.getMonth();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-April-1900" + "'", str9.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "9-April-1900" + "'", str16.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 9 + "'", int25 == 9);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2958465, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("9-April-1900");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str3 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        boolean boolean9 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        spreadsheetDate24.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str32 = spreadsheetDate31.toString();
        boolean boolean33 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        boolean boolean39 = spreadsheetDate35.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int41 = spreadsheetDate37.getDayOfMonth();
        boolean boolean42 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int43 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays(100, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        int int46 = spreadsheetDate18.toSerial();
        java.lang.Class<?> wildcardClass47 = spreadsheetDate18.getClass();
        java.lang.Class class48 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass47);
        java.lang.ClassLoader classLoader49 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class48);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9 + "'", int41 == 9);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 100 + "'", int46 == 100);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(class48);
        org.junit.Assert.assertNotNull(classLoader49);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = year1.getSerialIndex();
        java.lang.String str3 = year1.toString();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str18 = spreadsheetDate17.toString();
        spreadsheetDate17.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        boolean boolean26 = spreadsheetDate22.isOn((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str31 = spreadsheetDate30.toString();
        boolean boolean32 = spreadsheetDate28.isOn((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean33 = spreadsheetDate24.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        int int34 = spreadsheetDate30.getDayOfMonth();
        boolean boolean35 = spreadsheetDate11.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, (org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean36 = fixedMillisecond8.equals((java.lang.Object) spreadsheetDate17);
        boolean boolean37 = day6.equals((java.lang.Object) fixedMillisecond8);
        java.lang.Class<?> wildcardClass38 = fixedMillisecond8.getClass();
        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass38);
        java.io.InputStream inputStream40 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass38);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long45 = fixedMillisecond44.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str50 = spreadsheetDate49.toString();
        boolean boolean51 = spreadsheetDate47.isOn((org.jfree.data.time.SerialDate) spreadsheetDate49);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str54 = spreadsheetDate53.toString();
        spreadsheetDate53.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str61 = spreadsheetDate60.toString();
        boolean boolean62 = spreadsheetDate58.isOn((org.jfree.data.time.SerialDate) spreadsheetDate60);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str67 = spreadsheetDate66.toString();
        boolean boolean68 = spreadsheetDate64.isOn((org.jfree.data.time.SerialDate) spreadsheetDate66);
        boolean boolean69 = spreadsheetDate60.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate66);
        int int70 = spreadsheetDate66.getDayOfMonth();
        boolean boolean71 = spreadsheetDate47.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate53, (org.jfree.data.time.SerialDate) spreadsheetDate66);
        boolean boolean72 = fixedMillisecond44.equals((java.lang.Object) spreadsheetDate53);
        boolean boolean73 = day42.equals((java.lang.Object) fixedMillisecond44);
        java.lang.Class<?> wildcardClass74 = fixedMillisecond44.getClass();
        java.io.InputStream inputStream75 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("9-April-1900", (java.lang.Class) wildcardClass74);
        java.lang.Class class76 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass74);
        java.lang.Object obj77 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("org.jfree.data.time.TimePeriodFormatException: ", (java.lang.Class) wildcardClass38, class76);
        org.jfree.data.time.TimeSeries timeSeries78 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year1, class76);
        org.jfree.data.time.TimeSeries timeSeries79 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year1);
        java.lang.Class class81 = null;
        org.jfree.data.time.TimeSeries timeSeries82 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class81);
        java.lang.Class class84 = null;
        org.jfree.data.time.TimeSeries timeSeries85 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class84);
        org.jfree.data.time.TimeSeries timeSeries86 = timeSeries82.addAndOrUpdate(timeSeries85);
        org.jfree.data.time.TimeSeries timeSeries89 = timeSeries86.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month92 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj93 = null;
        boolean boolean94 = month92.equals(obj93);
        int int95 = timeSeries86.getIndex((org.jfree.data.time.RegularTimePeriod) month92);
        org.jfree.data.time.Month month96 = new org.jfree.data.time.Month();
        timeSeries86.delete((org.jfree.data.time.RegularTimePeriod) month96);
        long long98 = month96.getSerialIndex();
        java.lang.Number number99 = timeSeries79.getValue((org.jfree.data.time.RegularTimePeriod) month96);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "9-April-1900" + "'", str18.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "9-April-1900" + "'", str31.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 9 + "'", int34 == 9);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertNotNull(inputStream40);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "9-April-1900" + "'", str50.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "9-April-1900" + "'", str54.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "9-April-1900" + "'", str61.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "9-April-1900" + "'", str67.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 9 + "'", int70 == 9);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(wildcardClass74);
        org.junit.Assert.assertNull(inputStream75);
        org.junit.Assert.assertNotNull(class76);
        org.junit.Assert.assertNull(obj77);
        org.junit.Assert.assertNotNull(timeSeries86);
        org.junit.Assert.assertNotNull(timeSeries89);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + (-1) + "'", int95 == (-1));
        org.junit.Assert.assertTrue("'" + long98 + "' != '" + 24234L + "'", long98 == 24234L);
        org.junit.Assert.assertNull(number99);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str5 = spreadsheetDate4.toString();
        boolean boolean6 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str9 = spreadsheetDate8.toString();
        spreadsheetDate8.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str16 = spreadsheetDate15.toString();
        boolean boolean17 = spreadsheetDate13.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str22 = spreadsheetDate21.toString();
        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean24 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        int int25 = spreadsheetDate21.getDayOfMonth();
        boolean boolean26 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        int int27 = spreadsheetDate8.toSerial();
        try {
            org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, (org.jfree.data.time.SerialDate) spreadsheetDate8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-April-1900" + "'", str9.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "9-April-1900" + "'", str16.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 9 + "'", int25 == 9);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 100 + "'", int27 == 100);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Last", "", "ERROR : Relative To String", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class8);
        timeSeries9.setDomainDescription("October 0");
        java.lang.Object obj12 = timeSeries9.clone();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries9);
        int int14 = timeSeries4.getItemCount();
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date2, timeZone5);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date2, timeZone7);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date12 = fixedMillisecond11.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date12);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date12, timeZone15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date12, timeZone17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date2, timeZone17);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date2);
        long long22 = year21.getFirstMillisecond();
        java.util.Calendar calendar23 = null;
        try {
            long long24 = year21.getLastMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31507200000L) + "'", long22 == (-31507200000L));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        int int7 = timeSeries6.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long10 = fixedMillisecond9.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond9.previous();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond9.getLastMillisecond(calendar12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) 11);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class17);
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class20);
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries18.addAndOrUpdate(timeSeries21);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries22.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj29 = null;
        boolean boolean30 = month28.equals(obj29);
        int int31 = timeSeries22.getIndex((org.jfree.data.time.RegularTimePeriod) month28);
        long long32 = month28.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date35 = fixedMillisecond34.getTime();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        boolean boolean37 = month28.equals((java.lang.Object) day36);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day36, (double) (-1.0f));
        java.util.Calendar calendar40 = null;
        try {
            long long41 = day36.getLastMillisecond(calendar40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem39);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str6 = spreadsheetDate5.toString();
        boolean boolean7 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean8 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str11 = spreadsheetDate10.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str16 = spreadsheetDate15.toString();
        boolean boolean17 = spreadsheetDate13.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str22 = spreadsheetDate21.toString();
        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean24 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        int int25 = spreadsheetDate21.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str28 = spreadsheetDate27.toString();
        boolean boolean29 = spreadsheetDate21.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean30 = spreadsheetDate10.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str35 = spreadsheetDate34.toString();
        boolean boolean36 = spreadsheetDate32.isOn((org.jfree.data.time.SerialDate) spreadsheetDate34);
        int int37 = spreadsheetDate34.getMonth();
        org.jfree.data.time.SerialDate serialDate39 = spreadsheetDate34.getNearestDayOfWeek(1);
        boolean boolean40 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, serialDate39);
        try {
            org.jfree.data.time.SerialDate serialDate42 = spreadsheetDate5.getPreviousDayOfWeek(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "9-April-1900" + "'", str6.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-April-1900" + "'", str11.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "9-April-1900" + "'", str16.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 9 + "'", int25 == 9);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "9-April-1900" + "'", str28.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "9-April-1900" + "'", str35.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str3 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        boolean boolean9 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        spreadsheetDate24.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str32 = spreadsheetDate31.toString();
        boolean boolean33 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        boolean boolean39 = spreadsheetDate35.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int41 = spreadsheetDate37.getDayOfMonth();
        boolean boolean42 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int43 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays(100, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        int int46 = spreadsheetDate18.toSerial();
        java.lang.Class<?> wildcardClass47 = spreadsheetDate18.getClass();
        java.lang.Class class48 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass47);
        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass47);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9 + "'", int41 == 9);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 100 + "'", int46 == 100);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(class48);
        org.junit.Assert.assertNotNull(class49);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class8);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries13.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj20 = null;
        boolean boolean21 = month19.equals(obj20);
        int int22 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) month19);
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class24);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries25.addAndOrUpdate(timeSeries28);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries29);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year32 = month31.getYear();
        int int33 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) year32);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) month19, (org.jfree.data.time.RegularTimePeriod) year32);
        int int35 = timeSeries6.getMaximumItemCount();
        java.lang.String str36 = timeSeries6.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date39 = fixedMillisecond38.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date39);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date39);
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date39, timeZone42);
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date39, timeZone44);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date49 = fixedMillisecond48.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond(date49);
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date49);
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date49, timeZone52);
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date49, timeZone54);
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month(date39, timeZone54);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date39);
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date39);
        long long59 = year58.getFirstMillisecond();
        try {
            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) year58, (java.lang.Number) 1546329600000L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(year32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2147483647 + "'", int35 == 2147483647);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-31507200000L) + "'", long59 == (-31507200000L));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
        timeSeries17.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long21 = fixedMillisecond20.getMiddleMillisecond();
        long long22 = fixedMillisecond20.getFirstMillisecond();
        long long23 = fixedMillisecond20.getLastMillisecond();
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond20.getMiddleMillisecond(calendar24);
        java.util.Date date26 = fixedMillisecond20.getTime();
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond20.getMiddleMillisecond(calendar27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str31 = spreadsheetDate30.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str36 = spreadsheetDate35.toString();
        boolean boolean37 = spreadsheetDate33.isOn((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str42 = spreadsheetDate41.toString();
        boolean boolean43 = spreadsheetDate39.isOn((org.jfree.data.time.SerialDate) spreadsheetDate41);
        boolean boolean44 = spreadsheetDate35.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str49 = spreadsheetDate48.toString();
        boolean boolean50 = spreadsheetDate46.isOn((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str53 = spreadsheetDate52.toString();
        spreadsheetDate52.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str60 = spreadsheetDate59.toString();
        boolean boolean61 = spreadsheetDate57.isOn((org.jfree.data.time.SerialDate) spreadsheetDate59);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str66 = spreadsheetDate65.toString();
        boolean boolean67 = spreadsheetDate63.isOn((org.jfree.data.time.SerialDate) spreadsheetDate65);
        boolean boolean68 = spreadsheetDate59.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate65);
        int int69 = spreadsheetDate65.getDayOfMonth();
        boolean boolean70 = spreadsheetDate46.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate52, (org.jfree.data.time.SerialDate) spreadsheetDate65);
        int int71 = spreadsheetDate41.compare((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SerialDate serialDate72 = spreadsheetDate30.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean73 = fixedMillisecond20.equals((java.lang.Object) serialDate72);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 100L + "'", long28 == 100L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "9-April-1900" + "'", str31.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "9-April-1900" + "'", str36.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "9-April-1900" + "'", str42.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "9-April-1900" + "'", str49.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "9-April-1900" + "'", str53.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "9-April-1900" + "'", str60.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "9-April-1900" + "'", str66.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 9 + "'", int69 == 9);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem74);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("ThreadContext");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: ThreadContext" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: ThreadContext"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 1.0d);
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class7);
        int int9 = timeSeries8.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries8.removeChangeListener(seriesChangeListener10);
        java.util.Collection collection12 = timeSeries8.getTimePeriods();
        int int13 = timeSeriesDataItem5.compareTo((java.lang.Object) timeSeries8);
        timeSeriesDataItem5.setValue((java.lang.Number) 10L);
        java.lang.Number number16 = timeSeriesDataItem5.getValue();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long21 = fixedMillisecond20.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str26 = spreadsheetDate25.toString();
        boolean boolean27 = spreadsheetDate23.isOn((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str30 = spreadsheetDate29.toString();
        spreadsheetDate29.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str37 = spreadsheetDate36.toString();
        boolean boolean38 = spreadsheetDate34.isOn((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str43 = spreadsheetDate42.toString();
        boolean boolean44 = spreadsheetDate40.isOn((org.jfree.data.time.SerialDate) spreadsheetDate42);
        boolean boolean45 = spreadsheetDate36.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate42);
        int int46 = spreadsheetDate42.getDayOfMonth();
        boolean boolean47 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, (org.jfree.data.time.SerialDate) spreadsheetDate42);
        boolean boolean48 = fixedMillisecond20.equals((java.lang.Object) spreadsheetDate29);
        boolean boolean49 = day18.equals((java.lang.Object) fixedMillisecond20);
        java.lang.Class<?> wildcardClass50 = fixedMillisecond20.getClass();
        java.io.InputStream inputStream51 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("9-April-1900", (java.lang.Class) wildcardClass50);
        java.lang.Class class52 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass50);
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem5, (java.lang.Class) wildcardClass50);
        java.lang.Object obj54 = timeSeriesDataItem5.clone();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 10L + "'", number16.equals(10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "9-April-1900" + "'", str26.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "9-April-1900" + "'", str30.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "9-April-1900" + "'", str37.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "9-April-1900" + "'", str43.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 9 + "'", int46 == 9);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNull(inputStream51);
        org.junit.Assert.assertNotNull(class52);
        org.junit.Assert.assertNotNull(obj54);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj13 = null;
        boolean boolean14 = month12.equals(obj13);
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) month16);
        long long18 = month16.getFirstMillisecond();
        long long19 = month16.getLastMillisecond();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1559372400000L + "'", long18 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561964399999L + "'", long19 == 1561964399999L);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (52) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) 1, (-459), 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = year1.getSerialIndex();
        java.lang.Class<?> wildcardClass3 = year1.getClass();
        long long4 = year1.getMiddleMillisecond();
        long long5 = year1.getSerialIndex();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        boolean boolean7 = timeSeries2.getNotify();
        int int8 = timeSeries2.getMaximumItemCount();
        java.lang.String str9 = timeSeries2.getDescription();
        int int10 = timeSeries2.getMaximumItemCount();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year12 = month11.getYear();
        long long13 = year12.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.next();
        try {
            timeSeries2.update((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str17 = spreadsheetDate16.toString();
        boolean boolean18 = spreadsheetDate14.isOn((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        spreadsheetDate20.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str28 = spreadsheetDate27.toString();
        boolean boolean29 = spreadsheetDate25.isOn((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str34 = spreadsheetDate33.toString();
        boolean boolean35 = spreadsheetDate31.isOn((org.jfree.data.time.SerialDate) spreadsheetDate33);
        boolean boolean36 = spreadsheetDate27.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int37 = spreadsheetDate33.getDayOfMonth();
        boolean boolean38 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate20, (org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int39 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str42 = spreadsheetDate41.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str47 = spreadsheetDate46.toString();
        boolean boolean48 = spreadsheetDate44.isOn((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str53 = spreadsheetDate52.toString();
        boolean boolean54 = spreadsheetDate50.isOn((org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean55 = spreadsheetDate46.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str60 = spreadsheetDate59.toString();
        boolean boolean61 = spreadsheetDate57.isOn((org.jfree.data.time.SerialDate) spreadsheetDate59);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str64 = spreadsheetDate63.toString();
        spreadsheetDate63.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str71 = spreadsheetDate70.toString();
        boolean boolean72 = spreadsheetDate68.isOn((org.jfree.data.time.SerialDate) spreadsheetDate70);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str77 = spreadsheetDate76.toString();
        boolean boolean78 = spreadsheetDate74.isOn((org.jfree.data.time.SerialDate) spreadsheetDate76);
        boolean boolean79 = spreadsheetDate70.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate76);
        int int80 = spreadsheetDate76.getDayOfMonth();
        boolean boolean81 = spreadsheetDate57.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate63, (org.jfree.data.time.SerialDate) spreadsheetDate76);
        int int82 = spreadsheetDate52.compare((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SerialDate serialDate83 = spreadsheetDate41.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SerialDate serialDate84 = spreadsheetDate14.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate57);
        int int85 = spreadsheetDate57.getMonth();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "9-April-1900" + "'", str17.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "9-April-1900" + "'", str28.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "9-April-1900" + "'", str34.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 9 + "'", int37 == 9);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "9-April-1900" + "'", str42.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "9-April-1900" + "'", str47.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "9-April-1900" + "'", str53.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "9-April-1900" + "'", str60.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "9-April-1900" + "'", str64.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "9-April-1900" + "'", str71.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "9-April-1900" + "'", str77.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 9 + "'", int80 == 9);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 4 + "'", int85 == 4);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.String str10 = timeSeries6.getDescription();
        java.lang.String str11 = timeSeries6.getDescription();
        timeSeries6.fireSeriesChanged();
        java.lang.Class class13 = timeSeries6.getTimePeriodClass();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(class13);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Last", "", "ERROR : Relative To String", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class8);
        timeSeries9.setDomainDescription("October 0");
        java.lang.Object obj12 = timeSeries9.clone();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = null;
        java.lang.Number number15 = null;
        try {
            timeSeries4.add(regularTimePeriod14, number15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(timeSeries13);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.String str10 = timeSeries6.getDescription();
        timeSeries6.setRangeDescription("Last");
        int int13 = timeSeries6.getItemCount();
        timeSeries6.removeAgedItems(false);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        long long4 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getMiddleMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date11 = fixedMillisecond10.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date11);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date11, timeZone14);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date7, timeZone14);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(serialDate17);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.util.Date date3 = fixedMillisecond1.getTime();
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        long long7 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = year1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year1.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str17 = spreadsheetDate16.toString();
        boolean boolean18 = spreadsheetDate14.isOn((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        spreadsheetDate20.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str28 = spreadsheetDate27.toString();
        boolean boolean29 = spreadsheetDate25.isOn((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str34 = spreadsheetDate33.toString();
        boolean boolean35 = spreadsheetDate31.isOn((org.jfree.data.time.SerialDate) spreadsheetDate33);
        boolean boolean36 = spreadsheetDate27.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int37 = spreadsheetDate33.getDayOfMonth();
        boolean boolean38 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate20, (org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int39 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str42 = spreadsheetDate41.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str47 = spreadsheetDate46.toString();
        boolean boolean48 = spreadsheetDate44.isOn((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str53 = spreadsheetDate52.toString();
        boolean boolean54 = spreadsheetDate50.isOn((org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean55 = spreadsheetDate46.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str60 = spreadsheetDate59.toString();
        boolean boolean61 = spreadsheetDate57.isOn((org.jfree.data.time.SerialDate) spreadsheetDate59);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str64 = spreadsheetDate63.toString();
        spreadsheetDate63.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str71 = spreadsheetDate70.toString();
        boolean boolean72 = spreadsheetDate68.isOn((org.jfree.data.time.SerialDate) spreadsheetDate70);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str77 = spreadsheetDate76.toString();
        boolean boolean78 = spreadsheetDate74.isOn((org.jfree.data.time.SerialDate) spreadsheetDate76);
        boolean boolean79 = spreadsheetDate70.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate76);
        int int80 = spreadsheetDate76.getDayOfMonth();
        boolean boolean81 = spreadsheetDate57.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate63, (org.jfree.data.time.SerialDate) spreadsheetDate76);
        int int82 = spreadsheetDate52.compare((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SerialDate serialDate83 = spreadsheetDate41.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SerialDate serialDate84 = spreadsheetDate14.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate57);
        try {
            org.jfree.data.time.SerialDate serialDate86 = spreadsheetDate14.getPreviousDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "9-April-1900" + "'", str17.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "9-April-1900" + "'", str28.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "9-April-1900" + "'", str34.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 9 + "'", int37 == 9);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "9-April-1900" + "'", str42.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "9-April-1900" + "'", str47.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "9-April-1900" + "'", str53.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "9-April-1900" + "'", str60.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "9-April-1900" + "'", str64.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "9-April-1900" + "'", str71.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "9-April-1900" + "'", str77.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 9 + "'", int80 == 9);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(serialDate84);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        timeSeries2.setDomainDescription("October 0");
        java.lang.Object obj5 = timeSeries2.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long8 = fixedMillisecond7.getMiddleMillisecond();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class10);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class13);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries11.addAndOrUpdate(timeSeries14);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries15.createCopy(0, (int) (short) 1);
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class20);
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class23);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries21.addAndOrUpdate(timeSeries24);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries18.addAndOrUpdate(timeSeries25);
        java.lang.Object obj27 = timeSeries26.clone();
        int int28 = fixedMillisecond7.compareTo(obj27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 0L);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long5 = fixedMillisecond4.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        spreadsheetDate13.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str27 = spreadsheetDate26.toString();
        boolean boolean28 = spreadsheetDate24.isOn((org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean29 = spreadsheetDate20.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        int int30 = spreadsheetDate26.getDayOfMonth();
        boolean boolean31 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean32 = fixedMillisecond4.equals((java.lang.Object) spreadsheetDate13);
        boolean boolean33 = day2.equals((java.lang.Object) fixedMillisecond4);
        java.lang.Class<?> wildcardClass34 = fixedMillisecond4.getClass();
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
        java.io.InputStream inputStream36 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass34);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str40 = spreadsheetDate39.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str45 = spreadsheetDate44.toString();
        boolean boolean46 = spreadsheetDate42.isOn((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str51 = spreadsheetDate50.toString();
        boolean boolean52 = spreadsheetDate48.isOn((org.jfree.data.time.SerialDate) spreadsheetDate50);
        boolean boolean53 = spreadsheetDate44.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str58 = spreadsheetDate57.toString();
        boolean boolean59 = spreadsheetDate55.isOn((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str62 = spreadsheetDate61.toString();
        spreadsheetDate61.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str69 = spreadsheetDate68.toString();
        boolean boolean70 = spreadsheetDate66.isOn((org.jfree.data.time.SerialDate) spreadsheetDate68);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate72 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str75 = spreadsheetDate74.toString();
        boolean boolean76 = spreadsheetDate72.isOn((org.jfree.data.time.SerialDate) spreadsheetDate74);
        boolean boolean77 = spreadsheetDate68.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate74);
        int int78 = spreadsheetDate74.getDayOfMonth();
        boolean boolean79 = spreadsheetDate55.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate61, (org.jfree.data.time.SerialDate) spreadsheetDate74);
        int int80 = spreadsheetDate50.compare((org.jfree.data.time.SerialDate) spreadsheetDate55);
        org.jfree.data.time.SerialDate serialDate81 = spreadsheetDate39.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate55);
        org.jfree.data.time.SerialDate serialDate82 = org.jfree.data.time.SerialDate.addDays(100, (org.jfree.data.time.SerialDate) spreadsheetDate55);
        int int83 = spreadsheetDate55.toSerial();
        java.lang.Class<?> wildcardClass84 = spreadsheetDate55.getClass();
        java.lang.Class class85 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass84);
        java.lang.Class class86 = org.jfree.data.time.RegularTimePeriod.downsize(class85);
        java.lang.Object obj87 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass34, class86);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "9-April-1900" + "'", str27.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertNotNull(inputStream36);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "9-April-1900" + "'", str40.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "9-April-1900" + "'", str45.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "9-April-1900" + "'", str51.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "9-April-1900" + "'", str58.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "9-April-1900" + "'", str62.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "9-April-1900" + "'", str69.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "9-April-1900" + "'", str75.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 9 + "'", int78 == 9);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertNotNull(serialDate81);
        org.junit.Assert.assertNotNull(serialDate82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 100 + "'", int83 == 100);
        org.junit.Assert.assertNotNull(wildcardClass84);
        org.junit.Assert.assertNotNull(class85);
        org.junit.Assert.assertNotNull(class86);
        org.junit.Assert.assertNull(obj87);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(1969);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str7 = spreadsheetDate6.toString();
        boolean boolean8 = spreadsheetDate4.isOn((org.jfree.data.time.SerialDate) spreadsheetDate6);
        boolean boolean9 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9-April-1900" + "'", str7.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        long long4 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getMiddleMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond1.getTime();
        long long8 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str3 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        boolean boolean9 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        spreadsheetDate24.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str32 = spreadsheetDate31.toString();
        boolean boolean33 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        boolean boolean39 = spreadsheetDate35.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int41 = spreadsheetDate37.getDayOfMonth();
        boolean boolean42 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int43 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays(100, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str48 = spreadsheetDate47.toString();
        spreadsheetDate47.setDescription("9-April-1900");
        int int51 = spreadsheetDate47.toSerial();
        boolean boolean52 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SerialDate serialDate54 = spreadsheetDate47.getNearestDayOfWeek(4);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(serialDate54);
        long long56 = day55.getFirstMillisecond();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long62 = fixedMillisecond61.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str67 = spreadsheetDate66.toString();
        boolean boolean68 = spreadsheetDate64.isOn((org.jfree.data.time.SerialDate) spreadsheetDate66);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str71 = spreadsheetDate70.toString();
        spreadsheetDate70.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str78 = spreadsheetDate77.toString();
        boolean boolean79 = spreadsheetDate75.isOn((org.jfree.data.time.SerialDate) spreadsheetDate77);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate81 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate83 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str84 = spreadsheetDate83.toString();
        boolean boolean85 = spreadsheetDate81.isOn((org.jfree.data.time.SerialDate) spreadsheetDate83);
        boolean boolean86 = spreadsheetDate77.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate83);
        int int87 = spreadsheetDate83.getDayOfMonth();
        boolean boolean88 = spreadsheetDate64.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate70, (org.jfree.data.time.SerialDate) spreadsheetDate83);
        boolean boolean89 = fixedMillisecond61.equals((java.lang.Object) spreadsheetDate70);
        boolean boolean90 = day59.equals((java.lang.Object) fixedMillisecond61);
        java.lang.Class<?> wildcardClass91 = fixedMillisecond61.getClass();
        java.io.InputStream inputStream92 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("9-April-1900", (java.lang.Class) wildcardClass91);
        java.net.URL uRL93 = org.jfree.chart.util.ObjectUtilities.getResource("April", (java.lang.Class) wildcardClass91);
        org.jfree.data.time.TimeSeries timeSeries94 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day55, (java.lang.Class) wildcardClass91);
        java.lang.ClassLoader classLoader95 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass91);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9 + "'", int41 == 9);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "9-April-1900" + "'", str48.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 100 + "'", int51 == 100);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-2200665600000L) + "'", long56 == (-2200665600000L));
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 100L + "'", long62 == 100L);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "9-April-1900" + "'", str67.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "9-April-1900" + "'", str71.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "9-April-1900" + "'", str78.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "9-April-1900" + "'", str84.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 9 + "'", int87 == 9);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(wildcardClass91);
        org.junit.Assert.assertNull(inputStream92);
        org.junit.Assert.assertNull(uRL93);
        org.junit.Assert.assertNotNull(classLoader95);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        long long4 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getMiddleMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond1.getTime();
        java.lang.Class<?> wildcardClass8 = fixedMillisecond1.getClass();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getLastMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int13 = spreadsheetDate9.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str16 = spreadsheetDate15.toString();
        boolean boolean17 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str22 = spreadsheetDate21.toString();
        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str28 = spreadsheetDate27.toString();
        boolean boolean29 = spreadsheetDate25.isOn((org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean30 = spreadsheetDate21.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean31 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate21);
        java.lang.String str32 = spreadsheetDate15.getDescription();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "9-April-1900" + "'", str16.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "9-April-1900" + "'", str28.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(str32);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        timeSeries5.setDomainDescription("October 0");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        timeSeries5.delete(regularTimePeriod9);
        java.lang.Class<?> wildcardClass11 = timeSeries5.getClass();
        java.util.List list12 = timeSeries5.getItems();
        boolean boolean13 = year0.equals((java.lang.Object) timeSeries5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        boolean boolean7 = timeSeries2.getNotify();
        timeSeries2.setDomainDescription("hi!");
        java.lang.String str10 = timeSeries2.getRangeDescription();
        timeSeries2.setRangeDescription("1969");
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("ClassContext");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("ClassContext");
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        java.lang.String str7 = seriesException6.toString();
        seriesException4.addSuppressed((java.lang.Throwable) seriesException6);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: ClassContext" + "'", str2.equals("org.jfree.data.general.SeriesException: ClassContext"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str7.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str2 = spreadsheetDate1.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str7 = spreadsheetDate6.toString();
        boolean boolean8 = spreadsheetDate4.isOn((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str13 = spreadsheetDate12.toString();
        boolean boolean14 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean15 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str20 = spreadsheetDate19.toString();
        boolean boolean21 = spreadsheetDate17.isOn((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str24 = spreadsheetDate23.toString();
        spreadsheetDate23.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str31 = spreadsheetDate30.toString();
        boolean boolean32 = spreadsheetDate28.isOn((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str37 = spreadsheetDate36.toString();
        boolean boolean38 = spreadsheetDate34.isOn((org.jfree.data.time.SerialDate) spreadsheetDate36);
        boolean boolean39 = spreadsheetDate30.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate36);
        int int40 = spreadsheetDate36.getDayOfMonth();
        boolean boolean41 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, (org.jfree.data.time.SerialDate) spreadsheetDate36);
        int int42 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SerialDate serialDate43 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SerialDate serialDate45 = spreadsheetDate17.getFollowingDayOfWeek(3);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "9-April-1900" + "'", str2.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9-April-1900" + "'", str7.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "9-April-1900" + "'", str13.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "9-April-1900" + "'", str20.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "9-April-1900" + "'", str24.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "9-April-1900" + "'", str31.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "9-April-1900" + "'", str37.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 9 + "'", int40 == 9);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate45);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        org.jfree.data.time.Year year5 = org.jfree.data.time.Year.parseYear("2019");
        java.lang.Number number6 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate2);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int3 = month2.getMonth();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Last", "", "ERROR : Relative To String", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class8);
        timeSeries9.setDomainDescription("October 0");
        java.lang.Object obj12 = timeSeries9.clone();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date16 = fixedMillisecond15.getTime();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int20 = month19.getMonth();
        java.lang.String str21 = month19.toString();
        java.lang.String str22 = month19.toString();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) month19);
        try {
            timeSeries23.delete(2019, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "October 0" + "'", str21.equals("October 0"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "October 0" + "'", str22.equals("October 0"));
        org.junit.Assert.assertNotNull(timeSeries23);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        long long4 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getMiddleMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date7);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date7, timeZone11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long15 = fixedMillisecond14.getMiddleMillisecond();
        long long16 = fixedMillisecond14.getFirstMillisecond();
        long long17 = fixedMillisecond14.getSerialIndex();
        java.util.Date date18 = fixedMillisecond14.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date21 = fixedMillisecond20.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date21);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date21, timeZone24);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date18, timeZone24);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date7, timeZone24);
        java.lang.Class<?> wildcardClass28 = timeZone24.getClass();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(wildcardClass28);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str3 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        boolean boolean9 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        spreadsheetDate24.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str32 = spreadsheetDate31.toString();
        boolean boolean33 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        boolean boolean39 = spreadsheetDate35.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int41 = spreadsheetDate37.getDayOfMonth();
        boolean boolean42 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int43 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays(100, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        int int46 = spreadsheetDate18.toSerial();
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate18);
        java.lang.Object obj48 = null;
        int int49 = day47.compareTo(obj48);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9 + "'", int41 == 9);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 100 + "'", int46 == 100);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        int int2 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str7 = spreadsheetDate6.toString();
        boolean boolean8 = spreadsheetDate4.isOn((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str13 = spreadsheetDate12.toString();
        boolean boolean14 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean15 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str20 = spreadsheetDate19.toString();
        boolean boolean21 = spreadsheetDate17.isOn((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str24 = spreadsheetDate23.toString();
        spreadsheetDate23.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str31 = spreadsheetDate30.toString();
        boolean boolean32 = spreadsheetDate28.isOn((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str37 = spreadsheetDate36.toString();
        boolean boolean38 = spreadsheetDate34.isOn((org.jfree.data.time.SerialDate) spreadsheetDate36);
        boolean boolean39 = spreadsheetDate30.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate36);
        int int40 = spreadsheetDate36.getDayOfMonth();
        boolean boolean41 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, (org.jfree.data.time.SerialDate) spreadsheetDate36);
        int int42 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean43 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        java.lang.String str44 = spreadsheetDate1.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9-April-1900" + "'", str7.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "9-April-1900" + "'", str13.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "9-April-1900" + "'", str20.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "9-April-1900" + "'", str24.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "9-April-1900" + "'", str31.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "9-April-1900" + "'", str37.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 9 + "'", int40 == 9);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "9-April-1900" + "'", str44.equals("9-April-1900"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str3 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        boolean boolean9 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        spreadsheetDate24.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str32 = spreadsheetDate31.toString();
        boolean boolean33 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        boolean boolean39 = spreadsheetDate35.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int41 = spreadsheetDate37.getDayOfMonth();
        boolean boolean42 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int43 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays(100, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str48 = spreadsheetDate47.toString();
        spreadsheetDate47.setDescription("9-April-1900");
        int int51 = spreadsheetDate47.toSerial();
        boolean boolean52 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SerialDate serialDate54 = spreadsheetDate47.getNearestDayOfWeek(4);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(serialDate54);
        long long56 = day55.getFirstMillisecond();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long62 = fixedMillisecond61.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str67 = spreadsheetDate66.toString();
        boolean boolean68 = spreadsheetDate64.isOn((org.jfree.data.time.SerialDate) spreadsheetDate66);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str71 = spreadsheetDate70.toString();
        spreadsheetDate70.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str78 = spreadsheetDate77.toString();
        boolean boolean79 = spreadsheetDate75.isOn((org.jfree.data.time.SerialDate) spreadsheetDate77);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate81 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate83 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str84 = spreadsheetDate83.toString();
        boolean boolean85 = spreadsheetDate81.isOn((org.jfree.data.time.SerialDate) spreadsheetDate83);
        boolean boolean86 = spreadsheetDate77.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate83);
        int int87 = spreadsheetDate83.getDayOfMonth();
        boolean boolean88 = spreadsheetDate64.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate70, (org.jfree.data.time.SerialDate) spreadsheetDate83);
        boolean boolean89 = fixedMillisecond61.equals((java.lang.Object) spreadsheetDate70);
        boolean boolean90 = day59.equals((java.lang.Object) fixedMillisecond61);
        java.lang.Class<?> wildcardClass91 = fixedMillisecond61.getClass();
        java.io.InputStream inputStream92 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("9-April-1900", (java.lang.Class) wildcardClass91);
        java.net.URL uRL93 = org.jfree.chart.util.ObjectUtilities.getResource("April", (java.lang.Class) wildcardClass91);
        org.jfree.data.time.TimeSeries timeSeries94 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day55, (java.lang.Class) wildcardClass91);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = day55.next();
        long long96 = day55.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9 + "'", int41 == 9);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "9-April-1900" + "'", str48.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 100 + "'", int51 == 100);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-2200665600000L) + "'", long56 == (-2200665600000L));
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 100L + "'", long62 == 100L);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "9-April-1900" + "'", str67.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "9-April-1900" + "'", str71.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "9-April-1900" + "'", str78.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "9-April-1900" + "'", str84.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 9 + "'", int87 == 9);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(wildcardClass91);
        org.junit.Assert.assertNull(inputStream92);
        org.junit.Assert.assertNull(uRL93);
        org.junit.Assert.assertNotNull(regularTimePeriod95);
        org.junit.Assert.assertTrue("'" + long96 + "' != '" + (-2200579200001L) + "'", long96 == (-2200579200001L));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        org.jfree.data.time.Year year5 = org.jfree.data.time.Year.parseYear("2019");
        java.lang.Number number6 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        long long10 = month9.getSerialIndex();
        long long11 = month9.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month9.previous();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month9);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class15);
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class18);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries16.addAndOrUpdate(timeSeries19);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj27 = null;
        boolean boolean28 = month26.equals(obj27);
        int int29 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) month26);
        long long30 = month26.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date33 = fixedMillisecond32.getTime();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date33);
        boolean boolean35 = month26.equals((java.lang.Object) day34);
        java.lang.Object obj36 = null;
        boolean boolean37 = day34.equals(obj36);
        int int38 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) day34);
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date3 = fixedMillisecond2.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(1, year5);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
        java.lang.Class class18 = timeSeries9.getTimePeriodClass();
        java.lang.Class class19 = timeSeries9.getTimePeriodClass();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertNull(class19);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getEnd();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str6 = spreadsheetDate5.toString();
        boolean boolean7 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str12 = spreadsheetDate11.toString();
        boolean boolean13 = spreadsheetDate9.isOn((org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean14 = spreadsheetDate5.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int15 = spreadsheetDate11.getDayOfMonth();
        int int16 = spreadsheetDate11.getMonth();
        boolean boolean17 = month0.equals((java.lang.Object) spreadsheetDate11);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "9-April-1900" + "'", str6.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-April-1900" + "'", str12.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int13 = spreadsheetDate3.getDayOfMonth();
        spreadsheetDate3.setDescription("2019");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str18 = spreadsheetDate17.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str23 = spreadsheetDate22.toString();
        boolean boolean24 = spreadsheetDate20.isOn((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str29 = spreadsheetDate28.toString();
        boolean boolean30 = spreadsheetDate26.isOn((org.jfree.data.time.SerialDate) spreadsheetDate28);
        boolean boolean31 = spreadsheetDate22.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str36 = spreadsheetDate35.toString();
        boolean boolean37 = spreadsheetDate33.isOn((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str40 = spreadsheetDate39.toString();
        spreadsheetDate39.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str47 = spreadsheetDate46.toString();
        boolean boolean48 = spreadsheetDate44.isOn((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str53 = spreadsheetDate52.toString();
        boolean boolean54 = spreadsheetDate50.isOn((org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean55 = spreadsheetDate46.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate52);
        int int56 = spreadsheetDate52.getDayOfMonth();
        boolean boolean57 = spreadsheetDate33.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate39, (org.jfree.data.time.SerialDate) spreadsheetDate52);
        int int58 = spreadsheetDate28.compare((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SerialDate serialDate59 = spreadsheetDate17.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SerialDate serialDate61 = spreadsheetDate33.getFollowingDayOfWeek(3);
        boolean boolean62 = spreadsheetDate3.isOn(serialDate61);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "9-April-1900" + "'", str18.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "9-April-1900" + "'", str23.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "9-April-1900" + "'", str29.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "9-April-1900" + "'", str36.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "9-April-1900" + "'", str40.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "9-April-1900" + "'", str47.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "9-April-1900" + "'", str53.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 9 + "'", int56 == 9);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        long long7 = timeSeries6.getMaximumItemAge();
        int int8 = timeSeries6.getItemCount();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(2019);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str3 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        boolean boolean9 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        spreadsheetDate24.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str32 = spreadsheetDate31.toString();
        boolean boolean33 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        boolean boolean39 = spreadsheetDate35.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int41 = spreadsheetDate37.getDayOfMonth();
        boolean boolean42 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int43 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        int int46 = spreadsheetDate18.getYYYY();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9 + "'", int41 == 9);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1900 + "'", int46 == 1900);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        java.util.Date date5 = month4.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date8 = fixedMillisecond7.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date8, timeZone11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date8, timeZone13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date5, timeZone13);
        long long16 = month15.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2649600000L) + "'", long16 == (-2649600000L));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        long long4 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getMiddleMillisecond(calendar5);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class8);
        timeSeries9.setDomainDescription("October 0");
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        timeSeries9.delete(regularTimePeriod13);
        timeSeries9.removeAgedItems(true);
        timeSeries9.setMaximumItemAge(100L);
        int int19 = fixedMillisecond1.compareTo((java.lang.Object) timeSeries9);
        java.lang.String str20 = timeSeries9.getRangeDescription();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Value" + "'", str20.equals("Value"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        long long5 = year4.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 28799999L + "'", long5 == 28799999L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = year1.getSerialIndex();
        long long3 = year1.getLastMillisecond();
        int int4 = year1.getYear();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year1.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = year1.getSerialIndex();
        java.lang.String str3 = year1.toString();
        int int4 = year1.getYear();
        long long5 = year1.getMiddleMillisecond();
        long long6 = year1.getFirstMillisecond();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        timeSeries2.clear();
        java.lang.Comparable comparable5 = timeSeries2.getKey();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year7 = month6.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date10 = fixedMillisecond9.getTime();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (double) 43629L);
        timeSeriesDataItem13.setValue((java.lang.Number) 1560409200000L);
        java.lang.Number number16 = timeSeriesDataItem13.getValue();
        org.jfree.data.time.Year year18 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str22 = spreadsheetDate21.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str27 = spreadsheetDate26.toString();
        boolean boolean28 = spreadsheetDate24.isOn((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str33 = spreadsheetDate32.toString();
        boolean boolean34 = spreadsheetDate30.isOn((org.jfree.data.time.SerialDate) spreadsheetDate32);
        boolean boolean35 = spreadsheetDate26.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str40 = spreadsheetDate39.toString();
        boolean boolean41 = spreadsheetDate37.isOn((org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str44 = spreadsheetDate43.toString();
        spreadsheetDate43.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str51 = spreadsheetDate50.toString();
        boolean boolean52 = spreadsheetDate48.isOn((org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str57 = spreadsheetDate56.toString();
        boolean boolean58 = spreadsheetDate54.isOn((org.jfree.data.time.SerialDate) spreadsheetDate56);
        boolean boolean59 = spreadsheetDate50.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate56);
        int int60 = spreadsheetDate56.getDayOfMonth();
        boolean boolean61 = spreadsheetDate37.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate43, (org.jfree.data.time.SerialDate) spreadsheetDate56);
        int int62 = spreadsheetDate32.compare((org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SerialDate serialDate63 = spreadsheetDate21.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.addDays(100, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int65 = spreadsheetDate37.toSerial();
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int67 = year18.compareTo((java.lang.Object) day66);
        boolean boolean68 = timeSeriesDataItem13.equals((java.lang.Object) year18);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 1.0f + "'", comparable5.equals(1.0f));
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 1560409200000L + "'", number16.equals(1560409200000L));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "9-April-1900" + "'", str27.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-April-1900" + "'", str33.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "9-April-1900" + "'", str40.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "9-April-1900" + "'", str44.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "9-April-1900" + "'", str51.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "9-April-1900" + "'", str57.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 9 + "'", int60 == 9);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 100 + "'", int65 == 100);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
        java.lang.Object obj18 = timeSeries17.clone();
        boolean boolean20 = timeSeries17.equals((java.lang.Object) "ClassContext");
        java.lang.Object obj21 = timeSeries17.clone();
        timeSeries17.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener24);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener18);
        java.lang.Object obj20 = timeSeries9.clone();
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class22);
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class25);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries23.addAndOrUpdate(timeSeries26);
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries27.createCopy(0, (int) (short) 1);
        timeSeries30.setMaximumItemCount(5);
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries9.addAndOrUpdate(timeSeries30);
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries30.addPropertyChangeListener(propertyChangeListener34);
        java.lang.Class class37 = null;
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class37);
        boolean boolean39 = timeSeries38.getNotify();
        timeSeries38.clear();
        java.lang.Comparable comparable41 = timeSeries38.getKey();
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year43 = month42.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date46 = fixedMillisecond45.getTime();
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries38.createCopy((org.jfree.data.time.RegularTimePeriod) year43, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond45);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year43, (double) 43629L);
        timeSeriesDataItem49.setValue((java.lang.Number) 1560409200000L);
        try {
            timeSeries30.add(timeSeriesDataItem49, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + comparable41 + "' != '" + 1.0f + "'", comparable41.equals(1.0f));
        org.junit.Assert.assertNotNull(year43);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeSeries47);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj13 = null;
        boolean boolean14 = month12.equals(obj13);
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        long long16 = month12.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date19 = fixedMillisecond18.getTime();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        boolean boolean21 = month12.equals((java.lang.Object) day20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day20, 0.0d);
        int int24 = day20.getMonth();
        long long25 = day20.getLastMillisecond();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 12 + "'", int24 == 12);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28799999L + "'", long25 == 28799999L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        timeSeries2.fireSeriesChanged();
        int int5 = timeSeries2.getMaximumItemCount();
        java.lang.Object obj6 = timeSeries2.clone();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeries2.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int13 = spreadsheetDate9.getYYYY();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj13 = null;
        boolean boolean14 = month12.equals(obj13);
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) month16);
        timeSeries6.setNotify(true);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int23 = month22.getMonth();
        java.lang.String str24 = month22.toString();
        java.lang.String str25 = month22.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) month22);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = timeSeries6.getTimePeriod(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "October 0" + "'", str24.equals("October 0"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "October 0" + "'", str25.equals("October 0"));
        org.junit.Assert.assertNull(timeSeriesDataItem26);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: ClassContext");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        long long4 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getMiddleMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond1.getTime();
        java.lang.Class<?> wildcardClass8 = fixedMillisecond1.getClass();
        java.util.Calendar calendar9 = null;
        fixedMillisecond1.peg(calendar9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long13 = fixedMillisecond12.getMiddleMillisecond();
        long long14 = fixedMillisecond12.getFirstMillisecond();
        long long15 = fixedMillisecond12.getLastMillisecond();
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond12.getMiddleMillisecond(calendar16);
        java.util.Date date18 = fixedMillisecond12.getTime();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date18);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date18, timeZone22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long26 = fixedMillisecond25.getMiddleMillisecond();
        long long27 = fixedMillisecond25.getFirstMillisecond();
        long long28 = fixedMillisecond25.getSerialIndex();
        java.util.Date date29 = fixedMillisecond25.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date32 = fixedMillisecond31.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(date32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date32);
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date32, timeZone35);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(date29, timeZone35);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date18, timeZone35);
        boolean boolean39 = fixedMillisecond1.equals((java.lang.Object) day38);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 100L + "'", long28 == 100L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.String str10 = timeSeries6.getDescription();
        timeSeries6.setRangeDescription("Last");
        timeSeries6.setMaximumItemCount(12);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 1.0d);
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class7);
        int int9 = timeSeries8.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries8.removeChangeListener(seriesChangeListener10);
        java.util.Collection collection12 = timeSeries8.getTimePeriods();
        int int13 = timeSeriesDataItem5.compareTo((java.lang.Object) timeSeries8);
        java.lang.Number number14 = timeSeriesDataItem5.getValue();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class16);
        timeSeries17.setDomainDescription("October 0");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
        timeSeries17.delete(regularTimePeriod21);
        timeSeries17.removeAgedItems(true);
        timeSeries17.setMaximumItemAge(100L);
        int int27 = timeSeriesDataItem5.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year29 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str33 = spreadsheetDate32.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        boolean boolean39 = spreadsheetDate35.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str44 = spreadsheetDate43.toString();
        boolean boolean45 = spreadsheetDate41.isOn((org.jfree.data.time.SerialDate) spreadsheetDate43);
        boolean boolean46 = spreadsheetDate37.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate43);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str51 = spreadsheetDate50.toString();
        boolean boolean52 = spreadsheetDate48.isOn((org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str55 = spreadsheetDate54.toString();
        spreadsheetDate54.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str62 = spreadsheetDate61.toString();
        boolean boolean63 = spreadsheetDate59.isOn((org.jfree.data.time.SerialDate) spreadsheetDate61);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str68 = spreadsheetDate67.toString();
        boolean boolean69 = spreadsheetDate65.isOn((org.jfree.data.time.SerialDate) spreadsheetDate67);
        boolean boolean70 = spreadsheetDate61.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate67);
        int int71 = spreadsheetDate67.getDayOfMonth();
        boolean boolean72 = spreadsheetDate48.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate54, (org.jfree.data.time.SerialDate) spreadsheetDate67);
        int int73 = spreadsheetDate43.compare((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SerialDate serialDate74 = spreadsheetDate32.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.addDays(100, (org.jfree.data.time.SerialDate) spreadsheetDate48);
        int int76 = spreadsheetDate48.toSerial();
        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate48);
        int int78 = year29.compareTo((java.lang.Object) day77);
        boolean boolean79 = timeSeriesDataItem5.equals((java.lang.Object) int78);
        java.lang.Number number80 = null;
        timeSeriesDataItem5.setValue(number80);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1.0d + "'", number14.equals(1.0d));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(year29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-April-1900" + "'", str33.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "9-April-1900" + "'", str44.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "9-April-1900" + "'", str51.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "9-April-1900" + "'", str55.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "9-April-1900" + "'", str62.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "9-April-1900" + "'", str68.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 9 + "'", int71 == 9);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertNotNull(serialDate75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 100 + "'", int76 == 100);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 6, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        spreadsheetDate7.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str15 = spreadsheetDate14.toString();
        boolean boolean16 = spreadsheetDate12.isOn((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean23 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int24 = spreadsheetDate20.getDayOfMonth();
        boolean boolean25 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, (org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int26 = spreadsheetDate20.getYYYY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long29 = fixedMillisecond28.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str34 = spreadsheetDate33.toString();
        boolean boolean35 = spreadsheetDate31.isOn((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        spreadsheetDate37.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str45 = spreadsheetDate44.toString();
        boolean boolean46 = spreadsheetDate42.isOn((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str51 = spreadsheetDate50.toString();
        boolean boolean52 = spreadsheetDate48.isOn((org.jfree.data.time.SerialDate) spreadsheetDate50);
        boolean boolean53 = spreadsheetDate44.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate50);
        int int54 = spreadsheetDate50.getDayOfMonth();
        boolean boolean55 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate37, (org.jfree.data.time.SerialDate) spreadsheetDate50);
        boolean boolean56 = fixedMillisecond28.equals((java.lang.Object) spreadsheetDate37);
        boolean boolean57 = spreadsheetDate20.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate37);
        java.util.Date date58 = spreadsheetDate37.toDate();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "9-April-1900" + "'", str15.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 9 + "'", int24 == 9);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1900 + "'", int26 == 1900);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "9-April-1900" + "'", str34.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "9-April-1900" + "'", str45.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "9-April-1900" + "'", str51.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 9 + "'", int54 == 9);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(date58);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        long long3 = month2.getSerialIndex();
        long long4 = month2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class8);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries13.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj20 = null;
        boolean boolean21 = month19.equals(obj20);
        int int22 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) month19);
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class24);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries25.addAndOrUpdate(timeSeries28);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries29);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year32 = month31.getYear();
        int int33 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) year32);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) month19, (org.jfree.data.time.RegularTimePeriod) year32);
        try {
            timeSeries6.removeAgedItems(1560495599999L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(year32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(timeSeries34);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str3 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        boolean boolean9 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        spreadsheetDate24.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str32 = spreadsheetDate31.toString();
        boolean boolean33 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        boolean boolean39 = spreadsheetDate35.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int41 = spreadsheetDate37.getDayOfMonth();
        boolean boolean42 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int43 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addMonths(2, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int46 = spreadsheetDate2.getDayOfWeek();
        int int47 = spreadsheetDate2.getYYYY();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9 + "'", int41 == 9);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1900 + "'", int47 == 1900);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test171");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
//        int int18 = timeSeries9.getItemCount();
//        java.lang.Comparable comparable19 = timeSeries9.getKey();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str25 = spreadsheetDate24.toString();
//        boolean boolean26 = spreadsheetDate22.isOn((org.jfree.data.time.SerialDate) spreadsheetDate24);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str29 = spreadsheetDate28.toString();
//        spreadsheetDate28.setDescription("9-April-1900");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str36 = spreadsheetDate35.toString();
//        boolean boolean37 = spreadsheetDate33.isOn((org.jfree.data.time.SerialDate) spreadsheetDate35);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str42 = spreadsheetDate41.toString();
//        boolean boolean43 = spreadsheetDate39.isOn((org.jfree.data.time.SerialDate) spreadsheetDate41);
//        boolean boolean44 = spreadsheetDate35.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
//        int int45 = spreadsheetDate41.getDayOfMonth();
//        boolean boolean46 = spreadsheetDate22.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate28, (org.jfree.data.time.SerialDate) spreadsheetDate41);
//        boolean boolean47 = day20.equals((java.lang.Object) spreadsheetDate28);
//        long long48 = day20.getLastMillisecond();
//        java.lang.Class class50 = null;
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class50);
//        java.lang.Class class53 = null;
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class53);
//        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries51.addAndOrUpdate(timeSeries54);
//        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries55.createCopy(0, (int) (short) 1);
//        java.lang.Class class60 = null;
//        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class60);
//        java.lang.Class class63 = null;
//        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class63);
//        org.jfree.data.time.TimeSeries timeSeries65 = timeSeries61.addAndOrUpdate(timeSeries64);
//        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries58.addAndOrUpdate(timeSeries65);
//        org.jfree.data.time.Month month67 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year68 = month67.getYear();
//        long long69 = year68.getSerialIndex();
//        java.lang.String str70 = year68.toString();
//        timeSeries65.setKey((java.lang.Comparable) year68);
//        org.jfree.data.time.TimeSeries timeSeries72 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) day20, (org.jfree.data.time.RegularTimePeriod) year68);
//        java.util.Calendar calendar73 = null;
//        try {
//            day20.peg(calendar73);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + "Overwritten values from: 1.0" + "'", comparable19.equals("Overwritten values from: 1.0"));
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "9-April-1900" + "'", str29.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "9-April-1900" + "'", str36.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "9-April-1900" + "'", str42.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 9 + "'", int45 == 9);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560495599999L + "'", long48 == 1560495599999L);
//        org.junit.Assert.assertNotNull(timeSeries55);
//        org.junit.Assert.assertNotNull(timeSeries58);
//        org.junit.Assert.assertNotNull(timeSeries65);
//        org.junit.Assert.assertNotNull(timeSeries66);
//        org.junit.Assert.assertNotNull(year68);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2019L + "'", long69 == 2019L);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "2019" + "'", str70.equals("2019"));
//        org.junit.Assert.assertNotNull(timeSeries72);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 4);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str3 = spreadsheetDate2.toString();
        spreadsheetDate2.setDescription("9-April-1900");
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths(4, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        long long4 = fixedMillisecond1.getSerialIndex();
        java.util.Date date5 = fixedMillisecond1.getTime();
        long long6 = fixedMillisecond1.getFirstMillisecond();
        java.lang.Object obj7 = null;
        boolean boolean8 = fixedMillisecond1.equals(obj7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        java.util.Date date5 = month4.getEnd();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        boolean boolean8 = month6.equals((java.lang.Object) "org.jfree.data.general.SeriesException: ClassContext");
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Last", "", "ERROR : Relative To String", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class8);
        timeSeries9.setDomainDescription("October 0");
        java.lang.Object obj12 = timeSeries9.clone();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date16 = fixedMillisecond15.getTime();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int20 = month19.getMonth();
        java.lang.String str21 = month19.toString();
        java.lang.String str22 = month19.toString();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) month19);
        timeSeries13.clear();
        timeSeries13.setDescription("April");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries13.addOrUpdate(regularTimePeriod27, (double) 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "October 0" + "'", str21.equals("October 0"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "October 0" + "'", str22.equals("October 0"));
        org.junit.Assert.assertNotNull(timeSeries23);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        spreadsheetDate7.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str15 = spreadsheetDate14.toString();
        boolean boolean16 = spreadsheetDate12.isOn((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean23 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int24 = spreadsheetDate20.getDayOfMonth();
        boolean boolean25 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, (org.jfree.data.time.SerialDate) spreadsheetDate20);
        try {
            org.jfree.data.time.SerialDate serialDate27 = spreadsheetDate20.getNearestDayOfWeek((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "9-April-1900" + "'", str15.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 9 + "'", int24 == 9);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getMiddleMillisecond(calendar6);
        long long8 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Last", "", "ERROR : Relative To String", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class8);
        timeSeries9.setDomainDescription("October 0");
        java.lang.Object obj12 = timeSeries9.clone();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date16 = fixedMillisecond15.getTime();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int20 = month19.getMonth();
        java.lang.String str21 = month19.toString();
        java.lang.String str22 = month19.toString();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) month19);
        timeSeries13.clear();
        timeSeries13.setDescription("April");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries13.getDataItem((-459));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "October 0" + "'", str21.equals("October 0"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "October 0" + "'", str22.equals("October 0"));
        org.junit.Assert.assertNotNull(timeSeries23);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod3, (java.lang.Number) 10.0f);
        timeSeriesDataItem5.setValue((java.lang.Number) 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str6 = spreadsheetDate5.toString();
        boolean boolean7 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean8 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.util.Date date9 = spreadsheetDate1.toDate();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "9-April-1900" + "'", str6.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        long long3 = month2.getSerialIndex();
        long long4 = month2.getSerialIndex();
        int int5 = month2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.previous();
        try {
            org.jfree.data.time.Year year7 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.String str10 = timeSeries6.getDescription();
        java.lang.Comparable comparable11 = timeSeries6.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long14 = fixedMillisecond13.getMiddleMillisecond();
        long long15 = fixedMillisecond13.getFirstMillisecond();
        long long16 = fixedMillisecond13.getLastMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        java.lang.Object obj19 = null;
        boolean boolean20 = spreadsheetDate18.equals(obj19);
        boolean boolean21 = fixedMillisecond13.equals(obj19);
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries6.addChangeListener(seriesChangeListener23);
        try {
            org.jfree.data.time.TimeSeries timeSeries27 = timeSeries6.createCopy(2958465, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + "Overwritten values from: 1.0" + "'", comparable11.equals("Overwritten values from: 1.0"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str3 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        boolean boolean9 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        spreadsheetDate24.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str32 = spreadsheetDate31.toString();
        boolean boolean33 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        boolean boolean39 = spreadsheetDate35.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int41 = spreadsheetDate37.getDayOfMonth();
        boolean boolean42 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int43 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(4, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9 + "'", int41 == 9);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        timeSeries2.clear();
        int int5 = timeSeries2.getItemCount();
        java.lang.Object obj6 = timeSeries2.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        long long10 = fixedMillisecond8.getFirstMillisecond();
        long long11 = fixedMillisecond8.getSerialIndex();
        java.util.Date date12 = fixedMillisecond8.getTime();
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond8.getFirstMillisecond(calendar13);
        int int15 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        try {
            timeSeries2.removeAgedItems((long) 31, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        boolean boolean7 = timeSeries2.getNotify();
        long long8 = timeSeries2.getMaximumItemAge();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int7 = month6.getMonth();
        java.lang.String str8 = month6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        long long10 = month6.getLastMillisecond();
        java.util.Date date11 = month6.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date14 = fixedMillisecond13.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date14, timeZone17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date14, timeZone19);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date24 = fixedMillisecond23.getTime();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date24);
        java.util.Date date27 = month26.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date30 = fixedMillisecond29.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(date30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date30);
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date30, timeZone33);
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date30, timeZone35);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(date27, timeZone35);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date14, timeZone35);
        try {
            org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date11, timeZone35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 0" + "'", str8.equals("October 0"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62109475200001L) + "'", long10 == (-62109475200001L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(timeZone35);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.String str10 = timeSeries6.getDescription();
        timeSeries6.setDescription("9-April-1900");
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.String str10 = timeSeries6.getDescription();
        java.lang.String str11 = timeSeries6.getDescription();
        timeSeries6.setDomainDescription("January");
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class15);
        timeSeries16.setDomainDescription("October 0");
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries6.addAndOrUpdate(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(timeSeries19);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        timeSeries2.clear();
        java.lang.Comparable comparable5 = timeSeries2.getKey();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year7 = month6.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date10 = fixedMillisecond9.getTime();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Date date12 = year7.getStart();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 1.0f + "'", comparable5.equals(1.0f));
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries5.addAndOrUpdate(timeSeries8);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries9.createCopy(0, (int) (short) 1);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class17);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries15.addAndOrUpdate(timeSeries18);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries12.addAndOrUpdate(timeSeries19);
        java.lang.Object obj21 = timeSeries20.clone();
        int int22 = fixedMillisecond1.compareTo(obj21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) 2019);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long32 = fixedMillisecond31.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str37 = spreadsheetDate36.toString();
        boolean boolean38 = spreadsheetDate34.isOn((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str41 = spreadsheetDate40.toString();
        spreadsheetDate40.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str48 = spreadsheetDate47.toString();
        boolean boolean49 = spreadsheetDate45.isOn((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str54 = spreadsheetDate53.toString();
        boolean boolean55 = spreadsheetDate51.isOn((org.jfree.data.time.SerialDate) spreadsheetDate53);
        boolean boolean56 = spreadsheetDate47.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate53);
        int int57 = spreadsheetDate53.getDayOfMonth();
        boolean boolean58 = spreadsheetDate34.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate40, (org.jfree.data.time.SerialDate) spreadsheetDate53);
        boolean boolean59 = fixedMillisecond31.equals((java.lang.Object) spreadsheetDate40);
        boolean boolean60 = day29.equals((java.lang.Object) fixedMillisecond31);
        java.lang.Class<?> wildcardClass61 = fixedMillisecond31.getClass();
        java.io.InputStream inputStream62 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("9-April-1900", (java.lang.Class) wildcardClass61);
        java.lang.Class class63 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass61);
        java.lang.Object obj64 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("October", class63);
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "January", class63);
        java.lang.Class class67 = null;
        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class67);
        boolean boolean69 = timeSeries68.getNotify();
        org.jfree.data.time.Month month72 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int73 = month72.getMonth();
        java.lang.String str74 = month72.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = timeSeries68.getDataItem((org.jfree.data.time.RegularTimePeriod) month72);
        long long76 = month72.getLastMillisecond();
        org.jfree.data.time.Month month77 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year78 = month77.getYear();
        int int79 = month72.compareTo((java.lang.Object) year78);
        java.lang.Class class81 = null;
        org.jfree.data.time.TimeSeries timeSeries82 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class81);
        boolean boolean83 = timeSeries82.getNotify();
        org.jfree.data.time.Month month86 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int87 = month86.getMonth();
        java.lang.String str88 = month86.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem89 = timeSeries82.getDataItem((org.jfree.data.time.RegularTimePeriod) month86);
        long long90 = month86.getLastMillisecond();
        org.jfree.data.time.Month month91 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year92 = month91.getYear();
        int int93 = month86.compareTo((java.lang.Object) year92);
        org.jfree.data.time.TimeSeries timeSeries94 = timeSeries65.createCopy((org.jfree.data.time.RegularTimePeriod) year78, (org.jfree.data.time.RegularTimePeriod) year92);
        java.util.Calendar calendar95 = null;
        try {
            year92.peg(calendar95);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 100L + "'", long32 == 100L);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "9-April-1900" + "'", str37.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "9-April-1900" + "'", str41.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "9-April-1900" + "'", str48.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "9-April-1900" + "'", str54.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 9 + "'", int57 == 9);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNull(inputStream62);
        org.junit.Assert.assertNotNull(class63);
        org.junit.Assert.assertNull(obj64);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 10 + "'", int73 == 10);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "October 0" + "'", str74.equals("October 0"));
        org.junit.Assert.assertNull(timeSeriesDataItem75);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + (-62109475200001L) + "'", long76 == (-62109475200001L));
        org.junit.Assert.assertNotNull(year78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 10 + "'", int87 == 10);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "October 0" + "'", str88.equals("October 0"));
        org.junit.Assert.assertNull(timeSeriesDataItem89);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + (-62109475200001L) + "'", long90 == (-62109475200001L));
        org.junit.Assert.assertNotNull(year92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertNotNull(timeSeries94);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int13 = spreadsheetDate9.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str16 = spreadsheetDate15.toString();
        boolean boolean17 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        int int18 = spreadsheetDate9.toSerial();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "9-April-1900" + "'", str16.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) 'a', 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str9 = spreadsheetDate8.toString();
        boolean boolean10 = spreadsheetDate6.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str15 = spreadsheetDate14.toString();
        boolean boolean16 = spreadsheetDate12.isOn((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean17 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str22 = spreadsheetDate21.toString();
        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str26 = spreadsheetDate25.toString();
        spreadsheetDate25.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str33 = spreadsheetDate32.toString();
        boolean boolean34 = spreadsheetDate30.isOn((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str39 = spreadsheetDate38.toString();
        boolean boolean40 = spreadsheetDate36.isOn((org.jfree.data.time.SerialDate) spreadsheetDate38);
        boolean boolean41 = spreadsheetDate32.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        int int42 = spreadsheetDate38.getDayOfMonth();
        boolean boolean43 = spreadsheetDate19.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate38);
        int int44 = spreadsheetDate14.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate45 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addDays(100, (org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str49 = spreadsheetDate48.toString();
        spreadsheetDate48.setDescription("9-April-1900");
        int int52 = spreadsheetDate48.toSerial();
        boolean boolean53 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addMonths(30, (org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-April-1900" + "'", str9.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "9-April-1900" + "'", str15.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "9-April-1900" + "'", str26.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-April-1900" + "'", str33.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "9-April-1900" + "'", str39.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "9-April-1900" + "'", str49.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 100 + "'", int52 == 100);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(serialDate54);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str5 = spreadsheetDate4.toString();
        boolean boolean6 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str11 = spreadsheetDate10.toString();
        boolean boolean12 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean13 = spreadsheetDate4.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int14 = spreadsheetDate10.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str17 = spreadsheetDate16.toString();
        boolean boolean18 = spreadsheetDate10.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        int int19 = spreadsheetDate10.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str22 = spreadsheetDate21.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str27 = spreadsheetDate26.toString();
        boolean boolean28 = spreadsheetDate24.isOn((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str33 = spreadsheetDate32.toString();
        boolean boolean34 = spreadsheetDate30.isOn((org.jfree.data.time.SerialDate) spreadsheetDate32);
        boolean boolean35 = spreadsheetDate26.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str40 = spreadsheetDate39.toString();
        boolean boolean41 = spreadsheetDate37.isOn((org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str44 = spreadsheetDate43.toString();
        spreadsheetDate43.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str51 = spreadsheetDate50.toString();
        boolean boolean52 = spreadsheetDate48.isOn((org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str57 = spreadsheetDate56.toString();
        boolean boolean58 = spreadsheetDate54.isOn((org.jfree.data.time.SerialDate) spreadsheetDate56);
        boolean boolean59 = spreadsheetDate50.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate56);
        int int60 = spreadsheetDate56.getDayOfMonth();
        boolean boolean61 = spreadsheetDate37.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate43, (org.jfree.data.time.SerialDate) spreadsheetDate56);
        int int62 = spreadsheetDate32.compare((org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SerialDate serialDate63 = spreadsheetDate21.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str68 = spreadsheetDate67.toString();
        boolean boolean69 = spreadsheetDate65.isOn((org.jfree.data.time.SerialDate) spreadsheetDate67);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate73 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str74 = spreadsheetDate73.toString();
        boolean boolean75 = spreadsheetDate71.isOn((org.jfree.data.time.SerialDate) spreadsheetDate73);
        boolean boolean76 = spreadsheetDate67.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate73);
        int int77 = spreadsheetDate67.getDayOfMonth();
        int int78 = spreadsheetDate67.getDayOfWeek();
        boolean boolean79 = spreadsheetDate10.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate21, (org.jfree.data.time.SerialDate) spreadsheetDate67);
        org.jfree.data.time.SerialDate serialDate80 = org.jfree.data.time.SerialDate.addYears(4, (org.jfree.data.time.SerialDate) spreadsheetDate67);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-April-1900" + "'", str11.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 9 + "'", int14 == 9);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "9-April-1900" + "'", str17.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "9-April-1900" + "'", str27.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-April-1900" + "'", str33.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "9-April-1900" + "'", str40.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "9-April-1900" + "'", str44.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "9-April-1900" + "'", str51.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "9-April-1900" + "'", str57.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 9 + "'", int60 == 9);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "9-April-1900" + "'", str68.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "9-April-1900" + "'", str74.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 9 + "'", int77 == 9);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 2 + "'", int78 == 2);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertNotNull(serialDate80);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.String str10 = timeSeries6.getDescription();
        java.lang.String str11 = timeSeries6.getDescription();
        timeSeries6.setDomainDescription("January");
        java.lang.Object obj14 = timeSeries6.clone();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.String str10 = timeSeries6.getDescription();
        java.lang.String str11 = timeSeries6.getDescription();
        timeSeries6.fireSeriesChanged();
        java.util.Collection collection13 = timeSeries6.getTimePeriods();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(collection13);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test201");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
//        timeSeries2.setDomainDescription("October 0");
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
//        timeSeries2.delete(regularTimePeriod6);
//        timeSeries2.removeAgedItems(true);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str15 = spreadsheetDate14.toString();
//        boolean boolean16 = spreadsheetDate12.isOn((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str19 = spreadsheetDate18.toString();
//        spreadsheetDate18.setDescription("9-April-1900");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str26 = spreadsheetDate25.toString();
//        boolean boolean27 = spreadsheetDate23.isOn((org.jfree.data.time.SerialDate) spreadsheetDate25);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str32 = spreadsheetDate31.toString();
//        boolean boolean33 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
//        boolean boolean34 = spreadsheetDate25.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
//        int int35 = spreadsheetDate31.getDayOfMonth();
//        boolean boolean36 = spreadsheetDate12.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate18, (org.jfree.data.time.SerialDate) spreadsheetDate31);
//        boolean boolean37 = day10.equals((java.lang.Object) spreadsheetDate18);
//        long long38 = day10.getSerialIndex();
//        long long39 = day10.getSerialIndex();
//        int int40 = day10.getMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Date date43 = fixedMillisecond42.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond(date43);
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date43);
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date43, timeZone46);
//        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date43, timeZone48);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date43);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Date date53 = fixedMillisecond52.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond(date53);
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date53);
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date53, timeZone56);
//        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date53, timeZone58);
//        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month(date43, timeZone58);
//        int int61 = day10.compareTo((java.lang.Object) month60);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = month60.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month60);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "9-April-1900" + "'", str15.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-April-1900" + "'", str19.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "9-April-1900" + "'", str26.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 9 + "'", int35 == 9);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 43629L + "'", long38 == 43629L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 43629L + "'", long39 == 43629L);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertNotNull(timeZone48);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNotNull(timeZone58);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertNull(timeSeriesDataItem63);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Last", "", "ERROR : Relative To String", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener6);
        org.junit.Assert.assertNull(class5);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Last", "", "ERROR : Relative To String", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries4.getDataItem(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Last", "", "ERROR : Relative To String", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class8);
        timeSeries9.setDomainDescription("October 0");
        java.lang.Object obj12 = timeSeries9.clone();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date16 = fixedMillisecond15.getTime();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int20 = month19.getMonth();
        java.lang.String str21 = month19.toString();
        java.lang.String str22 = month19.toString();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) month19);
        timeSeries13.clear();
        timeSeries13.fireSeriesChanged();
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "October 0" + "'", str21.equals("October 0"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "October 0" + "'", str22.equals("October 0"));
        org.junit.Assert.assertNotNull(timeSeries23);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date2, timeZone5);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date2, timeZone7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date11 = fixedMillisecond10.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date11);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date11, timeZone14);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date11, timeZone16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date2, timeZone16);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date2);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(timeZone16);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries6);
        java.lang.Object obj8 = timeSeries6.clone();
        timeSeries6.setMaximumItemCount(2958465);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class12);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries13.addAndOrUpdate(timeSeries16);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries17.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj24 = null;
        boolean boolean25 = month23.equals(obj24);
        int int26 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) month27);
        long long29 = month27.getSerialIndex();
        long long30 = month27.getLastMillisecond();
        try {
            timeSeries6.update((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) 1560495599999L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 24234L + "'", long29 == 24234L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1561964399999L + "'", long30 == 1561964399999L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(0, (-460), 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 11, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries5.addAndOrUpdate(timeSeries8);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries9.createCopy(0, (int) (short) 1);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class17);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries15.addAndOrUpdate(timeSeries18);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries12.addAndOrUpdate(timeSeries19);
        java.lang.Object obj21 = timeSeries20.clone();
        java.util.Collection collection22 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        java.lang.Comparable comparable23 = null;
        try {
            timeSeries20.setKey(comparable23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(collection22);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date2, timeZone5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.next();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        long long4 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getMiddleMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond1.getTime();
        java.lang.Class<?> wildcardClass8 = fixedMillisecond1.getClass();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getLastMillisecond(calendar9);
        long long11 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("December 1969");
        org.junit.Assert.assertNotNull(month1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long5 = fixedMillisecond4.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        spreadsheetDate13.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str27 = spreadsheetDate26.toString();
        boolean boolean28 = spreadsheetDate24.isOn((org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean29 = spreadsheetDate20.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        int int30 = spreadsheetDate26.getDayOfMonth();
        boolean boolean31 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean32 = fixedMillisecond4.equals((java.lang.Object) spreadsheetDate13);
        boolean boolean33 = day2.equals((java.lang.Object) fixedMillisecond4);
        java.lang.Class<?> wildcardClass34 = fixedMillisecond4.getClass();
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
        java.lang.Object obj36 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", class35);
        java.net.URL uRL37 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", class35);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "9-April-1900" + "'", str27.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertNull(obj36);
        org.junit.Assert.assertNull(uRL37);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(2958465);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test215");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        long long3 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int13 = spreadsheetDate9.getDayOfMonth();
        int int14 = spreadsheetDate9.getMonth();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getFirstMillisecond();
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) -1, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str6 = spreadsheetDate5.toString();
        boolean boolean7 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean8 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate1, class9);
        java.util.Collection collection11 = timeSeries10.getTimePeriods();
        boolean boolean12 = timeSeries10.isEmpty();
        try {
            java.lang.Number number14 = timeSeries10.getValue(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "9-April-1900" + "'", str6.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date2, timeZone5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date2);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Last", "", "ERROR : Relative To String", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class8);
        timeSeries9.setDomainDescription("October 0");
        java.lang.Object obj12 = timeSeries9.clone();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries9);
        java.util.Collection collection14 = timeSeries9.getTimePeriods();
        timeSeries9.clear();
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(collection14);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date2, timeZone5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date11 = fixedMillisecond10.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date11);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date11, timeZone14);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date11, timeZone16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date2, timeZone16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date21 = fixedMillisecond20.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date21);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date21, timeZone24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date21, timeZone26);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date2, timeZone26);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(timeZone26);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        java.util.Date date5 = month4.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date8 = fixedMillisecond7.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date8, timeZone11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date8, timeZone13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date5, timeZone13);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class17);
        boolean boolean19 = timeSeries18.getNotify();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int23 = month22.getMonth();
        java.lang.String str24 = month22.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) month22);
        long long26 = month22.getMiddleMillisecond();
        boolean boolean27 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) date5, (java.lang.Object) month22);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "October 0" + "'", str24.equals("October 0"));
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-62126582400001L) + "'", long26 == (-62126582400001L));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str3 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        boolean boolean9 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        spreadsheetDate24.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str32 = spreadsheetDate31.toString();
        boolean boolean33 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        boolean boolean39 = spreadsheetDate35.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int41 = spreadsheetDate37.getDayOfMonth();
        boolean boolean42 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int43 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays(100, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str48 = spreadsheetDate47.toString();
        spreadsheetDate47.setDescription("9-April-1900");
        int int51 = spreadsheetDate47.toSerial();
        boolean boolean52 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SerialDate serialDate54 = spreadsheetDate47.getNearestDayOfWeek(4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str60 = spreadsheetDate59.toString();
        boolean boolean61 = spreadsheetDate57.isOn((org.jfree.data.time.SerialDate) spreadsheetDate59);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str64 = spreadsheetDate63.toString();
        spreadsheetDate63.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str71 = spreadsheetDate70.toString();
        boolean boolean72 = spreadsheetDate68.isOn((org.jfree.data.time.SerialDate) spreadsheetDate70);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str77 = spreadsheetDate76.toString();
        boolean boolean78 = spreadsheetDate74.isOn((org.jfree.data.time.SerialDate) spreadsheetDate76);
        boolean boolean79 = spreadsheetDate70.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate76);
        int int80 = spreadsheetDate76.getDayOfMonth();
        boolean boolean81 = spreadsheetDate57.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate63, (org.jfree.data.time.SerialDate) spreadsheetDate76);
        int int82 = spreadsheetDate57.toSerial();
        org.jfree.data.time.SerialDate serialDate83 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate) spreadsheetDate57);
        boolean boolean84 = spreadsheetDate47.isAfter(serialDate83);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9 + "'", int41 == 9);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "9-April-1900" + "'", str48.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 100 + "'", int51 == 100);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "9-April-1900" + "'", str60.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "9-April-1900" + "'", str64.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "9-April-1900" + "'", str71.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "9-April-1900" + "'", str77.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 9 + "'", int80 == 9);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 100 + "'", int82 == 100);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        boolean boolean4 = timeSeries2.getNotify();
        timeSeries2.setDomainDescription("hi!");
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str3 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        boolean boolean9 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        spreadsheetDate24.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str32 = spreadsheetDate31.toString();
        boolean boolean33 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        boolean boolean39 = spreadsheetDate35.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int41 = spreadsheetDate37.getDayOfMonth();
        boolean boolean42 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int43 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays(100, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        int int46 = spreadsheetDate18.toSerial();
        java.lang.Class<?> wildcardClass47 = spreadsheetDate18.getClass();
        java.lang.Class class48 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass47);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent49 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass47);
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date52 = fixedMillisecond51.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long55 = fixedMillisecond54.getMiddleMillisecond();
        long long56 = fixedMillisecond54.getFirstMillisecond();
        long long57 = fixedMillisecond54.getLastMillisecond();
        java.util.Calendar calendar58 = null;
        long long59 = fixedMillisecond54.getMiddleMillisecond(calendar58);
        java.util.Date date60 = fixedMillisecond54.getTime();
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance(date60);
        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month(date60);
        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond(date60);
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(date60, timeZone64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date52, timeZone64);
        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(date52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9 + "'", int41 == 9);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 100 + "'", int46 == 100);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(class48);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 100L + "'", long55 == 100L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 100L + "'", long56 == 100L);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 100L + "'", long57 == 100L);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 100L + "'", long59 == 100L);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNull(regularTimePeriod66);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) '#');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        spreadsheetDate7.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str15 = spreadsheetDate14.toString();
        boolean boolean16 = spreadsheetDate12.isOn((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean23 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int24 = spreadsheetDate20.getDayOfMonth();
        boolean boolean25 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, (org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int26 = spreadsheetDate7.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str33 = spreadsheetDate32.toString();
        boolean boolean34 = spreadsheetDate30.isOn((org.jfree.data.time.SerialDate) spreadsheetDate32);
        boolean boolean35 = spreadsheetDate28.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SerialDate serialDate36 = spreadsheetDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "9-April-1900" + "'", str15.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 9 + "'", int24 == 9);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 100 + "'", int26 == 100);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-April-1900" + "'", str33.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(serialDate36);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (32) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date2, timeZone5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date2);
        int int8 = month7.getYearValue();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 1.0d);
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class7);
        int int9 = timeSeries8.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries8.removeChangeListener(seriesChangeListener10);
        java.util.Collection collection12 = timeSeries8.getTimePeriods();
        int int13 = timeSeriesDataItem5.compareTo((java.lang.Object) timeSeries8);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int17 = month16.getMonth();
        java.lang.String str18 = month16.toString();
        java.lang.String str19 = month16.toString();
        boolean boolean20 = timeSeriesDataItem5.equals((java.lang.Object) month16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
        boolean boolean25 = timeSeriesDataItem5.equals((java.lang.Object) fixedMillisecond22);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("ThreadContext");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("January");
        timePeriodFormatException27.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
        boolean boolean31 = timeSeriesDataItem5.equals((java.lang.Object) timePeriodFormatException29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "October 0" + "'", str18.equals("October 0"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "October 0" + "'", str19.equals("October 0"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
        java.lang.Class class18 = timeSeries9.getTimePeriodClass();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class20);
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class23);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries21.addAndOrUpdate(timeSeries24);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries25.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj32 = null;
        boolean boolean33 = month31.equals(obj32);
        int int34 = timeSeries25.getIndex((org.jfree.data.time.RegularTimePeriod) month31);
        long long35 = month31.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date38 = fixedMillisecond37.getTime();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        boolean boolean40 = month31.equals((java.lang.Object) day39);
        int int41 = day39.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) day39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day39.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent44 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day39);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 31 + "'", int41 == 31);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries6);
        java.lang.Object obj8 = timeSeries6.clone();
        timeSeries6.setMaximumItemCount(2958465);
        java.util.List list11 = timeSeries6.getItems();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj13 = null;
        boolean boolean14 = month12.equals(obj13);
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) month16);
        org.jfree.data.time.Year year18 = month16.getYear();
        java.util.Calendar calendar19 = null;
        try {
            long long20 = year18.getFirstMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(year18);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test235");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate2);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date2, timeZone5);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date2, timeZone7);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date12 = fixedMillisecond11.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date12);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date12, timeZone15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date12, timeZone17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date2, timeZone17);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date2);
        long long22 = year21.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year21.next();
        long long24 = year21.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31507200000L) + "'", long22 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1969L + "'", long24 == 1969L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long5 = fixedMillisecond4.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        spreadsheetDate13.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str27 = spreadsheetDate26.toString();
        boolean boolean28 = spreadsheetDate24.isOn((org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean29 = spreadsheetDate20.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        int int30 = spreadsheetDate26.getDayOfMonth();
        boolean boolean31 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean32 = fixedMillisecond4.equals((java.lang.Object) spreadsheetDate13);
        boolean boolean33 = day2.equals((java.lang.Object) fixedMillisecond4);
        java.lang.Class<?> wildcardClass34 = fixedMillisecond4.getClass();
        java.io.InputStream inputStream35 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("9-April-1900", (java.lang.Class) wildcardClass34);
        java.net.URL uRL36 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("31-December-1969", (java.lang.Class) wildcardClass34);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "9-April-1900" + "'", str27.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNull(inputStream35);
        org.junit.Assert.assertNull(uRL36);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        timeSeries2.clear();
        java.lang.Comparable comparable5 = timeSeries2.getKey();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year7 = month6.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date10 = fixedMillisecond9.getTime();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        boolean boolean13 = year7.equals((java.lang.Object) 11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year7.previous();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 1.0f + "'", comparable5.equals(1.0f));
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-460));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-572) + "'", int1 == (-572));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 1.0d);
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class7);
        int int9 = timeSeries8.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries8.removeChangeListener(seriesChangeListener10);
        java.util.Collection collection12 = timeSeries8.getTimePeriods();
        int int13 = timeSeriesDataItem5.compareTo((java.lang.Object) timeSeries8);
        timeSeriesDataItem5.setValue((java.lang.Number) 10L);
        java.lang.Number number16 = timeSeriesDataItem5.getValue();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long20 = fixedMillisecond19.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        boolean boolean26 = spreadsheetDate22.isOn((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str29 = spreadsheetDate28.toString();
        spreadsheetDate28.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str36 = spreadsheetDate35.toString();
        boolean boolean37 = spreadsheetDate33.isOn((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str42 = spreadsheetDate41.toString();
        boolean boolean43 = spreadsheetDate39.isOn((org.jfree.data.time.SerialDate) spreadsheetDate41);
        boolean boolean44 = spreadsheetDate35.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
        int int45 = spreadsheetDate41.getDayOfMonth();
        boolean boolean46 = spreadsheetDate22.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate28, (org.jfree.data.time.SerialDate) spreadsheetDate41);
        boolean boolean47 = fixedMillisecond19.equals((java.lang.Object) spreadsheetDate28);
        boolean boolean48 = day17.equals((java.lang.Object) fixedMillisecond19);
        java.lang.Class<?> wildcardClass49 = fixedMillisecond19.getClass();
        java.lang.Class class50 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass49);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem5, class50);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 10L + "'", number16.equals(10L));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "9-April-1900" + "'", str29.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "9-April-1900" + "'", str36.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "9-April-1900" + "'", str42.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 9 + "'", int45 == 9);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertNotNull(class50);
    }
}

