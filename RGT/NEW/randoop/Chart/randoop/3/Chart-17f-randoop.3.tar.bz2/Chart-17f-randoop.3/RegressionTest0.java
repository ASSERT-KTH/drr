import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) -1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays((int) (short) 10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) -1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("October 0");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        try {
            timeSeries2.update((int) (byte) 1, (java.lang.Number) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int21 = month20.getMonth();
        try {
            timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month20, (double) (byte) 1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int3 = month2.getMonth();
        int int4 = month2.getYearValue();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = year1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year1.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str2 = spreadsheetDate1.toString();
        try {
            org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getPreviousDayOfWeek((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "9-April-1900" + "'", str2.equals("9-April-1900"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(4, (int) '#', 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) '4');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (4) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        try {
            timeSeries17.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(10, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "October" + "'", str2.equals("October"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        timeSeries2.setDomainDescription("October 0");
        java.lang.Object obj5 = timeSeries2.clone();
        timeSeries2.setDomainDescription("ERROR : Relative To String");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries2.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int7 = month6.getMonth();
        java.lang.String str8 = month6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        try {
            org.jfree.data.time.Year year10 = month6.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 0" + "'", str8.equals("October 0"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int3 = month2.getMonth();
        int int4 = month2.getMonth();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1900, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(9, 12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class8);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries13.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj20 = null;
        boolean boolean21 = month19.equals(obj20);
        int int22 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) month19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) month23);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj28 = null;
        boolean boolean29 = month27.equals(obj28);
        try {
            org.jfree.data.time.TimeSeries timeSeries30 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) month23, (org.jfree.data.time.RegularTimePeriod) month27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start on or before end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) '4', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ClassContext", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        int int3 = timeSeries2.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries2.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long8 = fixedMillisecond7.getMiddleMillisecond();
        long long9 = fixedMillisecond7.getFirstMillisecond();
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj13 = null;
        boolean boolean14 = month12.equals(obj13);
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        try {
            org.jfree.data.time.Year year16 = month12.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        try {
            timeSeries17.add((org.jfree.data.time.RegularTimePeriod) month18, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries17);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year5 = month4.getYear();
        long long6 = year5.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (double) (short) 10);
        try {
            org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = null;
        try {
            timeSeries2.add(timeSeriesDataItem3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        try {
            org.jfree.data.time.TimeSeries timeSeries9 = timeSeries2.createCopy(10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((-1), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Last", "", "ERROR : Relative To String", class3);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeries4.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        spreadsheetDate3.setDescription("9-April-1900");
        try {
            int int16 = spreadsheetDate3.compareTo((java.lang.Object) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj13 = null;
        boolean boolean14 = month12.equals(obj13);
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) month16);
        java.util.Calendar calendar18 = null;
        try {
            month16.peg(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.lang.Comparable comparable0 = null;
        java.lang.Class class1 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries(comparable0, class1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        long long3 = month2.getSerialIndex();
        try {
            org.jfree.data.time.Year year4 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.util.Date date3 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
        timeSeries9.setDomainDescription("ClassContext");
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries17);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Last", "", "ERROR : Relative To String", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        timeSeries4.setMaximumItemAge((long) ' ');
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj13 = null;
        boolean boolean14 = month12.equals(obj13);
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) month16);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int21 = month20.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 1.0d);
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class25);
        int int27 = timeSeries26.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
        timeSeries26.removeChangeListener(seriesChangeListener28);
        java.util.Collection collection30 = timeSeries26.getTimePeriods();
        int int31 = timeSeriesDataItem23.compareTo((java.lang.Object) timeSeries26);
        java.lang.Number number32 = timeSeriesDataItem23.getValue();
        try {
            timeSeries6.add(timeSeriesDataItem23, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 1.0d + "'", number32.equals(1.0d));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int13 = spreadsheetDate3.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate14 = null;
        try {
            boolean boolean15 = spreadsheetDate3.isOnOrAfter(serialDate14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int7 = month6.getMonth();
        java.lang.String str8 = month6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        try {
            timeSeries2.delete(9, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 0" + "'", str8.equals("October 0"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = timeSeries2.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj13 = null;
        boolean boolean14 = month12.equals(obj13);
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        java.util.Calendar calendar16 = null;
        try {
            long long17 = month12.getFirstMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("9-April-1900");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        try {
            java.lang.Object obj5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) year4);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
        int int18 = timeSeries9.getItemCount();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeries9.getTimePeriod((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Last", "", "ERROR : Relative To String", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class8);
        timeSeries9.setDomainDescription("October 0");
        java.lang.Object obj12 = timeSeries9.clone();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        try {
            timeSeries13.add((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(timeSeries13);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int3 = month2.getMonth();
        java.lang.String str4 = month2.toString();
        java.util.Calendar calendar5 = null;
        try {
            month2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "October 0" + "'", str4.equals("October 0"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) ' ');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 1.0d);
        long long6 = month2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62109475200001L) + "'", long6 == (-62109475200001L));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str17 = spreadsheetDate16.toString();
        boolean boolean18 = spreadsheetDate14.isOn((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        spreadsheetDate20.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str28 = spreadsheetDate27.toString();
        boolean boolean29 = spreadsheetDate25.isOn((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str34 = spreadsheetDate33.toString();
        boolean boolean35 = spreadsheetDate31.isOn((org.jfree.data.time.SerialDate) spreadsheetDate33);
        boolean boolean36 = spreadsheetDate27.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int37 = spreadsheetDate33.getDayOfMonth();
        boolean boolean38 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate20, (org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int39 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        try {
            java.lang.Object obj40 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) int39);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "9-April-1900" + "'", str17.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "9-April-1900" + "'", str28.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "9-April-1900" + "'", str34.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 9 + "'", int37 == 9);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = month0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("October");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        timeSeries2.setDomainDescription("October 0");
        java.lang.Object obj5 = timeSeries2.clone();
        timeSeries2.setDomainDescription("ERROR : Relative To String");
        try {
            timeSeries2.removeAgedItems(1L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        timeSeries2.setDomainDescription("October 0");
        java.lang.Object obj5 = timeSeries2.clone();
        timeSeries2.setDomainDescription("ERROR : Relative To String");
        int int8 = timeSeries2.getMaximumItemCount();
        try {
            timeSeries2.update(2, (java.lang.Number) 1560495599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.String str10 = timeSeries6.getDescription();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        long long14 = month13.getSerialIndex();
        long long15 = month13.getSerialIndex();
        try {
            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) 1559372400000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int7 = month6.getMonth();
        java.lang.String str8 = month6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        long long10 = month6.getLastMillisecond();
        java.util.Calendar calendar11 = null;
        try {
            month6.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 0" + "'", str8.equals("October 0"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62109475200001L) + "'", long10 == (-62109475200001L));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("ERROR : Relative To String");
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test127");
//        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
//        org.junit.Assert.assertNull(classLoader0);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int3 = month2.getMonth();
        try {
            org.jfree.data.time.Year year4 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str17 = spreadsheetDate16.toString();
        boolean boolean18 = spreadsheetDate14.isOn((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        spreadsheetDate20.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str28 = spreadsheetDate27.toString();
        boolean boolean29 = spreadsheetDate25.isOn((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str34 = spreadsheetDate33.toString();
        boolean boolean35 = spreadsheetDate31.isOn((org.jfree.data.time.SerialDate) spreadsheetDate33);
        boolean boolean36 = spreadsheetDate27.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int37 = spreadsheetDate33.getDayOfMonth();
        boolean boolean38 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate20, (org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int39 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str42 = spreadsheetDate41.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str47 = spreadsheetDate46.toString();
        boolean boolean48 = spreadsheetDate44.isOn((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str53 = spreadsheetDate52.toString();
        boolean boolean54 = spreadsheetDate50.isOn((org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean55 = spreadsheetDate46.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str60 = spreadsheetDate59.toString();
        boolean boolean61 = spreadsheetDate57.isOn((org.jfree.data.time.SerialDate) spreadsheetDate59);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str64 = spreadsheetDate63.toString();
        spreadsheetDate63.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str71 = spreadsheetDate70.toString();
        boolean boolean72 = spreadsheetDate68.isOn((org.jfree.data.time.SerialDate) spreadsheetDate70);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str77 = spreadsheetDate76.toString();
        boolean boolean78 = spreadsheetDate74.isOn((org.jfree.data.time.SerialDate) spreadsheetDate76);
        boolean boolean79 = spreadsheetDate70.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate76);
        int int80 = spreadsheetDate76.getDayOfMonth();
        boolean boolean81 = spreadsheetDate57.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate63, (org.jfree.data.time.SerialDate) spreadsheetDate76);
        int int82 = spreadsheetDate52.compare((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SerialDate serialDate83 = spreadsheetDate41.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SerialDate serialDate84 = spreadsheetDate14.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate57);
        java.lang.Object obj85 = null;
        try {
            int int86 = spreadsheetDate57.compareTo(obj85);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "9-April-1900" + "'", str17.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "9-April-1900" + "'", str28.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "9-April-1900" + "'", str34.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 9 + "'", int37 == 9);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "9-April-1900" + "'", str42.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "9-April-1900" + "'", str47.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "9-April-1900" + "'", str53.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "9-April-1900" + "'", str60.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "9-April-1900" + "'", str64.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "9-April-1900" + "'", str71.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "9-April-1900" + "'", str77.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 9 + "'", int80 == 9);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(serialDate84);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(11);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2958465, (int) '4', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        try {
            org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate1.getFollowingDayOfWeek(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(9, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Sep" + "'", str2.equals("Sep"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            day0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        java.lang.Class class1 = null;
//        try {
//            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Overwritten values from: 1.0", class1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener18);
        timeSeries9.clear();
        java.lang.Object obj21 = timeSeries9.clone();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int25 = month24.getMonth();
        java.lang.String str26 = month24.toString();
        java.lang.String str27 = month24.toString();
        java.lang.Number number28 = null;
        try {
            timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month24, number28, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "October 0" + "'", str26.equals("October 0"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "October 0" + "'", str27.equals("October 0"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        spreadsheetDate13.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str27 = spreadsheetDate26.toString();
        boolean boolean28 = spreadsheetDate24.isOn((org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean29 = spreadsheetDate20.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        int int30 = spreadsheetDate26.getDayOfMonth();
        boolean boolean31 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate32 = null;
        try {
            boolean boolean34 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate26, serialDate32, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "9-April-1900" + "'", str27.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
        try {
            org.jfree.data.time.TimeSeries timeSeries20 = timeSeries17.createCopy(10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries17);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        long long3 = month2.getSerialIndex();
        long long4 = month2.getSerialIndex();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj13 = null;
        boolean boolean14 = month12.equals(obj13);
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) month16);
        long long18 = month16.getSerialIndex();
        long long19 = month16.getMiddleMillisecond();
        java.lang.Object obj20 = null;
        int int21 = month16.compareTo(obj20);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 24234L + "'", long18 == 24234L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560668399999L + "'", long19 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(4);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "April" + "'", str1.equals("April"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("ThreadContext");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        int int3 = timeSeries2.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries2.removeChangeListener(seriesChangeListener4);
        java.util.Collection collection6 = timeSeries2.getTimePeriods();
        timeSeries2.setRangeDescription("ClassContext");
        try {
            java.lang.Number number10 = timeSeries2.getValue(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(collection6);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
        java.lang.Object obj18 = timeSeries17.clone();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class20);
        timeSeries21.setDomainDescription("October 0");
        java.lang.Object obj24 = timeSeries21.clone();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getLastMillisecond();
        boolean boolean27 = timeSeries21.equals((java.lang.Object) year25);
        try {
            timeSeries17.add((org.jfree.data.time.RegularTimePeriod) year25, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("April");
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(9999, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9999");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Last", "", "ERROR : Relative To String", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class8);
        timeSeries9.setDomainDescription("October 0");
        java.lang.Object obj12 = timeSeries9.clone();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries9);
        try {
            timeSeries9.update(6, (java.lang.Number) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(timeSeries13);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Last", "", "ERROR : Relative To String", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class8);
        timeSeries9.setDomainDescription("October 0");
        java.lang.Object obj12 = timeSeries9.clone();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries9);
        try {
            timeSeries4.setMaximumItemCount((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(timeSeries13);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.String str10 = timeSeries6.getDescription();
        timeSeries6.setRangeDescription("Last");
        java.util.Collection collection13 = timeSeries6.getTimePeriods();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(collection13);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str5 = spreadsheetDate4.toString();
        boolean boolean6 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str11 = spreadsheetDate10.toString();
        boolean boolean12 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean13 = spreadsheetDate4.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        spreadsheetDate4.setDescription("9-April-1900");
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths(1900, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-April-1900" + "'", str11.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(serialDate16);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.String str10 = timeSeries6.getDescription();
        java.lang.Comparable comparable11 = timeSeries6.getKey();
        java.util.Collection collection12 = timeSeries6.getTimePeriods();
        java.lang.Comparable comparable13 = null;
        try {
            timeSeries6.setKey(comparable13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + "Overwritten values from: 1.0" + "'", comparable11.equals("Overwritten values from: 1.0"));
        org.junit.Assert.assertNotNull(collection12);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 1.0d);
        java.lang.String str6 = month2.toString();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month2.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str5 = spreadsheetDate4.toString();
//        boolean boolean6 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str9 = spreadsheetDate8.toString();
//        spreadsheetDate8.setDescription("9-April-1900");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str16 = spreadsheetDate15.toString();
//        boolean boolean17 = spreadsheetDate13.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str22 = spreadsheetDate21.toString();
//        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        boolean boolean24 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        int int25 = spreadsheetDate21.getDayOfMonth();
//        boolean boolean26 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate21);
//        boolean boolean27 = day0.equals((java.lang.Object) spreadsheetDate8);
//        long long28 = day0.getLastMillisecond();
//        java.util.Calendar calendar29 = null;
//        try {
//            long long30 = day0.getFirstMillisecond(calendar29);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-April-1900" + "'", str9.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "9-April-1900" + "'", str16.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 9 + "'", int25 == 9);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560495599999L + "'", long28 == 1560495599999L);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("April");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(1900);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("9-April-1900");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 100, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        java.lang.Object obj2 = null;
        boolean boolean3 = spreadsheetDate1.equals(obj2);
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class5);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class8);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries6.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries10.createCopy(0, (int) (short) 1);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class15);
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class18);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries16.addAndOrUpdate(timeSeries19);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries13.addAndOrUpdate(timeSeries20);
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener22);
        java.lang.Object obj24 = timeSeries13.clone();
        try {
            int int25 = spreadsheetDate1.compareTo((java.lang.Object) timeSeries13);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimeSeries cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str5 = spreadsheetDate4.toString();
        boolean boolean6 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str11 = spreadsheetDate10.toString();
        boolean boolean12 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean13 = spreadsheetDate4.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-April-1900" + "'", str11.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(serialDate14);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int7 = month6.getMonth();
        java.lang.String str8 = month6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        java.util.Calendar calendar10 = null;
        try {
            month6.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 0" + "'", str8.equals("October 0"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int3 = month2.getMonth();
        java.lang.String str4 = month2.toString();
        java.lang.String str5 = month2.toString();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "October 0" + "'", str4.equals("October 0"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "October 0" + "'", str5.equals("October 0"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries6.getTimePeriod(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int7 = month6.getMonth();
        java.lang.String str8 = month6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        long long10 = month6.getLastMillisecond();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year12 = month11.getYear();
        int int13 = month6.compareTo((java.lang.Object) year12);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = year12.getLastMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 0" + "'", str8.equals("October 0"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62109475200001L) + "'", long10 == (-62109475200001L));
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(2019, (int) '4', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = year1.getSerialIndex();
        java.lang.String str3 = year1.toString();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year1.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 43629L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            year0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str9 = spreadsheetDate8.toString();
        boolean boolean10 = spreadsheetDate6.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str15 = spreadsheetDate14.toString();
        boolean boolean16 = spreadsheetDate12.isOn((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean17 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str22 = spreadsheetDate21.toString();
        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str26 = spreadsheetDate25.toString();
        spreadsheetDate25.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str33 = spreadsheetDate32.toString();
        boolean boolean34 = spreadsheetDate30.isOn((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str39 = spreadsheetDate38.toString();
        boolean boolean40 = spreadsheetDate36.isOn((org.jfree.data.time.SerialDate) spreadsheetDate38);
        boolean boolean41 = spreadsheetDate32.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        int int42 = spreadsheetDate38.getDayOfMonth();
        boolean boolean43 = spreadsheetDate19.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate38);
        int int44 = spreadsheetDate14.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate45 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str51 = spreadsheetDate50.toString();
        boolean boolean52 = spreadsheetDate48.isOn((org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str57 = spreadsheetDate56.toString();
        boolean boolean58 = spreadsheetDate54.isOn((org.jfree.data.time.SerialDate) spreadsheetDate56);
        boolean boolean59 = spreadsheetDate50.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate56);
        boolean boolean60 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate56);
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.addYears((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate56);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-April-1900" + "'", str9.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "9-April-1900" + "'", str15.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "9-April-1900" + "'", str26.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-April-1900" + "'", str33.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "9-April-1900" + "'", str39.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "9-April-1900" + "'", str51.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "9-April-1900" + "'", str57.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(serialDate61);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.lang.Object obj4 = null;
        boolean boolean5 = day3.equals(obj4);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        int int7 = timeSeries6.getItemCount();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj11 = null;
        boolean boolean12 = month10.equals(obj11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 10.0f);
        timeSeriesDataItem14.setValue((java.lang.Number) 12);
        try {
            timeSeries6.add(timeSeriesDataItem14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(12, 5, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int7 = month6.getMonth();
        java.lang.String str8 = month6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        try {
            org.jfree.data.time.TimeSeries timeSeries12 = timeSeries2.createCopy((int) (byte) -1, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 0" + "'", str8.equals("October 0"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str3 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        boolean boolean9 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        spreadsheetDate24.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str32 = spreadsheetDate31.toString();
        boolean boolean33 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        boolean boolean39 = spreadsheetDate35.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int41 = spreadsheetDate37.getDayOfMonth();
        boolean boolean42 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int43 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays(100, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        int int46 = spreadsheetDate18.getDayOfWeek();
        try {
            org.jfree.data.time.SerialDate serialDate48 = spreadsheetDate18.getNearestDayOfWeek(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9 + "'", int41 == 9);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
        java.lang.Object obj18 = timeSeries17.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long21 = fixedMillisecond20.getMiddleMillisecond();
        long long22 = fixedMillisecond20.getFirstMillisecond();
        long long23 = fixedMillisecond20.getLastMillisecond();
        try {
            timeSeries17.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) (short) 1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        timeSeries2.setDomainDescription("October 0");
        int int5 = timeSeries2.getMaximumItemCount();
        org.jfree.data.time.Year year7 = org.jfree.data.time.Year.parseYear("2019");
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year7, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNotNull(year7);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long6 = fixedMillisecond5.getMiddleMillisecond();
        long long7 = fixedMillisecond5.getFirstMillisecond();
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str3 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        boolean boolean9 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        spreadsheetDate24.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str32 = spreadsheetDate31.toString();
        boolean boolean33 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        boolean boolean39 = spreadsheetDate35.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int41 = spreadsheetDate37.getDayOfMonth();
        boolean boolean42 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int43 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str49 = spreadsheetDate48.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str54 = spreadsheetDate53.toString();
        boolean boolean55 = spreadsheetDate51.isOn((org.jfree.data.time.SerialDate) spreadsheetDate53);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str60 = spreadsheetDate59.toString();
        boolean boolean61 = spreadsheetDate57.isOn((org.jfree.data.time.SerialDate) spreadsheetDate59);
        boolean boolean62 = spreadsheetDate53.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate59);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str67 = spreadsheetDate66.toString();
        boolean boolean68 = spreadsheetDate64.isOn((org.jfree.data.time.SerialDate) spreadsheetDate66);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str71 = spreadsheetDate70.toString();
        spreadsheetDate70.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str78 = spreadsheetDate77.toString();
        boolean boolean79 = spreadsheetDate75.isOn((org.jfree.data.time.SerialDate) spreadsheetDate77);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate81 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate83 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str84 = spreadsheetDate83.toString();
        boolean boolean85 = spreadsheetDate81.isOn((org.jfree.data.time.SerialDate) spreadsheetDate83);
        boolean boolean86 = spreadsheetDate77.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate83);
        int int87 = spreadsheetDate83.getDayOfMonth();
        boolean boolean88 = spreadsheetDate64.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate70, (org.jfree.data.time.SerialDate) spreadsheetDate83);
        int int89 = spreadsheetDate59.compare((org.jfree.data.time.SerialDate) spreadsheetDate64);
        org.jfree.data.time.SerialDate serialDate90 = spreadsheetDate48.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate64);
        org.jfree.data.time.SerialDate serialDate91 = org.jfree.data.time.SerialDate.addDays(100, (org.jfree.data.time.SerialDate) spreadsheetDate64);
        int int92 = spreadsheetDate18.compare((org.jfree.data.time.SerialDate) spreadsheetDate64);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9 + "'", int41 == 9);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "9-April-1900" + "'", str49.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "9-April-1900" + "'", str54.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "9-April-1900" + "'", str60.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "9-April-1900" + "'", str67.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "9-April-1900" + "'", str71.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "9-April-1900" + "'", str78.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "9-April-1900" + "'", str84.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 9 + "'", int87 == 9);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
        org.junit.Assert.assertNotNull(serialDate90);
        org.junit.Assert.assertNotNull(serialDate91);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1900");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str3 = spreadsheetDate2.toString();
        spreadsheetDate2.setDescription("9-April-1900");
        int int6 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(7, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        timeSeries2.setDomainDescription("October 0");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries2.addChangeListener(seriesChangeListener5);
        timeSeries2.clear();
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(11);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long3 = fixedMillisecond2.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        boolean boolean9 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str12 = spreadsheetDate11.toString();
        spreadsheetDate11.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str19 = spreadsheetDate18.toString();
        boolean boolean20 = spreadsheetDate16.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        boolean boolean26 = spreadsheetDate22.isOn((org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean27 = spreadsheetDate18.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate24);
        int int28 = spreadsheetDate24.getDayOfMonth();
        boolean boolean29 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, (org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean30 = fixedMillisecond2.equals((java.lang.Object) spreadsheetDate11);
        boolean boolean31 = day0.equals((java.lang.Object) fixedMillisecond2);
        java.lang.Class<?> wildcardClass32 = fixedMillisecond2.getClass();
        long long33 = fixedMillisecond2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-April-1900" + "'", str12.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-April-1900" + "'", str19.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 9 + "'", int28 == 9);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 100L + "'", long33 == 100L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str5 = spreadsheetDate4.toString();
        boolean boolean6 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str11 = spreadsheetDate10.toString();
        boolean boolean12 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean13 = spreadsheetDate4.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int14 = spreadsheetDate10.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str17 = spreadsheetDate16.toString();
        boolean boolean18 = spreadsheetDate10.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-April-1900" + "'", str11.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 9 + "'", int14 == 9);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "9-April-1900" + "'", str17.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int7 = month6.getMonth();
        java.lang.String str8 = month6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        long long10 = month6.getLastMillisecond();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year12 = month11.getYear();
        int int13 = month6.compareTo((java.lang.Object) year12);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = month6.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 0" + "'", str8.equals("October 0"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62109475200001L) + "'", long10 == (-62109475200001L));
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj3 = null;
        boolean boolean4 = month2.equals(obj3);
        int int5 = month2.getMonth();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries2.createCopy(0, 7);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int13 = month12.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) 1.0d);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class17);
        int int19 = timeSeries18.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries18.removeChangeListener(seriesChangeListener20);
        java.util.Collection collection22 = timeSeries18.getTimePeriods();
        int int23 = timeSeriesDataItem15.compareTo((java.lang.Object) timeSeries18);
        java.lang.Number number24 = timeSeriesDataItem15.getValue();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year26 = month25.getYear();
        int int27 = timeSeriesDataItem15.compareTo((java.lang.Object) month25);
        try {
            timeSeries9.add(timeSeriesDataItem15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 1.0d + "'", number24.equals(1.0d));
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Sep");
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("October");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(2019);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        int int3 = timeSeries2.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries2.removeChangeListener(seriesChangeListener4);
        java.util.Collection collection6 = timeSeries2.getTimePeriods();
        timeSeries2.setRangeDescription("ClassContext");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries2.removeChangeListener(seriesChangeListener9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(collection6);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str9 = spreadsheetDate8.toString();
        boolean boolean10 = spreadsheetDate6.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str15 = spreadsheetDate14.toString();
        boolean boolean16 = spreadsheetDate12.isOn((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean17 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str22 = spreadsheetDate21.toString();
        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str26 = spreadsheetDate25.toString();
        spreadsheetDate25.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str33 = spreadsheetDate32.toString();
        boolean boolean34 = spreadsheetDate30.isOn((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str39 = spreadsheetDate38.toString();
        boolean boolean40 = spreadsheetDate36.isOn((org.jfree.data.time.SerialDate) spreadsheetDate38);
        boolean boolean41 = spreadsheetDate32.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        int int42 = spreadsheetDate38.getDayOfMonth();
        boolean boolean43 = spreadsheetDate19.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate38);
        int int44 = spreadsheetDate14.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate45 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addDays(100, (org.jfree.data.time.SerialDate) spreadsheetDate19);
        int int47 = spreadsheetDate19.toSerial();
        try {
            org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, (org.jfree.data.time.SerialDate) spreadsheetDate19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-April-1900" + "'", str9.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "9-April-1900" + "'", str15.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "9-April-1900" + "'", str26.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-April-1900" + "'", str33.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "9-April-1900" + "'", str39.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 100 + "'", int47 == 100);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str5 = spreadsheetDate4.toString();
        boolean boolean6 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
        try {
            org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(12, (org.jfree.data.time.SerialDate) spreadsheetDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(1900);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        int int3 = timeSeries2.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries2.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str18 = spreadsheetDate17.toString();
        spreadsheetDate17.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        boolean boolean26 = spreadsheetDate22.isOn((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str31 = spreadsheetDate30.toString();
        boolean boolean32 = spreadsheetDate28.isOn((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean33 = spreadsheetDate24.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        int int34 = spreadsheetDate30.getDayOfMonth();
        boolean boolean35 = spreadsheetDate11.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, (org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean36 = fixedMillisecond8.equals((java.lang.Object) spreadsheetDate17);
        boolean boolean37 = day6.equals((java.lang.Object) fixedMillisecond8);
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 7, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "9-April-1900" + "'", str18.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "9-April-1900" + "'", str31.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 9 + "'", int34 == 9);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (short) -1);
        try {
            org.jfree.data.time.Year year3 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str5 = spreadsheetDate4.toString();
        boolean boolean6 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str11 = spreadsheetDate10.toString();
        boolean boolean12 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean13 = spreadsheetDate4.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int14 = spreadsheetDate4.getDayOfMonth();
        spreadsheetDate4.setDescription("2019");
        try {
            org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-April-1900" + "'", str11.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 9 + "'", int14 == 9);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = year1.getSerialIndex();
        java.lang.String str3 = year1.toString();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year1.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str6 = spreadsheetDate5.toString();
        boolean boolean7 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean8 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str18 = spreadsheetDate17.toString();
        spreadsheetDate17.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        boolean boolean26 = spreadsheetDate22.isOn((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str31 = spreadsheetDate30.toString();
        boolean boolean32 = spreadsheetDate28.isOn((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean33 = spreadsheetDate24.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        int int34 = spreadsheetDate30.getDayOfMonth();
        boolean boolean35 = spreadsheetDate11.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, (org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean36 = day9.equals((java.lang.Object) spreadsheetDate17);
        boolean boolean37 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "9-April-1900" + "'", str6.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "9-April-1900" + "'", str18.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "9-April-1900" + "'", str31.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 9 + "'", int34 == 9);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener18);
        timeSeries9.clear();
        java.lang.Object obj21 = timeSeries9.clone();
        timeSeries9.fireSeriesChanged();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int3 = month2.getMonth();
        long long4 = month2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str3 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        boolean boolean9 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        spreadsheetDate24.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str32 = spreadsheetDate31.toString();
        boolean boolean33 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        boolean boolean39 = spreadsheetDate35.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int41 = spreadsheetDate37.getDayOfMonth();
        boolean boolean42 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int43 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        try {
            org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(12, serialDate44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9 + "'", int41 == 9);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(serialDate44);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str9 = spreadsheetDate8.toString();
        boolean boolean10 = spreadsheetDate6.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str15 = spreadsheetDate14.toString();
        boolean boolean16 = spreadsheetDate12.isOn((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean17 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str22 = spreadsheetDate21.toString();
        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str26 = spreadsheetDate25.toString();
        spreadsheetDate25.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str33 = spreadsheetDate32.toString();
        boolean boolean34 = spreadsheetDate30.isOn((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str39 = spreadsheetDate38.toString();
        boolean boolean40 = spreadsheetDate36.isOn((org.jfree.data.time.SerialDate) spreadsheetDate38);
        boolean boolean41 = spreadsheetDate32.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        int int42 = spreadsheetDate38.getDayOfMonth();
        boolean boolean43 = spreadsheetDate19.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate38);
        int int44 = spreadsheetDate14.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate45 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addMonths(2, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addMonths(12, serialDate46);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-April-1900" + "'", str9.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "9-April-1900" + "'", str15.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "9-April-1900" + "'", str26.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-April-1900" + "'", str33.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "9-April-1900" + "'", str39.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate47);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10, 2147483647, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str2 = spreadsheetDate1.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str7 = spreadsheetDate6.toString();
        boolean boolean8 = spreadsheetDate4.isOn((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str13 = spreadsheetDate12.toString();
        boolean boolean14 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean15 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str20 = spreadsheetDate19.toString();
        boolean boolean21 = spreadsheetDate17.isOn((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str24 = spreadsheetDate23.toString();
        spreadsheetDate23.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str31 = spreadsheetDate30.toString();
        boolean boolean32 = spreadsheetDate28.isOn((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str37 = spreadsheetDate36.toString();
        boolean boolean38 = spreadsheetDate34.isOn((org.jfree.data.time.SerialDate) spreadsheetDate36);
        boolean boolean39 = spreadsheetDate30.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate36);
        int int40 = spreadsheetDate36.getDayOfMonth();
        boolean boolean41 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, (org.jfree.data.time.SerialDate) spreadsheetDate36);
        int int42 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SerialDate serialDate43 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str44 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SerialDate serialDate45 = null;
        try {
            boolean boolean46 = spreadsheetDate1.isOnOrBefore(serialDate45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "9-April-1900" + "'", str2.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9-April-1900" + "'", str7.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "9-April-1900" + "'", str13.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "9-April-1900" + "'", str20.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "9-April-1900" + "'", str24.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "9-April-1900" + "'", str31.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "9-April-1900" + "'", str37.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 9 + "'", int40 == 9);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNull(str44);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str3 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        boolean boolean9 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        spreadsheetDate24.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str32 = spreadsheetDate31.toString();
        boolean boolean33 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        boolean boolean39 = spreadsheetDate35.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int41 = spreadsheetDate37.getDayOfMonth();
        boolean boolean42 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int43 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays(100, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str48 = spreadsheetDate47.toString();
        spreadsheetDate47.setDescription("9-April-1900");
        int int51 = spreadsheetDate47.toSerial();
        boolean boolean52 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SerialDate serialDate54 = spreadsheetDate47.getNearestDayOfWeek(4);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(serialDate54);
        long long56 = day55.getFirstMillisecond();
        java.util.Calendar calendar57 = null;
        try {
            long long58 = day55.getFirstMillisecond(calendar57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9 + "'", int41 == 9);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "9-April-1900" + "'", str48.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 100 + "'", int51 == 100);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-2200665600000L) + "'", long56 == (-2200665600000L));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2);
        java.util.Calendar calendar6 = null;
        try {
            year5.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str3 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        boolean boolean9 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        spreadsheetDate24.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str32 = spreadsheetDate31.toString();
        boolean boolean33 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        boolean boolean39 = spreadsheetDate35.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int41 = spreadsheetDate37.getDayOfMonth();
        boolean boolean42 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int43 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        serialDate45.setDescription("org.jfree.data.time.TimePeriodFormatException: ");
        try {
            org.jfree.data.time.SerialDate serialDate49 = serialDate45.getNearestDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9 + "'", int41 == 9);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        boolean boolean7 = timeSeries2.getNotify();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries2.getDataItem(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str3 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        boolean boolean9 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        spreadsheetDate24.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str32 = spreadsheetDate31.toString();
        boolean boolean33 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        boolean boolean39 = spreadsheetDate35.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int41 = spreadsheetDate37.getDayOfMonth();
        boolean boolean42 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int43 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays(100, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str48 = spreadsheetDate47.toString();
        spreadsheetDate47.setDescription("9-April-1900");
        int int51 = spreadsheetDate47.toSerial();
        boolean boolean52 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SerialDate serialDate54 = spreadsheetDate47.getNearestDayOfWeek(4);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(serialDate54);
        java.lang.Object obj56 = null;
        int int57 = day55.compareTo(obj56);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9 + "'", int41 == 9);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "9-April-1900" + "'", str48.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 100 + "'", int51 == 100);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long6 = fixedMillisecond5.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str11 = spreadsheetDate10.toString();
        boolean boolean12 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str15 = spreadsheetDate14.toString();
        spreadsheetDate14.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str22 = spreadsheetDate21.toString();
        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str28 = spreadsheetDate27.toString();
        boolean boolean29 = spreadsheetDate25.isOn((org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean30 = spreadsheetDate21.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        int int31 = spreadsheetDate27.getDayOfMonth();
        boolean boolean32 = spreadsheetDate8.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate14, (org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean33 = fixedMillisecond5.equals((java.lang.Object) spreadsheetDate14);
        boolean boolean34 = day3.equals((java.lang.Object) fixedMillisecond5);
        java.lang.Class<?> wildcardClass35 = fixedMillisecond5.getClass();
        java.io.InputStream inputStream36 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("9-April-1900", (java.lang.Class) wildcardClass35);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, (java.lang.Class) wildcardClass35);
        boolean boolean38 = timeSeries37.isEmpty();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-April-1900" + "'", str11.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "9-April-1900" + "'", str15.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "9-April-1900" + "'", str28.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 9 + "'", int31 == 9);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNull(inputStream36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str5 = spreadsheetDate4.toString();
        boolean boolean6 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str9 = spreadsheetDate8.toString();
        spreadsheetDate8.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str16 = spreadsheetDate15.toString();
        boolean boolean17 = spreadsheetDate13.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str22 = spreadsheetDate21.toString();
        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean24 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        int int25 = spreadsheetDate21.getDayOfMonth();
        boolean boolean26 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean27 = day0.equals((java.lang.Object) spreadsheetDate8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day0.next();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-April-1900" + "'", str9.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "9-April-1900" + "'", str16.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 9 + "'", int25 == 9);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        timeSeries2.clear();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) day5, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test237");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        long long2 = fixedMillisecond0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439126358L + "'", long2 == 1560439126358L);
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year3 = month2.getYear();
        long long4 = year3.getSerialIndex();
        java.lang.String str5 = year3.toString();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 10, year3);
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(2147483647, year3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate13 = null;
        try {
            int int14 = spreadsheetDate3.compare(serialDate13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long5 = fixedMillisecond4.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        spreadsheetDate13.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str27 = spreadsheetDate26.toString();
        boolean boolean28 = spreadsheetDate24.isOn((org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean29 = spreadsheetDate20.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        int int30 = spreadsheetDate26.getDayOfMonth();
        boolean boolean31 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean32 = fixedMillisecond4.equals((java.lang.Object) spreadsheetDate13);
        boolean boolean33 = day2.equals((java.lang.Object) fixedMillisecond4);
        java.lang.Class<?> wildcardClass34 = fixedMillisecond4.getClass();
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
        java.io.InputStream inputStream36 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass34);
        java.io.InputStream inputStream37 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("October", (java.lang.Class) wildcardClass34);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "9-April-1900" + "'", str27.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertNotNull(inputStream36);
        org.junit.Assert.assertNull(inputStream37);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        int int7 = timeSeries6.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long10 = fixedMillisecond9.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond9.previous();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond9.getLastMillisecond(calendar12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) 11);
        long long16 = fixedMillisecond9.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
        java.lang.Class class18 = timeSeries9.getTimePeriodClass();
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Last", "", "ERROR : Relative To String", class22);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries23.removePropertyChangeListener(propertyChangeListener24);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class27);
        timeSeries28.setDomainDescription("October 0");
        java.lang.Object obj31 = timeSeries28.clone();
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries23.addAndOrUpdate(timeSeries28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date35 = fixedMillisecond34.getTime();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int39 = month38.getMonth();
        java.lang.String str40 = month38.toString();
        java.lang.String str41 = month38.toString();
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (org.jfree.data.time.RegularTimePeriod) month38);
        try {
            timeSeries9.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (java.lang.Number) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "October 0" + "'", str40.equals("October 0"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "October 0" + "'", str41.equals("October 0"));
        org.junit.Assert.assertNotNull(timeSeries42);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100, (int) (short) -1, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (35) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Last", "", "ERROR : Relative To String", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class8);
        timeSeries9.setDomainDescription("October 0");
        java.lang.Object obj12 = timeSeries9.clone();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries9);
        java.lang.Object obj14 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) timeSeries13);
        timeSeries13.setMaximumItemCount(2147483647);
        try {
            timeSeries13.update((int) '4', (java.lang.Number) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Comparable comparable10 = timeSeries6.getKey();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class12);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries13.addAndOrUpdate(timeSeries16);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries17.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj24 = null;
        boolean boolean25 = month23.equals(obj24);
        int int26 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
        long long27 = month23.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries29 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) month23, regularTimePeriod28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + "Overwritten values from: 1.0" + "'", comparable10.equals("Overwritten values from: 1.0"));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class8);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries13.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj20 = null;
        boolean boolean21 = month19.equals(obj20);
        int int22 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) month19);
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class24);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries25.addAndOrUpdate(timeSeries28);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries29);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year32 = month31.getYear();
        int int33 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) year32);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) month19, (org.jfree.data.time.RegularTimePeriod) year32);
        int int35 = month19.getYearValue();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(year32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        spreadsheetDate7.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str15 = spreadsheetDate14.toString();
        boolean boolean16 = spreadsheetDate12.isOn((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean23 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int24 = spreadsheetDate20.getDayOfMonth();
        boolean boolean25 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, (org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int26 = spreadsheetDate20.getYYYY();
        java.lang.String str27 = spreadsheetDate20.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "9-April-1900" + "'", str15.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 9 + "'", int24 == 9);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1900 + "'", int26 == 1900);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "9-April-1900" + "'", str27.equals("9-April-1900"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str6 = spreadsheetDate5.toString();
        boolean boolean7 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str12 = spreadsheetDate11.toString();
        boolean boolean13 = spreadsheetDate9.isOn((org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean14 = spreadsheetDate5.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int15 = spreadsheetDate11.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str18 = spreadsheetDate17.toString();
        boolean boolean19 = spreadsheetDate11.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(6, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        try {
            org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "9-April-1900" + "'", str6.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-April-1900" + "'", str12.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "9-April-1900" + "'", str18.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(serialDate20);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        boolean boolean7 = timeSeries2.getNotify();
        int int8 = timeSeries2.getMaximumItemCount();
        java.lang.String str9 = timeSeries2.getDescription();
        timeSeries2.removeAgedItems(false);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj13 = null;
        boolean boolean14 = month12.equals(obj13);
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) month16);
        long long18 = month16.getSerialIndex();
        java.util.Calendar calendar19 = null;
        try {
            long long20 = month16.getFirstMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 24234L + "'", long18 == 24234L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        boolean boolean7 = timeSeries2.getNotify();
        int int8 = timeSeries2.getMaximumItemCount();
        java.lang.String str9 = timeSeries2.getDescription();
        int int10 = timeSeries2.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int14 = month13.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) 1.0d);
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class18);
        int int20 = timeSeries19.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries19.removeChangeListener(seriesChangeListener21);
        java.util.Collection collection23 = timeSeries19.getTimePeriods();
        int int24 = timeSeriesDataItem16.compareTo((java.lang.Object) timeSeries19);
        java.lang.Number number25 = timeSeriesDataItem16.getValue();
        try {
            timeSeries2.add(timeSeriesDataItem16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 1.0d + "'", number25.equals(1.0d));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        timeSeries2.clear();
        java.lang.Comparable comparable5 = timeSeries2.getKey();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year7 = month6.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date10 = fixedMillisecond9.getTime();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        long long12 = fixedMillisecond9.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 1.0f + "'", comparable5.equals(1.0f));
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str3 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        boolean boolean9 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        spreadsheetDate24.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str32 = spreadsheetDate31.toString();
        boolean boolean33 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        boolean boolean39 = spreadsheetDate35.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int41 = spreadsheetDate37.getDayOfMonth();
        boolean boolean42 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int43 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays(100, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str48 = spreadsheetDate47.toString();
        spreadsheetDate47.setDescription("9-April-1900");
        int int51 = spreadsheetDate47.toSerial();
        boolean boolean52 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SerialDate serialDate54 = spreadsheetDate47.getNearestDayOfWeek(4);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(serialDate54);
        long long56 = day55.getFirstMillisecond();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long62 = fixedMillisecond61.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str67 = spreadsheetDate66.toString();
        boolean boolean68 = spreadsheetDate64.isOn((org.jfree.data.time.SerialDate) spreadsheetDate66);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str71 = spreadsheetDate70.toString();
        spreadsheetDate70.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str78 = spreadsheetDate77.toString();
        boolean boolean79 = spreadsheetDate75.isOn((org.jfree.data.time.SerialDate) spreadsheetDate77);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate81 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate83 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str84 = spreadsheetDate83.toString();
        boolean boolean85 = spreadsheetDate81.isOn((org.jfree.data.time.SerialDate) spreadsheetDate83);
        boolean boolean86 = spreadsheetDate77.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate83);
        int int87 = spreadsheetDate83.getDayOfMonth();
        boolean boolean88 = spreadsheetDate64.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate70, (org.jfree.data.time.SerialDate) spreadsheetDate83);
        boolean boolean89 = fixedMillisecond61.equals((java.lang.Object) spreadsheetDate70);
        boolean boolean90 = day59.equals((java.lang.Object) fixedMillisecond61);
        java.lang.Class<?> wildcardClass91 = fixedMillisecond61.getClass();
        java.io.InputStream inputStream92 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("9-April-1900", (java.lang.Class) wildcardClass91);
        java.net.URL uRL93 = org.jfree.chart.util.ObjectUtilities.getResource("April", (java.lang.Class) wildcardClass91);
        org.jfree.data.time.TimeSeries timeSeries94 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day55, (java.lang.Class) wildcardClass91);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = day55.next();
        long long96 = day55.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9 + "'", int41 == 9);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "9-April-1900" + "'", str48.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 100 + "'", int51 == 100);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-2200665600000L) + "'", long56 == (-2200665600000L));
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 100L + "'", long62 == 100L);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "9-April-1900" + "'", str67.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "9-April-1900" + "'", str71.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "9-April-1900" + "'", str78.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "9-April-1900" + "'", str84.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 9 + "'", int87 == 9);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(wildcardClass91);
        org.junit.Assert.assertNull(inputStream92);
        org.junit.Assert.assertNull(uRL93);
        org.junit.Assert.assertNotNull(regularTimePeriod95);
        org.junit.Assert.assertTrue("'" + long96 + "' != '" + 98L + "'", long96 == 98L);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(1900);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-458) + "'", int1 == (-458));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        timeSeries9.setNotify(false);
        timeSeries9.removeAgedItems(true);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("April");
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj13 = null;
        boolean boolean14 = month12.equals(obj13);
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) month16);
        long long18 = month16.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month16, (double) (-457));
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 24234L + "'", long18 == 24234L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str2 = spreadsheetDate1.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str7 = spreadsheetDate6.toString();
        boolean boolean8 = spreadsheetDate4.isOn((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str13 = spreadsheetDate12.toString();
        boolean boolean14 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean15 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str20 = spreadsheetDate19.toString();
        boolean boolean21 = spreadsheetDate17.isOn((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str24 = spreadsheetDate23.toString();
        spreadsheetDate23.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str31 = spreadsheetDate30.toString();
        boolean boolean32 = spreadsheetDate28.isOn((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str37 = spreadsheetDate36.toString();
        boolean boolean38 = spreadsheetDate34.isOn((org.jfree.data.time.SerialDate) spreadsheetDate36);
        boolean boolean39 = spreadsheetDate30.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate36);
        int int40 = spreadsheetDate36.getDayOfMonth();
        boolean boolean41 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, (org.jfree.data.time.SerialDate) spreadsheetDate36);
        int int42 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SerialDate serialDate43 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str44 = spreadsheetDate1.getDescription();
        java.lang.Class class46 = null;
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class46);
        java.lang.Class class49 = null;
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class49);
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries47.addAndOrUpdate(timeSeries50);
        boolean boolean52 = timeSeries47.getNotify();
        int int53 = timeSeries47.getItemCount();
        boolean boolean54 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) str44, (java.lang.Object) timeSeries47);
        java.lang.Class class58 = null;
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Last", "", "ERROR : Relative To String", class58);
        java.beans.PropertyChangeListener propertyChangeListener60 = null;
        timeSeries59.removePropertyChangeListener(propertyChangeListener60);
        java.lang.Class class63 = null;
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class63);
        timeSeries64.setDomainDescription("October 0");
        java.lang.Object obj67 = timeSeries64.clone();
        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries59.addAndOrUpdate(timeSeries64);
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date71 = fixedMillisecond70.getTime();
        org.jfree.data.time.Month month74 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int75 = month74.getMonth();
        java.lang.String str76 = month74.toString();
        java.lang.String str77 = month74.toString();
        org.jfree.data.time.TimeSeries timeSeries78 = timeSeries68.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond70, (org.jfree.data.time.RegularTimePeriod) month74);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem79 = timeSeries47.getDataItem((org.jfree.data.time.RegularTimePeriod) month74);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "9-April-1900" + "'", str2.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9-April-1900" + "'", str7.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "9-April-1900" + "'", str13.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "9-April-1900" + "'", str20.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "9-April-1900" + "'", str24.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "9-April-1900" + "'", str31.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "9-April-1900" + "'", str37.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 9 + "'", int40 == 9);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(obj67);
        org.junit.Assert.assertNotNull(timeSeries68);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 10 + "'", int75 == 10);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "October 0" + "'", str76.equals("October 0"));
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "October 0" + "'", str77.equals("October 0"));
        org.junit.Assert.assertNotNull(timeSeries78);
        org.junit.Assert.assertNull(timeSeriesDataItem79);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str5 = spreadsheetDate4.toString();
//        boolean boolean6 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str9 = spreadsheetDate8.toString();
//        spreadsheetDate8.setDescription("9-April-1900");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str16 = spreadsheetDate15.toString();
//        boolean boolean17 = spreadsheetDate13.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str22 = spreadsheetDate21.toString();
//        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        boolean boolean24 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        int int25 = spreadsheetDate21.getDayOfMonth();
//        boolean boolean26 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate21);
//        boolean boolean27 = day0.equals((java.lang.Object) spreadsheetDate8);
//        long long28 = day0.getSerialIndex();
//        long long29 = day0.getSerialIndex();
//        int int30 = day0.getYear();
//        java.util.Calendar calendar31 = null;
//        try {
//            long long32 = day0.getLastMillisecond(calendar31);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-April-1900" + "'", str9.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "9-April-1900" + "'", str16.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 9 + "'", int25 == 9);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 43629L + "'", long28 == 43629L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 43629L + "'", long29 == 43629L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        long long3 = month2.getSerialIndex();
        long long4 = month2.getSerialIndex();
        int int5 = month2.getMonth();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str6 = spreadsheetDate5.toString();
        boolean boolean7 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str12 = spreadsheetDate11.toString();
        boolean boolean13 = spreadsheetDate9.isOn((org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean14 = spreadsheetDate5.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int15 = spreadsheetDate5.getMonth();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addDays((int) 'a', (org.jfree.data.time.SerialDate) spreadsheetDate5);
        try {
            org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 10, (org.jfree.data.time.SerialDate) spreadsheetDate5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "9-April-1900" + "'", str6.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-April-1900" + "'", str12.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(serialDate16);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str6 = spreadsheetDate5.toString();
        boolean boolean7 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str12 = spreadsheetDate11.toString();
        boolean boolean13 = spreadsheetDate9.isOn((org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean14 = spreadsheetDate5.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str19 = spreadsheetDate18.toString();
        boolean boolean20 = spreadsheetDate16.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str23 = spreadsheetDate22.toString();
        spreadsheetDate22.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str30 = spreadsheetDate29.toString();
        boolean boolean31 = spreadsheetDate27.isOn((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str36 = spreadsheetDate35.toString();
        boolean boolean37 = spreadsheetDate33.isOn((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean38 = spreadsheetDate29.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        int int39 = spreadsheetDate35.getDayOfMonth();
        boolean boolean40 = spreadsheetDate16.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate22, (org.jfree.data.time.SerialDate) spreadsheetDate35);
        int int41 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str44 = spreadsheetDate43.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str49 = spreadsheetDate48.toString();
        boolean boolean50 = spreadsheetDate46.isOn((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str55 = spreadsheetDate54.toString();
        boolean boolean56 = spreadsheetDate52.isOn((org.jfree.data.time.SerialDate) spreadsheetDate54);
        boolean boolean57 = spreadsheetDate48.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate54);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str62 = spreadsheetDate61.toString();
        boolean boolean63 = spreadsheetDate59.isOn((org.jfree.data.time.SerialDate) spreadsheetDate61);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str66 = spreadsheetDate65.toString();
        spreadsheetDate65.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate72 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str73 = spreadsheetDate72.toString();
        boolean boolean74 = spreadsheetDate70.isOn((org.jfree.data.time.SerialDate) spreadsheetDate72);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate78 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str79 = spreadsheetDate78.toString();
        boolean boolean80 = spreadsheetDate76.isOn((org.jfree.data.time.SerialDate) spreadsheetDate78);
        boolean boolean81 = spreadsheetDate72.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate78);
        int int82 = spreadsheetDate78.getDayOfMonth();
        boolean boolean83 = spreadsheetDate59.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate65, (org.jfree.data.time.SerialDate) spreadsheetDate78);
        int int84 = spreadsheetDate54.compare((org.jfree.data.time.SerialDate) spreadsheetDate59);
        org.jfree.data.time.SerialDate serialDate85 = spreadsheetDate43.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate59);
        org.jfree.data.time.SerialDate serialDate86 = spreadsheetDate16.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate59);
        boolean boolean87 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate59);
        int int88 = spreadsheetDate59.getMonth();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "9-April-1900" + "'", str6.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-April-1900" + "'", str12.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-April-1900" + "'", str19.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "9-April-1900" + "'", str23.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "9-April-1900" + "'", str30.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "9-April-1900" + "'", str36.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 9 + "'", int39 == 9);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "9-April-1900" + "'", str44.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "9-April-1900" + "'", str49.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "9-April-1900" + "'", str55.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "9-April-1900" + "'", str62.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "9-April-1900" + "'", str66.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "9-April-1900" + "'", str73.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "9-April-1900" + "'", str79.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 9 + "'", int82 == 9);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertNotNull(serialDate85);
        org.junit.Assert.assertNotNull(serialDate86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 4 + "'", int88 == 4);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int7 = month6.getMonth();
        java.lang.String str8 = month6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        long long10 = month6.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 0" + "'", str8.equals("October 0"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62109475200001L) + "'", long10 == (-62109475200001L));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        int int7 = timeSeries6.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long10 = fixedMillisecond9.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond9.previous();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond9.getLastMillisecond(calendar12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) 11);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class17);
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class20);
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries18.addAndOrUpdate(timeSeries21);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries22.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj29 = null;
        boolean boolean30 = month28.equals(obj29);
        int int31 = timeSeries22.getIndex((org.jfree.data.time.RegularTimePeriod) month28);
        long long32 = month28.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date35 = fixedMillisecond34.getTime();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        boolean boolean37 = month28.equals((java.lang.Object) day36);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day36, (double) (-1.0f));
        java.util.Calendar calendar40 = null;
        try {
            long long41 = day36.getFirstMillisecond(calendar40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem39);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str5 = spreadsheetDate4.toString();
        boolean boolean6 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str11 = spreadsheetDate10.toString();
        boolean boolean12 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean13 = spreadsheetDate4.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str18 = spreadsheetDate17.toString();
        boolean boolean19 = spreadsheetDate15.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str22 = spreadsheetDate21.toString();
        spreadsheetDate21.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str29 = spreadsheetDate28.toString();
        boolean boolean30 = spreadsheetDate26.isOn((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str35 = spreadsheetDate34.toString();
        boolean boolean36 = spreadsheetDate32.isOn((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean37 = spreadsheetDate28.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate34);
        int int38 = spreadsheetDate34.getDayOfMonth();
        boolean boolean39 = spreadsheetDate15.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate21, (org.jfree.data.time.SerialDate) spreadsheetDate34);
        int int40 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        try {
            org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-April-1900" + "'", str11.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "9-April-1900" + "'", str18.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "9-April-1900" + "'", str29.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "9-April-1900" + "'", str35.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 9 + "'", int38 == 9);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str5 = spreadsheetDate4.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str16 = spreadsheetDate15.toString();
        boolean boolean17 = spreadsheetDate13.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str23 = spreadsheetDate22.toString();
        boolean boolean24 = spreadsheetDate20.isOn((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str27 = spreadsheetDate26.toString();
        spreadsheetDate26.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str34 = spreadsheetDate33.toString();
        boolean boolean35 = spreadsheetDate31.isOn((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str40 = spreadsheetDate39.toString();
        boolean boolean41 = spreadsheetDate37.isOn((org.jfree.data.time.SerialDate) spreadsheetDate39);
        boolean boolean42 = spreadsheetDate33.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate39);
        int int43 = spreadsheetDate39.getDayOfMonth();
        boolean boolean44 = spreadsheetDate20.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate26, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        int int45 = spreadsheetDate15.compare((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SerialDate serialDate46 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str52 = spreadsheetDate51.toString();
        boolean boolean53 = spreadsheetDate49.isOn((org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str58 = spreadsheetDate57.toString();
        boolean boolean59 = spreadsheetDate55.isOn((org.jfree.data.time.SerialDate) spreadsheetDate57);
        boolean boolean60 = spreadsheetDate51.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate57);
        boolean boolean61 = spreadsheetDate20.isOn((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate57);
        int int63 = spreadsheetDate57.getMonth();
        try {
            org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(13, (org.jfree.data.time.SerialDate) spreadsheetDate57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "9-April-1900" + "'", str16.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "9-April-1900" + "'", str23.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "9-April-1900" + "'", str27.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "9-April-1900" + "'", str34.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "9-April-1900" + "'", str40.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 9 + "'", int43 == 9);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "9-April-1900" + "'", str52.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "9-April-1900" + "'", str58.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 4 + "'", int63 == 4);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str2 = spreadsheetDate1.toString();
        spreadsheetDate1.setDescription("9-April-1900");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "9-April-1900" + "'", str2.equals("9-April-1900"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        boolean boolean7 = timeSeries2.getNotify();
        timeSeries2.setDomainDescription("hi!");
        java.lang.String str10 = timeSeries2.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries2.addChangeListener(seriesChangeListener11);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test274");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str5 = spreadsheetDate4.toString();
//        boolean boolean6 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str9 = spreadsheetDate8.toString();
//        spreadsheetDate8.setDescription("9-April-1900");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str16 = spreadsheetDate15.toString();
//        boolean boolean17 = spreadsheetDate13.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str22 = spreadsheetDate21.toString();
//        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        boolean boolean24 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        int int25 = spreadsheetDate21.getDayOfMonth();
//        boolean boolean26 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate21);
//        boolean boolean27 = day0.equals((java.lang.Object) spreadsheetDate8);
//        long long28 = day0.getLastMillisecond();
//        long long29 = day0.getSerialIndex();
//        long long30 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-April-1900" + "'", str9.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "9-April-1900" + "'", str16.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 9 + "'", int25 == 9);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560495599999L + "'", long28 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 43629L + "'", long29 == 43629L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560495599999L + "'", long30 == 1560495599999L);
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        long long10 = fixedMillisecond8.getFirstMillisecond();
        long long11 = fixedMillisecond8.getLastMillisecond();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond8.getMiddleMillisecond(calendar12);
        java.util.Date date14 = fixedMillisecond8.getTime();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.previous();
        try {
            timeSeries5.add(regularTimePeriod17, (java.lang.Number) (byte) 1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long5 = fixedMillisecond4.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        spreadsheetDate13.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str27 = spreadsheetDate26.toString();
        boolean boolean28 = spreadsheetDate24.isOn((org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean29 = spreadsheetDate20.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        int int30 = spreadsheetDate26.getDayOfMonth();
        boolean boolean31 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean32 = fixedMillisecond4.equals((java.lang.Object) spreadsheetDate13);
        boolean boolean33 = day2.equals((java.lang.Object) fixedMillisecond4);
        java.lang.Class<?> wildcardClass34 = fixedMillisecond4.getClass();
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
        java.net.URL uRL36 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass34);
        java.lang.ClassLoader classLoader37 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass34);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long42 = fixedMillisecond41.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str47 = spreadsheetDate46.toString();
        boolean boolean48 = spreadsheetDate44.isOn((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str51 = spreadsheetDate50.toString();
        spreadsheetDate50.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str58 = spreadsheetDate57.toString();
        boolean boolean59 = spreadsheetDate55.isOn((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str64 = spreadsheetDate63.toString();
        boolean boolean65 = spreadsheetDate61.isOn((org.jfree.data.time.SerialDate) spreadsheetDate63);
        boolean boolean66 = spreadsheetDate57.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate63);
        int int67 = spreadsheetDate63.getDayOfMonth();
        boolean boolean68 = spreadsheetDate44.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate50, (org.jfree.data.time.SerialDate) spreadsheetDate63);
        boolean boolean69 = fixedMillisecond41.equals((java.lang.Object) spreadsheetDate50);
        boolean boolean70 = day39.equals((java.lang.Object) fixedMillisecond41);
        java.lang.Class<?> wildcardClass71 = fixedMillisecond41.getClass();
        java.io.InputStream inputStream72 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("9-April-1900", (java.lang.Class) wildcardClass71);
        java.lang.Class class73 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass71);
        java.lang.Object obj74 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("org.jfree.data.time.TimePeriodFormatException: ", (java.lang.Class) wildcardClass34, class73);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "9-April-1900" + "'", str27.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertNull(uRL36);
        org.junit.Assert.assertNotNull(classLoader37);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 100L + "'", long42 == 100L);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "9-April-1900" + "'", str47.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "9-April-1900" + "'", str51.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "9-April-1900" + "'", str58.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "9-April-1900" + "'", str64.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 9 + "'", int67 == 9);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(wildcardClass71);
        org.junit.Assert.assertNull(inputStream72);
        org.junit.Assert.assertNotNull(class73);
        org.junit.Assert.assertNull(obj74);
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test278");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
//        boolean boolean7 = timeSeries2.getNotify();
//        int int8 = timeSeries2.getMaximumItemCount();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class10);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class13);
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries11.addAndOrUpdate(timeSeries14);
//        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries15.createCopy(0, (int) (short) 1);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class20);
//        java.lang.Class class23 = null;
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class23);
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries21.addAndOrUpdate(timeSeries24);
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries18.addAndOrUpdate(timeSeries25);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year28 = month27.getYear();
//        long long29 = year28.getSerialIndex();
//        java.lang.String str30 = year28.toString();
//        timeSeries25.setKey((java.lang.Comparable) year28);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str37 = spreadsheetDate36.toString();
//        boolean boolean38 = spreadsheetDate34.isOn((org.jfree.data.time.SerialDate) spreadsheetDate36);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str41 = spreadsheetDate40.toString();
//        spreadsheetDate40.setDescription("9-April-1900");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str48 = spreadsheetDate47.toString();
//        boolean boolean49 = spreadsheetDate45.isOn((org.jfree.data.time.SerialDate) spreadsheetDate47);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str54 = spreadsheetDate53.toString();
//        boolean boolean55 = spreadsheetDate51.isOn((org.jfree.data.time.SerialDate) spreadsheetDate53);
//        boolean boolean56 = spreadsheetDate47.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate53);
//        int int57 = spreadsheetDate53.getDayOfMonth();
//        boolean boolean58 = spreadsheetDate34.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate40, (org.jfree.data.time.SerialDate) spreadsheetDate53);
//        boolean boolean59 = day32.equals((java.lang.Object) spreadsheetDate40);
//        long long60 = day32.getLastMillisecond();
//        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year62 = month61.getYear();
//        long long63 = year62.getSerialIndex();
//        long long64 = year62.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries65 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) day32, (org.jfree.data.time.RegularTimePeriod) year62);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year62, (java.lang.Number) 43629L);
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertNotNull(timeSeries18);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNotNull(year28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2019" + "'", str30.equals("2019"));
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "9-April-1900" + "'", str37.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "9-April-1900" + "'", str41.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "9-April-1900" + "'", str48.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "9-April-1900" + "'", str54.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 9 + "'", int57 == 9);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560495599999L + "'", long60 == 1560495599999L);
//        org.junit.Assert.assertNotNull(year62);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 2019L + "'", long63 == 2019L);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1577865599999L + "'", long64 == 1577865599999L);
//        org.junit.Assert.assertNotNull(timeSeries65);
//        org.junit.Assert.assertNull(timeSeriesDataItem67);
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str5 = spreadsheetDate4.toString();
        boolean boolean6 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str9 = spreadsheetDate8.toString();
        spreadsheetDate8.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str16 = spreadsheetDate15.toString();
        boolean boolean17 = spreadsheetDate13.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str22 = spreadsheetDate21.toString();
        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean24 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        int int25 = spreadsheetDate21.getDayOfMonth();
        boolean boolean26 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        int int27 = spreadsheetDate21.getYYYY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long30 = fixedMillisecond29.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str35 = spreadsheetDate34.toString();
        boolean boolean36 = spreadsheetDate32.isOn((org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str39 = spreadsheetDate38.toString();
        spreadsheetDate38.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str46 = spreadsheetDate45.toString();
        boolean boolean47 = spreadsheetDate43.isOn((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str52 = spreadsheetDate51.toString();
        boolean boolean53 = spreadsheetDate49.isOn((org.jfree.data.time.SerialDate) spreadsheetDate51);
        boolean boolean54 = spreadsheetDate45.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate51);
        int int55 = spreadsheetDate51.getDayOfMonth();
        boolean boolean56 = spreadsheetDate32.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate38, (org.jfree.data.time.SerialDate) spreadsheetDate51);
        boolean boolean57 = fixedMillisecond29.equals((java.lang.Object) spreadsheetDate38);
        boolean boolean58 = spreadsheetDate21.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate38);
        try {
            org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.addYears(9999, (org.jfree.data.time.SerialDate) spreadsheetDate21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-April-1900" + "'", str9.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "9-April-1900" + "'", str16.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 9 + "'", int25 == 9);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1900 + "'", int27 == 1900);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "9-April-1900" + "'", str35.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "9-April-1900" + "'", str39.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "9-April-1900" + "'", str46.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "9-April-1900" + "'", str52.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 9 + "'", int55 == 9);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        long long3 = fixedMillisecond2.getMiddleMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str8 = spreadsheetDate7.toString();
//        boolean boolean9 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str12 = spreadsheetDate11.toString();
//        spreadsheetDate11.setDescription("9-April-1900");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str19 = spreadsheetDate18.toString();
//        boolean boolean20 = spreadsheetDate16.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str25 = spreadsheetDate24.toString();
//        boolean boolean26 = spreadsheetDate22.isOn((org.jfree.data.time.SerialDate) spreadsheetDate24);
//        boolean boolean27 = spreadsheetDate18.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate24);
//        int int28 = spreadsheetDate24.getDayOfMonth();
//        boolean boolean29 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, (org.jfree.data.time.SerialDate) spreadsheetDate24);
//        boolean boolean30 = fixedMillisecond2.equals((java.lang.Object) spreadsheetDate11);
//        boolean boolean31 = day0.equals((java.lang.Object) fixedMillisecond2);
//        long long32 = day0.getFirstMillisecond();
//        java.lang.Object obj33 = null;
//        boolean boolean34 = day0.equals(obj33);
//        java.lang.String str35 = day0.toString();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-April-1900" + "'", str12.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-April-1900" + "'", str19.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 9 + "'", int28 == 9);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560409200000L + "'", long32 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "13-June-2019" + "'", str35.equals("13-June-2019"));
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        timeSeries2.setDomainDescription("October 0");
        java.lang.Object obj5 = timeSeries2.clone();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        long long9 = month8.getSerialIndex();
        java.lang.Number number10 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) month8);
        timeSeries2.setMaximumItemAge((long) 4);
        timeSeries2.setMaximumItemCount(0);
        java.lang.String str15 = timeSeries2.getRangeDescription();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Value" + "'", str15.equals("Value"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str17 = spreadsheetDate16.toString();
        boolean boolean18 = spreadsheetDate14.isOn((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        spreadsheetDate20.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str28 = spreadsheetDate27.toString();
        boolean boolean29 = spreadsheetDate25.isOn((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str34 = spreadsheetDate33.toString();
        boolean boolean35 = spreadsheetDate31.isOn((org.jfree.data.time.SerialDate) spreadsheetDate33);
        boolean boolean36 = spreadsheetDate27.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int37 = spreadsheetDate33.getDayOfMonth();
        boolean boolean38 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate20, (org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int39 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str42 = spreadsheetDate41.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str47 = spreadsheetDate46.toString();
        boolean boolean48 = spreadsheetDate44.isOn((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str53 = spreadsheetDate52.toString();
        boolean boolean54 = spreadsheetDate50.isOn((org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean55 = spreadsheetDate46.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str60 = spreadsheetDate59.toString();
        boolean boolean61 = spreadsheetDate57.isOn((org.jfree.data.time.SerialDate) spreadsheetDate59);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str64 = spreadsheetDate63.toString();
        spreadsheetDate63.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str71 = spreadsheetDate70.toString();
        boolean boolean72 = spreadsheetDate68.isOn((org.jfree.data.time.SerialDate) spreadsheetDate70);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str77 = spreadsheetDate76.toString();
        boolean boolean78 = spreadsheetDate74.isOn((org.jfree.data.time.SerialDate) spreadsheetDate76);
        boolean boolean79 = spreadsheetDate70.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate76);
        int int80 = spreadsheetDate76.getDayOfMonth();
        boolean boolean81 = spreadsheetDate57.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate63, (org.jfree.data.time.SerialDate) spreadsheetDate76);
        int int82 = spreadsheetDate52.compare((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SerialDate serialDate83 = spreadsheetDate41.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SerialDate serialDate84 = spreadsheetDate14.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate57);
        int int85 = spreadsheetDate14.getYYYY();
        org.jfree.data.time.SerialDate serialDate86 = null;
        try {
            org.jfree.data.time.SerialDate serialDate87 = spreadsheetDate14.getEndOfCurrentMonth(serialDate86);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "9-April-1900" + "'", str17.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "9-April-1900" + "'", str28.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "9-April-1900" + "'", str34.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 9 + "'", int37 == 9);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "9-April-1900" + "'", str42.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "9-April-1900" + "'", str47.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "9-April-1900" + "'", str53.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "9-April-1900" + "'", str60.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "9-April-1900" + "'", str64.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "9-April-1900" + "'", str71.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "9-April-1900" + "'", str77.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 9 + "'", int80 == 9);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1900 + "'", int85 == 1900);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj13 = null;
        boolean boolean14 = month12.equals(obj13);
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) month16);
        int int18 = timeSeries6.getMaximumItemCount();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeries6.getTimePeriod(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2147483647 + "'", int18 == 2147483647);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int6 = spreadsheetDate3.getMonth();
        org.jfree.data.time.SerialDate serialDate8 = spreadsheetDate3.getNearestDayOfWeek(1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str11 = spreadsheetDate10.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str16 = spreadsheetDate15.toString();
        boolean boolean17 = spreadsheetDate13.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str22 = spreadsheetDate21.toString();
        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean24 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str29 = spreadsheetDate28.toString();
        boolean boolean30 = spreadsheetDate26.isOn((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str33 = spreadsheetDate32.toString();
        spreadsheetDate32.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str40 = spreadsheetDate39.toString();
        boolean boolean41 = spreadsheetDate37.isOn((org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str46 = spreadsheetDate45.toString();
        boolean boolean47 = spreadsheetDate43.isOn((org.jfree.data.time.SerialDate) spreadsheetDate45);
        boolean boolean48 = spreadsheetDate39.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate45);
        int int49 = spreadsheetDate45.getDayOfMonth();
        boolean boolean50 = spreadsheetDate26.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate32, (org.jfree.data.time.SerialDate) spreadsheetDate45);
        int int51 = spreadsheetDate21.compare((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate52 = spreadsheetDate10.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean53 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-April-1900" + "'", str11.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "9-April-1900" + "'", str16.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "9-April-1900" + "'", str29.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-April-1900" + "'", str33.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "9-April-1900" + "'", str40.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "9-April-1900" + "'", str46.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 9 + "'", int49 == 9);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        long long3 = month2.getSerialIndex();
        long long4 = month2.getSerialIndex();
        try {
            org.jfree.data.time.Year year5 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj3 = null;
        boolean boolean4 = month2.equals(obj3);
        int int5 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj13 = null;
        boolean boolean14 = month12.equals(obj13);
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) month16);
        timeSeries6.setNotify(true);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int23 = month22.getMonth();
        java.lang.String str24 = month22.toString();
        java.lang.String str25 = month22.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) month22);
        java.util.Calendar calendar27 = null;
        try {
            month22.peg(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "October 0" + "'", str24.equals("October 0"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "October 0" + "'", str25.equals("October 0"));
        org.junit.Assert.assertNull(timeSeriesDataItem26);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str5 = spreadsheetDate4.toString();
        boolean boolean6 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str11 = spreadsheetDate10.toString();
        boolean boolean12 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean13 = spreadsheetDate4.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str18 = spreadsheetDate17.toString();
        boolean boolean19 = spreadsheetDate15.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str22 = spreadsheetDate21.toString();
        spreadsheetDate21.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str29 = spreadsheetDate28.toString();
        boolean boolean30 = spreadsheetDate26.isOn((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str35 = spreadsheetDate34.toString();
        boolean boolean36 = spreadsheetDate32.isOn((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean37 = spreadsheetDate28.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate34);
        int int38 = spreadsheetDate34.getDayOfMonth();
        boolean boolean39 = spreadsheetDate15.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate21, (org.jfree.data.time.SerialDate) spreadsheetDate34);
        int int40 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str43 = spreadsheetDate42.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str48 = spreadsheetDate47.toString();
        boolean boolean49 = spreadsheetDate45.isOn((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str54 = spreadsheetDate53.toString();
        boolean boolean55 = spreadsheetDate51.isOn((org.jfree.data.time.SerialDate) spreadsheetDate53);
        boolean boolean56 = spreadsheetDate47.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate53);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str61 = spreadsheetDate60.toString();
        boolean boolean62 = spreadsheetDate58.isOn((org.jfree.data.time.SerialDate) spreadsheetDate60);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str65 = spreadsheetDate64.toString();
        spreadsheetDate64.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str72 = spreadsheetDate71.toString();
        boolean boolean73 = spreadsheetDate69.isOn((org.jfree.data.time.SerialDate) spreadsheetDate71);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str78 = spreadsheetDate77.toString();
        boolean boolean79 = spreadsheetDate75.isOn((org.jfree.data.time.SerialDate) spreadsheetDate77);
        boolean boolean80 = spreadsheetDate71.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate77);
        int int81 = spreadsheetDate77.getDayOfMonth();
        boolean boolean82 = spreadsheetDate58.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate64, (org.jfree.data.time.SerialDate) spreadsheetDate77);
        int int83 = spreadsheetDate53.compare((org.jfree.data.time.SerialDate) spreadsheetDate58);
        org.jfree.data.time.SerialDate serialDate84 = spreadsheetDate42.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate58);
        org.jfree.data.time.SerialDate serialDate85 = spreadsheetDate15.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate58);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate87 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate89 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str90 = spreadsheetDate89.toString();
        boolean boolean91 = spreadsheetDate87.isOn((org.jfree.data.time.SerialDate) spreadsheetDate89);
        int int92 = spreadsheetDate89.getMonth();
        boolean boolean93 = spreadsheetDate15.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate89);
        try {
            org.jfree.data.time.SerialDate serialDate94 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) ' ', (org.jfree.data.time.SerialDate) spreadsheetDate15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-April-1900" + "'", str11.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "9-April-1900" + "'", str18.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "9-April-1900" + "'", str29.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "9-April-1900" + "'", str35.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 9 + "'", int38 == 9);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "9-April-1900" + "'", str43.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "9-April-1900" + "'", str48.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "9-April-1900" + "'", str54.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "9-April-1900" + "'", str61.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "9-April-1900" + "'", str65.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "9-April-1900" + "'", str72.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "9-April-1900" + "'", str78.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 9 + "'", int81 == 9);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertNotNull(serialDate85);
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "9-April-1900" + "'", str90.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 4 + "'", int92 == 4);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str9 = spreadsheetDate8.toString();
        boolean boolean10 = spreadsheetDate6.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str15 = spreadsheetDate14.toString();
        boolean boolean16 = spreadsheetDate12.isOn((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean17 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str22 = spreadsheetDate21.toString();
        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str26 = spreadsheetDate25.toString();
        spreadsheetDate25.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str33 = spreadsheetDate32.toString();
        boolean boolean34 = spreadsheetDate30.isOn((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str39 = spreadsheetDate38.toString();
        boolean boolean40 = spreadsheetDate36.isOn((org.jfree.data.time.SerialDate) spreadsheetDate38);
        boolean boolean41 = spreadsheetDate32.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        int int42 = spreadsheetDate38.getDayOfMonth();
        boolean boolean43 = spreadsheetDate19.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate38);
        int int44 = spreadsheetDate14.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate45 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addDays(100, (org.jfree.data.time.SerialDate) spreadsheetDate19);
        int int47 = spreadsheetDate19.toSerial();
        java.lang.Class<?> wildcardClass48 = spreadsheetDate19.getClass();
        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
        java.io.InputStream inputStream50 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("October 0", (java.lang.Class) wildcardClass48);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-April-1900" + "'", str9.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "9-April-1900" + "'", str15.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "9-April-1900" + "'", str26.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-April-1900" + "'", str33.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "9-April-1900" + "'", str39.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 100 + "'", int47 == 100);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(class49);
        org.junit.Assert.assertNull(inputStream50);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries2.createCopy(0, 7);
        try {
            org.jfree.data.time.TimeSeries timeSeries12 = timeSeries2.createCopy(0, (-458));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Last", "", "ERROR : Relative To String", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj10 = null;
        boolean boolean11 = month9.equals(obj10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 10.0f);
        try {
            timeSeries4.add(timeSeriesDataItem13, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
        java.lang.Object obj18 = timeSeries17.clone();
        boolean boolean20 = timeSeries17.equals((java.lang.Object) "ClassContext");
        java.lang.Object obj21 = timeSeries17.clone();
        java.lang.Class class22 = timeSeries17.getTimePeriodClass();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNull(class22);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        timeSeries2.setKey((java.lang.Comparable) "ClassContext");
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date2, timeZone5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(2019);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str5 = spreadsheetDate4.toString();
        boolean boolean6 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str9 = spreadsheetDate8.toString();
        spreadsheetDate8.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str16 = spreadsheetDate15.toString();
        boolean boolean17 = spreadsheetDate13.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str22 = spreadsheetDate21.toString();
        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean24 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        int int25 = spreadsheetDate21.getDayOfMonth();
        boolean boolean26 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean27 = day0.equals((java.lang.Object) spreadsheetDate8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day0.previous();
        int int29 = day0.getYear();
        java.util.Calendar calendar30 = null;
        try {
            long long31 = day0.getMiddleMillisecond(calendar30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-April-1900" + "'", str9.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "9-April-1900" + "'", str16.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 9 + "'", int25 == 9);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj13 = null;
        boolean boolean14 = month12.equals(obj13);
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) month16);
        timeSeries6.setRangeDescription("2019");
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str30 = spreadsheetDate29.toString();
        boolean boolean31 = spreadsheetDate27.isOn((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str36 = spreadsheetDate35.toString();
        boolean boolean37 = spreadsheetDate33.isOn((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean38 = spreadsheetDate29.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str43 = spreadsheetDate42.toString();
        boolean boolean44 = spreadsheetDate40.isOn((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str47 = spreadsheetDate46.toString();
        spreadsheetDate46.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str54 = spreadsheetDate53.toString();
        boolean boolean55 = spreadsheetDate51.isOn((org.jfree.data.time.SerialDate) spreadsheetDate53);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str60 = spreadsheetDate59.toString();
        boolean boolean61 = spreadsheetDate57.isOn((org.jfree.data.time.SerialDate) spreadsheetDate59);
        boolean boolean62 = spreadsheetDate53.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate59);
        int int63 = spreadsheetDate59.getDayOfMonth();
        boolean boolean64 = spreadsheetDate40.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate46, (org.jfree.data.time.SerialDate) spreadsheetDate59);
        int int65 = spreadsheetDate35.compare((org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.jfree.data.time.SerialDate serialDate66 = spreadsheetDate24.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.addDays(100, (org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str70 = spreadsheetDate69.toString();
        spreadsheetDate69.setDescription("9-April-1900");
        int int73 = spreadsheetDate69.toSerial();
        boolean boolean74 = spreadsheetDate40.isOn((org.jfree.data.time.SerialDate) spreadsheetDate69);
        org.jfree.data.time.SerialDate serialDate76 = spreadsheetDate69.getNearestDayOfWeek(4);
        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day(serialDate76);
        long long78 = day77.getFirstMillisecond();
        try {
            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day77, (java.lang.Number) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "9-April-1900" + "'", str30.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "9-April-1900" + "'", str36.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "9-April-1900" + "'", str43.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "9-April-1900" + "'", str47.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "9-April-1900" + "'", str54.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "9-April-1900" + "'", str60.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 9 + "'", int63 == 9);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "9-April-1900" + "'", str70.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 100 + "'", int73 == 100);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(serialDate76);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + (-2200665600000L) + "'", long78 == (-2200665600000L));
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year19 = month18.getYear();
//        long long20 = year19.getSerialIndex();
//        java.lang.String str21 = year19.toString();
//        timeSeries16.setKey((java.lang.Comparable) year19);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str28 = spreadsheetDate27.toString();
//        boolean boolean29 = spreadsheetDate25.isOn((org.jfree.data.time.SerialDate) spreadsheetDate27);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str32 = spreadsheetDate31.toString();
//        spreadsheetDate31.setDescription("9-April-1900");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str39 = spreadsheetDate38.toString();
//        boolean boolean40 = spreadsheetDate36.isOn((org.jfree.data.time.SerialDate) spreadsheetDate38);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str45 = spreadsheetDate44.toString();
//        boolean boolean46 = spreadsheetDate42.isOn((org.jfree.data.time.SerialDate) spreadsheetDate44);
//        boolean boolean47 = spreadsheetDate38.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate44);
//        int int48 = spreadsheetDate44.getDayOfMonth();
//        boolean boolean49 = spreadsheetDate25.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate31, (org.jfree.data.time.SerialDate) spreadsheetDate44);
//        boolean boolean50 = day23.equals((java.lang.Object) spreadsheetDate31);
//        long long51 = day23.getLastMillisecond();
//        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year53 = month52.getYear();
//        long long54 = year53.getSerialIndex();
//        long long55 = year53.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) day23, (org.jfree.data.time.RegularTimePeriod) year53);
//        org.jfree.data.time.SerialDate serialDate57 = day23.getSerialDate();
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "9-April-1900" + "'", str28.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "9-April-1900" + "'", str39.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "9-April-1900" + "'", str45.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 9 + "'", int48 == 9);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560495599999L + "'", long51 == 1560495599999L);
//        org.junit.Assert.assertNotNull(year53);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 2019L + "'", long54 == 2019L);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1577865599999L + "'", long55 == 1577865599999L);
//        org.junit.Assert.assertNotNull(timeSeries56);
//        org.junit.Assert.assertNotNull(serialDate57);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj13 = null;
        boolean boolean14 = month12.equals(obj13);
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        long long16 = month12.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date19 = fixedMillisecond18.getTime();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        boolean boolean21 = month12.equals((java.lang.Object) day20);
        int int22 = day20.getDayOfMonth();
        int int23 = day20.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day20, (java.lang.Number) 0.0d);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 31 + "'", int22 == 31);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 12 + "'", int23 == 12);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int7 = month6.getMonth();
        java.lang.String str8 = month6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        long long10 = month6.getLastMillisecond();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year12 = month11.getYear();
        int int13 = month6.compareTo((java.lang.Object) year12);
        long long14 = month6.getSerialIndex();
        java.util.Calendar calendar15 = null;
        try {
            month6.peg(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 0" + "'", str8.equals("October 0"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62109475200001L) + "'", long10 == (-62109475200001L));
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(100);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class8);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries13.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj20 = null;
        boolean boolean21 = month19.equals(obj20);
        int int22 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) month19);
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class24);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries25.addAndOrUpdate(timeSeries28);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries29);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year32 = month31.getYear();
        int int33 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) year32);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) month19, (org.jfree.data.time.RegularTimePeriod) year32);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class36);
        java.lang.Class class39 = null;
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class39);
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries37.addAndOrUpdate(timeSeries40);
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries41.createCopy(0, (int) (short) 1);
        java.lang.String str45 = timeSeries41.getDescription();
        java.lang.String str46 = timeSeries41.getDescription();
        boolean boolean47 = timeSeries34.equals((java.lang.Object) timeSeries41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = null;
        try {
            timeSeries34.add(regularTimePeriod48, (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(year32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str5 = spreadsheetDate4.toString();
        boolean boolean6 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str9 = spreadsheetDate8.toString();
        spreadsheetDate8.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str16 = spreadsheetDate15.toString();
        boolean boolean17 = spreadsheetDate13.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str22 = spreadsheetDate21.toString();
        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean24 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        int int25 = spreadsheetDate21.getDayOfMonth();
        boolean boolean26 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean27 = day0.equals((java.lang.Object) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str32 = spreadsheetDate31.toString();
        boolean boolean33 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        boolean boolean39 = spreadsheetDate35.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str45 = spreadsheetDate44.toString();
        boolean boolean46 = spreadsheetDate42.isOn((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str49 = spreadsheetDate48.toString();
        spreadsheetDate48.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str56 = spreadsheetDate55.toString();
        boolean boolean57 = spreadsheetDate53.isOn((org.jfree.data.time.SerialDate) spreadsheetDate55);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str62 = spreadsheetDate61.toString();
        boolean boolean63 = spreadsheetDate59.isOn((org.jfree.data.time.SerialDate) spreadsheetDate61);
        boolean boolean64 = spreadsheetDate55.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate61);
        int int65 = spreadsheetDate61.getDayOfMonth();
        boolean boolean66 = spreadsheetDate42.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate48, (org.jfree.data.time.SerialDate) spreadsheetDate61);
        int int67 = spreadsheetDate37.compare((org.jfree.data.time.SerialDate) spreadsheetDate42);
        boolean boolean68 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate37);
        java.lang.Class class70 = null;
        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class70);
        java.lang.Class class72 = timeSeries71.getTimePeriodClass();
        org.jfree.data.time.Year year74 = org.jfree.data.time.Year.parseYear("2019");
        java.lang.Number number75 = timeSeries71.getValue((org.jfree.data.time.RegularTimePeriod) year74);
        try {
            int int76 = spreadsheetDate8.compareTo((java.lang.Object) timeSeries71);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimeSeries cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-April-1900" + "'", str9.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "9-April-1900" + "'", str16.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 9 + "'", int25 == 9);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "9-April-1900" + "'", str45.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "9-April-1900" + "'", str49.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "9-April-1900" + "'", str56.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "9-April-1900" + "'", str62.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 9 + "'", int65 == 9);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNull(class72);
        org.junit.Assert.assertNotNull(year74);
        org.junit.Assert.assertNull(number75);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 1.0d);
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(2147483647, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        try {
            org.jfree.data.time.TimeSeries timeSeries12 = timeSeries9.createCopy(2147483647, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
        timeSeries17.setMaximumItemCount(3);
        timeSeries17.setNotify(true);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries17);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            year1.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str17 = spreadsheetDate16.toString();
        boolean boolean18 = spreadsheetDate14.isOn((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        spreadsheetDate20.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str28 = spreadsheetDate27.toString();
        boolean boolean29 = spreadsheetDate25.isOn((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str34 = spreadsheetDate33.toString();
        boolean boolean35 = spreadsheetDate31.isOn((org.jfree.data.time.SerialDate) spreadsheetDate33);
        boolean boolean36 = spreadsheetDate27.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int37 = spreadsheetDate33.getDayOfMonth();
        boolean boolean38 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate20, (org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int39 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int40 = spreadsheetDate9.getYYYY();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "9-April-1900" + "'", str17.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "9-April-1900" + "'", str28.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "9-April-1900" + "'", str34.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 9 + "'", int37 == 9);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1900 + "'", int40 == 1900);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = year1.getSerialIndex();
        java.lang.String str3 = year1.toString();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str18 = spreadsheetDate17.toString();
        spreadsheetDate17.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        boolean boolean26 = spreadsheetDate22.isOn((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str31 = spreadsheetDate30.toString();
        boolean boolean32 = spreadsheetDate28.isOn((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean33 = spreadsheetDate24.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        int int34 = spreadsheetDate30.getDayOfMonth();
        boolean boolean35 = spreadsheetDate11.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, (org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean36 = fixedMillisecond8.equals((java.lang.Object) spreadsheetDate17);
        boolean boolean37 = day6.equals((java.lang.Object) fixedMillisecond8);
        java.lang.Class<?> wildcardClass38 = fixedMillisecond8.getClass();
        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass38);
        java.io.InputStream inputStream40 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass38);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long45 = fixedMillisecond44.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str50 = spreadsheetDate49.toString();
        boolean boolean51 = spreadsheetDate47.isOn((org.jfree.data.time.SerialDate) spreadsheetDate49);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str54 = spreadsheetDate53.toString();
        spreadsheetDate53.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str61 = spreadsheetDate60.toString();
        boolean boolean62 = spreadsheetDate58.isOn((org.jfree.data.time.SerialDate) spreadsheetDate60);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str67 = spreadsheetDate66.toString();
        boolean boolean68 = spreadsheetDate64.isOn((org.jfree.data.time.SerialDate) spreadsheetDate66);
        boolean boolean69 = spreadsheetDate60.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate66);
        int int70 = spreadsheetDate66.getDayOfMonth();
        boolean boolean71 = spreadsheetDate47.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate53, (org.jfree.data.time.SerialDate) spreadsheetDate66);
        boolean boolean72 = fixedMillisecond44.equals((java.lang.Object) spreadsheetDate53);
        boolean boolean73 = day42.equals((java.lang.Object) fixedMillisecond44);
        java.lang.Class<?> wildcardClass74 = fixedMillisecond44.getClass();
        java.io.InputStream inputStream75 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("9-April-1900", (java.lang.Class) wildcardClass74);
        java.lang.Class class76 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass74);
        java.lang.Object obj77 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("org.jfree.data.time.TimePeriodFormatException: ", (java.lang.Class) wildcardClass38, class76);
        org.jfree.data.time.TimeSeries timeSeries78 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year1, class76);
        java.lang.String str79 = timeSeries78.getDescription();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "9-April-1900" + "'", str18.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "9-April-1900" + "'", str31.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 9 + "'", int34 == 9);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertNotNull(inputStream40);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "9-April-1900" + "'", str50.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "9-April-1900" + "'", str54.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "9-April-1900" + "'", str61.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "9-April-1900" + "'", str67.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 9 + "'", int70 == 9);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(wildcardClass74);
        org.junit.Assert.assertNull(inputStream75);
        org.junit.Assert.assertNotNull(class76);
        org.junit.Assert.assertNull(obj77);
        org.junit.Assert.assertNull(str79);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "January" + "'", str1.equals("January"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year2 = month1.getYear();
        long long3 = year2.getSerialIndex();
        java.lang.String str4 = year2.toString();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long10 = fixedMillisecond9.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str15 = spreadsheetDate14.toString();
        boolean boolean16 = spreadsheetDate12.isOn((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str19 = spreadsheetDate18.toString();
        spreadsheetDate18.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str26 = spreadsheetDate25.toString();
        boolean boolean27 = spreadsheetDate23.isOn((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str32 = spreadsheetDate31.toString();
        boolean boolean33 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean34 = spreadsheetDate25.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        int int35 = spreadsheetDate31.getDayOfMonth();
        boolean boolean36 = spreadsheetDate12.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate18, (org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean37 = fixedMillisecond9.equals((java.lang.Object) spreadsheetDate18);
        boolean boolean38 = day7.equals((java.lang.Object) fixedMillisecond9);
        java.lang.Class<?> wildcardClass39 = fixedMillisecond9.getClass();
        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
        java.io.InputStream inputStream41 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass39);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long46 = fixedMillisecond45.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str51 = spreadsheetDate50.toString();
        boolean boolean52 = spreadsheetDate48.isOn((org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str55 = spreadsheetDate54.toString();
        spreadsheetDate54.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str62 = spreadsheetDate61.toString();
        boolean boolean63 = spreadsheetDate59.isOn((org.jfree.data.time.SerialDate) spreadsheetDate61);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str68 = spreadsheetDate67.toString();
        boolean boolean69 = spreadsheetDate65.isOn((org.jfree.data.time.SerialDate) spreadsheetDate67);
        boolean boolean70 = spreadsheetDate61.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate67);
        int int71 = spreadsheetDate67.getDayOfMonth();
        boolean boolean72 = spreadsheetDate48.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate54, (org.jfree.data.time.SerialDate) spreadsheetDate67);
        boolean boolean73 = fixedMillisecond45.equals((java.lang.Object) spreadsheetDate54);
        boolean boolean74 = day43.equals((java.lang.Object) fixedMillisecond45);
        java.lang.Class<?> wildcardClass75 = fixedMillisecond45.getClass();
        java.io.InputStream inputStream76 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("9-April-1900", (java.lang.Class) wildcardClass75);
        java.lang.Class class77 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass75);
        java.lang.Object obj78 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("org.jfree.data.time.TimePeriodFormatException: ", (java.lang.Class) wildcardClass39, class77);
        org.jfree.data.time.TimeSeries timeSeries79 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year2, class77);
        java.io.InputStream inputStream80 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("April", class77);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "9-April-1900" + "'", str15.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-April-1900" + "'", str19.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "9-April-1900" + "'", str26.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 9 + "'", int35 == 9);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(class40);
        org.junit.Assert.assertNotNull(inputStream41);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "9-April-1900" + "'", str51.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "9-April-1900" + "'", str55.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "9-April-1900" + "'", str62.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "9-April-1900" + "'", str68.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 9 + "'", int71 == 9);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(wildcardClass75);
        org.junit.Assert.assertNull(inputStream76);
        org.junit.Assert.assertNotNull(class77);
        org.junit.Assert.assertNull(obj78);
        org.junit.Assert.assertNull(inputStream80);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(9, (-457));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str3 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        boolean boolean9 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        spreadsheetDate24.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str32 = spreadsheetDate31.toString();
        boolean boolean33 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        boolean boolean39 = spreadsheetDate35.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int41 = spreadsheetDate37.getDayOfMonth();
        boolean boolean42 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int43 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays(100, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str48 = spreadsheetDate47.toString();
        spreadsheetDate47.setDescription("9-April-1900");
        int int51 = spreadsheetDate47.toSerial();
        boolean boolean52 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SerialDate serialDate54 = spreadsheetDate47.getNearestDayOfWeek(4);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(serialDate54);
        long long56 = day55.getFirstMillisecond();
        java.lang.String str57 = day55.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9 + "'", int41 == 9);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "9-April-1900" + "'", str48.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 100 + "'", int51 == 100);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-2200665600000L) + "'", long56 == (-2200665600000L));
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "7-April-1900" + "'", str57.equals("7-April-1900"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        boolean boolean7 = timeSeries2.getNotify();
        int int8 = timeSeries2.getMaximumItemCount();
        java.lang.Class class9 = timeSeries2.getTimePeriodClass();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertNull(class9);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getLastMillisecond();
        long long5 = year3.getFirstMillisecond();
        long long6 = year3.getSerialIndex();
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 1.0d);
        java.lang.String str6 = month2.toString();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int7 = month6.getMonth();
        java.lang.String str8 = month6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = month6.getMiddleMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 0" + "'", str8.equals("October 0"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str5 = spreadsheetDate4.toString();
//        boolean boolean6 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str9 = spreadsheetDate8.toString();
//        spreadsheetDate8.setDescription("9-April-1900");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str16 = spreadsheetDate15.toString();
//        boolean boolean17 = spreadsheetDate13.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str22 = spreadsheetDate21.toString();
//        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        boolean boolean24 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        int int25 = spreadsheetDate21.getDayOfMonth();
//        boolean boolean26 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate21);
//        boolean boolean27 = day0.equals((java.lang.Object) spreadsheetDate8);
//        long long28 = day0.getLastMillisecond();
//        java.util.Date date29 = day0.getStart();
//        java.util.Calendar calendar30 = null;
//        try {
//            day0.peg(calendar30);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-April-1900" + "'", str9.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "9-April-1900" + "'", str16.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 9 + "'", int25 == 9);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560495599999L + "'", long28 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date29);
//    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.String str10 = timeSeries6.getDescription();
        timeSeries6.setRangeDescription("Last");
        int int13 = timeSeries6.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener14);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class17);
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class20);
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries18.addAndOrUpdate(timeSeries21);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries22.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj29 = null;
        boolean boolean30 = month28.equals(obj29);
        int int31 = timeSeries22.getIndex((org.jfree.data.time.RegularTimePeriod) month28);
        long long32 = month28.getSerialIndex();
        try {
            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) month28, 0.0d, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date2, timeZone5);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date2, timeZone7);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class10);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class13);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries11.addAndOrUpdate(timeSeries14);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries15.createCopy(0, (int) (short) 1);
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class20);
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class23);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries21.addAndOrUpdate(timeSeries24);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries18.addAndOrUpdate(timeSeries25);
        int int27 = timeSeries18.getItemCount();
        java.util.List list28 = timeSeries18.getItems();
        int int29 = year8.compareTo((java.lang.Object) list28);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries2.createCopy(0, 7);
        java.lang.String str10 = timeSeries9.getDescription();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) -1, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year19 = month18.getYear();
//        long long20 = year19.getSerialIndex();
//        java.lang.String str21 = year19.toString();
//        timeSeries16.setKey((java.lang.Comparable) year19);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str28 = spreadsheetDate27.toString();
//        boolean boolean29 = spreadsheetDate25.isOn((org.jfree.data.time.SerialDate) spreadsheetDate27);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str32 = spreadsheetDate31.toString();
//        spreadsheetDate31.setDescription("9-April-1900");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str39 = spreadsheetDate38.toString();
//        boolean boolean40 = spreadsheetDate36.isOn((org.jfree.data.time.SerialDate) spreadsheetDate38);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str45 = spreadsheetDate44.toString();
//        boolean boolean46 = spreadsheetDate42.isOn((org.jfree.data.time.SerialDate) spreadsheetDate44);
//        boolean boolean47 = spreadsheetDate38.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate44);
//        int int48 = spreadsheetDate44.getDayOfMonth();
//        boolean boolean49 = spreadsheetDate25.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate31, (org.jfree.data.time.SerialDate) spreadsheetDate44);
//        boolean boolean50 = day23.equals((java.lang.Object) spreadsheetDate31);
//        long long51 = day23.getLastMillisecond();
//        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year53 = month52.getYear();
//        long long54 = year53.getSerialIndex();
//        long long55 = year53.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) day23, (org.jfree.data.time.RegularTimePeriod) year53);
//        timeSeries16.fireSeriesChanged();
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "9-April-1900" + "'", str28.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "9-April-1900" + "'", str39.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "9-April-1900" + "'", str45.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 9 + "'", int48 == 9);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560495599999L + "'", long51 == 1560495599999L);
//        org.junit.Assert.assertNotNull(year53);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 2019L + "'", long54 == 2019L);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1577865599999L + "'", long55 == 1577865599999L);
//        org.junit.Assert.assertNotNull(timeSeries56);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        boolean boolean7 = timeSeries2.getNotify();
        int int8 = timeSeries2.getMaximumItemCount();
        java.lang.String str9 = timeSeries2.getDescription();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries2.addOrUpdate(regularTimePeriod12, (java.lang.Number) (-458));
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int13 = spreadsheetDate9.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str16 = spreadsheetDate15.toString();
        boolean boolean17 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        int int18 = spreadsheetDate9.getDayOfMonth();
        int int19 = spreadsheetDate9.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "9-April-1900" + "'", str16.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        java.util.Date date5 = month4.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (double) 1560439126358L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 1.0d);
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class7);
        int int9 = timeSeries8.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries8.removeChangeListener(seriesChangeListener10);
        java.util.Collection collection12 = timeSeries8.getTimePeriods();
        int int13 = timeSeriesDataItem5.compareTo((java.lang.Object) timeSeries8);
        timeSeriesDataItem5.setValue((java.lang.Number) 10L);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str20 = spreadsheetDate19.toString();
        boolean boolean21 = spreadsheetDate17.isOn((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str24 = spreadsheetDate23.toString();
        spreadsheetDate23.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str31 = spreadsheetDate30.toString();
        boolean boolean32 = spreadsheetDate28.isOn((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str37 = spreadsheetDate36.toString();
        boolean boolean38 = spreadsheetDate34.isOn((org.jfree.data.time.SerialDate) spreadsheetDate36);
        boolean boolean39 = spreadsheetDate30.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate36);
        int int40 = spreadsheetDate36.getDayOfMonth();
        boolean boolean41 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, (org.jfree.data.time.SerialDate) spreadsheetDate36);
        int int42 = spreadsheetDate36.getYYYY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long45 = fixedMillisecond44.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str50 = spreadsheetDate49.toString();
        boolean boolean51 = spreadsheetDate47.isOn((org.jfree.data.time.SerialDate) spreadsheetDate49);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str54 = spreadsheetDate53.toString();
        spreadsheetDate53.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str61 = spreadsheetDate60.toString();
        boolean boolean62 = spreadsheetDate58.isOn((org.jfree.data.time.SerialDate) spreadsheetDate60);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str67 = spreadsheetDate66.toString();
        boolean boolean68 = spreadsheetDate64.isOn((org.jfree.data.time.SerialDate) spreadsheetDate66);
        boolean boolean69 = spreadsheetDate60.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate66);
        int int70 = spreadsheetDate66.getDayOfMonth();
        boolean boolean71 = spreadsheetDate47.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate53, (org.jfree.data.time.SerialDate) spreadsheetDate66);
        boolean boolean72 = fixedMillisecond44.equals((java.lang.Object) spreadsheetDate53);
        boolean boolean73 = spreadsheetDate36.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate53);
        int int74 = timeSeriesDataItem5.compareTo((java.lang.Object) spreadsheetDate53);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "9-April-1900" + "'", str20.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "9-April-1900" + "'", str24.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "9-April-1900" + "'", str31.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "9-April-1900" + "'", str37.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 9 + "'", int40 == 9);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1900 + "'", int42 == 1900);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "9-April-1900" + "'", str50.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "9-April-1900" + "'", str54.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "9-April-1900" + "'", str61.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "9-April-1900" + "'", str67.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 9 + "'", int70 == 9);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year2 = month1.getYear();
        long long3 = year2.getSerialIndex();
        java.lang.Class<?> wildcardClass4 = year2.getClass();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.previous();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str2 = spreadsheetDate1.toString();
        spreadsheetDate1.setDescription("9-April-1900");
        int int5 = spreadsheetDate1.getDayOfMonth();
        int int6 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "9-April-1900" + "'", str2.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str5 = spreadsheetDate4.toString();
//        boolean boolean6 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str9 = spreadsheetDate8.toString();
//        spreadsheetDate8.setDescription("9-April-1900");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str16 = spreadsheetDate15.toString();
//        boolean boolean17 = spreadsheetDate13.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str22 = spreadsheetDate21.toString();
//        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        boolean boolean24 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        int int25 = spreadsheetDate21.getDayOfMonth();
//        boolean boolean26 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate21);
//        boolean boolean27 = day0.equals((java.lang.Object) spreadsheetDate8);
//        long long28 = day0.getSerialIndex();
//        long long29 = day0.getSerialIndex();
//        int int30 = day0.getMonth();
//        int int31 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-April-1900" + "'", str9.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "9-April-1900" + "'", str16.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 9 + "'", int25 == 9);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 43629L + "'", long28 == 43629L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 43629L + "'", long29 == 43629L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 13 + "'", int31 == 13);
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj13 = null;
        boolean boolean14 = month12.equals(obj13);
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        long long16 = month12.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date19 = fixedMillisecond18.getTime();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        boolean boolean21 = month12.equals((java.lang.Object) day20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day20, 0.0d);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long26 = fixedMillisecond25.getMiddleMillisecond();
        long long27 = fixedMillisecond25.getFirstMillisecond();
        long long28 = fixedMillisecond25.getLastMillisecond();
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond25.getMiddleMillisecond(calendar29);
        int int31 = timeSeriesDataItem23.compareTo((java.lang.Object) calendar29);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 100L + "'", long28 == 100L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        spreadsheetDate7.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str15 = spreadsheetDate14.toString();
        boolean boolean16 = spreadsheetDate12.isOn((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean23 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int24 = spreadsheetDate20.getDayOfMonth();
        boolean boolean25 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, (org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean25, class26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = null;
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        try {
            org.jfree.data.time.TimeSeries timeSeries30 = timeSeries27.createCopy(regularTimePeriod28, (org.jfree.data.time.RegularTimePeriod) day29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "9-April-1900" + "'", str15.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 9 + "'", int24 == 9);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        long long4 = fixedMillisecond1.getLastMillisecond();
        long long5 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.util.Date date0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date3 = fixedMillisecond2.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date3, timeZone6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date3, timeZone8);
        try {
            org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date0, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(timeZone8);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("April");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Last", "", "ERROR : Relative To String", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class8);
        timeSeries9.setDomainDescription("October 0");
        java.lang.Object obj12 = timeSeries9.clone();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries9);
        java.lang.Object obj14 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) timeSeries13);
        timeSeries13.setMaximumItemCount(2147483647);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries13.getDataItem((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date2, timeZone5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date9);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date9, timeZone12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date2, timeZone12);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long5 = fixedMillisecond4.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        spreadsheetDate13.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str27 = spreadsheetDate26.toString();
        boolean boolean28 = spreadsheetDate24.isOn((org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean29 = spreadsheetDate20.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        int int30 = spreadsheetDate26.getDayOfMonth();
        boolean boolean31 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean32 = fixedMillisecond4.equals((java.lang.Object) spreadsheetDate13);
        boolean boolean33 = day2.equals((java.lang.Object) fixedMillisecond4);
        java.lang.Class<?> wildcardClass34 = fixedMillisecond4.getClass();
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
        java.net.URL uRL36 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass34);
        java.lang.ClassLoader classLoader37 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass34);
        java.net.URL uRL38 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("October 0", (java.lang.Class) wildcardClass34);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "9-April-1900" + "'", str27.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertNull(uRL36);
        org.junit.Assert.assertNotNull(classLoader37);
        org.junit.Assert.assertNull(uRL38);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str3 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        boolean boolean9 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        spreadsheetDate24.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str32 = spreadsheetDate31.toString();
        boolean boolean33 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        boolean boolean39 = spreadsheetDate35.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int41 = spreadsheetDate37.getDayOfMonth();
        boolean boolean42 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int43 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addMonths(2, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str48 = spreadsheetDate47.toString();
        spreadsheetDate47.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str54 = spreadsheetDate53.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str59 = spreadsheetDate58.toString();
        boolean boolean60 = spreadsheetDate56.isOn((org.jfree.data.time.SerialDate) spreadsheetDate58);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str65 = spreadsheetDate64.toString();
        boolean boolean66 = spreadsheetDate62.isOn((org.jfree.data.time.SerialDate) spreadsheetDate64);
        boolean boolean67 = spreadsheetDate58.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate64);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str72 = spreadsheetDate71.toString();
        boolean boolean73 = spreadsheetDate69.isOn((org.jfree.data.time.SerialDate) spreadsheetDate71);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str76 = spreadsheetDate75.toString();
        spreadsheetDate75.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate80 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate82 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str83 = spreadsheetDate82.toString();
        boolean boolean84 = spreadsheetDate80.isOn((org.jfree.data.time.SerialDate) spreadsheetDate82);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate86 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate88 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str89 = spreadsheetDate88.toString();
        boolean boolean90 = spreadsheetDate86.isOn((org.jfree.data.time.SerialDate) spreadsheetDate88);
        boolean boolean91 = spreadsheetDate82.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate88);
        int int92 = spreadsheetDate88.getDayOfMonth();
        boolean boolean93 = spreadsheetDate69.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate75, (org.jfree.data.time.SerialDate) spreadsheetDate88);
        int int94 = spreadsheetDate64.compare((org.jfree.data.time.SerialDate) spreadsheetDate69);
        org.jfree.data.time.SerialDate serialDate95 = spreadsheetDate53.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate69);
        org.jfree.data.time.SerialDate serialDate96 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate69);
        boolean boolean97 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate47, serialDate96);
        java.lang.String str98 = spreadsheetDate47.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9 + "'", int41 == 9);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "9-April-1900" + "'", str48.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "9-April-1900" + "'", str54.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "9-April-1900" + "'", str59.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "9-April-1900" + "'", str65.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "9-April-1900" + "'", str72.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "9-April-1900" + "'", str76.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "9-April-1900" + "'", str83.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "9-April-1900" + "'", str89.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 9 + "'", int92 == 9);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 0 + "'", int94 == 0);
        org.junit.Assert.assertNotNull(serialDate95);
        org.junit.Assert.assertNotNull(serialDate96);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
        org.junit.Assert.assertTrue("'" + str98 + "' != '" + "9-April-1900" + "'", str98.equals("9-April-1900"));
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str5 = spreadsheetDate4.toString();
//        boolean boolean6 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str9 = spreadsheetDate8.toString();
//        spreadsheetDate8.setDescription("9-April-1900");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str16 = spreadsheetDate15.toString();
//        boolean boolean17 = spreadsheetDate13.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str22 = spreadsheetDate21.toString();
//        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        boolean boolean24 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        int int25 = spreadsheetDate21.getDayOfMonth();
//        boolean boolean26 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate21);
//        boolean boolean27 = day0.equals((java.lang.Object) spreadsheetDate8);
//        long long28 = day0.getLastMillisecond();
//        java.lang.String str29 = day0.toString();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-April-1900" + "'", str9.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "9-April-1900" + "'", str16.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 9 + "'", int25 == 9);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560495599999L + "'", long28 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "13-June-2019" + "'", str29.equals("13-June-2019"));
//    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        java.lang.String str5 = seriesException4.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("9-April-1900");
        java.lang.String str9 = seriesException8.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str5.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesException: 9-April-1900" + "'", str9.equals("org.jfree.data.general.SeriesException: 9-April-1900"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((-457), (int) (short) -1, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        boolean boolean7 = timeSeries2.getNotify();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str13 = spreadsheetDate12.toString();
        boolean boolean14 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str17 = spreadsheetDate16.toString();
        spreadsheetDate16.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str24 = spreadsheetDate23.toString();
        boolean boolean25 = spreadsheetDate21.isOn((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str30 = spreadsheetDate29.toString();
        boolean boolean31 = spreadsheetDate27.isOn((org.jfree.data.time.SerialDate) spreadsheetDate29);
        boolean boolean32 = spreadsheetDate23.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        int int33 = spreadsheetDate29.getDayOfMonth();
        boolean boolean34 = spreadsheetDate10.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate16, (org.jfree.data.time.SerialDate) spreadsheetDate29);
        boolean boolean35 = day8.equals((java.lang.Object) spreadsheetDate16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day8.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long39 = fixedMillisecond38.getMiddleMillisecond();
        long long40 = fixedMillisecond38.getFirstMillisecond();
        long long41 = fixedMillisecond38.getLastMillisecond();
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond38.getMiddleMillisecond(calendar42);
        java.util.Date date44 = fixedMillisecond38.getTime();
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(date44);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(date44);
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries2.createCopy(regularTimePeriod36, (org.jfree.data.time.RegularTimePeriod) month46);
        java.lang.Class class49 = null;
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class49);
        java.lang.Class class52 = null;
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class52);
        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries50.addAndOrUpdate(timeSeries53);
        int int55 = timeSeries54.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long58 = fixedMillisecond57.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = fixedMillisecond57.previous();
        java.util.Calendar calendar60 = null;
        long long61 = fixedMillisecond57.getLastMillisecond(calendar60);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries54.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57, (double) 11);
        java.lang.Class class65 = null;
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class65);
        java.lang.Class class68 = null;
        org.jfree.data.time.TimeSeries timeSeries69 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class68);
        org.jfree.data.time.TimeSeries timeSeries70 = timeSeries66.addAndOrUpdate(timeSeries69);
        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries70.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month76 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj77 = null;
        boolean boolean78 = month76.equals(obj77);
        int int79 = timeSeries70.getIndex((org.jfree.data.time.RegularTimePeriod) month76);
        long long80 = month76.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond82 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date83 = fixedMillisecond82.getTime();
        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day(date83);
        boolean boolean85 = month76.equals((java.lang.Object) day84);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem87 = timeSeries54.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day84, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = day84.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) day84);
        timeSeries2.removeAgedItems(true);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "9-April-1900" + "'", str13.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "9-April-1900" + "'", str17.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "9-April-1900" + "'", str24.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "9-April-1900" + "'", str30.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 9 + "'", int33 == 9);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 100L + "'", long39 == 100L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 100L + "'", long40 == 100L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 100L + "'", long41 == 100L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 100L + "'", long43 == 100L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(timeSeries47);
        org.junit.Assert.assertNotNull(timeSeries54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 100L + "'", long58 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 100L + "'", long61 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem63);
        org.junit.Assert.assertNotNull(timeSeries70);
        org.junit.Assert.assertNotNull(timeSeries73);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 10L + "'", long80 == 10L);
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem87);
        org.junit.Assert.assertNotNull(regularTimePeriod88);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2958465);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str2.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (97) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year9 = month8.getYear();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year9);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class12);
        boolean boolean14 = timeSeries13.getNotify();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int18 = month17.getMonth();
        java.lang.String str19 = month17.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        long long21 = month17.getLastMillisecond();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year23 = month22.getYear();
        int int24 = month17.compareTo((java.lang.Object) year23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 24234L);
        try {
            org.jfree.data.time.TimeSeries timeSeries29 = timeSeries6.createCopy(11, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "October 0" + "'", str19.equals("October 0"));
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62109475200001L) + "'", long21 == (-62109475200001L));
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year8 = month7.getYear();
        long long9 = year8.getSerialIndex();
        long long10 = year8.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year8);
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) (-31507200000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        boolean boolean7 = timeSeries2.getNotify();
        int int8 = timeSeries2.getMaximumItemCount();
        java.lang.String str9 = timeSeries2.getDescription();
        int int10 = timeSeries2.getMaximumItemCount();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class12);
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries13.addAndOrUpdate(timeSeries16);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries17.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj24 = null;
        boolean boolean25 = month23.equals(obj24);
        int int26 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) month27);
        timeSeries17.setNotify(true);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int34 = month33.getMonth();
        java.lang.String str35 = month33.toString();
        java.lang.String str36 = month33.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month33, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month33, (double) 100L);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "October 0" + "'", str35.equals("October 0"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "October 0" + "'", str36.equals("October 0"));
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        boolean boolean7 = timeSeries2.getNotify();
        int int8 = timeSeries2.getMaximumItemCount();
        java.lang.String str9 = timeSeries2.getDescription();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries2.createCopy(0, (int) (short) 0);
        try {
            timeSeries2.removeAgedItems((long) 30, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(timeSeries12);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj13 = null;
        boolean boolean14 = month12.equals(obj13);
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        long long16 = month12.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date19 = fixedMillisecond18.getTime();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        boolean boolean21 = month12.equals((java.lang.Object) day20);
        java.lang.Object obj22 = null;
        boolean boolean23 = day20.equals(obj22);
        java.util.Calendar calendar24 = null;
        try {
            long long25 = day20.getLastMillisecond(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj3 = null;
        boolean boolean4 = month2.equals(obj3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.previous();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(9);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "September" + "'", str1.equals("September"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
        timeSeries17.clear();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year20 = month19.getYear();
        long long21 = year20.getSerialIndex();
        long long22 = year20.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year20, (double) '4');
        try {
            timeSeries17.add(timeSeriesDataItem24, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        timeSeries2.setDomainDescription("October 0");
        timeSeries2.setMaximumItemAge(10L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date9);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date9, timeZone12);
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 1560409200000L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(12, 0, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries6);
        try {
            timeSeries6.delete(6, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("ClassContext");
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
        int int18 = timeSeries9.getItemCount();
        boolean boolean19 = timeSeries9.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener20);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(7, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        boolean boolean7 = timeSeries2.getNotify();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str13 = spreadsheetDate12.toString();
        boolean boolean14 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str17 = spreadsheetDate16.toString();
        spreadsheetDate16.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str24 = spreadsheetDate23.toString();
        boolean boolean25 = spreadsheetDate21.isOn((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str30 = spreadsheetDate29.toString();
        boolean boolean31 = spreadsheetDate27.isOn((org.jfree.data.time.SerialDate) spreadsheetDate29);
        boolean boolean32 = spreadsheetDate23.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        int int33 = spreadsheetDate29.getDayOfMonth();
        boolean boolean34 = spreadsheetDate10.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate16, (org.jfree.data.time.SerialDate) spreadsheetDate29);
        boolean boolean35 = day8.equals((java.lang.Object) spreadsheetDate16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day8.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long39 = fixedMillisecond38.getMiddleMillisecond();
        long long40 = fixedMillisecond38.getFirstMillisecond();
        long long41 = fixedMillisecond38.getLastMillisecond();
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond38.getMiddleMillisecond(calendar42);
        java.util.Date date44 = fixedMillisecond38.getTime();
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(date44);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(date44);
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries2.createCopy(regularTimePeriod36, (org.jfree.data.time.RegularTimePeriod) month46);
        java.beans.PropertyChangeListener propertyChangeListener48 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener48);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "9-April-1900" + "'", str13.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "9-April-1900" + "'", str17.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "9-April-1900" + "'", str24.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "9-April-1900" + "'", str30.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 9 + "'", int33 == 9);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 100L + "'", long39 == 100L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 100L + "'", long40 == 100L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 100L + "'", long41 == 100L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 100L + "'", long43 == 100L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(timeSeries47);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        java.util.Date date5 = month4.getEnd();
        int int6 = month4.getMonth();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str3 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        boolean boolean9 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        spreadsheetDate24.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str32 = spreadsheetDate31.toString();
        boolean boolean33 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        boolean boolean39 = spreadsheetDate35.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int41 = spreadsheetDate37.getDayOfMonth();
        boolean boolean42 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int43 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays(100, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        int int46 = spreadsheetDate18.toSerial();
        java.lang.Class<?> wildcardClass47 = spreadsheetDate18.getClass();
        int int48 = spreadsheetDate18.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9 + "'", int41 == 9);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 100 + "'", int46 == 100);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 9 + "'", int48 == 9);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int7 = month6.getMonth();
        java.lang.String str8 = month6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries16.createCopy(0, (int) (short) 1);
        java.lang.String str20 = timeSeries16.getDescription();
        timeSeries16.setRangeDescription("Last");
        java.util.Collection collection23 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        try {
            java.lang.Number number25 = timeSeries16.getValue((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 0" + "'", str8.equals("October 0"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(collection23);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
        java.lang.Object obj18 = timeSeries17.clone();
        boolean boolean20 = timeSeries17.equals((java.lang.Object) "ClassContext");
        java.lang.Object obj21 = timeSeries17.clone();
        int int22 = timeSeries17.getItemCount();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 2958465);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.String str3 = seriesChangeEvent1.toString();
        java.lang.String str4 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 2958465 + "'", obj2.equals(2958465));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2958465]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=2958465]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2958465]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=2958465]"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Last", "", "ERROR : Relative To String", class3);
        try {
            java.lang.Number number6 = timeSeries4.getValue(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str5 = spreadsheetDate4.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str16 = spreadsheetDate15.toString();
        boolean boolean17 = spreadsheetDate13.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str23 = spreadsheetDate22.toString();
        boolean boolean24 = spreadsheetDate20.isOn((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str27 = spreadsheetDate26.toString();
        spreadsheetDate26.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str34 = spreadsheetDate33.toString();
        boolean boolean35 = spreadsheetDate31.isOn((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str40 = spreadsheetDate39.toString();
        boolean boolean41 = spreadsheetDate37.isOn((org.jfree.data.time.SerialDate) spreadsheetDate39);
        boolean boolean42 = spreadsheetDate33.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate39);
        int int43 = spreadsheetDate39.getDayOfMonth();
        boolean boolean44 = spreadsheetDate20.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate26, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        int int45 = spreadsheetDate15.compare((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SerialDate serialDate46 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addDays(100, (org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int48 = spreadsheetDate20.toSerial();
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int50 = year1.compareTo((java.lang.Object) day49);
        java.util.Calendar calendar51 = null;
        try {
            long long52 = day49.getLastMillisecond(calendar51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "9-April-1900" + "'", str16.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "9-April-1900" + "'", str23.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "9-April-1900" + "'", str27.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "9-April-1900" + "'", str34.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "9-April-1900" + "'", str40.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 9 + "'", int43 == 9);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 100 + "'", int48 == 100);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj13 = null;
        boolean boolean14 = month12.equals(obj13);
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) month16);
        timeSeries6.setNotify(true);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year21 = month20.getYear();
        long long22 = year21.getSerialIndex();
        java.lang.String str23 = year21.toString();
        int int24 = year21.getYear();
        long long25 = year21.getMiddleMillisecond();
        try {
            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) year21, (java.lang.Number) 13, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1562097599999L + "'", long25 == 1562097599999L);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str2 = spreadsheetDate1.toString();
        spreadsheetDate1.setDescription("9-April-1900");
        org.jfree.data.time.SerialDate serialDate5 = null;
        try {
            boolean boolean6 = spreadsheetDate1.isBefore(serialDate5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "9-April-1900" + "'", str2.equals("9-April-1900"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("org.jfree.data.time.TimePeriodFormatException: ");
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        try {
            timeSeries6.update((org.jfree.data.time.RegularTimePeriod) day8, (java.lang.Number) 1577865599999L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str2 = spreadsheetDate1.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str7 = spreadsheetDate6.toString();
        boolean boolean8 = spreadsheetDate4.isOn((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str13 = spreadsheetDate12.toString();
        boolean boolean14 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean15 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str20 = spreadsheetDate19.toString();
        boolean boolean21 = spreadsheetDate17.isOn((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str24 = spreadsheetDate23.toString();
        spreadsheetDate23.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str31 = spreadsheetDate30.toString();
        boolean boolean32 = spreadsheetDate28.isOn((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str37 = spreadsheetDate36.toString();
        boolean boolean38 = spreadsheetDate34.isOn((org.jfree.data.time.SerialDate) spreadsheetDate36);
        boolean boolean39 = spreadsheetDate30.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate36);
        int int40 = spreadsheetDate36.getDayOfMonth();
        boolean boolean41 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, (org.jfree.data.time.SerialDate) spreadsheetDate36);
        int int42 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SerialDate serialDate43 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str44 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str47 = spreadsheetDate46.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str52 = spreadsheetDate51.toString();
        boolean boolean53 = spreadsheetDate49.isOn((org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str58 = spreadsheetDate57.toString();
        boolean boolean59 = spreadsheetDate55.isOn((org.jfree.data.time.SerialDate) spreadsheetDate57);
        boolean boolean60 = spreadsheetDate51.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str65 = spreadsheetDate64.toString();
        boolean boolean66 = spreadsheetDate62.isOn((org.jfree.data.time.SerialDate) spreadsheetDate64);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str69 = spreadsheetDate68.toString();
        spreadsheetDate68.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate73 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str76 = spreadsheetDate75.toString();
        boolean boolean77 = spreadsheetDate73.isOn((org.jfree.data.time.SerialDate) spreadsheetDate75);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate79 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate81 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str82 = spreadsheetDate81.toString();
        boolean boolean83 = spreadsheetDate79.isOn((org.jfree.data.time.SerialDate) spreadsheetDate81);
        boolean boolean84 = spreadsheetDate75.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate81);
        int int85 = spreadsheetDate81.getDayOfMonth();
        boolean boolean86 = spreadsheetDate62.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate68, (org.jfree.data.time.SerialDate) spreadsheetDate81);
        int int87 = spreadsheetDate57.compare((org.jfree.data.time.SerialDate) spreadsheetDate62);
        org.jfree.data.time.SerialDate serialDate88 = spreadsheetDate46.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate62);
        java.lang.String str89 = spreadsheetDate46.getDescription();
        org.jfree.data.time.SerialDate serialDate90 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "9-April-1900" + "'", str2.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9-April-1900" + "'", str7.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "9-April-1900" + "'", str13.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "9-April-1900" + "'", str20.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "9-April-1900" + "'", str24.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "9-April-1900" + "'", str31.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "9-April-1900" + "'", str37.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 9 + "'", int40 == 9);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "9-April-1900" + "'", str47.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "9-April-1900" + "'", str52.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "9-April-1900" + "'", str58.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "9-April-1900" + "'", str65.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "9-April-1900" + "'", str69.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "9-April-1900" + "'", str76.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "9-April-1900" + "'", str82.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 9 + "'", int85 == 9);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertNotNull(serialDate88);
        org.junit.Assert.assertNull(str89);
        org.junit.Assert.assertNotNull(serialDate90);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("hi!");
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long3 = fixedMillisecond2.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        boolean boolean9 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str12 = spreadsheetDate11.toString();
        spreadsheetDate11.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str19 = spreadsheetDate18.toString();
        boolean boolean20 = spreadsheetDate16.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        boolean boolean26 = spreadsheetDate22.isOn((org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean27 = spreadsheetDate18.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate24);
        int int28 = spreadsheetDate24.getDayOfMonth();
        boolean boolean29 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, (org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean30 = fixedMillisecond2.equals((java.lang.Object) spreadsheetDate11);
        boolean boolean31 = day0.equals((java.lang.Object) fixedMillisecond2);
        long long32 = fixedMillisecond2.getFirstMillisecond();
        java.util.Date date33 = fixedMillisecond2.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = fixedMillisecond2.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-April-1900" + "'", str12.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-April-1900" + "'", str19.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 9 + "'", int28 == 9);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 100L + "'", long32 == 100L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int3 = month2.getMonth();
        java.util.Calendar calendar4 = null;
        try {
            month2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 2958465);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.String str3 = seriesChangeEvent1.toString();
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 2958465 + "'", obj2.equals(2958465));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2958465]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=2958465]"));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + 2958465 + "'", obj4.equals(2958465));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long6 = fixedMillisecond5.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str11 = spreadsheetDate10.toString();
        boolean boolean12 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str15 = spreadsheetDate14.toString();
        spreadsheetDate14.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str22 = spreadsheetDate21.toString();
        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str28 = spreadsheetDate27.toString();
        boolean boolean29 = spreadsheetDate25.isOn((org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean30 = spreadsheetDate21.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        int int31 = spreadsheetDate27.getDayOfMonth();
        boolean boolean32 = spreadsheetDate8.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate14, (org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean33 = fixedMillisecond5.equals((java.lang.Object) spreadsheetDate14);
        boolean boolean34 = day3.equals((java.lang.Object) fixedMillisecond5);
        java.lang.Class<?> wildcardClass35 = fixedMillisecond5.getClass();
        java.io.InputStream inputStream36 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("9-April-1900", (java.lang.Class) wildcardClass35);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, (java.lang.Class) wildcardClass35);
        long long38 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-April-1900" + "'", str11.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "9-April-1900" + "'", str15.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "9-April-1900" + "'", str28.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 9 + "'", int31 == 9);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNull(inputStream36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj13 = null;
        boolean boolean14 = month12.equals(obj13);
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) month16);
        long long18 = month16.getFirstMillisecond();
        java.lang.Object obj19 = null;
        boolean boolean20 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month16, obj19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month16.next();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1559372400000L + "'", long18 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 6);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long6 = fixedMillisecond5.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str11 = spreadsheetDate10.toString();
        boolean boolean12 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str15 = spreadsheetDate14.toString();
        spreadsheetDate14.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str22 = spreadsheetDate21.toString();
        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str28 = spreadsheetDate27.toString();
        boolean boolean29 = spreadsheetDate25.isOn((org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean30 = spreadsheetDate21.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        int int31 = spreadsheetDate27.getDayOfMonth();
        boolean boolean32 = spreadsheetDate8.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate14, (org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean33 = fixedMillisecond5.equals((java.lang.Object) spreadsheetDate14);
        boolean boolean34 = day3.equals((java.lang.Object) fixedMillisecond5);
        java.lang.Class<?> wildcardClass35 = fixedMillisecond5.getClass();
        java.io.InputStream inputStream36 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("9-April-1900", (java.lang.Class) wildcardClass35);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, (java.lang.Class) wildcardClass35);
        java.lang.Class class39 = null;
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class39);
        java.lang.Class class42 = null;
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class42);
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries40.addAndOrUpdate(timeSeries43);
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries40.createCopy(0, 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener48 = null;
        timeSeries40.removeChangeListener(seriesChangeListener48);
        int int50 = fixedMillisecond1.compareTo((java.lang.Object) seriesChangeListener48);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-April-1900" + "'", str11.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "9-April-1900" + "'", str15.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "9-April-1900" + "'", str28.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 9 + "'", int31 == 9);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNull(inputStream36);
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertNotNull(timeSeries47);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str17 = spreadsheetDate16.toString();
        boolean boolean18 = spreadsheetDate14.isOn((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        spreadsheetDate20.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str28 = spreadsheetDate27.toString();
        boolean boolean29 = spreadsheetDate25.isOn((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str34 = spreadsheetDate33.toString();
        boolean boolean35 = spreadsheetDate31.isOn((org.jfree.data.time.SerialDate) spreadsheetDate33);
        boolean boolean36 = spreadsheetDate27.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int37 = spreadsheetDate33.getDayOfMonth();
        boolean boolean38 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate20, (org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int39 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str42 = spreadsheetDate41.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str47 = spreadsheetDate46.toString();
        boolean boolean48 = spreadsheetDate44.isOn((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str53 = spreadsheetDate52.toString();
        boolean boolean54 = spreadsheetDate50.isOn((org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean55 = spreadsheetDate46.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str60 = spreadsheetDate59.toString();
        boolean boolean61 = spreadsheetDate57.isOn((org.jfree.data.time.SerialDate) spreadsheetDate59);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str64 = spreadsheetDate63.toString();
        spreadsheetDate63.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str71 = spreadsheetDate70.toString();
        boolean boolean72 = spreadsheetDate68.isOn((org.jfree.data.time.SerialDate) spreadsheetDate70);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str77 = spreadsheetDate76.toString();
        boolean boolean78 = spreadsheetDate74.isOn((org.jfree.data.time.SerialDate) spreadsheetDate76);
        boolean boolean79 = spreadsheetDate70.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate76);
        int int80 = spreadsheetDate76.getDayOfMonth();
        boolean boolean81 = spreadsheetDate57.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate63, (org.jfree.data.time.SerialDate) spreadsheetDate76);
        int int82 = spreadsheetDate52.compare((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SerialDate serialDate83 = spreadsheetDate41.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SerialDate serialDate84 = spreadsheetDate14.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate86 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate88 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str89 = spreadsheetDate88.toString();
        boolean boolean90 = spreadsheetDate86.isOn((org.jfree.data.time.SerialDate) spreadsheetDate88);
        org.jfree.data.time.SerialDate serialDate91 = spreadsheetDate14.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate88);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "9-April-1900" + "'", str17.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "9-April-1900" + "'", str28.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "9-April-1900" + "'", str34.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 9 + "'", int37 == 9);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "9-April-1900" + "'", str42.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "9-April-1900" + "'", str47.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "9-April-1900" + "'", str53.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "9-April-1900" + "'", str60.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "9-April-1900" + "'", str64.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "9-April-1900" + "'", str71.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "9-April-1900" + "'", str77.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 9 + "'", int80 == 9);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "9-April-1900" + "'", str89.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertNotNull(serialDate91);
    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str5 = spreadsheetDate4.toString();
//        boolean boolean6 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str9 = spreadsheetDate8.toString();
//        spreadsheetDate8.setDescription("9-April-1900");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str16 = spreadsheetDate15.toString();
//        boolean boolean17 = spreadsheetDate13.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str22 = spreadsheetDate21.toString();
//        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        boolean boolean24 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        int int25 = spreadsheetDate21.getDayOfMonth();
//        boolean boolean26 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate21);
//        boolean boolean27 = day0.equals((java.lang.Object) spreadsheetDate8);
//        long long28 = day0.getSerialIndex();
//        int int29 = day0.getDayOfMonth();
//        java.lang.Object obj30 = null;
//        boolean boolean31 = day0.equals(obj30);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-April-1900" + "'", str9.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "9-April-1900" + "'", str16.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 9 + "'", int25 == 9);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 43629L + "'", long28 == 43629L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 13 + "'", int29 == 13);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj3 = null;
        boolean boolean4 = month2.equals(obj3);
        long long5 = month2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62126582400001L) + "'", long5 == (-62126582400001L));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = year1.getSerialIndex();
        long long3 = year1.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) '4');
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year1.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
        try {
            java.lang.Number number19 = timeSeries16.getValue((-459));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries17);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        timeSeries2.clear();
        int int5 = timeSeries2.getItemCount();
        java.lang.Object obj6 = timeSeries2.clone();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class8);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries13.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj20 = null;
        boolean boolean21 = month19.equals(obj20);
        int int22 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) month19);
        long long23 = month19.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date26 = fixedMillisecond25.getTime();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
        boolean boolean28 = month19.equals((java.lang.Object) day27);
        int int29 = day27.getDayOfMonth();
        java.lang.String str30 = day27.toString();
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) day27, (java.lang.Number) 10L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "31-December-1969" + "'", str30.equals("31-December-1969"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        java.util.Collection collection4 = timeSeries2.getTimePeriods();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(collection4);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        long long3 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str2 = spreadsheetDate1.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str7 = spreadsheetDate6.toString();
        boolean boolean8 = spreadsheetDate4.isOn((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str13 = spreadsheetDate12.toString();
        boolean boolean14 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean15 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str20 = spreadsheetDate19.toString();
        boolean boolean21 = spreadsheetDate17.isOn((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str24 = spreadsheetDate23.toString();
        spreadsheetDate23.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str31 = spreadsheetDate30.toString();
        boolean boolean32 = spreadsheetDate28.isOn((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str37 = spreadsheetDate36.toString();
        boolean boolean38 = spreadsheetDate34.isOn((org.jfree.data.time.SerialDate) spreadsheetDate36);
        boolean boolean39 = spreadsheetDate30.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate36);
        int int40 = spreadsheetDate36.getDayOfMonth();
        boolean boolean41 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, (org.jfree.data.time.SerialDate) spreadsheetDate36);
        int int42 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SerialDate serialDate43 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int44 = spreadsheetDate1.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "9-April-1900" + "'", str2.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9-April-1900" + "'", str7.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "9-April-1900" + "'", str13.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "9-April-1900" + "'", str20.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "9-April-1900" + "'", str24.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "9-April-1900" + "'", str31.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "9-April-1900" + "'", str37.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 9 + "'", int40 == 9);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2 + "'", int44 == 2);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date2, timeZone5);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date2, timeZone7);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date12 = fixedMillisecond11.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date12);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date12, timeZone15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date12, timeZone17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date2, timeZone17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date23 = fixedMillisecond22.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date23, timeZone26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date23, timeZone28);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date33 = fixedMillisecond32.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date33);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date33, timeZone36);
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date33, timeZone38);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date23, timeZone38);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date2, timeZone38);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(timeZone38);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar1 = null;
        fixedMillisecond0.peg(calendar1);
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        int int7 = timeSeries6.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long10 = fixedMillisecond9.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond9.previous();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond9.getLastMillisecond(calendar12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) 11);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class17);
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class20);
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries18.addAndOrUpdate(timeSeries21);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries22.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj29 = null;
        boolean boolean30 = month28.equals(obj29);
        int int31 = timeSeries22.getIndex((org.jfree.data.time.RegularTimePeriod) month28);
        long long32 = month28.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date35 = fixedMillisecond34.getTime();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        boolean boolean37 = month28.equals((java.lang.Object) day36);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day36, (double) (-1.0f));
        java.lang.Class class41 = null;
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class41);
        java.lang.Class class44 = null;
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class44);
        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries42.addAndOrUpdate(timeSeries45);
        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries46.createCopy(0, (int) (short) 1);
        java.lang.Class class51 = null;
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class51);
        java.lang.Class class54 = null;
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class54);
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries52.addAndOrUpdate(timeSeries55);
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries49.addAndOrUpdate(timeSeries56);
        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year59 = month58.getYear();
        long long60 = year59.getSerialIndex();
        java.lang.String str61 = year59.toString();
        timeSeries56.setKey((java.lang.Comparable) year59);
        int int63 = timeSeriesDataItem39.compareTo((java.lang.Object) year59);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str68 = spreadsheetDate67.toString();
        boolean boolean69 = spreadsheetDate65.isOn((org.jfree.data.time.SerialDate) spreadsheetDate67);
        org.jfree.data.time.SerialDate serialDate71 = spreadsheetDate67.getPreviousDayOfWeek(2);
        int int72 = timeSeriesDataItem39.compareTo((java.lang.Object) serialDate71);
        java.lang.Number number73 = timeSeriesDataItem39.getValue();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(timeSeries46);
        org.junit.Assert.assertNotNull(timeSeries49);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertNotNull(year59);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "2019" + "'", str61.equals("2019"));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "9-April-1900" + "'", str68.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertTrue("'" + number73 + "' != '" + 11.0d + "'", number73.equals(11.0d));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year5 = month4.getYear();
        long long6 = year5.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (double) (short) 10);
        int int9 = timeSeries2.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-458), (int) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(8, 0, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries2.createCopy(0, 7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries2.removeChangeListener(seriesChangeListener10);
        java.lang.Class class12 = timeSeries2.getTimePeriodClass();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries2.getTimePeriod((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(class12);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj13 = null;
        boolean boolean14 = month12.equals(obj13);
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        long long16 = month12.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date19 = fixedMillisecond18.getTime();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        boolean boolean21 = month12.equals((java.lang.Object) day20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day20, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem23.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = timeSeriesDataItem23.getPeriod();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        timeSeries2.setDomainDescription("October 0");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries2.addChangeListener(seriesChangeListener5);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class8);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries13.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj20 = null;
        boolean boolean21 = month19.equals(obj20);
        int int22 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) month19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) month23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str29 = spreadsheetDate28.toString();
        boolean boolean30 = spreadsheetDate26.isOn((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str35 = spreadsheetDate34.toString();
        boolean boolean36 = spreadsheetDate32.isOn((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean37 = spreadsheetDate28.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate34);
        spreadsheetDate28.setDescription("9-April-1900");
        boolean boolean40 = month23.equals((java.lang.Object) "9-April-1900");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month23);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "9-April-1900" + "'", str29.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "9-April-1900" + "'", str35.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        java.lang.Object obj4 = timeSeries2.clone();
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 1.0d);
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class7);
        int int9 = timeSeries8.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries8.removeChangeListener(seriesChangeListener10);
        java.util.Collection collection12 = timeSeries8.getTimePeriods();
        int int13 = timeSeriesDataItem5.compareTo((java.lang.Object) timeSeries8);
        java.lang.Number number14 = timeSeriesDataItem5.getValue();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year16 = month15.getYear();
        int int17 = timeSeriesDataItem5.compareTo((java.lang.Object) month15);
        timeSeriesDataItem5.setValue((java.lang.Number) 10.0d);
        java.lang.Object obj20 = timeSeriesDataItem5.clone();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1.0d + "'", number14.equals(1.0d));
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str9 = spreadsheetDate8.toString();
        boolean boolean10 = spreadsheetDate6.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str15 = spreadsheetDate14.toString();
        boolean boolean16 = spreadsheetDate12.isOn((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean17 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str22 = spreadsheetDate21.toString();
        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str26 = spreadsheetDate25.toString();
        spreadsheetDate25.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str33 = spreadsheetDate32.toString();
        boolean boolean34 = spreadsheetDate30.isOn((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str39 = spreadsheetDate38.toString();
        boolean boolean40 = spreadsheetDate36.isOn((org.jfree.data.time.SerialDate) spreadsheetDate38);
        boolean boolean41 = spreadsheetDate32.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        int int42 = spreadsheetDate38.getDayOfMonth();
        boolean boolean43 = spreadsheetDate19.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate38);
        int int44 = spreadsheetDate14.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate45 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addDays(100, (org.jfree.data.time.SerialDate) spreadsheetDate19);
        int int47 = spreadsheetDate19.toSerial();
        java.lang.Class<?> wildcardClass48 = spreadsheetDate19.getClass();
        java.net.URL uRL49 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Overwritten values from: 1.0", (java.lang.Class) wildcardClass48);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-April-1900" + "'", str9.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "9-April-1900" + "'", str15.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "9-April-1900" + "'", str26.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-April-1900" + "'", str33.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "9-April-1900" + "'", str39.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 100 + "'", int47 == 100);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNull(uRL49);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(1, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "January" + "'", str2.equals("January"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        long long3 = month2.getSerialIndex();
        long long4 = month2.getSerialIndex();
        int int5 = month2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.previous();
        int int7 = month2.getYearValue();
        java.lang.String str8 = month2.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 0" + "'", str8.equals("October 0"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        timeSeries2.clear();
        java.lang.Comparable comparable5 = timeSeries2.getKey();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year7 = month6.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date10 = fixedMillisecond9.getTime();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long14 = fixedMillisecond13.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond13.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod15, (java.lang.Number) 10.0f);
        try {
            timeSeries11.add(timeSeriesDataItem17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 1.0f + "'", comparable5.equals(1.0f));
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100, 13, (-458));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.general.SeriesException: ClassContext");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((-459));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str17 = spreadsheetDate16.toString();
        boolean boolean18 = spreadsheetDate14.isOn((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        spreadsheetDate20.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str28 = spreadsheetDate27.toString();
        boolean boolean29 = spreadsheetDate25.isOn((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str34 = spreadsheetDate33.toString();
        boolean boolean35 = spreadsheetDate31.isOn((org.jfree.data.time.SerialDate) spreadsheetDate33);
        boolean boolean36 = spreadsheetDate27.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int37 = spreadsheetDate33.getDayOfMonth();
        boolean boolean38 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate20, (org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int39 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str42 = spreadsheetDate41.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str47 = spreadsheetDate46.toString();
        boolean boolean48 = spreadsheetDate44.isOn((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str53 = spreadsheetDate52.toString();
        boolean boolean54 = spreadsheetDate50.isOn((org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean55 = spreadsheetDate46.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str60 = spreadsheetDate59.toString();
        boolean boolean61 = spreadsheetDate57.isOn((org.jfree.data.time.SerialDate) spreadsheetDate59);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str64 = spreadsheetDate63.toString();
        spreadsheetDate63.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str71 = spreadsheetDate70.toString();
        boolean boolean72 = spreadsheetDate68.isOn((org.jfree.data.time.SerialDate) spreadsheetDate70);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str77 = spreadsheetDate76.toString();
        boolean boolean78 = spreadsheetDate74.isOn((org.jfree.data.time.SerialDate) spreadsheetDate76);
        boolean boolean79 = spreadsheetDate70.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate76);
        int int80 = spreadsheetDate76.getDayOfMonth();
        boolean boolean81 = spreadsheetDate57.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate63, (org.jfree.data.time.SerialDate) spreadsheetDate76);
        int int82 = spreadsheetDate52.compare((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SerialDate serialDate83 = spreadsheetDate41.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SerialDate serialDate84 = spreadsheetDate14.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate57);
        try {
            org.jfree.data.time.SerialDate serialDate86 = serialDate84.getNearestDayOfWeek((-458));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "9-April-1900" + "'", str17.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "9-April-1900" + "'", str28.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "9-April-1900" + "'", str34.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 9 + "'", int37 == 9);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "9-April-1900" + "'", str42.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "9-April-1900" + "'", str47.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "9-April-1900" + "'", str53.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "9-April-1900" + "'", str60.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "9-April-1900" + "'", str64.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "9-April-1900" + "'", str71.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "9-April-1900" + "'", str77.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 9 + "'", int80 == 9);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(serialDate84);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        timeSeries2.setDomainDescription("October 0");
        java.lang.Object obj5 = timeSeries2.clone();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        boolean boolean8 = timeSeries2.equals((java.lang.Object) year6);
        java.util.Date date9 = year6.getEnd();
        java.util.TimeZone timeZone10 = null;
        try {
            org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9, timeZone10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        long long3 = month2.getSerialIndex();
        long long4 = month2.getSerialIndex();
        int int5 = month2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.previous();
        int int7 = month2.getYearValue();
        int int8 = month2.getMonth();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str6 = spreadsheetDate5.toString();
        boolean boolean7 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str12 = spreadsheetDate11.toString();
        boolean boolean13 = spreadsheetDate9.isOn((org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean14 = spreadsheetDate5.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str19 = spreadsheetDate18.toString();
        boolean boolean20 = spreadsheetDate16.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str23 = spreadsheetDate22.toString();
        spreadsheetDate22.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str30 = spreadsheetDate29.toString();
        boolean boolean31 = spreadsheetDate27.isOn((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str36 = spreadsheetDate35.toString();
        boolean boolean37 = spreadsheetDate33.isOn((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean38 = spreadsheetDate29.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        int int39 = spreadsheetDate35.getDayOfMonth();
        boolean boolean40 = spreadsheetDate16.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate22, (org.jfree.data.time.SerialDate) spreadsheetDate35);
        int int41 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str44 = spreadsheetDate43.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str49 = spreadsheetDate48.toString();
        boolean boolean50 = spreadsheetDate46.isOn((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str55 = spreadsheetDate54.toString();
        boolean boolean56 = spreadsheetDate52.isOn((org.jfree.data.time.SerialDate) spreadsheetDate54);
        boolean boolean57 = spreadsheetDate48.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate54);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str62 = spreadsheetDate61.toString();
        boolean boolean63 = spreadsheetDate59.isOn((org.jfree.data.time.SerialDate) spreadsheetDate61);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str66 = spreadsheetDate65.toString();
        spreadsheetDate65.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate72 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str73 = spreadsheetDate72.toString();
        boolean boolean74 = spreadsheetDate70.isOn((org.jfree.data.time.SerialDate) spreadsheetDate72);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate78 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str79 = spreadsheetDate78.toString();
        boolean boolean80 = spreadsheetDate76.isOn((org.jfree.data.time.SerialDate) spreadsheetDate78);
        boolean boolean81 = spreadsheetDate72.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate78);
        int int82 = spreadsheetDate78.getDayOfMonth();
        boolean boolean83 = spreadsheetDate59.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate65, (org.jfree.data.time.SerialDate) spreadsheetDate78);
        int int84 = spreadsheetDate54.compare((org.jfree.data.time.SerialDate) spreadsheetDate59);
        org.jfree.data.time.SerialDate serialDate85 = spreadsheetDate43.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate59);
        org.jfree.data.time.SerialDate serialDate86 = spreadsheetDate16.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate59);
        boolean boolean87 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate59);
        org.jfree.data.time.SerialDate serialDate88 = null;
        try {
            boolean boolean89 = spreadsheetDate1.isOn(serialDate88);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "9-April-1900" + "'", str6.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-April-1900" + "'", str12.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-April-1900" + "'", str19.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "9-April-1900" + "'", str23.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "9-April-1900" + "'", str30.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "9-April-1900" + "'", str36.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 9 + "'", int39 == 9);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "9-April-1900" + "'", str44.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "9-April-1900" + "'", str49.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "9-April-1900" + "'", str55.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "9-April-1900" + "'", str62.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "9-April-1900" + "'", str66.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "9-April-1900" + "'", str73.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "9-April-1900" + "'", str79.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 9 + "'", int82 == 9);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertNotNull(serialDate85);
        org.junit.Assert.assertNotNull(serialDate86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long4 = fixedMillisecond3.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str9 = spreadsheetDate8.toString();
        boolean boolean10 = spreadsheetDate6.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str13 = spreadsheetDate12.toString();
        spreadsheetDate12.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str20 = spreadsheetDate19.toString();
        boolean boolean21 = spreadsheetDate17.isOn((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str26 = spreadsheetDate25.toString();
        boolean boolean27 = spreadsheetDate23.isOn((org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean28 = spreadsheetDate19.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        int int29 = spreadsheetDate25.getDayOfMonth();
        boolean boolean30 = spreadsheetDate6.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, (org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean31 = fixedMillisecond3.equals((java.lang.Object) spreadsheetDate12);
        boolean boolean32 = day1.equals((java.lang.Object) fixedMillisecond3);
        java.lang.Class<?> wildcardClass33 = fixedMillisecond3.getClass();
        java.io.InputStream inputStream34 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("9-April-1900", (java.lang.Class) wildcardClass33);
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
        java.lang.ClassLoader classLoader36 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class35);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-April-1900" + "'", str9.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "9-April-1900" + "'", str13.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "9-April-1900" + "'", str20.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "9-April-1900" + "'", str26.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 9 + "'", int29 == 9);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNull(inputStream34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertNotNull(classLoader36);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj13 = null;
        boolean boolean14 = month12.equals(obj13);
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        long long16 = month12.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date19 = fixedMillisecond18.getTime();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        boolean boolean21 = month12.equals((java.lang.Object) day20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day20, 0.0d);
        java.util.Calendar calendar24 = null;
        try {
            long long25 = day20.getLastMillisecond(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        timeSeries2.fireSeriesChanged();
        int int5 = timeSeries2.getMaximumItemCount();
        timeSeries2.setDescription("org.jfree.data.general.SeriesException: ClassContext");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj13 = null;
        boolean boolean14 = month12.equals(obj13);
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        long long16 = month12.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date19 = fixedMillisecond18.getTime();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        boolean boolean21 = month12.equals((java.lang.Object) day20);
        int int22 = day20.getDayOfMonth();
        java.lang.String str23 = day20.toString();
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class25);
        timeSeries26.setDomainDescription("October 0");
        java.lang.Object obj29 = timeSeries26.clone();
        timeSeries26.setNotify(false);
        int int32 = day20.compareTo((java.lang.Object) false);
        int int33 = day20.getYear();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 31 + "'", int22 == 31);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "31-December-1969" + "'", str23.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1969 + "'", int33 == 1969);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Last", "", "ERROR : Relative To String", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener5);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class8);
        timeSeries9.setDomainDescription("October 0");
        java.lang.Object obj12 = timeSeries9.clone();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.addAndOrUpdate(timeSeries9);
        timeSeries13.setDescription("September");
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(timeSeries13);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int3 = month2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.next();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths(1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str9 = spreadsheetDate8.toString();
        boolean boolean10 = spreadsheetDate6.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str15 = spreadsheetDate14.toString();
        boolean boolean16 = spreadsheetDate12.isOn((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean17 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str22 = spreadsheetDate21.toString();
        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str26 = spreadsheetDate25.toString();
        spreadsheetDate25.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str33 = spreadsheetDate32.toString();
        boolean boolean34 = spreadsheetDate30.isOn((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str39 = spreadsheetDate38.toString();
        boolean boolean40 = spreadsheetDate36.isOn((org.jfree.data.time.SerialDate) spreadsheetDate38);
        boolean boolean41 = spreadsheetDate32.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        int int42 = spreadsheetDate38.getDayOfMonth();
        boolean boolean43 = spreadsheetDate19.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate38);
        int int44 = spreadsheetDate14.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate45 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str51 = spreadsheetDate50.toString();
        boolean boolean52 = spreadsheetDate48.isOn((org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str57 = spreadsheetDate56.toString();
        boolean boolean58 = spreadsheetDate54.isOn((org.jfree.data.time.SerialDate) spreadsheetDate56);
        boolean boolean59 = spreadsheetDate50.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate56);
        boolean boolean60 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate56);
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate56);
        int int62 = spreadsheetDate56.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str65 = spreadsheetDate64.toString();
        spreadsheetDate64.setDescription("9-April-1900");
        int int68 = spreadsheetDate64.toSerial();
        int int69 = spreadsheetDate64.getDayOfWeek();
        boolean boolean70 = spreadsheetDate56.isOn((org.jfree.data.time.SerialDate) spreadsheetDate64);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-April-1900" + "'", str9.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "9-April-1900" + "'", str15.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "9-April-1900" + "'", str26.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-April-1900" + "'", str33.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "9-April-1900" + "'", str39.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "9-April-1900" + "'", str51.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "9-April-1900" + "'", str57.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 4 + "'", int62 == 4);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "9-April-1900" + "'", str65.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 100 + "'", int68 == 100);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 2 + "'", int69 == 2);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) 30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        int int7 = timeSeries6.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long10 = fixedMillisecond9.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond9.previous();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond9.getLastMillisecond(calendar12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) 11);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class17);
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class20);
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries18.addAndOrUpdate(timeSeries21);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries22.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj29 = null;
        boolean boolean30 = month28.equals(obj29);
        int int31 = timeSeries22.getIndex((org.jfree.data.time.RegularTimePeriod) month28);
        long long32 = month28.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date35 = fixedMillisecond34.getTime();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        boolean boolean37 = month28.equals((java.lang.Object) day36);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day36, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day36.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date43 = fixedMillisecond42.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond(date43);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date43);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date43);
        boolean boolean47 = day36.equals((java.lang.Object) date43);
        int int48 = day36.getYear();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1969 + "'", int48 == 1969);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.general.SeriesException: 9-April-1900");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long7 = fixedMillisecond6.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str12 = spreadsheetDate11.toString();
        boolean boolean13 = spreadsheetDate9.isOn((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str16 = spreadsheetDate15.toString();
        spreadsheetDate15.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str23 = spreadsheetDate22.toString();
        boolean boolean24 = spreadsheetDate20.isOn((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str29 = spreadsheetDate28.toString();
        boolean boolean30 = spreadsheetDate26.isOn((org.jfree.data.time.SerialDate) spreadsheetDate28);
        boolean boolean31 = spreadsheetDate22.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate28);
        int int32 = spreadsheetDate28.getDayOfMonth();
        boolean boolean33 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate15, (org.jfree.data.time.SerialDate) spreadsheetDate28);
        boolean boolean34 = fixedMillisecond6.equals((java.lang.Object) spreadsheetDate15);
        boolean boolean35 = day4.equals((java.lang.Object) fixedMillisecond6);
        java.lang.Class<?> wildcardClass36 = fixedMillisecond6.getClass();
        java.io.InputStream inputStream37 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("9-April-1900", (java.lang.Class) wildcardClass36);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond2, (java.lang.Class) wildcardClass36);
        java.net.URL uRL39 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("December 1969", (java.lang.Class) wildcardClass36);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-April-1900" + "'", str12.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "9-April-1900" + "'", str16.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "9-April-1900" + "'", str23.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "9-April-1900" + "'", str29.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 9 + "'", int32 == 9);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNull(inputStream37);
        org.junit.Assert.assertNull(uRL39);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Calendar calendar3 = null;
        try {
            year0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str17 = spreadsheetDate16.toString();
        boolean boolean18 = spreadsheetDate14.isOn((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        spreadsheetDate20.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str28 = spreadsheetDate27.toString();
        boolean boolean29 = spreadsheetDate25.isOn((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str34 = spreadsheetDate33.toString();
        boolean boolean35 = spreadsheetDate31.isOn((org.jfree.data.time.SerialDate) spreadsheetDate33);
        boolean boolean36 = spreadsheetDate27.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int37 = spreadsheetDate33.getDayOfMonth();
        boolean boolean38 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate20, (org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int39 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str42 = spreadsheetDate41.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str47 = spreadsheetDate46.toString();
        boolean boolean48 = spreadsheetDate44.isOn((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str53 = spreadsheetDate52.toString();
        boolean boolean54 = spreadsheetDate50.isOn((org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean55 = spreadsheetDate46.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str60 = spreadsheetDate59.toString();
        boolean boolean61 = spreadsheetDate57.isOn((org.jfree.data.time.SerialDate) spreadsheetDate59);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str64 = spreadsheetDate63.toString();
        spreadsheetDate63.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str71 = spreadsheetDate70.toString();
        boolean boolean72 = spreadsheetDate68.isOn((org.jfree.data.time.SerialDate) spreadsheetDate70);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str77 = spreadsheetDate76.toString();
        boolean boolean78 = spreadsheetDate74.isOn((org.jfree.data.time.SerialDate) spreadsheetDate76);
        boolean boolean79 = spreadsheetDate70.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate76);
        int int80 = spreadsheetDate76.getDayOfMonth();
        boolean boolean81 = spreadsheetDate57.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate63, (org.jfree.data.time.SerialDate) spreadsheetDate76);
        int int82 = spreadsheetDate52.compare((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SerialDate serialDate83 = spreadsheetDate41.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SerialDate serialDate84 = spreadsheetDate14.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate86 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate88 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str89 = spreadsheetDate88.toString();
        boolean boolean90 = spreadsheetDate86.isOn((org.jfree.data.time.SerialDate) spreadsheetDate88);
        int int91 = spreadsheetDate88.getMonth();
        boolean boolean92 = spreadsheetDate14.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate88);
        int int93 = spreadsheetDate14.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "9-April-1900" + "'", str17.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "9-April-1900" + "'", str28.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "9-April-1900" + "'", str34.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 9 + "'", int37 == 9);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "9-April-1900" + "'", str42.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "9-April-1900" + "'", str47.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "9-April-1900" + "'", str53.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "9-April-1900" + "'", str60.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "9-April-1900" + "'", str64.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "9-April-1900" + "'", str71.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "9-April-1900" + "'", str77.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 9 + "'", int80 == 9);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "9-April-1900" + "'", str89.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 4 + "'", int91 == 4);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 2 + "'", int93 == 2);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str3 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        boolean boolean9 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        spreadsheetDate24.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str32 = spreadsheetDate31.toString();
        boolean boolean33 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        boolean boolean39 = spreadsheetDate35.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int41 = spreadsheetDate37.getDayOfMonth();
        boolean boolean42 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int43 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays(100, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str48 = spreadsheetDate47.toString();
        spreadsheetDate47.setDescription("9-April-1900");
        int int51 = spreadsheetDate47.toSerial();
        boolean boolean52 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SerialDate serialDate54 = spreadsheetDate47.getNearestDayOfWeek(4);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(serialDate54);
        java.util.Calendar calendar56 = null;
        try {
            day55.peg(calendar56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9 + "'", int41 == 9);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "9-April-1900" + "'", str48.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 100 + "'", int51 == 100);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(serialDate54);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str12 = spreadsheetDate11.toString();
        boolean boolean13 = spreadsheetDate9.isOn((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str16 = spreadsheetDate15.toString();
        spreadsheetDate15.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str23 = spreadsheetDate22.toString();
        boolean boolean24 = spreadsheetDate20.isOn((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str29 = spreadsheetDate28.toString();
        boolean boolean30 = spreadsheetDate26.isOn((org.jfree.data.time.SerialDate) spreadsheetDate28);
        boolean boolean31 = spreadsheetDate22.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate28);
        int int32 = spreadsheetDate28.getDayOfMonth();
        boolean boolean33 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate15, (org.jfree.data.time.SerialDate) spreadsheetDate28);
        int int34 = spreadsheetDate9.toSerial();
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate36 = serialDate6.getEndOfCurrentMonth(serialDate35);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-April-1900" + "'", str12.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "9-April-1900" + "'", str16.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "9-April-1900" + "'", str23.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "9-April-1900" + "'", str29.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 9 + "'", int32 == 9);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 100 + "'", int34 == 100);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate36);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj13 = null;
        boolean boolean14 = month12.equals(obj13);
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month12);
        long long16 = month12.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month12.next();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        boolean boolean7 = timeSeries2.getNotify();
        int int8 = timeSeries2.getMaximumItemCount();
        java.lang.String str9 = timeSeries2.getDescription();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries2.createCopy(0, (int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long15 = fixedMillisecond14.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond14.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod16, (java.lang.Number) 10.0f);
        java.lang.Number number19 = timeSeriesDataItem18.getValue();
        try {
            timeSeries2.add(timeSeriesDataItem18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 10.0f + "'", number19.equals(10.0f));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str5 = spreadsheetDate4.toString();
        boolean boolean6 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str11 = spreadsheetDate10.toString();
        boolean boolean12 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean13 = spreadsheetDate4.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int14 = spreadsheetDate4.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(6, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-April-1900" + "'", str11.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 9 + "'", int14 == 9);
        org.junit.Assert.assertNotNull(serialDate15);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("SerialDate.weekInMonthToString(): invalid code.");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        timeSeries2.setDomainDescription("October 0");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        timeSeries2.delete(regularTimePeriod6);
        timeSeries2.removeAgedItems(true);
        timeSeries2.setMaximumItemAge(100L);
        java.lang.String str12 = timeSeries2.getDomainDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "October 0" + "'", str12.equals("October 0"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        timeSeries2.clear();
        int int5 = timeSeries2.getItemCount();
        java.lang.Object obj6 = timeSeries2.clone();
        int int7 = timeSeries2.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-2200665600000L));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year9 = month8.getYear();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year9);
        java.lang.Object obj11 = timeSeries6.clone();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.String str10 = timeSeries6.getDescription();
        java.lang.Comparable comparable11 = timeSeries6.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long14 = fixedMillisecond13.getMiddleMillisecond();
        long long15 = fixedMillisecond13.getFirstMillisecond();
        long long16 = fixedMillisecond13.getLastMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        java.lang.Object obj19 = null;
        boolean boolean20 = spreadsheetDate18.equals(obj19);
        boolean boolean21 = fixedMillisecond13.equals(obj19);
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond13.getLastMillisecond(calendar23);
        long long25 = fixedMillisecond13.getSerialIndex();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + "Overwritten values from: 1.0" + "'", comparable11.equals("Overwritten values from: 1.0"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int7 = month6.getMonth();
        java.lang.String str8 = month6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        long long10 = month6.getLastMillisecond();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year12 = month11.getYear();
        int int13 = month6.compareTo((java.lang.Object) year12);
        java.lang.String str14 = month6.toString();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 0" + "'", str8.equals("October 0"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62109475200001L) + "'", long10 == (-62109475200001L));
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "October 0" + "'", str14.equals("October 0"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Nearest");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str2 = spreadsheetDate1.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str7 = spreadsheetDate6.toString();
        boolean boolean8 = spreadsheetDate4.isOn((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str13 = spreadsheetDate12.toString();
        boolean boolean14 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean15 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str20 = spreadsheetDate19.toString();
        boolean boolean21 = spreadsheetDate17.isOn((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str24 = spreadsheetDate23.toString();
        spreadsheetDate23.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str31 = spreadsheetDate30.toString();
        boolean boolean32 = spreadsheetDate28.isOn((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str37 = spreadsheetDate36.toString();
        boolean boolean38 = spreadsheetDate34.isOn((org.jfree.data.time.SerialDate) spreadsheetDate36);
        boolean boolean39 = spreadsheetDate30.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate36);
        int int40 = spreadsheetDate36.getDayOfMonth();
        boolean boolean41 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, (org.jfree.data.time.SerialDate) spreadsheetDate36);
        int int42 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SerialDate serialDate43 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int44 = spreadsheetDate17.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "9-April-1900" + "'", str2.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9-April-1900" + "'", str7.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "9-April-1900" + "'", str13.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "9-April-1900" + "'", str20.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "9-April-1900" + "'", str24.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "9-April-1900" + "'", str31.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "9-April-1900" + "'", str37.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 9 + "'", int40 == 9);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 9 + "'", int44 == 9);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = year1.getSerialIndex();
        long long3 = year1.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year1);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class6);
        boolean boolean8 = timeSeries7.getNotify();
        timeSeries7.fireSeriesChanged();
        int int10 = timeSeries7.getMaximumItemCount();
        int int11 = year1.compareTo((java.lang.Object) timeSeries7);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj3 = null;
        boolean boolean4 = month2.equals(obj3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 10.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem6.getPeriod();
        java.lang.Object obj8 = timeSeriesDataItem6.clone();
        java.lang.Number number9 = timeSeriesDataItem6.getValue();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 10.0f + "'", number9.equals(10.0f));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener18);
        java.lang.Object obj20 = timeSeries9.clone();
        boolean boolean21 = timeSeries9.getNotify();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long20 = fixedMillisecond19.getMiddleMillisecond();
        long long21 = fixedMillisecond19.getFirstMillisecond();
        long long22 = fixedMillisecond19.getSerialIndex();
        java.util.Date date23 = fixedMillisecond19.getTime();
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond19.getFirstMillisecond(calendar24);
        try {
            timeSeries16.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 43629L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("ClassContext");
        java.lang.String str2 = seriesException1.toString();
        java.lang.String str3 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: ClassContext" + "'", str2.equals("org.jfree.data.general.SeriesException: ClassContext"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: ClassContext" + "'", str3.equals("org.jfree.data.general.SeriesException: ClassContext"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        boolean boolean5 = fixedMillisecond1.equals((java.lang.Object) 'a');
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getFirstMillisecond(calendar6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date2, timeZone5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year8 = month7.getYear();
        long long9 = year8.getSerialIndex();
        long long10 = year8.getLastMillisecond();
        int int11 = year8.getYear();
        boolean boolean12 = year6.equals((java.lang.Object) year8);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) 10, 2147483647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date2, timeZone5);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date2, timeZone7);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date12 = fixedMillisecond11.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date12);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date12, timeZone15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date12, timeZone17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date2, timeZone17);
        long long20 = month19.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 28799999L + "'", long20 == 28799999L);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date2, timeZone5);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date2, timeZone7);
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class10);
        boolean boolean12 = timeSeries11.getNotify();
        timeSeries11.clear();
        java.lang.Comparable comparable14 = timeSeries11.getKey();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year16 = month15.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date19 = fixedMillisecond18.getTime();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) year16, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        boolean boolean21 = year8.equals((java.lang.Object) fixedMillisecond18);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 1.0f + "'", comparable14.equals(1.0f));
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class11);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries12.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries9.addAndOrUpdate(timeSeries16);
//        int int18 = timeSeries9.getItemCount();
//        java.lang.Comparable comparable19 = timeSeries9.getKey();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str25 = spreadsheetDate24.toString();
//        boolean boolean26 = spreadsheetDate22.isOn((org.jfree.data.time.SerialDate) spreadsheetDate24);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str29 = spreadsheetDate28.toString();
//        spreadsheetDate28.setDescription("9-April-1900");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str36 = spreadsheetDate35.toString();
//        boolean boolean37 = spreadsheetDate33.isOn((org.jfree.data.time.SerialDate) spreadsheetDate35);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str42 = spreadsheetDate41.toString();
//        boolean boolean43 = spreadsheetDate39.isOn((org.jfree.data.time.SerialDate) spreadsheetDate41);
//        boolean boolean44 = spreadsheetDate35.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
//        int int45 = spreadsheetDate41.getDayOfMonth();
//        boolean boolean46 = spreadsheetDate22.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate28, (org.jfree.data.time.SerialDate) spreadsheetDate41);
//        boolean boolean47 = day20.equals((java.lang.Object) spreadsheetDate28);
//        long long48 = day20.getLastMillisecond();
//        java.lang.Class class50 = null;
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class50);
//        java.lang.Class class53 = null;
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class53);
//        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries51.addAndOrUpdate(timeSeries54);
//        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries55.createCopy(0, (int) (short) 1);
//        java.lang.Class class60 = null;
//        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class60);
//        java.lang.Class class63 = null;
//        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class63);
//        org.jfree.data.time.TimeSeries timeSeries65 = timeSeries61.addAndOrUpdate(timeSeries64);
//        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries58.addAndOrUpdate(timeSeries65);
//        org.jfree.data.time.Month month67 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year68 = month67.getYear();
//        long long69 = year68.getSerialIndex();
//        java.lang.String str70 = year68.toString();
//        timeSeries65.setKey((java.lang.Comparable) year68);
//        org.jfree.data.time.TimeSeries timeSeries72 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) day20, (org.jfree.data.time.RegularTimePeriod) year68);
//        try {
//            timeSeries72.delete((int) (byte) 0, 9999);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + "Overwritten values from: 1.0" + "'", comparable19.equals("Overwritten values from: 1.0"));
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "9-April-1900" + "'", str29.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "9-April-1900" + "'", str36.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "9-April-1900" + "'", str42.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 9 + "'", int45 == 9);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560495599999L + "'", long48 == 1560495599999L);
//        org.junit.Assert.assertNotNull(timeSeries55);
//        org.junit.Assert.assertNotNull(timeSeries58);
//        org.junit.Assert.assertNotNull(timeSeries65);
//        org.junit.Assert.assertNotNull(timeSeries66);
//        org.junit.Assert.assertNotNull(year68);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2019L + "'", long69 == 2019L);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "2019" + "'", str70.equals("2019"));
//        org.junit.Assert.assertNotNull(timeSeries72);
//    }

//    @Test
//    public void test476() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test476");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str5 = spreadsheetDate4.toString();
//        boolean boolean6 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str9 = spreadsheetDate8.toString();
//        spreadsheetDate8.setDescription("9-April-1900");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str16 = spreadsheetDate15.toString();
//        boolean boolean17 = spreadsheetDate13.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str22 = spreadsheetDate21.toString();
//        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        boolean boolean24 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        int int25 = spreadsheetDate21.getDayOfMonth();
//        boolean boolean26 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate21);
//        boolean boolean27 = day0.equals((java.lang.Object) spreadsheetDate8);
//        long long28 = day0.getLastMillisecond();
//        java.util.Date date29 = day0.getStart();
//        long long30 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-April-1900" + "'", str9.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "9-April-1900" + "'", str16.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 9 + "'", int25 == 9);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560495599999L + "'", long28 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 43629L + "'", long30 == 43629L);
//    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries6);
        int int8 = timeSeries6.getMaximumItemCount();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class10);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class13);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries11.addAndOrUpdate(timeSeries14);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries15.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj22 = null;
        boolean boolean23 = month21.equals(obj22);
        int int24 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) month21);
        long long25 = month21.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date28 = fixedMillisecond27.getTime();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        boolean boolean30 = month21.equals((java.lang.Object) day29);
        long long31 = month21.getSerialIndex();
        java.lang.Number number32 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) month21);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 10L + "'", long25 == 10L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertNull(number32);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str3 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        boolean boolean9 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        spreadsheetDate24.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str32 = spreadsheetDate31.toString();
        boolean boolean33 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        boolean boolean39 = spreadsheetDate35.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int41 = spreadsheetDate37.getDayOfMonth();
        boolean boolean42 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int43 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str50 = spreadsheetDate49.toString();
        boolean boolean51 = spreadsheetDate47.isOn((org.jfree.data.time.SerialDate) spreadsheetDate49);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str56 = spreadsheetDate55.toString();
        boolean boolean57 = spreadsheetDate53.isOn((org.jfree.data.time.SerialDate) spreadsheetDate55);
        boolean boolean58 = spreadsheetDate49.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate55);
        boolean boolean59 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate55);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str64 = spreadsheetDate63.toString();
        boolean boolean65 = spreadsheetDate61.isOn((org.jfree.data.time.SerialDate) spreadsheetDate63);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str70 = spreadsheetDate69.toString();
        boolean boolean71 = spreadsheetDate67.isOn((org.jfree.data.time.SerialDate) spreadsheetDate69);
        boolean boolean72 = spreadsheetDate63.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate69);
        spreadsheetDate63.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate78 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str79 = spreadsheetDate78.toString();
        boolean boolean80 = spreadsheetDate76.isOn((org.jfree.data.time.SerialDate) spreadsheetDate78);
        org.jfree.data.time.SerialDate serialDate82 = spreadsheetDate78.getPreviousDayOfWeek(2);
        boolean boolean84 = spreadsheetDate55.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate63, serialDate82, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9 + "'", int41 == 9);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "9-April-1900" + "'", str50.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "9-April-1900" + "'", str56.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "9-April-1900" + "'", str64.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "9-April-1900" + "'", str70.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "9-April-1900" + "'", str79.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertNotNull(serialDate82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        timeSeries2.setDomainDescription("October 0");
        java.lang.Object obj5 = timeSeries2.clone();
        timeSeries2.setDomainDescription("ERROR : Relative To String");
        int int8 = timeSeries2.getMaximumItemCount();
        boolean boolean9 = timeSeries2.getNotify();
        try {
            java.lang.Number number11 = timeSeries2.getValue((-458));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj3 = null;
        boolean boolean4 = month2.equals(obj3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 10.0f);
        timeSeriesDataItem6.setValue((java.lang.Number) 12);
        java.lang.Number number9 = timeSeriesDataItem6.getValue();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 12 + "'", number9.equals(12));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        boolean boolean7 = timeSeries2.getNotify();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str13 = spreadsheetDate12.toString();
        boolean boolean14 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str17 = spreadsheetDate16.toString();
        spreadsheetDate16.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str24 = spreadsheetDate23.toString();
        boolean boolean25 = spreadsheetDate21.isOn((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str30 = spreadsheetDate29.toString();
        boolean boolean31 = spreadsheetDate27.isOn((org.jfree.data.time.SerialDate) spreadsheetDate29);
        boolean boolean32 = spreadsheetDate23.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        int int33 = spreadsheetDate29.getDayOfMonth();
        boolean boolean34 = spreadsheetDate10.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate16, (org.jfree.data.time.SerialDate) spreadsheetDate29);
        boolean boolean35 = day8.equals((java.lang.Object) spreadsheetDate16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day8.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long39 = fixedMillisecond38.getMiddleMillisecond();
        long long40 = fixedMillisecond38.getFirstMillisecond();
        long long41 = fixedMillisecond38.getLastMillisecond();
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond38.getMiddleMillisecond(calendar42);
        java.util.Date date44 = fixedMillisecond38.getTime();
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(date44);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(date44);
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries2.createCopy(regularTimePeriod36, (org.jfree.data.time.RegularTimePeriod) month46);
        java.util.List list48 = timeSeries2.getItems();
        try {
            java.util.Collection collection49 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list48);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "9-April-1900" + "'", str13.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "9-April-1900" + "'", str17.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "9-April-1900" + "'", str24.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "9-April-1900" + "'", str30.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 9 + "'", int33 == 9);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 100L + "'", long39 == 100L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 100L + "'", long40 == 100L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 100L + "'", long41 == 100L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 100L + "'", long43 == 100L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(timeSeries47);
        org.junit.Assert.assertNotNull(list48);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int13 = spreadsheetDate3.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str4 = spreadsheetDate3.toString();
        boolean boolean5 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        boolean boolean11 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int13 = spreadsheetDate3.getMonth();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        long long16 = year14.getLastMillisecond();
        try {
            int int17 = spreadsheetDate3.compareTo((java.lang.Object) year14);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.Year cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-April-1900" + "'", str4.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        timeSeries2.setDomainDescription("October 0");
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        long long8 = year6.getLastMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(2, year6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) year6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int7 = month6.getMonth();
        java.lang.String str8 = month6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (double) 1L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 0" + "'", str8.equals("October 0"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str5 = spreadsheetDate4.toString();
//        boolean boolean6 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str9 = spreadsheetDate8.toString();
//        spreadsheetDate8.setDescription("9-April-1900");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str16 = spreadsheetDate15.toString();
//        boolean boolean17 = spreadsheetDate13.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str22 = spreadsheetDate21.toString();
//        boolean boolean23 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        boolean boolean24 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        int int25 = spreadsheetDate21.getDayOfMonth();
//        boolean boolean26 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate21);
//        boolean boolean27 = day0.equals((java.lang.Object) spreadsheetDate8);
//        long long28 = day0.getSerialIndex();
//        long long29 = day0.getSerialIndex();
//        int int30 = day0.getMonth();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        long long36 = fixedMillisecond35.getMiddleMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str41 = spreadsheetDate40.toString();
//        boolean boolean42 = spreadsheetDate38.isOn((org.jfree.data.time.SerialDate) spreadsheetDate40);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str45 = spreadsheetDate44.toString();
//        spreadsheetDate44.setDescription("9-April-1900");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str52 = spreadsheetDate51.toString();
//        boolean boolean53 = spreadsheetDate49.isOn((org.jfree.data.time.SerialDate) spreadsheetDate51);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(100);
//        java.lang.String str58 = spreadsheetDate57.toString();
//        boolean boolean59 = spreadsheetDate55.isOn((org.jfree.data.time.SerialDate) spreadsheetDate57);
//        boolean boolean60 = spreadsheetDate51.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate57);
//        int int61 = spreadsheetDate57.getDayOfMonth();
//        boolean boolean62 = spreadsheetDate38.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate44, (org.jfree.data.time.SerialDate) spreadsheetDate57);
//        boolean boolean63 = fixedMillisecond35.equals((java.lang.Object) spreadsheetDate44);
//        boolean boolean64 = day33.equals((java.lang.Object) fixedMillisecond35);
//        java.lang.Class<?> wildcardClass65 = fixedMillisecond35.getClass();
//        java.lang.Class class66 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass65);
//        java.io.InputStream inputStream67 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass65);
//        java.io.InputStream inputStream68 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Sep", (java.lang.Class) wildcardClass65);
//        boolean boolean69 = day0.equals((java.lang.Object) "Sep");
//        int int70 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-April-1900" + "'", str5.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-April-1900" + "'", str9.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "9-April-1900" + "'", str16.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-April-1900" + "'", str22.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 9 + "'", int25 == 9);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 43629L + "'", long28 == 43629L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 43629L + "'", long29 == 43629L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 100L + "'", long36 == 100L);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "9-April-1900" + "'", str41.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "9-April-1900" + "'", str45.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "9-April-1900" + "'", str52.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "9-April-1900" + "'", str58.equals("9-April-1900"));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 9 + "'", int61 == 9);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(wildcardClass65);
//        org.junit.Assert.assertNotNull(class66);
//        org.junit.Assert.assertNotNull(inputStream67);
//        org.junit.Assert.assertNull(inputStream68);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 2019 + "'", int70 == 2019);
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class2);
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class5);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries3.addAndOrUpdate(timeSeries6);
        int int8 = timeSeries7.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long11 = fixedMillisecond10.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond10.previous();
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond10.getLastMillisecond(calendar13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (double) 11);
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class18);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries19.addAndOrUpdate(timeSeries22);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 1);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        java.lang.Object obj30 = null;
        boolean boolean31 = month29.equals(obj30);
        int int32 = timeSeries23.getIndex((org.jfree.data.time.RegularTimePeriod) month29);
        long long33 = month29.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Date date36 = fixedMillisecond35.getTime();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        boolean boolean38 = month29.equals((java.lang.Object) day37);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day37, (double) (-1.0f));
        java.lang.Class class42 = null;
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class42);
        java.lang.Class class45 = null;
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class45);
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries43.addAndOrUpdate(timeSeries46);
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries47.createCopy(0, (int) (short) 1);
        java.lang.Class class52 = null;
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class52);
        java.lang.Class class55 = null;
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class55);
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries53.addAndOrUpdate(timeSeries56);
        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries50.addAndOrUpdate(timeSeries57);
        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year60 = month59.getYear();
        long long61 = year60.getSerialIndex();
        java.lang.String str62 = year60.toString();
        timeSeries57.setKey((java.lang.Comparable) year60);
        int int64 = timeSeriesDataItem40.compareTo((java.lang.Object) year60);
        java.lang.Class<?> wildcardClass65 = year60.getClass();
        try {
            org.jfree.data.time.Month month66 = new org.jfree.data.time.Month(31, year60);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem40);
        org.junit.Assert.assertNotNull(timeSeries47);
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertNotNull(timeSeries58);
        org.junit.Assert.assertNotNull(year60);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 2019L + "'", long61 == 2019L);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "2019" + "'", str62.equals("2019"));
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertNotNull(wildcardClass65);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(11);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        long long3 = month2.getSerialIndex();
        long long4 = month2.getSerialIndex();
        java.lang.String str5 = month2.toString();
        long long6 = month2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "October 0" + "'", str5.equals("October 0"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62126582400001L) + "'", long6 == (-62126582400001L));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str3 = spreadsheetDate2.toString();
        try {
            org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("2019", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '#');
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str3 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str8 = spreadsheetDate7.toString();
        boolean boolean9 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str21 = spreadsheetDate20.toString();
        boolean boolean22 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        spreadsheetDate24.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str32 = spreadsheetDate31.toString();
        boolean boolean33 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str38 = spreadsheetDate37.toString();
        boolean boolean39 = spreadsheetDate35.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate31.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int41 = spreadsheetDate37.getDayOfMonth();
        boolean boolean42 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        int int43 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays(100, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        int int46 = spreadsheetDate18.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str50 = spreadsheetDate49.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str55 = spreadsheetDate54.toString();
        boolean boolean56 = spreadsheetDate52.isOn((org.jfree.data.time.SerialDate) spreadsheetDate54);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str61 = spreadsheetDate60.toString();
        boolean boolean62 = spreadsheetDate58.isOn((org.jfree.data.time.SerialDate) spreadsheetDate60);
        boolean boolean63 = spreadsheetDate54.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate60);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str68 = spreadsheetDate67.toString();
        boolean boolean69 = spreadsheetDate65.isOn((org.jfree.data.time.SerialDate) spreadsheetDate67);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str72 = spreadsheetDate71.toString();
        spreadsheetDate71.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate78 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str79 = spreadsheetDate78.toString();
        boolean boolean80 = spreadsheetDate76.isOn((org.jfree.data.time.SerialDate) spreadsheetDate78);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate82 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate84 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str85 = spreadsheetDate84.toString();
        boolean boolean86 = spreadsheetDate82.isOn((org.jfree.data.time.SerialDate) spreadsheetDate84);
        boolean boolean87 = spreadsheetDate78.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate84);
        int int88 = spreadsheetDate84.getDayOfMonth();
        boolean boolean89 = spreadsheetDate65.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate71, (org.jfree.data.time.SerialDate) spreadsheetDate84);
        int int90 = spreadsheetDate60.compare((org.jfree.data.time.SerialDate) spreadsheetDate65);
        org.jfree.data.time.SerialDate serialDate91 = spreadsheetDate49.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate65);
        org.jfree.data.time.SerialDate serialDate92 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate65);
        boolean boolean93 = spreadsheetDate18.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate65);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-April-1900" + "'", str8.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-April-1900" + "'", str21.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-April-1900" + "'", str32.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-1900" + "'", str38.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9 + "'", int41 == 9);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "9-April-1900" + "'", str50.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "9-April-1900" + "'", str55.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "9-April-1900" + "'", str61.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "9-April-1900" + "'", str68.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "9-April-1900" + "'", str72.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "9-April-1900" + "'", str79.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "9-April-1900" + "'", str85.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 9 + "'", int88 == 9);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
        org.junit.Assert.assertNotNull(serialDate91);
        org.junit.Assert.assertNotNull(serialDate92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        boolean boolean3 = timeSeries2.getNotify();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 0);
        int int7 = month6.getMonth();
        java.lang.String str8 = month6.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        long long10 = month6.getFirstMillisecond();
        java.lang.String[] strArray11 = org.jfree.data.time.SerialDate.getMonths();
        int int12 = month6.compareTo((java.lang.Object) strArray11);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 0" + "'", str8.equals("October 0"));
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62143689600000L) + "'", long10 == (-62143689600000L));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = year1.getSerialIndex();
        java.lang.String str3 = year1.toString();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long9 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str14 = spreadsheetDate13.toString();
        boolean boolean15 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str18 = spreadsheetDate17.toString();
        spreadsheetDate17.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str25 = spreadsheetDate24.toString();
        boolean boolean26 = spreadsheetDate22.isOn((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str31 = spreadsheetDate30.toString();
        boolean boolean32 = spreadsheetDate28.isOn((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean33 = spreadsheetDate24.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        int int34 = spreadsheetDate30.getDayOfMonth();
        boolean boolean35 = spreadsheetDate11.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, (org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean36 = fixedMillisecond8.equals((java.lang.Object) spreadsheetDate17);
        boolean boolean37 = day6.equals((java.lang.Object) fixedMillisecond8);
        java.lang.Class<?> wildcardClass38 = fixedMillisecond8.getClass();
        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass38);
        java.io.InputStream inputStream40 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass38);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long45 = fixedMillisecond44.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str50 = spreadsheetDate49.toString();
        boolean boolean51 = spreadsheetDate47.isOn((org.jfree.data.time.SerialDate) spreadsheetDate49);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str54 = spreadsheetDate53.toString();
        spreadsheetDate53.setDescription("9-April-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str61 = spreadsheetDate60.toString();
        boolean boolean62 = spreadsheetDate58.isOn((org.jfree.data.time.SerialDate) spreadsheetDate60);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str67 = spreadsheetDate66.toString();
        boolean boolean68 = spreadsheetDate64.isOn((org.jfree.data.time.SerialDate) spreadsheetDate66);
        boolean boolean69 = spreadsheetDate60.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate66);
        int int70 = spreadsheetDate66.getDayOfMonth();
        boolean boolean71 = spreadsheetDate47.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate53, (org.jfree.data.time.SerialDate) spreadsheetDate66);
        boolean boolean72 = fixedMillisecond44.equals((java.lang.Object) spreadsheetDate53);
        boolean boolean73 = day42.equals((java.lang.Object) fixedMillisecond44);
        java.lang.Class<?> wildcardClass74 = fixedMillisecond44.getClass();
        java.io.InputStream inputStream75 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("9-April-1900", (java.lang.Class) wildcardClass74);
        java.lang.Class class76 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass74);
        java.lang.Object obj77 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("org.jfree.data.time.TimePeriodFormatException: ", (java.lang.Class) wildcardClass38, class76);
        org.jfree.data.time.TimeSeries timeSeries78 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year1, class76);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = timeSeries78.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9-April-1900" + "'", str14.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "9-April-1900" + "'", str18.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "9-April-1900" + "'", str25.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "9-April-1900" + "'", str31.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 9 + "'", int34 == 9);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertNotNull(inputStream40);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "9-April-1900" + "'", str50.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "9-April-1900" + "'", str54.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "9-April-1900" + "'", str61.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "9-April-1900" + "'", str67.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 9 + "'", int70 == 9);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(wildcardClass74);
        org.junit.Assert.assertNull(inputStream75);
        org.junit.Assert.assertNotNull(class76);
        org.junit.Assert.assertNull(obj77);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str3 = spreadsheetDate2.toString();
        spreadsheetDate2.setDescription("9-April-1900");
        int int6 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        java.lang.String str10 = spreadsheetDate9.toString();
        spreadsheetDate9.setDescription("9-April-1900");
        boolean boolean13 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9-April-1900" + "'", str3.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-April-1900" + "'", str10.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, class4);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries2.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 1);
        java.lang.String str10 = timeSeries6.getDescription();
        java.lang.String str11 = timeSeries6.getDescription();
        timeSeries6.fireSeriesChanged();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = null;
        try {
            timeSeries6.add(timeSeriesDataItem13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        int int3 = spreadsheetDate2.getYYYY();
        try {
            org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths((-457), (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
    }
}

