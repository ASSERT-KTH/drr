import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        timeSeries4.setMaximumItemAge((long) (byte) 10);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(7);
        int int11 = spreadsheetDate10.getMonth();
        int int12 = spreadsheetDate10.getYYYY();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, 100.0d);
        try {
            java.lang.Number number17 = timeSeries4.getValue(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.lang.Class class0 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean5 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        java.util.Date date6 = spreadsheetDate2.toDate();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date6, timeZone8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date6, timeZone10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean16 = spreadsheetDate13.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        java.util.Date date17 = spreadsheetDate13.toDate();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17, timeZone19);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date6, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.previous();
        org.jfree.data.time.Year year23 = month21.getYear();
        org.jfree.data.time.Year year24 = month21.getYear();
        java.lang.String str25 = year24.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year24.next();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1900" + "'", str25.equals("1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(8, 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, 0.0d);
        timeSeries4.setKey((java.lang.Comparable) 0.0d);
        int int11 = timeSeries4.getMaximumItemCount();
        java.util.Collection collection12 = timeSeries4.getTimePeriods();
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
        org.junit.Assert.assertNotNull(collection12);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) serialDate5);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str5 = timeSeries4.getDescription();
        boolean boolean6 = timeSeries4.isEmpty();
        java.lang.String str7 = timeSeries4.getDomainDescription();
        java.util.List list8 = timeSeries4.getItems();
        timeSeries4.clear();
        java.lang.Class class10 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean15 = spreadsheetDate12.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date16 = spreadsheetDate12.toDate();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date16, timeZone18);
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date16, timeZone20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean26 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        java.util.Date date27 = spreadsheetDate23.toDate();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date27);
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date27, timeZone29);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date16, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month31.previous();
        org.jfree.data.time.Year year33 = month31.getYear();
        org.jfree.data.time.Year year34 = month31.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month31.next();
        java.lang.Number number36 = timeSeries4.getValue(regularTimePeriod35);
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(year33);
        org.junit.Assert.assertNotNull(year34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(number36);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        int int2 = spreadsheetDate1.getDayOfWeek();
        boolean boolean4 = spreadsheetDate1.equals((java.lang.Object) 5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean9 = spreadsheetDate6.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int10 = spreadsheetDate6.getMonth();
        boolean boolean11 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate1.getNearestDayOfWeek(1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean5 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
        int int9 = spreadsheetDate8.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(7);
        int int12 = spreadsheetDate11.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean17 = spreadsheetDate14.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean22 = spreadsheetDate19.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean23 = spreadsheetDate16.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(7);
        int int27 = spreadsheetDate26.getMonth();
        int int28 = spreadsheetDate26.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(7);
        int int31 = spreadsheetDate30.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean36 = spreadsheetDate33.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean38 = spreadsheetDate26.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate30, (org.jfree.data.time.SerialDate) spreadsheetDate33, (int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean41 = spreadsheetDate11.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate16, serialDate39, (-1));
        boolean boolean42 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(7);
        int int45 = spreadsheetDate44.getMonth();
        int int46 = spreadsheetDate44.getYYYY();
        int int47 = spreadsheetDate44.toSerial();
        boolean boolean48 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, (org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 7 + "'", int12 == 7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1900 + "'", int28 == 1900);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 7 + "'", int31 == 7);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1900 + "'", int46 == 1900);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 7 + "'", int47 == 7);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str5 = timeSeries4.getDescription();
        boolean boolean6 = timeSeries4.isEmpty();
        java.lang.String str7 = timeSeries4.getDomainDescription();
        long long8 = timeSeries4.getMaximumItemAge();
        java.lang.String str9 = timeSeries4.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        java.lang.Class class12 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean17 = spreadsheetDate14.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        java.util.Date date18 = spreadsheetDate14.toDate();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date18, timeZone20);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date18, timeZone22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean28 = spreadsheetDate25.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        java.util.Date date29 = spreadsheetDate25.toDate();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date29);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date29, timeZone31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date18, timeZone31);
        boolean boolean34 = timeSeries11.equals((java.lang.Object) month33);
        org.jfree.data.time.Year year35 = month33.getYear();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year35, (double) (-2208527999814L), false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(year35);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str5 = timeSeries4.getDescription();
        boolean boolean6 = timeSeries4.isEmpty();
        java.lang.String str7 = timeSeries4.getDomainDescription();
        java.util.List list8 = timeSeries4.getItems();
        java.lang.Object obj9 = timeSeries4.clone();
        timeSeries4.setDomainDescription("Value");
        timeSeries4.fireSeriesChanged();
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        timeSeries4.setMaximumItemAge((long) (byte) 10);
        timeSeries4.clear();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries4.removeChangeListener(seriesChangeListener8);
        java.lang.Class class10 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean15 = spreadsheetDate12.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date16 = spreadsheetDate12.toDate();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date16, timeZone18);
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date16, timeZone20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean26 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        java.util.Date date27 = spreadsheetDate23.toDate();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date27);
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date27, timeZone29);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date16, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month31.previous();
        org.jfree.data.time.Year year33 = month31.getYear();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries35.createCopy((int) 'a', (int) (byte) 100);
        timeSeries38.setMaximumItemAge((long) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(7);
        int int43 = spreadsheetDate42.getMonth();
        int int44 = spreadsheetDate42.getYYYY();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate42);
        boolean boolean47 = day45.equals((java.lang.Object) 11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean52 = spreadsheetDate49.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate51);
        java.util.Date date53 = spreadsheetDate49.toDate();
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(date53);
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date53, timeZone55);
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries38.createCopy((org.jfree.data.time.RegularTimePeriod) day45, (org.jfree.data.time.RegularTimePeriod) year56);
        int int58 = day45.getYear();
        boolean boolean59 = year33.equals((java.lang.Object) day45);
        timeSeries4.setKey((java.lang.Comparable) day45);
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(year33);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1900 + "'", int44 == 1900);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1900 + "'", int58 == 1900);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        java.util.Date date4 = spreadsheetDate1.toDate();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(7);
        int int8 = spreadsheetDate7.getMonth();
        int int9 = spreadsheetDate7.getYYYY();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate7);
        boolean boolean12 = day10.equals((java.lang.Object) 11);
        int int13 = day10.getMonth();
        int int14 = day10.getMonth();
        boolean boolean15 = month5.equals((java.lang.Object) day10);
        java.lang.Object obj16 = null;
        boolean boolean17 = month5.equals(obj16);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1900 + "'", int9 == 1900);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        timeSeries1.setNotify(true);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(7);
        int int6 = spreadsheetDate5.getMonth();
        int int7 = spreadsheetDate5.getYYYY();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(7);
        int int11 = spreadsheetDate10.getMonth();
        int int12 = spreadsheetDate10.getYYYY();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day13);
        java.lang.String str15 = timeSeries14.getDescription();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries17.createCopy((int) 'a', (int) (byte) 100);
        timeSeries20.setMaximumItemAge((long) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(7);
        int int25 = spreadsheetDate24.getMonth();
        int int26 = spreadsheetDate24.getYYYY();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean29 = day27.equals((java.lang.Object) 11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean34 = spreadsheetDate31.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate33);
        java.util.Date date35 = spreadsheetDate31.toDate();
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date35, timeZone37);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) day27, (org.jfree.data.time.RegularTimePeriod) year38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean44 = spreadsheetDate41.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate43);
        java.util.Date date45 = spreadsheetDate41.toDate();
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(date45);
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date45, timeZone47);
        java.lang.String str49 = year48.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries39.createCopy((org.jfree.data.time.RegularTimePeriod) year48, (org.jfree.data.time.RegularTimePeriod) day54);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year48, (double) 7);
        java.lang.Object obj58 = null;
        boolean boolean59 = year48.equals(obj58);
        java.lang.String str60 = year48.toString();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1900 + "'", int7 == 1900);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1900 + "'", int26 == 1900);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1900" + "'", str49.equals("1900"));
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertNull(timeSeriesDataItem57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "1900" + "'", str60.equals("1900"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(7);
        int int6 = spreadsheetDate5.getMonth();
        int int7 = spreadsheetDate5.getYYYY();
        boolean boolean8 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean10 = spreadsheetDate1.equals((java.lang.Object) "Value");
        java.util.Date date11 = spreadsheetDate1.toDate();
        int int12 = spreadsheetDate1.getYYYY();
        java.lang.String str13 = spreadsheetDate1.getDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1900 + "'", int7 == 1900);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        boolean boolean6 = day4.equals((java.lang.Object) 11);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries8.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str12 = timeSeries11.getDescription();
        boolean boolean13 = timeSeries11.isEmpty();
        int int14 = day4.compareTo((java.lang.Object) timeSeries11);
        try {
            org.jfree.data.time.TimeSeries timeSeries17 = timeSeries11.createCopy(0, (-447));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str5 = timeSeries4.getDescription();
        boolean boolean6 = timeSeries4.isEmpty();
        java.lang.String str7 = timeSeries4.getDomainDescription();
        java.util.List list8 = timeSeries4.getItems();
        timeSeries4.setDomainDescription("ERROR : Relative To String");
        int int11 = timeSeries4.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries13.createCopy((int) 'a', (int) (byte) 100);
        timeSeries16.setMaximumItemAge((long) (byte) 10);
        timeSeries16.clear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean24 = spreadsheetDate21.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate23);
        java.util.Date date25 = spreadsheetDate21.toDate();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date25, timeZone27);
        java.lang.String str29 = year28.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year28, (java.lang.Number) 9999);
        timeSeries16.fireSeriesChanged();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = timeSeries16.getNextTimePeriod();
        timeSeries4.setKey((java.lang.Comparable) regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1900" + "'", str29.equals("1900"));
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean5 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
        int int9 = spreadsheetDate8.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(7);
        int int12 = spreadsheetDate11.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean17 = spreadsheetDate14.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean22 = spreadsheetDate19.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean23 = spreadsheetDate16.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(7);
        int int27 = spreadsheetDate26.getMonth();
        int int28 = spreadsheetDate26.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(7);
        int int31 = spreadsheetDate30.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean36 = spreadsheetDate33.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean38 = spreadsheetDate26.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate30, (org.jfree.data.time.SerialDate) spreadsheetDate33, (int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean41 = spreadsheetDate11.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate16, serialDate39, (-1));
        boolean boolean42 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(7);
        int int45 = spreadsheetDate44.getMonth();
        int int46 = spreadsheetDate44.getYYYY();
        int int47 = spreadsheetDate44.toSerial();
        boolean boolean48 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, (org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(7);
        int int51 = spreadsheetDate50.getMonth();
        int int52 = spreadsheetDate50.getYYYY();
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate50);
        boolean boolean54 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate50);
        java.util.Date date55 = spreadsheetDate50.toDate();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 7 + "'", int12 == 7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1900 + "'", int28 == 1900);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 7 + "'", int31 == 7);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1900 + "'", int46 == 1900);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 7 + "'", int47 == 7);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1900 + "'", int52 == 1900);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(date55);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        int int3 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(7);
        int int6 = spreadsheetDate5.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean11 = spreadsheetDate8.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean16 = spreadsheetDate13.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate10.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(7);
        int int21 = spreadsheetDate20.getMonth();
        int int22 = spreadsheetDate20.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(7);
        int int25 = spreadsheetDate24.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean30 = spreadsheetDate27.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        boolean boolean32 = spreadsheetDate20.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate27, (int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean35 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, serialDate33, (-1));
        boolean boolean36 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate37);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1900 + "'", int22 == 1900);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 7 + "'", int25 == 7);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(serialDate37);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        boolean boolean6 = day4.equals((java.lang.Object) 11);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries8.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str12 = timeSeries11.getDescription();
        boolean boolean13 = timeSeries11.isEmpty();
        int int14 = day4.compareTo((java.lang.Object) timeSeries11);
        long long15 = day4.getSerialIndex();
        int int17 = day4.compareTo((java.lang.Object) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 7L + "'", long15 == 7L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str5 = timeSeries4.getDescription();
        boolean boolean6 = timeSeries4.isEmpty();
        java.lang.String str7 = timeSeries4.getDomainDescription();
        java.util.List list8 = timeSeries4.getItems();
        timeSeries4.setDomainDescription("ERROR : Relative To String");
        int int11 = timeSeries4.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries4.createCopy(0, (int) 'a');
        java.lang.String str15 = timeSeries4.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        java.lang.Class class18 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean23 = spreadsheetDate20.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        java.util.Date date24 = spreadsheetDate20.toDate();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date24, timeZone26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date24, timeZone28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean34 = spreadsheetDate31.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate33);
        java.util.Date date35 = spreadsheetDate31.toDate();
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date35, timeZone37);
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date24, timeZone37);
        boolean boolean40 = timeSeries17.equals((java.lang.Object) month39);
        org.jfree.data.time.Year year41 = month39.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year41);
        java.lang.Object obj43 = timeSeries4.clone();
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Value" + "'", str15.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(year41);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertNotNull(obj43);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean4 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.util.Date date5 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date5, timeZone7);
        java.lang.String str9 = year8.toString();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy((int) 'a', (int) (byte) 100);
        timeSeries14.setMaximumItemAge((long) (byte) 10);
        java.lang.String str17 = timeSeries14.getDescription();
        boolean boolean18 = year8.equals((java.lang.Object) timeSeries14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(7);
        int int21 = spreadsheetDate20.getMonth();
        int int22 = spreadsheetDate20.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(7);
        int int25 = spreadsheetDate24.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean30 = spreadsheetDate27.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        boolean boolean32 = spreadsheetDate20.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate27, (int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean37 = spreadsheetDate34.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate36);
        java.util.Date date38 = spreadsheetDate34.toDate();
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance(date38);
        int int40 = spreadsheetDate24.compare(serialDate39);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(7);
        int int43 = spreadsheetDate42.getMonth();
        int int44 = spreadsheetDate42.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(7);
        int int47 = spreadsheetDate46.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean52 = spreadsheetDate49.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate51);
        boolean boolean54 = spreadsheetDate42.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate46, (org.jfree.data.time.SerialDate) spreadsheetDate49, (int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean59 = spreadsheetDate56.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate58);
        java.util.Date date60 = spreadsheetDate56.toDate();
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance(date60);
        int int62 = spreadsheetDate46.compare(serialDate61);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(7);
        int int65 = spreadsheetDate64.getMonth();
        int int66 = spreadsheetDate64.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(7);
        int int69 = spreadsheetDate68.getMonth();
        int int70 = spreadsheetDate68.getYYYY();
        boolean boolean71 = spreadsheetDate64.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate68);
        boolean boolean73 = spreadsheetDate24.isInRange(serialDate61, (org.jfree.data.time.SerialDate) spreadsheetDate68, (-1));
        int int74 = year8.compareTo((java.lang.Object) boolean73);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1900" + "'", str9.equals("1900"));
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1900 + "'", int22 == 1900);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 7 + "'", int25 == 7);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1900 + "'", int44 == 1900);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 7 + "'", int47 == 7);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1900 + "'", int66 == 1900);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1900 + "'", int70 == 1900);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.addChangeListener(seriesChangeListener5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries8.createCopy((int) 'a', (int) (byte) 100);
        java.util.List list12 = timeSeries11.getItems();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) 'a', (int) (byte) 100);
        timeSeries17.setMaximumItemAge((long) (byte) 10);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener20);
        java.util.Collection collection22 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries24.createCopy((int) 'a', (int) (byte) 100);
        timeSeries27.setMaximumItemAge((long) (byte) 10);
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries27.addPropertyChangeListener(propertyChangeListener30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(7);
        int int34 = spreadsheetDate33.getMonth();
        int int35 = spreadsheetDate33.getYYYY();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day36, 100.0d);
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) day36, (java.lang.Number) 10L);
        int int41 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day36);
        long long42 = day36.getFirstMillisecond();
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1900 + "'", int35 == 1900);
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-2208528000000L) + "'", long42 == (-2208528000000L));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        java.util.Date date4 = spreadsheetDate1.toDate();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month5.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        boolean boolean6 = day4.equals((java.lang.Object) 11);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries8.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str12 = timeSeries11.getDescription();
        boolean boolean13 = timeSeries11.isEmpty();
        int int14 = day4.compareTo((java.lang.Object) timeSeries11);
        int int15 = day4.getYear();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = day4.getLastMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1900 + "'", int15 == 1900);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean4 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.util.Date date5 = spreadsheetDate1.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date5);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("January 1900");
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        int int2 = spreadsheetDate1.getMonth();
//        int int3 = spreadsheetDate1.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(7);
//        int int6 = spreadsheetDate5.getDayOfWeek();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean11 = spreadsheetDate8.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        boolean boolean13 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate5, (org.jfree.data.time.SerialDate) spreadsheetDate8, (int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean18 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        java.util.Date date19 = spreadsheetDate15.toDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
//        int int21 = spreadsheetDate5.compare(serialDate20);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(7);
//        int int24 = spreadsheetDate23.getMonth();
//        int int25 = spreadsheetDate23.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(7);
//        int int28 = spreadsheetDate27.getDayOfWeek();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean33 = spreadsheetDate30.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate32);
//        boolean boolean35 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate27, (org.jfree.data.time.SerialDate) spreadsheetDate30, (int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean40 = spreadsheetDate37.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate39);
//        java.util.Date date41 = spreadsheetDate37.toDate();
//        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance(date41);
//        int int43 = spreadsheetDate27.compare(serialDate42);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(7);
//        int int46 = spreadsheetDate45.getMonth();
//        int int47 = spreadsheetDate45.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(7);
//        int int50 = spreadsheetDate49.getMonth();
//        int int51 = spreadsheetDate49.getYYYY();
//        boolean boolean52 = spreadsheetDate45.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate49);
//        boolean boolean54 = spreadsheetDate5.isInRange(serialDate42, (org.jfree.data.time.SerialDate) spreadsheetDate49, (-1));
//        int int55 = spreadsheetDate5.toSerial();
//        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
//        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries57.createCopy((int) 'a', (int) (byte) 100);
//        java.lang.String str61 = timeSeries60.getDescription();
//        boolean boolean62 = timeSeries60.isEmpty();
//        java.lang.String str63 = timeSeries60.getDomainDescription();
//        java.lang.Class class64 = timeSeries60.getTimePeriodClass();
//        java.lang.Class class65 = org.jfree.data.time.RegularTimePeriod.downsize(class64);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate(7);
//        int int68 = spreadsheetDate67.getMonth();
//        int int69 = spreadsheetDate67.getYYYY();
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate67);
//        int int71 = day70.getYear();
//        java.util.Date date72 = day70.getStart();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean77 = spreadsheetDate74.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate76);
//        java.util.Date date78 = spreadsheetDate74.toDate();
//        org.jfree.data.time.SerialDate serialDate79 = org.jfree.data.time.SerialDate.createInstance(date78);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond80 = new org.jfree.data.time.FixedMillisecond(date78);
//        java.util.Calendar calendar81 = null;
//        fixedMillisecond80.peg(calendar81);
//        long long83 = fixedMillisecond80.getMiddleMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate85 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate87 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean88 = spreadsheetDate85.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate87);
//        java.util.Date date89 = spreadsheetDate85.toDate();
//        org.jfree.data.time.SerialDate serialDate90 = org.jfree.data.time.SerialDate.createInstance(date89);
//        java.util.TimeZone timeZone91 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year92 = new org.jfree.data.time.Year(date89, timeZone91);
//        boolean boolean93 = fixedMillisecond80.equals((java.lang.Object) timeZone91);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = org.jfree.data.time.RegularTimePeriod.createInstance(class64, date72, timeZone91);
//        java.lang.Class class95 = org.jfree.data.time.RegularTimePeriod.downsize(class64);
//        org.jfree.data.time.TimeSeries timeSeries96 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate5, class64);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod98 = timeSeries96.getTimePeriod((-571));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1900 + "'", int25 == 1900);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 7 + "'", int28 == 7);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1900 + "'", int47 == 1900);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1900 + "'", int51 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 7 + "'", int55 == 7);
//        org.junit.Assert.assertNotNull(timeSeries60);
//        org.junit.Assert.assertNull(str61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "Time" + "'", str63.equals("Time"));
//        org.junit.Assert.assertNotNull(class64);
//        org.junit.Assert.assertNotNull(class65);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1900 + "'", int69 == 1900);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1900 + "'", int71 == 1900);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertNotNull(serialDate79);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + (-2208527999211L) + "'", long83 == (-2208527999211L));
//        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
//        org.junit.Assert.assertNotNull(date89);
//        org.junit.Assert.assertNotNull(serialDate90);
//        org.junit.Assert.assertNotNull(timeZone91);
//        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod94);
//        org.junit.Assert.assertNotNull(class95);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        timeSeries4.setMaximumItemAge((long) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
        int int9 = spreadsheetDate8.getMonth();
        int int10 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean13 = day11.equals((java.lang.Object) 11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean18 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.util.Date date19 = spreadsheetDate15.toDate();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date19, timeZone21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) year22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean28 = spreadsheetDate25.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        java.util.Date date29 = spreadsheetDate25.toDate();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date29);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date29, timeZone31);
        java.lang.String str33 = year32.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) year32, (org.jfree.data.time.RegularTimePeriod) day38);
        long long40 = year32.getSerialIndex();
        java.lang.String str41 = year32.toString();
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1900" + "'", str33.equals("1900"));
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1900L + "'", long40 == 1900L);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1900" + "'", str41.equals("1900"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        timeSeries1.setNotify(true);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(7);
        int int6 = spreadsheetDate5.getMonth();
        int int7 = spreadsheetDate5.getYYYY();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(7);
        int int11 = spreadsheetDate10.getMonth();
        int int12 = spreadsheetDate10.getYYYY();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day13);
        java.lang.String str15 = timeSeries14.getDescription();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries17.createCopy((int) 'a', (int) (byte) 100);
        timeSeries20.setMaximumItemAge((long) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(7);
        int int25 = spreadsheetDate24.getMonth();
        int int26 = spreadsheetDate24.getYYYY();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean29 = day27.equals((java.lang.Object) 11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean34 = spreadsheetDate31.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate33);
        java.util.Date date35 = spreadsheetDate31.toDate();
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date35, timeZone37);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) day27, (org.jfree.data.time.RegularTimePeriod) year38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean44 = spreadsheetDate41.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate43);
        java.util.Date date45 = spreadsheetDate41.toDate();
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(date45);
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date45, timeZone47);
        java.lang.String str49 = year48.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries39.createCopy((org.jfree.data.time.RegularTimePeriod) year48, (org.jfree.data.time.RegularTimePeriod) day54);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year48, (double) 7);
        java.lang.String str58 = timeSeries14.getDescription();
        int int59 = timeSeries14.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1900 + "'", int7 == 1900);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1900 + "'", int26 == 1900);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1900" + "'", str49.equals("1900"));
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertNull(timeSeriesDataItem57);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2147483647 + "'", int59 == 2147483647);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        int int2 = spreadsheetDate1.getDayOfWeek();
        boolean boolean4 = spreadsheetDate1.equals((java.lang.Object) 5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean9 = spreadsheetDate6.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int10 = spreadsheetDate6.getMonth();
        boolean boolean11 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int12 = spreadsheetDate6.getMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Preceding");
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean4 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        java.util.Date date5 = spreadsheetDate1.toDate();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date5);
//        java.util.Calendar calendar8 = null;
//        fixedMillisecond7.peg(calendar8);
//        long long10 = fixedMillisecond7.getFirstMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean15 = spreadsheetDate12.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        java.util.Date date16 = spreadsheetDate12.toDate();
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date16);
//        java.util.Calendar calendar19 = null;
//        fixedMillisecond18.peg(calendar19);
//        long long21 = fixedMillisecond18.getFirstMillisecond();
//        boolean boolean22 = fixedMillisecond7.equals((java.lang.Object) fixedMillisecond18);
//        long long23 = fixedMillisecond18.getMiddleMillisecond();
//        java.lang.Object obj24 = null;
//        boolean boolean25 = fixedMillisecond18.equals(obj24);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2208527999508L) + "'", long10 == (-2208527999508L));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-2208527999507L) + "'", long21 == (-2208527999507L));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-2208527999507L) + "'", long23 == (-2208527999507L));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(8, 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, 0.0d);
        timeSeries4.setKey((java.lang.Comparable) 0.0d);
        java.lang.Class class11 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean16 = spreadsheetDate13.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        java.util.Date date17 = spreadsheetDate13.toDate();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17, timeZone19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date17, timeZone21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean27 = spreadsheetDate24.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        java.util.Date date28 = spreadsheetDate24.toDate();
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date28);
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date28, timeZone30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date17, timeZone30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month32.previous();
        org.jfree.data.time.Year year34 = month32.getYear();
        org.jfree.data.time.Year year35 = month32.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) (-1));
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries42.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str46 = timeSeries45.getDescription();
        boolean boolean47 = timeSeries45.isEmpty();
        java.lang.String str48 = timeSeries45.getDomainDescription();
        java.lang.Class class49 = timeSeries45.getTimePeriodClass();
        java.lang.Class class50 = org.jfree.data.time.RegularTimePeriod.downsize(class49);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "org.jfree.data.time.TimePeriodFormatException: Value", "hi!", class50);
        int int52 = timeSeriesDataItem37.compareTo((java.lang.Object) class50);
        try {
            timeSeries4.add(timeSeriesDataItem37);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(year34);
        org.junit.Assert.assertNotNull(year35);
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Time" + "'", str48.equals("Time"));
        org.junit.Assert.assertNotNull(class49);
        org.junit.Assert.assertNotNull(class50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        java.util.Date date4 = spreadsheetDate1.toDate();
        int int5 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(7);
        int int8 = spreadsheetDate7.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean13 = spreadsheetDate10.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean18 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate12.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(7);
        int int23 = spreadsheetDate22.getMonth();
        int int24 = spreadsheetDate22.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(7);
        int int27 = spreadsheetDate26.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean32 = spreadsheetDate29.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean34 = spreadsheetDate22.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate26, (org.jfree.data.time.SerialDate) spreadsheetDate29, (int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean37 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, serialDate35, (-1));
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(7);
        int int40 = spreadsheetDate39.getMonth();
        int int41 = spreadsheetDate39.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(7);
        int int44 = spreadsheetDate43.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean49 = spreadsheetDate46.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate48);
        boolean boolean51 = spreadsheetDate39.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate43, (org.jfree.data.time.SerialDate) spreadsheetDate46, (int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean56 = spreadsheetDate53.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate55);
        java.util.Date date57 = spreadsheetDate53.toDate();
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.createInstance(date57);
        int int59 = spreadsheetDate43.compare(serialDate58);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate62);
        int int64 = spreadsheetDate62.toSerial();
        boolean boolean66 = spreadsheetDate7.isInRange(serialDate58, (org.jfree.data.time.SerialDate) spreadsheetDate62, (int) '4');
        boolean boolean67 = spreadsheetDate1.isAfter(serialDate58);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1900 + "'", int5 == 1900);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 7 + "'", int8 == 7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1900 + "'", int24 == 1900);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 7 + "'", int27 == 7);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1900 + "'", int41 == 1900);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 7 + "'", int44 == 7);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 7 + "'", int64 == 7);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        timeSeries4.setMaximumItemAge((long) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
        int int9 = spreadsheetDate8.getMonth();
        int int10 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean13 = day11.equals((java.lang.Object) 11);
        int int14 = day11.getMonth();
        int int15 = day11.getMonth();
        int int16 = day11.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (double) (short) -1);
        boolean boolean20 = day11.equals((java.lang.Object) (-1L));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 10);
        java.lang.Number number23 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, number23);
        java.lang.Object obj25 = null;
        boolean boolean26 = timeSeriesDataItem24.equals(obj25);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries28.createCopy((int) 'a', (int) (byte) 100);
        timeSeries31.setMaximumItemAge((long) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(7);
        int int36 = spreadsheetDate35.getMonth();
        int int37 = spreadsheetDate35.getYYYY();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean40 = day38.equals((java.lang.Object) 11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean45 = spreadsheetDate42.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate44);
        java.util.Date date46 = spreadsheetDate42.toDate();
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance(date46);
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date46, timeZone48);
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries31.createCopy((org.jfree.data.time.RegularTimePeriod) day38, (org.jfree.data.time.RegularTimePeriod) year49);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean55 = spreadsheetDate52.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate54);
        java.util.Date date56 = spreadsheetDate52.toDate();
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(date56);
        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date56, timeZone58);
        java.lang.String str60 = year59.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate63);
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate63);
        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries50.createCopy((org.jfree.data.time.RegularTimePeriod) year59, (org.jfree.data.time.RegularTimePeriod) day65);
        java.lang.Class class67 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean72 = spreadsheetDate69.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate71);
        java.util.Date date73 = spreadsheetDate69.toDate();
        org.jfree.data.time.SerialDate serialDate74 = org.jfree.data.time.SerialDate.createInstance(date73);
        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year(date73, timeZone75);
        java.util.TimeZone timeZone77 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance(class67, date73, timeZone77);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate80 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate82 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean83 = spreadsheetDate80.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate82);
        java.util.Date date84 = spreadsheetDate80.toDate();
        org.jfree.data.time.SerialDate serialDate85 = org.jfree.data.time.SerialDate.createInstance(date84);
        java.util.TimeZone timeZone86 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year87 = new org.jfree.data.time.Year(date84, timeZone86);
        org.jfree.data.time.Month month88 = new org.jfree.data.time.Month(date73, timeZone86);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = month88.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem91 = timeSeries66.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month88, (java.lang.Number) (-1.0f));
        org.jfree.data.time.Year year92 = month88.getYear();
        int int93 = timeSeriesDataItem24.compareTo((java.lang.Object) year92);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = year92.previous();
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1900 + "'", int37 == 1900);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "1900" + "'", str60.equals("1900"));
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(timeSeries66);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertNotNull(timeZone75);
        org.junit.Assert.assertNotNull(timeZone77);
        org.junit.Assert.assertNull(regularTimePeriod78);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertNotNull(serialDate85);
        org.junit.Assert.assertNotNull(timeZone86);
        org.junit.Assert.assertNull(regularTimePeriod89);
        org.junit.Assert.assertNull(timeSeriesDataItem91);
        org.junit.Assert.assertNotNull(year92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 1 + "'", int93 == 1);
        org.junit.Assert.assertNull(regularTimePeriod94);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-2208527999276L));
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean4 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        java.util.Date date5 = spreadsheetDate1.toDate();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date5);
//        java.util.Calendar calendar8 = null;
//        fixedMillisecond7.peg(calendar8);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond7.getLastMillisecond(calendar10);
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond7.getMiddleMillisecond(calendar12);
//        java.lang.String str14 = fixedMillisecond7.toString();
//        java.lang.String str15 = fixedMillisecond7.toString();
//        java.lang.Class<?> wildcardClass16 = fixedMillisecond7.getClass();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-2208527999647L) + "'", long11 == (-2208527999647L));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-2208527999647L) + "'", long13 == (-2208527999647L));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Sat Jan 06 00:00:00 PST 1900" + "'", str14.equals("Sat Jan 06 00:00:00 PST 1900"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Sat Jan 06 00:00:00 PST 1900" + "'", str15.equals("Sat Jan 06 00:00:00 PST 1900"));
//        org.junit.Assert.assertNotNull(wildcardClass16);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        int int2 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean7 = spreadsheetDate4.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean12 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean13 = spreadsheetDate6.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        int int17 = spreadsheetDate16.getMonth();
        int int18 = spreadsheetDate16.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(7);
        int int21 = spreadsheetDate20.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean26 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean28 = spreadsheetDate16.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate20, (org.jfree.data.time.SerialDate) spreadsheetDate23, (int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean31 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, serialDate29, (-1));
        java.util.Date date32 = spreadsheetDate1.toDate();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1900 + "'", int18 == 1900);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 7 + "'", int21 == 7);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date32);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean4 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        java.util.Date date5 = spreadsheetDate1.toDate();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date5);
//        java.util.Calendar calendar8 = null;
//        fixedMillisecond7.peg(calendar8);
//        long long10 = fixedMillisecond7.getFirstMillisecond();
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond7.getFirstMillisecond(calendar11);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2208527999542L) + "'", long10 == (-2208527999542L));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2208527999542L) + "'", long12 == (-2208527999542L));
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        boolean boolean6 = day4.equals((java.lang.Object) 11);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries8.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str12 = timeSeries11.getDescription();
        boolean boolean13 = timeSeries11.isEmpty();
        int int14 = day4.compareTo((java.lang.Object) timeSeries11);
        long long15 = day4.getSerialIndex();
        long long16 = day4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day4.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (-2208527999495L));
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        java.util.Date date22 = fixedMillisecond21.getTime();
        boolean boolean23 = day4.equals((java.lang.Object) date22);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 7L + "'", long15 == 7L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 7L + "'", long16 == 7L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean4 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.util.Date date5 = spreadsheetDate1.toDate();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.Year year7 = month6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries10.createCopy((int) 'a', (int) (byte) 100);
        timeSeries13.setMaximumItemAge((long) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        int int18 = spreadsheetDate17.getMonth();
        int int19 = spreadsheetDate17.getYYYY();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean22 = day20.equals((java.lang.Object) 11);
        int int23 = day20.getMonth();
        int int24 = day20.getMonth();
        int int25 = day20.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day20, (double) (short) -1);
        java.lang.String str28 = timeSeries13.getDescription();
        int int29 = year7.compareTo((java.lang.Object) timeSeries13);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1900 + "'", int19 == 1900);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.lang.Class class0 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean5 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        java.util.Date date6 = spreadsheetDate2.toDate();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date6, timeZone8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date6, timeZone10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean16 = spreadsheetDate13.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        java.util.Date date17 = spreadsheetDate13.toDate();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17, timeZone19);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date6, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.previous();
        org.jfree.data.time.Year year23 = month21.getYear();
        java.lang.Class<?> wildcardClass24 = year23.getClass();
        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(class25);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        timeSeries4.setMaximumItemAge((long) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
        int int9 = spreadsheetDate8.getMonth();
        int int10 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean13 = day11.equals((java.lang.Object) 11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean18 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.util.Date date19 = spreadsheetDate15.toDate();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date19, timeZone21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) year22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean28 = spreadsheetDate25.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        java.util.Date date29 = spreadsheetDate25.toDate();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date29);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date29, timeZone31);
        java.lang.String str33 = year32.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) year32, (org.jfree.data.time.RegularTimePeriod) day38);
        java.util.Calendar calendar40 = null;
        try {
            long long41 = day38.getLastMillisecond(calendar40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1900" + "'", str33.equals("1900"));
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(timeSeries39);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
//        java.lang.String str5 = timeSeries4.getDescription();
//        boolean boolean6 = timeSeries4.isEmpty();
//        java.lang.String str7 = timeSeries4.getDomainDescription();
//        java.util.List list8 = timeSeries4.getItems();
//        timeSeries4.setDomainDescription("ERROR : Relative To String");
//        int int11 = timeSeries4.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries4.createCopy(0, (int) 'a');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean19 = spreadsheetDate16.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        java.util.Date date20 = spreadsheetDate16.toDate();
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date20);
//        java.util.Calendar calendar23 = null;
//        fixedMillisecond22.peg(calendar23);
//        long long25 = fixedMillisecond22.getMiddleMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean30 = spreadsheetDate27.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
//        java.util.Date date31 = spreadsheetDate27.toDate();
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date31, timeZone33);
//        boolean boolean35 = fixedMillisecond22.equals((java.lang.Object) timeZone33);
//        java.util.Date date36 = fixedMillisecond22.getTime();
//        java.lang.Number number37 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        java.beans.PropertyChangeListener propertyChangeListener38 = null;
//        timeSeries14.addPropertyChangeListener(propertyChangeListener38);
//        timeSeries14.clear();
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-2208527999433L) + "'", long25 == (-2208527999433L));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNull(number37);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean7 = spreadsheetDate4.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(7);
        int int11 = spreadsheetDate10.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(7);
        int int14 = spreadsheetDate13.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean19 = spreadsheetDate16.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean24 = spreadsheetDate21.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate23);
        boolean boolean25 = spreadsheetDate18.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(7);
        int int29 = spreadsheetDate28.getMonth();
        int int30 = spreadsheetDate28.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(7);
        int int33 = spreadsheetDate32.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean38 = spreadsheetDate35.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate28.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate32, (org.jfree.data.time.SerialDate) spreadsheetDate35, (int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate28);
        boolean boolean43 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate18, serialDate41, (-1));
        boolean boolean44 = spreadsheetDate10.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(7);
        int int47 = spreadsheetDate46.getMonth();
        int int48 = spreadsheetDate46.getYYYY();
        int int49 = spreadsheetDate46.toSerial();
        boolean boolean50 = spreadsheetDate6.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, (org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(7);
        int int53 = spreadsheetDate52.getMonth();
        int int54 = spreadsheetDate52.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(7);
        int int57 = spreadsheetDate56.getMonth();
        int int58 = spreadsheetDate56.getYYYY();
        boolean boolean59 = spreadsheetDate52.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate56);
        org.jfree.data.time.SerialDate serialDate60 = spreadsheetDate6.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate56);
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.addYears((int) '4', serialDate60);
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate60);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 7 + "'", int14 == 7);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1900 + "'", int30 == 1900);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 7 + "'", int33 == 7);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1900 + "'", int48 == 1900);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 7 + "'", int49 == 7);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1900 + "'", int54 == 1900);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1900 + "'", int58 == 1900);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNotNull(serialDate62);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        timeSeries4.setMaximumItemAge((long) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
        int int9 = spreadsheetDate8.getMonth();
        int int10 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean13 = day11.equals((java.lang.Object) 11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean18 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.util.Date date19 = spreadsheetDate15.toDate();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date19, timeZone21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) year22);
        long long24 = year22.getSerialIndex();
        long long25 = year22.getLastMillisecond();
        java.util.Calendar calendar26 = null;
        try {
            long long27 = year22.getFirstMillisecond(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1900L + "'", long24 == 1900L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-2177424000001L) + "'", long25 == (-2177424000001L));
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        int int2 = spreadsheetDate1.getDayOfWeek();
//        java.util.Date date3 = spreadsheetDate1.toDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        long long5 = fixedMillisecond4.getSerialIndex();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = fixedMillisecond4.equals(obj6);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries9.createCopy((int) 'a', (int) (byte) 100);
//        java.util.List list13 = timeSeries12.getItems();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
//        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries15.createCopy((int) 'a', (int) (byte) 100);
//        timeSeries18.setMaximumItemAge((long) (byte) 10);
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timeSeries18.addPropertyChangeListener(propertyChangeListener21);
//        java.util.Collection collection23 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries18);
//        java.util.List list24 = timeSeries18.getItems();
//        java.lang.String str25 = timeSeries18.getDescription();
//        int int26 = fixedMillisecond4.compareTo((java.lang.Object) timeSeries18);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2208527999078L) + "'", long5 == (-2208527999078L));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(timeSeries12);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertNotNull(timeSeries18);
//        org.junit.Assert.assertNotNull(collection23);
//        org.junit.Assert.assertNotNull(list24);
//        org.junit.Assert.assertNull(str25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(7);
        int int6 = spreadsheetDate5.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean11 = spreadsheetDate8.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean13 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate5, (org.jfree.data.time.SerialDate) spreadsheetDate8, (int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean18 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.util.Date date19 = spreadsheetDate15.toDate();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        int int21 = spreadsheetDate5.compare(serialDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(7);
        int int24 = spreadsheetDate23.getMonth();
        int int25 = spreadsheetDate23.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(7);
        int int28 = spreadsheetDate27.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean33 = spreadsheetDate30.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate32);
        boolean boolean35 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate27, (org.jfree.data.time.SerialDate) spreadsheetDate30, (int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean40 = spreadsheetDate37.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate39);
        java.util.Date date41 = spreadsheetDate37.toDate();
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance(date41);
        int int43 = spreadsheetDate27.compare(serialDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(7);
        int int46 = spreadsheetDate45.getMonth();
        int int47 = spreadsheetDate45.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(7);
        int int50 = spreadsheetDate49.getMonth();
        int int51 = spreadsheetDate49.getYYYY();
        boolean boolean52 = spreadsheetDate45.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate49);
        boolean boolean54 = spreadsheetDate5.isInRange(serialDate42, (org.jfree.data.time.SerialDate) spreadsheetDate49, (-1));
        spreadsheetDate5.setDescription("June");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1900 + "'", int25 == 1900);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 7 + "'", int28 == 7);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1900 + "'", int47 == 1900);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1900 + "'", int51 == 1900);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean4 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        java.util.Date date5 = spreadsheetDate1.toDate();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date5);
//        java.util.Calendar calendar8 = null;
//        fixedMillisecond7.peg(calendar8);
//        long long10 = fixedMillisecond7.getFirstMillisecond();
//        long long11 = fixedMillisecond7.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2208527999869L) + "'", long10 == (-2208527999869L));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-2208527999869L) + "'", long11 == (-2208527999869L));
//    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean4 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        java.util.Date date5 = spreadsheetDate1.toDate();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date5);
//        java.util.Calendar calendar8 = null;
//        fixedMillisecond7.peg(calendar8);
//        long long10 = fixedMillisecond7.getMiddleMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean15 = spreadsheetDate12.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        java.util.Date date16 = spreadsheetDate12.toDate();
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date16);
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date16, timeZone18);
//        boolean boolean20 = fixedMillisecond7.equals((java.lang.Object) timeZone18);
//        java.util.Date date21 = fixedMillisecond7.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries24.createCopy((int) 'a', (int) (byte) 100);
//        java.lang.String str28 = timeSeries27.getDescription();
//        boolean boolean29 = timeSeries27.isEmpty();
//        java.lang.String str30 = timeSeries27.getDomainDescription();
//        java.lang.Class class31 = timeSeries27.getTimePeriodClass();
//        java.lang.Class class32 = org.jfree.data.time.RegularTimePeriod.downsize(class31);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(7);
//        int int35 = spreadsheetDate34.getMonth();
//        int int36 = spreadsheetDate34.getYYYY();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate34);
//        int int38 = day37.getYear();
//        java.util.Date date39 = day37.getStart();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean44 = spreadsheetDate41.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate43);
//        java.util.Date date45 = spreadsheetDate41.toDate();
//        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(date45);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date45);
//        java.util.Calendar calendar48 = null;
//        fixedMillisecond47.peg(calendar48);
//        long long50 = fixedMillisecond47.getMiddleMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean55 = spreadsheetDate52.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate54);
//        java.util.Date date56 = spreadsheetDate52.toDate();
//        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(date56);
//        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date56, timeZone58);
//        boolean boolean60 = fixedMillisecond47.equals((java.lang.Object) timeZone58);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date39, timeZone58);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean66 = spreadsheetDate63.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate65);
//        java.util.Date date67 = spreadsheetDate63.toDate();
//        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month(date67);
//        java.lang.Class class69 = null;
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate73 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean74 = spreadsheetDate71.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate73);
//        java.util.Date date75 = spreadsheetDate71.toDate();
//        org.jfree.data.time.SerialDate serialDate76 = org.jfree.data.time.SerialDate.createInstance(date75);
//        java.util.TimeZone timeZone77 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year(date75, timeZone77);
//        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance(class69, date75, timeZone79);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date67, timeZone79);
//        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year(date21, timeZone79);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond83 = new org.jfree.data.time.FixedMillisecond(date21);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2208527999850L) + "'", long10 == (-2208527999850L));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNull(str28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Time" + "'", str30.equals("Time"));
//        org.junit.Assert.assertNotNull(class31);
//        org.junit.Assert.assertNotNull(class32);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1900 + "'", int36 == 1900);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1900 + "'", int38 == 1900);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-2208527999841L) + "'", long50 == (-2208527999841L));
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertNotNull(timeZone58);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNotNull(serialDate76);
//        org.junit.Assert.assertNotNull(timeZone77);
//        org.junit.Assert.assertNotNull(timeZone79);
//        org.junit.Assert.assertNull(regularTimePeriod80);
//        org.junit.Assert.assertNotNull(regularTimePeriod81);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str10 = timeSeries9.getDescription();
        boolean boolean11 = timeSeries9.isEmpty();
        java.lang.String str12 = timeSeries9.getDomainDescription();
        java.util.List list13 = timeSeries9.getItems();
        timeSeries9.clear();
        boolean boolean15 = day4.equals((java.lang.Object) timeSeries9);
        int int16 = day4.getDayOfMonth();
        int int17 = day4.getMonth();
        int int18 = day4.getMonth();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(8, 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, 0.0d);
//        timeSeries4.setKey((java.lang.Comparable) 0.0d);
//        java.lang.Object obj11 = timeSeries4.clone();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean16 = spreadsheetDate13.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        java.util.Date date17 = spreadsheetDate13.toDate();
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date17);
//        java.util.Calendar calendar20 = null;
//        fixedMillisecond19.peg(calendar20);
//        long long22 = fixedMillisecond19.getMiddleMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean27 = spreadsheetDate24.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
//        java.util.Date date28 = spreadsheetDate24.toDate();
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date28);
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date28, timeZone30);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) timeZone30);
//        long long33 = fixedMillisecond19.getLastMillisecond();
//        int int34 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        java.lang.String str35 = timeSeries4.getDomainDescription();
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertNotNull(obj11);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-2208527999595L) + "'", long22 == (-2208527999595L));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-2208527999595L) + "'", long33 == (-2208527999595L));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Time" + "'", str35.equals("Time"));
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.removeChangeListener(seriesChangeListener5);
        timeSeries4.removeAgedItems((long) 2958465, true);
        java.lang.Class class10 = timeSeries4.getTimePeriodClass();
        timeSeries4.setMaximumItemAge((long) 8);
        long long13 = timeSeries4.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries15.createCopy((int) 'a', (int) (byte) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries18.addChangeListener(seriesChangeListener19);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries22.createCopy((int) 'a', (int) (byte) 100);
        java.util.List list26 = timeSeries25.getItems();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries28.createCopy((int) 'a', (int) (byte) 100);
        timeSeries31.setMaximumItemAge((long) (byte) 10);
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries31.addPropertyChangeListener(propertyChangeListener34);
        java.util.Collection collection36 = timeSeries25.getTimePeriodsUniqueToOtherSeries(timeSeries31);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries38.createCopy((int) 'a', (int) (byte) 100);
        timeSeries41.setMaximumItemAge((long) (byte) 10);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timeSeries41.addPropertyChangeListener(propertyChangeListener44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(7);
        int int48 = spreadsheetDate47.getMonth();
        int int49 = spreadsheetDate47.getYYYY();
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day50, 100.0d);
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) day50, (java.lang.Number) 10L);
        int int55 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) day50);
        int int56 = day50.getDayOfMonth();
        boolean boolean57 = timeSeries4.equals((java.lang.Object) int56);
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 8L + "'", long13 == 8L);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(collection36);
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1900 + "'", int49 == 1900);
        org.junit.Assert.assertNull(timeSeriesDataItem52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 6 + "'", int56 == 6);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str5 = timeSeries4.getDescription();
        java.lang.String str6 = timeSeries4.getRangeDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
        int int9 = spreadsheetDate8.getMonth();
        int int10 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean13 = day11.equals((java.lang.Object) 11);
        int int14 = day11.getMonth();
        org.jfree.data.time.SerialDate serialDate15 = day11.getSerialDate();
        int int16 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        boolean boolean17 = timeSeries4.isEmpty();
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.String str1 = fixedMillisecond0.toString();
//        long long2 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getFirstMillisecond(calendar3);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mon Jun 10 11:26:20 PDT 2019" + "'", str1.equals("Mon Jun 10 11:26:20 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191180624L + "'", long2 == 1560191180624L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560191180624L + "'", long4 == 1560191180624L);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        timeSeries4.setMaximumItemAge((long) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
        int int9 = spreadsheetDate8.getMonth();
        int int10 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean13 = day11.equals((java.lang.Object) 11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean18 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.util.Date date19 = spreadsheetDate15.toDate();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date19, timeZone21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) year22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day11.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day11.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day11.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day11.previous();
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(11, (int) (short) 1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "January");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        java.lang.Class class4 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean9 = spreadsheetDate6.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate8);
        java.util.Date date10 = spreadsheetDate6.toDate();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date10, timeZone12);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date10, timeZone14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean20 = spreadsheetDate17.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        java.util.Date date21 = spreadsheetDate17.toDate();
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date21);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21, timeZone23);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date10, timeZone23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.previous();
        org.jfree.data.time.Year year27 = month25.getYear();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year27, (java.lang.Number) (-2208527999273L));
        timeSeries1.setMaximumItemAge(7L);
        boolean boolean33 = timeSeries1.getNotify();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(year27);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "January");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        java.lang.Class class4 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean9 = spreadsheetDate6.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate8);
        java.util.Date date10 = spreadsheetDate6.toDate();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date10, timeZone12);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date10, timeZone14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean20 = spreadsheetDate17.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        java.util.Date date21 = spreadsheetDate17.toDate();
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date21);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21, timeZone23);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date10, timeZone23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.previous();
        org.jfree.data.time.Year year27 = month25.getYear();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year27, (java.lang.Number) (-2208527999273L));
        timeSeries1.setMaximumItemAge(7L);
        timeSeries1.clear();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(year27);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        timeSeries4.setMaximumItemAge((long) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
        int int9 = spreadsheetDate8.getMonth();
        int int10 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean13 = day11.equals((java.lang.Object) 11);
        int int14 = day11.getMonth();
        int int15 = day11.getMonth();
        int int16 = day11.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (double) (short) -1);
        java.lang.String str19 = timeSeries4.getDescription();
        java.lang.String str20 = timeSeries4.getDescription();
        int int21 = timeSeries4.getMaximumItemCount();
        timeSeries4.setMaximumItemCount((int) ' ');
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        java.lang.Class class26 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean31 = spreadsheetDate28.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        java.util.Date date32 = spreadsheetDate28.toDate();
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(date32);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date32, timeZone34);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date32, timeZone36);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean42 = spreadsheetDate39.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
        java.util.Date date43 = spreadsheetDate39.toDate();
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance(date43);
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date43, timeZone45);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date32, timeZone45);
        boolean boolean48 = timeSeries25.equals((java.lang.Object) month47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(7);
        int int51 = spreadsheetDate50.getMonth();
        int int52 = spreadsheetDate50.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(7);
        int int55 = spreadsheetDate54.getMonth();
        int int56 = spreadsheetDate54.getYYYY();
        boolean boolean57 = spreadsheetDate50.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate54);
        boolean boolean59 = spreadsheetDate50.equals((java.lang.Object) "Value");
        java.util.Date date60 = spreadsheetDate50.toDate();
        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month(date60);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month61, (java.lang.Number) (byte) -1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) month61);
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1900 + "'", int52 == 1900);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1900 + "'", int56 == 1900);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNull(timeSeriesDataItem63);
        org.junit.Assert.assertNotNull(timeSeriesDataItem64);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        timeSeries4.setMaximumItemAge((long) (byte) 10);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener7);
        java.lang.Comparable comparable9 = timeSeries4.getKey();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str18 = timeSeries17.getDescription();
        boolean boolean19 = timeSeries17.isEmpty();
        java.lang.String str20 = timeSeries17.getDomainDescription();
        java.lang.Class class21 = timeSeries17.getTimePeriodClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize(class21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "org.jfree.data.time.TimePeriodFormatException: Value", "hi!", class22);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries25.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str29 = timeSeries28.getDescription();
        boolean boolean30 = timeSeries28.isEmpty();
        java.lang.String str31 = timeSeries28.getDomainDescription();
        java.util.List list32 = timeSeries28.getItems();
        timeSeries28.setDomainDescription("ERROR : Relative To String");
        boolean boolean35 = timeSeries28.getNotify();
        java.util.Collection collection36 = timeSeries28.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries23.addAndOrUpdate(timeSeries28);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries4.addAndOrUpdate(timeSeries37);
        int int39 = timeSeries4.getMaximumItemCount();
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + "ERROR : Relative To String" + "'", comparable9.equals("ERROR : Relative To String"));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Time" + "'", str31.equals("Time"));
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(collection36);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2147483647 + "'", int39 == 2147483647);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        java.util.Date date4 = spreadsheetDate1.toDate();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) 4);
        java.lang.Number number9 = timeSeriesDataItem8.getValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 4.0d + "'", number9.equals(4.0d));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(7);
        int int6 = spreadsheetDate5.getMonth();
        int int7 = spreadsheetDate5.getYYYY();
        boolean boolean8 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean13 = spreadsheetDate10.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        java.util.Date date14 = spreadsheetDate10.toDate();
        boolean boolean15 = spreadsheetDate5.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addDays(1900, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean20 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(7);
        int int25 = spreadsheetDate24.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(7);
        int int28 = spreadsheetDate27.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean33 = spreadsheetDate30.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean38 = spreadsheetDate35.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean39 = spreadsheetDate32.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(7);
        int int43 = spreadsheetDate42.getMonth();
        int int44 = spreadsheetDate42.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(7);
        int int47 = spreadsheetDate46.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean52 = spreadsheetDate49.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate51);
        boolean boolean54 = spreadsheetDate42.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate46, (org.jfree.data.time.SerialDate) spreadsheetDate49, (int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate42);
        boolean boolean57 = spreadsheetDate27.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate32, serialDate55, (-1));
        boolean boolean58 = spreadsheetDate24.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(7);
        int int62 = spreadsheetDate61.getMonth();
        int int63 = spreadsheetDate61.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate(7);
        int int66 = spreadsheetDate65.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean71 = spreadsheetDate68.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate70);
        boolean boolean73 = spreadsheetDate61.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate65, (org.jfree.data.time.SerialDate) spreadsheetDate68, (int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SerialDate serialDate77 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate76);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate79 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate81 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean82 = spreadsheetDate79.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate81);
        int int83 = spreadsheetDate79.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate86 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SerialDate serialDate87 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate86);
        boolean boolean88 = spreadsheetDate79.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate86);
        org.jfree.data.time.SerialDate serialDate90 = spreadsheetDate86.getNearestDayOfWeek(2);
        boolean boolean92 = spreadsheetDate65.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate76, serialDate90, 0);
        org.jfree.data.time.SerialDate serialDate93 = serialDate59.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate76);
        org.jfree.data.time.SerialDate serialDate94 = org.jfree.data.time.SerialDate.addMonths(0, serialDate93);
        boolean boolean95 = spreadsheetDate10.isAfter(serialDate94);
        int int96 = spreadsheetDate10.getYYYY();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1900 + "'", int7 == 1900);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 7 + "'", int28 == 7);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1900 + "'", int44 == 1900);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 7 + "'", int47 == 7);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1900 + "'", int63 == 1900);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 7 + "'", int66 == 7);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(serialDate77);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 7 + "'", int83 == 7);
        org.junit.Assert.assertNotNull(serialDate87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(serialDate90);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertNotNull(serialDate93);
        org.junit.Assert.assertNotNull(serialDate94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 1900 + "'", int96 == 1900);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        java.lang.Class class2 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean7 = spreadsheetDate4.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        java.util.Date date8 = spreadsheetDate4.toDate();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8, timeZone10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date8, timeZone12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean18 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.util.Date date19 = spreadsheetDate15.toDate();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date19, timeZone21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date8, timeZone21);
        boolean boolean24 = timeSeries1.equals((java.lang.Object) month23);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener25);
        java.lang.String str27 = timeSeries1.getDescription();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(str27);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean4 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        java.util.Date date5 = spreadsheetDate1.toDate();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date5);
//        java.util.Calendar calendar8 = null;
//        fixedMillisecond7.peg(calendar8);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond7.getLastMillisecond(calendar10);
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond7.getMiddleMillisecond(calendar12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond7.next();
//        long long15 = fixedMillisecond7.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, 0.0d);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-2208527999198L) + "'", long11 == (-2208527999198L));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-2208527999198L) + "'", long13 == (-2208527999198L));
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-2208527999198L) + "'", long15 == (-2208527999198L));
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        timeSeries4.setMaximumItemAge((long) (byte) 10);
        timeSeries4.clear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean12 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        java.util.Date date13 = spreadsheetDate9.toDate();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date13, timeZone15);
        java.lang.String str17 = year16.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 9999);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries21.createCopy((int) 'a', (int) (byte) 100);
        boolean boolean25 = timeSeries4.equals((java.lang.Object) (byte) 100);
        timeSeries4.setNotify(false);
        java.util.List list28 = timeSeries4.getItems();
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener29);
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1900" + "'", str17.equals("1900"));
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(list28);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(7);
        int int6 = spreadsheetDate5.getMonth();
        int int7 = spreadsheetDate5.getYYYY();
        boolean boolean8 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean13 = spreadsheetDate10.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        java.util.Date date14 = spreadsheetDate10.toDate();
        boolean boolean15 = spreadsheetDate5.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        int int18 = spreadsheetDate17.getDayOfWeek();
        int int19 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int20 = spreadsheetDate17.getMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1900 + "'", int7 == 1900);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 7 + "'", int18 == 7);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        timeSeries4.setMaximumItemAge((long) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
        int int9 = spreadsheetDate8.getMonth();
        int int10 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean13 = day11.equals((java.lang.Object) 11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean18 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.util.Date date19 = spreadsheetDate15.toDate();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date19, timeZone21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) year22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean28 = spreadsheetDate25.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        java.util.Date date29 = spreadsheetDate25.toDate();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date29);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date29, timeZone31);
        java.lang.String str33 = year32.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) year32, (org.jfree.data.time.RegularTimePeriod) day38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean44 = spreadsheetDate41.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate43);
        java.util.Date date45 = spreadsheetDate41.toDate();
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(date45);
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date45, timeZone47);
        java.lang.String str49 = year48.toString();
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries51.createCopy((int) 'a', (int) (byte) 100);
        timeSeries54.setMaximumItemAge((long) (byte) 10);
        java.lang.String str57 = timeSeries54.getDescription();
        boolean boolean58 = year48.equals((java.lang.Object) timeSeries54);
        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month(8, 0);
        timeSeries54.setKey((java.lang.Comparable) month61);
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries64.createCopy((int) 'a', (int) (byte) 100);
        java.util.List list68 = timeSeries67.getItems();
        java.lang.Class class69 = timeSeries67.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month61, class69);
        boolean boolean71 = timeSeries39.equals((java.lang.Object) timeSeries70);
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1900" + "'", str33.equals("1900"));
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1900" + "'", str49.equals("1900"));
        org.junit.Assert.assertNotNull(timeSeries54);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(timeSeries67);
        org.junit.Assert.assertNotNull(list68);
        org.junit.Assert.assertNotNull(class69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean5 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean10 = spreadsheetDate7.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate4.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate4.getNearestDayOfWeek((int) (short) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths(2019, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Value");
        java.lang.Class class2 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean7 = spreadsheetDate4.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        java.util.Date date8 = spreadsheetDate4.toDate();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8, timeZone10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date8, timeZone12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean18 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.util.Date date19 = spreadsheetDate15.toDate();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date19, timeZone21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date8, timeZone21);
        int int24 = month23.getYearValue();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("");
        int int27 = month23.compareTo((java.lang.Object) timePeriodFormatException26);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("Value");
        java.lang.Class class31 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean36 = spreadsheetDate33.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        java.util.Date date37 = spreadsheetDate33.toDate();
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(date37);
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date37, timeZone39);
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date37, timeZone41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean47 = spreadsheetDate44.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate46);
        java.util.Date date48 = spreadsheetDate44.toDate();
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(date48);
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date48, timeZone50);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date37, timeZone50);
        int int53 = month52.getYearValue();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException55 = new org.jfree.data.time.TimePeriodFormatException("");
        int int56 = month52.compareTo((java.lang.Object) timePeriodFormatException55);
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException55);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException55);
        java.lang.Throwable[] throwableArray59 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException61 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException61);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1900 + "'", int24 == 1900);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1900 + "'", int53 == 1900);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertNotNull(throwableArray59);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str5 = timeSeries4.getDescription();
        boolean boolean6 = timeSeries4.isEmpty();
        java.lang.String str7 = timeSeries4.getDomainDescription();
        java.util.List list8 = timeSeries4.getItems();
        timeSeries4.setDomainDescription("ERROR : Relative To String");
        boolean boolean11 = timeSeries4.getNotify();
        java.lang.String str12 = timeSeries4.getRangeDescription();
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str5 = timeSeries4.getDescription();
        boolean boolean6 = timeSeries4.isEmpty();
        java.lang.String str7 = timeSeries4.getDomainDescription();
        java.util.List list8 = timeSeries4.getItems();
        timeSeries4.setMaximumItemAge(0L);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries15.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str19 = timeSeries18.getDescription();
        boolean boolean20 = timeSeries18.isEmpty();
        java.lang.String str21 = timeSeries18.getDomainDescription();
        java.lang.Class class22 = timeSeries18.getTimePeriodClass();
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize(class22);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", "org.jfree.data.time.TimePeriodFormatException: Value", "hi!", class23);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries26.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str30 = timeSeries29.getDescription();
        boolean boolean31 = timeSeries29.isEmpty();
        java.lang.String str32 = timeSeries29.getDomainDescription();
        java.util.List list33 = timeSeries29.getItems();
        timeSeries29.setDomainDescription("ERROR : Relative To String");
        boolean boolean36 = timeSeries29.getNotify();
        java.util.Collection collection37 = timeSeries29.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries24.addAndOrUpdate(timeSeries29);
        java.util.Collection collection39 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries38);
        try {
            java.lang.Number number41 = timeSeries38.getValue(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Time" + "'", str21.equals("Time"));
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Time" + "'", str32.equals("Time"));
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(collection39);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
//        timeSeries4.setMaximumItemAge((long) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
//        int int9 = spreadsheetDate8.getMonth();
//        int int10 = spreadsheetDate8.getYYYY();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
//        boolean boolean13 = day11.equals((java.lang.Object) 11);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean18 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        java.util.Date date19 = spreadsheetDate15.toDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date19, timeZone21);
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) year22);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean28 = spreadsheetDate25.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
//        java.util.Date date29 = spreadsheetDate25.toDate();
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date29);
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date29, timeZone31);
//        java.lang.String str33 = year32.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate36);
//        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) year32, (org.jfree.data.time.RegularTimePeriod) day38);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries41.createCopy((int) 'a', (int) (byte) 100);
//        timeSeries44.setMaximumItemAge((long) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(7);
//        int int49 = spreadsheetDate48.getMonth();
//        int int50 = spreadsheetDate48.getYYYY();
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate48);
//        boolean boolean53 = day51.equals((java.lang.Object) 11);
//        int int54 = day51.getMonth();
//        int int55 = day51.getMonth();
//        int int56 = day51.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries44.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day51, (double) (short) -1);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
//        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries60.createCopy((int) 'a', (int) (byte) 100);
//        timeSeries63.setMaximumItemAge((long) (byte) 10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener66 = null;
//        timeSeries63.removeChangeListener(seriesChangeListener66);
//        int int68 = timeSeries63.getMaximumItemCount();
//        org.jfree.data.time.TimeSeries timeSeries69 = timeSeries44.addAndOrUpdate(timeSeries63);
//        org.jfree.data.time.TimeSeries timeSeries70 = timeSeries23.addAndOrUpdate(timeSeries63);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate72 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean75 = spreadsheetDate72.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate74);
//        java.util.Date date76 = spreadsheetDate72.toDate();
//        org.jfree.data.time.SerialDate serialDate77 = org.jfree.data.time.SerialDate.createInstance(date76);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond78 = new org.jfree.data.time.FixedMillisecond(date76);
//        java.util.Calendar calendar79 = null;
//        fixedMillisecond78.peg(calendar79);
//        java.util.Calendar calendar81 = null;
//        long long82 = fixedMillisecond78.getLastMillisecond(calendar81);
//        java.util.Calendar calendar83 = null;
//        long long84 = fixedMillisecond78.getMiddleMillisecond(calendar83);
//        java.lang.String str85 = fixedMillisecond78.toString();
//        try {
//            timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond78, (java.lang.Number) 11, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1900" + "'", str33.equals("1900"));
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(timeSeries39);
//        org.junit.Assert.assertNotNull(timeSeries44);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1900 + "'", int50 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem58);
//        org.junit.Assert.assertNotNull(timeSeries63);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 2147483647 + "'", int68 == 2147483647);
//        org.junit.Assert.assertNotNull(timeSeries69);
//        org.junit.Assert.assertNotNull(timeSeries70);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNotNull(serialDate77);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-2208527999993L) + "'", long82 == (-2208527999993L));
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + (-2208527999993L) + "'", long84 == (-2208527999993L));
//        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "Sat Jan 06 00:00:00 PST 1900" + "'", str85.equals("Sat Jan 06 00:00:00 PST 1900"));
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(2147483647, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        timeSeries4.setMaximumItemAge((long) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
        int int9 = spreadsheetDate8.getMonth();
        int int10 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean13 = day11.equals((java.lang.Object) 11);
        int int14 = day11.getMonth();
        int int15 = day11.getMonth();
        int int16 = day11.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day11, (double) (short) -1);
        java.lang.String str19 = timeSeries4.getDescription();
        java.lang.String str20 = timeSeries4.getDescription();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries22.createCopy((int) 'a', (int) (byte) 100);
        timeSeries25.setMaximumItemAge((long) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(7);
        int int30 = spreadsheetDate29.getMonth();
        int int31 = spreadsheetDate29.getYYYY();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate29);
        boolean boolean34 = day32.equals((java.lang.Object) 11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean39 = spreadsheetDate36.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        java.util.Date date40 = spreadsheetDate36.toDate();
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance(date40);
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date40, timeZone42);
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) day32, (org.jfree.data.time.RegularTimePeriod) year43);
        java.util.List list45 = timeSeries44.getItems();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries47.createCopy((int) 'a', (int) (byte) 100);
        timeSeries50.setMaximumItemAge((long) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(7);
        int int55 = spreadsheetDate54.getMonth();
        int int56 = spreadsheetDate54.getYYYY();
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate54);
        boolean boolean59 = day57.equals((java.lang.Object) 11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean64 = spreadsheetDate61.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate63);
        java.util.Date date65 = spreadsheetDate61.toDate();
        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.createInstance(date65);
        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year(date65, timeZone67);
        org.jfree.data.time.TimeSeries timeSeries69 = timeSeries50.createCopy((org.jfree.data.time.RegularTimePeriod) day57, (org.jfree.data.time.RegularTimePeriod) year68);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem71 = timeSeries44.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year68, (double) (byte) 1);
        int int72 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year68);
        timeSeries4.clear();
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1900 + "'", int31 == 1900);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1900 + "'", int56 == 1900);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertNotNull(timeZone67);
        org.junit.Assert.assertNotNull(timeSeries69);
        org.junit.Assert.assertNull(timeSeriesDataItem71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(8, 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeriesDataItem4.getPeriod();
        timeSeriesDataItem4.setValue((java.lang.Number) (-1.0d));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener5);
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(7);
        int int10 = spreadsheetDate9.getMonth();
        int int11 = spreadsheetDate9.getYYYY();
        int int12 = spreadsheetDate9.toSerial();
        boolean boolean14 = spreadsheetDate9.equals((java.lang.Object) (-1L));
        java.util.Date date15 = spreadsheetDate9.toDate();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date15, timeZone16);
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1900 + "'", int11 == 1900);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 7 + "'", int12 == 7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(100, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((-460), 6, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.String str1 = fixedMillisecond0.toString();
//        long long2 = fixedMillisecond0.getFirstMillisecond();
//        long long3 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mon Jun 10 11:26:23 PDT 2019" + "'", str1.equals("Mon Jun 10 11:26:23 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191183587L + "'", long2 == 1560191183587L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560191183587L + "'", long3 == 1560191183587L);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int5 = day4.getYear();
        java.util.Date date6 = day4.getStart();
        long long7 = day4.getMiddleMillisecond();
        int int8 = day4.getDayOfMonth();
        long long9 = day4.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1900 + "'", int5 == 1900);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208484800001L) + "'", long7 == (-2208484800001L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-2208528000000L) + "'", long9 == (-2208528000000L));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(8, 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, 0.0d);
        timeSeries4.setKey((java.lang.Comparable) 0.0d);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(7);
        int int13 = spreadsheetDate12.getMonth();
        int int14 = spreadsheetDate12.getYYYY();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day15);
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1900 + "'", int14 == 1900);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.lang.Class class0 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean5 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        java.util.Date date6 = spreadsheetDate2.toDate();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date6, timeZone8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date6, timeZone10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean16 = spreadsheetDate13.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        java.util.Date date17 = spreadsheetDate13.toDate();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17, timeZone19);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date6, timeZone19);
        java.util.Date date22 = month21.getEnd();
        java.lang.Class class23 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean28 = spreadsheetDate25.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        java.util.Date date29 = spreadsheetDate25.toDate();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date29);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date29, timeZone31);
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date29, timeZone33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean39 = spreadsheetDate36.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        java.util.Date date40 = spreadsheetDate36.toDate();
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance(date40);
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date40, timeZone42);
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date29, timeZone42);
        java.util.Date date45 = month44.getEnd();
        boolean boolean46 = month21.equals((java.lang.Object) month44);
        int int47 = month21.getMonth();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        java.lang.Class class2 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean7 = spreadsheetDate4.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        java.util.Date date8 = spreadsheetDate4.toDate();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8, timeZone10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date8, timeZone12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean18 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.util.Date date19 = spreadsheetDate15.toDate();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date19, timeZone21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date8, timeZone21);
        boolean boolean24 = timeSeries1.equals((java.lang.Object) month23);
        org.jfree.data.time.Year year25 = month23.getYear();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        timeSeries27.setNotify(true);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        int int32 = spreadsheetDate31.getMonth();
        int int33 = spreadsheetDate31.getYYYY();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(7);
        int int37 = spreadsheetDate36.getMonth();
        int int38 = spreadsheetDate36.getYYYY();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries27.createCopy((org.jfree.data.time.RegularTimePeriod) day34, (org.jfree.data.time.RegularTimePeriod) day39);
        int int41 = year25.compareTo((java.lang.Object) day39);
        java.util.Date date42 = year25.getEnd();
        java.util.Calendar calendar43 = null;
        try {
            long long44 = year25.getLastMillisecond(calendar43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(year25);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1900 + "'", int33 == 1900);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1900 + "'", int38 == 1900);
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(date42);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean4 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        java.util.Date date5 = spreadsheetDate1.toDate();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date5);
//        java.util.Calendar calendar8 = null;
//        fixedMillisecond7.peg(calendar8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond7.next();
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond7.getFirstMillisecond(calendar11);
//        long long13 = fixedMillisecond7.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2208527999095L) + "'", long12 == (-2208527999095L));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-2208527999095L) + "'", long13 == (-2208527999095L));
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        java.lang.Class class2 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean7 = spreadsheetDate4.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        java.util.Date date8 = spreadsheetDate4.toDate();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8, timeZone10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date8, timeZone12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean18 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.util.Date date19 = spreadsheetDate15.toDate();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date19, timeZone21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date8, timeZone21);
        boolean boolean24 = timeSeries1.equals((java.lang.Object) month23);
        java.lang.String str25 = month23.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month23.next();
        java.util.Calendar calendar27 = null;
        try {
            long long28 = month23.getFirstMillisecond(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "January 1900" + "'", str25.equals("January 1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        java.util.Date date4 = spreadsheetDate1.toDate();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) 4);
        timeSeriesDataItem8.setValue((java.lang.Number) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str5 = timeSeries4.getDescription();
        boolean boolean6 = timeSeries4.isEmpty();
        java.lang.String str7 = timeSeries4.getDomainDescription();
        java.lang.Class class8 = timeSeries4.getTimePeriodClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize(class8);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize(class8);
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(class10);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(4);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Fourth" + "'", str1.equals("Fourth"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str10 = timeSeries9.getDescription();
        boolean boolean11 = timeSeries9.isEmpty();
        java.lang.String str12 = timeSeries9.getDomainDescription();
        java.util.List list13 = timeSeries9.getItems();
        timeSeries9.clear();
        boolean boolean15 = day4.equals((java.lang.Object) timeSeries9);
        int int16 = day4.getDayOfMonth();
        long long17 = day4.getFirstMillisecond();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2208528000000L) + "'", long17 == (-2208528000000L));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        java.util.List list5 = timeSeries4.getItems();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries7.createCopy((int) 'a', (int) (byte) 100);
        timeSeries10.setMaximumItemAge((long) (byte) 10);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener13);
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        timeSeries17.setNotify(true);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(7);
        int int22 = spreadsheetDate21.getMonth();
        int int23 = spreadsheetDate21.getYYYY();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(7);
        int int27 = spreadsheetDate26.getMonth();
        int int28 = spreadsheetDate26.getYYYY();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day24, (org.jfree.data.time.RegularTimePeriod) day29);
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) 100.0d, true);
        timeSeries4.setMaximumItemCount(0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(7);
        int int38 = spreadsheetDate37.getMonth();
        int int39 = spreadsheetDate37.getYYYY();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean42 = day40.equals((java.lang.Object) 11);
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries44.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str48 = timeSeries47.getDescription();
        boolean boolean49 = timeSeries47.isEmpty();
        int int50 = day40.compareTo((java.lang.Object) timeSeries47);
        long long51 = day40.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day40, (java.lang.Number) 1900);
        int int55 = timeSeriesDataItem53.compareTo((java.lang.Object) 0);
        timeSeriesDataItem53.setValue((java.lang.Number) (-2208527999695L));
        timeSeries4.add(timeSeriesDataItem53);
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1900 + "'", int23 == 1900);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1900 + "'", int28 == 1900);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1900 + "'", int39 == 1900);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(timeSeries47);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 7L + "'", long51 == 7L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "January");
        timeSeries1.setDescription("1900");
        timeSeries1.removeAgedItems((long) 9999, false);
        java.lang.Class class7 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean12 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        java.util.Date date13 = spreadsheetDate9.toDate();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date13, timeZone15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date13, timeZone17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean23 = spreadsheetDate20.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        java.util.Date date24 = spreadsheetDate20.toDate();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date24, timeZone26);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date13, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month28.previous();
        org.jfree.data.time.Year year30 = month28.getYear();
        org.jfree.data.time.Year year31 = month28.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) (-1));
        try {
            timeSeries1.add(timeSeriesDataItem33, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertNotNull(year31);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        timeSeries4.setMaximumItemAge((long) (byte) 10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries4.addChangeListener(seriesChangeListener7);
        timeSeries4.clear();
        java.lang.String str10 = timeSeries4.getRangeDescription();
        timeSeries4.setDomainDescription("Value");
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str5 = timeSeries4.getDescription();
        boolean boolean6 = timeSeries4.isEmpty();
        java.lang.String str7 = timeSeries4.getDomainDescription();
        java.lang.Class class8 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean13 = spreadsheetDate10.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        java.util.Date date14 = spreadsheetDate10.toDate();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.Year year16 = month15.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, (double) (-2208527999695L));
        java.util.Collection collection19 = timeSeries4.getTimePeriods();
        java.util.Collection collection20 = timeSeries4.getTimePeriods();
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(collection20);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        timeSeries1.setMaximumItemCount(9);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        java.util.Date date4 = spreadsheetDate1.toDate();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(7);
        int int8 = spreadsheetDate7.getMonth();
        int int9 = spreadsheetDate7.getYYYY();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate7);
        boolean boolean12 = day10.equals((java.lang.Object) 11);
        int int13 = day10.getMonth();
        int int14 = day10.getMonth();
        boolean boolean15 = month5.equals((java.lang.Object) day10);
        java.util.Calendar calendar16 = null;
        try {
            month5.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1900 + "'", int9 == 1900);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        java.lang.Class class2 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean7 = spreadsheetDate4.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        java.util.Date date8 = spreadsheetDate4.toDate();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8, timeZone10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date8, timeZone12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean18 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.util.Date date19 = spreadsheetDate15.toDate();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date19, timeZone21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date8, timeZone21);
        boolean boolean24 = timeSeries1.equals((java.lang.Object) month23);
        org.jfree.data.time.Year year25 = month23.getYear();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        timeSeries27.setNotify(true);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        int int32 = spreadsheetDate31.getMonth();
        int int33 = spreadsheetDate31.getYYYY();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(7);
        int int37 = spreadsheetDate36.getMonth();
        int int38 = spreadsheetDate36.getYYYY();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries27.createCopy((org.jfree.data.time.RegularTimePeriod) day34, (org.jfree.data.time.RegularTimePeriod) day39);
        int int41 = year25.compareTo((java.lang.Object) day39);
        java.util.Calendar calendar42 = null;
        try {
            year25.peg(calendar42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(year25);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1900 + "'", int33 == 1900);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1900 + "'", int38 == 1900);
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(5, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean4 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.util.Date date5 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date5);
        java.util.Calendar calendar8 = null;
        fixedMillisecond7.peg(calendar8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond7.next();
        java.lang.Object obj11 = null;
        int int12 = fixedMillisecond7.compareTo(obj11);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((-1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-2208527999443L));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        java.util.List list5 = timeSeries4.getItems();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries7.createCopy((int) 'a', (int) (byte) 100);
        timeSeries10.setMaximumItemAge((long) (byte) 10);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener13);
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        java.util.List list16 = timeSeries10.getItems();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener17);
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(list16);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean4 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        java.util.Date date5 = spreadsheetDate1.toDate();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date5);
//        java.util.Calendar calendar8 = null;
//        fixedMillisecond7.peg(calendar8);
//        long long10 = fixedMillisecond7.getFirstMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean15 = spreadsheetDate12.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        java.util.Date date16 = spreadsheetDate12.toDate();
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date16);
//        java.util.Calendar calendar19 = null;
//        fixedMillisecond18.peg(calendar19);
//        long long21 = fixedMillisecond18.getFirstMillisecond();
//        boolean boolean22 = fixedMillisecond7.equals((java.lang.Object) fixedMillisecond18);
//        long long23 = fixedMillisecond7.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2208527999603L) + "'", long10 == (-2208527999603L));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-2208527999601L) + "'", long21 == (-2208527999601L));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-2208527999603L) + "'", long23 == (-2208527999603L));
//    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean4 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        java.util.Date date5 = spreadsheetDate1.toDate();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date5);
//        java.util.Calendar calendar8 = null;
//        fixedMillisecond7.peg(calendar8);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond7.getLastMillisecond(calendar10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 100);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond7.getFirstMillisecond(calendar14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond7.next();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-2208527999560L) + "'", long11 == (-2208527999560L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-2208527999560L) + "'", long15 == (-2208527999560L));
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        timeSeries4.setMaximumItemAge((long) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
        int int9 = spreadsheetDate8.getMonth();
        int int10 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean13 = day11.equals((java.lang.Object) 11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean18 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.util.Date date19 = spreadsheetDate15.toDate();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date19, timeZone21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) year22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean28 = spreadsheetDate25.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        java.util.Date date29 = spreadsheetDate25.toDate();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date29);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date29, timeZone31);
        java.lang.String str33 = year32.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) year32, (org.jfree.data.time.RegularTimePeriod) day38);
        int int41 = year32.compareTo((java.lang.Object) 11);
        java.lang.String str42 = year32.toString();
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1900" + "'", str33.equals("1900"));
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "1900" + "'", str42.equals("1900"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((-571));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
//        timeSeries2.setNotify(true);
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) true);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond0.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond0.getFirstMillisecond(calendar9);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560191184626L + "'", long7 == 1560191184626L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560191184626L + "'", long10 == 1560191184626L);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean5 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean10 = spreadsheetDate7.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate4.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        try {
            org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1900, (org.jfree.data.time.SerialDate) spreadsheetDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean4 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.util.Date date5 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date5, timeZone7);
        java.lang.String str9 = year8.toString();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy((int) 'a', (int) (byte) 100);
        timeSeries14.setMaximumItemAge((long) (byte) 10);
        java.lang.String str17 = timeSeries14.getDescription();
        boolean boolean18 = year8.equals((java.lang.Object) timeSeries14);
        java.lang.String str19 = year8.toString();
        long long20 = year8.getLastMillisecond();
        long long21 = year8.getLastMillisecond();
        java.util.Calendar calendar22 = null;
        try {
            year8.peg(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1900" + "'", str9.equals("1900"));
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1900" + "'", str19.equals("1900"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-2177424000001L) + "'", long20 == (-2177424000001L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-2177424000001L) + "'", long21 == (-2177424000001L));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Sat Jan 06 00:00:00 PST 1900");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean4 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.util.Date date5 = spreadsheetDate1.toDate();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.Year year7 = month6.getYear();
        int int8 = year7.getYear();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1900 + "'", int8 == 1900);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str5 = timeSeries4.getDescription();
        boolean boolean6 = timeSeries4.isEmpty();
        java.lang.String str7 = timeSeries4.getDomainDescription();
        java.util.List list8 = timeSeries4.getItems();
        timeSeries4.clear();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries4.addChangeListener(seriesChangeListener10);
        java.util.Collection collection12 = timeSeries4.getTimePeriods();
        timeSeries4.removeAgedItems(true);
        timeSeries4.clear();
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(collection12);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        int int4 = spreadsheetDate1.toSerial();
        spreadsheetDate1.setDescription("");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
//        timeSeries4.setMaximumItemAge((long) (byte) 10);
//        timeSeries4.removeAgedItems((long) 8, false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean14 = spreadsheetDate11.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
//        java.util.Date date15 = spreadsheetDate11.toDate();
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date15);
//        java.util.Calendar calendar18 = null;
//        fixedMillisecond17.peg(calendar18);
//        long long20 = fixedMillisecond17.getFirstMillisecond();
//        long long21 = fixedMillisecond17.getLastMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) '#');
//        boolean boolean24 = fixedMillisecond17.equals((java.lang.Object) '#');
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond17.previous();
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-2208527999280L) + "'", long20 == (-2208527999280L));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-2208527999280L) + "'", long21 == (-2208527999280L));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        boolean boolean6 = day4.equals((java.lang.Object) 11);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries8.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str12 = timeSeries11.getDescription();
        boolean boolean13 = timeSeries11.isEmpty();
        int int14 = day4.compareTo((java.lang.Object) timeSeries11);
        long long15 = day4.getSerialIndex();
        long long16 = day4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day4.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (-2208527999495L));
        long long20 = day4.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 7L + "'", long15 == 7L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 7L + "'", long16 == 7L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-2208528000000L) + "'", long20 == (-2208528000000L));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int5 = day4.getYear();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day4.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1900 + "'", int5 == 1900);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        boolean boolean6 = day4.equals((java.lang.Object) 11);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries8.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str12 = timeSeries11.getDescription();
        boolean boolean13 = timeSeries11.isEmpty();
        int int14 = day4.compareTo((java.lang.Object) timeSeries11);
        long long15 = day4.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 1900);
        int int19 = timeSeriesDataItem17.compareTo((java.lang.Object) 0);
        timeSeriesDataItem17.setValue((java.lang.Number) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem17.getPeriod();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(7);
        int int25 = spreadsheetDate24.getMonth();
        int int26 = spreadsheetDate24.getYYYY();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean29 = day27.equals((java.lang.Object) 11);
        int int30 = day27.getMonth();
        int int31 = day27.getMonth();
        java.util.Date date32 = day27.getEnd();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
        boolean boolean34 = timeSeriesDataItem17.equals((java.lang.Object) date32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 7L + "'", long15 == 7L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1900 + "'", int26 == 1900);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str5 = timeSeries4.getDescription();
        boolean boolean6 = timeSeries4.isEmpty();
        java.lang.String str7 = timeSeries4.getDomainDescription();
        java.util.List list8 = timeSeries4.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries10.createCopy((int) 'a', (int) (byte) 100);
        timeSeries13.setMaximumItemAge((long) (byte) 10);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(7);
        int int20 = spreadsheetDate19.getMonth();
        int int21 = spreadsheetDate19.getYYYY();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, 100.0d);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries4.addAndOrUpdate(timeSeries13);
        java.util.Collection collection26 = timeSeries13.getTimePeriods();
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1900 + "'", int21 == 1900);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNotNull(collection26);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        try {
            org.jfree.data.time.SerialDate serialDate5 = serialDate3.getFollowingDayOfWeek(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        timeSeries1.setNotify(true);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(7);
        int int6 = spreadsheetDate5.getMonth();
        int int7 = spreadsheetDate5.getYYYY();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(7);
        int int11 = spreadsheetDate10.getMonth();
        int int12 = spreadsheetDate10.getYYYY();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day13);
        java.lang.String str15 = timeSeries14.getDescription();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries17.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str21 = timeSeries20.getDescription();
        boolean boolean22 = timeSeries20.isEmpty();
        java.lang.String str23 = timeSeries20.getDomainDescription();
        java.util.List list24 = timeSeries20.getItems();
        java.lang.Object obj25 = timeSeries20.clone();
        timeSeries20.setDomainDescription("Value");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
        timeSeries20.removeChangeListener(seriesChangeListener28);
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries14.addAndOrUpdate(timeSeries20);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1900 + "'", int7 == 1900);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(timeSeries30);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        int int2 = spreadsheetDate1.getDayOfWeek();
        boolean boolean4 = spreadsheetDate1.equals((java.lang.Object) 5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean9 = spreadsheetDate6.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int10 = spreadsheetDate6.getMonth();
        boolean boolean11 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int12 = spreadsheetDate1.toSerial();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 7 + "'", int12 == 7);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        int int3 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(7);
        int int6 = spreadsheetDate5.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean11 = spreadsheetDate8.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean16 = spreadsheetDate13.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate10.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(7);
        int int21 = spreadsheetDate20.getMonth();
        int int22 = spreadsheetDate20.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(7);
        int int25 = spreadsheetDate24.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean30 = spreadsheetDate27.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        boolean boolean32 = spreadsheetDate20.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate27, (int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean35 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, serialDate33, (-1));
        boolean boolean36 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(7);
        int int40 = spreadsheetDate39.getMonth();
        int int41 = spreadsheetDate39.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(7);
        int int44 = spreadsheetDate43.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean49 = spreadsheetDate46.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate48);
        boolean boolean51 = spreadsheetDate39.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate43, (org.jfree.data.time.SerialDate) spreadsheetDate46, (int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate54);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean60 = spreadsheetDate57.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate59);
        int int61 = spreadsheetDate57.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate64);
        boolean boolean66 = spreadsheetDate57.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate64);
        org.jfree.data.time.SerialDate serialDate68 = spreadsheetDate64.getNearestDayOfWeek(2);
        boolean boolean70 = spreadsheetDate43.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate54, serialDate68, 0);
        org.jfree.data.time.SerialDate serialDate71 = serialDate37.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate54);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate74);
        boolean boolean76 = spreadsheetDate54.isOnOrBefore(serialDate75);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1900 + "'", int22 == 1900);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 7 + "'", int25 == 7);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1900 + "'", int41 == 1900);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 7 + "'", int44 == 7);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 7 + "'", int61 == 7);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertNotNull(serialDate75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean4 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.util.Date date5 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date5, timeZone7);
        java.lang.String str9 = year8.toString();
        long long10 = year8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year8.previous();
        java.lang.Class<?> wildcardClass12 = year8.getClass();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) 'a', (int) (byte) 100);
        timeSeries17.setMaximumItemAge((long) (byte) 10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries17.removeChangeListener(seriesChangeListener20);
        int int22 = timeSeries17.getMaximumItemCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(7);
        int int25 = spreadsheetDate24.getMonth();
        int int26 = spreadsheetDate24.getYYYY();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean29 = day27.equals((java.lang.Object) 11);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries31.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str35 = timeSeries34.getDescription();
        boolean boolean36 = timeSeries34.isEmpty();
        int int37 = day27.compareTo((java.lang.Object) timeSeries34);
        long long38 = day27.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day27, (java.lang.Number) 1900);
        int int42 = timeSeriesDataItem40.compareTo((java.lang.Object) 0);
        timeSeriesDataItem40.setValue((java.lang.Number) 12);
        timeSeries17.add(timeSeriesDataItem40);
        boolean boolean46 = year8.equals((java.lang.Object) timeSeries17);
        int int47 = year8.getYear();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1900" + "'", str9.equals("1900"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2193192000001L) + "'", long10 == (-2193192000001L));
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2147483647 + "'", int22 == 2147483647);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1900 + "'", int26 == 1900);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 7L + "'", long38 == 7L);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1900 + "'", int47 == 1900);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.lang.Class class0 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean5 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        java.util.Date date6 = spreadsheetDate2.toDate();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date6, timeZone8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date6, timeZone10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean16 = spreadsheetDate13.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        java.util.Date date17 = spreadsheetDate13.toDate();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17, timeZone19);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date6, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.previous();
        org.jfree.data.time.Year year23 = month21.getYear();
        org.jfree.data.time.Year year24 = month21.getYear();
        java.lang.Class class25 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean30 = spreadsheetDate27.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        java.util.Date date31 = spreadsheetDate27.toDate();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date31, timeZone33);
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date31, timeZone35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean41 = spreadsheetDate38.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate40);
        java.util.Date date42 = spreadsheetDate38.toDate();
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(date42);
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date42, timeZone44);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(date31, timeZone44);
        java.util.Date date47 = month46.getEnd();
        java.lang.Class class48 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean53 = spreadsheetDate50.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate52);
        java.util.Date date54 = spreadsheetDate50.toDate();
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(date54);
        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date54, timeZone56);
        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date54, timeZone58);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean64 = spreadsheetDate61.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate63);
        java.util.Date date65 = spreadsheetDate61.toDate();
        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.createInstance(date65);
        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year(date65, timeZone67);
        org.jfree.data.time.Month month69 = new org.jfree.data.time.Month(date54, timeZone67);
        java.util.Date date70 = month69.getEnd();
        boolean boolean71 = month46.equals((java.lang.Object) month69);
        boolean boolean72 = year24.equals((java.lang.Object) month46);
        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries77 = timeSeries74.createCopy((int) 'a', (int) (byte) 100);
        java.beans.PropertyChangeListener propertyChangeListener78 = null;
        timeSeries74.addPropertyChangeListener(propertyChangeListener78);
        boolean boolean80 = month46.equals((java.lang.Object) propertyChangeListener78);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(timeZone56);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertNotNull(timeZone67);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(timeSeries77);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str5 = timeSeries4.getDescription();
        boolean boolean6 = timeSeries4.isEmpty();
        java.lang.String str7 = timeSeries4.getDomainDescription();
        java.util.List list8 = timeSeries4.getItems();
        timeSeries4.setDomainDescription("ERROR : Relative To String");
        int int11 = timeSeries4.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries4.createCopy(0, (int) 'a');
        java.lang.String str15 = timeSeries4.getRangeDescription();
        int int16 = timeSeries4.getItemCount();
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Value" + "'", str15.equals("Value"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.lang.Class class0 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean5 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        java.util.Date date6 = spreadsheetDate2.toDate();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date6, timeZone8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date6, timeZone10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean16 = spreadsheetDate13.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        java.util.Date date17 = spreadsheetDate13.toDate();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17, timeZone19);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date6, timeZone19);
        int int22 = month21.getYearValue();
        long long23 = month21.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1900 + "'", int22 == 1900);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-2206281600001L) + "'", long23 == (-2206281600001L));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        org.junit.Assert.assertNotNull(timeSeries4);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        java.util.List list5 = timeSeries4.getItems();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries7.createCopy((int) 'a', (int) (byte) 100);
        timeSeries10.setMaximumItemAge((long) (byte) 10);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener13);
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        java.util.List list16 = timeSeries10.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries10.removeChangeListener(seriesChangeListener17);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener19);
        java.lang.String str21 = timeSeries10.getDescription();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries10.createCopy((int) (short) 0, 0);
        timeSeries10.removeAgedItems(false);
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(timeSeries24);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2019, (int) (byte) 100, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int5 = day4.getYear();
        java.util.Date date6 = day4.getStart();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(7);
        int int10 = spreadsheetDate9.getMonth();
        int int11 = spreadsheetDate9.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(7);
        int int14 = spreadsheetDate13.getMonth();
        int int15 = spreadsheetDate13.getYYYY();
        boolean boolean16 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int17 = spreadsheetDate13.getDayOfMonth();
        int int18 = day4.compareTo((java.lang.Object) spreadsheetDate13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1900 + "'", int5 == 1900);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1900 + "'", int11 == 1900);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1900 + "'", int15 == 1900);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '4', 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(7);
        int int6 = spreadsheetDate5.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean11 = spreadsheetDate8.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean13 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate5, (org.jfree.data.time.SerialDate) spreadsheetDate8, (int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean18 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.util.Date date19 = spreadsheetDate15.toDate();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        int int21 = spreadsheetDate5.compare(serialDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean27 = spreadsheetDate24.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        java.util.Date date28 = spreadsheetDate24.toDate();
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addYears(8, (org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean30 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        timeSeries4.setMaximumItemAge((long) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
        int int9 = spreadsheetDate8.getMonth();
        int int10 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean13 = day11.equals((java.lang.Object) 11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean18 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.util.Date date19 = spreadsheetDate15.toDate();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date19, timeZone21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) year22);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries26.createCopy((int) 'a', (int) (byte) 100);
        java.util.List list30 = timeSeries29.getItems();
        java.lang.Class class31 = timeSeries29.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f, class31);
        java.util.Date date33 = null;
        java.lang.Class class34 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean39 = spreadsheetDate36.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        java.util.Date date40 = spreadsheetDate36.toDate();
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance(date40);
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date40, timeZone42);
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date40, timeZone44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date33, timeZone44);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year22, class31);
        java.lang.Class class48 = org.jfree.data.time.RegularTimePeriod.downsize(class31);
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(class48);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        timeSeries4.setMaximumItemAge((long) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
        int int9 = spreadsheetDate8.getMonth();
        int int10 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean13 = day11.equals((java.lang.Object) 11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean18 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.util.Date date19 = spreadsheetDate15.toDate();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date19, timeZone21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) year22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean28 = spreadsheetDate25.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        java.util.Date date29 = spreadsheetDate25.toDate();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date29);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date29, timeZone31);
        java.lang.String str33 = year32.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) year32, (org.jfree.data.time.RegularTimePeriod) day38);
        timeSeries39.removeAgedItems((-2208527999443L), false);
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timeSeries39.removePropertyChangeListener(propertyChangeListener43);
        java.lang.Class class45 = timeSeries39.getTimePeriodClass();
        timeSeries39.removeAgedItems(false);
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1900" + "'", str33.equals("1900"));
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNotNull(class45);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(7);
        int int6 = spreadsheetDate5.getMonth();
        int int7 = spreadsheetDate5.getYYYY();
        boolean boolean8 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int9 = spreadsheetDate5.getDayOfMonth();
        int int10 = spreadsheetDate5.toSerial();
        int int11 = spreadsheetDate5.getYYYY();
        spreadsheetDate5.setDescription("Time");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1900 + "'", int7 == 1900);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 7 + "'", int10 == 7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1900 + "'", int11 == 1900);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        java.util.List list5 = timeSeries4.getItems();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries7.createCopy((int) 'a', (int) (byte) 100);
        timeSeries10.setMaximumItemAge((long) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(7);
        int int15 = spreadsheetDate14.getMonth();
        int int16 = spreadsheetDate14.getYYYY();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean19 = day17.equals((java.lang.Object) 11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean24 = spreadsheetDate21.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate23);
        java.util.Date date25 = spreadsheetDate21.toDate();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date25, timeZone27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) day17, (org.jfree.data.time.RegularTimePeriod) year28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean34 = spreadsheetDate31.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate33);
        java.util.Date date35 = spreadsheetDate31.toDate();
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date35, timeZone37);
        java.lang.String str39 = year38.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) year38, (org.jfree.data.time.RegularTimePeriod) day44);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day44);
        java.util.Date date47 = day44.getStart();
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance(date47);
        java.lang.Class class49 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean54 = spreadsheetDate51.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate53);
        java.util.Date date55 = spreadsheetDate51.toDate();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date55);
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date55, timeZone57);
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class49, date55, timeZone59);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean65 = spreadsheetDate62.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate64);
        java.util.Date date66 = spreadsheetDate62.toDate();
        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.createInstance(date66);
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(date66, timeZone68);
        org.jfree.data.time.Month month70 = new org.jfree.data.time.Month(date55, timeZone68);
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(date47, timeZone68);
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1900 + "'", int16 == 1900);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1900" + "'", str39.equals("1900"));
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertNotNull(timeZone68);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(8, 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
        java.lang.Class class5 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean10 = spreadsheetDate7.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        java.util.Date date11 = spreadsheetDate7.toDate();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date11, timeZone13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date11, timeZone15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean21 = spreadsheetDate18.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.util.Date date22 = spreadsheetDate18.toDate();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date22, timeZone24);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date11, timeZone24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month26.previous();
        org.jfree.data.time.Year year28 = month26.getYear();
        boolean boolean29 = timeSeriesDataItem4.equals((java.lang.Object) year28);
        java.util.Calendar calendar30 = null;
        try {
            year28.peg(calendar30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(year28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.lang.Class class0 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean5 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        java.util.Date date6 = spreadsheetDate2.toDate();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date6, timeZone8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date6, timeZone10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean16 = spreadsheetDate13.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        java.util.Date date17 = spreadsheetDate13.toDate();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17, timeZone19);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date6, timeZone19);
        java.util.Date date22 = month21.getEnd();
        java.lang.Class class23 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean28 = spreadsheetDate25.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        java.util.Date date29 = spreadsheetDate25.toDate();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date29);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date29, timeZone31);
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date29, timeZone33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean39 = spreadsheetDate36.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        java.util.Date date40 = spreadsheetDate36.toDate();
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance(date40);
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date40, timeZone42);
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date29, timeZone42);
        java.util.Date date45 = month44.getEnd();
        boolean boolean46 = month21.equals((java.lang.Object) month44);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month21);
        org.jfree.data.general.SeriesException seriesException49 = new org.jfree.data.general.SeriesException("hi!");
        boolean boolean50 = month21.equals((java.lang.Object) seriesException49);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        timeSeries4.setMaximumItemAge((long) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
        int int9 = spreadsheetDate8.getMonth();
        int int10 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean13 = day11.equals((java.lang.Object) 11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean18 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.util.Date date19 = spreadsheetDate15.toDate();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date19, timeZone21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) year22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean28 = spreadsheetDate25.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        java.util.Date date29 = spreadsheetDate25.toDate();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date29);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date29, timeZone31);
        java.lang.String str33 = year32.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) year32, (org.jfree.data.time.RegularTimePeriod) day38);
        java.lang.Object obj40 = null;
        boolean boolean41 = timeSeries23.equals(obj40);
        try {
            timeSeries23.delete(0, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1900" + "'", str33.equals("1900"));
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Value");
        java.lang.Class class2 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean7 = spreadsheetDate4.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        java.util.Date date8 = spreadsheetDate4.toDate();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8, timeZone10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date8, timeZone12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean18 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.util.Date date19 = spreadsheetDate15.toDate();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date19, timeZone21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date8, timeZone21);
        int int24 = month23.getYearValue();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("");
        int int27 = month23.compareTo((java.lang.Object) timePeriodFormatException26);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent29 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodFormatException26);
        java.lang.Object obj30 = seriesChangeEvent29.getSource();
        java.lang.Object obj31 = seriesChangeEvent29.getSource();
        java.lang.String str32 = seriesChangeEvent29.toString();
        java.lang.Object obj33 = seriesChangeEvent29.getSource();
        java.lang.String str34 = seriesChangeEvent29.toString();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1900 + "'", int24 == 1900);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=org.jfree.data.time.TimePeriodFormatException: ]" + "'", str32.equals("org.jfree.data.general.SeriesChangeEvent[source=org.jfree.data.time.TimePeriodFormatException: ]"));
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=org.jfree.data.time.TimePeriodFormatException: ]" + "'", str34.equals("org.jfree.data.general.SeriesChangeEvent[source=org.jfree.data.time.TimePeriodFormatException: ]"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.removeChangeListener(seriesChangeListener5);
        timeSeries4.removeAgedItems((long) 2958465, true);
        java.lang.Class class10 = timeSeries4.getTimePeriodClass();
        boolean boolean11 = timeSeries4.isEmpty();
        timeSeries4.setRangeDescription("6-January-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str24 = timeSeries23.getDescription();
        boolean boolean25 = timeSeries23.isEmpty();
        java.lang.String str26 = timeSeries23.getDomainDescription();
        java.util.List list27 = timeSeries23.getItems();
        timeSeries23.clear();
        boolean boolean29 = day18.equals((java.lang.Object) timeSeries23);
        int int30 = day18.getDayOfMonth();
        int int31 = day18.getMonth();
        int int32 = day18.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries34 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day18, regularTimePeriod33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        java.lang.String str5 = timeSeries4.getDescription();
        boolean boolean6 = timeSeries4.isEmpty();
        java.lang.String str7 = timeSeries4.getDomainDescription();
        java.util.List list8 = timeSeries4.getItems();
        timeSeries4.setDomainDescription("ERROR : Relative To String");
        int int11 = timeSeries4.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries4.createCopy(0, (int) 'a');
        java.lang.String str15 = timeSeries4.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        java.lang.Class class18 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean23 = spreadsheetDate20.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        java.util.Date date24 = spreadsheetDate20.toDate();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date24, timeZone26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date24, timeZone28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean34 = spreadsheetDate31.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate33);
        java.util.Date date35 = spreadsheetDate31.toDate();
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date35, timeZone37);
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date24, timeZone37);
        boolean boolean40 = timeSeries17.equals((java.lang.Object) month39);
        org.jfree.data.time.Year year41 = month39.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year41.next();
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Value" + "'", str15.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(year41);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        java.util.List list5 = timeSeries4.getItems();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries7.createCopy((int) 'a', (int) (byte) 100);
        timeSeries10.setMaximumItemAge((long) (byte) 10);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener13);
        java.util.Collection collection15 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        timeSeries17.setNotify(true);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(7);
        int int22 = spreadsheetDate21.getMonth();
        int int23 = spreadsheetDate21.getYYYY();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(7);
        int int27 = spreadsheetDate26.getMonth();
        int int28 = spreadsheetDate26.getYYYY();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day24, (org.jfree.data.time.RegularTimePeriod) day29);
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) 100.0d, true);
        timeSeries4.setDescription("Mon Jun 10 11:25:30 PDT 2019");
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1900 + "'", int23 == 1900);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1900 + "'", int28 == 1900);
        org.junit.Assert.assertNotNull(timeSeries30);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean4 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.util.Date date5 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date5);
        java.util.Calendar calendar8 = null;
        fixedMillisecond7.peg(calendar8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("Value");
        java.lang.Class class12 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean17 = spreadsheetDate14.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        java.util.Date date18 = spreadsheetDate14.toDate();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date18, timeZone20);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date18, timeZone22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean28 = spreadsheetDate25.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        java.util.Date date29 = spreadsheetDate25.toDate();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date29);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date29, timeZone31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date18, timeZone31);
        int int34 = month33.getYearValue();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("");
        int int37 = month33.compareTo((java.lang.Object) timePeriodFormatException36);
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
        int int39 = fixedMillisecond7.compareTo((java.lang.Object) timePeriodFormatException36);
        org.jfree.data.general.SeriesException seriesException41 = new org.jfree.data.general.SeriesException("hi!");
        timePeriodFormatException36.addSuppressed((java.lang.Throwable) seriesException41);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1900 + "'", int34 == 1900);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        timeSeries4.setMaximumItemAge((long) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
        int int9 = spreadsheetDate8.getMonth();
        int int10 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean13 = day11.equals((java.lang.Object) 11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean18 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.util.Date date19 = spreadsheetDate15.toDate();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date19, timeZone21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) year22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean28 = spreadsheetDate25.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        java.util.Date date29 = spreadsheetDate25.toDate();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date29);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date29, timeZone31);
        java.lang.String str33 = year32.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) year32, (org.jfree.data.time.RegularTimePeriod) day38);
        java.util.Calendar calendar40 = null;
        try {
            long long41 = year32.getLastMillisecond(calendar40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1900" + "'", str33.equals("1900"));
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(timeSeries39);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.lang.Class class0 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean5 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        java.util.Date date6 = spreadsheetDate2.toDate();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date6, timeZone8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date6, timeZone10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean16 = spreadsheetDate13.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        java.util.Date date17 = spreadsheetDate13.toDate();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17, timeZone19);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date6, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.previous();
        org.jfree.data.time.Year year23 = month21.getYear();
        org.jfree.data.time.Year year24 = month21.getYear();
        java.lang.Class class25 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean30 = spreadsheetDate27.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        java.util.Date date31 = spreadsheetDate27.toDate();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date31, timeZone33);
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date31, timeZone35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean41 = spreadsheetDate38.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate40);
        java.util.Date date42 = spreadsheetDate38.toDate();
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(date42);
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date42, timeZone44);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(date31, timeZone44);
        java.util.Date date47 = month46.getEnd();
        java.lang.Class class48 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean53 = spreadsheetDate50.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate52);
        java.util.Date date54 = spreadsheetDate50.toDate();
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(date54);
        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date54, timeZone56);
        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date54, timeZone58);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean64 = spreadsheetDate61.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate63);
        java.util.Date date65 = spreadsheetDate61.toDate();
        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.createInstance(date65);
        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year(date65, timeZone67);
        org.jfree.data.time.Month month69 = new org.jfree.data.time.Month(date54, timeZone67);
        java.util.Date date70 = month69.getEnd();
        boolean boolean71 = month46.equals((java.lang.Object) month69);
        boolean boolean72 = year24.equals((java.lang.Object) month46);
        long long73 = month46.getLastMillisecond();
        org.jfree.data.time.Year year74 = month46.getYear();
        java.util.Calendar calendar75 = null;
        try {
            long long76 = month46.getLastMillisecond(calendar75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(timeZone56);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertNotNull(timeZone67);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-2206281600001L) + "'", long73 == (-2206281600001L));
        org.junit.Assert.assertNotNull(year74);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean5 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
        int int9 = spreadsheetDate8.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(7);
        int int12 = spreadsheetDate11.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean17 = spreadsheetDate14.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean22 = spreadsheetDate19.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean23 = spreadsheetDate16.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(7);
        int int27 = spreadsheetDate26.getMonth();
        int int28 = spreadsheetDate26.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(7);
        int int31 = spreadsheetDate30.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean36 = spreadsheetDate33.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean38 = spreadsheetDate26.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate30, (org.jfree.data.time.SerialDate) spreadsheetDate33, (int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean41 = spreadsheetDate11.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate16, serialDate39, (-1));
        boolean boolean42 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(7);
        int int45 = spreadsheetDate44.getMonth();
        int int46 = spreadsheetDate44.getYYYY();
        int int47 = spreadsheetDate44.toSerial();
        boolean boolean48 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, (org.jfree.data.time.SerialDate) spreadsheetDate44);
        int int49 = spreadsheetDate44.toSerial();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 7 + "'", int12 == 7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1900 + "'", int28 == 1900);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 7 + "'", int31 == 7);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1900 + "'", int46 == 1900);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 7 + "'", int47 == 7);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 7 + "'", int49 == 7);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        timeSeries4.setMaximumItemAge((long) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(7);
        int int9 = spreadsheetDate8.getMonth();
        int int10 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean13 = day11.equals((java.lang.Object) 11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean18 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.util.Date date19 = spreadsheetDate15.toDate();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date19, timeZone21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) year22);
        long long24 = year22.getSerialIndex();
        long long25 = year22.getLastMillisecond();
        long long26 = year22.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year22.previous();
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1900L + "'", long24 == 1900L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-2177424000001L) + "'", long25 == (-2177424000001L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-2177424000001L) + "'", long26 == (-2177424000001L));
        org.junit.Assert.assertNull(regularTimePeriod27);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy((int) 'a', (int) (byte) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.removeChangeListener(seriesChangeListener5);
        timeSeries4.removeAgedItems((long) 2958465, true);
        boolean boolean11 = timeSeries4.equals((java.lang.Object) (-2207620800001L));
        timeSeries4.setDomainDescription("Mon Jun 10 11:25:30 PDT 2019");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(7);
        int int16 = spreadsheetDate15.getMonth();
        int int17 = spreadsheetDate15.getYYYY();
        java.util.Date date18 = spreadsheetDate15.toDate();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        long long20 = month19.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month19.next();
        java.lang.Class class22 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean27 = spreadsheetDate24.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        java.util.Date date28 = spreadsheetDate24.toDate();
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date28);
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date28, timeZone30);
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date28, timeZone32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean38 = spreadsheetDate35.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        java.util.Date date39 = spreadsheetDate35.toDate();
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(date39);
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date39, timeZone41);
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date28, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month43.previous();
        org.jfree.data.time.Year year45 = month43.getYear();
        org.jfree.data.time.Year year46 = month43.getYear();
        java.lang.Class class47 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean52 = spreadsheetDate49.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate51);
        java.util.Date date53 = spreadsheetDate49.toDate();
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(date53);
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date53, timeZone55);
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date53, timeZone57);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean63 = spreadsheetDate60.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate62);
        java.util.Date date64 = spreadsheetDate60.toDate();
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.createInstance(date64);
        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(date64, timeZone66);
        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month(date53, timeZone66);
        java.util.Date date69 = month68.getEnd();
        java.lang.Class class70 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate72 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean75 = spreadsheetDate72.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate74);
        java.util.Date date76 = spreadsheetDate72.toDate();
        org.jfree.data.time.SerialDate serialDate77 = org.jfree.data.time.SerialDate.createInstance(date76);
        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year(date76, timeZone78);
        java.util.TimeZone timeZone80 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance(class70, date76, timeZone80);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate83 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate85 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean86 = spreadsheetDate83.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate85);
        java.util.Date date87 = spreadsheetDate83.toDate();
        org.jfree.data.time.SerialDate serialDate88 = org.jfree.data.time.SerialDate.createInstance(date87);
        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year90 = new org.jfree.data.time.Year(date87, timeZone89);
        org.jfree.data.time.Month month91 = new org.jfree.data.time.Month(date76, timeZone89);
        java.util.Date date92 = month91.getEnd();
        boolean boolean93 = month68.equals((java.lang.Object) month91);
        boolean boolean94 = year46.equals((java.lang.Object) month68);
        long long95 = month68.getLastMillisecond();
        org.jfree.data.time.Year year96 = month68.getYear();
        int int97 = month68.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries98 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) month19, (org.jfree.data.time.RegularTimePeriod) month68);
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1900 + "'", int17 == 1900);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-2208960000000L) + "'", long20 == (-2208960000000L));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(year45);
        org.junit.Assert.assertNotNull(year46);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(serialDate77);
        org.junit.Assert.assertNotNull(timeZone78);
        org.junit.Assert.assertNotNull(timeZone80);
        org.junit.Assert.assertNull(regularTimePeriod81);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertNotNull(date87);
        org.junit.Assert.assertNotNull(serialDate88);
        org.junit.Assert.assertNotNull(timeZone89);
        org.junit.Assert.assertNotNull(date92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + long95 + "' != '" + (-2206281600001L) + "'", long95 == (-2206281600001L));
        org.junit.Assert.assertNotNull(year96);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 1900 + "'", int97 == 1900);
        org.junit.Assert.assertNotNull(timeSeries98);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test162");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean4 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        java.util.Date date5 = spreadsheetDate1.toDate();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date5);
//        java.util.Calendar calendar8 = null;
//        fixedMillisecond7.peg(calendar8);
//        long long10 = fixedMillisecond7.getMiddleMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(7);
//        boolean boolean15 = spreadsheetDate12.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        java.util.Date date16 = spreadsheetDate12.toDate();
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date16);
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date16, timeZone18);
//        boolean boolean20 = fixedMillisecond7.equals((java.lang.Object) timeZone18);
//        long long21 = fixedMillisecond7.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2208527999050L) + "'", long10 == (-2208527999050L));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-2208527999050L) + "'", long21 == (-2208527999050L));
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(12);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        java.util.Date date4 = spreadsheetDate1.toDate();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(7);
        int int8 = spreadsheetDate7.getMonth();
        int int9 = spreadsheetDate7.getYYYY();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate7);
        boolean boolean12 = day10.equals((java.lang.Object) 11);
        int int13 = day10.getMonth();
        int int14 = day10.getMonth();
        boolean boolean15 = month5.equals((java.lang.Object) day10);
        java.lang.Object obj16 = null;
        int int17 = day10.compareTo(obj16);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1900 + "'", int9 == 1900);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(7);
        int int6 = spreadsheetDate5.getMonth();
        int int7 = spreadsheetDate5.getYYYY();
        boolean boolean8 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int9 = spreadsheetDate5.getDayOfMonth();
        int int10 = spreadsheetDate5.toSerial();
        int int11 = spreadsheetDate5.getYYYY();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries13.createCopy((int) 'a', (int) (byte) 100);
        timeSeries16.setMaximumItemAge((long) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(7);
        int int21 = spreadsheetDate20.getMonth();
        int int22 = spreadsheetDate20.getYYYY();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean25 = day23.equals((java.lang.Object) 11);
        int int26 = day23.getMonth();
        int int27 = day23.getMonth();
        int int28 = day23.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) (short) -1);
        java.lang.String str31 = timeSeries16.getDescription();
        java.lang.String str32 = timeSeries16.getDescription();
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries34.createCopy((int) 'a', (int) (byte) 100);
        timeSeries37.setMaximumItemAge((long) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(7);
        int int42 = spreadsheetDate41.getMonth();
        int int43 = spreadsheetDate41.getYYYY();
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate41);
        boolean boolean46 = day44.equals((java.lang.Object) 11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean51 = spreadsheetDate48.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate50);
        java.util.Date date52 = spreadsheetDate48.toDate();
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance(date52);
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date52, timeZone54);
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries37.createCopy((org.jfree.data.time.RegularTimePeriod) day44, (org.jfree.data.time.RegularTimePeriod) year55);
        java.util.List list57 = timeSeries56.getItems();
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
        org.jfree.data.time.TimeSeries timeSeries62 = timeSeries59.createCopy((int) 'a', (int) (byte) 100);
        timeSeries62.setMaximumItemAge((long) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(7);
        int int67 = spreadsheetDate66.getMonth();
        int int68 = spreadsheetDate66.getYYYY();
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate66);
        boolean boolean71 = day69.equals((java.lang.Object) 11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate73 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean76 = spreadsheetDate73.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate75);
        java.util.Date date77 = spreadsheetDate73.toDate();
        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.createInstance(date77);
        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year(date77, timeZone79);
        org.jfree.data.time.TimeSeries timeSeries81 = timeSeries62.createCopy((org.jfree.data.time.RegularTimePeriod) day69, (org.jfree.data.time.RegularTimePeriod) year80);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem83 = timeSeries56.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year80, (double) (byte) 1);
        int int84 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) year80);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate86 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate88 = new org.jfree.data.time.SpreadsheetDate(7);
        boolean boolean89 = spreadsheetDate86.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate88);
        java.util.Date date90 = spreadsheetDate86.toDate();
        org.jfree.data.time.Month month91 = new org.jfree.data.time.Month(date90);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem93 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month91, (java.lang.Number) (-2208527999490L));
        java.lang.Number number94 = timeSeriesDataItem93.getValue();
        boolean boolean95 = spreadsheetDate5.equals((java.lang.Object) timeSeriesDataItem93);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1900 + "'", int7 == 1900);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 7 + "'", int10 == 7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1900 + "'", int11 == 1900);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1900 + "'", int22 == 1900);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1900 + "'", int43 == 1900);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertNotNull(list57);
        org.junit.Assert.assertNotNull(timeSeries62);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1900 + "'", int68 == 1900);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertNotNull(serialDate78);
        org.junit.Assert.assertNotNull(timeZone79);
        org.junit.Assert.assertNotNull(timeSeries81);
        org.junit.Assert.assertNull(timeSeriesDataItem83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertNotNull(date90);
        org.junit.Assert.assertNotNull(timeSeriesDataItem93);
        org.junit.Assert.assertTrue("'" + number94 + "' != '" + (-1.0d) + "'", number94.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
    }
}

