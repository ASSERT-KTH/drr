import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("({0}, {1}) = {3} - {4}", graphics2D1, (float) 10, (float) 900000L, (double) 128, (float) 10L, (float) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setStartAngle(0.0d);
        ringPlot0.setIgnoreNullValues(true);
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint6 = polarPlot5.getOutlinePaint();
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot5.setOutlineStroke(stroke7);
        java.lang.String str9 = polarPlot5.getPlotType();
        java.awt.Paint paint10 = polarPlot5.getOutlinePaint();
        java.awt.Paint paint11 = polarPlot5.getBackgroundPaint();
        ringPlot0.setLabelLinkPaint(paint11);
        java.lang.Comparable comparable13 = null;
        try {
            java.awt.Paint paint14 = ringPlot0.getSectionOutlinePaint(comparable13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Polar Plot" + "'", str9.equals("Polar Plot"));
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = statisticalLineAndShapeRenderer2.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = statisticalLineAndShapeRenderer2.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer15.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint21 = statisticalLineAndShapeRenderer15.getItemOutlinePaint((-1), 0);
        statisticalLineAndShapeRenderer2.setBaseOutlinePaint(paint21, true);
        java.awt.Font font26 = statisticalLineAndShapeRenderer2.getItemLabelFont(8, 8);
        java.awt.Stroke stroke28 = null;
        statisticalLineAndShapeRenderer2.setSeriesOutlineStroke(2, stroke28, true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor31 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.jfree.chart.text.TextAnchor textAnchor32 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor33 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor31, textAnchor32, textAnchor33, 1.0d);
        statisticalLineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition35, false);
        boolean boolean40 = statisticalLineAndShapeRenderer2.getItemShapeVisible(2, 0);
        java.awt.Stroke stroke41 = null;
        try {
            statisticalLineAndShapeRenderer2.setBaseOutlineStroke(stroke41, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(itemLabelAnchor31);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertNotNull(textAnchor33);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = barRenderer0.getPlot();
        double double2 = barRenderer0.getBase();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertNull(categoryPlot1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(itemLabelPosition3);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke3 = polarPlot2.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', (java.awt.Paint) color1, stroke3);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int6 = taskSeriesCollection5.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries8 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection5.add(taskSeries8);
        org.jfree.data.gantt.TaskSeries taskSeries11 = taskSeriesCollection5.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, (java.lang.Comparable) "CONTRACT");
        boolean boolean14 = categoryMarker4.equals((java.lang.Object) taskSeriesCollection5);
        java.awt.Color color15 = java.awt.Color.GREEN;
        categoryMarker4.setPaint((java.awt.Paint) color15);
        java.awt.Paint paint17 = categoryMarker4.getLabelPaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent18 = null;
        categoryMarker4.notifyListeners(markerChangeEvent18);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(taskSeries11);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset3.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.general.DatasetGroup datasetGroup9 = defaultStatisticalCategoryDataset3.getGroup();
        java.lang.Comparable comparable11 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity12 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "hi!", "", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, (java.lang.Comparable) 1.0d, comparable11);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean16 = statisticalLineAndShapeRenderer15.getBaseItemLabelsVisible();
        int int17 = statisticalLineAndShapeRenderer15.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = null;
        statisticalLineAndShapeRenderer15.setSeriesNegativeItemLabelPosition(0, itemLabelPosition19);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator23 = statisticalLineAndShapeRenderer15.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = statisticalLineAndShapeRenderer15.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor26 = itemLabelPosition25.getRotationAnchor();
        boolean boolean27 = defaultStatisticalCategoryDataset3.equals((java.lang.Object) textAnchor26);
        int int28 = defaultStatisticalCategoryDataset3.getColumnCount();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(datasetGroup9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator23);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
        org.junit.Assert.assertNotNull(textAnchor26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint8 = statisticalLineAndShapeRenderer2.getItemOutlinePaint((-1), 0);
        boolean boolean11 = statisticalLineAndShapeRenderer2.getItemVisible(7, (int) (short) 10);
        java.awt.Shape shape13 = statisticalLineAndShapeRenderer2.getSeriesShape((int) (byte) -1);
        boolean boolean14 = statisticalLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYPlot0.setRangeCrosshairStroke(stroke3);
        xYPlot0.setBackgroundImageAlignment((int) (short) 10);
        boolean boolean7 = xYPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("LengthConstraintType.NONE");
        xYPlot0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis3D10);
        java.awt.Color color13 = java.awt.Color.blue;
        try {
            xYPlot0.setQuadrantPaint(1900, (java.awt.Paint) color13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.lang.String str3 = textTitle2.getToolTipText();
        textTitle2.setWidth(0.0d);
        java.awt.Font font6 = textTitle2.getFont();
        textTitle2.setPadding(4.0d, (double) ' ', (double) 1L, (double) 1L);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("LengthConstraintType.NONE");
        numberAxis3D14.setLabelToolTip("");
        org.jfree.chart.entity.EntityCollection entityCollection18 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo(entityCollection18);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryAxis20.getLabelInsets();
        double double23 = rectangleInsets21.trimWidth((double) (byte) 10);
        double double25 = rectangleInsets21.calculateTopInset((-1.0d));
        double double27 = rectangleInsets21.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock29 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str30 = labelBlock29.getToolTipText();
        java.lang.String str31 = labelBlock29.getURLText();
        java.awt.geom.Rectangle2D rectangle2D32 = labelBlock29.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType33 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType34 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str35 = lengthAdjustmentType34.toString();
        java.awt.geom.Rectangle2D rectangle2D36 = rectangleInsets21.createAdjustedRectangle(rectangle2D32, lengthAdjustmentType33, lengthAdjustmentType34);
        chartRenderingInfo19.setChartArea(rectangle2D32);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean39 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge38);
        double double40 = numberAxis3D14.valueToJava2D(0.25d, rectangle2D32, rectangleEdge38);
        textTitle2.draw(graphics2D12, rectangle2D32);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 3.0d + "'", double25 == 3.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(lengthAdjustmentType33);
        org.junit.Assert.assertNotNull(lengthAdjustmentType34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "CONTRACT" + "'", str35.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeObject((java.lang.Comparable) "Polar Plot", (java.lang.Comparable) 10.0f);
        try {
            java.lang.Object obj6 = keyedObjects2D0.getObject((int) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint8 = statisticalLineAndShapeRenderer2.getItemOutlinePaint((-1), 0);
        boolean boolean11 = statisticalLineAndShapeRenderer2.getItemVisible(7, (int) (short) 10);
        statisticalLineAndShapeRenderer2.setBaseCreateEntities(true, false);
        org.jfree.chart.LegendItem legendItem17 = statisticalLineAndShapeRenderer2.getLegendItem((int) (byte) 0, (int) (byte) 100);
        int int18 = statisticalLineAndShapeRenderer2.getRowCount();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(legendItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = dateAxis5.getStandardTickUnits();
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis5.setRangeWithMargins((org.jfree.data.Range) dateRange9, false, false);
        dateAxis5.setAutoRange(false);
        double double15 = dateAxis5.getAutoRangeMinimumSize();
        double double16 = dateAxis5.getAutoRangeMinimumSize();
        org.jfree.data.Range range17 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0d + "'", double15 == 2.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer0.setMaximumItemWidth((double) 900000L);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list2 = defaultKeyedValues2D1.getRowKeys();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str5 = spreadsheetDate4.getDescription();
        int int6 = spreadsheetDate4.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str9 = spreadsheetDate8.getDescription();
        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int11 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) spreadsheetDate8);
        java.lang.Object obj12 = defaultKeyedValues2D1.clone();
        try {
            java.lang.Comparable comparable14 = defaultKeyedValues2D1.getRowKey(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateX((double) (short) 10);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        java.lang.Object obj5 = null;
        boolean boolean6 = xYPlot0.equals(obj5);
        xYPlot0.setRangeCrosshairValue((double) ' ');
        xYPlot0.setRangeZeroBaselineVisible(false);
        java.awt.Image image11 = null;
        xYPlot0.setBackgroundImage(image11);
        org.jfree.chart.axis.AxisSpace axisSpace13 = new org.jfree.chart.axis.AxisSpace();
        axisSpace13.setLeft((double) (short) 10);
        xYPlot0.setFixedRangeAxisSpace(axisSpace13);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(0L, 0, 15);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        java.awt.Paint paint5 = jFreeChart4.getBorderPaint();
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart4.getTitle();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(textTitle6);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 1, (double) (short) 10, false);
        java.awt.Font font4 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        stackedBarRenderer3D3.setBaseItemLabelFont(font4, true);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str11 = labelBlock10.getToolTipText();
        java.lang.String str12 = labelBlock10.getURLText();
        java.awt.geom.Rectangle2D rectangle2D13 = labelBlock10.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D13, "Polar Plot", "LengthConstraintType.NONE");
        try {
            stackedBarRenderer3D3.drawBackground(graphics2D7, categoryPlot8, rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(rectangle2D13);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        int int3 = color2.getGreen();
        boolean boolean4 = year0.equals((java.lang.Object) color2);
        java.lang.String str5 = year0.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 128 + "'", int3 == 128);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis0);
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = dateAxis4.getStandardTickUnits();
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis4.setRangeWithMargins((org.jfree.data.Range) dateRange8, false, false);
        dateAxis4.setAutoRange(false);
        java.util.Date date14 = dateAxis4.getMinimumDate();
        boolean boolean15 = dateAxis4.isVerticalTickLabels();
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str17 = dateTickUnit16.toString();
        double double18 = dateTickUnit16.getSize();
        dateAxis4.setTickUnit(dateTickUnit16);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis20);
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis20.setTickUnit(dateTickUnit22);
        java.util.Date date24 = dateAxis4.calculateLowestVisibleTickValue(dateTickUnit22);
        dateAxis0.setTickUnit(dateTickUnit22);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint27 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        categoryAxis26.setTickMarkPaint(paint27);
        java.lang.String str29 = categoryAxis26.getLabel();
        java.awt.Paint paint30 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryAxis26.setLabelPaint(paint30);
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity36 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis26, shape33, "({0}, {1}) = {2}", "({0}, {1}) = {2}");
        boolean boolean37 = categoryAxis26.isAxisLineVisible();
        boolean boolean38 = dateTickUnit22.equals((java.lang.Object) boolean37);
        java.lang.String str39 = dateTickUnit22.toString();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTickUnit16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "DateTickUnit[DAY, 1]" + "'", str17.equals("DateTickUnit[DAY, 1]"));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.64E7d + "'", double18 == 8.64E7d);
        org.junit.Assert.assertNotNull(dateTickUnit22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DateTickUnit[DAY, 1]" + "'", str39.equals("DateTickUnit[DAY, 1]"));
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 1, (double) (short) 10, false);
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean5 = polarPlot4.isOutlineVisible();
        polarPlot4.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot4);
        java.awt.Stroke stroke9 = jFreeChart8.getBorderStroke();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) false, jFreeChart8, 9999, (int) '4');
        org.jfree.chart.JFreeChart jFreeChart13 = chartProgressEvent12.getChart();
        java.awt.RenderingHints renderingHints14 = jFreeChart13.getRenderingHints();
        java.awt.image.BufferedImage bufferedImage17 = jFreeChart13.createBufferedImage((int) (short) 100, 5);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(jFreeChart13);
        org.junit.Assert.assertNotNull(renderingHints14);
        org.junit.Assert.assertNotNull(bufferedImage17);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        textBlock1.draw(graphics2D2, (float) (byte) 100, (float) (byte) 1, textBlockAnchor5, (float) 7, (float) '4', (double) (short) 100);
        java.util.List list10 = textBlock1.getLines();
        org.jfree.chart.text.TextBlock textBlock11 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        textBlock11.draw(graphics2D12, (float) (byte) 100, (float) (byte) 1, textBlockAnchor15, (float) 7, (float) '4', (double) (short) 100);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.axis.CategoryTick categoryTick22 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 900000L, textBlock1, textBlockAnchor15, textAnchor20, (double) (-329600));
        org.jfree.chart.text.TextBlock textBlock23 = categoryTick22.getLabel();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor27 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        textBlock23.draw(graphics2D24, 0.0f, 10.0f, textBlockAnchor27);
        org.jfree.chart.block.BlockContainer blockContainer29 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement30 = blockContainer29.getArrangement();
        org.jfree.chart.block.BorderArrangement borderArrangement31 = new org.jfree.chart.block.BorderArrangement();
        java.awt.Image image35 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo39 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image35, "", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray40 = projectInfo39.getLibraries();
        java.lang.String str41 = projectInfo39.getName();
        boolean boolean42 = borderArrangement31.equals((java.lang.Object) projectInfo39);
        org.jfree.chart.plot.RingPlot ringPlot43 = new org.jfree.chart.plot.RingPlot();
        boolean boolean44 = borderArrangement31.equals((java.lang.Object) ringPlot43);
        blockContainer29.setArrangement((org.jfree.chart.block.Arrangement) borderArrangement31);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer48 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean49 = statisticalLineAndShapeRenderer48.getBaseItemLabelsVisible();
        int int50 = statisticalLineAndShapeRenderer48.getPassCount();
        java.awt.Font font51 = statisticalLineAndShapeRenderer48.getBaseItemLabelFont();
        java.awt.Shape shape53 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape57 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape53, rectangleAnchor54, (double) (short) 100, (double) 4);
        statisticalLineAndShapeRenderer48.setBaseShape(shape57, false);
        boolean boolean60 = statisticalLineAndShapeRenderer48.getUseFillPaint();
        org.jfree.chart.title.LegendTitle legendTitle61 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalLineAndShapeRenderer48);
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke63 = categoryAxis62.getTickMarkStroke();
        boolean boolean64 = legendTitle61.equals((java.lang.Object) stroke63);
        java.awt.Graphics2D graphics2D65 = null;
        org.jfree.data.Range range66 = null;
        org.jfree.data.Range range68 = org.jfree.data.Range.expandToInclude(range66, (double) 1.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint70 = new org.jfree.chart.block.RectangleConstraint(range68, (double) (short) 1);
        org.jfree.chart.axis.DateAxis dateAxis71 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource72 = dateAxis71.getStandardTickUnits();
        org.jfree.data.time.DateRange dateRange75 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis71.setRangeWithMargins((org.jfree.data.Range) dateRange75, false, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint79 = new org.jfree.chart.block.RectangleConstraint(range68, (org.jfree.data.Range) dateRange75);
        org.jfree.data.Range range81 = null;
        org.jfree.data.Range range83 = org.jfree.data.Range.expandToInclude(range81, (double) 1.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint85 = new org.jfree.chart.block.RectangleConstraint(range83, (double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint86 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, range83);
        org.jfree.data.Range range89 = org.jfree.data.Range.expand(range83, (double) 6, (double) 8);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint90 = rectangleConstraint79.toRangeWidth(range83);
        org.jfree.chart.util.Size2D size2D91 = legendTitle61.arrange(graphics2D65, rectangleConstraint90);
        blockContainer29.add((org.jfree.chart.block.Block) legendTitle61);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment93 = legendTitle61.getHorizontalAlignment();
        textBlock23.setLineAlignment(horizontalAlignment93);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(textBlockAnchor15);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(textBlock23);
        org.junit.Assert.assertNotNull(textBlockAnchor27);
        org.junit.Assert.assertNotNull(arrangement30);
        org.junit.Assert.assertNotNull(libraryArray40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2 + "'", int50 == 2);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNotNull(rectangleAnchor54);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(range68);
        org.junit.Assert.assertNotNull(tickUnitSource72);
        org.junit.Assert.assertNotNull(range83);
        org.junit.Assert.assertNotNull(range89);
        org.junit.Assert.assertNotNull(rectangleConstraint90);
        org.junit.Assert.assertNotNull(size2D91);
        org.junit.Assert.assertNotNull(horizontalAlignment93);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean6 = statisticalLineAndShapeRenderer5.getBaseItemLabelsVisible();
        int int7 = statisticalLineAndShapeRenderer5.getPassCount();
        java.awt.Font font8 = statisticalLineAndShapeRenderer5.getBaseItemLabelFont();
        java.awt.Paint paint9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("CONTRACT", font8, paint9, (float) '4');
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("NOID", font8);
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("DateTickUnit[DAY, 1]", font8);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer21 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean22 = statisticalLineAndShapeRenderer21.getBaseItemLabelsVisible();
        int int23 = statisticalLineAndShapeRenderer21.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = null;
        statisticalLineAndShapeRenderer21.setSeriesNegativeItemLabelPosition(0, itemLabelPosition25);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator29 = statisticalLineAndShapeRenderer21.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = statisticalLineAndShapeRenderer21.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor32 = itemLabelPosition31.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType34 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.awt.Color color35 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        boolean boolean36 = categoryLabelWidthType34.equals((java.lang.Object) color35);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition38 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor17, textBlockAnchor18, textAnchor32, 8.64E7d, categoryLabelWidthType34, (float) 0L);
        try {
            textFragment13.draw(graphics2D14, (float) 35L, (float) 1900, textAnchor32, (float) (short) 1, (float) 10, (double) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(textBlockAnchor18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator29);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertNotNull(categoryLabelWidthType34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        java.lang.String str4 = polarPlot3.getNoDataMessage();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        polarPlot3.rendererChanged(rendererChangeEvent5);
        polarPlot3.addCornerTextItem("NOID");
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        polarPlot3.setRadiusGridlineStroke(stroke9);
        boolean boolean11 = dateRange2.equals((java.lang.Object) polarPlot3);
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint13 = null;
        ringPlot12.setShadowPaint(paint13);
        double double15 = ringPlot12.getMaximumLabelWidth();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot12);
        polarPlot3.notifyListeners(plotChangeEvent16);
        org.jfree.chart.plot.Plot plot18 = plotChangeEvent16.getPlot();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.2d + "'", double15 == 0.2d);
        org.junit.Assert.assertNotNull(plot18);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.lang.String str3 = textTitle2.getToolTipText();
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("hi!", font5);
        java.lang.String str7 = textTitle6.getToolTipText();
        textTitle6.setWidth(0.0d);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle6);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = textTitle6.getVerticalAlignment();
        textTitle2.setVerticalAlignment(verticalAlignment11);
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean14 = polarPlot13.isOutlineVisible();
        polarPlot13.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot13);
        java.awt.Paint paint18 = jFreeChart17.getBorderPaint();
        java.lang.Object obj19 = jFreeChart17.getTextAntiAlias();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textTitle2, jFreeChart17);
        int int21 = jFreeChart17.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(obj19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.LegendItem legendItem3 = areaRenderer0.getLegendItem(0, 2019);
        org.junit.Assert.assertNull(legendItem3);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint8 = statisticalLineAndShapeRenderer2.getItemOutlinePaint((-1), 0);
        boolean boolean10 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) 2958465);
        java.awt.Color color12 = java.awt.Color.BLUE;
        statisticalLineAndShapeRenderer2.setSeriesOutlinePaint(4, (java.awt.Paint) color12);
        int int14 = color12.getGreen();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = org.jfree.chart.block.LengthConstraintType.RANGE;
        java.lang.String str16 = lengthConstraintType15.toString();
        boolean boolean17 = color12.equals((java.lang.Object) str16);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "RectangleConstraintType.RANGE" + "'", str16.equals("RectangleConstraintType.RANGE"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint6 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        statisticalLineAndShapeRenderer2.setBasePaint(paint6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis8.getLabelInsets();
        java.awt.Stroke stroke10 = categoryAxis8.getAxisLineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis11.getLabelInsets();
        double double14 = rectangleInsets12.trimWidth((double) (byte) 10);
        double double16 = rectangleInsets12.calculateTopInset((-1.0d));
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder(paint6, stroke10, rectangleInsets12);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline18 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        boolean boolean19 = lineBorder17.equals((java.lang.Object) segmentedTimeline18);
        segmentedTimeline18.addException((long) (-1), (long) (-460));
        long long23 = segmentedTimeline18.getSegmentsExcludedSize();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 3.0d + "'", double16 == 3.0d);
        org.junit.Assert.assertNotNull(segmentedTimeline18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 172800000L + "'", long23 == 172800000L);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) 1.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint(range3, (double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, range3);
        org.jfree.data.Range range7 = rectangleConstraint6.getWidthRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = rectangleConstraint6.getHeightConstraintType();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint8 = statisticalLineAndShapeRenderer2.getItemOutlinePaint((-1), 0);
        boolean boolean11 = statisticalLineAndShapeRenderer2.getItemVisible(7, (int) (short) 10);
        statisticalLineAndShapeRenderer2.setBaseCreateEntities(true, false);
        org.jfree.chart.LegendItem legendItem17 = statisticalLineAndShapeRenderer2.getLegendItem((int) (byte) 0, (int) (byte) 100);
        java.awt.Shape shape20 = statisticalLineAndShapeRenderer2.getItemShape((-460), 11);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(legendItem17);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.List list1 = segmentedTimeline0.getExceptionSegments();
        segmentedTimeline0.setStartTime(0L);
        segmentedTimeline0.setStartTime((long) (byte) 100);
        segmentedTimeline0.addException((long) 12, 35L);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        java.lang.Number number5 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) 1, (java.lang.Comparable) (short) 0);
        java.util.List list6 = defaultStatisticalCategoryDataset0.getColumnKeys();
        int int8 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "RectangleConstraintType.RANGE");
        java.lang.Number number9 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.KeyToGroupMap keyToGroupMap11 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 1.0E-5d);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, keyToGroupMap11);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        dateAxis14.setRangeWithMargins((double) 1L, 12.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis14.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource20 = dateAxis19.getStandardTickUnits();
        org.jfree.data.time.DateRange dateRange23 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis19.setRangeWithMargins((org.jfree.data.Range) dateRange23, false, false);
        dateAxis19.setAutoRange(false);
        java.util.Date date29 = dateAxis19.getMinimumDate();
        java.util.Date date30 = dateTickUnit18.rollDate(date29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.data.DefaultKeyedValue defaultKeyedValue34 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) "DateTickUnit[DAY, 1]", (java.lang.Number) 128);
        int int35 = year31.compareTo((java.lang.Object) defaultKeyedValue34);
        keyToGroupMap11.mapKeyToGroup((java.lang.Comparable) 12, (java.lang.Comparable) year31);
        java.util.Date date37 = year31.getStart();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertEquals((double) number9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(tickUnitSource20);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(date37);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        float float4 = polarPlot0.getBackgroundAlpha();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        polarPlot0.setDataset(xYDataset5);
        polarPlot0.setBackgroundAlpha((float) 11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        java.awt.Stroke stroke5 = xYPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint14 = statisticalLineAndShapeRenderer8.getItemOutlinePaint((-1), 0);
        boolean boolean15 = statisticalLineAndShapeRenderer8.getUseOutlinePaint();
        statisticalLineAndShapeRenderer8.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.block.FlowArrangement flowArrangement18 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent19 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) flowArrangement18);
        statisticalLineAndShapeRenderer8.notifyListeners(rendererChangeEvent19);
        xYPlot0.rendererChanged(rendererChangeEvent19);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot0.getDomainAxisLocation((int) '4');
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        dateAxis25.resizeRange(1.0d);
        xYPlot0.setDomainAxis(5, (org.jfree.chart.axis.ValueAxis) dateAxis25);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = dateAxis25.getLabelInsets();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(rectangleInsets29);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test41");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Paint paint3 = intervalBarRenderer0.getItemPaint((int) (byte) -1, (int) (byte) 10);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray7 = new java.lang.Number[][] { numberArray2, numberArray3, numberArray4, numberArray5, numberArray6 };
        org.jfree.data.category.CategoryDataset categoryDataset8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("DateTickUnit[DAY, 1]", "LengthConstraintType.NONE", numberArray7);
        java.lang.Number[] numberArray11 = new java.lang.Number[] {};
        java.lang.Number[] numberArray12 = new java.lang.Number[] {};
        java.lang.Number[] numberArray13 = new java.lang.Number[] {};
        java.lang.Number[] numberArray14 = new java.lang.Number[] {};
        java.lang.Number[] numberArray15 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray11, numberArray12, numberArray13, numberArray14, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("DateTickUnit[DAY, 1]", "LengthConstraintType.NONE", numberArray16);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset18 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray7, numberArray16);
        java.util.List list19 = defaultIntervalCategoryDataset18.getColumnKeys();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        double double21 = dateAxis20.getUpperMargin();
        org.jfree.data.Range range22 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis20.setRange(range22, false, true);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        dateAxis26.setRangeWithMargins((double) 1L, 12.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = dateAxis26.getTickUnit();
        dateAxis20.setTickUnit(dateTickUnit30, false, true);
        try {
            java.lang.Number number35 = defaultIntervalCategoryDataset18.getEndValue((java.lang.Comparable) dateTickUnit30, (java.lang.Comparable) "2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown 'series' key.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(categoryDataset8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(dateTickUnit30);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        float float4 = polarPlot0.getBackgroundAlpha();
        boolean boolean5 = polarPlot0.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        try {
            defaultKeyedValues2D1.removeRow((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test45");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 10L, (double) 100);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset3.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.general.DatasetGroup datasetGroup9 = defaultStatisticalCategoryDataset3.getGroup();
        boolean boolean10 = meanAndStandardDeviation2.equals((java.lang.Object) datasetGroup9);
        org.junit.Assert.assertNotNull(datasetGroup9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        try {
            java.lang.Number number5 = taskSeriesCollection0.getEndValue((java.lang.Comparable) "2019", (java.lang.Comparable) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) 5, (double) (byte) 100);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test48");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = barRenderer0.getPlot();
        double double2 = barRenderer0.getMaximumBarWidth();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block6 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean10 = statisticalLineAndShapeRenderer9.getBaseItemLabelsVisible();
        int int11 = statisticalLineAndShapeRenderer9.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = null;
        statisticalLineAndShapeRenderer9.setSeriesNegativeItemLabelPosition(0, itemLabelPosition13);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator17 = statisticalLineAndShapeRenderer9.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = statisticalLineAndShapeRenderer9.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        flowArrangement5.add(block6, (java.lang.Object) itemLabelPosition19);
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition19);
        org.jfree.chart.block.LineBorder lineBorder22 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke23 = lineBorder22.getStroke();
        barRenderer0.setBaseStroke(stroke23, false);
        java.awt.Paint paint28 = barRenderer0.getItemPaint(0, (-1));
        org.junit.Assert.assertNull(categoryPlot1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNull(itemLabelPosition3);
        org.junit.Assert.assertNull(itemLabelPosition4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator17);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test49");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setStartAngle(0.0d);
        java.lang.Object obj3 = ringPlot0.clone();
        ringPlot0.setSectionDepth(0.0d);
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer6 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint7 = waterfallBarRenderer6.getLastBarPaint();
        java.awt.Paint paint8 = waterfallBarRenderer6.getPositiveBarPaint();
        ringPlot0.setLabelLinkPaint(paint8);
        java.awt.Stroke stroke10 = ringPlot0.getSeparatorStroke();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test50");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setStartAngle(0.0d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        ringPlot0.setLabelGenerator(pieSectionLabelGenerator3);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test51");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test52");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint8 = statisticalLineAndShapeRenderer2.getItemOutlinePaint((-1), 0);
        boolean boolean9 = statisticalLineAndShapeRenderer2.getUseOutlinePaint();
        statisticalLineAndShapeRenderer2.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) flowArrangement12);
        statisticalLineAndShapeRenderer2.notifyListeners(rendererChangeEvent13);
        boolean boolean15 = statisticalLineAndShapeRenderer2.getBaseSeriesVisible();
        statisticalLineAndShapeRenderer2.setAutoPopulateSeriesOutlinePaint(true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test53");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.HOUR_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 3600000L + "'", long0 == 3600000L);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test54");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        double double3 = rectangleInsets1.trimWidth((double) (byte) 10);
        double double5 = rectangleInsets1.calculateLeftOutset(0.0d);
        double double7 = rectangleInsets1.calculateBottomOutset((double) (byte) 10);
        double double8 = rectangleInsets1.getRight();
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets1.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets(unitType9, (double) 52.0f, 0.0d, 0.0d, (double) (short) 10);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
        org.junit.Assert.assertNotNull(unitType9);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test55");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        double double1 = levelRenderer0.getItemMargin();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test56");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str9 = spreadsheetDate8.getDescription();
        int int10 = spreadsheetDate8.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str13 = spreadsheetDate12.getDescription();
        org.jfree.data.time.SerialDate serialDate14 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        java.lang.Number number15 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) (-1.0f), (java.lang.Comparable) serialDate14);
        org.jfree.data.KeyedObjects2D keyedObjects2D16 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D16.removeObject((java.lang.Comparable) "Polar Plot", (java.lang.Comparable) 10.0f);
        java.awt.Stroke stroke20 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        boolean boolean21 = keyedObjects2D16.equals((java.lang.Object) stroke20);
        boolean boolean22 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) boolean21);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test57");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder4 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        int int6 = xYPlot0.indexOf(xYDataset5);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test58");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateBottomInset((double) 0);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test59");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke1 = polarPlot0.getOutlineStroke();
        polarPlot0.setBackgroundImageAlpha(1.0f);
        java.awt.Color color4 = java.awt.Color.black;
        float[] floatArray10 = new float[] { 1, (short) 10, (short) 10, (short) -1, (-1) };
        float[] floatArray11 = color4.getRGBComponents(floatArray10);
        float[] floatArray12 = null;
        float[] floatArray13 = color4.getRGBComponents(floatArray12);
        polarPlot0.setAngleGridlinePaint((java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test60");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        jFreeChart4.setTitle("hi!");
        java.lang.Object obj7 = jFreeChart4.getTextAntiAlias();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis8.getLabelInsets();
        double double11 = rectangleInsets9.trimWidth((double) (byte) 10);
        double double13 = rectangleInsets9.calculateLeftOutset(0.0d);
        double double15 = rectangleInsets9.calculateBottomOutset((double) (byte) 10);
        jFreeChart4.setPadding(rectangleInsets9);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot17 = jFreeChart4.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PolarPlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.0d + "'", double13 == 3.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15 == 3.0d);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test61");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (short) 100, (double) 4);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint14 = statisticalLineAndShapeRenderer8.getItemOutlinePaint((-1), 0);
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape5, paint14);
        java.awt.Paint paint16 = null;
        legendGraphic15.setLinePaint(paint16);
        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("hi!", font19);
        java.lang.String str21 = textTitle20.getToolTipText();
        java.lang.String str22 = textTitle20.getText();
        java.lang.String str23 = textTitle20.getID();
        java.lang.Object obj24 = textTitle20.clone();
        org.jfree.chart.block.BlockFrame blockFrame25 = textTitle20.getFrame();
        legendGraphic15.setFrame(blockFrame25);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.block.LabelBlock labelBlock30 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str31 = labelBlock30.getToolTipText();
        java.lang.String str32 = labelBlock30.getURLText();
        java.awt.geom.Rectangle2D rectangle2D33 = labelBlock30.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity36 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D33, "Polar Plot", "LengthConstraintType.NONE");
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge37);
        double double39 = dateAxis27.valueToJava2D((double) 128, rectangle2D33, rectangleEdge37);
        legendGraphic15.setLine((java.awt.Shape) rectangle2D33);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) legendGraphic15);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(blockFrame25);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test62");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        float float4 = polarPlot0.getBackgroundAlpha();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        polarPlot0.setDataset(xYDataset5);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = polarPlot0.getRenderer();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNull(polarItemRenderer7);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test63");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset3.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.general.DatasetGroup datasetGroup9 = defaultStatisticalCategoryDataset3.getGroup();
        java.lang.Comparable comparable11 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity12 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "hi!", "", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, (java.lang.Comparable) 1.0d, comparable11);
        java.awt.Shape shape13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset16 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset16.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.general.DatasetGroup datasetGroup22 = defaultStatisticalCategoryDataset16.getGroup();
        java.lang.Comparable comparable24 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity25 = new org.jfree.chart.entity.CategoryItemEntity(shape13, "hi!", "", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset16, (java.lang.Comparable) 1.0d, comparable24);
        java.lang.String str26 = categoryItemEntity25.getToolTipText();
        try {
            boolean boolean27 = categoryItemEntity12.equals((java.lang.Object) categoryItemEntity25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(datasetGroup9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(datasetGroup22);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test64");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (short) 100, (double) 4);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint14 = statisticalLineAndShapeRenderer8.getItemOutlinePaint((-1), 0);
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape5, paint14);
        java.awt.Paint paint16 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        legendGraphic15.setOutlinePaint(paint16);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = legendGraphic15.getShapeAnchor();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test65");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        java.awt.Font font5 = statisticalLineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, rectangleAnchor8, (double) (short) 100, (double) 4);
        statisticalLineAndShapeRenderer2.setBaseShape(shape11, false);
        boolean boolean14 = statisticalLineAndShapeRenderer2.getUseFillPaint();
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalLineAndShapeRenderer2);
        java.awt.Paint paint16 = legendTitle15.getItemPaint();
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = legendTitle15.getVerticalAlignment();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(verticalAlignment17);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test66");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, 100.0d);
        java.awt.Paint paint4 = stackedBarRenderer3D3.getWallPaint();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke9 = polarPlot8.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', (java.awt.Paint) color7, stroke9);
        stackedBarRenderer3D3.setSeriesOutlineStroke(2, stroke9);
        java.awt.Shape shape13 = stackedBarRenderer3D3.getSeriesShape((int) ' ');
        java.awt.Paint paint14 = stackedBarRenderer3D3.getWallPaint();
        boolean boolean15 = stackedAreaRenderer0.equals((java.lang.Object) paint14);
        stackedAreaRenderer0.setBaseItemLabelsVisible(false, false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(shape13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test67");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setStartAngle(0.0d);
        java.awt.Stroke stroke3 = ringPlot0.getBaseSectionOutlineStroke();
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test68");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D2 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int3 = defaultKeyedValues2D2.getRowCount();
        java.util.List list4 = defaultKeyedValues2D2.getColumnKeys();
        boolean boolean5 = waterfallBarRenderer0.equals((java.lang.Object) list4);
        java.awt.Paint paint6 = waterfallBarRenderer0.getFirstBarPaint();
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint8 = polarPlot7.getOutlinePaint();
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot7.setOutlineStroke(stroke9);
        boolean boolean11 = polarPlot7.isRadiusGridlinesVisible();
        waterfallBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test69");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        categoryAxis0.setTickMarkPaint(paint1);
        java.lang.String str3 = categoryAxis0.getLabel();
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryAxis0.setLabelPaint(paint4);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity10 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis0, shape7, "({0}, {1}) = {2}", "({0}, {1}) = {2}");
        java.lang.String str11 = axisLabelEntity10.getToolTipText();
        java.awt.Shape shape12 = axisLabelEntity10.getArea();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "({0}, {1}) = {2}" + "'", str11.equals("({0}, {1}) = {2}"));
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test70");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double3 = defaultStatisticalCategoryDataset1.getRangeUpperBound(false);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset4.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.general.DatasetGroup datasetGroup10 = defaultStatisticalCategoryDataset4.getGroup();
        java.lang.String str11 = datasetGroup10.getID();
        defaultStatisticalCategoryDataset1.setGroup(datasetGroup10);
        int int13 = defaultStatisticalCategoryDataset1.getColumnCount();
        org.jfree.data.Range range14 = waterfallBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(datasetGroup10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "NOID" + "'", str11.equals("NOID"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(range14);
    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test71");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer5.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint9 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        statisticalLineAndShapeRenderer5.setBasePaint(paint9);
        textTitle2.setBackgroundPaint(paint9);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis13.getLabelInsets();
        double double16 = rectangleInsets14.trimWidth((double) (byte) 10);
        double double18 = rectangleInsets14.calculateTopInset((-1.0d));
        org.jfree.chart.block.LineBorder lineBorder19 = new org.jfree.chart.block.LineBorder(paint9, stroke12, rectangleInsets14);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource21 = dateAxis20.getStandardTickUnits();
        org.jfree.data.time.DateRange dateRange24 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis20.setRangeWithMargins((org.jfree.data.Range) dateRange24, false, false);
        dateAxis20.setAutoRange(false);
        double double30 = dateAxis20.getAutoRangeMinimumSize();
        dateAxis20.setInverted(true);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline33 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.List list34 = segmentedTimeline33.getExceptionSegments();
        dateAxis20.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline33);
        boolean boolean36 = dateAxis20.isTickLabelsVisible();
        boolean boolean37 = lineBorder19.equals((java.lang.Object) dateAxis20);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.0d + "'", double18 == 3.0d);
        org.junit.Assert.assertNotNull(tickUnitSource21);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.0d + "'", double30 == 2.0d);
        org.junit.Assert.assertNotNull(segmentedTimeline33);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test72");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (short) 100, 8.0d, (double) 100L, 12.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test73");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis0.setRangeWithMargins((org.jfree.data.Range) dateRange4, false, false);
        dateAxis0.setAutoRange(false);
        dateAxis0.setFixedAutoRange(9999.0d);
        org.junit.Assert.assertNotNull(tickUnitSource1);
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test74");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        categoryAxis0.setTickMarkPaint(paint1);
        java.lang.String str3 = categoryAxis0.getLabel();
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryAxis0.setLabelPaint(paint4);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity10 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis0, shape7, "({0}, {1}) = {2}", "({0}, {1}) = {2}");
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape7);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity12 = new org.jfree.chart.entity.LegendItemEntity(shape7);
        org.jfree.data.general.Dataset dataset13 = legendItemEntity12.getDataset();
        java.lang.String str14 = legendItemEntity12.getShapeType();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNull(dataset13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "poly" + "'", str14.equals("poly"));
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test75");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        double double3 = ringPlot0.getMaximumLabelWidth();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        ringPlot0.setExplodePercent((java.lang.Comparable) 'a', (double) 100);
        java.awt.Paint paint9 = ringPlot0.getNoDataMessagePaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test76");
        org.jfree.data.time.TimePeriod timePeriod1 = null;
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("DateTickUnit[DAY, 1]", timePeriod1);
        task2.setPercentComplete((double) 0L);
        org.jfree.data.time.TimePeriod timePeriod5 = null;
        task2.setDuration(timePeriod5);
        task2.setPercentComplete((java.lang.Double) 2.0d);
    }

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test77");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Comparable comparable4 = null;
        int int5 = defaultStatisticalCategoryDataset3.getRowIndex(comparable4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str9 = spreadsheetDate8.getDescription();
        int int10 = spreadsheetDate8.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str13 = spreadsheetDate12.getDescription();
        org.jfree.data.time.SerialDate serialDate14 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity15 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "hi!", "RectangleConstraintType.RANGE", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, (java.lang.Comparable) (byte) 10, (java.lang.Comparable) spreadsheetDate8);
        categoryItemEntity15.setColumnKey((java.lang.Comparable) 1.0d);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(serialDate14);
    }

    @Test
    public void test78() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test78");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        boolean boolean5 = xYPlot0.isRangeZeroBaselineVisible();
        xYPlot0.setRangeZeroBaselineVisible(false);
        java.awt.Stroke stroke8 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation9 = null;
        try {
            boolean boolean10 = xYPlot0.removeAnnotation(xYAnnotation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test79() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test79");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
    }

    @Test
    public void test80() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test80");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint8 = statisticalLineAndShapeRenderer2.getItemOutlinePaint((-1), 0);
        statisticalLineAndShapeRenderer2.setSeriesVisible(4, (java.lang.Boolean) false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = statisticalLineAndShapeRenderer2.getSeriesURLGenerator(11);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryURLGenerator13);
    }

    @Test
    public void test81() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test81");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYPlot0.setRangeCrosshairStroke(stroke3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot0.getDataset();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke9 = polarPlot8.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', (java.awt.Paint) color7, stroke9);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection11 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int12 = taskSeriesCollection11.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries14 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection11.add(taskSeries14);
        org.jfree.data.gantt.TaskSeries taskSeries17 = taskSeriesCollection11.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection11, (java.lang.Comparable) "CONTRACT");
        boolean boolean20 = categoryMarker10.equals((java.lang.Object) taskSeriesCollection11);
        java.awt.Color color21 = java.awt.Color.GREEN;
        categoryMarker10.setPaint((java.awt.Paint) color21);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10);
        java.lang.String str24 = xYPlot0.getPlotType();
        org.jfree.chart.axis.ValueAxis valueAxis25 = xYPlot0.getDomainAxis();
        org.jfree.data.xy.XYDataset xYDataset26 = xYPlot0.getDataset();
        org.jfree.chart.text.TextBlock textBlock28 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor32 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        textBlock28.draw(graphics2D29, (float) (byte) 100, (float) (byte) 1, textBlockAnchor32, (float) 7, (float) '4', (double) (short) 100);
        java.util.List list37 = textBlock28.getLines();
        org.jfree.chart.text.TextBlock textBlock38 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor42 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        textBlock38.draw(graphics2D39, (float) (byte) 100, (float) (byte) 1, textBlockAnchor42, (float) 7, (float) '4', (double) (short) 100);
        org.jfree.chart.text.TextAnchor textAnchor47 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.axis.CategoryTick categoryTick49 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 900000L, textBlock28, textBlockAnchor42, textAnchor47, (double) (-329600));
        org.jfree.chart.text.TextBlock textBlock50 = categoryTick49.getLabel();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder51 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        boolean boolean52 = categoryTick49.equals((java.lang.Object) datasetRenderingOrder51);
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder51);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(taskSeries17);
        org.junit.Assert.assertNotNull(pieDataset19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "XY Plot" + "'", str24.equals("XY Plot"));
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertNull(xYDataset26);
        org.junit.Assert.assertNotNull(textBlockAnchor32);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertNotNull(textBlockAnchor42);
        org.junit.Assert.assertNotNull(textAnchor47);
        org.junit.Assert.assertNotNull(textBlock50);
        org.junit.Assert.assertNotNull(datasetRenderingOrder51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test82() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test82");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 1, (double) (short) 10, false);
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean5 = polarPlot4.isOutlineVisible();
        polarPlot4.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot4);
        java.awt.Stroke stroke9 = jFreeChart8.getBorderStroke();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) false, jFreeChart8, 9999, (int) '4');
        org.jfree.chart.JFreeChart jFreeChart13 = chartProgressEvent12.getChart();
        java.util.List list14 = jFreeChart13.getSubtitles();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(jFreeChart13);
        org.junit.Assert.assertNotNull(list14);
    }

    @Test
    public void test83() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test83");
        org.jfree.chart.axis.AxisSpace axisSpace2 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis3.getLabelInsets();
        double double6 = rectangleInsets4.trimWidth((double) (byte) 10);
        double double8 = rectangleInsets4.calculateTopInset((-1.0d));
        double double10 = rectangleInsets4.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str13 = labelBlock12.getToolTipText();
        java.lang.String str14 = labelBlock12.getURLText();
        java.awt.geom.Rectangle2D rectangle2D15 = labelBlock12.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType17 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str18 = lengthAdjustmentType17.toString();
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets4.createAdjustedRectangle(rectangle2D15, lengthAdjustmentType16, lengthAdjustmentType17);
        org.jfree.chart.block.LabelBlock labelBlock21 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str22 = labelBlock21.getToolTipText();
        java.lang.String str23 = labelBlock21.getURLText();
        java.awt.geom.Rectangle2D rectangle2D24 = labelBlock21.getBounds();
        java.awt.geom.Rectangle2D rectangle2D25 = axisSpace2.shrink(rectangle2D19, rectangle2D24);
        java.awt.geom.Point2D point2D26 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 9999, (double) (-1), rectangle2D19);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(lengthAdjustmentType16);
        org.junit.Assert.assertNotNull(lengthAdjustmentType17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "CONTRACT" + "'", str18.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(point2D26);
    }

    @Test
    public void test84() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test84");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset3.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.general.DatasetGroup datasetGroup9 = defaultStatisticalCategoryDataset3.getGroup();
        java.lang.Comparable comparable11 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity12 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "hi!", "", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, (java.lang.Comparable) 1.0d, comparable11);
        try {
            java.lang.Number number15 = defaultStatisticalCategoryDataset3.getMeanValue((int) (byte) 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(datasetGroup9);
    }

    @Test
    public void test85() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test85");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        java.lang.Number number5 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) 1, (java.lang.Comparable) (short) 0);
        java.util.List list6 = defaultStatisticalCategoryDataset0.getColumnKeys();
        int int8 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "RectangleConstraintType.RANGE");
        java.lang.Number number9 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.KeyToGroupMap keyToGroupMap11 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 1.0E-5d);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, keyToGroupMap11);
        org.jfree.data.Range range15 = org.jfree.data.Range.expand(range12, 12.0d, 8.64E7d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertEquals((double) number9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range15);
    }

    @Test
    public void test86() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test86");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorLeft((double) (-1.0f));
        java.util.List list3 = axisState0.getTicks();
        double double4 = axisState0.getCursor();
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test87() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test87");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        java.awt.Stroke stroke2 = categoryAxis0.getAxisLineStroke();
        float float3 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        org.jfree.chart.axis.Axis axis5 = axisChangeEvent4.getAxis();
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color8 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("({0}, {1}) = {2}", font7, (java.awt.Paint) color8, (float) 2958465);
        axis5.setLabelFont(font7);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(axis5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test88() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test88");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean4 = statisticalLineAndShapeRenderer3.getBaseItemLabelsVisible();
        int int5 = statisticalLineAndShapeRenderer3.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        statisticalLineAndShapeRenderer3.setSeriesNegativeItemLabelPosition(0, itemLabelPosition7);
        java.awt.Stroke stroke11 = statisticalLineAndShapeRenderer3.getItemOutlineStroke(4, (int) '4');
        boolean boolean12 = waterfallBarRenderer0.equals((java.lang.Object) statisticalLineAndShapeRenderer3);
        boolean boolean15 = statisticalLineAndShapeRenderer3.getItemShapeVisible(1, (-1));
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesPaint(100, (java.awt.Paint) color17, false);
        java.awt.Stroke stroke22 = statisticalLineAndShapeRenderer3.getItemStroke(7, (int) '#');
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test89() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test89");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.Plot plot1 = xYPlot0.getRootPlot();
        org.junit.Assert.assertNotNull(plot1);
    }

    @Test
    public void test90() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test90");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYPlot0.setRangeCrosshairStroke(stroke3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot0.getDataset();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        xYPlot0.setDataset(9999, xYDataset7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        int int11 = xYPlot9.indexOf(xYDataset10);
        int int12 = xYPlot9.getSeriesCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot9.zoomDomainAxes((double) 500, plotRenderingInfo14, point2D15);
        org.jfree.chart.LegendItemCollection legendItemCollection17 = xYPlot9.getLegendItems();
        xYPlot0.setFixedLegendItems(legendItemCollection17);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection17);
    }

    @Test
    public void test91() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test91");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        java.lang.String str1 = waferMapPlot0.getPlotType();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "WMAP_Plot" + "'", str1.equals("WMAP_Plot"));
    }

    @Test
    public void test92() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test92");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        double double1 = lineRenderer3D0.getXOffset();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.resizeRange(1.0d);
        org.jfree.chart.util.Size2D size2D9 = new org.jfree.chart.util.Size2D(0.0d, (double) 1.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.geom.Rectangle2D rectangle2D13 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D9, (double) 100L, (double) 0L, rectangleAnchor12);
        lineRenderer3D0.drawRangeGridline(graphics2D2, categoryPlot3, (org.jfree.chart.axis.ValueAxis) dateAxis4, rectangle2D13, (double) 100.0f);
        lineRenderer3D0.setXOffset((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.0d + "'", double1 == 12.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangle2D13);
    }

    @Test
    public void test93() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test93");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        groupedStackedBarRenderer0.setAutoPopulateSeriesStroke(true);
    }

    @Test
    public void test94() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test94");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor5);
        org.jfree.chart.text.TextAnchor textAnchor8 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("LengthConstraintType.NONE", graphics2D1, (float) 10L, (float) '4', textAnchor5, 0.0d, textAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test95() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test95");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        java.awt.Paint paint3 = ringPlot0.getSeparatorPaint();
        double double4 = ringPlot0.getInteriorGap();
        java.awt.Stroke stroke5 = ringPlot0.getLabelLinkStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = null;
        ringPlot0.setURLGenerator(pieURLGenerator6);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
        org.junit.Assert.assertNotNull(stroke5);
    }
}

