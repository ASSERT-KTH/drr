import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.TickLabelEntity tickLabelEntity3 = new org.jfree.chart.entity.TickLabelEntity(shape0, "hi!", "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {2}" + "'", str0.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) 0L, (float) (short) 100, 0.0f);
        org.junit.Assert.assertNull(shape4);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = null;
        try {
            defaultStatisticalCategoryDataset0.setGroup(datasetGroup1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'group' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) false, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.lang.Comparable comparable0 = null;
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        try {
            org.jfree.chart.axis.CategoryTick categoryTick5 = new org.jfree.chart.axis.CategoryTick(comparable0, textBlock1, textBlockAnchor2, textAnchor3, (double) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        try {
            org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = null;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range1, lengthConstraintType2, (double) 1, range4, lengthConstraintType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.chart.axis.DateTickUnit.MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 1L, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) (-1L), (double) (byte) 100);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        categoryAxis0.setTickMarkPaint(paint1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            org.jfree.chart.axis.AxisState axisState9 = categoryAxis0.draw(graphics2D3, (double) 'a', rectangle2D5, rectangle2D6, rectangleEdge7, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint8 = statisticalLineAndShapeRenderer2.getItemOutlinePaint((-1), 0);
        boolean boolean10 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) 2958465);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = null;
        statisticalLineAndShapeRenderer2.setSeriesItemLabelGenerator(1, categoryItemLabelGenerator12, false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = null;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor2, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'itemLabelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-1), serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.text.DateFormat dateFormat4 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit((int) (byte) 10, (int) (byte) 10, 0, 0, dateFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Shape shape1 = org.jfree.chart.util.SerialUtilities.readShape(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("hi!");
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        double double3 = rectangleInsets1.trimWidth((double) (byte) 10);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets1.createInsetRectangle(rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.Paint paint4 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        try {
            java.lang.Object obj5 = labelBlock1.draw(graphics2D2, rectangle2D3, (java.lang.Object) paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.START;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.general.DatasetGroup datasetGroup6 = defaultStatisticalCategoryDataset0.getGroup();
        org.jfree.data.KeyToGroupMap keyToGroupMap7 = null;
        try {
            org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, keyToGroupMap7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup6);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "hi!" + "'", str0.equals("hi!"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int0 = org.jfree.chart.axis.DateTickUnit.HOUR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer7 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean8 = statisticalLineAndShapeRenderer7.getBaseItemLabelsVisible();
        int int9 = statisticalLineAndShapeRenderer7.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        statisticalLineAndShapeRenderer7.setSeriesNegativeItemLabelPosition(0, itemLabelPosition11);
        java.awt.Stroke stroke15 = statisticalLineAndShapeRenderer7.getItemOutlineStroke(4, (int) '4');
        try {
            statisticalLineAndShapeRenderer2.setSeriesStroke((int) (byte) -1, stroke15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("({0}, {1}) = {2}");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((int) '4', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date1 = null;
        try {
            java.util.Date date2 = dateTickUnit0.addToDate(date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset3.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.general.DatasetGroup datasetGroup9 = defaultStatisticalCategoryDataset3.getGroup();
        java.lang.Comparable comparable11 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity12 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "hi!", "", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, (java.lang.Comparable) 1.0d, comparable11);
        org.jfree.data.KeyToGroupMap keyToGroupMap13 = null;
        try {
            org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, keyToGroupMap13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(datasetGroup9);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint6 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        statisticalLineAndShapeRenderer2.setBasePaint(paint6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            statisticalLineAndShapeRenderer2.drawDomainGridline(graphics2D8, categoryPlot9, rectangle2D10, (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        try {
            double double6 = categoryAxis3D0.getCategoryJava2DCoordinate(categoryAnchor1, (int) ' ', (int) 'a', rectangle2D4, rectangleEdge5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("({0}, {1}) = {2}", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone2;
        try {
            java.util.Date date4 = dateTickUnit0.addToDate(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertNotNull(timeZone2);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        statisticalLineAndShapeRenderer2.setUseFillPaint(false);
        boolean boolean10 = statisticalLineAndShapeRenderer2.getAutoPopulateSeriesOutlinePaint();
        boolean boolean11 = statisticalLineAndShapeRenderer2.getAutoPopulateSeriesFillPaint();
        boolean boolean14 = statisticalLineAndShapeRenderer2.getItemCreateEntity((int) (short) 0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = statisticalLineAndShapeRenderer2.getURLGenerator(100, (int) (short) 10);
        java.awt.Stroke stroke12 = statisticalLineAndShapeRenderer2.getSeriesStroke(2958465);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset19 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double21 = defaultStatisticalCategoryDataset19.getRangeUpperBound(false);
        try {
            statisticalLineAndShapeRenderer2.drawItem(graphics2D13, categoryItemRendererState14, rectangle2D15, categoryPlot16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, valueAxis18, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset19, (int) (short) 100, (int) ' ', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Paint paint1 = org.jfree.chart.util.SerialUtilities.readPaint(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset3.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.general.DatasetGroup datasetGroup9 = defaultStatisticalCategoryDataset3.getGroup();
        java.lang.Comparable comparable11 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity12 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "hi!", "", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, (java.lang.Comparable) 1.0d, comparable11);
        try {
            org.jfree.data.general.PieDataset pieDataset14 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(datasetGroup9);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.awt.Color color0 = java.awt.Color.BLUE;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint((java.awt.Paint) color0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.lang.String str3 = textTitle2.getToolTipText();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = null;
        try {
            textTitle2.setTextAlignment(horizontalAlignment4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.lang.Object obj1 = blockContainer0.clone();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            blockContainer0.draw(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        statisticalLineAndShapeRenderer2.setUseFillPaint(false);
        boolean boolean10 = statisticalLineAndShapeRenderer2.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint12 = null;
        statisticalLineAndShapeRenderer2.setSeriesFillPaint(4, paint12);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = statisticalLineAndShapeRenderer2.getBaseItemLabelGenerator();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            labelBlock1.draw(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            taskSeriesCollection0.remove(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: TaskSeriesCollection.remove(): index outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.0d, (double) 'a', rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        try {
            java.util.Date date3 = dateTickUnit0.rollDate(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertNotNull(timeZone2);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        categoryAxis0.setTickMarkPaint(paint1);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paint1);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        boolean boolean2 = categoryLabelPositions0.equals((java.lang.Object) 0.0f);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("Polar Plot");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name Polar Plot, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset3.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.general.DatasetGroup datasetGroup9 = defaultStatisticalCategoryDataset3.getGroup();
        java.lang.Comparable comparable11 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity12 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "hi!", "", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, (java.lang.Comparable) 1.0d, comparable11);
        java.lang.String str13 = categoryItemEntity12.getToolTipText();
        java.lang.String str14 = categoryItemEntity12.getURLText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(datasetGroup9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        polarPlot0.markerChanged(markerChangeEvent1);
        java.lang.String str3 = polarPlot0.getNoDataMessage();
        java.lang.String str4 = polarPlot0.getNoDataMessage();
        org.jfree.data.general.DatasetGroup datasetGroup5 = polarPlot0.getDatasetGroup();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(datasetGroup5);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = statisticalLineAndShapeRenderer2.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = statisticalLineAndShapeRenderer2.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer15.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint21 = statisticalLineAndShapeRenderer15.getItemOutlinePaint((-1), 0);
        statisticalLineAndShapeRenderer2.setBaseOutlinePaint(paint21, true);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D28 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset30 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset30.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        try {
            statisticalLineAndShapeRenderer2.drawItem(graphics2D24, categoryItemRendererState25, rectangle2D26, categoryPlot27, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D28, valueAxis29, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset30, (int) (byte) 1, (int) (short) 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.awt.Paint paint0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        categoryAxis0.setTickMarkPaint(paint1);
        java.lang.String str3 = categoryAxis0.getLabel();
        categoryAxis0.setLabelAngle((double) '#');
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        try {
            org.jfree.chart.axis.AxisState axisState12 = categoryAxis0.draw(graphics2D6, (double) ' ', rectangle2D8, rectangle2D9, rectangleEdge10, plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer5.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint9 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        statisticalLineAndShapeRenderer5.setBasePaint(paint9);
        textTitle2.setBackgroundPaint(paint9);
        boolean boolean12 = textTitle2.getExpandToFitSpace();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = null;
        try {
            org.jfree.chart.util.Size2D size2D15 = textTitle2.arrange(graphics2D13, rectangleConstraint14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        java.awt.Paint paint10 = statisticalLineAndShapeRenderer2.getItemOutlinePaint((int) (short) 1, 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setBackgroundAlpha((float) 0L);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("hi!", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.util.Size2D size2D0 = null;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, rectangleAnchor5, (double) (short) 100, (double) 4);
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (byte) 0, (double) 3, rectangleAnchor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = '#';
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = 9999;
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean4 = statisticalLineAndShapeRenderer3.getBaseItemLabelsVisible();
        int int5 = statisticalLineAndShapeRenderer3.getPassCount();
        java.awt.Font font6 = statisticalLineAndShapeRenderer3.getBaseItemLabelFont();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape8, rectangleAnchor9, (double) (short) 100, (double) 4);
        statisticalLineAndShapeRenderer3.setBaseShape(shape12, false);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.clone(shape12);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape15, (double) (short) -1, (float) 10, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.Number number3 = taskSeriesCollection0.getStartValue((int) (short) 100, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.util.Date date0 = null;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean6 = statisticalLineAndShapeRenderer5.getBaseItemLabelsVisible();
        int int7 = statisticalLineAndShapeRenderer5.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        statisticalLineAndShapeRenderer5.setSeriesNegativeItemLabelPosition(0, itemLabelPosition9);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = statisticalLineAndShapeRenderer5.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = statisticalLineAndShapeRenderer5.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor16 = itemLabelPosition15.getRotationAnchor();
        try {
            org.jfree.chart.axis.DateTick dateTick18 = new org.jfree.chart.axis.DateTick(date0, "({0}, {1}) = {2}", textAnchor2, textAnchor16, (double) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(textAnchor16);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str2 = labelBlock1.getURLText();
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit((int) (byte) -1, (int) (byte) 0, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        double double3 = rectangleInsets1.trimWidth((double) (byte) 10);
        double double5 = rectangleInsets1.extendWidth((double) 'a');
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets1.createOutsetRectangle(rectangle2D6, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.0d + "'", double5 == 103.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100, (int) '#', 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        try {
            dateAxis0.zoomRange(100.0d, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        try {
            java.lang.Number number4 = defaultKeyedValues2D1.getValue((java.lang.Comparable) 103.0d, (java.lang.Comparable) 4.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 4.0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int1 = taskSeriesCollection0.getColumnCount();
        try {
            org.jfree.data.gantt.TaskSeries taskSeries3 = taskSeriesCollection0.getSeries(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("NOID", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int1 = taskSeriesCollection0.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries2 = null;
        try {
            taskSeriesCollection0.remove(taskSeries2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.awt.Image image7 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo11 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image7, "", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray12 = projectInfo11.getLibraries();
        boolean boolean13 = textAnchor3.equals((java.lang.Object) projectInfo11);
        org.jfree.chart.axis.NumberTick numberTick15 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 1.0E-5d, "CONTRACT", textAnchor2, textAnchor3, 0.4d);
        java.lang.String str16 = numberTick15.toString();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(libraryArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "CONTRACT" + "'", str16.equals("CONTRACT"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            int int3 = taskSeriesCollection0.getSubIntervalCount(100, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        double double3 = rectangleInsets1.trimWidth((double) (byte) 10);
        double double5 = rectangleInsets1.calculateTopInset((-1.0d));
        double double7 = rectangleInsets1.calculateLeftOutset(0.0d);
        double double8 = rectangleInsets1.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        java.awt.Shape shape1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset4.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.general.DatasetGroup datasetGroup10 = defaultStatisticalCategoryDataset4.getGroup();
        java.lang.Comparable comparable12 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity13 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "hi!", "", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, (java.lang.Comparable) 1.0d, comparable12);
        java.lang.String str14 = categoryItemEntity13.getToolTipText();
        boolean boolean15 = itemLabelAnchor0.equals((java.lang.Object) str14);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(datasetGroup10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        int int0 = org.jfree.chart.axis.DateTickUnit.DAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("hi!", font2);
        java.lang.String str4 = textTitle3.getToolTipText();
        java.lang.String str5 = textTitle3.getText();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D7 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int8 = defaultKeyedValues2D7.getRowCount();
        int int10 = defaultKeyedValues2D7.getColumnIndex((java.lang.Comparable) 0);
        try {
            blockContainer0.add((org.jfree.chart.block.Block) textTitle3, (java.lang.Object) int10);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list2 = defaultKeyedValues2D1.getRowKeys();
        try {
            java.lang.Comparable comparable4 = defaultKeyedValues2D1.getRowKey((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.general.DatasetGroup datasetGroup6 = defaultStatisticalCategoryDataset0.getGroup();
        java.lang.Number number9 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) (byte) -1, (java.lang.Comparable) 15);
        org.junit.Assert.assertNotNull(datasetGroup6);
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType4 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, textAnchor2, (double) (short) -1, categoryLabelWidthType4, (float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'left' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        outlierListCollection0.setLowFarOut(false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.lang.String str3 = textTitle2.getToolTipText();
        java.lang.String str4 = textTitle2.getText();
        java.awt.Paint paint5 = textTitle2.getPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("NOID", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.lang.String str3 = textTitle2.getToolTipText();
        textTitle2.setWidth(0.0d);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent6 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle2);
        java.lang.String str7 = textTitle2.getToolTipText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(9999, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.lang.Object obj3 = textTitle2.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.lang.String str3 = textTitle2.getToolTipText();
        textTitle2.setWidth(0.0d);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent6 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle2);
        org.jfree.chart.event.TitleChangeListener titleChangeListener7 = null;
        textTitle2.addChangeListener(titleChangeListener7);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image3, "", "hi!", "");
        java.awt.Image image8 = projectInfo7.getLogo();
        org.jfree.chart.ui.Library[] libraryArray9 = projectInfo7.getOptionalLibraries();
        projectInfo7.setVersion("hi!");
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNotNull(libraryArray9);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean4 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge3);
        try {
            double double5 = dateAxis0.java2DToValue((double) (byte) 100, rectangle2D2, rectangleEdge3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        polarPlot0.drawBackgroundImage(graphics2D4, rectangle2D5);
        polarPlot0.setBackgroundAlpha((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 1.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(range2, (double) (short) 1);
        java.lang.String str5 = range2.toString();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Range[1.0,1.0]" + "'", str5.equals("Range[1.0,1.0]"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 1.0E-5d, 103.0d, (double) (-1L), (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        statisticalLineAndShapeRenderer2.setUseFillPaint(false);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean14 = statisticalLineAndShapeRenderer13.getBaseItemLabelsVisible();
        int int15 = statisticalLineAndShapeRenderer13.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        statisticalLineAndShapeRenderer13.setSeriesNegativeItemLabelPosition(0, itemLabelPosition17);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = statisticalLineAndShapeRenderer13.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = statisticalLineAndShapeRenderer13.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(100, itemLabelPosition23);
        java.awt.Font font26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("hi!", font26);
        statisticalLineAndShapeRenderer2.setBaseItemLabelFont(font26);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator21);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(font26);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint2 = polarPlot1.getOutlinePaint();
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot1.setOutlineStroke(stroke3);
        barRenderer0.setBaseOutlineStroke(stroke3, true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape1, "NOID");
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("hi!", font2);
        java.awt.Paint paint4 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("({0}, {1}) = {2}", font2, paint4);
        java.awt.Graphics2D graphics2D6 = null;
        try {
            org.jfree.chart.util.Size2D size2D7 = textLine5.calculateDimensions(graphics2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.Number number3 = taskSeriesCollection0.getPercentComplete(0, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator0 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        java.lang.Object obj1 = standardCategoryURLGenerator0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        double double3 = rectangleInsets1.trimWidth((double) (byte) 10);
        double double5 = rectangleInsets1.calculateTopInset((-1.0d));
        double double7 = rectangleInsets1.calculateLeftOutset(0.0d);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            rectangleInsets1.trim(rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.lang.Object obj1 = blockContainer0.clone();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        boolean boolean3 = blockContainer0.equals((java.lang.Object) shape2);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer3.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint9 = statisticalLineAndShapeRenderer3.getItemOutlinePaint((-1), 0);
        java.awt.Paint paint10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Paint paint11 = null;
        try {
            org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer12 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color0, paint9, paint10, paint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lastBarPaint' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint1 = null;
        try {
            waterfallBarRenderer0.setPositiveBarPaint(paint1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        categoryAxis0.setTickMarkPaint(paint1);
        java.lang.String str3 = categoryAxis0.getLabel();
        categoryAxis0.setLabelAngle((double) '#');
        double double6 = categoryAxis0.getUpperMargin();
        org.jfree.chart.plot.Plot plot7 = categoryAxis0.getPlot();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNull(plot7);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        statisticalLineAndShapeRenderer2.setUseFillPaint(false);
        boolean boolean10 = statisticalLineAndShapeRenderer2.getAutoPopulateSeriesOutlinePaint();
        boolean boolean11 = statisticalLineAndShapeRenderer2.getAutoPopulateSeriesFillPaint();
        java.awt.Color color13 = java.awt.Color.MAGENTA;
        statisticalLineAndShapeRenderer2.setSeriesPaint(1, (java.awt.Paint) color13);
        java.awt.color.ColorSpace colorSpace15 = null;
        java.awt.Color color16 = java.awt.Color.black;
        float[] floatArray22 = new float[] { 1, (short) 10, (short) 10, (short) -1, (-1) };
        float[] floatArray23 = color16.getRGBComponents(floatArray22);
        try {
            float[] floatArray24 = color13.getColorComponents(colorSpace15, floatArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("({0}, {1}) = {2}", font2, (java.awt.Paint) color3, (float) 2958465);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.text.TextMeasurer textMeasurer8 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock9 = org.jfree.chart.text.TextUtilities.createTextBlock("NOID", font2, (java.awt.Paint) color6, 1.0f, textMeasurer8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.awt.Shape shape0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.lang.String str3 = textTitle2.getToolTipText();
        java.lang.String str4 = textTitle2.getText();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        textTitle2.draw(graphics2D5, rectangle2D6);
        double double8 = textTitle2.getContentXOffset();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        java.lang.Object obj2 = null;
        boolean boolean3 = lengthAdjustmentType0.equals(obj2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CONTRACT" + "'", str1.equals("CONTRACT"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int1 = taskSeriesCollection0.getColumnCount();
        java.util.List list2 = taskSeriesCollection0.getColumnKeys();
        try {
            java.lang.Number number5 = taskSeriesCollection0.getPercentComplete((java.lang.Comparable) false, (java.lang.Comparable) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.lang.String str3 = textTitle2.getToolTipText();
        java.awt.Paint paint4 = textTitle2.getPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.awt.Paint paint0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj3 = categoryAxis3D2.clone();
        boolean boolean4 = blockBorder1.equals((java.lang.Object) categoryAxis3D2);
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer6 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean7 = statisticalLineAndShapeRenderer6.getBaseItemLabelsVisible();
        int int8 = statisticalLineAndShapeRenderer6.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        statisticalLineAndShapeRenderer6.setSeriesNegativeItemLabelPosition(0, itemLabelPosition10);
        java.awt.Stroke stroke14 = statisticalLineAndShapeRenderer6.getItemOutlineStroke(4, (int) '4');
        org.jfree.chart.LegendItem legendItem17 = statisticalLineAndShapeRenderer6.getLegendItem((int) (short) -1, (int) ' ');
        java.awt.Color color19 = java.awt.Color.GREEN;
        statisticalLineAndShapeRenderer6.setSeriesItemLabelPaint(1, (java.awt.Paint) color19, true);
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) 1L, (double) 0, (-1.0d), (java.awt.Paint) color19);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(legendItem17);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("DateTickUnit[DAY, 1]", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        java.awt.Image image4 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image4, "", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray9 = projectInfo8.getLibraries();
        java.lang.String str10 = projectInfo8.getName();
        boolean boolean11 = borderArrangement0.equals((java.lang.Object) projectInfo8);
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.awt.Image image19 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo23 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image19, "", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray24 = projectInfo23.getLibraries();
        boolean boolean25 = textAnchor15.equals((java.lang.Object) projectInfo23);
        org.jfree.chart.axis.NumberTick numberTick27 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 1.0E-5d, "CONTRACT", textAnchor14, textAnchor15, 0.4d);
        boolean boolean28 = borderArrangement0.equals((java.lang.Object) 1.0E-5d);
        org.junit.Assert.assertNotNull(libraryArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(libraryArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        java.awt.Stroke stroke10 = statisticalLineAndShapeRenderer2.getItemOutlineStroke(4, (int) '4');
        boolean boolean11 = statisticalLineAndShapeRenderer2.getBaseShapesVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisible(false, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.LEVEL;
        org.junit.Assert.assertNotNull(areaRendererEndType0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        boolean boolean1 = outlierListCollection0.isHighFarOut();
        outlierListCollection0.setLowFarOut(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint8 = statisticalLineAndShapeRenderer2.getItemOutlinePaint((-1), 0);
        boolean boolean10 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) 2958465);
        statisticalLineAndShapeRenderer2.setSeriesCreateEntities((int) '4', (java.lang.Boolean) true, false);
        statisticalLineAndShapeRenderer2.setSeriesLinesVisible(0, true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        polarPlot0.markerChanged(markerChangeEvent1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        polarPlot0.drawBackgroundImage(graphics2D3, rectangle2D4);
        boolean boolean6 = polarPlot0.isSubplot();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = statisticalLineAndShapeRenderer2.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = statisticalLineAndShapeRenderer2.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer15.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint21 = statisticalLineAndShapeRenderer15.getItemOutlinePaint((-1), 0);
        statisticalLineAndShapeRenderer2.setBaseOutlinePaint(paint21, true);
        statisticalLineAndShapeRenderer2.setBaseItemLabelsVisible(true, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image3, "", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray8 = projectInfo7.getLibraries();
        java.lang.String str9 = projectInfo7.getName();
        java.lang.String str10 = projectInfo7.getInfo();
        org.junit.Assert.assertNotNull(libraryArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        try {
            java.awt.Color color1 = java.awt.Color.decode("Polar Plot");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Polar Plot\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("hi!", font4);
        java.awt.Paint paint6 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("({0}, {1}) = {2}", font4, paint6);
        textBlock1.addLine(textLine7);
        textBlock0.addLine(textLine7);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("hi!");
        org.jfree.data.time.TimePeriod timePeriod3 = null;
        org.jfree.data.gantt.Task task4 = new org.jfree.data.gantt.Task("DateTickUnit[DAY, 1]", timePeriod3);
        taskSeries1.remove(task4);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str3 = spreadsheetDate2.getDescription();
        int int4 = spreadsheetDate2.getDayOfWeek();
        try {
            org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.lang.String str3 = textTitle2.getToolTipText();
        textTitle2.setNotify(false);
        java.lang.String str6 = textTitle2.getToolTipText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SerialDate serialDate3 = null;
        try {
            boolean boolean4 = spreadsheetDate1.isBefore(serialDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis0.java2DToValue((double) 4, rectangle2D3, rectangleEdge4);
        double double6 = dateAxis0.getLowerMargin();
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 9.223372036854776E18d + "'", double5 == 9.223372036854776E18d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.util.Date date0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date2 = dateAxis1.getMinimumDate();
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod(date0, date2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int1 = taskSeriesCollection0.getColumnCount();
        java.util.List list2 = taskSeriesCollection0.getColumnKeys();
        try {
            java.lang.Number number5 = taskSeriesCollection0.getEndValue(15, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean5 = statisticalLineAndShapeRenderer4.getBaseItemLabelsVisible();
        int int6 = statisticalLineAndShapeRenderer4.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = null;
        statisticalLineAndShapeRenderer4.setSeriesNegativeItemLabelPosition(0, itemLabelPosition8);
        java.awt.Stroke stroke12 = statisticalLineAndShapeRenderer4.getItemOutlineStroke(4, (int) '4');
        org.jfree.chart.LegendItem legendItem15 = statisticalLineAndShapeRenderer4.getLegendItem((int) (short) -1, (int) ' ');
        java.awt.Color color17 = java.awt.Color.GREEN;
        statisticalLineAndShapeRenderer4.setSeriesItemLabelPaint(1, (java.awt.Paint) color17, true);
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot();
        java.lang.String str21 = polarPlot20.getNoDataMessage();
        org.jfree.chart.plot.PolarPlot polarPlot22 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke23 = polarPlot22.getOutlineStroke();
        polarPlot20.setOutlineStroke(stroke23);
        java.awt.Paint paint25 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer28 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer28.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint32 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        statisticalLineAndShapeRenderer28.setBasePaint(paint32);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = categoryAxis34.getLabelInsets();
        java.awt.Stroke stroke36 = categoryAxis34.getAxisLineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = categoryAxis37.getLabelInsets();
        double double40 = rectangleInsets38.trimWidth((double) (byte) 10);
        double double42 = rectangleInsets38.calculateTopInset((-1.0d));
        org.jfree.chart.block.LineBorder lineBorder43 = new org.jfree.chart.block.LineBorder(paint32, stroke36, rectangleInsets38);
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker45 = new org.jfree.chart.plot.IntervalMarker(1.0d, (double) (byte) 10, (java.awt.Paint) color17, stroke23, paint25, stroke36, (float) 900000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 4.0d + "'", double40 == 4.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 3.0d + "'", double42 == 3.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.text.DateFormat dateFormat1 = standardCategoryToolTipGenerator0.getDateFormat();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double4 = defaultStatisticalCategoryDataset2.getRangeUpperBound(false);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset5 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset5.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.general.DatasetGroup datasetGroup11 = defaultStatisticalCategoryDataset5.getGroup();
        java.lang.String str12 = datasetGroup11.getID();
        defaultStatisticalCategoryDataset2.setGroup(datasetGroup11);
        try {
            java.lang.String str15 = standardCategoryToolTipGenerator0.generateRowLabel((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset2, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(datasetGroup11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "NOID" + "'", str12.equals("NOID"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        int int3 = java.awt.Color.HSBtoRGB((float) 15, 10.0f, (float) 900000L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-329600) + "'", int3 == (-329600));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis0);
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis0.setRange((org.jfree.data.Range) dateRange4);
        double double6 = dateRange4.getLowerBound();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = axisSpace0.reserved(rectangle2D1, rectangleEdge2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int1 = taskSeriesCollection0.getColumnCount();
        java.util.List list2 = taskSeriesCollection0.getColumnKeys();
        try {
            java.lang.Number number6 = taskSeriesCollection0.getEndValue((java.lang.Comparable) 900000L, (java.lang.Comparable) Double.NaN, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int1 = taskSeriesCollection0.getColumnCount();
        try {
            java.lang.Number number5 = taskSeriesCollection0.getEndValue((java.lang.Comparable) 0.05d, (java.lang.Comparable) 8, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.lang.String str3 = textTitle2.getToolTipText();
        boolean boolean4 = textTitle2.getNotify();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle2.getHorizontalAlignment();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.lang.String str1 = polarPlot0.getNoDataMessage();
        boolean boolean2 = polarPlot0.isOutlineVisible();
        java.lang.String str3 = polarPlot0.getNoDataMessage();
        polarPlot0.setOutlineVisible(false);
        java.awt.Paint paint6 = polarPlot0.getAngleLabelPaint();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        java.awt.Image image4 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image4, "", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray9 = projectInfo8.getLibraries();
        java.lang.String str10 = projectInfo8.getName();
        boolean boolean11 = borderArrangement0.equals((java.lang.Object) projectInfo8);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer();
        java.lang.Object obj13 = blockContainer12.clone();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        try {
            borderArrangement0.add((org.jfree.chart.block.Block) blockContainer12, (java.lang.Object) color14);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.awt.Color cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(libraryArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = statisticalLineAndShapeRenderer2.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = statisticalLineAndShapeRenderer2.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        java.awt.Paint paint14 = statisticalLineAndShapeRenderer2.getSeriesPaint((-1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNull(paint14);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        polarPlot0.markerChanged(markerChangeEvent1);
        try {
            polarPlot0.setBackgroundImageAlpha((float) 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.lang.String str1 = polarPlot0.getNoDataMessage();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        polarPlot0.rendererChanged(rendererChangeEvent2);
        boolean boolean4 = polarPlot0.isAngleLabelsVisible();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        polarPlot0.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("Range[1.0,1.0]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.awt.Shape shape1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity4 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) Double.NaN, shape1, "", "NOID");
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        polarPlot0.markerChanged(markerChangeEvent1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        polarPlot0.drawBackgroundImage(graphics2D3, rectangle2D4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint7 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        categoryAxis6.setTickMarkPaint(paint7);
        java.lang.String str9 = categoryAxis6.getLabel();
        categoryAxis6.setLabelAngle((double) '#');
        boolean boolean12 = categoryAxis6.isAxisLineVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis13.getLabelInsets();
        double double16 = rectangleInsets14.trimWidth((double) (byte) 10);
        double double18 = rectangleInsets14.calculateTopInset((-1.0d));
        categoryAxis6.setTickLabelInsets(rectangleInsets14);
        polarPlot0.setInsets(rectangleInsets14, false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.0d + "'", double18 == 3.0d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint6 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        statisticalLineAndShapeRenderer2.setBasePaint(paint6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis8.getLabelInsets();
        java.awt.Stroke stroke10 = categoryAxis8.getAxisLineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis11.getLabelInsets();
        double double14 = rectangleInsets12.trimWidth((double) (byte) 10);
        double double16 = rectangleInsets12.calculateTopInset((-1.0d));
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder(paint6, stroke10, rectangleInsets12);
        double double19 = rectangleInsets12.calculateBottomInset(Double.NaN);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 3.0d + "'", double16 == 3.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.0d + "'", double19 == 3.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = null;
        try {
            xYPlot0.setRangeAxisLocation(axisLocation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.lang.String str0 = org.jfree.chart.labels.IntervalCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {3} - {4}" + "'", str0.equals("({0}, {1}) = {3} - {4}"));
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        try {
            java.lang.String str3 = standardCategoryToolTipGenerator0.generateColumnLabel(categoryDataset1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        polarPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        try {
            polarPlot0.zoomRangeAxes((double) ' ', plotRenderingInfo4, point2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 3);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        polarPlot1.markerChanged(markerChangeEvent2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        polarPlot1.drawBackgroundImage(graphics2D4, rectangle2D5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        polarPlot1.drawBackgroundImage(graphics2D7, rectangle2D8);
        boolean boolean10 = categoryAxis3D0.hasListener((java.util.EventListener) polarPlot1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        categoryAxis0.setTickMarkPaint(paint1);
        java.lang.String str3 = categoryAxis0.getLabel();
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryAxis0.setLabelPaint(paint4);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity10 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis0, shape7, "({0}, {1}) = {2}", "({0}, {1}) = {2}");
        categoryAxis0.configure();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.lang.String str3 = textTitle2.getToolTipText();
        java.lang.String str4 = textTitle2.getText();
        textTitle2.setPadding((double) 100.0f, 0.0d, (double) (byte) -1, (double) 0);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        java.awt.Stroke stroke10 = statisticalLineAndShapeRenderer2.getItemOutlineStroke(4, (int) '4');
        boolean boolean11 = statisticalLineAndShapeRenderer2.getAutoPopulateSeriesOutlinePaint();
        statisticalLineAndShapeRenderer2.setSeriesVisible(0, (java.lang.Boolean) false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        java.lang.String str1 = lengthConstraintType0.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "LengthConstraintType.NONE" + "'", str1.equals("LengthConstraintType.NONE"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        try {
            org.jfree.chart.title.Title title6 = jFreeChart4.getSubtitle(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        boolean boolean5 = statisticalLineAndShapeRenderer2.isSeriesVisible((int) (byte) 10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = statisticalLineAndShapeRenderer2.getURLGenerator((int) (byte) -1, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(categoryURLGenerator8);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.List list1 = segmentedTimeline0.getExceptionSegments();
        segmentedTimeline0.setStartTime(0L);
        long long6 = segmentedTimeline0.getExceptionSegmentCount((long) (byte) -1, (long) 10);
        java.util.Date date7 = null;
        try {
            segmentedTimeline0.addBaseTimelineException(date7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        java.awt.Stroke stroke10 = statisticalLineAndShapeRenderer2.getItemOutlineStroke(4, (int) '4');
        boolean boolean11 = statisticalLineAndShapeRenderer2.getAutoPopulateSeriesOutlinePaint();
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(true, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.text.DateFormat dateFormat1 = standardCategoryToolTipGenerator0.getDateFormat();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double4 = defaultStatisticalCategoryDataset2.getRangeUpperBound(false);
        java.lang.Number number7 = defaultStatisticalCategoryDataset2.getMeanValue((java.lang.Comparable) 1, (java.lang.Comparable) (short) 0);
        java.util.List list8 = defaultStatisticalCategoryDataset2.getColumnKeys();
        try {
            java.lang.String str11 = standardCategoryToolTipGenerator0.generateToolTip((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset2, 15, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        boolean boolean3 = lengthAdjustmentType0.equals((java.lang.Object) 0.4d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CONTRACT" + "'", str1.equals("CONTRACT"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisSpace0.add((double) (byte) 0, rectangleEdge2);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = axisSpace0.expand(rectangle2D4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int1 = taskSeriesCollection0.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries3 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection0.add(taskSeries3);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = new org.jfree.chart.axis.NumberTickUnit(1.0E-5d);
        try {
            java.lang.Number number9 = taskSeriesCollection0.getPercentComplete((java.lang.Comparable) 1.0E-5d, (java.lang.Comparable) '4', 3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        java.awt.Paint paint4 = ringPlot0.getSectionPaint((java.lang.Comparable) (byte) 1);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.lang.String str3 = textTitle2.getToolTipText();
        textTitle2.setWidth(0.0d);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent6 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = textTitle2.getVerticalAlignment();
        java.awt.Paint paint8 = null;
        try {
            textTitle2.setPaint(paint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(verticalAlignment7);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        try {
            xYPlot0.setRangeAxisLocation(axisLocation2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        java.awt.Font font5 = statisticalLineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, rectangleAnchor8, (double) (short) 100, (double) 4);
        statisticalLineAndShapeRenderer2.setBaseShape(shape11, false);
        boolean boolean14 = statisticalLineAndShapeRenderer2.getUseFillPaint();
        statisticalLineAndShapeRenderer2.setSeriesItemLabelsVisible(2958465, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = null;
        statisticalLineAndShapeRenderer2.setLegendItemURLGenerator(categorySeriesLabelGenerator19);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setVersion("Range[1.0,1.0]");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        categoryAxis0.setTickMarkPaint(paint1);
        java.lang.String str3 = categoryAxis0.getLabel();
        categoryAxis0.setLabelAngle((double) '#');
        double double6 = categoryAxis0.getFixedDimension();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        jFreeChart4.setTitle("hi!");
        java.lang.Object obj7 = jFreeChart4.getTextAntiAlias();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.Point2D point2D10 = null;
        org.jfree.chart.entity.EntityCollection entityCollection11 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo(entityCollection11);
        org.jfree.chart.entity.EntityCollection entityCollection13 = chartRenderingInfo12.getEntityCollection();
        try {
            jFreeChart4.draw(graphics2D8, rectangle2D9, point2D10, chartRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNull(entityCollection13);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis6);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis6.setRange((org.jfree.data.Range) dateRange10);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset12 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset12.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.general.DatasetGroup datasetGroup18 = defaultStatisticalCategoryDataset12.getGroup();
        try {
            waterfallBarRenderer0.drawItem(graphics2D1, categoryItemRendererState2, rectangle2D3, categoryPlot4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12, 0, 9999, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup18);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getUpperMargin();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range2, false, true);
        double double6 = dateAxis0.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.List list1 = segmentedTimeline0.getExceptionSegments();
        segmentedTimeline0.setStartTime(0L);
        long long6 = segmentedTimeline0.getExceptionSegmentCount((long) (byte) -1, (long) 10);
        int int7 = segmentedTimeline0.getGroupSegmentCount();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 7 + "'", int7 == 7);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.awt.Color color1 = java.awt.Color.YELLOW;
        java.awt.image.ColorModel colorModel2 = null;
        java.awt.Rectangle rectangle3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.AffineTransform affineTransform5 = null;
        java.awt.RenderingHints renderingHints6 = null;
        java.awt.PaintContext paintContext7 = color1.createContext(colorModel2, rectangle3, rectangle2D4, affineTransform5, renderingHints6);
        java.awt.Stroke stroke8 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 2, (java.awt.Paint) color1, stroke8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintContext7);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str9 = spreadsheetDate8.getDescription();
        int int10 = spreadsheetDate8.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str13 = spreadsheetDate12.getDescription();
        org.jfree.data.time.SerialDate serialDate14 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        java.lang.Number number15 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) (-1.0f), (java.lang.Comparable) serialDate14);
        serialDate14.setDescription("Range[1.0,1.0]");
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNull(number15);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        java.awt.Stroke stroke10 = statisticalLineAndShapeRenderer2.getItemOutlineStroke(4, (int) '4');
        boolean boolean11 = statisticalLineAndShapeRenderer2.getAutoPopulateSeriesOutlinePaint();
        java.awt.Stroke stroke13 = statisticalLineAndShapeRenderer2.getSeriesStroke((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(stroke13);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis5 = xYPlot0.getRangeAxisForDataset((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 'index' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.lang.String str3 = textTitle2.getToolTipText();
        java.lang.String str4 = textTitle2.getText();
        java.lang.String str5 = textTitle2.getID();
        java.lang.Object obj6 = textTitle2.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = textTitle2.getPosition();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        try {
            defaultKeyedValues2D1.removeColumn(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("Polar Plot", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = null;
        try {
            xYPlot0.setOrientation(plotOrientation5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke3 = polarPlot2.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', (java.awt.Paint) color1, stroke3);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int6 = taskSeriesCollection5.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries8 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection5.add(taskSeries8);
        org.jfree.data.gantt.TaskSeries taskSeries11 = taskSeriesCollection5.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, (java.lang.Comparable) "CONTRACT");
        boolean boolean14 = categoryMarker4.equals((java.lang.Object) taskSeriesCollection5);
        try {
            org.jfree.data.general.PieDataset pieDataset16 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, (java.lang.Comparable) "Polar Plot");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(taskSeries11);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 100L, (float) (short) 100);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        java.lang.Object obj5 = null;
        boolean boolean6 = xYPlot0.equals(obj5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomDomainAxes((double) 0L, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        try {
            xYPlot0.setDomainAxisLocation(axisLocation11, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        boolean boolean5 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomDomainAxes((double) 15, plotRenderingInfo7, point2D8);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        try {
            java.awt.Color color1 = java.awt.Color.decode("Range[1.0,1.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Range[1.0,1.0]\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.black;
        try {
            org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("({0}, {1}) = {2}", font1, (java.awt.Paint) color2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        segmentedTimeline0.setStartTime((long) (-1));
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.List list4 = segmentedTimeline3.getExceptionSegments();
        try {
            segmentedTimeline0.setBaseTimeline(segmentedTimeline3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: baseTimeline.getStartTime() is after startTime");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segmentedTimeline3);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 1, (double) (short) 10, false);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis6.getLabelInsets();
        double double9 = rectangleInsets7.trimWidth((double) (byte) 10);
        double double11 = rectangleInsets7.calculateTopInset((-1.0d));
        double double13 = rectangleInsets7.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str16 = labelBlock15.getToolTipText();
        java.lang.String str17 = labelBlock15.getURLText();
        java.awt.geom.Rectangle2D rectangle2D18 = labelBlock15.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType19 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType20 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str21 = lengthAdjustmentType20.toString();
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets7.createAdjustedRectangle(rectangle2D18, lengthAdjustmentType19, lengthAdjustmentType20);
        try {
            stackedBarRenderer3D3.drawOutline(graphics2D4, categoryPlot5, rectangle2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.0d + "'", double13 == 3.0d);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(lengthAdjustmentType19);
        org.junit.Assert.assertNotNull(lengthAdjustmentType20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "CONTRACT" + "'", str21.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D22);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.awt.Paint paint0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int1 = taskSeriesCollection0.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries3 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection0.add(taskSeries3);
        org.jfree.data.gantt.TaskSeries taskSeries6 = taskSeriesCollection0.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, (java.lang.Comparable) "CONTRACT");
        taskSeriesCollection0.validateObject();
        try {
            java.lang.Number number12 = taskSeriesCollection0.getValue(7, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(taskSeries6);
        org.junit.Assert.assertNotNull(pieDataset8);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = barRenderer0.getPlot();
        int int2 = barRenderer0.getColumnCount();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer3 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        barRenderer0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer3);
        org.junit.Assert.assertNull(categoryPlot1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getGPL();
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        dateAxis0.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline1);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.setRangeWithMargins((double) 1L, 12.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = dateAxis3.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = dateAxis8.getStandardTickUnits();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis8.setRangeWithMargins((org.jfree.data.Range) dateRange12, false, false);
        dateAxis8.setAutoRange(false);
        java.util.Date date18 = dateAxis8.getMinimumDate();
        java.util.Date date19 = dateTickUnit7.rollDate(date18);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource21 = dateAxis20.getStandardTickUnits();
        org.jfree.data.time.DateRange dateRange24 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis20.setRangeWithMargins((org.jfree.data.Range) dateRange24, false, false);
        dateAxis20.setAutoRange(false);
        java.util.Date date30 = dateAxis20.getMinimumDate();
        try {
            boolean boolean31 = segmentedTimeline1.containsDomainRange(date19, date30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: domainValueEnd (100) < domainValueStart (86400100)");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertNotNull(dateTickUnit7);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(tickUnitSource21);
        org.junit.Assert.assertNotNull(date30);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) 1.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint(range3, (double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, range3);
        org.jfree.data.Range range7 = rectangleConstraint6.getWidthRange();
        org.jfree.data.Range range8 = null;
        org.jfree.data.Range range10 = org.jfree.data.Range.expandToInclude(range8, (double) 1.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint(range10, (double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint6.toRangeHeight(range10);
        org.jfree.data.Range range14 = rectangleConstraint6.getWidthRange();
        org.jfree.data.Range range15 = rectangleConstraint6.getHeightRange();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(range15);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        statisticalLineAndShapeRenderer2.setBaseItemLabelGenerator(categoryItemLabelGenerator4, false);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer10.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint16 = statisticalLineAndShapeRenderer10.getItemOutlinePaint((-1), 0);
        boolean boolean18 = statisticalLineAndShapeRenderer10.equals((java.lang.Object) 2958465);
        java.awt.Color color20 = java.awt.Color.BLUE;
        statisticalLineAndShapeRenderer10.setSeriesOutlinePaint(4, (java.awt.Paint) color20);
        try {
            statisticalLineAndShapeRenderer2.setSeriesFillPaint((-1), (java.awt.Paint) color20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer2 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.LegendItem legendItem5 = areaRenderer2.getLegendItem(2, 0);
        java.awt.Shape shape6 = areaRenderer2.getBaseShape();
        boolean boolean7 = stackedBarRenderer3D1.equals((java.lang.Object) shape6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("hi!", font11);
        java.lang.String str13 = textTitle12.getToolTipText();
        textTitle12.setWidth(0.0d);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent16 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle12);
        java.awt.Color color17 = java.awt.Color.cyan;
        boolean boolean18 = textTitle12.equals((java.lang.Object) color17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryAxis20.getLabelInsets();
        double double23 = rectangleInsets21.trimWidth((double) (byte) 10);
        double double25 = rectangleInsets21.calculateTopInset((-1.0d));
        double double27 = rectangleInsets21.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock29 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str30 = labelBlock29.getToolTipText();
        java.lang.String str31 = labelBlock29.getURLText();
        java.awt.geom.Rectangle2D rectangle2D32 = labelBlock29.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType33 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType34 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str35 = lengthAdjustmentType34.toString();
        java.awt.geom.Rectangle2D rectangle2D36 = rectangleInsets21.createAdjustedRectangle(rectangle2D32, lengthAdjustmentType33, lengthAdjustmentType34);
        java.lang.Object obj37 = null;
        java.lang.Object obj38 = textTitle12.draw(graphics2D19, rectangle2D32, obj37);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        double double40 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D32, rectangleEdge39);
        try {
            stackedBarRenderer3D1.drawOutline(graphics2D8, categoryPlot9, rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(legendItem5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 3.0d + "'", double25 == 3.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(lengthAdjustmentType33);
        org.junit.Assert.assertNotNull(lengthAdjustmentType34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "CONTRACT" + "'", str35.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNull(obj38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("", "NOID", "", "");
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        java.lang.Object obj3 = statisticalLineAndShapeRenderer2.clone();
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.lang.String str2 = polarPlot1.getNoDataMessage();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = null;
        polarPlot1.rendererChanged(rendererChangeEvent3);
        polarPlot1.addCornerTextItem("NOID");
        java.awt.Font font7 = polarPlot1.getNoDataMessageFont();
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("NOID", font7);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = ringPlot0.getLegendLabelGenerator();
        boolean boolean4 = ringPlot0.getLabelLinksVisible();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int1 = taskSeriesCollection0.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries3 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection0.add(taskSeries3);
        org.jfree.data.gantt.TaskSeries taskSeries6 = taskSeriesCollection0.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, (java.lang.Comparable) "CONTRACT");
        try {
            taskSeriesCollection0.remove((-329600));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: TaskSeriesCollection.remove(): index outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(taskSeries6);
        org.junit.Assert.assertNotNull(pieDataset8);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("({0}, {1}) = {3} - {4}");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.25d + "'", double0 == 0.25d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        double double3 = rectangleInsets1.trimWidth((double) (byte) 10);
        double double5 = rectangleInsets1.calculateLeftOutset(0.0d);
        double double7 = rectangleInsets1.calculateBottomOutset((double) (byte) 10);
        double double9 = rectangleInsets1.calculateBottomInset((double) 100L);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint8 = statisticalLineAndShapeRenderer2.getItemOutlinePaint((-1), 0);
        boolean boolean10 = statisticalLineAndShapeRenderer2.isSeriesItemLabelsVisible(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = statisticalLineAndShapeRenderer2.getNegativeItemLabelPosition((int) (short) 1, (int) (byte) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = statisticalLineAndShapeRenderer2.getPositiveItemLabelPosition(7, (int) (byte) -1);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        categoryAxis0.setTickMarkPaint(paint1);
        java.lang.String str3 = categoryAxis0.getLabel();
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryAxis0.setLabelPaint(paint4);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity10 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis0, shape7, "({0}, {1}) = {2}", "({0}, {1}) = {2}");
        java.lang.String str11 = axisLabelEntity10.getToolTipText();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator12 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator13 = null;
        try {
            java.lang.String str14 = axisLabelEntity10.getImageMapAreaTag(toolTipTagFragmentGenerator12, uRLTagFragmentGenerator13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "({0}, {1}) = {2}" + "'", str11.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.configure();
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str9 = spreadsheetDate8.getDescription();
        int int10 = spreadsheetDate8.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str13 = spreadsheetDate12.getDescription();
        org.jfree.data.time.SerialDate serialDate14 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        java.lang.Number number15 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) (-1.0f), (java.lang.Comparable) serialDate14);
        java.lang.Number number18 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) 0L, (java.lang.Comparable) 3.0d);
        try {
            java.lang.Comparable comparable20 = defaultStatisticalCategoryDataset0.getColumnKey((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertNull(number18);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = barRenderer0.getPlot();
        double double2 = barRenderer0.getMaximumBarWidth();
        barRenderer0.setAutoPopulateSeriesPaint(false);
        org.junit.Assert.assertNull(categoryPlot1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean4 = statisticalLineAndShapeRenderer3.getBaseItemLabelsVisible();
        int int5 = statisticalLineAndShapeRenderer3.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        statisticalLineAndShapeRenderer3.setSeriesNegativeItemLabelPosition(0, itemLabelPosition7);
        java.awt.Stroke stroke11 = statisticalLineAndShapeRenderer3.getItemOutlineStroke(4, (int) '4');
        boolean boolean12 = waterfallBarRenderer0.equals((java.lang.Object) statisticalLineAndShapeRenderer3);
        java.lang.Object obj13 = null;
        boolean boolean14 = waterfallBarRenderer0.equals(obj13);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        jFreeChart4.setTitle("hi!");
        java.lang.Object obj7 = jFreeChart4.getTextAntiAlias();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font9);
        java.lang.String str11 = textTitle10.getToolTipText();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("hi!", font13);
        java.lang.String str15 = textTitle14.getToolTipText();
        textTitle14.setWidth(0.0d);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent18 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle14);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle14.getVerticalAlignment();
        textTitle10.setVerticalAlignment(verticalAlignment19);
        jFreeChart4.setTitle(textTitle10);
        org.jfree.chart.entity.EntityCollection entityCollection25 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = new org.jfree.chart.ChartRenderingInfo(entityCollection25);
        org.jfree.chart.entity.EntityCollection entityCollection27 = chartRenderingInfo26.getEntityCollection();
        try {
            java.awt.image.BufferedImage bufferedImage28 = jFreeChart4.createBufferedImage(4, 0, (int) 'a', chartRenderingInfo26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNull(entityCollection27);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (byte) 0, (double) (byte) 100, (double) 100.0f, 1.0d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Tuesday" + "'", str1.equals("Tuesday"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke3 = polarPlot2.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', (java.awt.Paint) color1, stroke3);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int6 = taskSeriesCollection5.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries8 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection5.add(taskSeries8);
        org.jfree.data.gantt.TaskSeries taskSeries11 = taskSeriesCollection5.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, (java.lang.Comparable) "CONTRACT");
        boolean boolean14 = categoryMarker4.equals((java.lang.Object) taskSeriesCollection5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str17 = spreadsheetDate16.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str20 = spreadsheetDate19.getDescription();
        int int21 = spreadsheetDate19.getDayOfWeek();
        boolean boolean22 = spreadsheetDate16.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str25 = spreadsheetDate24.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str28 = spreadsheetDate27.getDescription();
        int int29 = spreadsheetDate27.getDayOfWeek();
        boolean boolean30 = spreadsheetDate24.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(8);
        boolean boolean34 = spreadsheetDate19.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate27, (org.jfree.data.time.SerialDate) spreadsheetDate32, 10);
        try {
            java.lang.Number number37 = taskSeriesCollection5.getStartValue((java.lang.Comparable) 10, (java.lang.Comparable) "Polar Plot", (-329600));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(taskSeries11);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer5.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint9 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        statisticalLineAndShapeRenderer5.setBasePaint(paint9);
        textTitle2.setBackgroundPaint(paint9);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis13.getLabelInsets();
        double double16 = rectangleInsets14.trimWidth((double) (byte) 10);
        double double18 = rectangleInsets14.calculateTopInset((-1.0d));
        org.jfree.chart.block.LineBorder lineBorder19 = new org.jfree.chart.block.LineBorder(paint9, stroke12, rectangleInsets14);
        java.awt.Stroke stroke20 = lineBorder19.getStroke();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.0d + "'", double18 == 3.0d);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.lang.Object obj1 = blockContainer0.clone();
        double double2 = blockContainer0.getWidth();
        java.lang.Object obj3 = blockContainer0.clone();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisSpace axisSpace5 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis6.getLabelInsets();
        double double9 = rectangleInsets7.trimWidth((double) (byte) 10);
        double double11 = rectangleInsets7.calculateTopInset((-1.0d));
        double double13 = rectangleInsets7.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str16 = labelBlock15.getToolTipText();
        java.lang.String str17 = labelBlock15.getURLText();
        java.awt.geom.Rectangle2D rectangle2D18 = labelBlock15.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType19 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType20 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str21 = lengthAdjustmentType20.toString();
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets7.createAdjustedRectangle(rectangle2D18, lengthAdjustmentType19, lengthAdjustmentType20);
        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str25 = labelBlock24.getToolTipText();
        java.lang.String str26 = labelBlock24.getURLText();
        java.awt.geom.Rectangle2D rectangle2D27 = labelBlock24.getBounds();
        java.awt.geom.Rectangle2D rectangle2D28 = axisSpace5.shrink(rectangle2D22, rectangle2D27);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator29 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.text.DateFormat dateFormat30 = standardCategoryToolTipGenerator29.getDateFormat();
        try {
            java.lang.Object obj31 = blockContainer0.draw(graphics2D4, rectangle2D22, (java.lang.Object) dateFormat30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.0d + "'", double13 == 3.0d);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(lengthAdjustmentType19);
        org.junit.Assert.assertNotNull(lengthAdjustmentType20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "CONTRACT" + "'", str21.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNull(dateFormat30);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setRangeWithMargins((double) 1L, 12.0d);
        dateAxis0.resizeRange(1.0d, 1.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition7 = dateAxis0.getTickMarkPosition();
        org.junit.Assert.assertNotNull(dateTickMarkPosition7);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        double double3 = ringPlot0.getMaximumLabelWidth();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        java.awt.Stroke stroke5 = ringPlot0.getLabelLinkStroke();
        java.awt.Paint paint6 = null;
        try {
            ringPlot0.setBaseSectionPaint(paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.lang.String str1 = polarPlot0.getNoDataMessage();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        polarPlot0.rendererChanged(rendererChangeEvent2);
        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis7.getLabelInsets();
        double double10 = rectangleInsets8.trimWidth((double) (byte) 10);
        double double12 = rectangleInsets8.calculateTopInset((-1.0d));
        double double14 = rectangleInsets8.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str17 = labelBlock16.getToolTipText();
        java.lang.String str18 = labelBlock16.getURLText();
        java.awt.geom.Rectangle2D rectangle2D19 = labelBlock16.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType20 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType21 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str22 = lengthAdjustmentType21.toString();
        java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets8.createAdjustedRectangle(rectangle2D19, lengthAdjustmentType20, lengthAdjustmentType21);
        org.jfree.chart.block.LabelBlock labelBlock25 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str26 = labelBlock25.getToolTipText();
        java.lang.String str27 = labelBlock25.getURLText();
        java.awt.geom.Rectangle2D rectangle2D28 = labelBlock25.getBounds();
        java.awt.geom.Rectangle2D rectangle2D29 = axisSpace6.shrink(rectangle2D23, rectangle2D28);
        try {
            java.awt.Point point30 = polarPlot0.translateValueThetaRadiusToJava2D((double) (-1), (double) 2958465, rectangle2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.0d + "'", double14 == 3.0d);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(lengthAdjustmentType20);
        org.junit.Assert.assertNotNull(lengthAdjustmentType21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "CONTRACT" + "'", str22.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D29);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.List list1 = segmentedTimeline0.getExceptionSegments();
        segmentedTimeline0.setStartTime(0L);
        long long6 = segmentedTimeline0.getExceptionSegmentCount((long) (byte) -1, (long) 10);
        long long8 = segmentedTimeline0.toTimelineValue((long) '#');
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 35L + "'", long8 == 35L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (short) 1, (double) 9999);
        double double3 = size2D2.width;
        double double4 = size2D2.height;
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9999.0d + "'", double4 == 9999.0d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        double double3 = rectangleInsets1.trimWidth((double) (byte) 10);
        double double5 = rectangleInsets1.extendWidth((double) 'a');
        double double7 = rectangleInsets1.calculateBottomInset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 103.0d + "'", double5 == 103.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        java.awt.Stroke stroke2 = categoryAxis0.getAxisLineStroke();
        float float3 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        java.lang.Object obj4 = categoryAxis0.clone();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        try {
            java.awt.Color color1 = java.awt.Color.decode("LengthConstraintType.NONE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"LengthConstraintType.NONE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.lang.Object obj1 = null;
        boolean boolean2 = paintList0.equals(obj1);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer6 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer6.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint12 = statisticalLineAndShapeRenderer6.getItemOutlinePaint((-1), 0);
        boolean boolean15 = statisticalLineAndShapeRenderer6.getItemVisible(7, (int) (short) 10);
        statisticalLineAndShapeRenderer6.setBaseCreateEntities(true, false);
        org.jfree.chart.LegendItem legendItem21 = statisticalLineAndShapeRenderer6.getLegendItem((int) (byte) 0, (int) (byte) 100);
        java.awt.Paint paint22 = statisticalLineAndShapeRenderer6.getBaseOutlinePaint();
        try {
            paintList0.setPaint((-1), paint22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(legendItem21);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setMaximumBarWidth((double) 2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = barRenderer0.getNegativeItemLabelPositionFallback();
        barRenderer0.setSeriesItemLabelsVisible(100, true);
        org.junit.Assert.assertNull(itemLabelPosition3);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        statisticalLineAndShapeRenderer2.setUseFillPaint(false);
        boolean boolean10 = statisticalLineAndShapeRenderer2.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint12 = null;
        statisticalLineAndShapeRenderer2.setSeriesFillPaint(4, paint12);
        statisticalLineAndShapeRenderer2.setBaseItemLabelsVisible(true, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = statisticalLineAndShapeRenderer2.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = statisticalLineAndShapeRenderer2.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer15.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint21 = statisticalLineAndShapeRenderer15.getItemOutlinePaint((-1), 0);
        statisticalLineAndShapeRenderer2.setBaseOutlinePaint(paint21, true);
        boolean boolean26 = statisticalLineAndShapeRenderer2.getItemShapeFilled(1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        double double3 = ringPlot0.getMaximumLabelWidth();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        java.awt.Stroke stroke5 = ringPlot0.getLabelLinkStroke();
        ringPlot0.setStartAngle(9.223372036854776E18d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("Range[1.0,1.0]", "NOID", "DateTickUnit[DAY, 1]", image3, "({0}, {1}) = {2}", "Range[1.0,1.0]", "");
        java.awt.Image image11 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo15 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image11, "", "hi!", "");
        java.awt.Image image19 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo23 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image19, "", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray24 = projectInfo23.getLibraries();
        projectInfo15.addLibrary((org.jfree.chart.ui.Library) projectInfo23);
        org.jfree.chart.ui.Library[] libraryArray26 = projectInfo23.getLibraries();
        projectInfo23.setLicenceName("({0}, {1}) = {3} - {4}");
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo23);
        org.junit.Assert.assertNotNull(libraryArray24);
        org.junit.Assert.assertNotNull(libraryArray26);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        int int0 = org.jfree.chart.axis.DateTickUnit.MILLISECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj1 = categoryAxis3D0.clone();
        categoryAxis3D0.configure();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent3 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D0);
        categoryAxis3D0.setLabelAngle((double) (byte) -1);
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.lang.String str2 = polarPlot1.getNoDataMessage();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = null;
        polarPlot1.rendererChanged(rendererChangeEvent3);
        polarPlot1.addCornerTextItem("NOID");
        java.awt.Font font7 = polarPlot1.getNoDataMessageFont();
        categoryAxis3D0.setPlot((org.jfree.chart.plot.Plot) polarPlot1);
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str13 = labelBlock12.getToolTipText();
        java.lang.String str14 = labelBlock12.getURLText();
        java.awt.geom.Rectangle2D rectangle2D15 = labelBlock12.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D15, "Polar Plot", "LengthConstraintType.NONE");
        try {
            java.awt.Point point19 = polarPlot1.translateValueThetaRadiusToJava2D((double) 1L, (double) (short) 0, rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(rectangle2D15);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str5 = labelBlock4.getToolTipText();
        java.lang.String str6 = labelBlock4.getURLText();
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock4.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint10 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        categoryAxis9.setTickMarkPaint(paint10);
        java.lang.String str12 = categoryAxis9.getLabel();
        categoryAxis9.setMaximumCategoryLabelLines((int) (short) 100);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis15.getStandardTickUnits();
        org.jfree.data.time.DateRange dateRange19 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis15.setRangeWithMargins((org.jfree.data.Range) dateRange19, false, false);
        dateAxis15.setAutoRange(false);
        java.util.Date date25 = dateAxis15.getMinimumDate();
        boolean boolean26 = dateAxis15.isVerticalTickLabels();
        org.jfree.data.Range range27 = null;
        org.jfree.data.Range range29 = org.jfree.data.Range.expandToInclude(range27, (double) 1.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint(range29, (double) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis32.getLabelInsets();
        double double35 = rectangleInsets33.trimWidth((double) (byte) 10);
        boolean boolean36 = range29.equals((java.lang.Object) rectangleInsets33);
        dateAxis15.setRange(range29, false, false);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset40 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        try {
            barRenderer0.drawItem(graphics2D1, categoryItemRendererState2, rectangle2D7, categoryPlot8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset40, (-1), (int) (short) 1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 4.0d + "'", double35 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        double[] doubleArray5 = new double[] { 1.0E-5d, 0.0d, 100L };
        double[] doubleArray9 = new double[] { 1.0E-5d, 0.0d, 100L };
        double[] doubleArray13 = new double[] { 1.0E-5d, 0.0d, 100L };
        double[][] doubleArray14 = new double[][] { doubleArray5, doubleArray9, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "LengthConstraintType.NONE", doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str5 = spreadsheetDate4.getDescription();
        int int6 = spreadsheetDate4.getDayOfWeek();
        boolean boolean7 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate8 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str11 = spreadsheetDate10.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str14 = spreadsheetDate13.getDescription();
        int int15 = spreadsheetDate13.getDayOfWeek();
        boolean boolean16 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str19 = spreadsheetDate18.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str22 = spreadsheetDate21.getDescription();
        int int23 = spreadsheetDate21.getDayOfWeek();
        boolean boolean24 = spreadsheetDate18.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(8);
        boolean boolean28 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate21, (org.jfree.data.time.SerialDate) spreadsheetDate26, 10);
        org.jfree.data.time.SerialDate serialDate30 = spreadsheetDate26.getPreviousDayOfWeek(7);
        try {
            boolean boolean31 = spreadsheetDate1.isInRange(serialDate8, serialDate30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(serialDate30);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = ringPlot0.getLegendLabelGenerator();
        boolean boolean4 = ringPlot0.getSeparatorsVisible();
        double double5 = ringPlot0.getMaximumLabelWidth();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(Double.NaN);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        java.awt.Paint paint5 = jFreeChart4.getBorderPaint();
        java.lang.Object obj6 = jFreeChart4.getTextAntiAlias();
        java.lang.Object obj7 = jFreeChart4.getTextAntiAlias();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNull(obj7);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.resizeRange(1.0d);
        org.jfree.data.Range range3 = null;
        org.jfree.data.Range range5 = org.jfree.data.Range.expandToInclude(range3, (double) 1.0f);
        try {
            dateAxis0.setRange(range3, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) '#');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        java.awt.Font font5 = statisticalLineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, rectangleAnchor8, (double) (short) 100, (double) 4);
        statisticalLineAndShapeRenderer2.setBaseShape(shape11, false);
        statisticalLineAndShapeRenderer2.setAutoPopulateSeriesFillPaint(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = statisticalLineAndShapeRenderer2.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = statisticalLineAndShapeRenderer2.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer15.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint21 = statisticalLineAndShapeRenderer15.getItemOutlinePaint((-1), 0);
        statisticalLineAndShapeRenderer2.setBaseOutlinePaint(paint21, true);
        java.awt.Shape shape25 = statisticalLineAndShapeRenderer2.lookupSeriesShape((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(shape25);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        polarPlot0.drawBackgroundImage(graphics2D4, rectangle2D5);
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke8 = polarPlot7.getOutlineStroke();
        boolean boolean9 = polarPlot0.equals((java.lang.Object) polarPlot7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("hi!", font3);
        java.awt.Paint paint5 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("({0}, {1}) = {2}", font3, paint5);
        textBlock0.addLine(textLine6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        try {
            textBlock0.draw(graphics2D8, (float) 2, (float) (byte) 10, textBlockAnchor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textBlockAnchor11);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        categoryAxis0.setTickMarkPaint(paint1);
        java.lang.String str3 = categoryAxis0.getLabel();
        categoryAxis0.setLabelAngle((double) '#');
        boolean boolean6 = categoryAxis0.isAxisLineVisible();
        java.awt.Shape shape7 = null;
        try {
            org.jfree.chart.entity.AxisLabelEntity axisLabelEntity10 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis0, shape7, "LengthConstraintType.NONE", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("LengthConstraintType.NONE");
        java.awt.Shape shape2 = numberAxis3D1.getLeftArrow();
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int1 = taskSeriesCollection0.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries3 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection0.add(taskSeries3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        taskSeries3.addPropertyChangeListener(propertyChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        taskSeries3.removePropertyChangeListener(propertyChangeListener7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset3.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.general.DatasetGroup datasetGroup9 = defaultStatisticalCategoryDataset3.getGroup();
        java.lang.Comparable comparable11 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity12 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "hi!", "", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, (java.lang.Comparable) 1.0d, comparable11);
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint14 = polarPlot13.getOutlinePaint();
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot13.setOutlineStroke(stroke15);
        java.lang.String str17 = polarPlot13.getPlotType();
        int int18 = polarPlot13.getBackgroundImageAlignment();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = categoryAxis19.getLabelInsets();
        java.awt.Stroke stroke21 = categoryAxis19.getAxisLineStroke();
        float float22 = categoryAxis19.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent23 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis19);
        org.jfree.chart.axis.Axis axis24 = axisChangeEvent23.getAxis();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer27 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean28 = statisticalLineAndShapeRenderer27.getBaseItemLabelsVisible();
        int int29 = statisticalLineAndShapeRenderer27.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = null;
        statisticalLineAndShapeRenderer27.setSeriesNegativeItemLabelPosition(0, itemLabelPosition31);
        java.awt.Stroke stroke35 = statisticalLineAndShapeRenderer27.getItemOutlineStroke(4, (int) '4');
        statisticalLineAndShapeRenderer27.setItemLabelAnchorOffset((double) (short) 1);
        java.awt.Stroke stroke38 = statisticalLineAndShapeRenderer27.getBaseOutlineStroke();
        axis24.setTickMarkStroke(stroke38);
        polarPlot13.setAngleGridlineStroke(stroke38);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent41 = null;
        polarPlot13.datasetChanged(datasetChangeEvent41);
        boolean boolean43 = defaultStatisticalCategoryDataset3.hasListener((java.util.EventListener) polarPlot13);
        org.jfree.chart.plot.RingPlot ringPlot44 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint45 = null;
        ringPlot44.setShadowPaint(paint45);
        double double47 = ringPlot44.getMaximumLabelWidth();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent48 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        ringPlot44.setExplodePercent((java.lang.Comparable) 'a', (double) 100);
        polarPlot13.setParent((org.jfree.chart.plot.Plot) ringPlot44);
        java.awt.Stroke stroke54 = ringPlot44.getSeparatorStroke();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(datasetGroup9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Polar Plot" + "'", str17.equals("Polar Plot"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertNotNull(axis24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2 + "'", int29 == 2);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.2d + "'", double47 == 0.2d);
        org.junit.Assert.assertNotNull(stroke54);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D2 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int3 = defaultKeyedValues2D2.getRowCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str8 = spreadsheetDate7.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str11 = spreadsheetDate10.getDescription();
        int int12 = spreadsheetDate10.getDayOfWeek();
        boolean boolean13 = spreadsheetDate7.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        defaultKeyedValues2D2.addValue((java.lang.Number) 2958465, (java.lang.Comparable) 100.0f, (java.lang.Comparable) spreadsheetDate7);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate7);
        try {
            int int17 = spreadsheetDate7.compareTo((java.lang.Object) 0.05d);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Double cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(serialDate15);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.lang.Object obj1 = null;
        boolean boolean2 = numberAxis3D0.equals(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        java.awt.Stroke stroke10 = statisticalLineAndShapeRenderer2.getItemOutlineStroke(4, (int) '4');
        statisticalLineAndShapeRenderer2.setItemLabelAnchorOffset((double) (short) 1);
        java.awt.Stroke stroke13 = statisticalLineAndShapeRenderer2.getBaseOutlineStroke();
        java.awt.Stroke stroke15 = statisticalLineAndShapeRenderer2.getSeriesStroke((int) (short) 1);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = categoryAxis18.getLabelInsets();
        double double21 = rectangleInsets19.trimWidth((double) (byte) 10);
        double double23 = rectangleInsets19.calculateTopInset((-1.0d));
        double double25 = rectangleInsets19.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock27 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str28 = labelBlock27.getToolTipText();
        java.lang.String str29 = labelBlock27.getURLText();
        java.awt.geom.Rectangle2D rectangle2D30 = labelBlock27.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType31 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType32 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str33 = lengthAdjustmentType32.toString();
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets19.createAdjustedRectangle(rectangle2D30, lengthAdjustmentType31, lengthAdjustmentType32);
        try {
            statisticalLineAndShapeRenderer2.drawOutline(graphics2D16, categoryPlot17, rectangle2D34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 3.0d + "'", double23 == 3.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 3.0d + "'", double25 == 3.0d);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(lengthAdjustmentType31);
        org.junit.Assert.assertNotNull(lengthAdjustmentType32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "CONTRACT" + "'", str33.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D34);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        polarPlot0.drawBackgroundImage(graphics2D4, rectangle2D5);
        org.jfree.chart.plot.Plot plot7 = polarPlot0.getRootPlot();
        polarPlot0.setRadiusGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(plot7);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("RectangleConstraintType.RANGE");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("LengthConstraintType.NONE");
        boolean boolean2 = numberAxis3D1.isInverted();
        org.jfree.data.RangeType rangeType3 = numberAxis3D1.getRangeType();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rangeType3);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator0 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer2 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.LegendItem legendItem5 = areaRenderer2.getLegendItem(2, 0);
        java.awt.Shape shape6 = areaRenderer2.getBaseShape();
        boolean boolean7 = stackedBarRenderer3D1.equals((java.lang.Object) shape6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("hi!", font10);
        java.lang.String str12 = textTitle11.getToolTipText();
        textTitle11.setWidth(0.0d);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent15 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle11);
        java.awt.Color color16 = java.awt.Color.cyan;
        boolean boolean17 = textTitle11.equals((java.lang.Object) color16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = categoryAxis19.getLabelInsets();
        double double22 = rectangleInsets20.trimWidth((double) (byte) 10);
        double double24 = rectangleInsets20.calculateTopInset((-1.0d));
        double double26 = rectangleInsets20.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock28 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str29 = labelBlock28.getToolTipText();
        java.lang.String str30 = labelBlock28.getURLText();
        java.awt.geom.Rectangle2D rectangle2D31 = labelBlock28.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType32 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType33 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str34 = lengthAdjustmentType33.toString();
        java.awt.geom.Rectangle2D rectangle2D35 = rectangleInsets20.createAdjustedRectangle(rectangle2D31, lengthAdjustmentType32, lengthAdjustmentType33);
        java.lang.Object obj36 = null;
        java.lang.Object obj37 = textTitle11.draw(graphics2D18, rectangle2D31, obj36);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState41 = stackedBarRenderer3D1.initialise(graphics2D8, rectangle2D31, categoryPlot38, 6, plotRenderingInfo40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItem5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 4.0d + "'", double22 == 4.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.0d + "'", double24 == 3.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(lengthAdjustmentType32);
        org.junit.Assert.assertNotNull(lengthAdjustmentType33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "CONTRACT" + "'", str34.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNull(obj37);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint8 = statisticalLineAndShapeRenderer2.getItemOutlinePaint((-1), 0);
        boolean boolean10 = statisticalLineAndShapeRenderer2.isSeriesItemLabelsVisible(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = statisticalLineAndShapeRenderer2.getLegendItemToolTipGenerator();
        java.awt.Stroke stroke13 = statisticalLineAndShapeRenderer2.getSeriesOutlineStroke(2958465);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator11);
        org.junit.Assert.assertNull(stroke13);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke3 = polarPlot2.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', (java.awt.Paint) color1, stroke3);
        java.lang.Object obj5 = categoryMarker4.clone();
        categoryMarker4.setAlpha(0.0f);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        int int2 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str5 = spreadsheetDate4.getDescription();
        int int6 = spreadsheetDate4.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str9 = spreadsheetDate8.getDescription();
        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str13 = spreadsheetDate12.getDescription();
        int int14 = spreadsheetDate12.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str17 = spreadsheetDate16.getDescription();
        org.jfree.data.time.SerialDate serialDate18 = spreadsheetDate12.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean19 = spreadsheetDate1.isInRange(serialDate10, (org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        java.lang.Object obj5 = null;
        boolean boolean6 = xYPlot0.equals(obj5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomDomainAxes((double) 0L, plotRenderingInfo8, point2D9);
        xYPlot0.setDomainCrosshairValue((-1.0d));
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = null;
        try {
            xYPlot0.setOrientation(plotOrientation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean5 = statisticalLineAndShapeRenderer4.getBaseItemLabelsVisible();
        int int6 = statisticalLineAndShapeRenderer4.getPassCount();
        java.awt.Font font7 = statisticalLineAndShapeRenderer4.getBaseItemLabelFont();
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("CONTRACT", font7, paint8, (float) '4');
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("NOID", font7);
        java.awt.Paint paint12 = textFragment11.getPaint();
        java.awt.Paint paint13 = textFragment11.getPaint();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        polarPlot0.markerChanged(markerChangeEvent1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        polarPlot0.drawBackgroundImage(graphics2D3, rectangle2D4);
        int int6 = polarPlot0.getSeriesCount();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 100, (int) (short) -1, 10);
        java.util.Date date4 = null;
        try {
            long long5 = segmentedTimeline3.toTimelineValue(date4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextFillPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        java.lang.Object obj3 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        java.awt.Stroke stroke10 = statisticalLineAndShapeRenderer2.getItemOutlineStroke(4, (int) '4');
        boolean boolean11 = statisticalLineAndShapeRenderer2.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        try {
            statisticalLineAndShapeRenderer2.setSeriesOutlinePaint((-329600), paint13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        jFreeChart4.setTitle("hi!");
        org.jfree.chart.event.ChartChangeListener chartChangeListener7 = null;
        try {
            jFreeChart4.removeChangeListener(chartChangeListener7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        jFreeChart4.setTitle("hi!");
        java.lang.Object obj7 = jFreeChart4.getTextAntiAlias();
        org.jfree.chart.title.TextTitle textTitle8 = jFreeChart4.getTitle();
        boolean boolean9 = jFreeChart4.isBorderVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNotNull(textTitle8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getRowCount();
        java.lang.Comparable comparable3 = null;
        try {
            int int4 = defaultKeyedValues2D1.getRowIndex(comparable3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset3.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.general.DatasetGroup datasetGroup9 = defaultStatisticalCategoryDataset3.getGroup();
        java.lang.String str10 = datasetGroup9.getID();
        defaultStatisticalCategoryDataset0.setGroup(datasetGroup9);
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        java.lang.String str13 = polarPlot12.getNoDataMessage();
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke15 = polarPlot14.getOutlineStroke();
        polarPlot12.setOutlineStroke(stroke15);
        defaultStatisticalCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot12);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(datasetGroup9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "NOID" + "'", str10.equals("NOID"));
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis0.setRangeWithMargins((org.jfree.data.Range) dateRange4, false, false);
        org.jfree.data.Range range9 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange4, (double) 35L);
        java.lang.String str10 = range9.toString();
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Range[135.0,135.0]" + "'", str10.equals("Range[135.0,135.0]"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        double double3 = ringPlot0.getMaximumLabelWidth();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = ringPlot0.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(drawingSupplier4);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str5 = labelBlock4.getToolTipText();
        java.lang.String str6 = labelBlock4.getURLText();
        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock4.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D7, "Polar Plot", "LengthConstraintType.NONE");
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryAxis12.getLabelInsets();
        boolean boolean14 = categoryAxis12.isAxisLineVisible();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer17 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean18 = statisticalLineAndShapeRenderer17.getBaseItemLabelsVisible();
        int int19 = statisticalLineAndShapeRenderer17.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = null;
        statisticalLineAndShapeRenderer17.setSeriesNegativeItemLabelPosition(0, itemLabelPosition21);
        java.awt.Stroke stroke25 = statisticalLineAndShapeRenderer17.getItemOutlineStroke(4, (int) '4');
        categoryAxis12.setAxisLineStroke(stroke25);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource28 = dateAxis27.getStandardTickUnits();
        org.jfree.data.time.DateRange dateRange31 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis27.setRangeWithMargins((org.jfree.data.Range) dateRange31, false, false);
        dateAxis27.setAutoRange(false);
        java.util.Date date37 = dateAxis27.getMinimumDate();
        boolean boolean38 = dateAxis27.isVerticalTickLabels();
        org.jfree.chart.axis.DateTickUnit dateTickUnit39 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str40 = dateTickUnit39.toString();
        double double41 = dateTickUnit39.getSize();
        dateAxis27.setTickUnit(dateTickUnit39);
        org.jfree.chart.block.BorderArrangement borderArrangement43 = new org.jfree.chart.block.BorderArrangement();
        borderArrangement43.clear();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection45 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int46 = taskSeriesCollection45.getColumnCount();
        java.util.List list47 = taskSeriesCollection45.getColumnKeys();
        int int48 = taskSeriesCollection45.getColumnCount();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer50 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) borderArrangement43, (org.jfree.data.general.Dataset) taskSeriesCollection45, (java.lang.Comparable) '4');
        try {
            lineRenderer3D0.drawItem(graphics2D1, categoryItemRendererState2, rectangle2D7, categoryPlot11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis27, (org.jfree.data.category.CategoryDataset) taskSeriesCollection45, 100, 2958465, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(tickUnitSource28);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTickUnit39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "DateTickUnit[DAY, 1]" + "'", str40.equals("DateTickUnit[DAY, 1]"));
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 8.64E7d + "'", double41 == 8.64E7d);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(list47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        textBlock0.draw(graphics2D1, (float) (byte) 100, (float) (byte) 1, textBlockAnchor4, (float) 7, (float) '4', (double) (short) 100);
        org.jfree.chart.text.TextLine textLine9 = null;
        textBlock0.addLine(textLine9);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit(9.223372036854776E18d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis3.getLabelInsets();
        double double6 = rectangleInsets4.trimWidth((double) (byte) 10);
        double double8 = rectangleInsets4.calculateTopInset((-1.0d));
        double double10 = rectangleInsets4.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str13 = labelBlock12.getToolTipText();
        java.lang.String str14 = labelBlock12.getURLText();
        java.awt.geom.Rectangle2D rectangle2D15 = labelBlock12.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType17 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str18 = lengthAdjustmentType17.toString();
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets4.createAdjustedRectangle(rectangle2D15, lengthAdjustmentType16, lengthAdjustmentType17);
        try {
            lineRenderer3D0.drawOutline(graphics2D1, categoryPlot2, rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(lengthAdjustmentType16);
        org.junit.Assert.assertNotNull(lengthAdjustmentType17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "CONTRACT" + "'", str18.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D19);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = statisticalLineAndShapeRenderer2.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = statisticalLineAndShapeRenderer2.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        boolean boolean14 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) "CONTRACT");
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = statisticalLineAndShapeRenderer2.getSeriesItemLabelGenerator(10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator16);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.DefaultKeyedValue defaultKeyedValue2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) "DateTickUnit[DAY, 1]", (java.lang.Number) 1);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        boolean boolean5 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder6 = xYPlot0.getSeriesRenderingOrder();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder6);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = barRenderer0.getPlot();
        int int2 = barRenderer0.getColumnCount();
        java.lang.Boolean boolean4 = barRenderer0.getSeriesVisible((int) (short) 0);
        java.awt.Paint paint6 = barRenderer0.getSeriesFillPaint((int) (short) 0);
        org.junit.Assert.assertNull(categoryPlot1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color2 = java.awt.Color.blue;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Paint[] paintArray4 = new java.awt.Paint[] { color0, color1, color2, color3 };
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Paint paint6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color5, paint6 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier8 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint9 = defaultDrawingSupplier8.getNextFillPaint();
        java.awt.Color color10 = java.awt.Color.BLUE;
        java.awt.Color color11 = java.awt.Color.GREEN;
        java.awt.Paint paint12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        java.awt.Color color13 = java.awt.Color.red;
        java.awt.Paint[] paintArray14 = new java.awt.Paint[] { paint9, color10, color11, paint12, color13 };
        java.awt.Stroke[] strokeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer18.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint24 = statisticalLineAndShapeRenderer18.getItemOutlinePaint((-1), 0);
        boolean boolean26 = statisticalLineAndShapeRenderer18.equals((java.lang.Object) 2958465);
        statisticalLineAndShapeRenderer18.setBaseSeriesVisibleInLegend(true, false);
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint31 = polarPlot30.getOutlinePaint();
        java.awt.Stroke stroke32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot30.setOutlineStroke(stroke32);
        java.lang.String str34 = polarPlot30.getPlotType();
        int int35 = polarPlot30.getBackgroundImageAlignment();
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = categoryAxis36.getLabelInsets();
        java.awt.Stroke stroke38 = categoryAxis36.getAxisLineStroke();
        float float39 = categoryAxis36.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent40 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis36);
        org.jfree.chart.axis.Axis axis41 = axisChangeEvent40.getAxis();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer44 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean45 = statisticalLineAndShapeRenderer44.getBaseItemLabelsVisible();
        int int46 = statisticalLineAndShapeRenderer44.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition48 = null;
        statisticalLineAndShapeRenderer44.setSeriesNegativeItemLabelPosition(0, itemLabelPosition48);
        java.awt.Stroke stroke52 = statisticalLineAndShapeRenderer44.getItemOutlineStroke(4, (int) '4');
        statisticalLineAndShapeRenderer44.setItemLabelAnchorOffset((double) (short) 1);
        java.awt.Stroke stroke55 = statisticalLineAndShapeRenderer44.getBaseOutlineStroke();
        axis41.setTickMarkStroke(stroke55);
        polarPlot30.setAngleGridlineStroke(stroke55);
        boolean boolean58 = statisticalLineAndShapeRenderer18.equals((java.lang.Object) stroke55);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer61 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean62 = statisticalLineAndShapeRenderer61.getBaseItemLabelsVisible();
        int int63 = statisticalLineAndShapeRenderer61.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition65 = null;
        statisticalLineAndShapeRenderer61.setSeriesNegativeItemLabelPosition(0, itemLabelPosition65);
        java.awt.Stroke stroke69 = statisticalLineAndShapeRenderer61.getItemOutlineStroke(4, (int) '4');
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer72 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean73 = statisticalLineAndShapeRenderer72.getBaseItemLabelsVisible();
        int int74 = statisticalLineAndShapeRenderer72.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition76 = null;
        statisticalLineAndShapeRenderer72.setSeriesNegativeItemLabelPosition(0, itemLabelPosition76);
        java.awt.Stroke stroke80 = statisticalLineAndShapeRenderer72.getItemOutlineStroke(4, (int) '4');
        org.jfree.chart.axis.CategoryAxis categoryAxis81 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets82 = categoryAxis81.getLabelInsets();
        boolean boolean83 = categoryAxis81.isAxisLineVisible();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer86 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean87 = statisticalLineAndShapeRenderer86.getBaseItemLabelsVisible();
        int int88 = statisticalLineAndShapeRenderer86.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition90 = null;
        statisticalLineAndShapeRenderer86.setSeriesNegativeItemLabelPosition(0, itemLabelPosition90);
        java.awt.Stroke stroke94 = statisticalLineAndShapeRenderer86.getItemOutlineStroke(4, (int) '4');
        categoryAxis81.setAxisLineStroke(stroke94);
        java.awt.Stroke stroke96 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray97 = new java.awt.Stroke[] { stroke55, stroke69, stroke80, stroke94, stroke96 };
        java.awt.Shape[] shapeArray98 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier99 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray4, paintArray7, paintArray14, strokeArray15, strokeArray97, shapeArray98);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paintArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Polar Plot" + "'", str34.equals("Polar Plot"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 15 + "'", int35 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 0.0f + "'", float39 == 0.0f);
        org.junit.Assert.assertNotNull(axis41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2 + "'", int63 == 2);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 2 + "'", int74 == 2);
        org.junit.Assert.assertNotNull(stroke80);
        org.junit.Assert.assertNotNull(rectangleInsets82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 2 + "'", int88 == 2);
        org.junit.Assert.assertNotNull(stroke94);
        org.junit.Assert.assertNotNull(stroke96);
        org.junit.Assert.assertNotNull(strokeArray97);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset4.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.general.DatasetGroup datasetGroup10 = defaultStatisticalCategoryDataset4.getGroup();
        java.lang.Comparable comparable12 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity13 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "hi!", "", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, (java.lang.Comparable) 1.0d, comparable12);
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint15 = polarPlot14.getOutlinePaint();
        java.awt.Stroke stroke16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot14.setOutlineStroke(stroke16);
        java.lang.String str18 = polarPlot14.getPlotType();
        int int19 = polarPlot14.getBackgroundImageAlignment();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryAxis20.getLabelInsets();
        java.awt.Stroke stroke22 = categoryAxis20.getAxisLineStroke();
        float float23 = categoryAxis20.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent24 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis20);
        org.jfree.chart.axis.Axis axis25 = axisChangeEvent24.getAxis();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer28 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean29 = statisticalLineAndShapeRenderer28.getBaseItemLabelsVisible();
        int int30 = statisticalLineAndShapeRenderer28.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = null;
        statisticalLineAndShapeRenderer28.setSeriesNegativeItemLabelPosition(0, itemLabelPosition32);
        java.awt.Stroke stroke36 = statisticalLineAndShapeRenderer28.getItemOutlineStroke(4, (int) '4');
        statisticalLineAndShapeRenderer28.setItemLabelAnchorOffset((double) (short) 1);
        java.awt.Stroke stroke39 = statisticalLineAndShapeRenderer28.getBaseOutlineStroke();
        axis25.setTickMarkStroke(stroke39);
        polarPlot14.setAngleGridlineStroke(stroke39);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent42 = null;
        polarPlot14.datasetChanged(datasetChangeEvent42);
        boolean boolean44 = defaultStatisticalCategoryDataset4.hasListener((java.util.EventListener) polarPlot14);
        org.jfree.chart.plot.RingPlot ringPlot45 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint46 = null;
        ringPlot45.setShadowPaint(paint46);
        double double48 = ringPlot45.getMaximumLabelWidth();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent49 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot45);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        ringPlot45.setExplodePercent((java.lang.Comparable) 'a', (double) 100);
        polarPlot14.setParent((org.jfree.chart.plot.Plot) ringPlot45);
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) ringPlot45);
        boolean boolean56 = ringPlot45.getIgnoreNullValues();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(datasetGroup10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Polar Plot" + "'", str18.equals("Polar Plot"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.0f + "'", float23 == 0.0f);
        org.junit.Assert.assertNotNull(axis25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.2d + "'", double48 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 1.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(range2, (double) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis5.getLabelInsets();
        double double8 = rectangleInsets6.trimWidth((double) (byte) 10);
        boolean boolean9 = range2.equals((java.lang.Object) rectangleInsets6);
        double double11 = rectangleInsets6.calculateTopInset((double) (byte) -1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.TOP" + "'", str1.equals("RectangleAnchor.TOP"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit(1.0E-5d);
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = dateAxis2.getStandardTickUnits();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis2.setRangeWithMargins((org.jfree.data.Range) dateRange6, false, false);
        dateAxis2.setAutoRange(false);
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        dateAxis2.setInverted(true);
        boolean boolean15 = numberTickUnit1.equals((java.lang.Object) dateAxis2);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.axis.AxisState axisState17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent19 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis18);
        org.jfree.data.time.DateRange dateRange22 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis18.setRange((org.jfree.data.Range) dateRange22);
        java.awt.Font font26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("hi!", font26);
        java.lang.String str28 = textTitle27.getToolTipText();
        textTitle27.setWidth(0.0d);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent31 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle27);
        java.awt.Color color32 = java.awt.Color.cyan;
        boolean boolean33 = textTitle27.equals((java.lang.Object) color32);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = categoryAxis35.getLabelInsets();
        double double38 = rectangleInsets36.trimWidth((double) (byte) 10);
        double double40 = rectangleInsets36.calculateTopInset((-1.0d));
        double double42 = rectangleInsets36.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock44 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str45 = labelBlock44.getToolTipText();
        java.lang.String str46 = labelBlock44.getURLText();
        java.awt.geom.Rectangle2D rectangle2D47 = labelBlock44.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType48 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType49 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str50 = lengthAdjustmentType49.toString();
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets36.createAdjustedRectangle(rectangle2D47, lengthAdjustmentType48, lengthAdjustmentType49);
        java.lang.Object obj52 = null;
        java.lang.Object obj53 = textTitle27.draw(graphics2D34, rectangle2D47, obj52);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = null;
        double double55 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D47, rectangleEdge54);
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double57 = dateAxis18.lengthToJava2D(0.0d, rectangle2D47, rectangleEdge56);
        org.jfree.chart.axis.AxisState axisState58 = new org.jfree.chart.axis.AxisState();
        double double59 = axisState58.getCursor();
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge61);
        axisState58.moveCursor(0.0d, rectangleEdge61);
        try {
            java.util.List list64 = dateAxis2.refreshTicks(graphics2D16, axisState17, rectangle2D47, rectangleEdge61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource3);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 4.0d + "'", double38 == 4.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 3.0d + "'", double40 == 3.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 3.0d + "'", double42 == 3.0d);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(lengthAdjustmentType48);
        org.junit.Assert.assertNotNull(lengthAdjustmentType49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "CONTRACT" + "'", str50.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNull(obj53);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge61);
        org.junit.Assert.assertNotNull(rectangleEdge62);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setStartAngle(0.0d);
        ringPlot0.setIgnoreNullValues(true);
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint6 = polarPlot5.getOutlinePaint();
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot5.setOutlineStroke(stroke7);
        java.lang.String str9 = polarPlot5.getPlotType();
        java.awt.Paint paint10 = polarPlot5.getOutlinePaint();
        java.awt.Paint paint11 = polarPlot5.getBackgroundPaint();
        ringPlot0.setLabelLinkPaint(paint11);
        java.awt.Stroke stroke13 = ringPlot0.getBaseSectionOutlineStroke();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Polar Plot" + "'", str9.equals("Polar Plot"));
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        java.awt.Stroke stroke2 = categoryAxis0.getAxisLineStroke();
        float float3 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        org.jfree.chart.axis.Axis axis5 = axisChangeEvent4.getAxis();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean9 = statisticalLineAndShapeRenderer8.getBaseItemLabelsVisible();
        int int10 = statisticalLineAndShapeRenderer8.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        statisticalLineAndShapeRenderer8.setSeriesNegativeItemLabelPosition(0, itemLabelPosition12);
        java.awt.Stroke stroke16 = statisticalLineAndShapeRenderer8.getItemOutlineStroke(4, (int) '4');
        statisticalLineAndShapeRenderer8.setItemLabelAnchorOffset((double) (short) 1);
        java.awt.Stroke stroke19 = statisticalLineAndShapeRenderer8.getBaseOutlineStroke();
        axis5.setTickMarkStroke(stroke19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double23 = rectangleInsets21.calculateBottomInset((double) (-1.0f));
        org.jfree.chart.util.UnitType unitType24 = rectangleInsets21.getUnitType();
        axis5.setLabelInsets(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(axis5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(unitType24);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean4 = statisticalLineAndShapeRenderer3.getBaseItemLabelsVisible();
        int int5 = statisticalLineAndShapeRenderer3.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        statisticalLineAndShapeRenderer3.setSeriesNegativeItemLabelPosition(0, itemLabelPosition7);
        java.awt.Stroke stroke11 = statisticalLineAndShapeRenderer3.getItemOutlineStroke(4, (int) '4');
        boolean boolean12 = waterfallBarRenderer0.equals((java.lang.Object) statisticalLineAndShapeRenderer3);
        boolean boolean15 = statisticalLineAndShapeRenderer3.isItemLabelVisible((int) (byte) -1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone0;
        org.junit.Assert.assertNotNull(timeZone0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        int int1 = stackedBarRenderer0.getPassCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.POSITIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (short) 100, (double) 4);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint14 = statisticalLineAndShapeRenderer8.getItemOutlinePaint((-1), 0);
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape5, paint14);
        java.awt.Paint paint16 = legendGraphic15.getOutlinePaint();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(paint16);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = barRenderer2.getPlot();
        barRenderer2.setMinimumBarLength(0.05d);
        boolean boolean6 = stackedAreaRenderer1.equals((java.lang.Object) barRenderer2);
        org.junit.Assert.assertNull(categoryPlot3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getOutlinePaint();
        java.awt.Stroke stroke2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot0.setOutlineStroke(stroke2);
        java.lang.String str4 = polarPlot0.getPlotType();
        java.awt.Paint paint5 = polarPlot0.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        boolean boolean9 = xYPlot6.isRangeZeroBaselineVisible();
        java.awt.Paint paint10 = xYPlot6.getRangeZeroBaselinePaint();
        java.awt.Stroke stroke11 = xYPlot6.getRangeZeroBaselineStroke();
        polarPlot0.setAngleGridlineStroke(stroke11);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Polar Plot" + "'", str4.equals("Polar Plot"));
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getOutlinePaint();
        java.awt.Stroke stroke2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot0.setOutlineStroke(stroke2);
        java.lang.String str4 = polarPlot0.getPlotType();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        polarPlot0.datasetChanged(datasetChangeEvent5);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Polar Plot" + "'", str4.equals("Polar Plot"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getOutlinePaint();
        java.awt.Stroke stroke2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot0.setOutlineStroke(stroke2);
        java.lang.String str4 = polarPlot0.getPlotType();
        int int5 = polarPlot0.getBackgroundImageAlignment();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis6.getLabelInsets();
        java.awt.Stroke stroke8 = categoryAxis6.getAxisLineStroke();
        float float9 = categoryAxis6.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis6);
        org.jfree.chart.axis.Axis axis11 = axisChangeEvent10.getAxis();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer14 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean15 = statisticalLineAndShapeRenderer14.getBaseItemLabelsVisible();
        int int16 = statisticalLineAndShapeRenderer14.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        statisticalLineAndShapeRenderer14.setSeriesNegativeItemLabelPosition(0, itemLabelPosition18);
        java.awt.Stroke stroke22 = statisticalLineAndShapeRenderer14.getItemOutlineStroke(4, (int) '4');
        statisticalLineAndShapeRenderer14.setItemLabelAnchorOffset((double) (short) 1);
        java.awt.Stroke stroke25 = statisticalLineAndShapeRenderer14.getBaseOutlineStroke();
        axis11.setTickMarkStroke(stroke25);
        polarPlot0.setAngleGridlineStroke(stroke25);
        polarPlot0.addCornerTextItem("ClassContext");
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Polar Plot" + "'", str4.equals("Polar Plot"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertNotNull(axis11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = xYPlot0.getDomainMarkers(7, layer5);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(collection6);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint(paint0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        statisticalLineAndShapeRenderer2.setSeriesShapesFilled(0, (java.lang.Boolean) false);
        statisticalLineAndShapeRenderer2.setSeriesShapesFilled(0, (java.lang.Boolean) false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelLinkPaint();
        double double2 = ringPlot0.getMaximumLabelWidth();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) 1.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint(range3, (double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, range3);
        org.jfree.data.Range range9 = org.jfree.data.Range.expand(range3, (double) 6, (double) 8);
        double double10 = range9.getCentralValue();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.TRUNCATE;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean2 = areaRendererEndType0.equals((java.lang.Object) polarPlot1);
        try {
            polarPlot1.setBackgroundImageAlpha((float) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(areaRendererEndType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        java.awt.Font font5 = statisticalLineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, rectangleAnchor8, (double) (short) 100, (double) 4);
        statisticalLineAndShapeRenderer2.setBaseShape(shape11, false);
        boolean boolean14 = statisticalLineAndShapeRenderer2.getUseFillPaint();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset15 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset15.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.general.DatasetGroup datasetGroup21 = defaultStatisticalCategoryDataset15.getGroup();
        java.lang.String str22 = datasetGroup21.getID();
        boolean boolean23 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) str22);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint26 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        categoryAxis25.setTickMarkPaint(paint26);
        java.lang.String str28 = categoryAxis25.getLabel();
        java.awt.Paint paint29 = categoryAxis25.getTickMarkPaint();
        statisticalLineAndShapeRenderer2.setSeriesPaint((int) (short) 1, paint29);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(datasetGroup21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "NOID" + "'", str22.equals("NOID"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D2 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int3 = defaultKeyedValues2D2.getRowCount();
        java.util.List list4 = defaultKeyedValues2D2.getColumnKeys();
        boolean boolean5 = waterfallBarRenderer0.equals((java.lang.Object) list4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint7 = polarPlot6.getOutlinePaint();
        java.awt.Stroke stroke8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot6.setOutlineStroke(stroke8);
        java.lang.String str10 = polarPlot6.getPlotType();
        int int11 = polarPlot6.getBackgroundImageAlignment();
        boolean boolean12 = waterfallBarRenderer0.equals((java.lang.Object) polarPlot6);
        waterfallBarRenderer0.setItemMargin(Double.NaN);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Polar Plot" + "'", str10.equals("Polar Plot"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("({0}, {1}) = {2}", font1, (java.awt.Paint) color2, (float) 2958465);
        java.awt.Image image8 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo12 = new org.jfree.chart.ui.ProjectInfo("Range[1.0,1.0]", "NOID", "DateTickUnit[DAY, 1]", image8, "({0}, {1}) = {2}", "Range[1.0,1.0]", "");
        boolean boolean13 = textFragment4.equals((java.lang.Object) "Range[1.0,1.0]");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint1 = waterfallBarRenderer0.getLastBarPaint();
        boolean boolean2 = waterfallBarRenderer0.getAutoPopulateSeriesFillPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Comparable comparable2 = null;
        int int3 = defaultStatisticalCategoryDataset1.getRowIndex(comparable2);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer5 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, (org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset1, (java.lang.Comparable) 100L);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis7.getLabelInsets();
        double double10 = rectangleInsets8.trimWidth((double) (byte) 10);
        double double12 = rectangleInsets8.calculateTopInset((-1.0d));
        double double14 = rectangleInsets8.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str17 = labelBlock16.getToolTipText();
        java.lang.String str18 = labelBlock16.getURLText();
        java.awt.geom.Rectangle2D rectangle2D19 = labelBlock16.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType20 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType21 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str22 = lengthAdjustmentType21.toString();
        java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets8.createAdjustedRectangle(rectangle2D19, lengthAdjustmentType20, lengthAdjustmentType21);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = categoryAxis24.getLabelInsets();
        java.awt.Stroke stroke26 = categoryAxis24.getAxisLineStroke();
        float float27 = categoryAxis24.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent28 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis24);
        try {
            java.lang.Object obj29 = legendItemBlockContainer5.draw(graphics2D6, rectangle2D19, (java.lang.Object) categoryAxis24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.0d + "'", double14 == 3.0d);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(lengthAdjustmentType20);
        org.junit.Assert.assertNotNull(lengthAdjustmentType21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "CONTRACT" + "'", str22.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.0f + "'", float27 == 0.0f);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        boolean boolean2 = categoryAxis0.isAxisLineVisible();
        java.awt.Paint paint4 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 100);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        double double2 = stackedBarRenderer3D1.getUpperClip();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str7 = labelBlock6.getToolTipText();
        java.lang.String str8 = labelBlock6.getURLText();
        java.awt.geom.Rectangle2D rectangle2D9 = labelBlock6.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D9, "Polar Plot", "LengthConstraintType.NONE");
        try {
            stackedBarRenderer3D1.drawBackground(graphics2D3, categoryPlot4, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(rectangle2D9);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint5 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        categoryAxis4.setTickMarkPaint(paint5);
        java.lang.String str7 = categoryAxis4.getLabel();
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryAxis4.setLabelPaint(paint8);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity14 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis4, shape11, "({0}, {1}) = {2}", "({0}, {1}) = {2}");
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape11);
        java.lang.String str16 = chartEntity15.getToolTipText();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape18, rectangleAnchor19, (double) (short) 100, (double) 4);
        chartEntity15.setArea(shape18);
        java.awt.Stroke stroke24 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.image.ColorModel colorModel26 = null;
        java.awt.Rectangle rectangle27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.awt.geom.AffineTransform affineTransform29 = null;
        java.awt.RenderingHints renderingHints30 = null;
        java.awt.PaintContext paintContext31 = color25.createContext(colorModel26, rectangle27, rectangle2D28, affineTransform29, renderingHints30);
        try {
            org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem(attributedString0, "", "", "LengthConstraintType.NONE", shape18, stroke24, (java.awt.Paint) color25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paintContext31);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getRowCount();
        defaultKeyedValues2D1.removeColumn((java.lang.Comparable) 9.223372036854776E18d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        polarPlot1.markerChanged(markerChangeEvent2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        polarPlot1.drawBackgroundImage(graphics2D4, rectangle2D5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        polarPlot1.drawBackgroundImage(graphics2D7, rectangle2D8);
        boolean boolean10 = color0.equals((java.lang.Object) polarPlot1);
        java.awt.color.ColorSpace colorSpace11 = null;
        java.awt.Color color12 = java.awt.Color.BLUE;
        java.awt.Color color13 = java.awt.Color.black;
        float[] floatArray19 = new float[] { 1, (short) 10, (short) 10, (short) -1, (-1) };
        float[] floatArray20 = color13.getRGBComponents(floatArray19);
        float[] floatArray21 = color12.getRGBColorComponents(floatArray19);
        try {
            float[] floatArray22 = color0.getColorComponents(colorSpace11, floatArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorLeft((double) (byte) 1);
        axisState0.cursorUp(103.0d);
        double double5 = axisState0.getMax();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        jFreeChart4.setTitle("hi!");
        java.lang.Object obj7 = jFreeChart4.getTextAntiAlias();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font9);
        java.lang.String str11 = textTitle10.getToolTipText();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("hi!", font13);
        java.lang.String str15 = textTitle14.getToolTipText();
        textTitle14.setWidth(0.0d);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent18 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle14);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle14.getVerticalAlignment();
        textTitle10.setVerticalAlignment(verticalAlignment19);
        jFreeChart4.setTitle(textTitle10);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer24 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean25 = statisticalLineAndShapeRenderer24.getBaseItemLabelsVisible();
        int int26 = statisticalLineAndShapeRenderer24.getPassCount();
        java.awt.Font font27 = statisticalLineAndShapeRenderer24.getBaseItemLabelFont();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape29, rectangleAnchor30, (double) (short) 100, (double) 4);
        statisticalLineAndShapeRenderer24.setBaseShape(shape33, false);
        boolean boolean36 = statisticalLineAndShapeRenderer24.getUseFillPaint();
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalLineAndShapeRenderer24);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke39 = categoryAxis38.getTickMarkStroke();
        boolean boolean40 = legendTitle37.equals((java.lang.Object) stroke39);
        jFreeChart4.addLegend(legendTitle37);
        org.jfree.data.Range range42 = null;
        org.jfree.data.Range range44 = org.jfree.data.Range.expandToInclude(range42, (double) 1.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint46 = new org.jfree.chart.block.RectangleConstraint(range44, (double) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = categoryAxis47.getLabelInsets();
        double double50 = rectangleInsets48.trimWidth((double) (byte) 10);
        boolean boolean51 = range44.equals((java.lang.Object) rectangleInsets48);
        double double53 = rectangleInsets48.calculateBottomInset((double) (-329600));
        double double54 = rectangleInsets48.getBottom();
        legendTitle37.setLegendItemGraphicPadding(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 4.0d + "'", double50 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 3.0d + "'", double53 == 3.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 3.0d + "'", double54 == 3.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.0d, (double) 1.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.geom.Rectangle2D rectangle2D6 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D2, (double) 100L, (double) 0L, rectangleAnchor5);
        size2D2.width = '4';
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangle2D6);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint8 = statisticalLineAndShapeRenderer2.getItemOutlinePaint((-1), 0);
        boolean boolean10 = statisticalLineAndShapeRenderer2.isSeriesItemLabelsVisible(0);
        statisticalLineAndShapeRenderer2.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color18 = java.awt.Color.getColor("Range[1.0,1.0]", 9999);
        statisticalLineAndShapeRenderer2.setSeriesFillPaint(3, (java.awt.Paint) color18, false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        polarPlot0.drawBackgroundImage(graphics2D4, rectangle2D5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        try {
            polarPlot0.zoomRangeAxes((double) (-1L), (double) 0, plotRenderingInfo9, point2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer5.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint9 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        statisticalLineAndShapeRenderer5.setBasePaint(paint9);
        textTitle2.setBackgroundPaint(paint9);
        boolean boolean12 = textTitle2.getExpandToFitSpace();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = textTitle2.getHorizontalAlignment();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        polarPlot0.zoomDomainAxes((double) 10, plotRenderingInfo5, point2D6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        polarPlot0.drawBackgroundImage(graphics2D8, rectangle2D9);
        polarPlot0.setOutlineVisible(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) flowArrangement0);
        java.lang.Object obj2 = rendererChangeEvent1.getRenderer();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        categoryAxis0.setTickMarkPaint(paint1);
        java.lang.String str3 = categoryAxis0.getLabel();
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryAxis0.setLabelPaint(paint4);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity10 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis0, shape7, "({0}, {1}) = {2}", "({0}, {1}) = {2}");
        org.jfree.chart.axis.Axis axis11 = axisLabelEntity10.getAxis();
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str14 = labelBlock13.getToolTipText();
        java.lang.String str15 = labelBlock13.getURLText();
        java.awt.geom.Rectangle2D rectangle2D16 = labelBlock13.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16, "Polar Plot", "LengthConstraintType.NONE");
        axisLabelEntity10.setArea((java.awt.Shape) rectangle2D16);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNull(axis11);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(rectangle2D16);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        java.awt.Paint paint5 = jFreeChart4.getBorderPaint();
        java.lang.Object obj6 = jFreeChart4.getTextAntiAlias();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str10 = labelBlock9.getToolTipText();
        java.lang.String str11 = labelBlock9.getURLText();
        java.awt.geom.Rectangle2D rectangle2D12 = labelBlock9.getBounds();
        org.jfree.chart.entity.EntityCollection entityCollection13 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo(entityCollection13);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryAxis15.getLabelInsets();
        double double18 = rectangleInsets16.trimWidth((double) (byte) 10);
        double double20 = rectangleInsets16.calculateTopInset((-1.0d));
        double double22 = rectangleInsets16.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str25 = labelBlock24.getToolTipText();
        java.lang.String str26 = labelBlock24.getURLText();
        java.awt.geom.Rectangle2D rectangle2D27 = labelBlock24.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType28 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType29 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str30 = lengthAdjustmentType29.toString();
        java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets16.createAdjustedRectangle(rectangle2D27, lengthAdjustmentType28, lengthAdjustmentType29);
        chartRenderingInfo14.setChartArea(rectangle2D27);
        try {
            jFreeChart4.draw(graphics2D7, rectangle2D12, chartRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 3.0d + "'", double20 == 3.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 3.0d + "'", double22 == 3.0d);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(lengthAdjustmentType28);
        org.junit.Assert.assertNotNull(lengthAdjustmentType29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "CONTRACT" + "'", str30.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D31);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (short) 100, (double) 4);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint14 = statisticalLineAndShapeRenderer8.getItemOutlinePaint((-1), 0);
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape5, paint14);
        boolean boolean16 = legendGraphic15.isLineVisible();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int1 = taskSeriesCollection0.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries3 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection0.add(taskSeries3);
        org.jfree.data.gantt.TaskSeries taskSeries6 = taskSeriesCollection0.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, (java.lang.Comparable) "CONTRACT");
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        piePlot3D9.setDepthFactor(12.0d);
        piePlot3D9.setLabelGap(Double.NaN);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(taskSeries6);
        org.junit.Assert.assertNotNull(pieDataset8);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        double double3 = rectangleInsets1.trimWidth((double) (byte) 10);
        double double5 = rectangleInsets1.calculateTopInset((-1.0d));
        double double7 = rectangleInsets1.calculateTopInset((double) 0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.lang.String str3 = textTitle2.getToolTipText();
        textTitle2.setWidth(0.0d);
        java.awt.Font font6 = textTitle2.getFont();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.data.Range range9 = null;
        org.jfree.data.Range range11 = org.jfree.data.Range.expandToInclude(range9, (double) 1.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint(range11, (double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, range11);
        org.jfree.data.Range range15 = rectangleConstraint14.getWidthRange();
        org.jfree.data.Range range16 = null;
        org.jfree.data.Range range18 = org.jfree.data.Range.expandToInclude(range16, (double) 1.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint(range18, (double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = rectangleConstraint14.toRangeHeight(range18);
        org.jfree.data.Range range22 = rectangleConstraint14.getWidthRange();
        try {
            org.jfree.chart.util.Size2D size2D23 = textTitle2.arrange(graphics2D7, rectangleConstraint14);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(rectangleConstraint21);
        org.junit.Assert.assertNull(range22);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYPlot0.setRangeCrosshairStroke(stroke3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot0.getDataset();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke9 = polarPlot8.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', (java.awt.Paint) color7, stroke9);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection11 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int12 = taskSeriesCollection11.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries14 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection11.add(taskSeries14);
        org.jfree.data.gantt.TaskSeries taskSeries17 = taskSeriesCollection11.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection11, (java.lang.Comparable) "CONTRACT");
        boolean boolean20 = categoryMarker10.equals((java.lang.Object) taskSeriesCollection11);
        java.awt.Color color21 = java.awt.Color.GREEN;
        categoryMarker10.setPaint((java.awt.Paint) color21);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10);
        int int24 = xYPlot0.getDatasetCount();
        int int25 = xYPlot0.getRangeAxisCount();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(taskSeries17);
        org.junit.Assert.assertNotNull(pieDataset19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) 1.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint(range3, (double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, range3);
        org.jfree.data.Range range7 = rectangleConstraint6.getWidthRange();
        org.jfree.data.Range range8 = rectangleConstraint6.getWidthRange();
        org.jfree.chart.util.Size2D size2D11 = new org.jfree.chart.util.Size2D((double) (short) 1, (double) 9999);
        double double12 = size2D11.getHeight();
        org.jfree.chart.util.Size2D size2D13 = rectangleConstraint6.calculateConstrainedSize(size2D11);
        size2D11.height = 9999;
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 9999.0d + "'", double12 == 9999.0d);
        org.junit.Assert.assertNotNull(size2D13);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint8 = statisticalLineAndShapeRenderer2.getItemOutlinePaint((-1), 0);
        boolean boolean10 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) 2958465);
        java.awt.Color color12 = java.awt.Color.BLUE;
        statisticalLineAndShapeRenderer2.setSeriesOutlinePaint(4, (java.awt.Paint) color12);
        int int14 = color12.getTransparency();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        textBlock1.draw(graphics2D2, (float) (byte) 100, (float) (byte) 1, textBlockAnchor5, (float) 7, (float) '4', (double) (short) 100);
        java.util.List list10 = textBlock1.getLines();
        org.jfree.chart.text.TextBlock textBlock11 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        textBlock11.draw(graphics2D12, (float) (byte) 100, (float) (byte) 1, textBlockAnchor15, (float) 7, (float) '4', (double) (short) 100);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.axis.CategoryTick categoryTick22 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 900000L, textBlock1, textBlockAnchor15, textAnchor20, (double) (-329600));
        java.lang.String str23 = categoryTick22.toString();
        java.lang.Object obj24 = categoryTick22.clone();
        java.lang.Object obj25 = categoryTick22.clone();
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(textBlockAnchor15);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.junit.Assert.assertNotNull(rectangleConstraint0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.lang.Object obj1 = blockContainer0.clone();
        double double2 = blockContainer0.getWidth();
        blockContainer0.setHeight((double) 1.0f);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis5.getLabelInsets();
        java.awt.Stroke stroke7 = categoryAxis5.getAxisLineStroke();
        float float8 = categoryAxis5.getMaximumCategoryLabelWidthRatio();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke12 = polarPlot11.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', (java.awt.Paint) color10, stroke12);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection14 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int15 = taskSeriesCollection14.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries17 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection14.add(taskSeries17);
        org.jfree.data.gantt.TaskSeries taskSeries20 = taskSeriesCollection14.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset22 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection14, (java.lang.Comparable) "CONTRACT");
        boolean boolean23 = categoryMarker13.equals((java.lang.Object) taskSeriesCollection14);
        java.awt.Color color24 = java.awt.Color.GREEN;
        categoryMarker13.setPaint((java.awt.Paint) color24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryAxis27.getLabelInsets();
        double double30 = rectangleInsets28.trimWidth((double) (byte) 10);
        double double32 = rectangleInsets28.calculateTopInset((-1.0d));
        double double34 = rectangleInsets28.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock36 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str37 = labelBlock36.getToolTipText();
        java.lang.String str38 = labelBlock36.getURLText();
        java.awt.geom.Rectangle2D rectangle2D39 = labelBlock36.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType40 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType41 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str42 = lengthAdjustmentType41.toString();
        java.awt.geom.Rectangle2D rectangle2D43 = rectangleInsets28.createAdjustedRectangle(rectangle2D39, lengthAdjustmentType40, lengthAdjustmentType41);
        org.jfree.chart.block.LabelBlock labelBlock45 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str46 = labelBlock45.getToolTipText();
        java.lang.String str47 = labelBlock45.getURLText();
        java.awt.geom.Rectangle2D rectangle2D48 = labelBlock45.getBounds();
        java.awt.geom.Rectangle2D rectangle2D49 = axisSpace26.shrink(rectangle2D43, rectangle2D48);
        try {
            statisticalLineAndShapeRenderer2.drawDomainMarker(graphics2D3, categoryPlot4, categoryAxis5, categoryMarker13, rectangle2D48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(taskSeries20);
        org.junit.Assert.assertNotNull(pieDataset22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 4.0d + "'", double30 == 4.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.0d + "'", double32 == 3.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 3.0d + "'", double34 == 3.0d);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(lengthAdjustmentType40);
        org.junit.Assert.assertNotNull(lengthAdjustmentType41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "CONTRACT" + "'", str42.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangle2D49);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        java.awt.Font font5 = statisticalLineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, rectangleAnchor8, (double) (short) 100, (double) 4);
        statisticalLineAndShapeRenderer2.setBaseShape(shape11, false);
        boolean boolean14 = statisticalLineAndShapeRenderer2.getUseFillPaint();
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalLineAndShapeRenderer2);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke17 = categoryAxis16.getTickMarkStroke();
        boolean boolean18 = legendTitle15.equals((java.lang.Object) stroke17);
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean20 = polarPlot19.isOutlineVisible();
        polarPlot19.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot19);
        jFreeChart23.setTitle("hi!");
        java.lang.Object obj26 = jFreeChart23.getTextAntiAlias();
        org.jfree.chart.title.TextTitle textTitle27 = jFreeChart23.getTitle();
        legendTitle15.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart23);
        java.awt.Paint paint29 = jFreeChart23.getBackgroundPaint();
        org.jfree.chart.entity.EntityCollection entityCollection33 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = new org.jfree.chart.ChartRenderingInfo(entityCollection33);
        try {
            java.awt.image.BufferedImage bufferedImage35 = jFreeChart23.createBufferedImage(2958465, 1, 128, chartRenderingInfo34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 128");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertNotNull(textTitle27);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.awt.Image image7 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo11 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image7, "", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray12 = projectInfo11.getLibraries();
        boolean boolean13 = textAnchor3.equals((java.lang.Object) projectInfo11);
        org.jfree.chart.axis.NumberTick numberTick15 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 1.0E-5d, "CONTRACT", textAnchor2, textAnchor3, 0.4d);
        java.lang.Number number16 = numberTick15.getNumber();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(libraryArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 1.0E-5d + "'", number16.equals(1.0E-5d));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.FlowArrangement flowArrangement1 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement1);
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement1);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        boolean boolean5 = xYPlot0.isRangeZeroBaselineVisible();
        boolean boolean6 = xYPlot0.isDomainCrosshairVisible();
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke10 = polarPlot9.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', (java.awt.Paint) color8, stroke10);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection12 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int13 = taskSeriesCollection12.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries15 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection12.add(taskSeries15);
        org.jfree.data.gantt.TaskSeries taskSeries18 = taskSeriesCollection12.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset20 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection12, (java.lang.Comparable) "CONTRACT");
        boolean boolean21 = categoryMarker11.equals((java.lang.Object) taskSeriesCollection12);
        java.awt.Color color22 = java.awt.Color.GREEN;
        categoryMarker11.setPaint((java.awt.Paint) color22);
        org.jfree.chart.util.Layer layer24 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer24);
        org.jfree.chart.text.TextAnchor textAnchor26 = categoryMarker11.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(taskSeries18);
        org.junit.Assert.assertNotNull(pieDataset20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(textAnchor26);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.lang.String str3 = textTitle2.getToolTipText();
        java.lang.String str4 = textTitle2.getText();
        textTitle2.setText("Polar Plot");
        java.lang.String str7 = textTitle2.getID();
        java.lang.Object obj8 = textTitle2.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getOutlinePaint();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        polarPlot0.setDataset(xYDataset2);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str1 = layer0.toString();
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Layer.BACKGROUND" + "'", str1.equals("Layer.BACKGROUND"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int1 = taskSeriesCollection0.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries3 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection0.add(taskSeries3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        taskSeries3.addPropertyChangeListener(propertyChangeListener5);
        java.lang.Object obj7 = taskSeries3.clone();
        taskSeries3.removeAll();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str5 = spreadsheetDate4.getDescription();
        int int6 = spreadsheetDate4.getDayOfWeek();
        boolean boolean7 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str10 = spreadsheetDate9.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str13 = spreadsheetDate12.getDescription();
        int int14 = spreadsheetDate12.getDayOfWeek();
        boolean boolean15 = spreadsheetDate9.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(8);
        boolean boolean19 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, (org.jfree.data.time.SerialDate) spreadsheetDate17, 10);
        org.jfree.data.time.SerialDate serialDate21 = spreadsheetDate17.getPreviousDayOfWeek(7);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset22 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset22.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str31 = spreadsheetDate30.getDescription();
        int int32 = spreadsheetDate30.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str35 = spreadsheetDate34.getDescription();
        org.jfree.data.time.SerialDate serialDate36 = spreadsheetDate30.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate34);
        java.lang.Number number37 = defaultStatisticalCategoryDataset22.getValue((java.lang.Comparable) (-1.0f), (java.lang.Comparable) serialDate36);
        boolean boolean38 = spreadsheetDate17.isOnOrAfter(serialDate36);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNull(number37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        jFreeChart4.setTitle("hi!");
        java.lang.Object obj7 = jFreeChart4.getTextAntiAlias();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font9);
        java.lang.String str11 = textTitle10.getToolTipText();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("hi!", font13);
        java.lang.String str15 = textTitle14.getToolTipText();
        textTitle14.setWidth(0.0d);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent18 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle14);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle14.getVerticalAlignment();
        textTitle10.setVerticalAlignment(verticalAlignment19);
        jFreeChart4.setTitle(textTitle10);
        jFreeChart4.setNotify(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(verticalAlignment19);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisSpace axisSpace4 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis5.getLabelInsets();
        double double8 = rectangleInsets6.trimWidth((double) (byte) 10);
        double double10 = rectangleInsets6.calculateTopInset((-1.0d));
        double double12 = rectangleInsets6.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str15 = labelBlock14.getToolTipText();
        java.lang.String str16 = labelBlock14.getURLText();
        java.awt.geom.Rectangle2D rectangle2D17 = labelBlock14.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType18 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType19 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str20 = lengthAdjustmentType19.toString();
        java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets6.createAdjustedRectangle(rectangle2D17, lengthAdjustmentType18, lengthAdjustmentType19);
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str24 = labelBlock23.getToolTipText();
        java.lang.String str25 = labelBlock23.getURLText();
        java.awt.geom.Rectangle2D rectangle2D26 = labelBlock23.getBounds();
        java.awt.geom.Rectangle2D rectangle2D27 = axisSpace4.shrink(rectangle2D21, rectangle2D26);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = categoryAxis28.getLabelInsets();
        double double31 = rectangleInsets29.trimWidth((double) (byte) 10);
        double double33 = rectangleInsets29.calculateTopInset((-1.0d));
        double double35 = rectangleInsets29.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock37 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str38 = labelBlock37.getToolTipText();
        java.lang.String str39 = labelBlock37.getURLText();
        java.awt.geom.Rectangle2D rectangle2D40 = labelBlock37.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType41 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType42 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str43 = lengthAdjustmentType42.toString();
        java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets29.createAdjustedRectangle(rectangle2D40, lengthAdjustmentType41, lengthAdjustmentType42);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        try {
            org.jfree.chart.axis.AxisState axisState47 = categoryAxis0.draw(graphics2D2, 12.0d, rectangle2D27, rectangle2D44, rectangleEdge45, plotRenderingInfo46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(lengthAdjustmentType18);
        org.junit.Assert.assertNotNull(lengthAdjustmentType19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "CONTRACT" + "'", str20.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 4.0d + "'", double31 == 4.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 3.0d + "'", double33 == 3.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 3.0d + "'", double35 == 3.0d);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(lengthAdjustmentType41);
        org.junit.Assert.assertNotNull(lengthAdjustmentType42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "CONTRACT" + "'", str43.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangleEdge45);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        polarPlot1.markerChanged(markerChangeEvent2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        polarPlot1.drawBackgroundImage(graphics2D4, rectangle2D5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        polarPlot1.drawBackgroundImage(graphics2D7, rectangle2D8);
        boolean boolean10 = color0.equals((java.lang.Object) polarPlot1);
        polarPlot1.setBackgroundAlpha((float) 1L);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.HORIZONTAL" + "'", str1.equals("GradientPaintTransformType.HORIZONTAL"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color2 = java.awt.Color.black;
        float[] floatArray8 = new float[] { 1, (short) 10, (short) 10, (short) -1, (-1) };
        float[] floatArray9 = color2.getRGBComponents(floatArray8);
        float[] floatArray10 = color1.getColorComponents(floatArray8);
        float[] floatArray11 = color0.getComponents(floatArray8);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        java.lang.Object obj5 = null;
        boolean boolean6 = xYPlot0.equals(obj5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomDomainAxes((double) 0L, plotRenderingInfo8, point2D9);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getRangeAxisForDataset((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 'index' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (double) 35L, 0.0f, (float) (byte) 10);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis3.getLabelInsets();
        double double6 = rectangleInsets4.trimWidth((double) (byte) 10);
        double double8 = rectangleInsets4.calculateTopInset((-1.0d));
        double double10 = rectangleInsets4.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str13 = labelBlock12.getToolTipText();
        java.lang.String str14 = labelBlock12.getURLText();
        java.awt.geom.Rectangle2D rectangle2D15 = labelBlock12.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType17 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str18 = lengthAdjustmentType17.toString();
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets4.createAdjustedRectangle(rectangle2D15, lengthAdjustmentType16, lengthAdjustmentType17);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer22 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer22.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint28 = statisticalLineAndShapeRenderer22.getItemOutlinePaint((-1), 0);
        boolean boolean30 = statisticalLineAndShapeRenderer22.equals((java.lang.Object) 2958465);
        java.awt.Color color32 = java.awt.Color.BLUE;
        statisticalLineAndShapeRenderer22.setSeriesOutlinePaint(4, (java.awt.Paint) color32);
        try {
            java.lang.Object obj34 = blockContainer1.draw(graphics2D2, rectangle2D15, (java.lang.Object) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(lengthAdjustmentType16);
        org.junit.Assert.assertNotNull(lengthAdjustmentType17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "CONTRACT" + "'", str18.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.text.DateFormat dateFormat1 = standardCategoryToolTipGenerator0.getDateFormat();
        java.lang.String str2 = standardCategoryToolTipGenerator0.getLabelFormat();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection3 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int4 = taskSeriesCollection3.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries6 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection3.add(taskSeries6);
        org.jfree.data.gantt.TaskSeries taskSeries9 = taskSeriesCollection3.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset11 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection3, (java.lang.Comparable) "CONTRACT");
        try {
            java.lang.String str14 = standardCategoryToolTipGenerator0.generateToolTip((org.jfree.data.category.CategoryDataset) taskSeriesCollection3, 0, 500);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 500, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "({0}, {1}) = {2}" + "'", str2.equals("({0}, {1}) = {2}"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(taskSeries9);
        org.junit.Assert.assertNotNull(pieDataset11);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        int int0 = org.jfree.chart.axis.DateTickUnit.YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        double double1 = lineRenderer3D0.getXOffset();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        org.jfree.chart.entity.EntityCollection entityCollection4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo(entityCollection4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis6.getLabelInsets();
        double double9 = rectangleInsets7.trimWidth((double) (byte) 10);
        double double11 = rectangleInsets7.calculateTopInset((-1.0d));
        double double13 = rectangleInsets7.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str16 = labelBlock15.getToolTipText();
        java.lang.String str17 = labelBlock15.getURLText();
        java.awt.geom.Rectangle2D rectangle2D18 = labelBlock15.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType19 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType20 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str21 = lengthAdjustmentType20.toString();
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets7.createAdjustedRectangle(rectangle2D18, lengthAdjustmentType19, lengthAdjustmentType20);
        chartRenderingInfo5.setChartArea(rectangle2D18);
        try {
            lineRenderer3D0.drawOutline(graphics2D2, categoryPlot3, rectangle2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.0d + "'", double1 == 12.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.0d + "'", double13 == 3.0d);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(lengthAdjustmentType19);
        org.junit.Assert.assertNotNull(lengthAdjustmentType20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "CONTRACT" + "'", str21.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D22);
    }
}

