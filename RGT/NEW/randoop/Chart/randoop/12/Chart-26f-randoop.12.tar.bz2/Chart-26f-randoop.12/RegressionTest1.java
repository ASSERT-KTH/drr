import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.Range range2 = new org.jfree.data.Range(0.05d, 10.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint1 = waterfallBarRenderer0.getLastBarPaint();
        java.awt.Color color2 = java.awt.Color.black;
        waterfallBarRenderer0.setPositiveBarPaint((java.awt.Paint) color2);
        double double4 = waterfallBarRenderer0.getLowerClip();
        waterfallBarRenderer0.setSeriesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (short) 100, (double) 4);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint14 = statisticalLineAndShapeRenderer8.getItemOutlinePaint((-1), 0);
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape5, paint14);
        java.awt.Paint paint16 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        legendGraphic15.setLinePaint(paint16);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[] numberArray7 = new java.lang.Number[] {};
        java.lang.Number[] numberArray8 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray9 = new java.lang.Number[][] { numberArray4, numberArray5, numberArray6, numberArray7, numberArray8 };
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("DateTickUnit[DAY, 1]", "LengthConstraintType.NONE", numberArray9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("GradientPaintTransformType.HORIZONTAL", "Range[1.0,1.0]", numberArray9);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(categoryDataset11);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getUpperMargin();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range2, false, true);
        org.jfree.data.Range range8 = org.jfree.data.Range.shift(range2, (double) (byte) 10, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        statisticalLineAndShapeRenderer2.setSeriesShapesFilled(0, (java.lang.Boolean) false);
        statisticalLineAndShapeRenderer2.setSeriesShapesVisible((int) (byte) 100, true);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 900000L);
        try {
            statisticalLineAndShapeRenderer2.setSeriesShape((-1), shape13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        java.awt.Stroke stroke10 = statisticalLineAndShapeRenderer2.getItemOutlineStroke(4, (int) '4');
        boolean boolean11 = statisticalLineAndShapeRenderer2.getAutoPopulateSeriesOutlinePaint();
        java.lang.Boolean boolean13 = statisticalLineAndShapeRenderer2.getSeriesLinesVisible(0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(boolean13);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.add((double) 10L, (double) 9, (java.lang.Comparable) (-1L), (java.lang.Comparable) 1.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = xYPlot0.getDrawingSupplier();
        boolean boolean4 = xYPlot0.isRangeZeroBaselineVisible();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(drawingSupplier3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list2 = defaultKeyedValues2D1.getRowKeys();
        defaultKeyedValues2D1.clear();
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis0);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis0.getTickMarkPosition();
        double double3 = dateAxis0.getLabelAngle();
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.awt.Image image4 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image4, "", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray9 = projectInfo8.getLibraries();
        boolean boolean10 = textAnchor0.equals((java.lang.Object) projectInfo8);
        projectInfo8.addOptionalLibrary("Tuesday");
        java.lang.String str13 = projectInfo8.getLicenceText();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(libraryArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = barRenderer0.getPlot();
        double double2 = barRenderer0.getMaximumBarWidth();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = barRenderer0.getPositiveItemLabelPositionFallback();
        barRenderer0.setSeriesVisibleInLegend(9, (java.lang.Boolean) false);
        org.junit.Assert.assertNull(categoryPlot1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNull(itemLabelPosition3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image3, "", "hi!", "");
        java.awt.Image image8 = projectInfo7.getLogo();
        projectInfo7.setName("");
        org.junit.Assert.assertNull(image8);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        double double3 = ringPlot0.getMaximumLabelWidth();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        java.awt.Paint paint5 = ringPlot0.getLabelLinkPaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        double double1 = lineRenderer3D0.getYOffset();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        java.awt.Image image4 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image4, "", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray9 = projectInfo8.getLibraries();
        java.lang.String str10 = projectInfo8.getName();
        boolean boolean11 = borderArrangement0.equals((java.lang.Object) projectInfo8);
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        boolean boolean13 = borderArrangement0.equals((java.lang.Object) ringPlot12);
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean15 = polarPlot14.isOutlineVisible();
        polarPlot14.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot14);
        jFreeChart18.setTitle("hi!");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType21 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) ringPlot12, jFreeChart18, chartChangeEventType21);
        org.jfree.chart.entity.EntityCollection entityCollection27 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = new org.jfree.chart.ChartRenderingInfo(entityCollection27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = categoryAxis29.getLabelInsets();
        double double32 = rectangleInsets30.trimWidth((double) (byte) 10);
        double double34 = rectangleInsets30.calculateTopInset((-1.0d));
        double double36 = rectangleInsets30.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock38 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str39 = labelBlock38.getToolTipText();
        java.lang.String str40 = labelBlock38.getURLText();
        java.awt.geom.Rectangle2D rectangle2D41 = labelBlock38.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType42 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType43 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str44 = lengthAdjustmentType43.toString();
        java.awt.geom.Rectangle2D rectangle2D45 = rectangleInsets30.createAdjustedRectangle(rectangle2D41, lengthAdjustmentType42, lengthAdjustmentType43);
        chartRenderingInfo28.setChartArea(rectangle2D41);
        try {
            java.awt.image.BufferedImage bufferedImage47 = jFreeChart18.createBufferedImage((int) (byte) -1, 9999, 0.0d, (double) 2, chartRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (9999) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(libraryArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 4.0d + "'", double32 == 4.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 3.0d + "'", double34 == 3.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 3.0d + "'", double36 == 3.0d);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(lengthAdjustmentType42);
        org.junit.Assert.assertNotNull(lengthAdjustmentType43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "CONTRACT" + "'", str44.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D45);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.awt.Image image7 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo11 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image7, "", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray12 = projectInfo11.getLibraries();
        boolean boolean13 = textAnchor3.equals((java.lang.Object) projectInfo11);
        org.jfree.chart.axis.NumberTick numberTick15 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 1.0E-5d, "CONTRACT", textAnchor2, textAnchor3, 0.4d);
        java.awt.Image image19 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo23 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image19, "", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray24 = projectInfo23.getLibraries();
        java.lang.String str25 = projectInfo23.getName();
        boolean boolean26 = numberTick15.equals((java.lang.Object) str25);
        org.jfree.chart.text.TextAnchor textAnchor27 = numberTick15.getTextAnchor();
        double double28 = numberTick15.getValue();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(libraryArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(libraryArray24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0E-5d + "'", double28 == 1.0E-5d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        borderArrangement0.clear();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int3 = taskSeriesCollection2.getColumnCount();
        java.util.List list4 = taskSeriesCollection2.getColumnKeys();
        int int5 = taskSeriesCollection2.getColumnCount();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) borderArrangement0, (org.jfree.data.general.Dataset) taskSeriesCollection2, (java.lang.Comparable) '4');
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection8 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int9 = taskSeriesCollection8.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries11 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection8.add(taskSeries11);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        taskSeries11.addPropertyChangeListener(propertyChangeListener13);
        java.lang.Object obj15 = taskSeries11.clone();
        taskSeries11.setDescription("({0}, {1}) = {2}");
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.awt.Image image22 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo26 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image22, "", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray27 = projectInfo26.getLibraries();
        boolean boolean28 = textAnchor18.equals((java.lang.Object) projectInfo26);
        java.awt.Image image29 = null;
        projectInfo26.setLogo(image29);
        boolean boolean31 = taskSeries11.equals((java.lang.Object) image29);
        taskSeriesCollection2.remove(taskSeries11);
        java.lang.Comparable comparable33 = null;
        java.lang.Comparable comparable34 = null;
        try {
            java.lang.Number number36 = taskSeriesCollection2.getEndValue(comparable33, comparable34, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertNotNull(libraryArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list2 = defaultKeyedValues2D1.getColumnKeys();
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (short) 100, (double) 4);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint14 = statisticalLineAndShapeRenderer8.getItemOutlinePaint((-1), 0);
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape5, paint14);
        java.awt.Shape shape16 = legendGraphic15.getLine();
        java.awt.Paint paint17 = legendGraphic15.getLinePaint();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(shape16);
        org.junit.Assert.assertNull(paint17);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.shift(range0, (double) 9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        boolean boolean5 = xYPlot0.isRangeZeroBaselineVisible();
        boolean boolean6 = xYPlot0.isDomainCrosshairVisible();
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke10 = polarPlot9.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', (java.awt.Paint) color8, stroke10);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection12 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int13 = taskSeriesCollection12.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries15 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection12.add(taskSeries15);
        org.jfree.data.gantt.TaskSeries taskSeries18 = taskSeriesCollection12.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset20 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection12, (java.lang.Comparable) "CONTRACT");
        boolean boolean21 = categoryMarker11.equals((java.lang.Object) taskSeriesCollection12);
        java.awt.Color color22 = java.awt.Color.GREEN;
        categoryMarker11.setPaint((java.awt.Paint) color22);
        org.jfree.chart.util.Layer layer24 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer24);
        xYPlot0.setWeight((int) (byte) 1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(taskSeries18);
        org.junit.Assert.assertNotNull(pieDataset20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str1 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.VERTICAL" + "'", str1.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("XY Plot");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = chartRenderingInfo1.getEntityCollection();
        chartRenderingInfo1.clear();
        org.junit.Assert.assertNull(entityCollection2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        java.awt.Stroke stroke5 = xYPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint14 = statisticalLineAndShapeRenderer8.getItemOutlinePaint((-1), 0);
        boolean boolean15 = statisticalLineAndShapeRenderer8.getUseOutlinePaint();
        statisticalLineAndShapeRenderer8.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.block.FlowArrangement flowArrangement18 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent19 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) flowArrangement18);
        statisticalLineAndShapeRenderer8.notifyListeners(rendererChangeEvent19);
        xYPlot0.rendererChanged(rendererChangeEvent19);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot0.getDomainAxisLocation((int) '4');
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot24.getRangeAxisEdge(0);
        java.awt.Stroke stroke27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYPlot24.setRangeCrosshairStroke(stroke27);
        org.jfree.chart.plot.PlotOrientation plotOrientation29 = xYPlot24.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation23, plotOrientation29);
        java.lang.String str31 = plotOrientation29.toString();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(plotOrientation29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "PlotOrientation.VERTICAL" + "'", str31.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint8 = statisticalLineAndShapeRenderer2.getItemOutlinePaint((-1), 0);
        boolean boolean11 = statisticalLineAndShapeRenderer2.getItemVisible(4, 2);
        java.awt.Paint paint13 = statisticalLineAndShapeRenderer2.getSeriesOutlinePaint(2019);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint16 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        categoryAxis15.setTickMarkPaint(paint16);
        java.lang.String str18 = categoryAxis15.getLabel();
        java.awt.Paint paint19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryAxis15.setLabelPaint(paint19);
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity25 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis15, shape22, "({0}, {1}) = {2}", "({0}, {1}) = {2}");
        org.jfree.chart.entity.ChartEntity chartEntity26 = new org.jfree.chart.entity.ChartEntity(shape22);
        java.lang.String str27 = chartEntity26.getToolTipText();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape29, rectangleAnchor30, (double) (short) 100, (double) 4);
        chartEntity26.setArea(shape29);
        statisticalLineAndShapeRenderer2.setSeriesShape((int) 'a', shape29, false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(shape33);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 1, (double) (short) 10, false);
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block5 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean9 = statisticalLineAndShapeRenderer8.getBaseItemLabelsVisible();
        int int10 = statisticalLineAndShapeRenderer8.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        statisticalLineAndShapeRenderer8.setSeriesNegativeItemLabelPosition(0, itemLabelPosition12);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator16 = statisticalLineAndShapeRenderer8.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = statisticalLineAndShapeRenderer8.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        flowArrangement4.add(block5, (java.lang.Object) itemLabelPosition18);
        stackedBarRenderer3D3.setBaseNegativeItemLabelPosition(itemLabelPosition18);
        boolean boolean23 = stackedBarRenderer3D3.getItemVisible((int) (short) -1, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator16);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        statisticalLineAndShapeRenderer2.setUseFillPaint(false);
        boolean boolean10 = statisticalLineAndShapeRenderer2.getAutoPopulateSeriesOutlinePaint();
        java.lang.Boolean boolean12 = statisticalLineAndShapeRenderer2.getSeriesShapesVisible((int) (short) 1);
        boolean boolean14 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        boolean boolean8 = statisticalLineAndShapeRenderer2.getUseFillPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        java.awt.Stroke stroke10 = statisticalLineAndShapeRenderer2.getItemOutlineStroke(4, (int) '4');
        boolean boolean11 = statisticalLineAndShapeRenderer2.getAutoPopulateSeriesOutlinePaint();
        boolean boolean12 = statisticalLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYPlot0.setRangeCrosshairStroke(stroke3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot0.getDataset();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke9 = polarPlot8.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', (java.awt.Paint) color7, stroke9);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection11 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int12 = taskSeriesCollection11.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries14 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection11.add(taskSeries14);
        org.jfree.data.gantt.TaskSeries taskSeries17 = taskSeriesCollection11.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection11, (java.lang.Comparable) "CONTRACT");
        boolean boolean20 = categoryMarker10.equals((java.lang.Object) taskSeriesCollection11);
        java.awt.Color color21 = java.awt.Color.GREEN;
        categoryMarker10.setPaint((java.awt.Paint) color21);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10);
        int int24 = xYPlot0.getDatasetCount();
        try {
            java.awt.Paint paint26 = xYPlot0.getQuadrantPaint((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(taskSeries17);
        org.junit.Assert.assertNotNull(pieDataset19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        ringPlot0.setLabelGap((double) 0);
        java.lang.Comparable comparable5 = null;
        try {
            java.awt.Paint paint6 = ringPlot0.getSectionPaint(comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 0, 100.0d);
        java.awt.Paint paint3 = stackedBarRenderer3D2.getWallPaint();
        double double4 = stackedBarRenderer3D2.getXOffset();
        boolean boolean6 = stackedBarRenderer3D2.equals((java.lang.Object) "RectangleConstraintType.RANGE");
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block1 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean5 = statisticalLineAndShapeRenderer4.getBaseItemLabelsVisible();
        int int6 = statisticalLineAndShapeRenderer4.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = null;
        statisticalLineAndShapeRenderer4.setSeriesNegativeItemLabelPosition(0, itemLabelPosition8);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = statisticalLineAndShapeRenderer4.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = statisticalLineAndShapeRenderer4.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        flowArrangement0.add(block1, (java.lang.Object) itemLabelPosition14);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor16 = itemLabelPosition14.getItemLabelAnchor();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor17 = itemLabelPosition14.getItemLabelAnchor();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator12);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(itemLabelAnchor16);
        org.junit.Assert.assertNotNull(itemLabelAnchor17);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str9 = spreadsheetDate8.getDescription();
        int int10 = spreadsheetDate8.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str13 = spreadsheetDate12.getDescription();
        org.jfree.data.time.SerialDate serialDate14 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        java.lang.Number number15 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) (-1.0f), (java.lang.Comparable) serialDate14);
        java.lang.Number number18 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) 0L, (java.lang.Comparable) 3.0d);
        java.lang.Object obj19 = defaultStatisticalCategoryDataset0.clone();
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint8 = statisticalLineAndShapeRenderer2.getItemOutlinePaint((-1), 0);
        boolean boolean10 = statisticalLineAndShapeRenderer2.isSeriesItemLabelsVisible(0);
        boolean boolean12 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) 0.4d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition((int) (short) 0, itemLabelPosition14, false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("GradientPaintTransformType.HORIZONTAL");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block7 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean11 = statisticalLineAndShapeRenderer10.getBaseItemLabelsVisible();
        int int12 = statisticalLineAndShapeRenderer10.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = null;
        statisticalLineAndShapeRenderer10.setSeriesNegativeItemLabelPosition(0, itemLabelPosition14);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = statisticalLineAndShapeRenderer10.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = statisticalLineAndShapeRenderer10.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        flowArrangement6.add(block7, (java.lang.Object) itemLabelPosition20);
        boolean boolean22 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) itemLabelPosition20);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator18);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        boolean boolean5 = xYPlot0.isRangeZeroBaselineVisible();
        boolean boolean6 = xYPlot0.isDomainCrosshairVisible();
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke10 = polarPlot9.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', (java.awt.Paint) color8, stroke10);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection12 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int13 = taskSeriesCollection12.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries15 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection12.add(taskSeries15);
        org.jfree.data.gantt.TaskSeries taskSeries18 = taskSeriesCollection12.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset20 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection12, (java.lang.Comparable) "CONTRACT");
        boolean boolean21 = categoryMarker11.equals((java.lang.Object) taskSeriesCollection12);
        java.awt.Color color22 = java.awt.Color.GREEN;
        categoryMarker11.setPaint((java.awt.Paint) color22);
        org.jfree.chart.util.Layer layer24 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer24);
        java.awt.Paint paint26 = xYPlot0.getDomainTickBandPaint();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(taskSeries18);
        org.junit.Assert.assertNotNull(pieDataset20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(paint26);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str3 = spreadsheetDate2.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str6 = spreadsheetDate5.getDescription();
        int int7 = spreadsheetDate5.getDayOfWeek();
        boolean boolean8 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addMonths((int) ' ', (org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint8 = statisticalLineAndShapeRenderer2.getItemOutlinePaint((-1), 0);
        boolean boolean9 = statisticalLineAndShapeRenderer2.getUseOutlinePaint();
        statisticalLineAndShapeRenderer2.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) flowArrangement12);
        statisticalLineAndShapeRenderer2.notifyListeners(rendererChangeEvent13);
        statisticalLineAndShapeRenderer2.setBaseCreateEntities(false, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = statisticalLineAndShapeRenderer2.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator18);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        segmentedTimeline0.setStartTime((long) (-1));
        boolean boolean3 = segmentedTimeline0.getAdjustForDaylightSaving();
        segmentedTimeline0.setStartTime((long) (byte) 10);
        int int6 = segmentedTimeline0.getSegmentsExcluded();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer5.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint9 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        statisticalLineAndShapeRenderer5.setBasePaint(paint9);
        textTitle2.setBackgroundPaint(paint9);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = textTitle2.getPadding();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.lang.Number number0 = null;
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation(number0, (java.lang.Number) 2958465);
        java.awt.Shape[] shapeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        boolean boolean4 = meanAndStandardDeviation2.equals((java.lang.Object) shapeArray3);
        org.junit.Assert.assertNotNull(shapeArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = dateAxis4.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = dateAxis4.java2DToValue((double) 4, rectangle2D7, rectangleEdge8);
        java.awt.Shape shape10 = dateAxis4.getLeftArrow();
        int int11 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("hi!", font13);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer17 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer17.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint21 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        statisticalLineAndShapeRenderer17.setBasePaint(paint21);
        textTitle14.setBackgroundPaint(paint21);
        xYPlot0.setRangeZeroBaselinePaint(paint21);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        try {
            xYPlot0.setQuadrantPaint((int) (byte) 10, (java.awt.Paint) color26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 9.223372036854776E18d + "'", double9 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray7 = new java.lang.Number[][] { numberArray2, numberArray3, numberArray4, numberArray5, numberArray6 };
        org.jfree.data.category.CategoryDataset categoryDataset8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("DateTickUnit[DAY, 1]", "LengthConstraintType.NONE", numberArray7);
        java.lang.Number[] numberArray11 = new java.lang.Number[] {};
        java.lang.Number[] numberArray12 = new java.lang.Number[] {};
        java.lang.Number[] numberArray13 = new java.lang.Number[] {};
        java.lang.Number[] numberArray14 = new java.lang.Number[] {};
        java.lang.Number[] numberArray15 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray11, numberArray12, numberArray13, numberArray14, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("DateTickUnit[DAY, 1]", "LengthConstraintType.NONE", numberArray16);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset18 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray7, numberArray16);
        try {
            java.lang.Number number21 = defaultIntervalCategoryDataset18.getEndValue((java.lang.Comparable) 12.0d, (java.lang.Comparable) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown 'series' key.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(categoryDataset8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset3.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.general.DatasetGroup datasetGroup9 = defaultStatisticalCategoryDataset3.getGroup();
        java.lang.Comparable comparable11 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity12 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "hi!", "", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, (java.lang.Comparable) 1.0d, comparable11);
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint14 = polarPlot13.getOutlinePaint();
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot13.setOutlineStroke(stroke15);
        java.lang.String str17 = polarPlot13.getPlotType();
        int int18 = polarPlot13.getBackgroundImageAlignment();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = categoryAxis19.getLabelInsets();
        java.awt.Stroke stroke21 = categoryAxis19.getAxisLineStroke();
        float float22 = categoryAxis19.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent23 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis19);
        org.jfree.chart.axis.Axis axis24 = axisChangeEvent23.getAxis();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer27 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean28 = statisticalLineAndShapeRenderer27.getBaseItemLabelsVisible();
        int int29 = statisticalLineAndShapeRenderer27.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = null;
        statisticalLineAndShapeRenderer27.setSeriesNegativeItemLabelPosition(0, itemLabelPosition31);
        java.awt.Stroke stroke35 = statisticalLineAndShapeRenderer27.getItemOutlineStroke(4, (int) '4');
        statisticalLineAndShapeRenderer27.setItemLabelAnchorOffset((double) (short) 1);
        java.awt.Stroke stroke38 = statisticalLineAndShapeRenderer27.getBaseOutlineStroke();
        axis24.setTickMarkStroke(stroke38);
        polarPlot13.setAngleGridlineStroke(stroke38);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent41 = null;
        polarPlot13.datasetChanged(datasetChangeEvent41);
        boolean boolean43 = defaultStatisticalCategoryDataset3.hasListener((java.util.EventListener) polarPlot13);
        org.jfree.data.Range range45 = defaultStatisticalCategoryDataset3.getRangeBounds(false);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(datasetGroup9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Polar Plot" + "'", str17.equals("Polar Plot"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertNotNull(axis24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2 + "'", int29 == 2);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(range45);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 1, (double) (short) 10, false);
        java.awt.Font font4 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        stackedBarRenderer3D3.setBaseItemLabelFont(font4, true);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        double double12 = rectangleInsets10.trimWidth((double) (byte) 10);
        double double14 = rectangleInsets10.calculateTopInset((-1.0d));
        double double16 = rectangleInsets10.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock18 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str19 = labelBlock18.getToolTipText();
        java.lang.String str20 = labelBlock18.getURLText();
        java.awt.geom.Rectangle2D rectangle2D21 = labelBlock18.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType22 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str24 = lengthAdjustmentType23.toString();
        java.awt.geom.Rectangle2D rectangle2D25 = rectangleInsets10.createAdjustedRectangle(rectangle2D21, lengthAdjustmentType22, lengthAdjustmentType23);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint28 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        categoryAxis27.setTickMarkPaint(paint28);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat31 = dateAxis30.getDateFormatOverride();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset32 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset32.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str41 = spreadsheetDate40.getDescription();
        int int42 = spreadsheetDate40.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str45 = spreadsheetDate44.getDescription();
        org.jfree.data.time.SerialDate serialDate46 = spreadsheetDate40.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate44);
        java.lang.Number number47 = defaultStatisticalCategoryDataset32.getValue((java.lang.Comparable) (-1.0f), (java.lang.Comparable) serialDate46);
        try {
            stackedBarRenderer3D3.drawItem(graphics2D7, categoryItemRendererState8, rectangle2D25, categoryPlot26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis30, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset32, 0, 8, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.0d + "'", double14 == 3.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 3.0d + "'", double16 == 3.0d);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(lengthAdjustmentType22);
        org.junit.Assert.assertNotNull(lengthAdjustmentType23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "CONTRACT" + "'", str24.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(dateFormat31);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNull(number47);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        polarPlot0.markerChanged(markerChangeEvent1);
        java.lang.String str3 = polarPlot0.getNoDataMessage();
        java.lang.Object obj4 = polarPlot0.clone();
        int int5 = polarPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((-329600));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorLeft((double) (-1.0f));
        java.util.List list3 = axisState0.getTicks();
        axisState0.setCursor((double) (short) 0);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        polarPlot0.markerChanged(markerChangeEvent1);
        int int3 = polarPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 1, (double) (short) 10, false);
        stackedBarRenderer3D3.setRenderAsPercentages(true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = null;
        stackedBarRenderer3D3.setBaseItemLabelGenerator(categoryItemLabelGenerator6, false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0);
        java.util.List list2 = blockContainer1.getBlocks();
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image3, "", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray8 = projectInfo7.getLibraries();
        java.lang.String str9 = projectInfo7.getName();
        projectInfo7.setCopyright("PlotOrientation.VERTICAL");
        org.junit.Assert.assertNotNull(libraryArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int1 = taskSeriesCollection0.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries3 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection0.add(taskSeries3);
        org.jfree.data.gantt.TaskSeries taskSeries6 = taskSeriesCollection0.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, (java.lang.Comparable) "CONTRACT");
        taskSeriesCollection0.validateObject();
        org.jfree.data.general.PieDataset pieDataset11 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(taskSeries6);
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertNotNull(pieDataset11);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 2, 2.0d, (double) 0.0f, (double) (-1));
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) 1.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint(range3, (double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, range3);
        org.jfree.data.Range range7 = rectangleConstraint6.getWidthRange();
        org.jfree.data.Range range8 = rectangleConstraint6.getWidthRange();
        org.jfree.chart.util.Size2D size2D11 = new org.jfree.chart.util.Size2D((double) (short) 1, (double) 9999);
        double double12 = size2D11.getHeight();
        org.jfree.chart.util.Size2D size2D13 = rectangleConstraint6.calculateConstrainedSize(size2D11);
        java.lang.String str14 = size2D11.toString();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 9999.0d + "'", double12 == 9999.0d);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Size2D[width=1.0, height=9999.0]" + "'", str14.equals("Size2D[width=1.0, height=9999.0]"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("hi!", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        jFreeChart4.setTitle("hi!");
        java.lang.Object obj7 = jFreeChart4.getTextAntiAlias();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font9);
        java.lang.String str11 = textTitle10.getToolTipText();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("hi!", font13);
        java.lang.String str15 = textTitle14.getToolTipText();
        textTitle14.setWidth(0.0d);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent18 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle14);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle14.getVerticalAlignment();
        textTitle10.setVerticalAlignment(verticalAlignment19);
        jFreeChart4.setTitle(textTitle10);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer24 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean25 = statisticalLineAndShapeRenderer24.getBaseItemLabelsVisible();
        int int26 = statisticalLineAndShapeRenderer24.getPassCount();
        java.awt.Font font27 = statisticalLineAndShapeRenderer24.getBaseItemLabelFont();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape29, rectangleAnchor30, (double) (short) 100, (double) 4);
        statisticalLineAndShapeRenderer24.setBaseShape(shape33, false);
        boolean boolean36 = statisticalLineAndShapeRenderer24.getUseFillPaint();
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalLineAndShapeRenderer24);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke39 = categoryAxis38.getTickMarkStroke();
        boolean boolean40 = legendTitle37.equals((java.lang.Object) stroke39);
        jFreeChart4.addLegend(legendTitle37);
        org.jfree.chart.title.LegendTitle legendTitle43 = jFreeChart4.getLegend((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(legendTitle43);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.lang.Number number7 = null;
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D9 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list10 = defaultKeyedValues2D9.getRowKeys();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem11 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 3, (java.lang.Number) 2958465, (java.lang.Number) (-1.0f), (java.lang.Number) 0.05d, (java.lang.Number) 10.0d, (java.lang.Number) (-1), (java.lang.Number) (byte) 100, number7, list10);
        java.lang.Number number12 = boxAndWhiskerItem11.getMinRegularValue();
        java.lang.Number number13 = boxAndWhiskerItem11.getMean();
        java.lang.Number number14 = boxAndWhiskerItem11.getMaxOutlier();
        java.lang.Number number15 = boxAndWhiskerItem11.getMean();
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 10.0d + "'", number12.equals(10.0d));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 3 + "'", number13.equals(3));
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 3 + "'", number15.equals(3));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 1.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(range2, (double) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis5.getLabelInsets();
        double double8 = rectangleInsets6.trimWidth((double) (byte) 10);
        boolean boolean9 = range2.equals((java.lang.Object) rectangleInsets6);
        double double11 = rectangleInsets6.extendHeight((double) (short) -1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 5.0d + "'", double11 == 5.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYPlot0.setRangeCrosshairStroke(stroke3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot0.getDataset();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot0.getDomainAxisEdge();
        xYPlot0.setRangeCrosshairValue(0.0d);
        java.awt.Paint paint9 = xYPlot0.getRangeZeroBaselinePaint();
        java.awt.Paint paint10 = xYPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("NOID", "hi!", "Layer.BACKGROUND", "RectangleConstraintType.RANGE", "");
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
        java.awt.Paint paint1 = areaRenderer0.getBaseFillPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        boolean boolean1 = stackedBarRenderer0.getRenderAsPercentages();
        java.awt.Shape shape2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset5 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset5.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.general.DatasetGroup datasetGroup11 = defaultStatisticalCategoryDataset5.getGroup();
        java.lang.Comparable comparable13 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity14 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "hi!", "", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5, (java.lang.Comparable) 1.0d, comparable13);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer17 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean18 = statisticalLineAndShapeRenderer17.getBaseItemLabelsVisible();
        int int19 = statisticalLineAndShapeRenderer17.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = null;
        statisticalLineAndShapeRenderer17.setSeriesNegativeItemLabelPosition(0, itemLabelPosition21);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator25 = statisticalLineAndShapeRenderer17.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = statisticalLineAndShapeRenderer17.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor28 = itemLabelPosition27.getRotationAnchor();
        boolean boolean29 = defaultStatisticalCategoryDataset5.equals((java.lang.Object) textAnchor28);
        java.util.List list30 = defaultStatisticalCategoryDataset5.getRowKeys();
        org.jfree.data.Range range31 = stackedBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(datasetGroup11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator25);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNotNull(range31);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(2019);
        java.awt.Color color2 = java.awt.Color.black;
        float[] floatArray8 = new float[] { 1, (short) 10, (short) 10, (short) -1, (-1) };
        float[] floatArray9 = color2.getRGBComponents(floatArray8);
        boolean boolean10 = objectList1.equals((java.lang.Object) color2);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        double double3 = ringPlot0.getMaximumLabelWidth();
        ringPlot0.setCircular(false);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint7 = defaultDrawingSupplier6.getNextFillPaint();
        ringPlot0.setSeparatorPaint(paint7);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("CONTRACT", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("hi!", font5);
        java.lang.String str7 = textTitle6.getToolTipText();
        textTitle6.setWidth(0.0d);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle6);
        java.awt.Color color11 = java.awt.Color.cyan;
        boolean boolean12 = textTitle6.equals((java.lang.Object) color11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = categoryAxis14.getLabelInsets();
        double double17 = rectangleInsets15.trimWidth((double) (byte) 10);
        double double19 = rectangleInsets15.calculateTopInset((-1.0d));
        double double21 = rectangleInsets15.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str24 = labelBlock23.getToolTipText();
        java.lang.String str25 = labelBlock23.getURLText();
        java.awt.geom.Rectangle2D rectangle2D26 = labelBlock23.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType27 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType28 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str29 = lengthAdjustmentType28.toString();
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets15.createAdjustedRectangle(rectangle2D26, lengthAdjustmentType27, lengthAdjustmentType28);
        java.lang.Object obj31 = null;
        java.lang.Object obj32 = textTitle6.draw(graphics2D13, rectangle2D26, obj31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        double double34 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D26, rectangleEdge33);
        try {
            stackedBarRenderer3D1.drawDomainGridline(graphics2D2, categoryPlot3, rectangle2D26, 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.0d + "'", double19 == 3.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(lengthAdjustmentType27);
        org.junit.Assert.assertNotNull(lengthAdjustmentType28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "CONTRACT" + "'", str29.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNull(obj32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("CONTRACT", "Range[1.0,1.0]", "PlotOrientation.VERTICAL", "ClassContext");
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis5.getLabelInsets();
        java.awt.Stroke stroke7 = categoryAxis5.getAxisLineStroke();
        categoryAxis5.setVisible(false);
        boolean boolean10 = basicProjectInfo4.equals((java.lang.Object) categoryAxis5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = dateAxis4.getStandardTickUnits();
        java.util.Date date6 = dateAxis4.getMinimumDate();
        org.jfree.data.Range range7 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis4);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj1 = categoryAxis3D0.clone();
        categoryAxis3D0.configure();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent3 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D0);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis3D0.getCategoryLabelPositions();
        java.lang.Object obj5 = categoryAxis3D0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        segmentedTimeline0.setStartTime((long) (-1));
        boolean boolean3 = segmentedTimeline0.getAdjustForDaylightSaving();
        segmentedTimeline0.setStartTime((long) (byte) 10);
        try {
            boolean boolean8 = segmentedTimeline0.containsDomainRange((long) 2019, (long) (-329600));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: domainValueEnd (-329600) < domainValueStart (2019)");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setMaximumBarWidth((double) 2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = barRenderer0.getNegativeItemLabelPositionFallback();
        double double4 = barRenderer0.getLowerClip();
        org.junit.Assert.assertNull(itemLabelPosition3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) flowArrangement8);
        statisticalLineAndShapeRenderer2.notifyListeners(rendererChangeEvent9);
        statisticalLineAndShapeRenderer2.setSeriesVisibleInLegend(2019, (java.lang.Boolean) false, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setStartAngle(0.0d);
        java.awt.Paint paint3 = ringPlot0.getLabelBackgroundPaint();
        ringPlot0.setShadowYOffset((double) 0.0f);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = ringPlot0.getToolTipGenerator();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(pieToolTipGenerator6);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset3.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.general.DatasetGroup datasetGroup9 = defaultStatisticalCategoryDataset3.getGroup();
        java.lang.Comparable comparable11 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity12 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "hi!", "", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, (java.lang.Comparable) 1.0d, comparable11);
        java.lang.String str13 = categoryItemEntity12.toString();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator14 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator15 = null;
        try {
            java.lang.String str16 = categoryItemEntity12.getImageMapAreaTag(toolTipTagFragmentGenerator14, uRLTagFragmentGenerator15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(datasetGroup9);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        java.awt.geom.Point2D point2D0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Image image1 = projectInfo0.getLogo();
        org.junit.Assert.assertNull(image1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str2 = spreadsheetDate1.getDescription();
        int int3 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate4 = null;
        try {
            boolean boolean5 = spreadsheetDate1.isAfter(serialDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.LegendItem legendItem3 = waterfallBarRenderer0.getLegendItem(15, 1);
        org.junit.Assert.assertNull(legendItem3);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 1.0f);
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange(range2);
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange3);
        org.junit.Assert.assertNotNull(range2);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke3 = polarPlot2.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', (java.awt.Paint) color1, stroke3);
        java.lang.Object obj5 = categoryMarker4.clone();
        java.awt.Stroke stroke6 = categoryMarker4.getOutlineStroke();
        java.awt.Color color7 = java.awt.Color.GREEN;
        categoryMarker4.setPaint((java.awt.Paint) color7);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        dateAxis0.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline1);
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        dateAxis0.removeChangeListener(axisChangeListener3);
        org.junit.Assert.assertNotNull(segmentedTimeline1);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        statisticalLineAndShapeRenderer2.setBaseItemLabelGenerator(categoryItemLabelGenerator4, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = statisticalLineAndShapeRenderer2.getPlot();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(categoryPlot7);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getRowCount();
        int int4 = defaultKeyedValues2D1.getColumnIndex((java.lang.Comparable) 0);
        int int6 = defaultKeyedValues2D1.getColumnIndex((java.lang.Comparable) 0.4d);
        java.util.List list7 = defaultKeyedValues2D1.getColumnKeys();
        try {
            java.lang.Comparable comparable9 = defaultKeyedValues2D1.getRowKey(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.util.Iterator iterator1 = legendItemCollection0.iterator();
        org.junit.Assert.assertNotNull(iterator1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis0.setRangeWithMargins((org.jfree.data.Range) dateRange4, false, false);
        dateAxis0.setAutoRange(false);
        java.lang.String str10 = dateAxis0.getLabelToolTip();
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getOutlinePaint();
        java.awt.Stroke stroke2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot0.setOutlineStroke(stroke2);
        boolean boolean4 = polarPlot0.isRadiusGridlinesVisible();
        java.awt.Stroke stroke5 = polarPlot0.getAngleGridlineStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 1, (double) (short) 10, false);
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block5 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean9 = statisticalLineAndShapeRenderer8.getBaseItemLabelsVisible();
        int int10 = statisticalLineAndShapeRenderer8.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        statisticalLineAndShapeRenderer8.setSeriesNegativeItemLabelPosition(0, itemLabelPosition12);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator16 = statisticalLineAndShapeRenderer8.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = statisticalLineAndShapeRenderer8.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        flowArrangement4.add(block5, (java.lang.Object) itemLabelPosition18);
        stackedBarRenderer3D3.setBaseNegativeItemLabelPosition(itemLabelPosition18);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent24 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis23);
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis23.setTickUnit(dateTickUnit25);
        org.jfree.chart.plot.Marker marker27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        stackedBarRenderer3D3.drawRangeMarker(graphics2D21, categoryPlot22, (org.jfree.chart.axis.ValueAxis) dateAxis23, marker27, rectangle2D28);
        boolean boolean32 = stackedBarRenderer3D3.isItemLabelVisible(0, 11);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator16);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(dateTickUnit25);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("LengthConstraintType.NONE", "XY Plot", "GradientPaintTransformType.HORIZONTAL", "DateTickUnit[DAY, 1]", "{0}");
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.lang.Object obj0 = null;
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'object' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int1 = taskSeriesCollection0.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries3 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection0.add(taskSeries3);
        int int5 = taskSeriesCollection0.getSeriesCount();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D9 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int10 = defaultKeyedValues2D9.getRowCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str15 = spreadsheetDate14.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str18 = spreadsheetDate17.getDescription();
        int int19 = spreadsheetDate17.getDayOfWeek();
        boolean boolean20 = spreadsheetDate14.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        defaultKeyedValues2D9.addValue((java.lang.Number) 2958465, (java.lang.Comparable) 100.0f, (java.lang.Comparable) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        try {
            java.lang.Number number24 = taskSeriesCollection0.getEndValue((java.lang.Comparable) 1900, (java.lang.Comparable) serialDate22, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(serialDate22);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray7 = new java.lang.Number[][] { numberArray2, numberArray3, numberArray4, numberArray5, numberArray6 };
        org.jfree.data.category.CategoryDataset categoryDataset8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("DateTickUnit[DAY, 1]", "LengthConstraintType.NONE", numberArray7);
        java.lang.Number[] numberArray11 = new java.lang.Number[] {};
        java.lang.Number[] numberArray12 = new java.lang.Number[] {};
        java.lang.Number[] numberArray13 = new java.lang.Number[] {};
        java.lang.Number[] numberArray14 = new java.lang.Number[] {};
        java.lang.Number[] numberArray15 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray11, numberArray12, numberArray13, numberArray14, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("DateTickUnit[DAY, 1]", "LengthConstraintType.NONE", numberArray16);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset18 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray7, numberArray16);
        try {
            java.lang.Comparable comparable20 = defaultIntervalCategoryDataset18.getColumnKey(1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(categoryDataset8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        java.lang.Object obj5 = null;
        boolean boolean6 = xYPlot0.equals(obj5);
        xYPlot0.setRangeCrosshairValue((double) ' ');
        java.awt.Stroke stroke9 = xYPlot0.getDomainCrosshairStroke();
        int int10 = xYPlot0.getWeight();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("hi!", "Polar Plot", "Polar Plot");
        java.lang.Object obj4 = standardCategoryURLGenerator3.clone();
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("Range[135.0,135.0]", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        java.lang.Object obj1 = null;
        boolean boolean2 = sortOrder0.equals(obj1);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("hi!", font3);
        java.awt.Paint paint5 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("({0}, {1}) = {2}", font3, paint5);
        textBlock0.addLine(textLine6);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        dateAxis9.resizeRange(1.0d);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer14 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean15 = statisticalLineAndShapeRenderer14.getBaseItemLabelsVisible();
        int int16 = statisticalLineAndShapeRenderer14.getPassCount();
        java.awt.Font font17 = statisticalLineAndShapeRenderer14.getBaseItemLabelFont();
        dateAxis9.setLabelFont(font17);
        java.awt.Paint paint19 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        textBlock0.addLine("Polar Plot", font17, paint19);
        java.awt.Graphics2D graphics2D21 = null;
        try {
            org.jfree.chart.util.Size2D size2D22 = textBlock0.calculateDimensions(graphics2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        boolean boolean5 = xYPlot0.isRangeZeroBaselineVisible();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = xYPlot0.getAxisOffset();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.awt.Image image7 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo11 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image7, "", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray12 = projectInfo11.getLibraries();
        boolean boolean13 = textAnchor3.equals((java.lang.Object) projectInfo11);
        org.jfree.chart.axis.NumberTick numberTick15 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 1.0E-5d, "CONTRACT", textAnchor2, textAnchor3, 0.4d);
        java.awt.Image image19 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo23 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image19, "", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray24 = projectInfo23.getLibraries();
        java.lang.String str25 = projectInfo23.getName();
        boolean boolean26 = numberTick15.equals((java.lang.Object) str25);
        java.lang.Object obj27 = numberTick15.clone();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(libraryArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(libraryArray24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        jFreeChart4.setTitle("hi!");
        java.lang.Object obj7 = jFreeChart4.getTextAntiAlias();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font9);
        java.lang.String str11 = textTitle10.getToolTipText();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("hi!", font13);
        java.lang.String str15 = textTitle14.getToolTipText();
        textTitle14.setWidth(0.0d);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent18 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle14);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle14.getVerticalAlignment();
        textTitle10.setVerticalAlignment(verticalAlignment19);
        jFreeChart4.setTitle(textTitle10);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer24 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean25 = statisticalLineAndShapeRenderer24.getBaseItemLabelsVisible();
        int int26 = statisticalLineAndShapeRenderer24.getPassCount();
        java.awt.Font font27 = statisticalLineAndShapeRenderer24.getBaseItemLabelFont();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape29, rectangleAnchor30, (double) (short) 100, (double) 4);
        statisticalLineAndShapeRenderer24.setBaseShape(shape33, false);
        boolean boolean36 = statisticalLineAndShapeRenderer24.getUseFillPaint();
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalLineAndShapeRenderer24);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke39 = categoryAxis38.getTickMarkStroke();
        boolean boolean40 = legendTitle37.equals((java.lang.Object) stroke39);
        jFreeChart4.addLegend(legendTitle37);
        org.jfree.chart.block.BlockContainer blockContainer42 = legendTitle37.getItemContainer();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = legendTitle37.getLegendItemGraphicAnchor();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(blockContainer42);
        org.junit.Assert.assertNotNull(rectangleAnchor43);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        segmentedTimeline0.setStartTime((long) (-1));
        boolean boolean3 = segmentedTimeline0.getAdjustForDaylightSaving();
        segmentedTimeline0.setStartTime((long) (byte) 10);
        long long6 = segmentedTimeline0.getSegmentsIncludedSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 432000000L + "'", long6 == 432000000L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot2.getRangeAxisEdge(0);
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYPlot2.setRangeCrosshairStroke(stroke5);
        boolean boolean7 = stackedAreaRenderer1.equals((java.lang.Object) stroke5);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        jFreeChart4.setTitle("hi!");
        java.lang.Object obj7 = jFreeChart4.getTextAntiAlias();
        java.lang.Object obj8 = jFreeChart4.clone();
        org.jfree.chart.plot.Plot plot9 = jFreeChart4.getPlot();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(plot9);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10L, (double) 1.0f, false);
        boolean boolean4 = stackedBarRenderer3D3.getRenderAsPercentages();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = xYPlot1.getRangeAxisEdge(0);
        boolean boolean4 = xYPlot1.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = dateAxis5.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = dateAxis5.java2DToValue((double) 4, rectangle2D8, rectangleEdge9);
        java.awt.Shape shape11 = dateAxis5.getLeftArrow();
        int int12 = xYPlot1.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("hi!", font14);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer18.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint22 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        statisticalLineAndShapeRenderer18.setBasePaint(paint22);
        textTitle15.setBackgroundPaint(paint22);
        xYPlot1.setRangeZeroBaselinePaint(paint22);
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke29 = polarPlot28.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', (java.awt.Paint) color27, stroke29);
        java.lang.String str31 = categoryMarker30.getLabel();
        xYPlot1.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker30);
        xYPlot1.clearDomainAxes();
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = xYPlot34.getRangeAxisEdge(0);
        boolean boolean37 = xYPlot34.isRangeZeroBaselineVisible();
        java.awt.Paint paint38 = xYPlot34.getRangeZeroBaselinePaint();
        java.awt.Stroke stroke39 = xYPlot34.getRangeZeroBaselineStroke();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer42 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer42.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint48 = statisticalLineAndShapeRenderer42.getItemOutlinePaint((-1), 0);
        boolean boolean49 = statisticalLineAndShapeRenderer42.getUseOutlinePaint();
        statisticalLineAndShapeRenderer42.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.block.FlowArrangement flowArrangement52 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent53 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) flowArrangement52);
        statisticalLineAndShapeRenderer42.notifyListeners(rendererChangeEvent53);
        xYPlot34.rendererChanged(rendererChangeEvent53);
        xYPlot1.rendererChanged(rendererChangeEvent53);
        java.awt.Graphics2D graphics2D57 = null;
        org.jfree.chart.axis.AxisSpace axisSpace58 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = categoryAxis59.getLabelInsets();
        double double62 = rectangleInsets60.trimWidth((double) (byte) 10);
        double double64 = rectangleInsets60.calculateTopInset((-1.0d));
        double double66 = rectangleInsets60.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock68 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str69 = labelBlock68.getToolTipText();
        java.lang.String str70 = labelBlock68.getURLText();
        java.awt.geom.Rectangle2D rectangle2D71 = labelBlock68.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType72 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType73 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str74 = lengthAdjustmentType73.toString();
        java.awt.geom.Rectangle2D rectangle2D75 = rectangleInsets60.createAdjustedRectangle(rectangle2D71, lengthAdjustmentType72, lengthAdjustmentType73);
        org.jfree.chart.block.LabelBlock labelBlock77 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str78 = labelBlock77.getToolTipText();
        java.lang.String str79 = labelBlock77.getURLText();
        java.awt.geom.Rectangle2D rectangle2D80 = labelBlock77.getBounds();
        java.awt.geom.Rectangle2D rectangle2D81 = axisSpace58.shrink(rectangle2D75, rectangle2D80);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline82 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.List list83 = segmentedTimeline82.getExceptionSegments();
        xYPlot1.drawRangeTickBands(graphics2D57, rectangle2D80, list83);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, (java.awt.Shape) rectangle2D80, 0.0d, (float) 900000L, (float) 35L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 9.223372036854776E18d + "'", double10 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 4.0d + "'", double62 == 4.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 3.0d + "'", double64 == 3.0d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 3.0d + "'", double66 == 3.0d);
        org.junit.Assert.assertNull(str69);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertNotNull(rectangle2D71);
        org.junit.Assert.assertNotNull(lengthAdjustmentType72);
        org.junit.Assert.assertNotNull(lengthAdjustmentType73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "CONTRACT" + "'", str74.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D75);
        org.junit.Assert.assertNull(str78);
        org.junit.Assert.assertNull(str79);
        org.junit.Assert.assertNotNull(rectangle2D80);
        org.junit.Assert.assertNotNull(rectangle2D81);
        org.junit.Assert.assertNotNull(segmentedTimeline82);
        org.junit.Assert.assertNotNull(list83);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int1 = taskSeriesCollection0.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries3 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection0.add(taskSeries3);
        org.jfree.data.gantt.TaskSeries taskSeries6 = taskSeriesCollection0.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, (java.lang.Comparable) "CONTRACT");
        taskSeriesCollection0.validateObject();
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(taskSeries6);
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.List list1 = segmentedTimeline0.getExceptionSegments();
        segmentedTimeline0.setStartTime(0L);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.List list5 = segmentedTimeline4.getExceptionSegments();
        segmentedTimeline4.setStartTime(0L);
        long long10 = segmentedTimeline4.getExceptionSegmentCount((long) (byte) -1, (long) 10);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int13 = defaultKeyedValues2D12.getRowCount();
        java.util.List list14 = defaultKeyedValues2D12.getColumnKeys();
        int int15 = defaultKeyedValues2D12.getRowCount();
        java.util.List list16 = defaultKeyedValues2D12.getColumnKeys();
        segmentedTimeline4.setExceptionSegments(list16);
        segmentedTimeline0.addExceptions(list16);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.awt.Image image8 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo12 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image8, "", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray13 = projectInfo12.getLibraries();
        boolean boolean14 = textAnchor4.equals((java.lang.Object) projectInfo12);
        org.jfree.chart.axis.NumberTick numberTick16 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 1.0E-5d, "CONTRACT", textAnchor3, textAnchor4, 0.4d);
        boolean boolean17 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(libraryArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 1.0f);
        double double3 = range2.getLowerBound();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        java.awt.Color color0 = null;
        try {
            java.lang.String str1 = org.jfree.chart.util.PaintUtilities.colorToString(color0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            org.jfree.data.gantt.TaskSeries taskSeries2 = taskSeriesCollection0.getSeries(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int1 = taskSeriesCollection0.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries3 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection0.add(taskSeries3);
        org.jfree.data.gantt.TaskSeries taskSeries6 = taskSeriesCollection0.getSeries((java.lang.Comparable) 1.0d);
        try {
            taskSeriesCollection0.remove((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: TaskSeriesCollection.remove(): index outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(taskSeries6);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("Size2D[width=1.0, height=9999.0]");
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = statisticalLineAndShapeRenderer2.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean14 = statisticalLineAndShapeRenderer13.getBaseItemLabelsVisible();
        int int15 = statisticalLineAndShapeRenderer13.getPassCount();
        java.awt.Font font16 = statisticalLineAndShapeRenderer13.getBaseItemLabelFont();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape18, rectangleAnchor19, (double) (short) 100, (double) 4);
        statisticalLineAndShapeRenderer13.setBaseShape(shape22, false);
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.clone(shape22);
        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape22, (double) 15, 0.0d);
        statisticalLineAndShapeRenderer2.setBaseShape(shape22, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint33 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        categoryAxis32.setTickMarkPaint(paint33);
        java.lang.String str35 = categoryAxis32.getLabel();
        java.awt.Paint paint36 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryAxis32.setLabelPaint(paint36);
        statisticalLineAndShapeRenderer2.setSeriesFillPaint((int) (byte) 1, paint36);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int1 = taskSeriesCollection0.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries3 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection0.add(taskSeries3);
        org.jfree.data.gantt.TaskSeries taskSeries6 = taskSeriesCollection0.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, (java.lang.Comparable) "CONTRACT");
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        piePlot3D9.setDepthFactor(12.0d);
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean13 = polarPlot12.isOutlineVisible();
        polarPlot12.setRadiusGridlinesVisible(true);
        float float16 = polarPlot12.getBackgroundAlpha();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        polarPlot12.setDataset(xYDataset17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        polarPlot12.zoomDomainAxes((double) 6, (double) (byte) -1, plotRenderingInfo21, point2D22);
        boolean boolean24 = piePlot3D9.equals((java.lang.Object) polarPlot12);
        java.awt.Paint paint25 = piePlot3D9.getLabelBackgroundPaint();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(taskSeries6);
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
//        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
//        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
//        dateAxis0.setRangeWithMargins((org.jfree.data.Range) dateRange4, false, false);
//        dateAxis0.setAutoRange(false);
//        double double10 = dateAxis0.getAutoRangeMinimumSize();
//        dateAxis0.setInverted(true);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline13 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        java.util.List list14 = segmentedTimeline13.getExceptionSegments();
//        dateAxis0.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline13);
//        boolean boolean16 = dateAxis0.isTickLabelsVisible();
//        boolean boolean18 = dateAxis0.isHiddenValue(0L);
//        org.junit.Assert.assertNotNull(tickUnitSource1);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
//        org.junit.Assert.assertNotNull(segmentedTimeline13);
//        org.junit.Assert.assertNotNull(list14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        ringPlot0.setLabelGap((double) 0);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = xYPlot5.getRangeAxisEdge(0);
        java.awt.Stroke stroke8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYPlot5.setRangeCrosshairStroke(stroke8);
        ringPlot0.setSeparatorStroke(stroke8);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.lang.String str1 = polarPlot0.getNoDataMessage();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        polarPlot0.rendererChanged(rendererChangeEvent2);
        polarPlot0.addCornerTextItem("NOID");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        polarPlot0.setRadiusGridlineStroke(stroke6);
        java.lang.Object obj8 = polarPlot0.clone();
        float float9 = polarPlot0.getForegroundAlpha();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint12 = polarPlot11.getOutlinePaint();
        java.awt.Stroke stroke13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot11.setOutlineStroke(stroke13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisSpace axisSpace16 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryAxis17.getLabelInsets();
        double double20 = rectangleInsets18.trimWidth((double) (byte) 10);
        double double22 = rectangleInsets18.calculateTopInset((-1.0d));
        double double24 = rectangleInsets18.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str27 = labelBlock26.getToolTipText();
        java.lang.String str28 = labelBlock26.getURLText();
        java.awt.geom.Rectangle2D rectangle2D29 = labelBlock26.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType30 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType31 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str32 = lengthAdjustmentType31.toString();
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets18.createAdjustedRectangle(rectangle2D29, lengthAdjustmentType30, lengthAdjustmentType31);
        org.jfree.chart.block.LabelBlock labelBlock35 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str36 = labelBlock35.getToolTipText();
        java.lang.String str37 = labelBlock35.getURLText();
        java.awt.geom.Rectangle2D rectangle2D38 = labelBlock35.getBounds();
        java.awt.geom.Rectangle2D rectangle2D39 = axisSpace16.shrink(rectangle2D33, rectangle2D38);
        polarPlot11.drawBackgroundImage(graphics2D15, rectangle2D39);
        java.awt.geom.Point2D point2D41 = null;
        org.jfree.chart.plot.PlotState plotState42 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        polarPlot0.draw(graphics2D10, rectangle2D39, point2D41, plotState42, plotRenderingInfo43);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 3.0d + "'", double22 == 3.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.0d + "'", double24 == 3.0d);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(lengthAdjustmentType30);
        org.junit.Assert.assertNotNull(lengthAdjustmentType31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "CONTRACT" + "'", str32.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangle2D39);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        java.lang.Number number5 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) 1, (java.lang.Comparable) (short) 0);
        java.util.List list6 = defaultStatisticalCategoryDataset0.getColumnKeys();
        int int8 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "RectangleConstraintType.RANGE");
        org.jfree.data.Range range10 = defaultStatisticalCategoryDataset0.getRangeBounds(false);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(range10);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        double double3 = ringPlot0.getMaximumLabelWidth();
        ringPlot0.setCircular(false);
        ringPlot0.setSectionOutlinesVisible(false);
        java.awt.Color color8 = java.awt.Color.black;
        float[] floatArray14 = new float[] { 1, (short) 10, (short) 10, (short) -1, (-1) };
        float[] floatArray15 = color8.getRGBComponents(floatArray14);
        float[] floatArray16 = null;
        float[] floatArray17 = color8.getRGBComponents(floatArray16);
        ringPlot0.setLabelPaint((java.awt.Paint) color8);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray17);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        polarPlot1.markerChanged(markerChangeEvent2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        polarPlot1.drawBackgroundImage(graphics2D4, rectangle2D5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        polarPlot1.drawBackgroundImage(graphics2D7, rectangle2D8);
        boolean boolean10 = color0.equals((java.lang.Object) polarPlot1);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean14 = statisticalLineAndShapeRenderer13.getBaseItemLabelsVisible();
        int int15 = statisticalLineAndShapeRenderer13.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        statisticalLineAndShapeRenderer13.setSeriesNegativeItemLabelPosition(0, itemLabelPosition17);
        java.awt.Stroke stroke21 = statisticalLineAndShapeRenderer13.getItemOutlineStroke(4, (int) '4');
        polarPlot1.setRadiusGridlineStroke(stroke21);
        java.awt.Paint paint23 = polarPlot1.getAngleLabelPaint();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = statisticalLineAndShapeRenderer2.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = statisticalLineAndShapeRenderer2.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer15.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint21 = statisticalLineAndShapeRenderer15.getItemOutlinePaint((-1), 0);
        statisticalLineAndShapeRenderer2.setBaseOutlinePaint(paint21, true);
        java.awt.Font font26 = statisticalLineAndShapeRenderer2.getItemLabelFont(8, 8);
        java.awt.Stroke stroke28 = null;
        statisticalLineAndShapeRenderer2.setSeriesOutlineStroke(2, stroke28, true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor31 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.jfree.chart.text.TextAnchor textAnchor32 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor33 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor31, textAnchor32, textAnchor33, 1.0d);
        statisticalLineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition35, false);
        boolean boolean40 = statisticalLineAndShapeRenderer2.getItemShapeVisible(2, 0);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = null;
        java.awt.Font font44 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("hi!", font44);
        java.lang.String str46 = textTitle45.getToolTipText();
        textTitle45.setWidth(0.0d);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent49 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle45);
        java.awt.Color color50 = java.awt.Color.cyan;
        boolean boolean51 = textTitle45.equals((java.lang.Object) color50);
        java.awt.Graphics2D graphics2D52 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = categoryAxis53.getLabelInsets();
        double double56 = rectangleInsets54.trimWidth((double) (byte) 10);
        double double58 = rectangleInsets54.calculateTopInset((-1.0d));
        double double60 = rectangleInsets54.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock62 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str63 = labelBlock62.getToolTipText();
        java.lang.String str64 = labelBlock62.getURLText();
        java.awt.geom.Rectangle2D rectangle2D65 = labelBlock62.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType66 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType67 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str68 = lengthAdjustmentType67.toString();
        java.awt.geom.Rectangle2D rectangle2D69 = rectangleInsets54.createAdjustedRectangle(rectangle2D65, lengthAdjustmentType66, lengthAdjustmentType67);
        java.lang.Object obj70 = null;
        java.lang.Object obj71 = textTitle45.draw(graphics2D52, rectangle2D65, obj70);
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = null;
        double double73 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D65, rectangleEdge72);
        try {
            statisticalLineAndShapeRenderer2.drawBackground(graphics2D41, categoryPlot42, rectangle2D65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(itemLabelAnchor31);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertNotNull(textAnchor33);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 4.0d + "'", double56 == 4.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 3.0d + "'", double58 == 3.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 3.0d + "'", double60 == 3.0d);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertNull(str64);
        org.junit.Assert.assertNotNull(rectangle2D65);
        org.junit.Assert.assertNotNull(lengthAdjustmentType66);
        org.junit.Assert.assertNotNull(lengthAdjustmentType67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "CONTRACT" + "'", str68.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D69);
        org.junit.Assert.assertNull(obj71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.lang.String str1 = polarPlot0.getNoDataMessage();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        polarPlot0.rendererChanged(rendererChangeEvent2);
        polarPlot0.addCornerTextItem("NOID");
        java.awt.Stroke stroke6 = polarPlot0.getOutlineStroke();
        java.awt.Color color7 = java.awt.Color.GRAY;
        polarPlot0.setAngleLabelPaint((java.awt.Paint) color7);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Layer.BACKGROUND");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint6 = null;
        ringPlot5.setShadowPaint(paint6);
        double double8 = ringPlot5.getMaximumLabelWidth();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot5);
        java.awt.Stroke stroke10 = ringPlot5.getLabelLinkStroke();
        polarPlot0.setOutlineStroke(stroke10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.lang.Object obj1 = null;
        boolean boolean2 = paintList0.equals(obj1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint5 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        categoryAxis4.setTickMarkPaint(paint5);
        paintList0.setPaint(2958465, paint5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = statisticalLineAndShapeRenderer2.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = statisticalLineAndShapeRenderer2.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer15.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint21 = statisticalLineAndShapeRenderer15.getItemOutlinePaint((-1), 0);
        statisticalLineAndShapeRenderer2.setBaseOutlinePaint(paint21, true);
        java.awt.Font font26 = statisticalLineAndShapeRenderer2.getItemLabelFont(8, 8);
        java.awt.Stroke stroke28 = null;
        statisticalLineAndShapeRenderer2.setSeriesOutlineStroke(2, stroke28, true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor31 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.jfree.chart.text.TextAnchor textAnchor32 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor33 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor31, textAnchor32, textAnchor33, 1.0d);
        statisticalLineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition35, false);
        java.awt.Color color38 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        statisticalLineAndShapeRenderer2.setBasePaint((java.awt.Paint) color38);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(itemLabelAnchor31);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertNotNull(textAnchor33);
        org.junit.Assert.assertNotNull(color38);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int1 = taskSeriesCollection0.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries3 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection0.add(taskSeries3);
        org.jfree.data.gantt.TaskSeries taskSeries6 = taskSeriesCollection0.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, (java.lang.Comparable) "CONTRACT");
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        piePlot3D9.setDepthFactor(12.0d);
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean13 = polarPlot12.isOutlineVisible();
        polarPlot12.setRadiusGridlinesVisible(true);
        float float16 = polarPlot12.getBackgroundAlpha();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        polarPlot12.setDataset(xYDataset17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        polarPlot12.zoomDomainAxes((double) 6, (double) (byte) -1, plotRenderingInfo21, point2D22);
        boolean boolean24 = piePlot3D9.equals((java.lang.Object) polarPlot12);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator25 = piePlot3D9.getToolTipGenerator();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(taskSeries6);
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(pieToolTipGenerator25);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = statisticalLineAndShapeRenderer2.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = statisticalLineAndShapeRenderer2.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer15.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint21 = statisticalLineAndShapeRenderer15.getItemOutlinePaint((-1), 0);
        statisticalLineAndShapeRenderer2.setBaseOutlinePaint(paint21, true);
        int int24 = statisticalLineAndShapeRenderer2.getRowCount();
        java.awt.Paint paint25 = statisticalLineAndShapeRenderer2.getBaseItemLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (short) 100, (double) 4);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint14 = statisticalLineAndShapeRenderer8.getItemOutlinePaint((-1), 0);
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape5, paint14);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer18.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint24 = statisticalLineAndShapeRenderer18.getItemOutlinePaint((-1), 0);
        boolean boolean26 = statisticalLineAndShapeRenderer18.isSeriesItemLabelsVisible(0);
        boolean boolean28 = statisticalLineAndShapeRenderer18.equals((java.lang.Object) 0.4d);
        java.awt.Color color29 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        statisticalLineAndShapeRenderer18.setBaseItemLabelPaint((java.awt.Paint) color29, false);
        legendGraphic15.setFillPaint((java.awt.Paint) color29);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(color29);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        statisticalLineAndShapeRenderer2.setUseFillPaint(false);
        boolean boolean10 = statisticalLineAndShapeRenderer2.getAutoPopulateSeriesOutlinePaint();
        boolean boolean11 = statisticalLineAndShapeRenderer2.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer14 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer14.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint20 = statisticalLineAndShapeRenderer14.getItemOutlinePaint((-1), 0);
        boolean boolean23 = statisticalLineAndShapeRenderer14.getItemVisible(7, (int) (short) 10);
        statisticalLineAndShapeRenderer14.setBaseCreateEntities(true, false);
        org.jfree.chart.LegendItem legendItem29 = statisticalLineAndShapeRenderer14.getLegendItem((int) (byte) 0, (int) (byte) 100);
        java.awt.Paint paint30 = statisticalLineAndShapeRenderer14.getBaseOutlinePaint();
        statisticalLineAndShapeRenderer2.setBaseItemLabelPaint(paint30);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(legendItem29);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) 1.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint(range3, (double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, range3);
        org.jfree.data.Range range7 = rectangleConstraint6.getWidthRange();
        org.jfree.data.Range range8 = null;
        org.jfree.data.Range range10 = org.jfree.data.Range.expandToInclude(range8, (double) 1.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint(range10, (double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint6.toRangeHeight(range10);
        org.jfree.data.Range range14 = rectangleConstraint6.getWidthRange();
        double double15 = rectangleConstraint6.getWidth();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        java.awt.Stroke stroke10 = statisticalLineAndShapeRenderer2.getItemOutlineStroke(4, (int) '4');
        org.jfree.chart.LegendItem legendItem13 = statisticalLineAndShapeRenderer2.getLegendItem((int) (short) -1, (int) ' ');
        java.awt.Color color15 = java.awt.Color.GREEN;
        statisticalLineAndShapeRenderer2.setSeriesItemLabelPaint(1, (java.awt.Paint) color15, true);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color22 = java.awt.Color.black;
        float[] floatArray28 = new float[] { 1, (short) 10, (short) 10, (short) -1, (-1) };
        float[] floatArray29 = color22.getRGBComponents(floatArray28);
        float[] floatArray30 = color21.getColorComponents(floatArray28);
        float[] floatArray31 = java.awt.Color.RGBtoHSB((int) (short) -1, (int) (byte) 1, (int) (short) 0, floatArray30);
        float[] floatArray32 = color15.getRGBColorComponents(floatArray31);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(legendItem13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D2 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list3 = defaultKeyedValues2D2.getRowKeys();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str6 = spreadsheetDate5.getDescription();
        int int7 = spreadsheetDate5.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str10 = spreadsheetDate9.getDescription();
        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate5.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int12 = defaultKeyedValues2D2.getRowIndex((java.lang.Comparable) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(1, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int1 = taskSeriesCollection0.getColumnCount();
        java.util.List list2 = taskSeriesCollection0.getColumnKeys();
        int int3 = taskSeriesCollection0.getColumnCount();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        dateAxis5.setRangeWithMargins((double) 1L, 12.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = dateAxis5.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource11 = dateAxis10.getStandardTickUnits();
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis10.setRangeWithMargins((org.jfree.data.Range) dateRange14, false, false);
        dateAxis10.setAutoRange(false);
        java.util.Date date20 = dateAxis10.getMinimumDate();
        java.util.Date date21 = dateTickUnit9.rollDate(date20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        java.util.TimeZone timeZone23 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21, timeZone23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.previous();
        try {
            java.lang.Number number26 = taskSeriesCollection0.getValue((java.lang.Comparable) (short) 1, (java.lang.Comparable) year24);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(tickUnitSource11);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone0;
        org.junit.Assert.assertNotNull(timeZone0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        java.lang.Number number5 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) 1, (java.lang.Comparable) (short) 0);
        double double7 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getRowCount();
        int int4 = defaultKeyedValues2D1.getColumnIndex((java.lang.Comparable) 0);
        java.lang.Object obj5 = defaultKeyedValues2D1.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        jFreeChart4.setTitle("hi!");
        java.lang.Object obj7 = jFreeChart4.getTextAntiAlias();
        org.jfree.chart.title.TextTitle textTitle8 = jFreeChart4.getTitle();
        jFreeChart4.setBackgroundImageAlpha((float) 1L);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart4.removeProgressListener(chartProgressListener11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNotNull(textTitle8);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("PlotOrientation.VERTICAL");
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("Tuesday");
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        statisticalLineAndShapeRenderer2.setSeriesShapesFilled(8, (java.lang.Boolean) false);
        java.awt.Paint paint11 = statisticalLineAndShapeRenderer2.getItemLabelPaint(8, (int) (byte) 10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorLeft((double) (byte) 1);
        axisState0.cursorDown(0.25d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) 1.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint(range3, (double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, range3);
        org.jfree.data.Range range7 = rectangleConstraint6.getWidthRange();
        org.jfree.data.Range range8 = null;
        org.jfree.data.Range range10 = org.jfree.data.Range.expandToInclude(range8, (double) 1.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint(range10, (double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint6.toRangeHeight(range10);
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint13.toRangeWidth(range14);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.lang.Number number7 = null;
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D9 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list10 = defaultKeyedValues2D9.getRowKeys();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem11 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 3, (java.lang.Number) 2958465, (java.lang.Number) (-1.0f), (java.lang.Number) 0.05d, (java.lang.Number) 10.0d, (java.lang.Number) (-1), (java.lang.Number) (byte) 100, number7, list10);
        java.lang.Number number12 = boxAndWhiskerItem11.getQ1();
        java.lang.Number number13 = boxAndWhiskerItem11.getMean();
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.0f) + "'", number12.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 3 + "'", number13.equals(3));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint8 = statisticalLineAndShapeRenderer2.getItemOutlinePaint((-1), 0);
        boolean boolean10 = statisticalLineAndShapeRenderer2.isSeriesItemLabelsVisible(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = statisticalLineAndShapeRenderer2.getLegendItemToolTipGenerator();
        boolean boolean12 = statisticalLineAndShapeRenderer2.getBaseSeriesVisibleInLegend();
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = barRenderer13.getPlot();
        int int15 = barRenderer13.getColumnCount();
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block17 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer20 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean21 = statisticalLineAndShapeRenderer20.getBaseItemLabelsVisible();
        int int22 = statisticalLineAndShapeRenderer20.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = null;
        statisticalLineAndShapeRenderer20.setSeriesNegativeItemLabelPosition(0, itemLabelPosition24);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator28 = statisticalLineAndShapeRenderer20.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = statisticalLineAndShapeRenderer20.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        flowArrangement16.add(block17, (java.lang.Object) itemLabelPosition30);
        barRenderer13.setNegativeItemLabelPositionFallback(itemLabelPosition30);
        statisticalLineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition30);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(categoryPlot14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator28);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer4.setMaximumBarWidth((double) 2);
        java.awt.Shape shape8 = barRenderer4.lookupSeriesShape(2958465);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer11 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean12 = statisticalLineAndShapeRenderer11.getBaseItemLabelsVisible();
        int int13 = statisticalLineAndShapeRenderer11.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = null;
        statisticalLineAndShapeRenderer11.setSeriesNegativeItemLabelPosition(0, itemLabelPosition15);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = statisticalLineAndShapeRenderer11.getURLGenerator(100, (int) (short) 10);
        statisticalLineAndShapeRenderer11.setSeriesLinesVisible(15, false);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color24 = java.awt.Color.black;
        float[] floatArray30 = new float[] { 1, (short) 10, (short) 10, (short) -1, (-1) };
        float[] floatArray31 = color24.getRGBComponents(floatArray30);
        float[] floatArray32 = color23.getColorComponents(floatArray30);
        int int33 = color23.getBlue();
        statisticalLineAndShapeRenderer11.setErrorIndicatorPaint((java.awt.Paint) color23);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = xYPlot35.getRangeAxisEdge(0);
        boolean boolean38 = xYPlot35.isRangeZeroBaselineVisible();
        java.awt.Paint paint39 = xYPlot35.getRangeZeroBaselinePaint();
        boolean boolean40 = xYPlot35.isRangeZeroBaselineVisible();
        boolean boolean41 = xYPlot35.isDomainCrosshairVisible();
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot44 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke45 = polarPlot44.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker46 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', (java.awt.Paint) color43, stroke45);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection47 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int48 = taskSeriesCollection47.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries50 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection47.add(taskSeries50);
        org.jfree.data.gantt.TaskSeries taskSeries53 = taskSeriesCollection47.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset55 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection47, (java.lang.Comparable) "CONTRACT");
        boolean boolean56 = categoryMarker46.equals((java.lang.Object) taskSeriesCollection47);
        java.awt.Color color57 = java.awt.Color.GREEN;
        categoryMarker46.setPaint((java.awt.Paint) color57);
        org.jfree.chart.util.Layer layer59 = null;
        xYPlot35.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker46, layer59);
        java.awt.Stroke stroke61 = categoryMarker46.getOutlineStroke();
        java.awt.Color color62 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        try {
            org.jfree.chart.LegendItem legendItem63 = new org.jfree.chart.LegendItem(attributedString0, "ERROR : Relative To String", "RectangleConstraintType.RANGE", "ClassContext", shape8, (java.awt.Paint) color23, stroke61, (java.awt.Paint) color62);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator19);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNull(taskSeries53);
        org.junit.Assert.assertNotNull(pieDataset55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(color62);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.LegendItem legendItem3 = areaRenderer0.getLegendItem(2, 0);
        java.awt.Shape shape4 = areaRenderer0.getBaseShape();
        java.lang.Object obj5 = areaRenderer0.clone();
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        java.awt.Image image4 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image4, "", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray9 = projectInfo8.getLibraries();
        java.lang.String str10 = projectInfo8.getName();
        boolean boolean11 = borderArrangement0.equals((java.lang.Object) projectInfo8);
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        boolean boolean13 = borderArrangement0.equals((java.lang.Object) ringPlot12);
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean15 = polarPlot14.isOutlineVisible();
        polarPlot14.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot14);
        jFreeChart18.setTitle("hi!");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType21 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) ringPlot12, jFreeChart18, chartChangeEventType21);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType23 = chartChangeEvent22.getType();
        org.junit.Assert.assertNotNull(libraryArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(chartChangeEventType23);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 1, (double) (short) 10, false);
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean5 = polarPlot4.isOutlineVisible();
        polarPlot4.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot4);
        java.awt.Stroke stroke9 = jFreeChart8.getBorderStroke();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) false, jFreeChart8, 9999, (int) '4');
        org.jfree.chart.JFreeChart jFreeChart13 = chartProgressEvent12.getChart();
        jFreeChart13.setNotify(false);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            jFreeChart13.draw(graphics2D16, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(jFreeChart13);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 1, (double) (short) 10, false);
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean5 = polarPlot4.isOutlineVisible();
        polarPlot4.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot4);
        java.awt.Stroke stroke9 = jFreeChart8.getBorderStroke();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) false, jFreeChart8, 9999, (int) '4');
        jFreeChart8.removeLegend();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((-329600), 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("RectangleConstraintType.RANGE");
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset4.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.general.DatasetGroup datasetGroup10 = defaultStatisticalCategoryDataset4.getGroup();
        java.lang.Comparable comparable12 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity13 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "hi!", "", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, (java.lang.Comparable) 1.0d, comparable12);
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint15 = polarPlot14.getOutlinePaint();
        java.awt.Stroke stroke16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot14.setOutlineStroke(stroke16);
        java.lang.String str18 = polarPlot14.getPlotType();
        int int19 = polarPlot14.getBackgroundImageAlignment();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryAxis20.getLabelInsets();
        java.awt.Stroke stroke22 = categoryAxis20.getAxisLineStroke();
        float float23 = categoryAxis20.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent24 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis20);
        org.jfree.chart.axis.Axis axis25 = axisChangeEvent24.getAxis();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer28 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean29 = statisticalLineAndShapeRenderer28.getBaseItemLabelsVisible();
        int int30 = statisticalLineAndShapeRenderer28.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = null;
        statisticalLineAndShapeRenderer28.setSeriesNegativeItemLabelPosition(0, itemLabelPosition32);
        java.awt.Stroke stroke36 = statisticalLineAndShapeRenderer28.getItemOutlineStroke(4, (int) '4');
        statisticalLineAndShapeRenderer28.setItemLabelAnchorOffset((double) (short) 1);
        java.awt.Stroke stroke39 = statisticalLineAndShapeRenderer28.getBaseOutlineStroke();
        axis25.setTickMarkStroke(stroke39);
        polarPlot14.setAngleGridlineStroke(stroke39);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent42 = null;
        polarPlot14.datasetChanged(datasetChangeEvent42);
        boolean boolean44 = defaultStatisticalCategoryDataset4.hasListener((java.util.EventListener) polarPlot14);
        org.jfree.chart.plot.RingPlot ringPlot45 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint46 = null;
        ringPlot45.setShadowPaint(paint46);
        double double48 = ringPlot45.getMaximumLabelWidth();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent49 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot45);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        ringPlot45.setExplodePercent((java.lang.Comparable) 'a', (double) 100);
        polarPlot14.setParent((org.jfree.chart.plot.Plot) ringPlot45);
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) ringPlot45);
        ringPlot45.setLabelLinkMargin((double) 11);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(datasetGroup10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Polar Plot" + "'", str18.equals("Polar Plot"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.0f + "'", float23 == 0.0f);
        org.junit.Assert.assertNotNull(axis25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.2d + "'", double48 == 0.2d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = 15;
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        boolean boolean1 = outlierListCollection0.isHighFarOut();
        outlierListCollection0.setHighFarOut(false);
        outlierListCollection0.setLowFarOut(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D2 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int3 = defaultKeyedValues2D2.getRowCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str8 = spreadsheetDate7.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str11 = spreadsheetDate10.getDescription();
        int int12 = spreadsheetDate10.getDayOfWeek();
        boolean boolean13 = spreadsheetDate7.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        defaultKeyedValues2D2.addValue((java.lang.Number) 2958465, (java.lang.Comparable) 100.0f, (java.lang.Comparable) spreadsheetDate7);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate7);
        java.lang.String str16 = serialDate15.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "25-May-1927" + "'", str16.equals("25-May-1927"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        java.lang.String str4 = polarPlot3.getNoDataMessage();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        polarPlot3.rendererChanged(rendererChangeEvent5);
        polarPlot3.addCornerTextItem("NOID");
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        polarPlot3.setRadiusGridlineStroke(stroke9);
        boolean boolean11 = dateRange2.equals((java.lang.Object) polarPlot3);
        java.lang.String str12 = dateRange2.toString();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str12.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        java.awt.Font font5 = statisticalLineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, rectangleAnchor8, (double) (short) 100, (double) 4);
        statisticalLineAndShapeRenderer2.setBaseShape(shape11, false);
        boolean boolean14 = statisticalLineAndShapeRenderer2.getUseFillPaint();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        dateAxis15.resizeRange(1.0d);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer20 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean21 = statisticalLineAndShapeRenderer20.getBaseItemLabelsVisible();
        int int22 = statisticalLineAndShapeRenderer20.getPassCount();
        java.awt.Font font23 = statisticalLineAndShapeRenderer20.getBaseItemLabelFont();
        dateAxis15.setLabelFont(font23);
        statisticalLineAndShapeRenderer2.setBaseItemLabelFont(font23, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getOutlinePaint();
        java.awt.Stroke stroke2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot0.setOutlineStroke(stroke2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisSpace axisSpace5 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis6.getLabelInsets();
        double double9 = rectangleInsets7.trimWidth((double) (byte) 10);
        double double11 = rectangleInsets7.calculateTopInset((-1.0d));
        double double13 = rectangleInsets7.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str16 = labelBlock15.getToolTipText();
        java.lang.String str17 = labelBlock15.getURLText();
        java.awt.geom.Rectangle2D rectangle2D18 = labelBlock15.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType19 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType20 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str21 = lengthAdjustmentType20.toString();
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets7.createAdjustedRectangle(rectangle2D18, lengthAdjustmentType19, lengthAdjustmentType20);
        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str25 = labelBlock24.getToolTipText();
        java.lang.String str26 = labelBlock24.getURLText();
        java.awt.geom.Rectangle2D rectangle2D27 = labelBlock24.getBounds();
        java.awt.geom.Rectangle2D rectangle2D28 = axisSpace5.shrink(rectangle2D22, rectangle2D27);
        polarPlot0.drawBackgroundImage(graphics2D4, rectangle2D28);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer30 = null;
        polarPlot0.setRenderer(polarItemRenderer30);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.0d + "'", double13 == 3.0d);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(lengthAdjustmentType19);
        org.junit.Assert.assertNotNull(lengthAdjustmentType20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "CONTRACT" + "'", str21.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D28);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean4 = statisticalLineAndShapeRenderer3.getBaseItemLabelsVisible();
        int int5 = statisticalLineAndShapeRenderer3.getPassCount();
        java.awt.Font font6 = statisticalLineAndShapeRenderer3.getBaseItemLabelFont();
        java.awt.Paint paint7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("CONTRACT", font6, paint7, (float) '4');
        float float10 = textFragment9.getBaselineOffset();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 52.0f + "'", float10 == 52.0f);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        java.util.TimeZone timeZone0 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
        org.junit.Assert.assertNotNull(timeZone0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("hi!", font2);
        java.awt.Paint paint4 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("({0}, {1}) = {2}", font2, paint4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.Shape shape9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset12 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset12.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.general.DatasetGroup datasetGroup18 = defaultStatisticalCategoryDataset12.getGroup();
        java.lang.Comparable comparable20 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity21 = new org.jfree.chart.entity.CategoryItemEntity(shape9, "hi!", "", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12, (java.lang.Comparable) 1.0d, comparable20);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer24 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean25 = statisticalLineAndShapeRenderer24.getBaseItemLabelsVisible();
        int int26 = statisticalLineAndShapeRenderer24.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = null;
        statisticalLineAndShapeRenderer24.setSeriesNegativeItemLabelPosition(0, itemLabelPosition28);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator32 = statisticalLineAndShapeRenderer24.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = statisticalLineAndShapeRenderer24.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor35 = itemLabelPosition34.getRotationAnchor();
        boolean boolean36 = defaultStatisticalCategoryDataset12.equals((java.lang.Object) textAnchor35);
        try {
            textLine5.draw(graphics2D6, (float) '#', (float) 3, textAnchor35, (float) (byte) 10, (float) (byte) 100, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(datasetGroup18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator32);
        org.junit.Assert.assertNotNull(itemLabelPosition34);
        org.junit.Assert.assertNotNull(textAnchor35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        java.awt.Color color0 = java.awt.Color.PINK;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str1.equals("java.awt.Color[r=255,g=175,b=175]"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint8 = statisticalLineAndShapeRenderer2.getItemOutlinePaint((-1), 0);
        boolean boolean11 = statisticalLineAndShapeRenderer2.getItemVisible(7, (int) (short) 10);
        statisticalLineAndShapeRenderer2.setBaseCreateEntities(true, false);
        org.jfree.chart.LegendItem legendItem17 = statisticalLineAndShapeRenderer2.getLegendItem((int) (byte) 0, (int) (byte) 100);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = statisticalLineAndShapeRenderer2.getSeriesURLGenerator(500);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(legendItem17);
        org.junit.Assert.assertNull(categoryURLGenerator19);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis0);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis0.getTickMarkPosition();
        boolean boolean3 = dateAxis0.isInverted();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent5 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis4);
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis4.setTickUnit(dateTickUnit6);
        java.util.Date date8 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit6);
        java.awt.Shape shape9 = dateAxis0.getUpArrow();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = dateAxis0.getTickUnit();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean14 = statisticalLineAndShapeRenderer13.getBaseItemLabelsVisible();
        int int15 = statisticalLineAndShapeRenderer13.getPassCount();
        java.awt.Font font16 = statisticalLineAndShapeRenderer13.getBaseItemLabelFont();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape18, rectangleAnchor19, (double) (short) 100, (double) 4);
        statisticalLineAndShapeRenderer13.setBaseShape(shape22, false);
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.clone(shape22);
        dateAxis0.setLeftArrow(shape25);
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape25);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        textBlock0.draw(graphics2D1, (float) (byte) 100, (float) (byte) 1, textBlockAnchor4, (float) 7, (float) '4', (double) (short) 100);
        java.util.List list9 = textBlock0.getLines();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        textBlock0.draw(graphics2D10, (float) 100, (float) '#', textBlockAnchor13);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        statisticalLineAndShapeRenderer2.setUseFillPaint(false);
        java.awt.Paint paint11 = statisticalLineAndShapeRenderer2.getSeriesItemLabelPaint(3);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalLineAndShapeRenderer2.getLegendItemURLGenerator();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot13.getRangeAxisEdge(0);
        java.awt.Stroke stroke16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYPlot13.setRangeCrosshairStroke(stroke16);
        statisticalLineAndShapeRenderer2.setBaseOutlineStroke(stroke16, false);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer23 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean24 = statisticalLineAndShapeRenderer23.getBaseItemLabelsVisible();
        int int25 = statisticalLineAndShapeRenderer23.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = null;
        statisticalLineAndShapeRenderer23.setSeriesNegativeItemLabelPosition(0, itemLabelPosition27);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator31 = statisticalLineAndShapeRenderer23.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = statisticalLineAndShapeRenderer23.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(11, itemLabelPosition33);
        boolean boolean35 = statisticalLineAndShapeRenderer2.getUseFillPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator31);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 128);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        categoryAxis0.setTickMarkPaint(paint1);
        java.lang.String str3 = categoryAxis0.getLabel();
        categoryAxis0.setLabelAngle((double) '#');
        boolean boolean6 = categoryAxis0.isAxisLineVisible();
        org.jfree.data.Range range7 = null;
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude(range7, (double) 1.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint(range9, (double) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryAxis12.getLabelInsets();
        double double15 = rectangleInsets13.trimWidth((double) (byte) 10);
        boolean boolean16 = range9.equals((java.lang.Object) rectangleInsets13);
        categoryAxis0.setTickLabelInsets(rectangleInsets13);
        org.jfree.data.Range range18 = null;
        org.jfree.data.Range range20 = org.jfree.data.Range.expandToInclude(range18, (double) 1.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint(range20, (double) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = categoryAxis23.getLabelInsets();
        double double26 = rectangleInsets24.trimWidth((double) (byte) 10);
        boolean boolean27 = range20.equals((java.lang.Object) rectangleInsets24);
        double double29 = rectangleInsets24.calculateBottomInset((double) (-329600));
        categoryAxis0.setLabelInsets(rectangleInsets24);
        categoryAxis0.setUpperMargin((double) (short) 100);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 3.0d + "'", double29 == 3.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYPlot0.setRangeCrosshairStroke(stroke3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot0.setRenderer((int) (short) 1, xYItemRenderer6);
        xYPlot0.mapDatasetToRangeAxis((-329600), (int) (short) -1);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer13.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint17 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        statisticalLineAndShapeRenderer13.setBasePaint(paint17);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = categoryAxis19.getLabelInsets();
        java.awt.Stroke stroke21 = categoryAxis19.getAxisLineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = categoryAxis22.getLabelInsets();
        double double25 = rectangleInsets23.trimWidth((double) (byte) 10);
        double double27 = rectangleInsets23.calculateTopInset((-1.0d));
        org.jfree.chart.block.LineBorder lineBorder28 = new org.jfree.chart.block.LineBorder(paint17, stroke21, rectangleInsets23);
        xYPlot0.setAxisOffset(rectangleInsets23);
        org.jfree.chart.util.UnitType unitType30 = rectangleInsets23.getUnitType();
        double double32 = rectangleInsets23.calculateBottomOutset((double) 35L);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertNotNull(unitType30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.0d + "'", double32 == 3.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str1 = dateTickUnit0.toString();
        int int2 = dateTickUnit0.getRollUnit();
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickUnit[DAY, 1]" + "'", str1.equals("DateTickUnit[DAY, 1]"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getLabelLinkPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(pieSectionLabelGenerator2);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYPlot0.setRangeCrosshairStroke(stroke3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot0.getDataset();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke9 = polarPlot8.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', (java.awt.Paint) color7, stroke9);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection11 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int12 = taskSeriesCollection11.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries14 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection11.add(taskSeries14);
        org.jfree.data.gantt.TaskSeries taskSeries17 = taskSeriesCollection11.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection11, (java.lang.Comparable) "CONTRACT");
        boolean boolean20 = categoryMarker10.equals((java.lang.Object) taskSeriesCollection11);
        java.awt.Color color21 = java.awt.Color.GREEN;
        categoryMarker10.setPaint((java.awt.Paint) color21);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10);
        int int24 = xYPlot0.getDatasetCount();
        java.awt.Paint paint25 = xYPlot0.getRangeTickBandPaint();
        xYPlot0.configureRangeAxes();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(taskSeries17);
        org.junit.Assert.assertNotNull(pieDataset19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNull(paint25);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("Polar Plot");
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str2 = labelBlock1.getToolTipText();
        labelBlock1.setPadding((double) (short) 1, 0.0d, (double) 0, (double) (-1.0f));
        java.awt.Font font8 = labelBlock1.getFont();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int1 = taskSeriesCollection0.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries3 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection0.add(taskSeries3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        taskSeries3.addPropertyChangeListener(propertyChangeListener5);
        java.lang.Object obj7 = taskSeries3.clone();
        taskSeries3.setNotify(false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D2 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int3 = defaultKeyedValues2D2.getRowCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str8 = spreadsheetDate7.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str11 = spreadsheetDate10.getDescription();
        int int12 = spreadsheetDate10.getDayOfWeek();
        boolean boolean13 = spreadsheetDate7.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        defaultKeyedValues2D2.addValue((java.lang.Number) 2958465, (java.lang.Comparable) 100.0f, (java.lang.Comparable) spreadsheetDate7);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate7);
        java.awt.Paint paint16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke18 = categoryAxis17.getTickMarkStroke();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer21 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer21.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint27 = statisticalLineAndShapeRenderer21.getItemOutlinePaint((-1), 0);
        boolean boolean30 = statisticalLineAndShapeRenderer21.getItemVisible(7, (int) (short) 10);
        statisticalLineAndShapeRenderer21.setBaseCreateEntities(true, false);
        org.jfree.chart.LegendItem legendItem36 = statisticalLineAndShapeRenderer21.getLegendItem((int) (byte) 0, (int) (byte) 100);
        java.awt.Paint paint37 = statisticalLineAndShapeRenderer21.getBaseOutlinePaint();
        org.jfree.chart.plot.PolarPlot polarPlot38 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean39 = polarPlot38.isOutlineVisible();
        polarPlot38.setRadiusGridlinesVisible(true);
        float float42 = polarPlot38.getBackgroundAlpha();
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        polarPlot38.setDataset(xYDataset43);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        java.awt.geom.Point2D point2D48 = null;
        polarPlot38.zoomDomainAxes((double) 6, (double) (byte) -1, plotRenderingInfo47, point2D48);
        java.awt.Stroke stroke50 = polarPlot38.getRadiusGridlineStroke();
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker52 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) serialDate15, paint16, stroke18, paint37, stroke50, (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(legendItem36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 1.0f + "'", float42 == 1.0f);
        org.junit.Assert.assertNotNull(stroke50);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        java.lang.Class class0 = null;
        try {
            boolean boolean1 = org.jfree.chart.util.SerialUtilities.isSerializable(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint8 = statisticalLineAndShapeRenderer2.getItemOutlinePaint((-1), 0);
        boolean boolean9 = statisticalLineAndShapeRenderer2.getUseOutlinePaint();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = statisticalLineAndShapeRenderer2.getItemLabelGenerator(10, 10);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean16 = statisticalLineAndShapeRenderer15.getBaseItemLabelsVisible();
        int int17 = statisticalLineAndShapeRenderer15.getPassCount();
        java.awt.Font font18 = statisticalLineAndShapeRenderer15.getBaseItemLabelFont();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape20, rectangleAnchor21, (double) (short) 100, (double) 4);
        statisticalLineAndShapeRenderer15.setBaseShape(shape24, false);
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.clone(shape24);
        statisticalLineAndShapeRenderer2.setBaseShape(shape27);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape27);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.0d, (double) 1.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.geom.Rectangle2D rectangle2D6 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D2, (double) 100L, (double) 0L, rectangleAnchor5);
        java.lang.String str7 = size2D2.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Size2D[width=0.0, height=1.0]" + "'", str7.equals("Size2D[width=0.0, height=1.0]"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("CONTRACT", font1);
        java.lang.String str3 = textTitle2.getText();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint5 = null;
        ringPlot4.setShadowPaint(paint5);
        java.awt.Paint paint7 = ringPlot4.getSeparatorPaint();
        textTitle2.setBackgroundPaint(paint7);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CONTRACT" + "'", str3.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("({0}, {1}) = {3} - {4}");
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        java.lang.Object obj5 = null;
        boolean boolean6 = xYPlot0.equals(obj5);
        xYPlot0.setRangeCrosshairValue((double) ' ');
        java.awt.Stroke stroke9 = xYPlot0.getDomainCrosshairStroke();
        xYPlot0.setWeight(0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis0);
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit2);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis0);
        java.awt.Paint paint5 = dateAxis0.getTickMarkPaint();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 1.0E-5d);
        int int2 = keyToGroupMap1.getGroupCount();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.setRangeWithMargins((double) 1L, 12.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = dateAxis3.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = dateAxis8.getStandardTickUnits();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis8.setRangeWithMargins((org.jfree.data.Range) dateRange12, false, false);
        dateAxis8.setAutoRange(false);
        java.util.Date date18 = dateAxis8.getMinimumDate();
        java.util.Date date19 = dateTickUnit7.rollDate(date18);
        int int20 = keyToGroupMap1.getGroupIndex((java.lang.Comparable) date18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(dateTickUnit7);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setShadowXOffset((double) (byte) 10);
        ringPlot0.setInnerSeparatorExtension((double) (byte) 10);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        jFreeChart4.setTitle("hi!");
        java.lang.Object obj7 = jFreeChart4.getTextAntiAlias();
        java.lang.Object obj8 = jFreeChart4.clone();
        jFreeChart4.setNotify(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int1 = taskSeriesCollection0.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries3 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection0.add(taskSeries3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        taskSeries3.addPropertyChangeListener(propertyChangeListener5);
        java.lang.Object obj7 = taskSeries3.clone();
        taskSeries3.setDescription("({0}, {1}) = {2}");
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.awt.Image image14 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo18 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image14, "", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray19 = projectInfo18.getLibraries();
        boolean boolean20 = textAnchor10.equals((java.lang.Object) projectInfo18);
        java.awt.Image image21 = null;
        projectInfo18.setLogo(image21);
        boolean boolean23 = taskSeries3.equals((java.lang.Object) image21);
        java.lang.Object obj24 = taskSeries3.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(libraryArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        java.lang.Object obj5 = null;
        boolean boolean6 = xYPlot0.equals(obj5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomDomainAxes((double) 0L, plotRenderingInfo8, point2D9);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean14 = statisticalLineAndShapeRenderer13.getBaseItemLabelsVisible();
        int int15 = statisticalLineAndShapeRenderer13.getPassCount();
        java.awt.Font font16 = statisticalLineAndShapeRenderer13.getBaseItemLabelFont();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape18, rectangleAnchor19, (double) (short) 100, (double) 4);
        statisticalLineAndShapeRenderer13.setBaseShape(shape22, false);
        boolean boolean25 = statisticalLineAndShapeRenderer13.getUseFillPaint();
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalLineAndShapeRenderer13);
        java.awt.Paint paint27 = legendTitle26.getItemPaint();
        java.awt.Paint paint28 = legendTitle26.getItemPaint();
        xYPlot0.setDomainCrosshairPaint(paint28);
        java.awt.Paint paint30 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        xYPlot0.setRangeCrosshairPaint(paint30);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        boolean boolean3 = textTitle2.getNotify();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str2 = spreadsheetDate1.getDescription();
        int int3 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str6 = spreadsheetDate5.getDescription();
        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange((double) 15, 100.0d);
        try {
            int int11 = spreadsheetDate5.compareTo((java.lang.Object) 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Double cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        java.lang.Object obj5 = null;
        boolean boolean6 = xYPlot0.equals(obj5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomDomainAxes((double) 0L, plotRenderingInfo8, point2D9);
        xYPlot0.setDomainCrosshairValue((-1.0d));
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis13.getLabelInsets();
        double double16 = rectangleInsets14.trimWidth((double) (byte) 10);
        double double18 = rectangleInsets14.calculateLeftOutset(0.0d);
        double double20 = rectangleInsets14.calculateBottomOutset((double) (byte) 10);
        xYPlot0.setInsets(rectangleInsets14);
        double double23 = rectangleInsets14.extendHeight((double) (-1));
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.0d + "'", double18 == 3.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 3.0d + "'", double20 == 3.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 5.0d + "'", double23 == 5.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.lang.String str1 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str1.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = dateAxis4.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = dateAxis4.java2DToValue((double) 4, rectangle2D7, rectangleEdge8);
        java.awt.Shape shape10 = dateAxis4.getLeftArrow();
        int int11 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("hi!", font13);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer17 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer17.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint21 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        statisticalLineAndShapeRenderer17.setBasePaint(paint21);
        textTitle14.setBackgroundPaint(paint21);
        xYPlot0.setRangeZeroBaselinePaint(paint21);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        double double27 = dateAxis26.getUpperMargin();
        org.jfree.data.Range range28 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis26.setRange(range28, false, true);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        dateAxis32.setRangeWithMargins((double) 1L, 12.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit36 = dateAxis32.getTickUnit();
        dateAxis26.setTickUnit(dateTickUnit36, false, true);
        xYPlot0.setRangeAxis(7, (org.jfree.chart.axis.ValueAxis) dateAxis26, false);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 9.223372036854776E18d + "'", double9 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(dateTickUnit36);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        java.awt.Font font5 = statisticalLineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, rectangleAnchor8, (double) (short) 100, (double) 4);
        statisticalLineAndShapeRenderer2.setBaseShape(shape11, false);
        boolean boolean14 = statisticalLineAndShapeRenderer2.getUseFillPaint();
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalLineAndShapeRenderer2);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke17 = categoryAxis16.getTickMarkStroke();
        boolean boolean18 = legendTitle15.equals((java.lang.Object) stroke17);
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean20 = polarPlot19.isOutlineVisible();
        polarPlot19.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot19);
        jFreeChart23.setTitle("hi!");
        java.lang.Object obj26 = jFreeChart23.getTextAntiAlias();
        org.jfree.chart.title.TextTitle textTitle27 = jFreeChart23.getTitle();
        legendTitle15.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart23);
        java.awt.Paint paint29 = jFreeChart23.getBackgroundPaint();
        org.jfree.chart.event.ChartChangeListener chartChangeListener30 = null;
        try {
            jFreeChart23.removeChangeListener(chartChangeListener30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertNotNull(textTitle27);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        java.awt.Stroke stroke2 = categoryAxis0.getAxisLineStroke();
        categoryAxis0.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) 1.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint(range3, (double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, range3);
        org.jfree.data.Range range7 = rectangleConstraint6.getWidthRange();
        org.jfree.data.Range range8 = null;
        org.jfree.data.Range range10 = org.jfree.data.Range.expandToInclude(range8, (double) 1.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint(range10, (double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint6.toRangeHeight(range10);
        org.jfree.data.Range range14 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint6.toRangeWidth(range14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.lang.String str3 = textTitle2.getToolTipText();
        java.lang.String str4 = textTitle2.getText();
        java.lang.String str5 = textTitle2.getURLText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = ringPlot0.getLegendLabelGenerator();
        org.jfree.chart.plot.Plot plot4 = ringPlot0.getParent();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNull(plot4);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint8 = statisticalLineAndShapeRenderer2.getItemOutlinePaint((-1), 0);
        boolean boolean9 = statisticalLineAndShapeRenderer2.getUseOutlinePaint();
        statisticalLineAndShapeRenderer2.setSeriesShapesFilled((int) (short) 1, false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj1 = standardGradientPaintTransformer0.clone();
        java.lang.Object obj2 = standardGradientPaintTransformer0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 7, (float) 2958465, (float) 100L);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint1 = waterfallBarRenderer0.getLastBarPaint();
        java.awt.Paint paint2 = waterfallBarRenderer0.getPositiveBarPaint();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer6 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean7 = statisticalLineAndShapeRenderer6.getBaseItemLabelsVisible();
        int int8 = statisticalLineAndShapeRenderer6.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        statisticalLineAndShapeRenderer6.setSeriesNegativeItemLabelPosition(0, itemLabelPosition10);
        statisticalLineAndShapeRenderer6.setUseFillPaint(false);
        java.awt.Paint paint15 = statisticalLineAndShapeRenderer6.getSeriesItemLabelPaint(3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = statisticalLineAndShapeRenderer6.getSeriesNegativeItemLabelPosition(2);
        waterfallBarRenderer0.setSeriesPositiveItemLabelPosition(5, itemLabelPosition17, false);
        java.awt.Stroke stroke21 = waterfallBarRenderer0.getSeriesOutlineStroke((-460));
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNull(stroke21);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYPlot0.setRangeCrosshairStroke(stroke3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot0.getDataset();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot0.getDomainAxisEdge();
        java.awt.Stroke stroke7 = xYPlot0.getDomainZeroBaselineStroke();
        xYPlot0.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        jFreeChart4.setTitle("hi!");
        java.lang.Object obj7 = jFreeChart4.getTextAntiAlias();
        java.lang.Object obj8 = jFreeChart4.clone();
        jFreeChart4.setBorderVisible(false);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("hi!", font13);
        java.lang.String str15 = textTitle14.getToolTipText();
        textTitle14.setWidth(0.0d);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent18 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle14);
        try {
            jFreeChart4.addSubtitle(500, (org.jfree.chart.title.Title) textTitle14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        try {
            java.awt.Color color1 = java.awt.Color.decode("Pie 3D Plot");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Pie 3D Plot\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setStartAngle(0.0d);
        ringPlot0.setIgnoreNullValues(true);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = ringPlot0.getToolTipGenerator();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        boolean boolean9 = xYPlot6.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource11 = dateAxis10.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = dateAxis10.java2DToValue((double) 4, rectangle2D13, rectangleEdge14);
        java.awt.Shape shape16 = dateAxis10.getLeftArrow();
        int int17 = xYPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis10);
        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("hi!", font19);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer23 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer23.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint27 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        statisticalLineAndShapeRenderer23.setBasePaint(paint27);
        textTitle20.setBackgroundPaint(paint27);
        xYPlot6.setRangeZeroBaselinePaint(paint27);
        ringPlot0.setLabelLinkPaint(paint27);
        org.junit.Assert.assertNull(pieToolTipGenerator5);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(tickUnitSource11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 9.223372036854776E18d + "'", double15 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = null;
        try {
            multiplePiePlot0.setDataExtractOrder(tableOrder1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        boolean boolean2 = categoryAxis0.isAxisLineVisible();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        java.lang.String str5 = polarPlot4.getNoDataMessage();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        polarPlot4.rendererChanged(rendererChangeEvent6);
        polarPlot4.addCornerTextItem("NOID");
        java.awt.Font font10 = polarPlot4.getNoDataMessageFont();
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("", font10);
        categoryAxis0.setLabelFont(font10);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = xYPlot0.getOrientation();
        java.lang.String str6 = plotOrientation5.toString();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PlotOrientation.VERTICAL" + "'", str6.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        java.text.DateFormat dateFormat4 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(3, 128, (int) (short) -1, 0, dateFormat4);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        polarPlot3.markerChanged(markerChangeEvent4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        polarPlot3.drawBackgroundImage(graphics2D6, rectangle2D7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        polarPlot3.drawBackgroundImage(graphics2D9, rectangle2D10);
        boolean boolean12 = color2.equals((java.lang.Object) polarPlot3);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean16 = statisticalLineAndShapeRenderer15.getBaseItemLabelsVisible();
        int int17 = statisticalLineAndShapeRenderer15.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = null;
        statisticalLineAndShapeRenderer15.setSeriesNegativeItemLabelPosition(0, itemLabelPosition19);
        java.awt.Stroke stroke23 = statisticalLineAndShapeRenderer15.getItemOutlineStroke(4, (int) '4');
        polarPlot3.setRadiusGridlineStroke(stroke23);
        strokeList0.setStroke(2019, stroke23);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement1 = blockContainer0.getArrangement();
        java.awt.Shape shape2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset5 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset5.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.general.DatasetGroup datasetGroup11 = defaultStatisticalCategoryDataset5.getGroup();
        java.lang.Comparable comparable13 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity14 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "hi!", "", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5, (java.lang.Comparable) 1.0d, comparable13);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer17 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean18 = statisticalLineAndShapeRenderer17.getBaseItemLabelsVisible();
        int int19 = statisticalLineAndShapeRenderer17.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = null;
        statisticalLineAndShapeRenderer17.setSeriesNegativeItemLabelPosition(0, itemLabelPosition21);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator25 = statisticalLineAndShapeRenderer17.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = statisticalLineAndShapeRenderer17.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor28 = itemLabelPosition27.getRotationAnchor();
        boolean boolean29 = defaultStatisticalCategoryDataset5.equals((java.lang.Object) textAnchor28);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer31 = new org.jfree.chart.title.LegendItemBlockContainer(arrangement1, (org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset5, (java.lang.Comparable) 1);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.axis.AxisSpace axisSpace33 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = categoryAxis34.getLabelInsets();
        double double37 = rectangleInsets35.trimWidth((double) (byte) 10);
        double double39 = rectangleInsets35.calculateTopInset((-1.0d));
        double double41 = rectangleInsets35.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock43 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str44 = labelBlock43.getToolTipText();
        java.lang.String str45 = labelBlock43.getURLText();
        java.awt.geom.Rectangle2D rectangle2D46 = labelBlock43.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType47 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType48 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str49 = lengthAdjustmentType48.toString();
        java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets35.createAdjustedRectangle(rectangle2D46, lengthAdjustmentType47, lengthAdjustmentType48);
        org.jfree.chart.block.LabelBlock labelBlock52 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str53 = labelBlock52.getToolTipText();
        java.lang.String str54 = labelBlock52.getURLText();
        java.awt.geom.Rectangle2D rectangle2D55 = labelBlock52.getBounds();
        java.awt.geom.Rectangle2D rectangle2D56 = axisSpace33.shrink(rectangle2D50, rectangle2D55);
        org.jfree.chart.text.TextAnchor textAnchor57 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        try {
            java.lang.Object obj58 = legendItemBlockContainer31.draw(graphics2D32, rectangle2D56, (java.lang.Object) textAnchor57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(arrangement1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(datasetGroup11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator25);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 4.0d + "'", double37 == 4.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 3.0d + "'", double39 == 3.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 3.0d + "'", double41 == 3.0d);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(lengthAdjustmentType47);
        org.junit.Assert.assertNotNull(lengthAdjustmentType48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "CONTRACT" + "'", str49.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNull(str53);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(textAnchor57);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        int int2 = xYPlot0.indexOf(xYDataset1);
        int int3 = xYPlot0.getSeriesCount();
        xYPlot0.clearDomainMarkers();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = statisticalLineAndShapeRenderer2.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = statisticalLineAndShapeRenderer2.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer15.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint21 = statisticalLineAndShapeRenderer15.getItemOutlinePaint((-1), 0);
        statisticalLineAndShapeRenderer2.setBaseOutlinePaint(paint21, true);
        java.awt.Font font26 = statisticalLineAndShapeRenderer2.getItemLabelFont(8, 8);
        java.awt.Stroke stroke28 = null;
        statisticalLineAndShapeRenderer2.setSeriesOutlineStroke(2, stroke28, true);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = categoryAxis33.getLabelInsets();
        double double36 = rectangleInsets34.trimWidth((double) (byte) 10);
        double double38 = rectangleInsets34.calculateTopInset((-1.0d));
        double double40 = rectangleInsets34.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock42 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str43 = labelBlock42.getToolTipText();
        java.lang.String str44 = labelBlock42.getURLText();
        java.awt.geom.Rectangle2D rectangle2D45 = labelBlock42.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType46 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType47 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str48 = lengthAdjustmentType47.toString();
        java.awt.geom.Rectangle2D rectangle2D49 = rectangleInsets34.createAdjustedRectangle(rectangle2D45, lengthAdjustmentType46, lengthAdjustmentType47);
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint52 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        categoryAxis51.setTickMarkPaint(paint52);
        java.lang.String str54 = categoryAxis51.getLabel();
        categoryAxis51.setMaximumCategoryLabelLines((int) (short) 100);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D58 = new org.jfree.chart.axis.NumberAxis3D("LengthConstraintType.NONE");
        boolean boolean59 = numberAxis3D58.isInverted();
        boolean boolean60 = numberAxis3D58.getAutoRangeIncludesZero();
        org.jfree.chart.block.BorderArrangement borderArrangement61 = new org.jfree.chart.block.BorderArrangement();
        borderArrangement61.clear();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection63 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int64 = taskSeriesCollection63.getColumnCount();
        java.util.List list65 = taskSeriesCollection63.getColumnKeys();
        int int66 = taskSeriesCollection63.getColumnCount();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer68 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) borderArrangement61, (org.jfree.data.general.Dataset) taskSeriesCollection63, (java.lang.Comparable) '4');
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection69 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int70 = taskSeriesCollection69.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries72 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection69.add(taskSeries72);
        java.beans.PropertyChangeListener propertyChangeListener74 = null;
        taskSeries72.addPropertyChangeListener(propertyChangeListener74);
        java.lang.Object obj76 = taskSeries72.clone();
        taskSeries72.setDescription("({0}, {1}) = {2}");
        org.jfree.chart.text.TextAnchor textAnchor79 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.awt.Image image83 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo87 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image83, "", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray88 = projectInfo87.getLibraries();
        boolean boolean89 = textAnchor79.equals((java.lang.Object) projectInfo87);
        java.awt.Image image90 = null;
        projectInfo87.setLogo(image90);
        boolean boolean92 = taskSeries72.equals((java.lang.Object) image90);
        taskSeriesCollection63.remove(taskSeries72);
        try {
            statisticalLineAndShapeRenderer2.drawItem(graphics2D31, categoryItemRendererState32, rectangle2D45, categoryPlot50, categoryAxis51, (org.jfree.chart.axis.ValueAxis) numberAxis3D58, (org.jfree.data.category.CategoryDataset) taskSeriesCollection63, 7, 0, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 4.0d + "'", double36 == 4.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 3.0d + "'", double38 == 3.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 3.0d + "'", double40 == 3.0d);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(lengthAdjustmentType46);
        org.junit.Assert.assertNotNull(lengthAdjustmentType47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "CONTRACT" + "'", str48.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(list65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNotNull(obj76);
        org.junit.Assert.assertNotNull(textAnchor79);
        org.junit.Assert.assertNotNull(libraryArray88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape5, rectangleAnchor6, (double) (short) 100, (double) 4);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer12 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer12.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint18 = statisticalLineAndShapeRenderer12.getItemOutlinePaint((-1), 0);
        org.jfree.chart.title.LegendGraphic legendGraphic19 = new org.jfree.chart.title.LegendGraphic(shape9, paint18);
        java.awt.Paint paint20 = null;
        legendGraphic19.setLinePaint(paint20);
        java.awt.Stroke stroke22 = legendGraphic19.getLineStroke();
        java.awt.Color color23 = java.awt.Color.blue;
        legendGraphic19.setFillPaint((java.awt.Paint) color23);
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder(0.0d, 9.223372036854776E18d, (double) 4, (double) 1.0f, (java.awt.Paint) color23);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint1 = waterfallBarRenderer0.getLastBarPaint();
        java.awt.Color color2 = java.awt.Color.black;
        waterfallBarRenderer0.setPositiveBarPaint((java.awt.Paint) color2);
        boolean boolean4 = waterfallBarRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Shape shape6 = waterfallBarRenderer0.getSeriesShape(7);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(shape6);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        textBlock0.draw(graphics2D1, (float) (byte) 100, (float) (byte) 1, textBlockAnchor4, (float) 7, (float) '4', (double) (short) 100);
        java.util.List list9 = textBlock0.getLines();
        java.util.List list10 = textBlock0.getLines();
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.lang.String str3 = textTitle2.getToolTipText();
        textTitle2.setWidth(0.0d);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent6 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle2);
        java.awt.Color color7 = java.awt.Color.cyan;
        boolean boolean8 = textTitle2.equals((java.lang.Object) color7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryAxis10.getLabelInsets();
        double double13 = rectangleInsets11.trimWidth((double) (byte) 10);
        double double15 = rectangleInsets11.calculateTopInset((-1.0d));
        double double17 = rectangleInsets11.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock19 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str20 = labelBlock19.getToolTipText();
        java.lang.String str21 = labelBlock19.getURLText();
        java.awt.geom.Rectangle2D rectangle2D22 = labelBlock19.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str25 = lengthAdjustmentType24.toString();
        java.awt.geom.Rectangle2D rectangle2D26 = rectangleInsets11.createAdjustedRectangle(rectangle2D22, lengthAdjustmentType23, lengthAdjustmentType24);
        java.lang.Object obj27 = null;
        java.lang.Object obj28 = textTitle2.draw(graphics2D9, rectangle2D22, obj27);
        java.lang.String str29 = textTitle2.getURLText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15 == 3.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.0d + "'", double17 == 3.0d);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(lengthAdjustmentType23);
        org.junit.Assert.assertNotNull(lengthAdjustmentType24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "CONTRACT" + "'", str25.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNull(obj28);
        org.junit.Assert.assertNull(str29);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        textBlock1.draw(graphics2D2, (float) (byte) 100, (float) (byte) 1, textBlockAnchor5, (float) 7, (float) '4', (double) (short) 100);
        java.util.List list10 = textBlock1.getLines();
        org.jfree.chart.text.TextBlock textBlock11 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        textBlock11.draw(graphics2D12, (float) (byte) 100, (float) (byte) 1, textBlockAnchor15, (float) 7, (float) '4', (double) (short) 100);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.axis.CategoryTick categoryTick22 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 900000L, textBlock1, textBlockAnchor15, textAnchor20, (double) (-329600));
        java.lang.String str23 = categoryTick22.toString();
        java.lang.Object obj24 = categoryTick22.clone();
        org.jfree.chart.text.TextAnchor textAnchor25 = categoryTick22.getTextAnchor();
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(textBlockAnchor15);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(textAnchor25);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("Range[1.0,1.0]", "NOID", "DateTickUnit[DAY, 1]", image3, "({0}, {1}) = {2}", "Range[1.0,1.0]", "");
        java.lang.String str8 = projectInfo7.getLicenceText();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("LengthConstraintType.NONE");
        boolean boolean2 = numberAxis3D1.isInverted();
        boolean boolean3 = numberAxis3D1.getAutoRangeIncludesZero();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("LengthConstraintType.NONE");
        boolean boolean6 = numberAxis3D5.isInverted();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = numberAxis7.getTickUnit();
        numberAxis3D5.setTickUnit(numberTickUnit8);
        numberAxis3D1.setTickUnit(numberTickUnit8);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(numberTickUnit8);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean4 = statisticalLineAndShapeRenderer3.getBaseItemLabelsVisible();
        int int5 = statisticalLineAndShapeRenderer3.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        statisticalLineAndShapeRenderer3.setSeriesNegativeItemLabelPosition(0, itemLabelPosition7);
        java.awt.Stroke stroke11 = statisticalLineAndShapeRenderer3.getItemOutlineStroke(4, (int) '4');
        boolean boolean12 = waterfallBarRenderer0.equals((java.lang.Object) statisticalLineAndShapeRenderer3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer14.setMaximumBarWidth((double) 2);
        java.awt.Shape shape18 = barRenderer14.lookupSeriesShape(2958465);
        statisticalLineAndShapeRenderer3.setSeriesShape((int) (byte) 0, shape18, false);
        statisticalLineAndShapeRenderer3.setUseFillPaint(true);
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        try {
            statisticalLineAndShapeRenderer3.setSeriesItemLabelPaint((int) (byte) -1, (java.awt.Paint) color24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        java.awt.Image image4 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image4, "", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray9 = projectInfo8.getLibraries();
        java.lang.String str10 = projectInfo8.getName();
        boolean boolean11 = borderArrangement0.equals((java.lang.Object) projectInfo8);
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        boolean boolean13 = borderArrangement0.equals((java.lang.Object) ringPlot12);
        ringPlot12.setLabelLinkMargin(103.0d);
        org.junit.Assert.assertNotNull(libraryArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.lang.String str3 = textTitle2.getToolTipText();
        boolean boolean4 = textTitle2.getExpandToFitSpace();
        java.lang.Object obj5 = textTitle2.clone();
        java.lang.String str6 = textTitle2.getURLText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getOutlinePaint();
        java.awt.Stroke stroke2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot0.setOutlineStroke(stroke2);
        java.lang.String str4 = polarPlot0.getPlotType();
        java.awt.Paint paint5 = polarPlot0.getOutlinePaint();
        java.awt.Paint paint6 = polarPlot0.getBackgroundPaint();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer10.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint16 = statisticalLineAndShapeRenderer10.getItemOutlinePaint((-1), 0);
        boolean boolean18 = statisticalLineAndShapeRenderer10.isSeriesItemLabelsVisible(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = statisticalLineAndShapeRenderer10.getNegativeItemLabelPosition((int) (short) 1, (int) (byte) 100);
        java.awt.Font font24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("hi!", font24);
        java.lang.String str26 = textTitle25.getToolTipText();
        textTitle25.setWidth(0.0d);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent29 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle25);
        java.awt.Color color30 = java.awt.Color.cyan;
        boolean boolean31 = textTitle25.equals((java.lang.Object) color30);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = categoryAxis33.getLabelInsets();
        double double36 = rectangleInsets34.trimWidth((double) (byte) 10);
        double double38 = rectangleInsets34.calculateTopInset((-1.0d));
        double double40 = rectangleInsets34.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock42 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str43 = labelBlock42.getToolTipText();
        java.lang.String str44 = labelBlock42.getURLText();
        java.awt.geom.Rectangle2D rectangle2D45 = labelBlock42.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType46 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType47 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str48 = lengthAdjustmentType47.toString();
        java.awt.geom.Rectangle2D rectangle2D49 = rectangleInsets34.createAdjustedRectangle(rectangle2D45, lengthAdjustmentType46, lengthAdjustmentType47);
        java.lang.Object obj50 = null;
        java.lang.Object obj51 = textTitle25.draw(graphics2D32, rectangle2D45, obj50);
        statisticalLineAndShapeRenderer10.setSeriesShape(2019, (java.awt.Shape) rectangle2D45, false);
        polarPlot0.drawBackgroundImage(graphics2D7, rectangle2D45);
        org.jfree.chart.text.TextBlock textBlock56 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D57 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor60 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        textBlock56.draw(graphics2D57, (float) (byte) 100, (float) (byte) 1, textBlockAnchor60, (float) 7, (float) '4', (double) (short) 100);
        java.util.List list65 = textBlock56.getLines();
        org.jfree.chart.text.TextBlock textBlock66 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D67 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor70 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        textBlock66.draw(graphics2D67, (float) (byte) 100, (float) (byte) 1, textBlockAnchor70, (float) 7, (float) '4', (double) (short) 100);
        org.jfree.chart.text.TextAnchor textAnchor75 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.axis.CategoryTick categoryTick77 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 900000L, textBlock56, textBlockAnchor70, textAnchor75, (double) (-329600));
        java.awt.Graphics2D graphics2D78 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor81 = null;
        java.awt.Shape shape85 = textBlock56.calculateBounds(graphics2D78, (float) (-329600), (float) (short) 10, textBlockAnchor81, 0.0f, (float) (short) 1, (double) (byte) 1);
        boolean boolean86 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape) rectangle2D45, shape85);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Polar Plot" + "'", str4.equals("Polar Plot"));
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 4.0d + "'", double36 == 4.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 3.0d + "'", double38 == 3.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 3.0d + "'", double40 == 3.0d);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(lengthAdjustmentType46);
        org.junit.Assert.assertNotNull(lengthAdjustmentType47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "CONTRACT" + "'", str48.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNull(obj51);
        org.junit.Assert.assertNotNull(textBlockAnchor60);
        org.junit.Assert.assertNotNull(list65);
        org.junit.Assert.assertNotNull(textBlockAnchor70);
        org.junit.Assert.assertNotNull(textAnchor75);
        org.junit.Assert.assertNotNull(shape85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getOutlinePaint();
        java.awt.Stroke stroke2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot0.setOutlineStroke(stroke2);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = polarPlot0.getLegendItems();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(legendItemCollection4);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        java.lang.String str2 = polarPlot1.getNoDataMessage();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = null;
        polarPlot1.rendererChanged(rendererChangeEvent3);
        polarPlot1.addCornerTextItem("NOID");
        java.awt.Font font7 = polarPlot1.getNoDataMessageFont();
        categoryAxis3D0.setPlot((org.jfree.chart.plot.Plot) polarPlot1);
        java.awt.Font font9 = polarPlot1.getAngleLabelFont();
        boolean boolean10 = polarPlot1.isRadiusGridlinesVisible();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setStartAngle(0.0d);
        java.awt.Paint paint3 = ringPlot0.getLabelBackgroundPaint();
        java.awt.Paint paint5 = ringPlot0.getSectionPaint((java.lang.Comparable) "CONTRACT");
        double double6 = ringPlot0.getSectionDepth();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        jFreeChart4.setTitle("hi!");
        java.lang.Object obj7 = jFreeChart4.getTextAntiAlias();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font9);
        java.lang.String str11 = textTitle10.getToolTipText();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("hi!", font13);
        java.lang.String str15 = textTitle14.getToolTipText();
        textTitle14.setWidth(0.0d);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent18 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle14);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle14.getVerticalAlignment();
        textTitle10.setVerticalAlignment(verticalAlignment19);
        jFreeChart4.setTitle(textTitle10);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer24 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean25 = statisticalLineAndShapeRenderer24.getBaseItemLabelsVisible();
        int int26 = statisticalLineAndShapeRenderer24.getPassCount();
        java.awt.Font font27 = statisticalLineAndShapeRenderer24.getBaseItemLabelFont();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape29, rectangleAnchor30, (double) (short) 100, (double) 4);
        statisticalLineAndShapeRenderer24.setBaseShape(shape33, false);
        boolean boolean36 = statisticalLineAndShapeRenderer24.getUseFillPaint();
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalLineAndShapeRenderer24);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke39 = categoryAxis38.getTickMarkStroke();
        boolean boolean40 = legendTitle37.equals((java.lang.Object) stroke39);
        jFreeChart4.addLegend(legendTitle37);
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = dateAxis42.getTickLabelInsets();
        java.awt.Font font45 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle("hi!", font45);
        java.lang.String str47 = textTitle46.getToolTipText();
        boolean boolean48 = rectangleInsets43.equals((java.lang.Object) textTitle46);
        legendTitle37.setLegendItemGraphicPadding(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis1);
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis1.setRange((org.jfree.data.Range) dateRange5);
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font9);
        java.lang.String str11 = textTitle10.getToolTipText();
        textTitle10.setWidth(0.0d);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent14 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle10);
        java.awt.Color color15 = java.awt.Color.cyan;
        boolean boolean16 = textTitle10.equals((java.lang.Object) color15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = categoryAxis18.getLabelInsets();
        double double21 = rectangleInsets19.trimWidth((double) (byte) 10);
        double double23 = rectangleInsets19.calculateTopInset((-1.0d));
        double double25 = rectangleInsets19.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock27 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str28 = labelBlock27.getToolTipText();
        java.lang.String str29 = labelBlock27.getURLText();
        java.awt.geom.Rectangle2D rectangle2D30 = labelBlock27.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType31 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType32 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str33 = lengthAdjustmentType32.toString();
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets19.createAdjustedRectangle(rectangle2D30, lengthAdjustmentType31, lengthAdjustmentType32);
        java.lang.Object obj35 = null;
        java.lang.Object obj36 = textTitle10.draw(graphics2D17, rectangle2D30, obj35);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = null;
        double double38 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D30, rectangleEdge37);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double40 = dateAxis1.lengthToJava2D(0.0d, rectangle2D30, rectangleEdge39);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection41 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int42 = taskSeriesCollection41.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries44 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection41.add(taskSeries44);
        org.jfree.data.gantt.TaskSeries taskSeries47 = taskSeriesCollection41.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection41, (java.lang.Comparable) "CONTRACT");
        org.jfree.chart.plot.PiePlot3D piePlot3D50 = new org.jfree.chart.plot.PiePlot3D(pieDataset49);
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) piePlot3D50);
        piePlot3D50.setCircular(false);
        java.lang.String str54 = piePlot3D50.getPlotType();
        org.jfree.chart.JFreeChart jFreeChart55 = new org.jfree.chart.JFreeChart("ClassContext", (org.jfree.chart.plot.Plot) piePlot3D50);
        java.awt.Stroke stroke56 = piePlot3D50.getLabelOutlineStroke();
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 3.0d + "'", double23 == 3.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 3.0d + "'", double25 == 3.0d);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(lengthAdjustmentType31);
        org.junit.Assert.assertNotNull(lengthAdjustmentType32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "CONTRACT" + "'", str33.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(obj36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNull(taskSeries47);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Pie 3D Plot" + "'", str54.equals("Pie 3D Plot"));
        org.junit.Assert.assertNotNull(stroke56);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.TRUNCATE;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean2 = areaRendererEndType0.equals((java.lang.Object) polarPlot1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        polarPlot1.zoomDomainAxes((double) 15, (-1.0d), plotRenderingInfo5, point2D6);
        org.junit.Assert.assertNotNull(areaRendererEndType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 11, 0.0d, 8.64E7d, Double.NaN);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (short) 100, (double) 4);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint14 = statisticalLineAndShapeRenderer8.getItemOutlinePaint((-1), 0);
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape5, paint14);
        java.awt.Shape shape16 = legendGraphic15.getLine();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer17 = legendGraphic15.getFillPaintTransformer();
        legendGraphic15.setShapeFilled(true);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(shape16);
        org.junit.Assert.assertNotNull(gradientPaintTransformer17);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        statisticalLineAndShapeRenderer2.setUseFillPaint(false);
        java.awt.Paint paint11 = statisticalLineAndShapeRenderer2.getSeriesItemLabelPaint(3);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalLineAndShapeRenderer2.getLegendItemURLGenerator();
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape14, rectangleAnchor15, (double) (short) 100, (double) 4);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer21 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer21.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint27 = statisticalLineAndShapeRenderer21.getItemOutlinePaint((-1), 0);
        org.jfree.chart.title.LegendGraphic legendGraphic28 = new org.jfree.chart.title.LegendGraphic(shape18, paint27);
        java.awt.Paint paint29 = null;
        legendGraphic28.setLinePaint(paint29);
        java.awt.Stroke stroke31 = legendGraphic28.getLineStroke();
        java.awt.Color color32 = java.awt.Color.blue;
        legendGraphic28.setFillPaint((java.awt.Paint) color32);
        statisticalLineAndShapeRenderer2.setBaseItemLabelPaint((java.awt.Paint) color32);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(stroke31);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setStartAngle(0.0d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = ringPlot0.getLegendLabelGenerator();
        java.awt.Paint paint4 = ringPlot0.getLabelOutlinePaint();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("hi!", font4);
        java.awt.Paint paint6 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("({0}, {1}) = {2}", font4, paint6);
        textBlock1.addLine(textLine7);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        dateAxis10.resizeRange(1.0d);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean16 = statisticalLineAndShapeRenderer15.getBaseItemLabelsVisible();
        int int17 = statisticalLineAndShapeRenderer15.getPassCount();
        java.awt.Font font18 = statisticalLineAndShapeRenderer15.getBaseItemLabelFont();
        dateAxis10.setLabelFont(font18);
        java.awt.Paint paint20 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        textBlock1.addLine("Polar Plot", font18, paint20);
        java.awt.Paint paint22 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock23 = org.jfree.chart.text.TextUtilities.createTextBlock("CategoryAnchor.MIDDLE", font18, paint22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        statisticalLineAndShapeRenderer2.setUseFillPaint(false);
        boolean boolean10 = statisticalLineAndShapeRenderer2.getAutoPopulateSeriesOutlinePaint();
        boolean boolean11 = statisticalLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        double double3 = ringPlot0.getMaximumLabelWidth();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        ringPlot0.setExplodePercent((java.lang.Comparable) 'a', (double) 100);
        double double9 = ringPlot0.getMinimumArcAngleToDraw();
        ringPlot0.setSeparatorsVisible(false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0E-5d + "'", double9 == 1.0E-5d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D2 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int3 = defaultKeyedValues2D2.getRowCount();
        java.util.List list4 = defaultKeyedValues2D2.getColumnKeys();
        boolean boolean5 = waterfallBarRenderer0.equals((java.lang.Object) list4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint7 = polarPlot6.getOutlinePaint();
        java.awt.Stroke stroke8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot6.setOutlineStroke(stroke8);
        java.lang.String str10 = polarPlot6.getPlotType();
        int int11 = polarPlot6.getBackgroundImageAlignment();
        boolean boolean12 = waterfallBarRenderer0.equals((java.lang.Object) polarPlot6);
        waterfallBarRenderer0.setItemMargin((double) 500);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Polar Plot" + "'", str10.equals("Polar Plot"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setStartAngle(0.0d);
        ringPlot0.setIgnoreNullValues(true);
        int int5 = ringPlot0.getPieIndex();
        ringPlot0.setCircular(false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean4 = statisticalLineAndShapeRenderer3.getBaseItemLabelsVisible();
        int int5 = statisticalLineAndShapeRenderer3.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        statisticalLineAndShapeRenderer3.setSeriesNegativeItemLabelPosition(0, itemLabelPosition7);
        statisticalLineAndShapeRenderer3.setUseFillPaint(false);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer13.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint19 = statisticalLineAndShapeRenderer13.getItemOutlinePaint((-1), 0);
        statisticalLineAndShapeRenderer3.setBaseOutlinePaint(paint19);
        java.awt.Stroke stroke21 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) ' ', paint19, stroke21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset4.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.general.DatasetGroup datasetGroup10 = defaultStatisticalCategoryDataset4.getGroup();
        java.lang.Comparable comparable12 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity13 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "hi!", "", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, (java.lang.Comparable) 1.0d, comparable12);
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint15 = polarPlot14.getOutlinePaint();
        java.awt.Stroke stroke16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot14.setOutlineStroke(stroke16);
        java.lang.String str18 = polarPlot14.getPlotType();
        int int19 = polarPlot14.getBackgroundImageAlignment();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryAxis20.getLabelInsets();
        java.awt.Stroke stroke22 = categoryAxis20.getAxisLineStroke();
        float float23 = categoryAxis20.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent24 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis20);
        org.jfree.chart.axis.Axis axis25 = axisChangeEvent24.getAxis();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer28 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean29 = statisticalLineAndShapeRenderer28.getBaseItemLabelsVisible();
        int int30 = statisticalLineAndShapeRenderer28.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = null;
        statisticalLineAndShapeRenderer28.setSeriesNegativeItemLabelPosition(0, itemLabelPosition32);
        java.awt.Stroke stroke36 = statisticalLineAndShapeRenderer28.getItemOutlineStroke(4, (int) '4');
        statisticalLineAndShapeRenderer28.setItemLabelAnchorOffset((double) (short) 1);
        java.awt.Stroke stroke39 = statisticalLineAndShapeRenderer28.getBaseOutlineStroke();
        axis25.setTickMarkStroke(stroke39);
        polarPlot14.setAngleGridlineStroke(stroke39);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent42 = null;
        polarPlot14.datasetChanged(datasetChangeEvent42);
        boolean boolean44 = defaultStatisticalCategoryDataset4.hasListener((java.util.EventListener) polarPlot14);
        org.jfree.chart.plot.RingPlot ringPlot45 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint46 = null;
        ringPlot45.setShadowPaint(paint46);
        double double48 = ringPlot45.getMaximumLabelWidth();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent49 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot45);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        ringPlot45.setExplodePercent((java.lang.Comparable) 'a', (double) 100);
        polarPlot14.setParent((org.jfree.chart.plot.Plot) ringPlot45);
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) ringPlot45);
        dateAxis0.setLowerMargin((double) 15);
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = categoryAxis59.getLabelInsets();
        double double62 = rectangleInsets60.trimWidth((double) (byte) 10);
        double double64 = rectangleInsets60.calculateTopInset((-1.0d));
        double double66 = rectangleInsets60.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock68 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str69 = labelBlock68.getToolTipText();
        java.lang.String str70 = labelBlock68.getURLText();
        java.awt.geom.Rectangle2D rectangle2D71 = labelBlock68.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType72 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType73 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str74 = lengthAdjustmentType73.toString();
        java.awt.geom.Rectangle2D rectangle2D75 = rectangleInsets60.createAdjustedRectangle(rectangle2D71, lengthAdjustmentType72, lengthAdjustmentType73);
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean77 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge76);
        double double78 = dateAxis0.java2DToValue((double) 2019, rectangle2D71, rectangleEdge76);
        dateAxis0.setAutoTickUnitSelection(false);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(datasetGroup10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Polar Plot" + "'", str18.equals("Polar Plot"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.0f + "'", float23 == 0.0f);
        org.junit.Assert.assertNotNull(axis25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.2d + "'", double48 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 4.0d + "'", double62 == 4.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 3.0d + "'", double64 == 3.0d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 3.0d + "'", double66 == 3.0d);
        org.junit.Assert.assertNull(str69);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertNotNull(rectangle2D71);
        org.junit.Assert.assertNotNull(lengthAdjustmentType72);
        org.junit.Assert.assertNotNull(lengthAdjustmentType73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "CONTRACT" + "'", str74.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D75);
        org.junit.Assert.assertNotNull(rectangleEdge76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 9.223372036854776E18d + "'", double78 == 9.223372036854776E18d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = dateAxis4.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = dateAxis4.java2DToValue((double) 4, rectangle2D7, rectangleEdge8);
        java.awt.Shape shape10 = dateAxis4.getLeftArrow();
        int int11 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("hi!", font13);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer17 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer17.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint21 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        statisticalLineAndShapeRenderer17.setBasePaint(paint21);
        textTitle14.setBackgroundPaint(paint21);
        xYPlot0.setRangeZeroBaselinePaint(paint21);
        java.awt.Color color26 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke28 = polarPlot27.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', (java.awt.Paint) color26, stroke28);
        java.lang.String str30 = categoryMarker29.getLabel();
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker29);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = xYPlot33.getRangeAxisEdge(0);
        boolean boolean36 = xYPlot33.isRangeZeroBaselineVisible();
        java.awt.Paint paint37 = xYPlot33.getRangeZeroBaselinePaint();
        java.awt.Stroke stroke38 = xYPlot33.getRangeZeroBaselineStroke();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer41 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer41.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint47 = statisticalLineAndShapeRenderer41.getItemOutlinePaint((-1), 0);
        boolean boolean48 = statisticalLineAndShapeRenderer41.getUseOutlinePaint();
        statisticalLineAndShapeRenderer41.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.block.FlowArrangement flowArrangement51 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent52 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) flowArrangement51);
        statisticalLineAndShapeRenderer41.notifyListeners(rendererChangeEvent52);
        xYPlot33.rendererChanged(rendererChangeEvent52);
        xYPlot0.rendererChanged(rendererChangeEvent52);
        java.awt.Graphics2D graphics2D56 = null;
        org.jfree.chart.axis.AxisSpace axisSpace57 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = categoryAxis58.getLabelInsets();
        double double61 = rectangleInsets59.trimWidth((double) (byte) 10);
        double double63 = rectangleInsets59.calculateTopInset((-1.0d));
        double double65 = rectangleInsets59.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock67 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str68 = labelBlock67.getToolTipText();
        java.lang.String str69 = labelBlock67.getURLText();
        java.awt.geom.Rectangle2D rectangle2D70 = labelBlock67.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType71 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType72 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str73 = lengthAdjustmentType72.toString();
        java.awt.geom.Rectangle2D rectangle2D74 = rectangleInsets59.createAdjustedRectangle(rectangle2D70, lengthAdjustmentType71, lengthAdjustmentType72);
        org.jfree.chart.block.LabelBlock labelBlock76 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str77 = labelBlock76.getToolTipText();
        java.lang.String str78 = labelBlock76.getURLText();
        java.awt.geom.Rectangle2D rectangle2D79 = labelBlock76.getBounds();
        java.awt.geom.Rectangle2D rectangle2D80 = axisSpace57.shrink(rectangle2D74, rectangle2D79);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline81 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.List list82 = segmentedTimeline81.getExceptionSegments();
        xYPlot0.drawRangeTickBands(graphics2D56, rectangle2D79, list82);
        org.jfree.chart.axis.DateAxis dateAxis84 = new org.jfree.chart.axis.DateAxis();
        double double85 = dateAxis84.getUpperMargin();
        java.awt.Shape shape86 = dateAxis84.getDownArrow();
        int int87 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis84);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 9.223372036854776E18d + "'", double9 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 4.0d + "'", double61 == 4.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 3.0d + "'", double63 == 3.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 3.0d + "'", double65 == 3.0d);
        org.junit.Assert.assertNull(str68);
        org.junit.Assert.assertNull(str69);
        org.junit.Assert.assertNotNull(rectangle2D70);
        org.junit.Assert.assertNotNull(lengthAdjustmentType71);
        org.junit.Assert.assertNotNull(lengthAdjustmentType72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "CONTRACT" + "'", str73.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D74);
        org.junit.Assert.assertNull(str77);
        org.junit.Assert.assertNull(str78);
        org.junit.Assert.assertNotNull(rectangle2D79);
        org.junit.Assert.assertNotNull(rectangle2D80);
        org.junit.Assert.assertNotNull(segmentedTimeline81);
        org.junit.Assert.assertNotNull(list82);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.05d + "'", double85 == 0.05d);
        org.junit.Assert.assertNotNull(shape86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + (-1) + "'", int87 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        java.lang.Object obj5 = null;
        boolean boolean6 = xYPlot0.equals(obj5);
        xYPlot0.zoom(0.0d);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot0.getDomainMarkers(2019, layer10);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot13.getRangeAxisEdge(0);
        boolean boolean16 = xYPlot13.isRangeZeroBaselineVisible();
        java.awt.Paint paint17 = xYPlot13.getRangeZeroBaselinePaint();
        java.lang.Object obj18 = null;
        boolean boolean19 = xYPlot13.equals(obj18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        xYPlot13.zoomDomainAxes((double) 0L, plotRenderingInfo21, point2D22);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot13.setRangeAxisLocation(7, axisLocation25);
        try {
            xYPlot0.setDomainAxisLocation((int) (short) -1, axisLocation25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(axisLocation25);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        java.lang.Object obj5 = null;
        boolean boolean6 = xYPlot0.equals(obj5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomDomainAxes((double) 0L, plotRenderingInfo8, point2D9);
        xYPlot0.setDomainCrosshairValue((-1.0d));
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis13.getLabelInsets();
        double double16 = rectangleInsets14.trimWidth((double) (byte) 10);
        double double18 = rectangleInsets14.calculateLeftOutset(0.0d);
        double double20 = rectangleInsets14.calculateBottomOutset((double) (byte) 10);
        xYPlot0.setInsets(rectangleInsets14);
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = xYPlot22.getRangeAxisEdge(0);
        boolean boolean25 = xYPlot22.isRangeZeroBaselineVisible();
        java.awt.Paint paint26 = xYPlot22.getRangeZeroBaselinePaint();
        java.awt.Stroke stroke27 = xYPlot22.getRangeZeroBaselineStroke();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer30 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer30.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint36 = statisticalLineAndShapeRenderer30.getItemOutlinePaint((-1), 0);
        boolean boolean37 = statisticalLineAndShapeRenderer30.getUseOutlinePaint();
        statisticalLineAndShapeRenderer30.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.block.FlowArrangement flowArrangement40 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent41 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) flowArrangement40);
        statisticalLineAndShapeRenderer30.notifyListeners(rendererChangeEvent41);
        xYPlot22.rendererChanged(rendererChangeEvent41);
        org.jfree.chart.axis.AxisLocation axisLocation45 = xYPlot22.getDomainAxisLocation((int) '4');
        xYPlot0.setRangeAxisLocation(axisLocation45);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.0d + "'", double18 == 3.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 3.0d + "'", double20 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(axisLocation45);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        java.awt.Paint paint3 = ringPlot0.getSeparatorPaint();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint5 = null;
        ringPlot4.setShadowPaint(paint5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = ringPlot4.getLegendLabelGenerator();
        ringPlot0.setLabelGenerator(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str2 = labelBlock1.getToolTipText();
        java.awt.Font font3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        labelBlock1.setFont(font3);
        java.lang.String str5 = labelBlock1.getToolTipText();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = barRenderer0.getPlot();
        double double2 = barRenderer0.getMaximumBarWidth();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer7 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer7.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint13 = statisticalLineAndShapeRenderer7.getItemOutlinePaint((-1), 0);
        boolean boolean15 = statisticalLineAndShapeRenderer7.equals((java.lang.Object) 2958465);
        statisticalLineAndShapeRenderer7.setBaseSeriesVisibleInLegend(true, false);
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint20 = polarPlot19.getOutlinePaint();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot19.setOutlineStroke(stroke21);
        java.lang.String str23 = polarPlot19.getPlotType();
        int int24 = polarPlot19.getBackgroundImageAlignment();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryAxis25.getLabelInsets();
        java.awt.Stroke stroke27 = categoryAxis25.getAxisLineStroke();
        float float28 = categoryAxis25.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent29 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis25);
        org.jfree.chart.axis.Axis axis30 = axisChangeEvent29.getAxis();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer33 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean34 = statisticalLineAndShapeRenderer33.getBaseItemLabelsVisible();
        int int35 = statisticalLineAndShapeRenderer33.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = null;
        statisticalLineAndShapeRenderer33.setSeriesNegativeItemLabelPosition(0, itemLabelPosition37);
        java.awt.Stroke stroke41 = statisticalLineAndShapeRenderer33.getItemOutlineStroke(4, (int) '4');
        statisticalLineAndShapeRenderer33.setItemLabelAnchorOffset((double) (short) 1);
        java.awt.Stroke stroke44 = statisticalLineAndShapeRenderer33.getBaseOutlineStroke();
        axis30.setTickMarkStroke(stroke44);
        polarPlot19.setAngleGridlineStroke(stroke44);
        boolean boolean47 = statisticalLineAndShapeRenderer7.equals((java.lang.Object) stroke44);
        barRenderer0.setBaseOutlineStroke(stroke44, true);
        java.awt.Paint paint51 = barRenderer0.lookupSeriesFillPaint(9);
        org.junit.Assert.assertNull(categoryPlot1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNull(itemLabelPosition3);
        org.junit.Assert.assertNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Polar Plot" + "'", str23.equals("Polar Plot"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 15 + "'", int24 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.0f + "'", float28 == 0.0f);
        org.junit.Assert.assertNotNull(axis30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2 + "'", int35 == 2);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(paint51);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = statisticalLineAndShapeRenderer2.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = statisticalLineAndShapeRenderer2.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer15.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint21 = statisticalLineAndShapeRenderer15.getItemOutlinePaint((-1), 0);
        statisticalLineAndShapeRenderer2.setBaseOutlinePaint(paint21, true);
        java.awt.Font font26 = statisticalLineAndShapeRenderer2.getItemLabelFont(8, 8);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(font26);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        boolean boolean5 = xYPlot0.isRangeZeroBaselineVisible();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = new org.jfree.chart.LegendItemCollection();
        xYPlot0.setFixedLegendItems(legendItemCollection8);
        try {
            org.jfree.chart.LegendItem legendItem11 = legendItemCollection8.get((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        java.awt.Font font5 = statisticalLineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, rectangleAnchor8, (double) (short) 100, (double) 4);
        statisticalLineAndShapeRenderer2.setBaseShape(shape11, false);
        boolean boolean14 = statisticalLineAndShapeRenderer2.getUseFillPaint();
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalLineAndShapeRenderer2);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot16.getRangeAxisEdge(0);
        boolean boolean19 = xYPlot16.isRangeZeroBaselineVisible();
        java.awt.Paint paint20 = xYPlot16.getRangeZeroBaselinePaint();
        java.awt.Stroke stroke21 = xYPlot16.getRangeZeroBaselineStroke();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray22 = new org.jfree.chart.LegendItemSource[] { xYPlot16 };
        legendTitle15.setSources(legendItemSourceArray22);
        java.awt.Font font24 = legendTitle15.getItemFont();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape26, rectangleAnchor27, (double) (short) 100, (double) 4);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer33 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer33.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint39 = statisticalLineAndShapeRenderer33.getItemOutlinePaint((-1), 0);
        org.jfree.chart.title.LegendGraphic legendGraphic40 = new org.jfree.chart.title.LegendGraphic(shape30, paint39);
        java.awt.Paint paint41 = null;
        legendGraphic40.setLinePaint(paint41);
        java.awt.Stroke stroke43 = legendGraphic40.getLineStroke();
        java.awt.Color color44 = java.awt.Color.blue;
        legendGraphic40.setFillPaint((java.awt.Paint) color44);
        legendTitle15.setItemPaint((java.awt.Paint) color44);
        java.awt.Paint paint47 = legendTitle15.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(legendItemSourceArray22);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNull(stroke43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNull(paint47);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.lang.String str3 = textTitle2.getToolTipText();
        textTitle2.setWidth(0.0d);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent6 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle2);
        java.awt.Color color7 = java.awt.Color.cyan;
        boolean boolean8 = textTitle2.equals((java.lang.Object) color7);
        textTitle2.setNotify(false);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis0);
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit2);
        int int4 = dateTickUnit2.getCount();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        int int2 = xYPlot0.indexOf(xYDataset1);
        int int3 = xYPlot0.getSeriesCount();
        java.lang.Object obj4 = xYPlot0.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Comparable comparable1 = null;
        int int2 = defaultStatisticalCategoryDataset0.getRowIndex(comparable1);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = xYPlot3.getRangeAxisEdge(0);
        boolean boolean6 = xYPlot3.isRangeZeroBaselineVisible();
        java.awt.Paint paint7 = xYPlot3.getRangeZeroBaselinePaint();
        java.lang.Object obj8 = null;
        boolean boolean9 = xYPlot3.equals(obj8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot3.zoomDomainAxes((double) 0L, plotRenderingInfo11, point2D12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot3.setRangeAxisLocation(7, axisLocation15);
        org.jfree.chart.axis.ValueAxis valueAxis18 = xYPlot3.getDomainAxis(15);
        defaultStatisticalCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(valueAxis18);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Comparable comparable2 = null;
        int int3 = defaultStatisticalCategoryDataset1.getRowIndex(comparable2);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer5 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, (org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset1, (java.lang.Comparable) 100L);
        java.lang.String str6 = legendItemBlockContainer5.getURLText();
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block8 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer11 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean12 = statisticalLineAndShapeRenderer11.getBaseItemLabelsVisible();
        int int13 = statisticalLineAndShapeRenderer11.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = null;
        statisticalLineAndShapeRenderer11.setSeriesNegativeItemLabelPosition(0, itemLabelPosition15);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = statisticalLineAndShapeRenderer11.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = statisticalLineAndShapeRenderer11.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        flowArrangement7.add(block8, (java.lang.Object) itemLabelPosition21);
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = null;
        polarPlot23.markerChanged(markerChangeEvent24);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        polarPlot23.drawBackgroundImage(graphics2D26, rectangle2D27);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        polarPlot23.drawBackgroundImage(graphics2D29, rectangle2D30);
        boolean boolean32 = flowArrangement7.equals((java.lang.Object) rectangle2D30);
        legendItemBlockContainer5.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator19);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        statisticalLineAndShapeRenderer2.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) true, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray7 = new java.lang.Number[][] { numberArray2, numberArray3, numberArray4, numberArray5, numberArray6 };
        org.jfree.data.category.CategoryDataset categoryDataset8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("DateTickUnit[DAY, 1]", "LengthConstraintType.NONE", numberArray7);
        java.lang.Number[] numberArray11 = new java.lang.Number[] {};
        java.lang.Number[] numberArray12 = new java.lang.Number[] {};
        java.lang.Number[] numberArray13 = new java.lang.Number[] {};
        java.lang.Number[] numberArray14 = new java.lang.Number[] {};
        java.lang.Number[] numberArray15 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray11, numberArray12, numberArray13, numberArray14, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("DateTickUnit[DAY, 1]", "LengthConstraintType.NONE", numberArray16);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset18 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray7, numberArray16);
        int int19 = defaultIntervalCategoryDataset18.getColumnCount();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(categoryDataset8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        categoryAxis0.setTickMarkPaint(paint1);
        java.lang.String str3 = categoryAxis0.getLabel();
        categoryAxis0.setLabelAngle((double) '#');
        boolean boolean6 = categoryAxis0.isAxisLineVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis7.getLabelInsets();
        double double10 = rectangleInsets8.trimWidth((double) (byte) 10);
        double double12 = rectangleInsets8.calculateTopInset((-1.0d));
        categoryAxis0.setTickLabelInsets(rectangleInsets8);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions14 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) '#');
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions14);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = ringPlot0.getLegendLabelGenerator();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_RED;
        boolean boolean5 = ringPlot0.equals((java.lang.Object) color4);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean6 = statisticalLineAndShapeRenderer5.getBaseItemLabelsVisible();
        int int7 = statisticalLineAndShapeRenderer5.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        statisticalLineAndShapeRenderer5.setSeriesNegativeItemLabelPosition(0, itemLabelPosition9);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = statisticalLineAndShapeRenderer5.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = statisticalLineAndShapeRenderer5.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor16 = itemLabelPosition15.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType18 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        boolean boolean20 = categoryLabelWidthType18.equals((java.lang.Object) color19);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition22 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor2, textAnchor16, 8.64E7d, categoryLabelWidthType18, (float) 0L);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke26 = polarPlot25.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', (java.awt.Paint) color24, stroke26);
        java.lang.Object obj28 = categoryMarker27.clone();
        org.jfree.chart.text.TextAnchor textAnchor31 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor32 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.awt.Image image36 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo40 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image36, "", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray41 = projectInfo40.getLibraries();
        boolean boolean42 = textAnchor32.equals((java.lang.Object) projectInfo40);
        org.jfree.chart.axis.NumberTick numberTick44 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 1.0E-5d, "CONTRACT", textAnchor31, textAnchor32, 0.4d);
        java.awt.Image image48 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo52 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image48, "", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray53 = projectInfo52.getLibraries();
        java.lang.String str54 = projectInfo52.getName();
        boolean boolean55 = numberTick44.equals((java.lang.Object) str54);
        org.jfree.chart.text.TextAnchor textAnchor56 = numberTick44.getTextAnchor();
        categoryMarker27.setLabelTextAnchor(textAnchor56);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition59 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor16, textAnchor56, 0.05d);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNotNull(categoryLabelWidthType18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(textAnchor31);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertNotNull(libraryArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(libraryArray53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "hi!" + "'", str54.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(textAnchor56);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = barRenderer0.getPlot();
        int int2 = barRenderer0.getColumnCount();
        java.awt.Color color3 = java.awt.Color.red;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color3);
        int int5 = color3.getBlue();
        int int6 = color3.getTransparency();
        org.junit.Assert.assertNull(categoryPlot1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getLicenceText();
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis0);
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis0.setRange((org.jfree.data.Range) dateRange4);
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!", font8);
        java.lang.String str10 = textTitle9.getToolTipText();
        textTitle9.setWidth(0.0d);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent13 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle9);
        java.awt.Color color14 = java.awt.Color.cyan;
        boolean boolean15 = textTitle9.equals((java.lang.Object) color14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryAxis17.getLabelInsets();
        double double20 = rectangleInsets18.trimWidth((double) (byte) 10);
        double double22 = rectangleInsets18.calculateTopInset((-1.0d));
        double double24 = rectangleInsets18.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str27 = labelBlock26.getToolTipText();
        java.lang.String str28 = labelBlock26.getURLText();
        java.awt.geom.Rectangle2D rectangle2D29 = labelBlock26.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType30 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType31 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str32 = lengthAdjustmentType31.toString();
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets18.createAdjustedRectangle(rectangle2D29, lengthAdjustmentType30, lengthAdjustmentType31);
        java.lang.Object obj34 = null;
        java.lang.Object obj35 = textTitle9.draw(graphics2D16, rectangle2D29, obj34);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D29, rectangleEdge36);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double39 = dateAxis0.lengthToJava2D(0.0d, rectangle2D29, rectangleEdge38);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection40 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int41 = taskSeriesCollection40.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries43 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection40.add(taskSeries43);
        org.jfree.data.gantt.TaskSeries taskSeries46 = taskSeriesCollection40.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset48 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection40, (java.lang.Comparable) "CONTRACT");
        org.jfree.chart.plot.PiePlot3D piePlot3D49 = new org.jfree.chart.plot.PiePlot3D(pieDataset48);
        dateAxis0.setPlot((org.jfree.chart.plot.Plot) piePlot3D49);
        piePlot3D49.setCircular(false);
        java.lang.String str53 = piePlot3D49.getPlotType();
        java.awt.Stroke stroke54 = piePlot3D49.getLabelOutlineStroke();
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 3.0d + "'", double22 == 3.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.0d + "'", double24 == 3.0d);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(lengthAdjustmentType30);
        org.junit.Assert.assertNotNull(lengthAdjustmentType31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "CONTRACT" + "'", str32.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNull(obj35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNull(taskSeries46);
        org.junit.Assert.assertNotNull(pieDataset48);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Pie 3D Plot" + "'", str53.equals("Pie 3D Plot"));
        org.junit.Assert.assertNotNull(stroke54);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        float float4 = polarPlot0.getBackgroundAlpha();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        polarPlot0.setDataset(xYDataset5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        polarPlot0.zoomDomainAxes((double) 6, (double) (byte) -1, plotRenderingInfo9, point2D10);
        java.awt.Stroke stroke12 = polarPlot0.getRadiusGridlineStroke();
        java.awt.Stroke stroke13 = polarPlot0.getAngleGridlineStroke();
        java.awt.Paint paint14 = null;
        polarPlot0.setRadiusGridlinePaint(paint14);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("Tuesday", "java.awt.Color[r=255,g=175,b=175]", "Layer.BACKGROUND", "25-May-1927", "GradientPaintTransformType.HORIZONTAL");
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis0.setRangeWithMargins((org.jfree.data.Range) dateRange4, false, false);
        dateAxis0.setAutoRange(false);
        java.util.Date date10 = dateAxis0.getMinimumDate();
        dateAxis0.setLabelURL("Layer.BACKGROUND");
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = dateAxis0.getTickUnit();
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(dateTickUnit13);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 0.4d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getUpperMargin();
        java.awt.Shape shape2 = dateAxis0.getDownArrow();
        java.io.ObjectOutputStream objectOutputStream3 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape2, objectOutputStream3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer1 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint2 = waterfallBarRenderer1.getLastBarPaint();
        boolean boolean3 = rectangleEdge0.equals((java.lang.Object) waterfallBarRenderer1);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis5.getLabelInsets();
        double double8 = rectangleInsets6.trimWidth((double) (byte) 10);
        double double10 = rectangleInsets6.calculateTopInset((-1.0d));
        double double12 = rectangleInsets6.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str15 = labelBlock14.getToolTipText();
        java.lang.String str16 = labelBlock14.getURLText();
        java.awt.geom.Rectangle2D rectangle2D17 = labelBlock14.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType18 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType19 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str20 = lengthAdjustmentType19.toString();
        java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets6.createAdjustedRectangle(rectangle2D17, lengthAdjustmentType18, lengthAdjustmentType19);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState25 = waterfallBarRenderer1.initialise(graphics2D4, rectangle2D21, categoryPlot22, (int) ' ', plotRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(lengthAdjustmentType18);
        org.junit.Assert.assertNotNull(lengthAdjustmentType19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "CONTRACT" + "'", str20.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D21);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = textTitle2.getPosition();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge3);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis0);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis0.getTickMarkPosition();
        boolean boolean3 = dateAxis0.isInverted();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent5 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis4);
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis4.setTickUnit(dateTickUnit6);
        java.util.Date date8 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit6);
        dateAxis0.setVerticalTickLabels(true);
        dateAxis0.setAutoRangeMinimumSize((double) (short) 1);
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean4 = statisticalLineAndShapeRenderer3.getBaseItemLabelsVisible();
        int int5 = statisticalLineAndShapeRenderer3.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        statisticalLineAndShapeRenderer3.setSeriesNegativeItemLabelPosition(0, itemLabelPosition7);
        java.awt.Stroke stroke11 = statisticalLineAndShapeRenderer3.getItemOutlineStroke(4, (int) '4');
        boolean boolean12 = waterfallBarRenderer0.equals((java.lang.Object) statisticalLineAndShapeRenderer3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer14.setMaximumBarWidth((double) 2);
        java.awt.Shape shape18 = barRenderer14.lookupSeriesShape(2958465);
        statisticalLineAndShapeRenderer3.setSeriesShape((int) (byte) 0, shape18, false);
        statisticalLineAndShapeRenderer3.setUseFillPaint(true);
        java.awt.Paint paint23 = statisticalLineAndShapeRenderer3.getErrorIndicatorPaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(paint23);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint6 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        categoryAxis5.setTickMarkPaint(paint6);
        java.lang.String str8 = categoryAxis5.getLabel();
        categoryAxis5.setLabelAngle((double) '#');
        org.jfree.chart.plot.Plot plot11 = categoryAxis5.getPlot();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent13 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis12);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition14 = dateAxis12.getTickMarkPosition();
        boolean boolean15 = dateAxis12.isInverted();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis16);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis16.setTickUnit(dateTickUnit18);
        java.util.Date date20 = dateAxis12.calculateHighestVisibleTickValue(dateTickUnit18);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer23 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean24 = statisticalLineAndShapeRenderer23.getBaseItemLabelsVisible();
        int int25 = statisticalLineAndShapeRenderer23.getPassCount();
        java.awt.Color color27 = java.awt.Color.MAGENTA;
        statisticalLineAndShapeRenderer23.setSeriesFillPaint(0, (java.awt.Paint) color27, false);
        statisticalLineAndShapeRenderer23.setSeriesLinesVisible((int) '4', false);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        statisticalLineAndShapeRenderer23.setBaseOutlinePaint((java.awt.Paint) color33, false);
        dateAxis12.setTickLabelPaint((java.awt.Paint) color33);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset37 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double39 = defaultStatisticalCategoryDataset37.getRangeUpperBound(false);
        java.lang.Number number42 = defaultStatisticalCategoryDataset37.getMeanValue((java.lang.Comparable) 1, (java.lang.Comparable) (short) 0);
        java.util.List list43 = defaultStatisticalCategoryDataset37.getColumnKeys();
        int int45 = defaultStatisticalCategoryDataset37.getColumnIndex((java.lang.Comparable) "RectangleConstraintType.RANGE");
        try {
            intervalBarRenderer0.drawItem(graphics2D1, categoryItemRendererState2, rectangle2D3, categoryPlot4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset37, 0, (int) '#', (-329600));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(dateTickMarkPosition14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertNull(number42);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        java.lang.Object obj5 = null;
        boolean boolean6 = xYPlot0.equals(obj5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomDomainAxes((double) 0L, plotRenderingInfo8, point2D9);
        xYPlot0.setDomainCrosshairValue((-1.0d));
        org.jfree.chart.plot.Plot plot13 = xYPlot0.getRootPlot();
        xYPlot0.configureRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot0.getDomainAxis();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(plot13);
        org.junit.Assert.assertNull(valueAxis15);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int1 = taskSeriesCollection0.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries3 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection0.add(taskSeries3);
        int int5 = taskSeriesCollection0.getSeriesCount();
        try {
            java.lang.Comparable comparable7 = taskSeriesCollection0.getSeriesKey((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("CONTRACT", font2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = textTitle3.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment4, 2.0d, (double) (-460));
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(verticalAlignment4);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        java.awt.Stroke stroke2 = categoryAxis0.getAxisLineStroke();
        float float3 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = axisChangeEvent4.getType();
        java.lang.String str6 = chartChangeEventType5.toString();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(chartChangeEventType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str6.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = null;
        polarPlot0.markerChanged(markerChangeEvent1);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = polarPlot0.getRenderer();
        boolean boolean4 = polarPlot0.isRangeZoomable();
        org.junit.Assert.assertNull(polarItemRenderer3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.lang.String str3 = textTitle2.getToolTipText();
        java.lang.String str4 = textTitle2.getText();
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean6 = polarPlot5.isOutlineVisible();
        polarPlot5.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot5);
        textTitle2.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart9);
        org.jfree.chart.entity.EntityCollection entityCollection13 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo(entityCollection13);
        org.jfree.chart.entity.EntityCollection entityCollection15 = chartRenderingInfo14.getEntityCollection();
        try {
            java.awt.image.BufferedImage bufferedImage16 = jFreeChart9.createBufferedImage(9999, 0, chartRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (9999) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(entityCollection15);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = dateAxis4.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = dateAxis4.java2DToValue((double) 4, rectangle2D7, rectangleEdge8);
        java.awt.Shape shape10 = dateAxis4.getLeftArrow();
        int int11 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("hi!", font13);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer17 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer17.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint21 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        statisticalLineAndShapeRenderer17.setBasePaint(paint21);
        textTitle14.setBackgroundPaint(paint21);
        xYPlot0.setRangeZeroBaselinePaint(paint21);
        java.awt.Color color26 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke28 = polarPlot27.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', (java.awt.Paint) color26, stroke28);
        java.lang.String str30 = categoryMarker29.getLabel();
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker29);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = xYPlot33.getRangeAxisEdge(0);
        boolean boolean36 = xYPlot33.isRangeZeroBaselineVisible();
        java.awt.Paint paint37 = xYPlot33.getRangeZeroBaselinePaint();
        java.awt.Stroke stroke38 = xYPlot33.getRangeZeroBaselineStroke();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer41 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer41.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint47 = statisticalLineAndShapeRenderer41.getItemOutlinePaint((-1), 0);
        boolean boolean48 = statisticalLineAndShapeRenderer41.getUseOutlinePaint();
        statisticalLineAndShapeRenderer41.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.block.FlowArrangement flowArrangement51 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent52 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) flowArrangement51);
        statisticalLineAndShapeRenderer41.notifyListeners(rendererChangeEvent52);
        xYPlot33.rendererChanged(rendererChangeEvent52);
        xYPlot0.rendererChanged(rendererChangeEvent52);
        java.awt.Graphics2D graphics2D56 = null;
        org.jfree.chart.axis.AxisSpace axisSpace57 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = categoryAxis58.getLabelInsets();
        double double61 = rectangleInsets59.trimWidth((double) (byte) 10);
        double double63 = rectangleInsets59.calculateTopInset((-1.0d));
        double double65 = rectangleInsets59.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock67 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str68 = labelBlock67.getToolTipText();
        java.lang.String str69 = labelBlock67.getURLText();
        java.awt.geom.Rectangle2D rectangle2D70 = labelBlock67.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType71 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType72 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str73 = lengthAdjustmentType72.toString();
        java.awt.geom.Rectangle2D rectangle2D74 = rectangleInsets59.createAdjustedRectangle(rectangle2D70, lengthAdjustmentType71, lengthAdjustmentType72);
        org.jfree.chart.block.LabelBlock labelBlock76 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str77 = labelBlock76.getToolTipText();
        java.lang.String str78 = labelBlock76.getURLText();
        java.awt.geom.Rectangle2D rectangle2D79 = labelBlock76.getBounds();
        java.awt.geom.Rectangle2D rectangle2D80 = axisSpace57.shrink(rectangle2D74, rectangle2D79);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline81 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.List list82 = segmentedTimeline81.getExceptionSegments();
        xYPlot0.drawRangeTickBands(graphics2D56, rectangle2D79, list82);
        org.jfree.chart.plot.Plot plot84 = xYPlot0.getRootPlot();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 9.223372036854776E18d + "'", double9 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 4.0d + "'", double61 == 4.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 3.0d + "'", double63 == 3.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 3.0d + "'", double65 == 3.0d);
        org.junit.Assert.assertNull(str68);
        org.junit.Assert.assertNull(str69);
        org.junit.Assert.assertNotNull(rectangle2D70);
        org.junit.Assert.assertNotNull(lengthAdjustmentType71);
        org.junit.Assert.assertNotNull(lengthAdjustmentType72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "CONTRACT" + "'", str73.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D74);
        org.junit.Assert.assertNull(str77);
        org.junit.Assert.assertNull(str78);
        org.junit.Assert.assertNotNull(rectangle2D79);
        org.junit.Assert.assertNotNull(rectangle2D80);
        org.junit.Assert.assertNotNull(segmentedTimeline81);
        org.junit.Assert.assertNotNull(list82);
        org.junit.Assert.assertNotNull(plot84);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("LengthConstraintType.NONE");
        boolean boolean2 = numberAxis3D1.isInverted();
        double double3 = numberAxis3D1.getLowerBound();
        numberAxis3D1.setAutoRangeMinimumSize(9.223372036854776E18d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        java.lang.Object obj5 = null;
        boolean boolean6 = xYPlot0.equals(obj5);
        java.awt.Paint paint7 = xYPlot0.getDomainTickBandPaint();
        java.awt.Stroke stroke8 = null;
        try {
            xYPlot0.setRangeZeroBaselineStroke(stroke8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj1 = categoryAxis3D0.clone();
        categoryAxis3D0.configure();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent3 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3D0);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis3D0.getCategoryLabelPositions();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis7);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis7.setRange((org.jfree.data.Range) dateRange11);
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("hi!", font15);
        java.lang.String str17 = textTitle16.getToolTipText();
        textTitle16.setWidth(0.0d);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent20 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle16);
        java.awt.Color color21 = java.awt.Color.cyan;
        boolean boolean22 = textTitle16.equals((java.lang.Object) color21);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = categoryAxis24.getLabelInsets();
        double double27 = rectangleInsets25.trimWidth((double) (byte) 10);
        double double29 = rectangleInsets25.calculateTopInset((-1.0d));
        double double31 = rectangleInsets25.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock33 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str34 = labelBlock33.getToolTipText();
        java.lang.String str35 = labelBlock33.getURLText();
        java.awt.geom.Rectangle2D rectangle2D36 = labelBlock33.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType37 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType38 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str39 = lengthAdjustmentType38.toString();
        java.awt.geom.Rectangle2D rectangle2D40 = rectangleInsets25.createAdjustedRectangle(rectangle2D36, lengthAdjustmentType37, lengthAdjustmentType38);
        java.lang.Object obj41 = null;
        java.lang.Object obj42 = textTitle16.draw(graphics2D23, rectangle2D36, obj41);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = null;
        double double44 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D36, rectangleEdge43);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double46 = dateAxis7.lengthToJava2D(0.0d, rectangle2D36, rectangleEdge45);
        org.jfree.chart.axis.AxisSpace axisSpace47 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = categoryAxis48.getLabelInsets();
        double double51 = rectangleInsets49.trimWidth((double) (byte) 10);
        double double53 = rectangleInsets49.calculateTopInset((-1.0d));
        double double55 = rectangleInsets49.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock57 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str58 = labelBlock57.getToolTipText();
        java.lang.String str59 = labelBlock57.getURLText();
        java.awt.geom.Rectangle2D rectangle2D60 = labelBlock57.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType61 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType62 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str63 = lengthAdjustmentType62.toString();
        java.awt.geom.Rectangle2D rectangle2D64 = rectangleInsets49.createAdjustedRectangle(rectangle2D60, lengthAdjustmentType61, lengthAdjustmentType62);
        org.jfree.chart.block.LabelBlock labelBlock66 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str67 = labelBlock66.getToolTipText();
        java.lang.String str68 = labelBlock66.getURLText();
        java.awt.geom.Rectangle2D rectangle2D69 = labelBlock66.getBounds();
        java.awt.geom.Rectangle2D rectangle2D70 = axisSpace47.shrink(rectangle2D64, rectangle2D69);
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo72 = null;
        try {
            org.jfree.chart.axis.AxisState axisState73 = categoryAxis3D0.draw(graphics2D5, (double) (short) 0, rectangle2D36, rectangle2D70, rectangleEdge71, plotRenderingInfo72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 4.0d + "'", double27 == 4.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 3.0d + "'", double29 == 3.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 3.0d + "'", double31 == 3.0d);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(lengthAdjustmentType37);
        org.junit.Assert.assertNotNull(lengthAdjustmentType38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "CONTRACT" + "'", str39.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNull(obj42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertEquals((double) double46, Double.NaN, 0);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 4.0d + "'", double51 == 4.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 3.0d + "'", double53 == 3.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 3.0d + "'", double55 == 3.0d);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(lengthAdjustmentType61);
        org.junit.Assert.assertNotNull(lengthAdjustmentType62);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "CONTRACT" + "'", str63.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNull(str68);
        org.junit.Assert.assertNotNull(rectangle2D69);
        org.junit.Assert.assertNotNull(rectangle2D70);
        org.junit.Assert.assertNotNull(rectangleEdge71);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYPlot0.setRangeCrosshairStroke(stroke3);
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot0.getDataset();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke9 = polarPlot8.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', (java.awt.Paint) color7, stroke9);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection11 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int12 = taskSeriesCollection11.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries14 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection11.add(taskSeries14);
        org.jfree.data.gantt.TaskSeries taskSeries17 = taskSeriesCollection11.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection11, (java.lang.Comparable) "CONTRACT");
        boolean boolean20 = categoryMarker10.equals((java.lang.Object) taskSeriesCollection11);
        java.awt.Color color21 = java.awt.Color.GREEN;
        categoryMarker10.setPaint((java.awt.Paint) color21);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10);
        java.lang.String str24 = xYPlot0.getPlotType();
        org.jfree.chart.axis.ValueAxis valueAxis25 = xYPlot0.getDomainAxis();
        java.awt.Stroke stroke26 = xYPlot0.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(taskSeries17);
        org.junit.Assert.assertNotNull(pieDataset19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "XY Plot" + "'", str24.equals("XY Plot"));
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getRowCount();
        java.util.List list3 = defaultKeyedValues2D1.getColumnKeys();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = dateAxis4.getStandardTickUnits();
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis4.setRangeWithMargins((org.jfree.data.Range) dateRange8, false, false);
        dateAxis4.setAutoRange(false);
        java.util.Date date14 = dateAxis4.getMinimumDate();
        boolean boolean15 = dateAxis4.isVerticalTickLabels();
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str17 = dateTickUnit16.toString();
        double double18 = dateTickUnit16.getSize();
        dateAxis4.setTickUnit(dateTickUnit16);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis20);
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis20.setTickUnit(dateTickUnit22);
        java.util.Date date24 = dateAxis4.calculateLowestVisibleTickValue(dateTickUnit22);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) date24, (java.lang.Comparable) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTickUnit16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "DateTickUnit[DAY, 1]" + "'", str17.equals("DateTickUnit[DAY, 1]"));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.64E7d + "'", double18 == 8.64E7d);
        org.junit.Assert.assertNotNull(dateTickUnit22);
        org.junit.Assert.assertNotNull(date24);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        java.awt.Font font5 = statisticalLineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, rectangleAnchor8, (double) (short) 100, (double) 4);
        statisticalLineAndShapeRenderer2.setBaseShape(shape11, false);
        boolean boolean14 = statisticalLineAndShapeRenderer2.getUseFillPaint();
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalLineAndShapeRenderer2);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot16.getRangeAxisEdge(0);
        boolean boolean19 = xYPlot16.isRangeZeroBaselineVisible();
        java.awt.Paint paint20 = xYPlot16.getRangeZeroBaselinePaint();
        java.awt.Stroke stroke21 = xYPlot16.getRangeZeroBaselineStroke();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray22 = new org.jfree.chart.LegendItemSource[] { xYPlot16 };
        legendTitle15.setSources(legendItemSourceArray22);
        java.awt.Font font24 = legendTitle15.getItemFont();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape26, rectangleAnchor27, (double) (short) 100, (double) 4);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer33 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer33.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint39 = statisticalLineAndShapeRenderer33.getItemOutlinePaint((-1), 0);
        org.jfree.chart.title.LegendGraphic legendGraphic40 = new org.jfree.chart.title.LegendGraphic(shape30, paint39);
        java.awt.Paint paint41 = null;
        legendGraphic40.setLinePaint(paint41);
        java.awt.Stroke stroke43 = legendGraphic40.getLineStroke();
        java.awt.Color color44 = java.awt.Color.blue;
        legendGraphic40.setFillPaint((java.awt.Paint) color44);
        legendTitle15.setItemPaint((java.awt.Paint) color44);
        java.awt.Font font47 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        legendTitle15.setItemFont(font47);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(legendItemSourceArray22);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNull(stroke43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(font47);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.text.TextBlock textBlock2 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        textBlock2.draw(graphics2D3, (float) (byte) 100, (float) (byte) 1, textBlockAnchor6, (float) 7, (float) '4', (double) (short) 100);
        java.util.List list11 = textBlock2.getLines();
        org.jfree.chart.text.TextBlock textBlock12 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor16 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        textBlock12.draw(graphics2D13, (float) (byte) 100, (float) (byte) 1, textBlockAnchor16, (float) 7, (float) '4', (double) (short) 100);
        org.jfree.chart.text.TextAnchor textAnchor21 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.axis.CategoryTick categoryTick23 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 900000L, textBlock2, textBlockAnchor16, textAnchor21, (double) (-329600));
        java.lang.String str24 = categoryTick23.toString();
        java.lang.Object obj25 = categoryTick23.clone();
        boolean boolean26 = defaultDrawingSupplier0.equals(obj25);
        java.lang.Object obj27 = defaultDrawingSupplier0.clone();
        java.awt.Paint paint28 = defaultDrawingSupplier0.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(textBlockAnchor16);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean5 = statisticalLineAndShapeRenderer4.getBaseItemLabelsVisible();
        int int6 = statisticalLineAndShapeRenderer4.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = null;
        statisticalLineAndShapeRenderer4.setSeriesNegativeItemLabelPosition(0, itemLabelPosition8);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = statisticalLineAndShapeRenderer4.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = statisticalLineAndShapeRenderer4.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor15 = itemLabelPosition14.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType17 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        boolean boolean19 = categoryLabelWidthType17.equals((java.lang.Object) color18);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition21 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, textAnchor15, 8.64E7d, categoryLabelWidthType17, (float) 0L);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition22 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor24 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer27 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean28 = statisticalLineAndShapeRenderer27.getBaseItemLabelsVisible();
        int int29 = statisticalLineAndShapeRenderer27.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = null;
        statisticalLineAndShapeRenderer27.setSeriesNegativeItemLabelPosition(0, itemLabelPosition31);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator35 = statisticalLineAndShapeRenderer27.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = statisticalLineAndShapeRenderer27.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor38 = itemLabelPosition37.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType40 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.awt.Color color41 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        boolean boolean42 = categoryLabelWidthType40.equals((java.lang.Object) color41);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition44 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor23, textBlockAnchor24, textAnchor38, 8.64E7d, categoryLabelWidthType40, (float) 0L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor46 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer49 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean50 = statisticalLineAndShapeRenderer49.getBaseItemLabelsVisible();
        int int51 = statisticalLineAndShapeRenderer49.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition53 = null;
        statisticalLineAndShapeRenderer49.setSeriesNegativeItemLabelPosition(0, itemLabelPosition53);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator57 = statisticalLineAndShapeRenderer49.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition59 = statisticalLineAndShapeRenderer49.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor60 = itemLabelPosition59.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType62 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.awt.Color color63 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        boolean boolean64 = categoryLabelWidthType62.equals((java.lang.Object) color63);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition66 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor45, textBlockAnchor46, textAnchor60, 8.64E7d, categoryLabelWidthType62, (float) 0L);
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions67 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition21, categoryLabelPosition22, categoryLabelPosition44, categoryLabelPosition66);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bottom' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator12);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(categoryLabelWidthType17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(textBlockAnchor24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2 + "'", int29 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator35);
        org.junit.Assert.assertNotNull(itemLabelPosition37);
        org.junit.Assert.assertNotNull(textAnchor38);
        org.junit.Assert.assertNotNull(categoryLabelWidthType40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(textBlockAnchor46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2 + "'", int51 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator57);
        org.junit.Assert.assertNotNull(itemLabelPosition59);
        org.junit.Assert.assertNotNull(textAnchor60);
        org.junit.Assert.assertNotNull(categoryLabelWidthType62);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        java.awt.Stroke stroke10 = statisticalLineAndShapeRenderer2.getItemOutlineStroke(4, (int) '4');
        boolean boolean11 = statisticalLineAndShapeRenderer2.getAutoPopulateSeriesOutlinePaint();
        java.awt.Stroke stroke14 = statisticalLineAndShapeRenderer2.getItemStroke(6, 11);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        java.lang.Object obj5 = null;
        boolean boolean6 = xYPlot0.equals(obj5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomDomainAxes((double) 0L, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation(7, axisLocation12);
        java.awt.Paint paint14 = xYPlot0.getOutlinePaint();
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke18 = polarPlot17.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', (java.awt.Paint) color16, stroke18);
        java.awt.Paint paint20 = categoryMarker19.getLabelPaint();
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker19);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        int int2 = polarPlot0.getBackgroundImageAlignment();
        polarPlot0.addCornerTextItem("RectangleAnchor.TOP");
        polarPlot0.setAngleGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str2 = labelBlock1.getToolTipText();
        java.lang.Object obj3 = labelBlock1.clone();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getLabelInsets();
        double double4 = rectangleInsets2.trimWidth((double) (byte) 10);
        double double6 = rectangleInsets2.calculateTopInset((-1.0d));
        double double8 = rectangleInsets2.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str11 = labelBlock10.getToolTipText();
        java.lang.String str12 = labelBlock10.getURLText();
        java.awt.geom.Rectangle2D rectangle2D13 = labelBlock10.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType14 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str16 = lengthAdjustmentType15.toString();
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets2.createAdjustedRectangle(rectangle2D13, lengthAdjustmentType14, lengthAdjustmentType15);
        org.jfree.chart.block.LabelBlock labelBlock19 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str20 = labelBlock19.getToolTipText();
        java.lang.String str21 = labelBlock19.getURLText();
        java.awt.geom.Rectangle2D rectangle2D22 = labelBlock19.getBounds();
        java.awt.geom.Rectangle2D rectangle2D23 = axisSpace0.shrink(rectangle2D17, rectangle2D22);
        java.lang.Object obj24 = axisSpace0.clone();
        java.lang.String str25 = axisSpace0.toString();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(lengthAdjustmentType14);
        org.junit.Assert.assertNotNull(lengthAdjustmentType15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "CONTRACT" + "'", str16.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setMaximumBarWidth((double) 2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = barRenderer0.getNegativeItemLabelPositionFallback();
        barRenderer0.setBase((double) 35L);
        org.junit.Assert.assertNull(itemLabelPosition3);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis0.setRangeWithMargins((org.jfree.data.Range) dateRange4, false, false);
        dateAxis0.setAutoRange(false);
        double double10 = dateAxis0.getAutoRangeMinimumSize();
        dateAxis0.setInverted(true);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline13 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.List list14 = segmentedTimeline13.getExceptionSegments();
        dateAxis0.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline13);
        java.lang.Object obj16 = null;
        boolean boolean17 = segmentedTimeline13.equals(obj16);
        long long18 = segmentedTimeline13.getSegmentsGroupSize();
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(segmentedTimeline13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 604800000L + "'", long18 == 604800000L);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int1 = taskSeriesCollection0.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries3 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection0.add(taskSeries3);
        org.jfree.data.gantt.TaskSeries taskSeries6 = taskSeriesCollection0.getSeries((java.lang.Comparable) 1.0d);
        int int7 = taskSeriesCollection0.getColumnCount();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection8 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int9 = taskSeriesCollection8.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries11 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection8.add(taskSeries11);
        taskSeriesCollection0.remove(taskSeries11);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(taskSeries6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.TRUNCATE;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean2 = areaRendererEndType0.equals((java.lang.Object) polarPlot1);
        java.awt.Paint paint3 = polarPlot1.getBackgroundPaint();
        org.junit.Assert.assertNotNull(areaRendererEndType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("hi!", "Polar Plot", "Polar Plot");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis4.getLabelInsets();
        boolean boolean6 = standardCategoryURLGenerator3.equals((java.lang.Object) categoryAxis4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = ringPlot0.getLegendLabelGenerator();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = ringPlot0.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNull(pieSectionLabelGenerator6);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (short) 100, (double) 4);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint14 = statisticalLineAndShapeRenderer8.getItemOutlinePaint((-1), 0);
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape5, paint14);
        java.awt.Paint paint16 = null;
        legendGraphic15.setLinePaint(paint16);
        java.awt.Paint paint18 = null;
        legendGraphic15.setFillPaint(paint18);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 1, (double) (short) 10, false);
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean8 = polarPlot7.isOutlineVisible();
        polarPlot7.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot7);
        java.awt.Stroke stroke12 = jFreeChart11.getBorderStroke();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent15 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) false, jFreeChart11, 9999, (int) '4');
        org.jfree.chart.entity.EntityCollection entityCollection20 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = new org.jfree.chart.ChartRenderingInfo(entityCollection20);
        org.jfree.chart.entity.EntityCollection entityCollection22 = chartRenderingInfo21.getEntityCollection();
        java.awt.image.BufferedImage bufferedImage23 = jFreeChart11.createBufferedImage((int) (short) 100, 1900, (double) (byte) 10, (double) (short) -1, chartRenderingInfo21);
        org.jfree.chart.ui.ProjectInfo projectInfo27 = new org.jfree.chart.ui.ProjectInfo("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "Range[135.0,135.0]", "({0}, {1}) = {3} - {4}", (java.awt.Image) bufferedImage23, "", "({0}, {1}) = {2}", "java.awt.Color[r=255,g=175,b=175]");
        java.lang.String str28 = projectInfo27.getInfo();
        org.jfree.chart.text.TextAnchor textAnchor29 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.awt.Image image33 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo37 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image33, "", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray38 = projectInfo37.getLibraries();
        boolean boolean39 = textAnchor29.equals((java.lang.Object) projectInfo37);
        java.awt.Image image40 = null;
        projectInfo37.setLogo(image40);
        projectInfo27.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo37);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(entityCollection22);
        org.junit.Assert.assertNotNull(bufferedImage23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "({0}, {1}) = {3} - {4}" + "'", str28.equals("({0}, {1}) = {3} - {4}"));
        org.junit.Assert.assertNotNull(textAnchor29);
        org.junit.Assert.assertNotNull(libraryArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYPlot0.setRangeCrosshairStroke(stroke3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot0.setRenderer((int) (short) 1, xYItemRenderer6);
        xYPlot0.mapDatasetToRangeAxis((-329600), (int) (short) -1);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer13.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint17 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        statisticalLineAndShapeRenderer13.setBasePaint(paint17);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = categoryAxis19.getLabelInsets();
        java.awt.Stroke stroke21 = categoryAxis19.getAxisLineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = categoryAxis22.getLabelInsets();
        double double25 = rectangleInsets23.trimWidth((double) (byte) 10);
        double double27 = rectangleInsets23.calculateTopInset((-1.0d));
        org.jfree.chart.block.LineBorder lineBorder28 = new org.jfree.chart.block.LineBorder(paint17, stroke21, rectangleInsets23);
        xYPlot0.setAxisOffset(rectangleInsets23);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent32 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis31);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition33 = dateAxis31.getTickMarkPosition();
        boolean boolean34 = dateAxis31.isInverted();
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent36 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis35);
        org.jfree.chart.axis.DateTickUnit dateTickUnit37 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis35.setTickUnit(dateTickUnit37);
        java.util.Date date39 = dateAxis31.calculateHighestVisibleTickValue(dateTickUnit37);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer42 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean43 = statisticalLineAndShapeRenderer42.getBaseItemLabelsVisible();
        int int44 = statisticalLineAndShapeRenderer42.getPassCount();
        java.awt.Color color46 = java.awt.Color.MAGENTA;
        statisticalLineAndShapeRenderer42.setSeriesFillPaint(0, (java.awt.Paint) color46, false);
        statisticalLineAndShapeRenderer42.setSeriesLinesVisible((int) '4', false);
        java.awt.Color color52 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        statisticalLineAndShapeRenderer42.setBaseOutlinePaint((java.awt.Paint) color52, false);
        dateAxis31.setTickLabelPaint((java.awt.Paint) color52);
        xYPlot0.setDomainAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis31);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dateTickUnit37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2 + "'", int44 == 2);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color52);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke7 = polarPlot6.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', (java.awt.Paint) color5, stroke7);
        java.lang.Object obj9 = categoryMarker8.clone();
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.awt.Image image17 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo21 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image17, "", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray22 = projectInfo21.getLibraries();
        boolean boolean23 = textAnchor13.equals((java.lang.Object) projectInfo21);
        org.jfree.chart.axis.NumberTick numberTick25 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 1.0E-5d, "CONTRACT", textAnchor12, textAnchor13, 0.4d);
        java.awt.Image image29 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo33 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image29, "", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray34 = projectInfo33.getLibraries();
        java.lang.String str35 = projectInfo33.getName();
        boolean boolean36 = numberTick25.equals((java.lang.Object) str35);
        org.jfree.chart.text.TextAnchor textAnchor37 = numberTick25.getTextAnchor();
        categoryMarker8.setLabelTextAnchor(textAnchor37);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Layer.BACKGROUND", graphics2D1, (float) 500, 0.0f, textAnchor37, 0.0d, (float) 900000L, (float) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(libraryArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(libraryArray34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(textAnchor37);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0);
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.data.time.TimePeriod timePeriod1 = null;
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("DateTickUnit[DAY, 1]", timePeriod1);
        task2.setDescription("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeRow((java.lang.Comparable) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str5 = spreadsheetDate4.getDescription();
        int int6 = spreadsheetDate4.getDayOfWeek();
        boolean boolean7 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str10 = spreadsheetDate9.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str13 = spreadsheetDate12.getDescription();
        int int14 = spreadsheetDate12.getDayOfWeek();
        boolean boolean15 = spreadsheetDate9.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(8);
        boolean boolean19 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, (org.jfree.data.time.SerialDate) spreadsheetDate17, 10);
        org.jfree.data.time.SerialDate serialDate21 = spreadsheetDate17.getPreviousDayOfWeek(7);
        spreadsheetDate17.setDescription("java.awt.Color[r=255,g=175,b=175]");
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(serialDate21);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        java.awt.Image image4 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image4, "", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray9 = projectInfo8.getLibraries();
        java.lang.String str10 = projectInfo8.getName();
        boolean boolean11 = borderArrangement0.equals((java.lang.Object) projectInfo8);
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        boolean boolean13 = borderArrangement0.equals((java.lang.Object) ringPlot12);
        borderArrangement0.clear();
        org.junit.Assert.assertNotNull(libraryArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("({0}, {1}) = {2}");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: ({0}, {1}) = {2}" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: ({0}, {1}) = {2}"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 1, (double) (short) 10, false);
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block5 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean9 = statisticalLineAndShapeRenderer8.getBaseItemLabelsVisible();
        int int10 = statisticalLineAndShapeRenderer8.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        statisticalLineAndShapeRenderer8.setSeriesNegativeItemLabelPosition(0, itemLabelPosition12);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator16 = statisticalLineAndShapeRenderer8.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = statisticalLineAndShapeRenderer8.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        flowArrangement4.add(block5, (java.lang.Object) itemLabelPosition18);
        stackedBarRenderer3D3.setBaseNegativeItemLabelPosition(itemLabelPosition18);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent24 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis23);
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis23.setTickUnit(dateTickUnit25);
        org.jfree.chart.plot.Marker marker27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        stackedBarRenderer3D3.drawRangeMarker(graphics2D21, categoryPlot22, (org.jfree.chart.axis.ValueAxis) dateAxis23, marker27, rectangle2D28);
        java.awt.Stroke stroke32 = stackedBarRenderer3D3.getItemOutlineStroke(11, 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = stackedBarRenderer3D3.getPlot();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator16);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(dateTickUnit25);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(categoryPlot33);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("GradientPaintTransformType.HORIZONTAL");
        java.lang.Object obj2 = categoryAxis1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray7 = new java.lang.Number[][] { numberArray2, numberArray3, numberArray4, numberArray5, numberArray6 };
        org.jfree.data.category.CategoryDataset categoryDataset8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("DateTickUnit[DAY, 1]", "LengthConstraintType.NONE", numberArray7);
        java.lang.Number[] numberArray11 = new java.lang.Number[] {};
        java.lang.Number[] numberArray12 = new java.lang.Number[] {};
        java.lang.Number[] numberArray13 = new java.lang.Number[] {};
        java.lang.Number[] numberArray14 = new java.lang.Number[] {};
        java.lang.Number[] numberArray15 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray11, numberArray12, numberArray13, numberArray14, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("DateTickUnit[DAY, 1]", "LengthConstraintType.NONE", numberArray16);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset18 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray7, numberArray16);
        java.util.List list19 = defaultIntervalCategoryDataset18.getColumnKeys();
        java.lang.Comparable[] comparableArray22 = new java.lang.Comparable[] { 100.0f, 1900 };
        try {
            defaultIntervalCategoryDataset18.setSeriesKeys(comparableArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of series keys does not match the data.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(categoryDataset8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(comparableArray22);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        java.lang.Number number7 = null;
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D9 = new org.jfree.data.DefaultKeyedValues2D(false);
        java.util.List list10 = defaultKeyedValues2D9.getRowKeys();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem11 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 3, (java.lang.Number) 2958465, (java.lang.Number) (-1.0f), (java.lang.Number) 0.05d, (java.lang.Number) 10.0d, (java.lang.Number) (-1), (java.lang.Number) (byte) 100, number7, list10);
        java.lang.Number number12 = boxAndWhiskerItem11.getMinRegularValue();
        java.lang.Number number13 = boxAndWhiskerItem11.getMean();
        java.lang.Number number14 = boxAndWhiskerItem11.getMaxOutlier();
        java.lang.Number number15 = boxAndWhiskerItem11.getMaxRegularValue();
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 10.0d + "'", number12.equals(10.0d));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 3 + "'", number13.equals(3));
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (-1) + "'", number15.equals((-1)));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = barRenderer0.getPlot();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = barRenderer0.getNegativeItemLabelPositionFallback();
        java.awt.Paint paint3 = barRenderer0.getBaseOutlinePaint();
        org.junit.Assert.assertNull(categoryPlot1);
        org.junit.Assert.assertNull(itemLabelPosition2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Size2D[width=0.0, height=1.0]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        java.awt.Font font5 = statisticalLineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, rectangleAnchor8, (double) (short) 100, (double) 4);
        statisticalLineAndShapeRenderer2.setBaseShape(shape11, false);
        boolean boolean14 = statisticalLineAndShapeRenderer2.getUseFillPaint();
        statisticalLineAndShapeRenderer2.setSeriesItemLabelsVisible(2958465, (java.lang.Boolean) false, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer19.setMaximumBarWidth((double) 2);
        java.awt.Shape shape23 = barRenderer19.lookupSeriesShape(2958465);
        statisticalLineAndShapeRenderer2.setBaseShape(shape23);
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot25.getRangeAxisEdge(0);
        boolean boolean28 = xYPlot25.isRangeZeroBaselineVisible();
        java.awt.Paint paint29 = xYPlot25.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = xYPlot25.getOrientation();
        boolean boolean31 = xYPlot25.isDomainCrosshairLockedOnData();
        statisticalLineAndShapeRenderer2.removeChangeListener((org.jfree.chart.event.RendererChangeListener) xYPlot25);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        java.awt.Stroke stroke10 = statisticalLineAndShapeRenderer2.getItemOutlineStroke(4, (int) '4');
        statisticalLineAndShapeRenderer2.setItemLabelAnchorOffset((double) (short) 1);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean17 = statisticalLineAndShapeRenderer16.getBaseItemLabelsVisible();
        int int18 = statisticalLineAndShapeRenderer16.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = null;
        statisticalLineAndShapeRenderer16.setSeriesNegativeItemLabelPosition(0, itemLabelPosition20);
        java.awt.Stroke stroke24 = statisticalLineAndShapeRenderer16.getItemOutlineStroke(4, (int) '4');
        statisticalLineAndShapeRenderer16.setItemLabelAnchorOffset((double) (short) 1);
        java.awt.Stroke stroke27 = statisticalLineAndShapeRenderer16.getBaseOutlineStroke();
        statisticalLineAndShapeRenderer2.setSeriesOutlineStroke(0, stroke27, false);
        java.awt.Paint paint31 = statisticalLineAndShapeRenderer2.getSeriesOutlinePaint((int) (byte) 1);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent35 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis34);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition36 = dateAxis34.getTickMarkPosition();
        boolean boolean37 = dateAxis34.isInverted();
        org.jfree.chart.plot.PolarPlot polarPlot38 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint39 = polarPlot38.getOutlinePaint();
        java.awt.Stroke stroke40 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot38.setOutlineStroke(stroke40);
        java.lang.String str42 = polarPlot38.getPlotType();
        java.awt.Paint paint43 = polarPlot38.getOutlinePaint();
        java.awt.Paint paint44 = polarPlot38.getBackgroundPaint();
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer48 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer48.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint54 = statisticalLineAndShapeRenderer48.getItemOutlinePaint((-1), 0);
        boolean boolean56 = statisticalLineAndShapeRenderer48.isSeriesItemLabelsVisible(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition59 = statisticalLineAndShapeRenderer48.getNegativeItemLabelPosition((int) (short) 1, (int) (byte) 100);
        java.awt.Font font62 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle63 = new org.jfree.chart.title.TextTitle("hi!", font62);
        java.lang.String str64 = textTitle63.getToolTipText();
        textTitle63.setWidth(0.0d);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent67 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle63);
        java.awt.Color color68 = java.awt.Color.cyan;
        boolean boolean69 = textTitle63.equals((java.lang.Object) color68);
        java.awt.Graphics2D graphics2D70 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis71 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = categoryAxis71.getLabelInsets();
        double double74 = rectangleInsets72.trimWidth((double) (byte) 10);
        double double76 = rectangleInsets72.calculateTopInset((-1.0d));
        double double78 = rectangleInsets72.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock80 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str81 = labelBlock80.getToolTipText();
        java.lang.String str82 = labelBlock80.getURLText();
        java.awt.geom.Rectangle2D rectangle2D83 = labelBlock80.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType84 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType85 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str86 = lengthAdjustmentType85.toString();
        java.awt.geom.Rectangle2D rectangle2D87 = rectangleInsets72.createAdjustedRectangle(rectangle2D83, lengthAdjustmentType84, lengthAdjustmentType85);
        java.lang.Object obj88 = null;
        java.lang.Object obj89 = textTitle63.draw(graphics2D70, rectangle2D83, obj88);
        statisticalLineAndShapeRenderer48.setSeriesShape(2019, (java.awt.Shape) rectangle2D83, false);
        polarPlot38.drawBackgroundImage(graphics2D45, rectangle2D83);
        statisticalLineAndShapeRenderer2.drawRangeGridline(graphics2D32, categoryPlot33, (org.jfree.chart.axis.ValueAxis) dateAxis34, rectangle2D83, (double) 'a');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(dateTickMarkPosition36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Polar Plot" + "'", str42.equals("Polar Plot"));
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition59);
        org.junit.Assert.assertNotNull(font62);
        org.junit.Assert.assertNull(str64);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 4.0d + "'", double74 == 4.0d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 3.0d + "'", double76 == 3.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 3.0d + "'", double78 == 3.0d);
        org.junit.Assert.assertNull(str81);
        org.junit.Assert.assertNull(str82);
        org.junit.Assert.assertNotNull(rectangle2D83);
        org.junit.Assert.assertNotNull(lengthAdjustmentType84);
        org.junit.Assert.assertNotNull(lengthAdjustmentType85);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "CONTRACT" + "'", str86.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D87);
        org.junit.Assert.assertNull(obj89);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        java.awt.Paint paint5 = jFreeChart4.getBorderPaint();
        java.lang.Object obj6 = jFreeChart4.getTextAntiAlias();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str12 = labelBlock11.getToolTipText();
        java.lang.String str13 = labelBlock11.getURLText();
        java.awt.geom.Rectangle2D rectangle2D14 = labelBlock11.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D14, "Polar Plot", "LengthConstraintType.NONE");
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge18);
        double double20 = dateAxis8.valueToJava2D((double) 128, rectangle2D14, rectangleEdge18);
        org.jfree.chart.entity.EntityCollection entityCollection21 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = new org.jfree.chart.ChartRenderingInfo(entityCollection21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = categoryAxis23.getLabelInsets();
        double double26 = rectangleInsets24.trimWidth((double) (byte) 10);
        double double28 = rectangleInsets24.calculateTopInset((-1.0d));
        double double30 = rectangleInsets24.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock32 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str33 = labelBlock32.getToolTipText();
        java.lang.String str34 = labelBlock32.getURLText();
        java.awt.geom.Rectangle2D rectangle2D35 = labelBlock32.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType36 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType37 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str38 = lengthAdjustmentType37.toString();
        java.awt.geom.Rectangle2D rectangle2D39 = rectangleInsets24.createAdjustedRectangle(rectangle2D35, lengthAdjustmentType36, lengthAdjustmentType37);
        chartRenderingInfo22.setChartArea(rectangle2D35);
        try {
            jFreeChart4.draw(graphics2D7, rectangle2D14, chartRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 3.0d + "'", double28 == 3.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(lengthAdjustmentType36);
        org.junit.Assert.assertNotNull(lengthAdjustmentType37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "CONTRACT" + "'", str38.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D39);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = dateAxis4.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = dateAxis4.java2DToValue((double) 4, rectangle2D7, rectangleEdge8);
        java.awt.Shape shape10 = dateAxis4.getLeftArrow();
        int int11 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("hi!", font13);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer17 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer17.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint21 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        statisticalLineAndShapeRenderer17.setBasePaint(paint21);
        textTitle14.setBackgroundPaint(paint21);
        xYPlot0.setRangeZeroBaselinePaint(paint21);
        java.awt.Color color26 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke28 = polarPlot27.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', (java.awt.Paint) color26, stroke28);
        java.lang.String str30 = categoryMarker29.getLabel();
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker29);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = xYPlot33.getRangeAxisEdge(0);
        boolean boolean36 = xYPlot33.isRangeZeroBaselineVisible();
        java.awt.Paint paint37 = xYPlot33.getRangeZeroBaselinePaint();
        java.awt.Stroke stroke38 = xYPlot33.getRangeZeroBaselineStroke();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer41 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer41.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint47 = statisticalLineAndShapeRenderer41.getItemOutlinePaint((-1), 0);
        boolean boolean48 = statisticalLineAndShapeRenderer41.getUseOutlinePaint();
        statisticalLineAndShapeRenderer41.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.block.FlowArrangement flowArrangement51 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent52 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) flowArrangement51);
        statisticalLineAndShapeRenderer41.notifyListeners(rendererChangeEvent52);
        xYPlot33.rendererChanged(rendererChangeEvent52);
        xYPlot0.rendererChanged(rendererChangeEvent52);
        java.awt.Graphics2D graphics2D56 = null;
        org.jfree.chart.axis.AxisSpace axisSpace57 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = categoryAxis58.getLabelInsets();
        double double61 = rectangleInsets59.trimWidth((double) (byte) 10);
        double double63 = rectangleInsets59.calculateTopInset((-1.0d));
        double double65 = rectangleInsets59.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock67 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str68 = labelBlock67.getToolTipText();
        java.lang.String str69 = labelBlock67.getURLText();
        java.awt.geom.Rectangle2D rectangle2D70 = labelBlock67.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType71 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType72 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str73 = lengthAdjustmentType72.toString();
        java.awt.geom.Rectangle2D rectangle2D74 = rectangleInsets59.createAdjustedRectangle(rectangle2D70, lengthAdjustmentType71, lengthAdjustmentType72);
        org.jfree.chart.block.LabelBlock labelBlock76 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str77 = labelBlock76.getToolTipText();
        java.lang.String str78 = labelBlock76.getURLText();
        java.awt.geom.Rectangle2D rectangle2D79 = labelBlock76.getBounds();
        java.awt.geom.Rectangle2D rectangle2D80 = axisSpace57.shrink(rectangle2D74, rectangle2D79);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline81 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.List list82 = segmentedTimeline81.getExceptionSegments();
        xYPlot0.drawRangeTickBands(graphics2D56, rectangle2D79, list82);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray84 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot0.setRenderers(xYItemRendererArray84);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis87 = xYPlot0.getRangeAxisForDataset(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 'index' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 9.223372036854776E18d + "'", double9 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 4.0d + "'", double61 == 4.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 3.0d + "'", double63 == 3.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 3.0d + "'", double65 == 3.0d);
        org.junit.Assert.assertNull(str68);
        org.junit.Assert.assertNull(str69);
        org.junit.Assert.assertNotNull(rectangle2D70);
        org.junit.Assert.assertNotNull(lengthAdjustmentType71);
        org.junit.Assert.assertNotNull(lengthAdjustmentType72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "CONTRACT" + "'", str73.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D74);
        org.junit.Assert.assertNull(str77);
        org.junit.Assert.assertNull(str78);
        org.junit.Assert.assertNotNull(rectangle2D79);
        org.junit.Assert.assertNotNull(rectangle2D80);
        org.junit.Assert.assertNotNull(segmentedTimeline81);
        org.junit.Assert.assertNotNull(list82);
        org.junit.Assert.assertNotNull(xYItemRendererArray84);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        double double3 = ringPlot0.getMaximumLabelWidth();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!", font7);
        java.awt.Paint paint9 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("({0}, {1}) = {2}", font7, paint9);
        boolean boolean11 = ringPlot0.equals((java.lang.Object) textLine10);
        java.awt.Image image12 = null;
        ringPlot0.setBackgroundImage(image12);
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("hi!", font15);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer19 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer19.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint23 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        statisticalLineAndShapeRenderer19.setBasePaint(paint23);
        textTitle16.setBackgroundPaint(paint23);
        java.awt.Stroke stroke26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryAxis27.getLabelInsets();
        double double30 = rectangleInsets28.trimWidth((double) (byte) 10);
        double double32 = rectangleInsets28.calculateTopInset((-1.0d));
        org.jfree.chart.block.LineBorder lineBorder33 = new org.jfree.chart.block.LineBorder(paint23, stroke26, rectangleInsets28);
        ringPlot0.setShadowPaint(paint23);
        ringPlot0.setShadowXOffset((double) 9);
        ringPlot0.setOuterSeparatorExtension((double) '4');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 4.0d + "'", double30 == 4.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.0d + "'", double32 == 3.0d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        ringPlot0.setMinimumArcAngleToDraw(9.223372036854776E18d);
        java.awt.Stroke stroke5 = ringPlot0.getLabelOutlineStroke();
        java.lang.Comparable comparable6 = null;
        try {
            java.awt.Stroke stroke7 = ringPlot0.getSectionOutlineStroke(comparable6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("LengthConstraintType.NONE");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource4);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (short) 100, (double) 4);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint14 = statisticalLineAndShapeRenderer8.getItemOutlinePaint((-1), 0);
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape5, paint14);
        java.awt.Paint paint16 = null;
        legendGraphic15.setLinePaint(paint16);
        java.awt.Stroke stroke18 = legendGraphic15.getLineStroke();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape20, rectangleAnchor21, (double) (short) 100, (double) 4);
        boolean boolean26 = rectangleAnchor21.equals((java.lang.Object) "Range[1.0,1.0]");
        legendGraphic15.setShapeLocation(rectangleAnchor21);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(stroke18);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        defaultKeyedValues2D0.addValue((java.lang.Number) (byte) 1, (java.lang.Comparable) 0.4d, (java.lang.Comparable) "({0}, {1}) = {2}");
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis1);
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis1.setRange((org.jfree.data.Range) dateRange5);
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font9);
        java.lang.String str11 = textTitle10.getToolTipText();
        textTitle10.setWidth(0.0d);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent14 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle10);
        java.awt.Color color15 = java.awt.Color.cyan;
        boolean boolean16 = textTitle10.equals((java.lang.Object) color15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = categoryAxis18.getLabelInsets();
        double double21 = rectangleInsets19.trimWidth((double) (byte) 10);
        double double23 = rectangleInsets19.calculateTopInset((-1.0d));
        double double25 = rectangleInsets19.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock27 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str28 = labelBlock27.getToolTipText();
        java.lang.String str29 = labelBlock27.getURLText();
        java.awt.geom.Rectangle2D rectangle2D30 = labelBlock27.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType31 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType32 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str33 = lengthAdjustmentType32.toString();
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets19.createAdjustedRectangle(rectangle2D30, lengthAdjustmentType31, lengthAdjustmentType32);
        java.lang.Object obj35 = null;
        java.lang.Object obj36 = textTitle10.draw(graphics2D17, rectangle2D30, obj35);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = null;
        double double38 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D30, rectangleEdge37);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double40 = dateAxis1.lengthToJava2D(0.0d, rectangle2D30, rectangleEdge39);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection41 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int42 = taskSeriesCollection41.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries44 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection41.add(taskSeries44);
        org.jfree.data.gantt.TaskSeries taskSeries47 = taskSeriesCollection41.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection41, (java.lang.Comparable) "CONTRACT");
        org.jfree.chart.plot.PiePlot3D piePlot3D50 = new org.jfree.chart.plot.PiePlot3D(pieDataset49);
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) piePlot3D50);
        piePlot3D50.setCircular(false);
        java.lang.String str54 = piePlot3D50.getPlotType();
        org.jfree.chart.JFreeChart jFreeChart55 = new org.jfree.chart.JFreeChart("ClassContext", (org.jfree.chart.plot.Plot) piePlot3D50);
        piePlot3D50.setLabelLinkMargin(5.0d);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 3.0d + "'", double23 == 3.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 3.0d + "'", double25 == 3.0d);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(lengthAdjustmentType31);
        org.junit.Assert.assertNotNull(lengthAdjustmentType32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "CONTRACT" + "'", str33.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(obj36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNull(taskSeries47);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Pie 3D Plot" + "'", str54.equals("Pie 3D Plot"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = statisticalLineAndShapeRenderer2.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        polarPlot11.markerChanged(markerChangeEvent12);
        java.lang.String str14 = polarPlot11.getNoDataMessage();
        java.lang.Object obj15 = polarPlot11.clone();
        boolean boolean16 = statisticalLineAndShapeRenderer2.equals(obj15);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection1 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection1.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries4 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection1.add(taskSeries4);
        int int6 = taskSeriesCollection1.getSeriesCount();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) borderArrangement0, (org.jfree.data.general.Dataset) taskSeriesCollection1, (java.lang.Comparable) "ClassContext");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        java.lang.Object obj5 = null;
        boolean boolean6 = xYPlot0.equals(obj5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomDomainAxes((double) 0L, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot0.setRangeAxisLocation(7, axisLocation12);
        java.awt.Paint paint14 = xYPlot0.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder15);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.List list1 = segmentedTimeline0.getExceptionSegments();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D3 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int4 = defaultKeyedValues2D3.getRowCount();
        java.util.List list5 = defaultKeyedValues2D3.getColumnKeys();
        segmentedTimeline0.setExceptionSegments(list5);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 1, (double) (short) 10, false);
        java.awt.Font font5 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        stackedBarRenderer3D4.setBaseItemLabelFont(font5, true);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis8);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition10 = dateAxis8.getTickMarkPosition();
        boolean boolean11 = dateAxis8.isInverted();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent13 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis12);
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis12.setTickUnit(dateTickUnit14);
        java.util.Date date16 = dateAxis8.calculateHighestVisibleTickValue(dateTickUnit14);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer19 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean20 = statisticalLineAndShapeRenderer19.getBaseItemLabelsVisible();
        int int21 = statisticalLineAndShapeRenderer19.getPassCount();
        java.awt.Color color23 = java.awt.Color.MAGENTA;
        statisticalLineAndShapeRenderer19.setSeriesFillPaint(0, (java.awt.Paint) color23, false);
        statisticalLineAndShapeRenderer19.setSeriesLinesVisible((int) '4', false);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        statisticalLineAndShapeRenderer19.setBaseOutlinePaint((java.awt.Paint) color29, false);
        dateAxis8.setTickLabelPaint((java.awt.Paint) color29);
        org.jfree.chart.block.LabelBlock labelBlock33 = new org.jfree.chart.block.LabelBlock("ClassContext", font5, (java.awt.Paint) color29);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(dateTickMarkPosition10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color29);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D2 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int3 = defaultKeyedValues2D2.getRowCount();
        java.util.List list4 = defaultKeyedValues2D2.getColumnKeys();
        boolean boolean5 = waterfallBarRenderer0.equals((java.lang.Object) list4);
        java.awt.Paint paint6 = waterfallBarRenderer0.getFirstBarPaint();
        java.awt.Paint paint7 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        waterfallBarRenderer0.setNegativeBarPaint(paint7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        waterfallBarRenderer0.setBasePaint((java.awt.Paint) color9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean4 = statisticalLineAndShapeRenderer3.getBaseItemLabelsVisible();
        int int5 = statisticalLineAndShapeRenderer3.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        statisticalLineAndShapeRenderer3.setSeriesNegativeItemLabelPosition(0, itemLabelPosition7);
        java.awt.Stroke stroke11 = statisticalLineAndShapeRenderer3.getItemOutlineStroke(4, (int) '4');
        boolean boolean12 = waterfallBarRenderer0.equals((java.lang.Object) statisticalLineAndShapeRenderer3);
        boolean boolean15 = statisticalLineAndShapeRenderer3.getItemShapeVisible(1, (-1));
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesPaint(100, (java.awt.Paint) color17, false);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D21 = new org.jfree.chart.renderer.category.LineRenderer3D();
        double double22 = lineRenderer3D21.getXOffset();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        dateAxis25.resizeRange(1.0d);
        org.jfree.chart.util.Size2D size2D30 = new org.jfree.chart.util.Size2D(0.0d, (double) 1.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, (double) 100L, (double) 0L, rectangleAnchor33);
        lineRenderer3D21.drawRangeGridline(graphics2D23, categoryPlot24, (org.jfree.chart.axis.ValueAxis) dateAxis25, rectangle2D34, (double) 100.0f);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator41 = new org.jfree.chart.urls.StandardCategoryURLGenerator("hi!", "Polar Plot", "Polar Plot");
        lineRenderer3D21.setSeriesURLGenerator((int) '4', (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator41);
        statisticalLineAndShapeRenderer3.setSeriesURLGenerator(100, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator41);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 12.0d + "'", double22 == 12.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.axis.AxisSpace axisSpace1 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis2.getLabelInsets();
        double double5 = rectangleInsets3.trimWidth((double) (byte) 10);
        double double7 = rectangleInsets3.calculateTopInset((-1.0d));
        double double9 = rectangleInsets3.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str12 = labelBlock11.getToolTipText();
        java.lang.String str13 = labelBlock11.getURLText();
        java.awt.geom.Rectangle2D rectangle2D14 = labelBlock11.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str17 = lengthAdjustmentType16.toString();
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets3.createAdjustedRectangle(rectangle2D14, lengthAdjustmentType15, lengthAdjustmentType16);
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str21 = labelBlock20.getToolTipText();
        java.lang.String str22 = labelBlock20.getURLText();
        java.awt.geom.Rectangle2D rectangle2D23 = labelBlock20.getBounds();
        java.awt.geom.Rectangle2D rectangle2D24 = axisSpace1.shrink(rectangle2D18, rectangle2D23);
        java.lang.Object obj25 = axisSpace1.clone();
        boolean boolean26 = stackedAreaRenderer0.equals((java.lang.Object) axisSpace1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(lengthAdjustmentType15);
        org.junit.Assert.assertNotNull(lengthAdjustmentType16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "CONTRACT" + "'", str17.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint8 = statisticalLineAndShapeRenderer2.getItemOutlinePaint((-1), 0);
        boolean boolean9 = statisticalLineAndShapeRenderer2.getUseOutlinePaint();
        statisticalLineAndShapeRenderer2.setAutoPopulateSeriesStroke(true);
        boolean boolean14 = statisticalLineAndShapeRenderer2.getItemCreateEntity(2958465, (-329600));
        java.awt.Shape shape16 = statisticalLineAndShapeRenderer2.lookupSeriesShape(1);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot17.getRangeAxisEdge(0);
        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYPlot17.setRangeCrosshairStroke(stroke20);
        org.jfree.data.xy.XYDataset xYDataset22 = xYPlot17.getDataset();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot17.getDomainAxisEdge();
        xYPlot17.setRangeCrosshairValue(0.0d);
        java.awt.Paint paint26 = xYPlot17.getRangeZeroBaselinePaint();
        org.jfree.chart.title.LegendGraphic legendGraphic27 = new org.jfree.chart.title.LegendGraphic(shape16, paint26);
        java.awt.Shape shape28 = null;
        legendGraphic27.setLine(shape28);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(xYDataset22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        categoryAxis0.setTickMarkPaint(paint1);
        java.lang.String str3 = categoryAxis0.getLabel();
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryAxis0.setLabelPaint(paint4);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity10 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis0, shape7, "({0}, {1}) = {2}", "({0}, {1}) = {2}");
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape7);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity12 = new org.jfree.chart.entity.LegendItemEntity(shape7);
        org.jfree.data.general.Dataset dataset13 = legendItemEntity12.getDataset();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset14 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double16 = defaultStatisticalCategoryDataset14.getRangeUpperBound(false);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset17 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset17.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.general.DatasetGroup datasetGroup23 = defaultStatisticalCategoryDataset17.getGroup();
        java.lang.String str24 = datasetGroup23.getID();
        defaultStatisticalCategoryDataset14.setGroup(datasetGroup23);
        legendItemEntity12.setDataset((org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D27 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj28 = categoryAxis3D27.clone();
        categoryAxis3D27.configure();
        int int30 = categoryAxis3D27.getCategoryLabelPositionOffset();
        boolean boolean31 = legendItemEntity12.equals((java.lang.Object) categoryAxis3D27);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNull(dataset13);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(datasetGroup23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "NOID" + "'", str24.equals("NOID"));
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setRangeWithMargins((double) 1L, 12.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis0.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = dateAxis5.getStandardTickUnits();
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis5.setRangeWithMargins((org.jfree.data.Range) dateRange9, false, false);
        dateAxis5.setAutoRange(false);
        java.util.Date date15 = dateAxis5.getMinimumDate();
        java.util.Date date16 = dateTickUnit4.rollDate(date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.DefaultKeyedValue defaultKeyedValue20 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) "DateTickUnit[DAY, 1]", (java.lang.Number) 128);
        int int21 = year17.compareTo((java.lang.Object) defaultKeyedValue20);
        org.jfree.chart.text.TextBlock textBlock22 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = null;
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.axis.CategoryTick categoryTick26 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) int21, textBlock22, textBlockAnchor23, textAnchor24, (double) 'a');
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(textAnchor24);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement1 = blockContainer0.getArrangement();
        java.awt.Shape shape2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset5 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset5.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.general.DatasetGroup datasetGroup11 = defaultStatisticalCategoryDataset5.getGroup();
        java.lang.Comparable comparable13 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity14 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "hi!", "", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5, (java.lang.Comparable) 1.0d, comparable13);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer17 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean18 = statisticalLineAndShapeRenderer17.getBaseItemLabelsVisible();
        int int19 = statisticalLineAndShapeRenderer17.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = null;
        statisticalLineAndShapeRenderer17.setSeriesNegativeItemLabelPosition(0, itemLabelPosition21);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator25 = statisticalLineAndShapeRenderer17.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = statisticalLineAndShapeRenderer17.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor28 = itemLabelPosition27.getRotationAnchor();
        boolean boolean29 = defaultStatisticalCategoryDataset5.equals((java.lang.Object) textAnchor28);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer31 = new org.jfree.chart.title.LegendItemBlockContainer(arrangement1, (org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset5, (java.lang.Comparable) 1);
        legendItemBlockContainer31.setURLText("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.block.LabelBlock labelBlock36 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str37 = labelBlock36.getToolTipText();
        java.lang.String str38 = labelBlock36.getURLText();
        java.awt.geom.Rectangle2D rectangle2D39 = labelBlock36.getBounds();
        java.awt.Color color40 = java.awt.Color.magenta;
        try {
            java.lang.Object obj41 = legendItemBlockContainer31.draw(graphics2D34, rectangle2D39, (java.lang.Object) color40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(arrangement1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(datasetGroup11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator25);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(color40);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        categoryAxis0.setTickMarkPaint(paint1);
        java.lang.String str3 = categoryAxis0.getLabel();
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryAxis0.setLabelPaint(paint4);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity10 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis0, shape7, "({0}, {1}) = {2}", "({0}, {1}) = {2}");
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape7);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity12 = new org.jfree.chart.entity.LegendItemEntity(shape7);
        org.jfree.data.general.Dataset dataset13 = legendItemEntity12.getDataset();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset14 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double16 = defaultStatisticalCategoryDataset14.getRangeUpperBound(false);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset17 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset17.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.general.DatasetGroup datasetGroup23 = defaultStatisticalCategoryDataset17.getGroup();
        java.lang.String str24 = datasetGroup23.getID();
        defaultStatisticalCategoryDataset14.setGroup(datasetGroup23);
        legendItemEntity12.setDataset((org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset14);
        legendItemEntity12.setSeriesKey((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable29 = legendItemEntity12.getSeriesKey();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNull(dataset13);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(datasetGroup23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "NOID" + "'", str24.equals("NOID"));
        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + 0.0f + "'", comparable29.equals(0.0f));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke3 = polarPlot2.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', (java.awt.Paint) color1, stroke3);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection5 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int6 = taskSeriesCollection5.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries8 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection5.add(taskSeries8);
        org.jfree.data.gantt.TaskSeries taskSeries11 = taskSeriesCollection5.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection5, (java.lang.Comparable) "CONTRACT");
        boolean boolean14 = categoryMarker4.equals((java.lang.Object) taskSeriesCollection5);
        try {
            java.lang.Number number17 = taskSeriesCollection5.getStartValue(0, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(taskSeries11);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.data.time.TimePeriod timePeriod1 = null;
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("DateTickUnit[DAY, 1]", timePeriod1);
        task2.setPercentComplete((double) 0L);
        org.jfree.data.time.TimePeriod timePeriod5 = null;
        task2.setDuration(timePeriod5);
        org.jfree.data.time.TimePeriod timePeriod8 = null;
        org.jfree.data.gantt.Task task9 = new org.jfree.data.gantt.Task("DateTickUnit[DAY, 1]", timePeriod8);
        task2.addSubtask(task9);
        java.lang.Double double11 = task2.getPercentComplete();
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11.equals(0.0d));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        boolean boolean5 = xYPlot0.isRangeZeroBaselineVisible();
        xYPlot0.setRangeZeroBaselineVisible(false);
        java.awt.Stroke stroke8 = xYPlot0.getDomainZeroBaselineStroke();
        boolean boolean9 = xYPlot0.isOutlineVisible();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str9 = spreadsheetDate8.getDescription();
        int int10 = spreadsheetDate8.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str13 = spreadsheetDate12.getDescription();
        org.jfree.data.time.SerialDate serialDate14 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        java.lang.Number number15 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) (-1.0f), (java.lang.Comparable) serialDate14);
        int int16 = defaultStatisticalCategoryDataset0.getRowCount();
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        java.lang.Object obj5 = null;
        boolean boolean6 = xYPlot0.equals(obj5);
        xYPlot0.setRangeCrosshairValue((double) ' ');
        java.awt.Stroke stroke9 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = xYPlot0.getDomainAxisEdge(5);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        java.text.DateFormat dateFormat2 = null;
        dateAxis0.setDateFormatOverride(dateFormat2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis4.getLabelInsets();
        double double7 = rectangleInsets5.trimWidth((double) (byte) 10);
        double double9 = rectangleInsets5.trimHeight(9.223372036854776E18d);
        dateAxis0.setLabelInsets(rectangleInsets5);
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 9.223372036854776E18d + "'", double9 == 9.223372036854776E18d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        java.awt.Stroke stroke2 = categoryAxis0.getAxisLineStroke();
        float float3 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        java.awt.Font font6 = null;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 900000L, font6);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis0.setRangeWithMargins((org.jfree.data.Range) dateRange4, false, false);
        dateAxis0.setAutoRange(false);
        double double10 = dateAxis0.getUpperBound();
        dateAxis0.setTickMarkOutsideLength((float) (short) -1);
        try {
            dateAxis0.setAutoRangeMinimumSize(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis1.getStandardTickUnits();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange5, false, false);
        dateAxis1.setAutoRange(false);
        java.util.Date date11 = dateAxis1.getMinimumDate();
        boolean boolean12 = dateAxis1.isVerticalTickLabels();
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str14 = dateTickUnit13.toString();
        double double15 = dateTickUnit13.getSize();
        dateAxis1.setTickUnit(dateTickUnit13);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis17);
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis17.setTickUnit(dateTickUnit19);
        java.util.Date date21 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit19);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date21);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent24 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis23);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition25 = dateAxis23.getTickMarkPosition();
        boolean boolean26 = dateAxis23.isInverted();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent28 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis27);
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis27.setTickUnit(dateTickUnit29);
        java.util.Date date31 = dateAxis23.calculateHighestVisibleTickValue(dateTickUnit29);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource33 = dateAxis32.getStandardTickUnits();
        org.jfree.data.time.DateRange dateRange36 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis32.setRangeWithMargins((org.jfree.data.Range) dateRange36, false, false);
        dateAxis32.setAutoRange(false);
        java.util.Date date42 = dateAxis32.getMinimumDate();
        dateAxis23.setMinimumDate(date42);
        try {
            org.jfree.data.gantt.Task task44 = new org.jfree.data.gantt.Task("", date21, date42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires end >= start.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTickUnit13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTickUnit[DAY, 1]" + "'", str14.equals("DateTickUnit[DAY, 1]"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.64E7d + "'", double15 == 8.64E7d);
        org.junit.Assert.assertNotNull(dateTickUnit19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(dateTickMarkPosition25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTickUnit29);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(tickUnitSource33);
        org.junit.Assert.assertNotNull(date42);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        boolean boolean2 = horizontalAlignment0.equals((java.lang.Object) 0.5f);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint1 = waterfallBarRenderer0.getLastBarPaint();
        java.awt.Color color2 = java.awt.Color.black;
        waterfallBarRenderer0.setPositiveBarPaint((java.awt.Paint) color2);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 1, (double) (short) 10, false);
        java.awt.Font font8 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        stackedBarRenderer3D7.setBaseItemLabelFont(font8, true);
        boolean boolean11 = waterfallBarRenderer0.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getOutlinePaint();
        java.awt.Stroke stroke2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot0.setOutlineStroke(stroke2);
        java.lang.String str4 = polarPlot0.getPlotType();
        polarPlot0.removeCornerTextItem("25-May-1927");
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Polar Plot" + "'", str4.equals("Polar Plot"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis0.setRangeWithMargins((org.jfree.data.Range) dateRange4, false, false);
        dateAxis0.setAutoRange(false);
        java.util.Date date10 = dateAxis0.getMinimumDate();
        boolean boolean11 = dateAxis0.isVerticalTickLabels();
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str13 = dateTickUnit12.toString();
        double double14 = dateTickUnit12.getSize();
        dateAxis0.setTickUnit(dateTickUnit12);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection16 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int17 = taskSeriesCollection16.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries19 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection16.add(taskSeries19);
        org.jfree.data.gantt.TaskSeries taskSeries22 = taskSeriesCollection16.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset24 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection16, (java.lang.Comparable) "CONTRACT");
        int int25 = dateTickUnit12.compareTo((java.lang.Object) "CONTRACT");
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickUnit12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTickUnit[DAY, 1]" + "'", str13.equals("DateTickUnit[DAY, 1]"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 8.64E7d + "'", double14 == 8.64E7d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(taskSeries22);
        org.junit.Assert.assertNotNull(pieDataset24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        boolean boolean5 = xYPlot0.isRangeZeroBaselineVisible();
        xYPlot0.setRangeZeroBaselineVisible(false);
        java.awt.Stroke stroke8 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.entity.EntityCollection entityCollection10 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = new org.jfree.chart.ChartRenderingInfo(entityCollection10);
        org.jfree.chart.entity.EntityCollection entityCollection12 = chartRenderingInfo11.getEntityCollection();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        java.awt.geom.Point2D point2D14 = null;
        xYPlot0.zoomRangeAxes((double) 3, plotRenderingInfo13, point2D14);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(entityCollection12);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setLeft((double) (short) 10);
        java.lang.String str3 = axisSpace0.toString();
        org.jfree.chart.axis.AxisSpace axisSpace5 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisSpace5.add((double) (byte) 0, rectangleEdge7);
        axisSpace0.ensureAtLeast((double) 100L, rectangleEdge7);
        axisSpace0.setTop((double) 10L);
        axisSpace0.setBottom((double) 604800000L);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis0);
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = dateAxis4.getStandardTickUnits();
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis4.setRangeWithMargins((org.jfree.data.Range) dateRange8, false, false);
        dateAxis4.setAutoRange(false);
        java.util.Date date14 = dateAxis4.getMinimumDate();
        boolean boolean15 = dateAxis4.isVerticalTickLabels();
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str17 = dateTickUnit16.toString();
        double double18 = dateTickUnit16.getSize();
        dateAxis4.setTickUnit(dateTickUnit16);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis20);
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis20.setTickUnit(dateTickUnit22);
        java.util.Date date24 = dateAxis4.calculateLowestVisibleTickValue(dateTickUnit22);
        dateAxis0.setTickUnit(dateTickUnit22);
        org.jfree.data.Range range26 = null;
        org.jfree.data.Range range28 = org.jfree.data.Range.expandToInclude(range26, (double) 1.0f);
        org.jfree.data.time.DateRange dateRange29 = new org.jfree.data.time.DateRange(range28);
        org.jfree.data.Range range31 = org.jfree.data.Range.shift(range28, 0.0d);
        dateAxis0.setRange(range28);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTickUnit16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "DateTickUnit[DAY, 1]" + "'", str17.equals("DateTickUnit[DAY, 1]"));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.64E7d + "'", double18 == 8.64E7d);
        org.junit.Assert.assertNotNull(dateTickUnit22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(range31);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        java.awt.Font font5 = statisticalLineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, rectangleAnchor8, (double) (short) 100, (double) 4);
        statisticalLineAndShapeRenderer2.setBaseShape(shape11, false);
        boolean boolean14 = statisticalLineAndShapeRenderer2.getUseFillPaint();
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalLineAndShapeRenderer2);
        java.awt.Paint paint16 = legendTitle15.getItemPaint();
        java.awt.Paint paint17 = legendTitle15.getItemPaint();
        boolean boolean18 = legendTitle15.getNotify();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        double double3 = rectangleInsets1.trimWidth((double) (byte) 10);
        double double5 = rectangleInsets1.calculateLeftOutset(0.0d);
        double double7 = rectangleInsets1.calculateBottomOutset((double) (byte) 10);
        double double9 = rectangleInsets1.calculateRightInset((double) 500);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer1 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D3 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int4 = defaultKeyedValues2D3.getRowCount();
        java.util.List list5 = defaultKeyedValues2D3.getColumnKeys();
        boolean boolean6 = waterfallBarRenderer1.equals((java.lang.Object) list5);
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint8 = polarPlot7.getOutlinePaint();
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot7.setOutlineStroke(stroke9);
        java.lang.String str11 = polarPlot7.getPlotType();
        int int12 = polarPlot7.getBackgroundImageAlignment();
        boolean boolean13 = waterfallBarRenderer1.equals((java.lang.Object) polarPlot7);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer17 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean18 = statisticalLineAndShapeRenderer17.getBaseItemLabelsVisible();
        int int19 = statisticalLineAndShapeRenderer17.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = null;
        statisticalLineAndShapeRenderer17.setSeriesNegativeItemLabelPosition(0, itemLabelPosition21);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator25 = statisticalLineAndShapeRenderer17.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = statisticalLineAndShapeRenderer17.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor28 = itemLabelPosition27.getRotationAnchor();
        waterfallBarRenderer1.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition27);
        org.jfree.chart.text.TextAnchor textAnchor30 = itemLabelPosition27.getTextAnchor();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor30);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Polar Plot" + "'", str11.equals("Polar Plot"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator25);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(textAnchor30);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset3.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) '#');
        org.jfree.data.general.DatasetGroup datasetGroup9 = defaultStatisticalCategoryDataset3.getGroup();
        java.lang.Comparable comparable11 = null;
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity12 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "hi!", "", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, (java.lang.Comparable) 1.0d, comparable11);
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint14 = polarPlot13.getOutlinePaint();
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot13.setOutlineStroke(stroke15);
        java.lang.String str17 = polarPlot13.getPlotType();
        int int18 = polarPlot13.getBackgroundImageAlignment();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = categoryAxis19.getLabelInsets();
        java.awt.Stroke stroke21 = categoryAxis19.getAxisLineStroke();
        float float22 = categoryAxis19.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent23 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis19);
        org.jfree.chart.axis.Axis axis24 = axisChangeEvent23.getAxis();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer27 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean28 = statisticalLineAndShapeRenderer27.getBaseItemLabelsVisible();
        int int29 = statisticalLineAndShapeRenderer27.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = null;
        statisticalLineAndShapeRenderer27.setSeriesNegativeItemLabelPosition(0, itemLabelPosition31);
        java.awt.Stroke stroke35 = statisticalLineAndShapeRenderer27.getItemOutlineStroke(4, (int) '4');
        statisticalLineAndShapeRenderer27.setItemLabelAnchorOffset((double) (short) 1);
        java.awt.Stroke stroke38 = statisticalLineAndShapeRenderer27.getBaseOutlineStroke();
        axis24.setTickMarkStroke(stroke38);
        polarPlot13.setAngleGridlineStroke(stroke38);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent41 = null;
        polarPlot13.datasetChanged(datasetChangeEvent41);
        boolean boolean43 = defaultStatisticalCategoryDataset3.hasListener((java.util.EventListener) polarPlot13);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D47 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 1, (double) (short) 10, false);
        org.jfree.chart.plot.PolarPlot polarPlot48 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean49 = polarPlot48.isOutlineVisible();
        polarPlot48.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart52 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot48);
        java.awt.Stroke stroke53 = jFreeChart52.getBorderStroke();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent56 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) false, jFreeChart52, 9999, (int) '4');
        org.jfree.chart.JFreeChart jFreeChart57 = chartProgressEvent56.getChart();
        java.awt.RenderingHints renderingHints58 = jFreeChart57.getRenderingHints();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent61 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) boolean43, jFreeChart57, 0, 4);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(datasetGroup9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Polar Plot" + "'", str17.equals("Polar Plot"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertNotNull(axis24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2 + "'", int29 == 2);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(jFreeChart57);
        org.junit.Assert.assertNotNull(renderingHints58);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint8 = statisticalLineAndShapeRenderer2.getItemOutlinePaint((-1), 0);
        boolean boolean10 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) 2958465);
        statisticalLineAndShapeRenderer2.setSeriesCreateEntities((int) '4', (java.lang.Boolean) true, false);
        java.lang.Boolean boolean16 = statisticalLineAndShapeRenderer2.getSeriesShapesFilled((int) (short) 10);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(boolean16);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = barRenderer0.getPlot();
        double double2 = barRenderer0.getMaximumBarWidth();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer7 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer7.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint13 = statisticalLineAndShapeRenderer7.getItemOutlinePaint((-1), 0);
        boolean boolean15 = statisticalLineAndShapeRenderer7.equals((java.lang.Object) 2958465);
        statisticalLineAndShapeRenderer7.setBaseSeriesVisibleInLegend(true, false);
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint20 = polarPlot19.getOutlinePaint();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot19.setOutlineStroke(stroke21);
        java.lang.String str23 = polarPlot19.getPlotType();
        int int24 = polarPlot19.getBackgroundImageAlignment();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryAxis25.getLabelInsets();
        java.awt.Stroke stroke27 = categoryAxis25.getAxisLineStroke();
        float float28 = categoryAxis25.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent29 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis25);
        org.jfree.chart.axis.Axis axis30 = axisChangeEvent29.getAxis();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer33 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean34 = statisticalLineAndShapeRenderer33.getBaseItemLabelsVisible();
        int int35 = statisticalLineAndShapeRenderer33.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = null;
        statisticalLineAndShapeRenderer33.setSeriesNegativeItemLabelPosition(0, itemLabelPosition37);
        java.awt.Stroke stroke41 = statisticalLineAndShapeRenderer33.getItemOutlineStroke(4, (int) '4');
        statisticalLineAndShapeRenderer33.setItemLabelAnchorOffset((double) (short) 1);
        java.awt.Stroke stroke44 = statisticalLineAndShapeRenderer33.getBaseOutlineStroke();
        axis30.setTickMarkStroke(stroke44);
        polarPlot19.setAngleGridlineStroke(stroke44);
        boolean boolean47 = statisticalLineAndShapeRenderer7.equals((java.lang.Object) stroke44);
        barRenderer0.setBaseOutlineStroke(stroke44, true);
        barRenderer0.setSeriesItemLabelsVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.junit.Assert.assertNull(categoryPlot1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNull(itemLabelPosition3);
        org.junit.Assert.assertNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Polar Plot" + "'", str23.equals("Polar Plot"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 15 + "'", int24 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.0f + "'", float28 == 0.0f);
        org.junit.Assert.assertNotNull(axis30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2 + "'", int35 == 2);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image3, "", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray8 = projectInfo7.getLibraries();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset9 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double11 = defaultStatisticalCategoryDataset9.getRangeUpperBound(false);
        java.lang.Number number14 = defaultStatisticalCategoryDataset9.getMeanValue((java.lang.Comparable) 1, (java.lang.Comparable) (short) 0);
        java.util.List list15 = defaultStatisticalCategoryDataset9.getColumnKeys();
        projectInfo7.setContributors(list15);
        java.lang.String str17 = projectInfo7.getName();
        org.junit.Assert.assertNotNull(libraryArray8);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 1, (double) (short) 10, false);
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean5 = polarPlot4.isOutlineVisible();
        polarPlot4.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot4);
        java.awt.Stroke stroke9 = jFreeChart8.getBorderStroke();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) false, jFreeChart8, 9999, (int) '4');
        int int13 = chartProgressEvent12.getPercent();
        chartProgressEvent12.setType(0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        java.awt.Font font5 = statisticalLineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, rectangleAnchor8, (double) (short) 100, (double) 4);
        statisticalLineAndShapeRenderer2.setBaseShape(shape11, false);
        boolean boolean14 = statisticalLineAndShapeRenderer2.getUseFillPaint();
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalLineAndShapeRenderer2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = null;
        try {
            legendTitle15.setVerticalAlignment(verticalAlignment16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray7 = new java.lang.Number[][] { numberArray2, numberArray3, numberArray4, numberArray5, numberArray6 };
        org.jfree.data.category.CategoryDataset categoryDataset8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("DateTickUnit[DAY, 1]", "LengthConstraintType.NONE", numberArray7);
        java.lang.Number[] numberArray11 = new java.lang.Number[] {};
        java.lang.Number[] numberArray12 = new java.lang.Number[] {};
        java.lang.Number[] numberArray13 = new java.lang.Number[] {};
        java.lang.Number[] numberArray14 = new java.lang.Number[] {};
        java.lang.Number[] numberArray15 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray11, numberArray12, numberArray13, numberArray14, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("DateTickUnit[DAY, 1]", "LengthConstraintType.NONE", numberArray16);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset18 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray7, numberArray16);
        java.util.List list19 = defaultIntervalCategoryDataset18.getRowKeys();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(categoryDataset8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        boolean boolean5 = xYPlot0.isRangeZeroBaselineVisible();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot0.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("RectangleConstraintType.RANGE");
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = new org.jfree.chart.axis.NumberTickUnit(9.223372036854776E18d);
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { (-460), "NOID", 10L, 9.223372036854776E18d };
        double[][] doubleArray7 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable[]) strArray0, comparableArray6, doubleArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(comparableArray6);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getOutlinePaint();
        boolean boolean2 = polarPlot0.isRadiusGridlinesVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        polarPlot0.zoomDomainAxes((double) 10, plotRenderingInfo5, point2D6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        polarPlot0.drawBackgroundImage(graphics2D8, rectangle2D9);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = polarPlot0.getLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = new org.jfree.chart.LegendItemCollection();
        legendItemCollection11.addAll(legendItemCollection12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(legendItemCollection11);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.lang.String str1 = polarPlot0.getNoDataMessage();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        polarPlot0.rendererChanged(rendererChangeEvent2);
        polarPlot0.addCornerTextItem("NOID");
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        polarPlot0.setRadiusGridlineStroke(stroke6);
        java.lang.Object obj8 = polarPlot0.clone();
        float float9 = polarPlot0.getForegroundAlpha();
        boolean boolean10 = polarPlot0.isDomainZoomable();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D3);
        numberAxis3D3.setAutoRangeStickyZero(false);
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int1 = taskSeriesCollection0.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries3 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection0.add(taskSeries3);
        org.jfree.data.gantt.TaskSeries taskSeries6 = taskSeriesCollection0.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, (java.lang.Comparable) "CONTRACT");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str14 = spreadsheetDate13.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(8);
        java.lang.String str17 = spreadsheetDate16.getDescription();
        int int18 = spreadsheetDate16.getDayOfWeek();
        boolean boolean19 = spreadsheetDate13.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(2958465);
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate16.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate21);
        try {
            java.lang.Number number24 = taskSeriesCollection0.getEndValue((java.lang.Comparable) "CONTRACT", (java.lang.Comparable) spreadsheetDate21, (-460));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(taskSeries6);
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(serialDate22);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (short) 100, (double) 4);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint14 = statisticalLineAndShapeRenderer8.getItemOutlinePaint((-1), 0);
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape5, paint14);
        java.awt.Paint paint16 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        legendGraphic15.setOutlinePaint(paint16);
        java.awt.Paint paint18 = legendGraphic15.getFillPaint();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis1);
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis1.setRange((org.jfree.data.Range) dateRange5);
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font9);
        java.lang.String str11 = textTitle10.getToolTipText();
        textTitle10.setWidth(0.0d);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent14 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle10);
        java.awt.Color color15 = java.awt.Color.cyan;
        boolean boolean16 = textTitle10.equals((java.lang.Object) color15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = categoryAxis18.getLabelInsets();
        double double21 = rectangleInsets19.trimWidth((double) (byte) 10);
        double double23 = rectangleInsets19.calculateTopInset((-1.0d));
        double double25 = rectangleInsets19.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock27 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str28 = labelBlock27.getToolTipText();
        java.lang.String str29 = labelBlock27.getURLText();
        java.awt.geom.Rectangle2D rectangle2D30 = labelBlock27.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType31 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType32 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str33 = lengthAdjustmentType32.toString();
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets19.createAdjustedRectangle(rectangle2D30, lengthAdjustmentType31, lengthAdjustmentType32);
        java.lang.Object obj35 = null;
        java.lang.Object obj36 = textTitle10.draw(graphics2D17, rectangle2D30, obj35);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = null;
        double double38 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D30, rectangleEdge37);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double40 = dateAxis1.lengthToJava2D(0.0d, rectangle2D30, rectangleEdge39);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection41 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int42 = taskSeriesCollection41.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries44 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection41.add(taskSeries44);
        org.jfree.data.gantt.TaskSeries taskSeries47 = taskSeriesCollection41.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection41, (java.lang.Comparable) "CONTRACT");
        org.jfree.chart.plot.PiePlot3D piePlot3D50 = new org.jfree.chart.plot.PiePlot3D(pieDataset49);
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) piePlot3D50);
        piePlot3D50.setCircular(false);
        java.lang.String str54 = piePlot3D50.getPlotType();
        org.jfree.chart.JFreeChart jFreeChart55 = new org.jfree.chart.JFreeChart("ClassContext", (org.jfree.chart.plot.Plot) piePlot3D50);
        java.awt.Graphics2D graphics2D56 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        java.awt.geom.Point2D point2D58 = null;
        org.jfree.chart.plot.PlotState plotState59 = null;
        org.jfree.chart.entity.EntityCollection entityCollection60 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo61 = new org.jfree.chart.ChartRenderingInfo(entityCollection60);
        org.jfree.chart.entity.EntityCollection entityCollection62 = chartRenderingInfo61.getEntityCollection();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo61);
        try {
            piePlot3D50.draw(graphics2D56, rectangle2D57, point2D58, plotState59, plotRenderingInfo63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 3.0d + "'", double23 == 3.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 3.0d + "'", double25 == 3.0d);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(lengthAdjustmentType31);
        org.junit.Assert.assertNotNull(lengthAdjustmentType32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "CONTRACT" + "'", str33.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(obj36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNull(taskSeries47);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Pie 3D Plot" + "'", str54.equals("Pie 3D Plot"));
        org.junit.Assert.assertNull(entityCollection62);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.lang.String str3 = textTitle2.getToolTipText();
        textTitle2.setWidth(0.0d);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent6 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = textTitle2.getVerticalAlignment();
        textTitle2.setNotify(true);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(verticalAlignment7);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.lang.String str3 = textTitle2.getToolTipText();
        textTitle2.setWidth(0.0d);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent6 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle2);
        org.jfree.chart.title.Title title7 = titleChangeEvent6.getTitle();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(title7);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        java.awt.Stroke stroke2 = categoryAxis0.getAxisLineStroke();
        float float3 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        org.jfree.chart.axis.Axis axis5 = axisChangeEvent4.getAxis();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean9 = statisticalLineAndShapeRenderer8.getBaseItemLabelsVisible();
        int int10 = statisticalLineAndShapeRenderer8.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        statisticalLineAndShapeRenderer8.setSeriesNegativeItemLabelPosition(0, itemLabelPosition12);
        java.awt.Stroke stroke16 = statisticalLineAndShapeRenderer8.getItemOutlineStroke(4, (int) '4');
        statisticalLineAndShapeRenderer8.setItemLabelAnchorOffset((double) (short) 1);
        java.awt.Stroke stroke19 = statisticalLineAndShapeRenderer8.getBaseOutlineStroke();
        axis5.setTickMarkStroke(stroke19);
        boolean boolean21 = axis5.isTickLabelsVisible();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(axis5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        boolean boolean1 = stackedBarRenderer0.getRenderAsPercentages();
        int int2 = stackedBarRenderer0.getPassCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.awt.Image image7 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo11 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image7, "", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray12 = projectInfo11.getLibraries();
        boolean boolean13 = textAnchor3.equals((java.lang.Object) projectInfo11);
        org.jfree.chart.axis.NumberTick numberTick15 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 1.0E-5d, "CONTRACT", textAnchor2, textAnchor3, 0.4d);
        java.awt.Image image19 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo23 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", image19, "", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray24 = projectInfo23.getLibraries();
        java.lang.String str25 = projectInfo23.getName();
        boolean boolean26 = numberTick15.equals((java.lang.Object) str25);
        org.jfree.chart.text.TextAnchor textAnchor27 = numberTick15.getTextAnchor();
        java.awt.Color color29 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke31 = polarPlot30.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', (java.awt.Paint) color29, stroke31);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType33 = categoryMarker32.getLabelOffsetType();
        boolean boolean34 = numberTick15.equals((java.lang.Object) lengthAdjustmentType33);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(libraryArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(libraryArray24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(lengthAdjustmentType33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor2, (double) (short) 100, (double) 4);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint14 = statisticalLineAndShapeRenderer8.getItemOutlinePaint((-1), 0);
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape5, paint14);
        java.awt.Shape shape16 = legendGraphic15.getLine();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer17 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj18 = standardGradientPaintTransformer17.clone();
        legendGraphic15.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer17);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType20 = standardGradientPaintTransformer17.getType();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(shape16);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(gradientPaintTransformType20);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        java.lang.Object obj5 = null;
        boolean boolean6 = xYPlot0.equals(obj5);
        xYPlot0.setRangeCrosshairValue((double) ' ');
        xYPlot0.setRangeZeroBaselineVisible(false);
        java.awt.Image image11 = null;
        xYPlot0.setBackgroundImage(image11);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer15.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint21 = statisticalLineAndShapeRenderer15.getItemOutlinePaint((-1), 0);
        xYPlot0.setDomainCrosshairPaint(paint21);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot24.getRangeAxisEdge(0);
        java.awt.Stroke stroke27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYPlot24.setRangeCrosshairStroke(stroke27);
        org.jfree.data.xy.XYDataset xYDataset29 = xYPlot24.getDataset();
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot32 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke33 = polarPlot32.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', (java.awt.Paint) color31, stroke33);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection35 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int36 = taskSeriesCollection35.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries38 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection35.add(taskSeries38);
        org.jfree.data.gantt.TaskSeries taskSeries41 = taskSeriesCollection35.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset43 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection35, (java.lang.Comparable) "CONTRACT");
        boolean boolean44 = categoryMarker34.equals((java.lang.Object) taskSeriesCollection35);
        java.awt.Color color45 = java.awt.Color.GREEN;
        categoryMarker34.setPaint((java.awt.Paint) color45);
        xYPlot24.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker34);
        java.lang.String str48 = xYPlot24.getPlotType();
        java.awt.Graphics2D graphics2D49 = null;
        org.jfree.chart.axis.AxisSpace axisSpace50 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = categoryAxis51.getLabelInsets();
        double double54 = rectangleInsets52.trimWidth((double) (byte) 10);
        double double56 = rectangleInsets52.calculateTopInset((-1.0d));
        double double58 = rectangleInsets52.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock60 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str61 = labelBlock60.getToolTipText();
        java.lang.String str62 = labelBlock60.getURLText();
        java.awt.geom.Rectangle2D rectangle2D63 = labelBlock60.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType64 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType65 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str66 = lengthAdjustmentType65.toString();
        java.awt.geom.Rectangle2D rectangle2D67 = rectangleInsets52.createAdjustedRectangle(rectangle2D63, lengthAdjustmentType64, lengthAdjustmentType65);
        org.jfree.chart.block.LabelBlock labelBlock69 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str70 = labelBlock69.getToolTipText();
        java.lang.String str71 = labelBlock69.getURLText();
        java.awt.geom.Rectangle2D rectangle2D72 = labelBlock69.getBounds();
        java.awt.geom.Rectangle2D rectangle2D73 = axisSpace50.shrink(rectangle2D67, rectangle2D72);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo74 = null;
        xYPlot24.drawAnnotations(graphics2D49, rectangle2D67, plotRenderingInfo74);
        org.jfree.chart.entity.EntityCollection entityCollection76 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo77 = new org.jfree.chart.ChartRenderingInfo(entityCollection76);
        org.jfree.chart.entity.EntityCollection entityCollection78 = chartRenderingInfo77.getEntityCollection();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo79 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo77);
        xYPlot0.drawAnnotations(graphics2D23, rectangle2D67, plotRenderingInfo79);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(xYDataset29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNull(taskSeries41);
        org.junit.Assert.assertNotNull(pieDataset43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "XY Plot" + "'", str48.equals("XY Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 4.0d + "'", double54 == 4.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 3.0d + "'", double56 == 3.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 3.0d + "'", double58 == 3.0d);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertNull(str62);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(lengthAdjustmentType64);
        org.junit.Assert.assertNotNull(lengthAdjustmentType65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "CONTRACT" + "'", str66.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertNull(str71);
        org.junit.Assert.assertNotNull(rectangle2D72);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertNull(entityCollection78);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisSpace0.add((double) (byte) 0, rectangleEdge2);
        org.jfree.chart.axis.AxisSpace axisSpace4 = new org.jfree.chart.axis.AxisSpace();
        axisSpace4.setLeft((double) (short) 10);
        java.lang.String str7 = axisSpace4.toString();
        org.jfree.chart.axis.AxisSpace axisSpace9 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisSpace9.add((double) (byte) 0, rectangleEdge11);
        axisSpace4.ensureAtLeast((double) 100L, rectangleEdge11);
        axisSpace0.ensureAtLeast(axisSpace4);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint1 = waterfallBarRenderer0.getLastBarPaint();
        java.awt.Color color2 = java.awt.Color.black;
        waterfallBarRenderer0.setPositiveBarPaint((java.awt.Paint) color2);
        boolean boolean5 = waterfallBarRenderer0.isSeriesItemLabelsVisible((int) '4');
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer11 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean12 = statisticalLineAndShapeRenderer11.getBaseItemLabelsVisible();
        int int13 = statisticalLineAndShapeRenderer11.getPassCount();
        java.awt.Font font14 = statisticalLineAndShapeRenderer11.getBaseItemLabelFont();
        java.awt.Paint paint15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("CONTRACT", font14, paint15, (float) '4');
        org.jfree.chart.text.TextFragment textFragment18 = new org.jfree.chart.text.TextFragment("NOID", font14);
        org.jfree.chart.text.TextFragment textFragment19 = new org.jfree.chart.text.TextFragment("DateTickUnit[DAY, 1]", font14);
        waterfallBarRenderer0.setBaseItemLabelFont(font14);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        double double3 = rectangleInsets1.trimWidth((double) (byte) 10);
        double double5 = rectangleInsets1.calculateTopInset((-1.0d));
        double double7 = rectangleInsets1.calculateBottomOutset((double) (-1.0f));
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int1 = taskSeriesCollection0.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries3 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection0.add(taskSeries3);
        org.jfree.data.gantt.TaskSeries taskSeries6 = taskSeriesCollection0.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, (java.lang.Comparable) "CONTRACT");
        java.util.List list9 = taskSeriesCollection0.getRowKeys();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(taskSeries6);
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Tuesday", graphics2D1, (double) 3, (float) (byte) 100, (float) 432000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getLabelInsets();
        java.awt.Stroke stroke2 = categoryAxis0.getAxisLineStroke();
        float float3 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        categoryAxis0.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        jFreeChart4.setTitle("hi!");
        java.lang.Object obj7 = jFreeChart4.getTextAntiAlias();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font9);
        java.lang.String str11 = textTitle10.getToolTipText();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("hi!", font13);
        java.lang.String str15 = textTitle14.getToolTipText();
        textTitle14.setWidth(0.0d);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent18 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle14);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle14.getVerticalAlignment();
        textTitle10.setVerticalAlignment(verticalAlignment19);
        jFreeChart4.setTitle(textTitle10);
        boolean boolean22 = jFreeChart4.getAntiAlias();
        try {
            org.jfree.chart.title.Title title24 = jFreeChart4.getSubtitle(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Paint paint8 = statisticalLineAndShapeRenderer2.getItemOutlinePaint((-1), 0);
        boolean boolean9 = statisticalLineAndShapeRenderer2.getUseOutlinePaint();
        statisticalLineAndShapeRenderer2.setAutoPopulateSeriesStroke(true);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalLineAndShapeRenderer2.setBaseStroke(stroke12, false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean5 = statisticalLineAndShapeRenderer4.getBaseItemLabelsVisible();
        int int6 = statisticalLineAndShapeRenderer4.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = null;
        statisticalLineAndShapeRenderer4.setSeriesNegativeItemLabelPosition(0, itemLabelPosition8);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = statisticalLineAndShapeRenderer4.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = statisticalLineAndShapeRenderer4.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor15 = itemLabelPosition14.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType17 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        boolean boolean19 = categoryLabelWidthType17.equals((java.lang.Object) color18);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition21 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, textAnchor15, 8.64E7d, categoryLabelWidthType17, (float) 0L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = categoryLabelPosition21.getCategoryAnchor();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator12);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(categoryLabelWidthType17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        boolean boolean5 = xYPlot0.isRangeZeroBaselineVisible();
        boolean boolean6 = xYPlot0.isDomainCrosshairVisible();
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke10 = polarPlot9.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', (java.awt.Paint) color8, stroke10);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection12 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int13 = taskSeriesCollection12.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries15 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection12.add(taskSeries15);
        org.jfree.data.gantt.TaskSeries taskSeries18 = taskSeriesCollection12.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset20 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection12, (java.lang.Comparable) "CONTRACT");
        boolean boolean21 = categoryMarker11.equals((java.lang.Object) taskSeriesCollection12);
        java.awt.Color color22 = java.awt.Color.GREEN;
        categoryMarker11.setPaint((java.awt.Paint) color22);
        org.jfree.chart.util.Layer layer24 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer24);
        java.awt.Paint paint26 = categoryMarker11.getOutlinePaint();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(taskSeries18);
        org.junit.Assert.assertNotNull(pieDataset20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        categoryAxis0.setTickMarkPaint(paint1);
        java.lang.String str3 = categoryAxis0.getLabel();
        categoryAxis0.setLabelAngle((double) '#');
        org.jfree.chart.plot.Plot plot6 = categoryAxis0.getPlot();
        java.awt.Font font7 = categoryAxis0.getLabelFont();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 1, (double) (short) 10, false);
        java.awt.Font font4 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        stackedBarRenderer3D3.setBaseItemLabelFont(font4, true);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getLabelInsets();
        double double12 = rectangleInsets10.trimWidth((double) (byte) 10);
        double double14 = rectangleInsets10.calculateTopInset((-1.0d));
        double double16 = rectangleInsets10.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock18 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str19 = labelBlock18.getToolTipText();
        java.lang.String str20 = labelBlock18.getURLText();
        java.awt.geom.Rectangle2D rectangle2D21 = labelBlock18.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType22 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str24 = lengthAdjustmentType23.toString();
        java.awt.geom.Rectangle2D rectangle2D25 = rectangleInsets10.createAdjustedRectangle(rectangle2D21, lengthAdjustmentType22, lengthAdjustmentType23);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        double double29 = dateAxis28.getUpperMargin();
        java.awt.Shape shape30 = dateAxis28.getDownArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = dateAxis28.getLabelInsets();
        dateAxis28.setVerticalTickLabels(true);
        java.awt.Color color35 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke37 = polarPlot36.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker38 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', (java.awt.Paint) color35, stroke37);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection39 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int40 = taskSeriesCollection39.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries42 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection39.add(taskSeries42);
        org.jfree.data.gantt.TaskSeries taskSeries45 = taskSeriesCollection39.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection39, (java.lang.Comparable) "CONTRACT");
        boolean boolean48 = categoryMarker38.equals((java.lang.Object) taskSeriesCollection39);
        try {
            stackedBarRenderer3D3.drawItem(graphics2D7, categoryItemRendererState8, rectangle2D25, categoryPlot26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis28, (org.jfree.data.category.CategoryDataset) taskSeriesCollection39, (int) (short) 0, 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.0d + "'", double14 == 3.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 3.0d + "'", double16 == 3.0d);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(lengthAdjustmentType22);
        org.junit.Assert.assertNotNull(lengthAdjustmentType23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "CONTRACT" + "'", str24.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNull(taskSeries45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setRangeWithMargins((double) 1L, 12.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis0.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = dateAxis5.getStandardTickUnits();
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis5.setRangeWithMargins((org.jfree.data.Range) dateRange9, false, false);
        dateAxis5.setAutoRange(false);
        java.util.Date date15 = dateAxis5.getMinimumDate();
        java.util.Date date16 = dateTickUnit4.rollDate(date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.DefaultKeyedValue defaultKeyedValue20 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) "DateTickUnit[DAY, 1]", (java.lang.Number) 128);
        int int21 = year17.compareTo((java.lang.Object) defaultKeyedValue20);
        java.lang.Comparable comparable22 = defaultKeyedValue20.getKey();
        java.lang.Object obj23 = defaultKeyedValue20.clone();
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + "DateTickUnit[DAY, 1]" + "'", comparable22.equals("DateTickUnit[DAY, 1]"));
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.List list9 = segmentedTimeline8.getExceptionSegments();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem10 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) (byte) -1, (java.lang.Number) 0.05d, (java.lang.Number) Double.NaN, (java.lang.Number) 1L, (java.lang.Number) 0.0d, (java.lang.Number) 12, (java.lang.Number) 0.4d, (java.lang.Number) (byte) 0, list9);
        java.lang.Number number11 = boxAndWhiskerItem10.getMean();
        org.junit.Assert.assertNotNull(segmentedTimeline8);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) -1 + "'", number11.equals((byte) -1));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Size2D[width=0.0, height=1.0]");
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        multiplePiePlot0.setAggregatedItemsPaint((java.awt.Paint) color1);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.resizeRange(1.0d);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean9 = statisticalLineAndShapeRenderer8.getBaseItemLabelsVisible();
        int int10 = statisticalLineAndShapeRenderer8.getPassCount();
        java.awt.Font font11 = statisticalLineAndShapeRenderer8.getBaseItemLabelFont();
        dateAxis3.setLabelFont(font11);
        java.util.Date date13 = dateAxis3.getMaximumDate();
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) date13);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.data.time.TimePeriod timePeriod1 = null;
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("DateTickUnit[DAY, 1]", timePeriod1);
        try {
            org.jfree.data.gantt.Task task4 = task2.getSubtask(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setRangeWithMargins((double) 1L, 12.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis0.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = dateAxis5.getStandardTickUnits();
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis5.setRangeWithMargins((org.jfree.data.Range) dateRange9, false, false);
        dateAxis5.setAutoRange(false);
        java.util.Date date15 = dateAxis5.getMinimumDate();
        java.util.Date date16 = dateTickUnit4.rollDate(date15);
        java.util.TimeZone timeZone18 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("CONTRACT", timeZone18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date15, timeZone18);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone18);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = textTitle2.getPosition();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 1, (double) (short) 10, false);
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean9 = polarPlot8.isOutlineVisible();
        polarPlot8.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot8);
        java.awt.Stroke stroke13 = jFreeChart12.getBorderStroke();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent16 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) false, jFreeChart12, 9999, (int) '4');
        org.jfree.chart.JFreeChart jFreeChart17 = chartProgressEvent16.getChart();
        textTitle2.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart17);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit19 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        boolean boolean20 = textTitle2.equals((java.lang.Object) numberTickUnit19);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(jFreeChart17);
        org.junit.Assert.assertNotNull(numberTickUnit19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray7 = new java.lang.Number[][] { numberArray2, numberArray3, numberArray4, numberArray5, numberArray6 };
        org.jfree.data.category.CategoryDataset categoryDataset8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("DateTickUnit[DAY, 1]", "LengthConstraintType.NONE", numberArray7);
        java.lang.Number[] numberArray11 = new java.lang.Number[] {};
        java.lang.Number[] numberArray12 = new java.lang.Number[] {};
        java.lang.Number[] numberArray13 = new java.lang.Number[] {};
        java.lang.Number[] numberArray14 = new java.lang.Number[] {};
        java.lang.Number[] numberArray15 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray11, numberArray12, numberArray13, numberArray14, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("DateTickUnit[DAY, 1]", "LengthConstraintType.NONE", numberArray16);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset18 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray7, numberArray16);
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean20 = polarPlot19.isOutlineVisible();
        polarPlot19.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot19);
        jFreeChart23.setTitle("hi!");
        java.lang.Object obj26 = jFreeChart23.getTextAntiAlias();
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("hi!", font28);
        java.lang.String str30 = textTitle29.getToolTipText();
        java.awt.Font font32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle33 = new org.jfree.chart.title.TextTitle("hi!", font32);
        java.lang.String str34 = textTitle33.getToolTipText();
        textTitle33.setWidth(0.0d);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent37 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle33);
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = textTitle33.getVerticalAlignment();
        textTitle29.setVerticalAlignment(verticalAlignment38);
        jFreeChart23.setTitle(textTitle29);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer43 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean44 = statisticalLineAndShapeRenderer43.getBaseItemLabelsVisible();
        int int45 = statisticalLineAndShapeRenderer43.getPassCount();
        java.awt.Font font46 = statisticalLineAndShapeRenderer43.getBaseItemLabelFont();
        java.awt.Shape shape48 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape52 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape48, rectangleAnchor49, (double) (short) 100, (double) 4);
        statisticalLineAndShapeRenderer43.setBaseShape(shape52, false);
        boolean boolean55 = statisticalLineAndShapeRenderer43.getUseFillPaint();
        org.jfree.chart.title.LegendTitle legendTitle56 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalLineAndShapeRenderer43);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke58 = categoryAxis57.getTickMarkStroke();
        boolean boolean59 = legendTitle56.equals((java.lang.Object) stroke58);
        jFreeChart23.addLegend(legendTitle56);
        boolean boolean61 = defaultIntervalCategoryDataset18.equals((java.lang.Object) jFreeChart23);
        try {
            java.lang.Number number64 = defaultIntervalCategoryDataset18.getStartValue(9, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.getValue(): series index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(categoryDataset8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2 + "'", int45 == 2);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge(0);
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        xYPlot0.mapDatasetToRangeAxis((int) (byte) 0, (int) (short) 1);
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint8 = polarPlot7.getOutlinePaint();
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        polarPlot7.setOutlineStroke(stroke9);
        xYPlot0.setDomainCrosshairStroke(stroke9);
        xYPlot0.setDomainCrosshairValue((double) 0L);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 1, (double) (short) 10, false);
        java.awt.Font font4 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        stackedBarRenderer3D3.setBaseItemLabelFont(font4, true);
        java.awt.Paint paint8 = stackedBarRenderer3D3.getSeriesPaint(3);
        java.awt.Paint paint9 = null;
        try {
            stackedBarRenderer3D3.setBaseOutlinePaint(paint9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        java.lang.String str4 = polarPlot3.getNoDataMessage();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        polarPlot3.rendererChanged(rendererChangeEvent5);
        polarPlot3.addCornerTextItem("NOID");
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        polarPlot3.setRadiusGridlineStroke(stroke9);
        boolean boolean11 = dateRange2.equals((java.lang.Object) polarPlot3);
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint13 = null;
        ringPlot12.setShadowPaint(paint13);
        double double15 = ringPlot12.getMaximumLabelWidth();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot12);
        polarPlot3.notifyListeners(plotChangeEvent16);
        polarPlot3.setOutlineVisible(false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.2d + "'", double15 == 0.2d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Paint paint1 = lineRenderer3D0.getWallPaint();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent5 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis4);
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis4.setTickUnit(dateTickUnit6);
        dateAxis4.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = xYPlot10.getRangeAxisEdge(0);
        java.awt.Stroke stroke13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYPlot10.setRangeCrosshairStroke(stroke13);
        org.jfree.data.xy.XYDataset xYDataset15 = xYPlot10.getDataset();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Stroke stroke19 = polarPlot18.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a', (java.awt.Paint) color17, stroke19);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection21 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int22 = taskSeriesCollection21.getColumnCount();
        org.jfree.data.gantt.TaskSeries taskSeries24 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeriesCollection21.add(taskSeries24);
        org.jfree.data.gantt.TaskSeries taskSeries27 = taskSeriesCollection21.getSeries((java.lang.Comparable) 1.0d);
        org.jfree.data.general.PieDataset pieDataset29 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection21, (java.lang.Comparable) "CONTRACT");
        boolean boolean30 = categoryMarker20.equals((java.lang.Object) taskSeriesCollection21);
        java.awt.Color color31 = java.awt.Color.GREEN;
        categoryMarker20.setPaint((java.awt.Paint) color31);
        xYPlot10.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker20);
        categoryMarker20.setDrawAsLine(false);
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        lineRenderer3D0.drawRangeMarker(graphics2D2, categoryPlot3, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.plot.Marker) categoryMarker20, rectangle2D36);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(xYDataset15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNull(taskSeries27);
        org.junit.Assert.assertNotNull(pieDataset29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(color31);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.lang.String str3 = textTitle2.getToolTipText();
        java.lang.String str4 = textTitle2.getText();
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean6 = polarPlot5.isOutlineVisible();
        polarPlot5.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot5);
        textTitle2.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart9);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = textTitle2.getTextAlignment();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.TRUNCATE;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean2 = areaRendererEndType0.equals((java.lang.Object) polarPlot1);
        java.lang.String str3 = areaRendererEndType0.toString();
        org.junit.Assert.assertNotNull(areaRendererEndType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "AreaRendererEndType.TRUNCATE" + "'", str3.equals("AreaRendererEndType.TRUNCATE"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean6 = statisticalLineAndShapeRenderer5.getBaseItemLabelsVisible();
        int int7 = statisticalLineAndShapeRenderer5.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        statisticalLineAndShapeRenderer5.setSeriesNegativeItemLabelPosition(0, itemLabelPosition9);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = statisticalLineAndShapeRenderer5.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = statisticalLineAndShapeRenderer5.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        org.jfree.chart.text.TextAnchor textAnchor16 = itemLabelPosition15.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType18 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        boolean boolean20 = categoryLabelWidthType18.equals((java.lang.Object) color19);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition22 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor2, textAnchor16, 8.64E7d, categoryLabelWidthType18, (float) 0L);
        org.jfree.chart.text.TextAnchor textAnchor23 = categoryLabelPosition22.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions24 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition22);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNotNull(categoryLabelWidthType18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(categoryLabelPositions24);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean4 = statisticalLineAndShapeRenderer3.getBaseItemLabelsVisible();
        int int5 = statisticalLineAndShapeRenderer3.getPassCount();
        java.awt.Color color7 = java.awt.Color.MAGENTA;
        statisticalLineAndShapeRenderer3.setSeriesFillPaint(0, (java.awt.Paint) color7, false);
        statisticalLineAndShapeRenderer3.setSeriesLinesVisible((int) '4', false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        statisticalLineAndShapeRenderer3.setBaseOutlinePaint((java.awt.Paint) color13, false);
        boolean boolean16 = blockBorder0.equals((java.lang.Object) statisticalLineAndShapeRenderer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = blockBorder0.getInsets();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = null;
        try {
            dateAxis0.setUpArrow(shape1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        double double3 = ringPlot0.getMaximumLabelWidth();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!", font7);
        java.awt.Paint paint9 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("({0}, {1}) = {2}", font7, paint9);
        boolean boolean11 = ringPlot0.equals((java.lang.Object) textLine10);
        org.jfree.data.general.PieDataset pieDataset12 = ringPlot0.getDataset();
        java.awt.Stroke stroke14 = ringPlot0.getSectionOutlineStroke((java.lang.Comparable) 0.0f);
        ringPlot0.setStartAngle((double) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(pieDataset12);
        org.junit.Assert.assertNull(stroke14);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        textBlock1.draw(graphics2D2, (float) (byte) 100, (float) (byte) 1, textBlockAnchor5, (float) 7, (float) '4', (double) (short) 100);
        java.util.List list10 = textBlock1.getLines();
        org.jfree.chart.text.TextBlock textBlock11 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        textBlock11.draw(graphics2D12, (float) (byte) 100, (float) (byte) 1, textBlockAnchor15, (float) 7, (float) '4', (double) (short) 100);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.axis.CategoryTick categoryTick22 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 900000L, textBlock1, textBlockAnchor15, textAnchor20, (double) (-329600));
        org.jfree.chart.text.TextBlock textBlock23 = categoryTick22.getLabel();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor27 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        textBlock23.draw(graphics2D24, 0.0f, 10.0f, textBlockAnchor27);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor32 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        textBlock23.draw(graphics2D29, (float) 0, (float) 900000L, textBlockAnchor32, (float) 100L, (float) 4, (double) 604800000L);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(textBlockAnchor15);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(textBlock23);
        org.junit.Assert.assertNotNull(textBlockAnchor27);
        org.junit.Assert.assertNotNull(textBlockAnchor32);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.TRUNCATE;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean2 = areaRendererEndType0.equals((java.lang.Object) polarPlot1);
        boolean boolean3 = polarPlot1.isAngleLabelsVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = polarPlot1.getDrawingSupplier();
        org.junit.Assert.assertNotNull(areaRendererEndType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(drawingSupplier4);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("hi!", font3);
        java.awt.Paint paint5 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("({0}, {1}) = {2}", font3, paint5);
        textBlock0.addLine(textLine6);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        dateAxis9.resizeRange(1.0d);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer14 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean15 = statisticalLineAndShapeRenderer14.getBaseItemLabelsVisible();
        int int16 = statisticalLineAndShapeRenderer14.getPassCount();
        java.awt.Font font17 = statisticalLineAndShapeRenderer14.getBaseItemLabelFont();
        dateAxis9.setLabelFont(font17);
        java.awt.Paint paint19 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        textBlock0.addLine("Polar Plot", font17, paint19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor24 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        try {
            java.awt.Shape shape28 = textBlock0.calculateBounds(graphics2D21, (float) 1900, (float) 5, textBlockAnchor24, (float) 500, 1.0f, (double) 35L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(textBlockAnchor24);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((double) (byte) 100, (double) 100);
        dateAxis0.setRangeWithMargins((org.jfree.data.Range) dateRange4, false, false);
        org.jfree.data.Range range9 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange4, (double) 35L);
        org.jfree.data.Range range12 = org.jfree.data.Range.expand(range9, 9.223372036854776E18d, (double) 100);
        boolean boolean15 = range12.intersects(5.0d, (double) (short) 10);
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        jFreeChart4.setTitle("hi!");
        java.lang.Object obj7 = jFreeChart4.getTextAntiAlias();
        java.lang.Object obj8 = jFreeChart4.clone();
        jFreeChart4.setBorderVisible(false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart4.removeProgressListener(chartProgressListener11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        ringPlot0.setShadowPaint(paint1);
        boolean boolean3 = ringPlot0.isCircular();
        java.awt.Font font4 = ringPlot0.getLabelFont();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isOutlineVisible();
        polarPlot0.setRadiusGridlinesVisible(true);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        jFreeChart4.setTitle("hi!");
        java.lang.Object obj7 = jFreeChart4.getTextAntiAlias();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font9);
        java.lang.String str11 = textTitle10.getToolTipText();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("hi!", font13);
        java.lang.String str15 = textTitle14.getToolTipText();
        textTitle14.setWidth(0.0d);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent18 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle14);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle14.getVerticalAlignment();
        textTitle10.setVerticalAlignment(verticalAlignment19);
        jFreeChart4.setTitle(textTitle10);
        jFreeChart4.fireChartChanged();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(verticalAlignment19);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis0);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis0.getTickMarkPosition();
        java.text.DateFormat dateFormat3 = dateAxis0.getDateFormatOverride();
        org.jfree.data.Range range4 = null;
        try {
            dateAxis0.setRangeWithMargins(range4, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertNull(dateFormat3);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis2.getLabelInsets();
        double double5 = rectangleInsets3.trimWidth((double) (byte) 10);
        double double7 = rectangleInsets3.calculateTopInset((-1.0d));
        double double9 = rectangleInsets3.calculateLeftOutset(0.0d);
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("");
        java.lang.String str12 = labelBlock11.getToolTipText();
        java.lang.String str13 = labelBlock11.getURLText();
        java.awt.geom.Rectangle2D rectangle2D14 = labelBlock11.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str17 = lengthAdjustmentType16.toString();
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets3.createAdjustedRectangle(rectangle2D14, lengthAdjustmentType15, lengthAdjustmentType16);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState22 = levelRenderer0.initialise(graphics2D1, rectangle2D18, categoryPlot19, 2019, plotRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(lengthAdjustmentType15);
        org.junit.Assert.assertNotNull(lengthAdjustmentType16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "CONTRACT" + "'", str17.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(rectangle2D18);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition6);
        statisticalLineAndShapeRenderer2.setUseFillPaint(false);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean14 = statisticalLineAndShapeRenderer13.getBaseItemLabelsVisible();
        int int15 = statisticalLineAndShapeRenderer13.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        statisticalLineAndShapeRenderer13.setSeriesNegativeItemLabelPosition(0, itemLabelPosition17);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = statisticalLineAndShapeRenderer13.getURLGenerator(100, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = statisticalLineAndShapeRenderer13.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        statisticalLineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(100, itemLabelPosition23);
        org.jfree.chart.text.TextBlock textBlock27 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor31 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        textBlock27.draw(graphics2D28, (float) (byte) 100, (float) (byte) 1, textBlockAnchor31, (float) 7, (float) '4', (double) (short) 100);
        java.util.List list36 = textBlock27.getLines();
        org.jfree.chart.text.TextBlock textBlock37 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor41 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        textBlock37.draw(graphics2D38, (float) (byte) 100, (float) (byte) 1, textBlockAnchor41, (float) 7, (float) '4', (double) (short) 100);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.axis.CategoryTick categoryTick48 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 900000L, textBlock27, textBlockAnchor41, textAnchor46, (double) (-329600));
        java.awt.Graphics2D graphics2D49 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor52 = null;
        java.awt.Shape shape56 = textBlock27.calculateBounds(graphics2D49, (float) (-329600), (float) (short) 10, textBlockAnchor52, 0.0f, (float) (short) 1, (double) (byte) 1);
        statisticalLineAndShapeRenderer2.setSeriesShape(1, shape56, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator21);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(textBlockAnchor31);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertNotNull(textBlockAnchor41);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(shape56);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(100.0d, (double) 2958465);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        boolean boolean3 = defaultKeyedValues2D1.equals((java.lang.Object) (byte) 100);
        java.util.List list4 = defaultKeyedValues2D1.getRowKeys();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getBaseItemLabelsVisible();
        int int4 = statisticalLineAndShapeRenderer2.getPassCount();
        java.awt.Font font5 = statisticalLineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2958465);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, rectangleAnchor8, (double) (short) 100, (double) 4);
        statisticalLineAndShapeRenderer2.setBaseShape(shape11, false);
        boolean boolean16 = statisticalLineAndShapeRenderer2.getItemShapeFilled((int) (short) 0, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }
}

