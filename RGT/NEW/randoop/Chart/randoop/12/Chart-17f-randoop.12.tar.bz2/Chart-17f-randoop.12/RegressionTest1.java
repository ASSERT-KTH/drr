import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        timeSeries10.setNotify(true);
//        java.util.List list41 = timeSeries10.getItems();
//        boolean boolean42 = timeSeries10.isEmpty();
//        timeSeries10.setDomainDescription("Nearest");
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) day45, (java.lang.Number) 1560440257080L, true);
//        java.lang.String str49 = timeSeries10.getDescription();
//        try {
//            java.lang.Number number51 = timeSeries10.getValue(2027);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2027, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440315301L + "'", long19 == 1560440315301L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440315301L + "'", long20 == 1560440315301L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(list41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertNull(str49);
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4', 7, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(30, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 'a');
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        long long8 = month7.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        java.lang.String str10 = month7.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem12.getPeriod();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        int int16 = timeSeriesDataItem12.compareTo((java.lang.Object) 100);
        int int17 = fixedMillisecond1.compareTo((java.lang.Object) int16);
        java.lang.String str18 = fixedMillisecond1.toString();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 24234L + "'", long8 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str18.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        timeSeries10.setNotify(true);
//        java.util.List list41 = timeSeries10.getItems();
//        java.lang.String str42 = timeSeries10.getDomainDescription();
//        timeSeries10.removeAgedItems(false);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener45 = null;
//        timeSeries10.removeChangeListener(seriesChangeListener45);
//        java.beans.PropertyChangeListener propertyChangeListener47 = null;
//        timeSeries10.addPropertyChangeListener(propertyChangeListener47);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440315396L + "'", long19 == 1560440315396L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440315396L + "'", long20 == 1560440315396L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(list41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod2);
        timeSeries3.setDomainDescription("ClassContext");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        long long2 = day1.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, serialDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        boolean boolean7 = day5.equals((java.lang.Object) 1560440245620L);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.lang.String str14 = month11.toString();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        long long16 = day15.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate17 = day15.getSerialDate();
//        boolean boolean18 = month11.equals((java.lang.Object) day15);
//        int int19 = day8.compareTo((java.lang.Object) day15);
//        int int20 = day5.compareTo((java.lang.Object) int19);
//        int int21 = day5.getYear();
//        long long22 = day5.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560495599999L + "'", long9 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560495599999L + "'", long16 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2027 + "'", int21 == 2027);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1823497199999L + "'", long22 == 1823497199999L);
//    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        timeSeries10.setNotify(true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (double) 10L);
//        java.util.Calendar calendar44 = null;
//        long long45 = fixedMillisecond41.getMiddleMillisecond(calendar44);
//        long long46 = fixedMillisecond41.getSerialIndex();
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        long long48 = month47.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month47.previous();
//        java.lang.String str50 = month47.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month47, (java.lang.Number) (byte) 100);
//        long long53 = month47.getLastMillisecond();
//        boolean boolean54 = fixedMillisecond41.equals((java.lang.Object) month47);
//        java.util.Calendar calendar55 = null;
//        long long56 = fixedMillisecond41.getFirstMillisecond(calendar55);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57, (double) 10L);
//        long long60 = fixedMillisecond57.getFirstMillisecond();
//        int int61 = fixedMillisecond41.compareTo((java.lang.Object) fixedMillisecond57);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57);
//        timeSeries10.removeAgedItems(0L, true);
//        timeSeries10.setDomainDescription("April");
//        timeSeries10.removeAgedItems(1560440244789L, true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440315596L + "'", long19 == 1560440315596L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440315596L + "'", long20 == 1560440315596L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560440315600L + "'", long45 == 1560440315600L);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560440315600L + "'", long46 == 1560440315600L);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 24234L + "'", long48 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "June 2019" + "'", str50.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1561964399999L + "'", long53 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560440315600L + "'", long56 == 1560440315600L);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560440315606L + "'", long60 == 1560440315606L);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
//        org.junit.Assert.assertNull(timeSeriesDataItem62);
//    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        timeSeries10.setNotify(true);
//        java.util.List list41 = timeSeries10.getItems();
//        boolean boolean42 = timeSeries10.isEmpty();
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        boolean boolean49 = day47.equals((java.lang.Object) 2958465);
//        long long50 = day47.getSerialIndex();
//        java.lang.Class<?> wildcardClass51 = day47.getClass();
//        java.net.URL uRL52 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass51);
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass51);
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month();
//        long long55 = month54.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = month54.previous();
//        java.util.Date date57 = month54.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond58, (double) 10L);
//        java.util.Calendar calendar61 = null;
//        long long62 = fixedMillisecond58.getMiddleMillisecond(calendar61);
//        long long63 = fixedMillisecond58.getSerialIndex();
//        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month();
//        long long65 = month64.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = month64.previous();
//        java.lang.String str67 = month64.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month64, (java.lang.Number) (byte) 100);
//        long long70 = month64.getLastMillisecond();
//        boolean boolean71 = fixedMillisecond58.equals((java.lang.Object) month64);
//        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day();
//        boolean boolean75 = day73.equals((java.lang.Object) 2958465);
//        long long76 = day73.getSerialIndex();
//        java.lang.Class<?> wildcardClass77 = day73.getClass();
//        java.lang.Object obj78 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass77);
//        boolean boolean79 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month64, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year80 = month64.getYear();
//        org.jfree.data.time.TimeSeries timeSeries81 = timeSeries53.createCopy((org.jfree.data.time.RegularTimePeriod) month54, (org.jfree.data.time.RegularTimePeriod) year80);
//        timeSeries53.setNotify(true);
//        java.util.List list84 = timeSeries53.getItems();
//        timeSeries53.removeAgedItems(1560409200000L, false);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener88 = null;
//        timeSeries53.removeChangeListener(seriesChangeListener88);
//        org.jfree.data.time.TimeSeries timeSeries90 = timeSeries10.addAndOrUpdate(timeSeries53);
//        int int91 = timeSeries53.getMaximumItemCount();
//        timeSeries53.setMaximumItemAge(1560440242996L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440315827L + "'", long19 == 1560440315827L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440315827L + "'", long20 == 1560440315827L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(list41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 43629L + "'", long50 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertNull(uRL52);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 24234L + "'", long55 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560440315833L + "'", long62 == 1560440315833L);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560440315833L + "'", long63 == 1560440315833L);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 24234L + "'", long65 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "June 2019" + "'", str67.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1561964399999L + "'", long70 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 43629L + "'", long76 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass77);
//        org.junit.Assert.assertNull(obj78);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//        org.junit.Assert.assertNotNull(year80);
//        org.junit.Assert.assertNotNull(timeSeries81);
//        org.junit.Assert.assertNotNull(list84);
//        org.junit.Assert.assertNotNull(timeSeries90);
//        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 2147483647 + "'", int91 == 2147483647);
//    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        timeSeries10.setNotify(true);
//        java.util.List list41 = timeSeries10.getItems();
//        java.lang.Object obj42 = timeSeries10.clone();
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        boolean boolean49 = day47.equals((java.lang.Object) 2958465);
//        long long50 = day47.getSerialIndex();
//        java.lang.Class<?> wildcardClass51 = day47.getClass();
//        java.net.URL uRL52 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass51);
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass51);
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month();
//        long long55 = month54.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = month54.previous();
//        java.util.Date date57 = month54.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond58, (double) 10L);
//        java.util.Calendar calendar61 = null;
//        long long62 = fixedMillisecond58.getMiddleMillisecond(calendar61);
//        long long63 = fixedMillisecond58.getSerialIndex();
//        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month();
//        long long65 = month64.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = month64.previous();
//        java.lang.String str67 = month64.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month64, (java.lang.Number) (byte) 100);
//        long long70 = month64.getLastMillisecond();
//        boolean boolean71 = fixedMillisecond58.equals((java.lang.Object) month64);
//        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day();
//        boolean boolean75 = day73.equals((java.lang.Object) 2958465);
//        long long76 = day73.getSerialIndex();
//        java.lang.Class<?> wildcardClass77 = day73.getClass();
//        java.lang.Object obj78 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass77);
//        boolean boolean79 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month64, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year80 = month64.getYear();
//        org.jfree.data.time.TimeSeries timeSeries81 = timeSeries53.createCopy((org.jfree.data.time.RegularTimePeriod) month54, (org.jfree.data.time.RegularTimePeriod) year80);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener82 = null;
//        timeSeries53.addChangeListener(seriesChangeListener82);
//        timeSeries53.setMaximumItemCount((int) (short) 0);
//        java.lang.Class class86 = timeSeries53.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries87 = timeSeries10.addAndOrUpdate(timeSeries53);
//        java.lang.String str88 = timeSeries10.getDomainDescription();
//        java.lang.String str89 = timeSeries10.getRangeDescription();
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440316471L + "'", long19 == 1560440316471L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440316471L + "'", long20 == 1560440316471L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(list41);
//        org.junit.Assert.assertNotNull(obj42);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 43629L + "'", long50 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertNull(uRL52);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 24234L + "'", long55 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560440316478L + "'", long62 == 1560440316478L);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560440316478L + "'", long63 == 1560440316478L);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 24234L + "'", long65 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "June 2019" + "'", str67.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1561964399999L + "'", long70 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 43629L + "'", long76 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass77);
//        org.junit.Assert.assertNull(obj78);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//        org.junit.Assert.assertNotNull(year80);
//        org.junit.Assert.assertNotNull(timeSeries81);
//        org.junit.Assert.assertNotNull(class86);
//        org.junit.Assert.assertNotNull(timeSeries87);
//        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "" + "'", str88.equals(""));
//        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "ThreadContext" + "'", str89.equals("ThreadContext"));
//    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        long long7 = month6.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.previous();
//        java.lang.String str9 = month6.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
//        boolean boolean13 = month6.equals((java.lang.Object) day10);
//        int int14 = day3.compareTo((java.lang.Object) day10);
//        org.jfree.data.time.SerialDate serialDate15 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths((-459), serialDate15);
//        int int17 = spreadsheetDate1.compare(serialDate15);
//        int int18 = spreadsheetDate1.getMonth();
//        int int19 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
//        org.jfree.data.time.SerialDate serialDate21 = null;
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        long long24 = day23.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate25 = day23.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, serialDate25);
//        try {
//            boolean boolean27 = spreadsheetDate1.isInRange(serialDate21, serialDate26);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 24234L + "'", long7 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "June 2019" + "'", str9.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560495599999L + "'", long11 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-43617) + "'", int17 == (-43617));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 12 + "'", int19 == 12);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560495599999L + "'", long24 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        timeSeries10.setNotify(true);
//        java.util.List list41 = timeSeries10.getItems();
//        java.lang.Comparable comparable42 = timeSeries10.getKey();
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440316994L + "'", long19 == 1560440316994L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440316994L + "'", long20 == 1560440316994L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(list41);
//        org.junit.Assert.assertTrue("'" + comparable42 + "' != '" + 2019 + "'", comparable42.equals(2019));
//    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener39 = null;
//        timeSeries10.addChangeListener(seriesChangeListener39);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
//        long long42 = month41.getSerialIndex();
//        org.jfree.data.time.Year year43 = month41.getYear();
//        long long44 = year43.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year43.previous();
//        int int46 = year43.getYear();
//        int int47 = year43.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year43, (double) 1900);
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
//        long long51 = month50.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = month50.previous();
//        java.lang.String str53 = month50.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month50, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = timeSeriesDataItem55.getPeriod();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        int int59 = timeSeriesDataItem55.compareTo((java.lang.Object) 100);
//        timeSeriesDataItem55.setValue((java.lang.Number) 100.0d);
//        try {
//            timeSeries10.add(timeSeriesDataItem55, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440317199L + "'", long19 == 1560440317199L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440317199L + "'", long20 == 1560440317199L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 24234L + "'", long42 == 24234L);
//        org.junit.Assert.assertNotNull(year43);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 2019L + "'", long44 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 24234L + "'", long51 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "June 2019" + "'", str53.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(1900);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(12);
        boolean boolean4 = spreadsheetDate1.isOnOrBefore(serialDate3);
        int int5 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(2);
        boolean boolean8 = spreadsheetDate1.isBefore(serialDate7);
        java.util.Date date9 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        java.util.TimeZone timeZone11 = null;
        try {
            org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date9, timeZone11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 11 + "'", int5 == 11);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 'a');
        java.lang.Number number7 = timeSeriesDataItem6.getValue();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem6, "org.jfree.data.general.SeriesException: 13-June-2019", "ThreadContext", class10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 97.0d + "'", number7.equals(97.0d));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("org.jfree.data.general.SeriesException: ");
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        timeSeries10.setNotify(true);
//        java.util.List list41 = timeSeries10.getItems();
//        java.lang.String str42 = timeSeries10.getDomainDescription();
//        timeSeries10.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries10.createCopy(8, 12);
//        int int48 = timeSeries47.getItemCount();
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440317471L + "'", long19 == 1560440317471L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440317471L + "'", long20 == 1560440317471L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(list41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        timeSeries10.setNotify(true);
//        java.util.List list41 = timeSeries10.getItems();
//        boolean boolean42 = timeSeries10.isEmpty();
//        timeSeries10.setDomainDescription("Nearest");
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) day45, (java.lang.Number) 1560440257080L, true);
//        boolean boolean50 = day45.equals((java.lang.Object) 1560440233309L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440317613L + "'", long19 == 1560440317613L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440317613L + "'", long20 == 1560440317613L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(list41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener39 = null;
//        timeSeries10.addChangeListener(seriesChangeListener39);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        long long43 = fixedMillisecond42.getFirstMillisecond();
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
//        long long45 = month44.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = month44.previous();
//        int int47 = fixedMillisecond42.compareTo((java.lang.Object) regularTimePeriod46);
//        timeSeries10.setKey((java.lang.Comparable) regularTimePeriod46);
//        timeSeries10.clear();
//        timeSeries10.setMaximumItemCount((int) (byte) 100);
//        try {
//            timeSeries10.update((-459), (java.lang.Number) 1560440291418L);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440317760L + "'", long19 == 1560440317760L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440317760L + "'", long20 == 1560440317760L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 100L + "'", long43 == 100L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 24234L + "'", long45 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        timeSeries10.setNotify(true);
//        java.util.List list41 = timeSeries10.getItems();
//        timeSeries10.removeAgedItems(1560409200000L, false);
//        long long45 = timeSeries10.getMaximumItemAge();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener46 = null;
//        timeSeries10.removeChangeListener(seriesChangeListener46);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (double) 10L);
//        java.util.Calendar calendar51 = null;
//        long long52 = fixedMillisecond48.getMiddleMillisecond(calendar51);
//        long long53 = fixedMillisecond48.getSerialIndex();
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month();
//        long long55 = month54.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = month54.previous();
//        java.lang.String str57 = month54.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month54, (java.lang.Number) (byte) 100);
//        long long60 = month54.getLastMillisecond();
//        boolean boolean61 = fixedMillisecond48.equals((java.lang.Object) month54);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
//        boolean boolean65 = day63.equals((java.lang.Object) 2958465);
//        long long66 = day63.getSerialIndex();
//        java.lang.Class<?> wildcardClass67 = day63.getClass();
//        java.lang.Object obj68 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass67);
//        boolean boolean69 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month54, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year70 = month54.getYear();
//        org.jfree.data.time.Year year71 = month54.getYear();
//        java.lang.String[] strArray73 = org.jfree.data.time.SerialDate.getMonths(false);
//        int int74 = year71.compareTo((java.lang.Object) strArray73);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year71, (java.lang.Number) (-460));
//        org.jfree.data.time.Month month77 = new org.jfree.data.time.Month();
//        long long78 = month77.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = month77.previous();
//        org.jfree.data.time.TimeSeries timeSeries80 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod79);
//        boolean boolean81 = timeSeries10.equals((java.lang.Object) timeSeries80);
//        timeSeries10.setKey((java.lang.Comparable) 1560440314106L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440317795L + "'", long19 == 1560440317795L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440317795L + "'", long20 == 1560440317795L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(list41);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 9223372036854775807L + "'", long45 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560440317800L + "'", long52 == 1560440317800L);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560440317800L + "'", long53 == 1560440317800L);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 24234L + "'", long55 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "June 2019" + "'", str57.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1561964399999L + "'", long60 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 43629L + "'", long66 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass67);
//        org.junit.Assert.assertNull(obj68);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertNotNull(year70);
//        org.junit.Assert.assertNotNull(year71);
//        org.junit.Assert.assertNotNull(strArray73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem76);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 24234L + "'", long78 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod79);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        timeSeries10.setNotify(true);
//        java.lang.String str41 = timeSeries10.getDomainDescription();
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
//        long long43 = month42.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month42.previous();
//        java.lang.String str45 = month42.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month42, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = timeSeriesDataItem47.getPeriod();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        int int51 = timeSeriesDataItem47.compareTo((java.lang.Object) 100);
//        timeSeriesDataItem47.setValue((java.lang.Number) 100.0d);
//        timeSeriesDataItem47.setValue((java.lang.Number) (-1));
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException57 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray58 = timePeriodFormatException57.getSuppressed();
//        boolean boolean59 = timeSeriesDataItem47.equals((java.lang.Object) timePeriodFormatException57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = timeSeriesDataItem47.getPeriod();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries10.getDataItem(regularTimePeriod60);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440318385L + "'", long19 == 1560440318385L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440318385L + "'", long20 == 1560440318385L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 24234L + "'", long43 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "June 2019" + "'", str45.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertNotNull(throwableArray58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNull(timeSeriesDataItem61);
//    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        boolean boolean7 = day5.equals((java.lang.Object) 2958465);
//        long long8 = day5.getSerialIndex();
//        java.lang.Class<?> wildcardClass9 = day5.getClass();
//        java.net.URL uRL10 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass9);
//        java.util.Date date11 = null;
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date11, timeZone12);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        boolean boolean20 = day18.equals((java.lang.Object) 2958465);
//        long long21 = day18.getSerialIndex();
//        java.lang.Class<?> wildcardClass22 = day18.getClass();
//        java.net.URL uRL23 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass22);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass22);
//        java.lang.Object obj25 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass9, (java.lang.Class) wildcardClass22);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        boolean boolean30 = day28.equals((java.lang.Object) 2958465);
//        long long31 = day28.getSerialIndex();
//        java.lang.Class<?> wildcardClass32 = day28.getClass();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        boolean boolean35 = day33.equals((java.lang.Object) 2958465);
//        long long36 = day33.getSerialIndex();
//        java.lang.Class<?> wildcardClass37 = day33.getClass();
//        java.lang.Object obj38 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass32, (java.lang.Class) wildcardClass37);
//        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
//        java.net.URL uRL40 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesException: 13-June-2019", (java.lang.Class) wildcardClass32);
//        java.lang.Object obj41 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass9, (java.lang.Class) wildcardClass32);
//        java.io.InputStream inputStream42 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", (java.lang.Class) wildcardClass9);
//        java.net.URL uRL43 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass9);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43629L + "'", long8 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNull(uRL10);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43629L + "'", long21 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNull(uRL23);
//        org.junit.Assert.assertNull(obj25);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 43629L + "'", long31 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 43629L + "'", long36 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNull(obj38);
//        org.junit.Assert.assertNotNull(class39);
//        org.junit.Assert.assertNull(uRL40);
//        org.junit.Assert.assertNull(obj41);
//        org.junit.Assert.assertNull(inputStream42);
//        org.junit.Assert.assertNotNull(uRL43);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        java.util.Date date3 = month0.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date3, timeZone7);
        java.lang.Object obj9 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) timeZone7);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(obj9);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean4 = day2.equals((java.lang.Object) 2958465);
//        long long5 = day2.getSerialIndex();
//        java.lang.Class<?> wildcardClass6 = day2.getClass();
//        java.net.URL uRL7 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass6);
//        java.util.Date date8 = null;
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date8, timeZone9);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date14, timeZone18);
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date14, timeZone20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date14);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNull(uRL7);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) 1560440234730L);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(12);
        boolean boolean4 = spreadsheetDate1.isOnOrBefore(serialDate3);
        int int5 = spreadsheetDate1.getDayOfMonth();
        int int6 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 11 + "'", int5 == 11);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 11 + "'", int6 == 11);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean4 = day2.equals((java.lang.Object) 2958465);
//        long long5 = day2.getSerialIndex();
//        java.lang.Class<?> wildcardClass6 = day2.getClass();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean9 = day7.equals((java.lang.Object) 2958465);
//        long long10 = day7.getSerialIndex();
//        java.lang.Class<?> wildcardClass11 = day7.getClass();
//        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass6, (java.lang.Class) wildcardClass11);
//        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass6);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43629L + "'", long10 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(obj12);
//        org.junit.Assert.assertNull(uRL13);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.lang.Object obj2 = null;
        boolean boolean3 = year0.equals(obj2);
        boolean boolean5 = year0.equals((java.lang.Object) 11);
        long long6 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        java.util.Date date4 = day0.getStart();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(date4);
//    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        boolean boolean8 = day6.equals((java.lang.Object) 2958465);
//        long long9 = day6.getSerialIndex();
//        java.lang.Class<?> wildcardClass10 = day6.getClass();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        boolean boolean13 = day11.equals((java.lang.Object) 2958465);
//        long long14 = day11.getSerialIndex();
//        java.lang.Class<?> wildcardClass15 = day11.getClass();
//        java.lang.Object obj16 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass10, (java.lang.Class) wildcardClass15);
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        java.io.InputStream inputStream18 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass10);
//        java.io.InputStream inputStream19 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", (java.lang.Class) wildcardClass10);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440262488L, "30-June-2019", "", (java.lang.Class) wildcardClass10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (double) 10L);
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond21.getMiddleMillisecond(calendar24);
//        long long26 = fixedMillisecond21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = null;
//        try {
//            org.jfree.data.time.TimeSeries timeSeries28 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, regularTimePeriod27);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43629L + "'", long9 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNull(obj16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertNotNull(inputStream18);
//        org.junit.Assert.assertNull(inputStream19);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560440319211L + "'", long25 == 1560440319211L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560440319211L + "'", long26 == 1560440319211L);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (byte) 100);
        int int6 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 2958465);
//        long long3 = day0.getSerialIndex();
//        long long4 = day0.getLastMillisecond();
//        long long5 = day0.getLastMillisecond();
//        long long6 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43629L + "'", long3 == 43629L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("30-June-2019");
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 2958465);
//        long long3 = day0.getFirstMillisecond();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date4);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        long long8 = month7.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
//        java.util.Date date10 = month7.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date10);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date10);
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date10, timeZone15);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date4, timeZone15);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date4);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 24234L + "'", long8 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(timeZone15);
//    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(12);
//        boolean boolean4 = spreadsheetDate1.isOnOrBefore(serialDate3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(12);
//        boolean boolean9 = spreadsheetDate6.isOnOrBefore(serialDate8);
//        int int10 = spreadsheetDate6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(2);
//        boolean boolean13 = spreadsheetDate6.isBefore(serialDate12);
//        boolean boolean15 = spreadsheetDate6.equals((java.lang.Object) "");
//        int int16 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate6);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate19 = day17.getSerialDate();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        long long21 = day20.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
//        java.lang.String str23 = serialDate22.toString();
//        org.jfree.data.time.SerialDate serialDate24 = serialDate19.getEndOfCurrentMonth(serialDate22);
//        serialDate19.setDescription("");
//        boolean boolean27 = spreadsheetDate1.isOnOrAfter(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 11 + "'", int10 == 11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560495599999L + "'", long18 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560495599999L + "'", long21 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener39 = null;
//        timeSeries10.addChangeListener(seriesChangeListener39);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        long long43 = fixedMillisecond42.getFirstMillisecond();
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
//        long long45 = month44.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = month44.previous();
//        int int47 = fixedMillisecond42.compareTo((java.lang.Object) regularTimePeriod46);
//        timeSeries10.setKey((java.lang.Comparable) regularTimePeriod46);
//        timeSeries10.clear();
//        timeSeries10.setMaximumItemCount((int) (byte) 100);
//        java.beans.PropertyChangeListener propertyChangeListener52 = null;
//        timeSeries10.removePropertyChangeListener(propertyChangeListener52);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440319591L + "'", long19 == 1560440319591L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440319591L + "'", long20 == 1560440319591L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 100L + "'", long43 == 100L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 24234L + "'", long45 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        java.lang.String str9 = serialDate8.toString();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate5.getEndOfCurrentMonth(serialDate8);
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(11, serialDate10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        long long13 = day12.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate14 = day12.getSerialDate();
//        java.lang.String str15 = serialDate14.toString();
//        org.jfree.data.time.SerialDate serialDate16 = serialDate10.getEndOfCurrentMonth(serialDate14);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addYears((int) '4', serialDate14);
//        try {
//            org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(13, serialDate14);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate17);
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (3) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        long long2 = fixedMillisecond1.getFirstMillisecond();
//        long long3 = fixedMillisecond1.getMiddleMillisecond();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 2958465);
//        long long13 = day10.getSerialIndex();
//        java.lang.Class<?> wildcardClass14 = day10.getClass();
//        java.net.URL uRL15 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass14);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass14);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        long long18 = month17.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month17.previous();
//        java.util.Date date20 = month17.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (double) 10L);
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond21.getMiddleMillisecond(calendar24);
//        long long26 = fixedMillisecond21.getSerialIndex();
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        long long28 = month27.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month27.previous();
//        java.lang.String str30 = month27.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) (byte) 100);
//        long long33 = month27.getLastMillisecond();
//        boolean boolean34 = fixedMillisecond21.equals((java.lang.Object) month27);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        boolean boolean38 = day36.equals((java.lang.Object) 2958465);
//        long long39 = day36.getSerialIndex();
//        java.lang.Class<?> wildcardClass40 = day36.getClass();
//        java.lang.Object obj41 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass40);
//        boolean boolean42 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month27, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year43 = month27.getYear();
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) month17, (org.jfree.data.time.RegularTimePeriod) year43);
//        timeSeries16.setNotify(true);
//        java.util.List list47 = timeSeries16.getItems();
//        timeSeries16.removeAgedItems(1560409200000L, false);
//        java.util.Collection collection51 = timeSeries16.getTimePeriods();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        long long54 = fixedMillisecond53.getFirstMillisecond();
//        long long55 = fixedMillisecond53.getMiddleMillisecond();
//        java.lang.String str56 = fixedMillisecond53.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53, (double) 1560440260894L);
//        boolean boolean59 = fixedMillisecond1.equals((java.lang.Object) timeSeries16);
//        long long60 = fixedMillisecond1.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43629L + "'", long13 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNull(uRL15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 24234L + "'", long18 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560440319803L + "'", long25 == 1560440319803L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560440319803L + "'", long26 == 1560440319803L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 24234L + "'", long28 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "June 2019" + "'", str30.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1561964399999L + "'", long33 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 43629L + "'", long39 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass40);
//        org.junit.Assert.assertNull(obj41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(year43);
//        org.junit.Assert.assertNotNull(timeSeries44);
//        org.junit.Assert.assertNotNull(list47);
//        org.junit.Assert.assertNotNull(collection51);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 100L + "'", long54 == 100L);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 100L + "'", long55 == 100L);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str56.equals("Wed Dec 31 16:00:00 PST 1969"));
//        org.junit.Assert.assertNull(timeSeriesDataItem58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 100L + "'", long60 == 100L);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        java.util.Date date3 = month0.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
        java.util.Date date9 = day8.getEnd();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        long long2 = month1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month1.previous();
        java.util.Date date4 = month1.getEnd();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(11, year6);
        java.util.Date date8 = year6.getEnd();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date8);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        timeSeries10.setNotify(true);
//        java.lang.String str41 = timeSeries10.getDomainDescription();
//        java.lang.String str42 = timeSeries10.getRangeDescription();
//        java.util.Collection collection43 = timeSeries10.getTimePeriods();
//        timeSeries10.fireSeriesChanged();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, (double) 10L);
//        java.util.Calendar calendar48 = null;
//        long long49 = fixedMillisecond45.getMiddleMillisecond(calendar48);
//        long long50 = fixedMillisecond45.getSerialIndex();
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
//        long long52 = month51.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = month51.previous();
//        java.lang.String str54 = month51.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month51, (java.lang.Number) (byte) 100);
//        long long57 = month51.getLastMillisecond();
//        boolean boolean58 = fixedMillisecond45.equals((java.lang.Object) month51);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        boolean boolean62 = day60.equals((java.lang.Object) 2958465);
//        long long63 = day60.getSerialIndex();
//        java.lang.Class<?> wildcardClass64 = day60.getClass();
//        java.lang.Object obj65 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass64);
//        boolean boolean66 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month51, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year67 = month51.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = month51.previous();
//        try {
//            timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month51, (java.lang.Number) 1560440246360L, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440320134L + "'", long19 == 1560440320134L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440320134L + "'", long20 == 1560440320134L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "ThreadContext" + "'", str42.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(collection43);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560440320141L + "'", long49 == 1560440320141L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560440320141L + "'", long50 == 1560440320141L);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 24234L + "'", long52 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "June 2019" + "'", str54.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1561964399999L + "'", long57 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 43629L + "'", long63 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass64);
//        org.junit.Assert.assertNull(obj65);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertNotNull(year67);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.Year year2 = month0.getYear();
        long long3 = year2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year2.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (java.lang.Number) 13);
        long long7 = year2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year2.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener39 = null;
//        timeSeries10.addChangeListener(seriesChangeListener39);
//        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries10.createCopy(0, 0);
//        try {
//            java.lang.Number number45 = timeSeries10.getValue((int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440320264L + "'", long19 == 1560440320264L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440320264L + "'", long20 == 1560440320264L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(timeSeries43);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.Year year2 = month0.getYear();
        long long3 = year2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year2.previous();
        int int5 = year2.getYear();
        int int6 = year2.getYear();
        long long7 = year2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        timeSeries10.setNotify(true);
//        timeSeries10.setDescription("org.jfree.data.general.SeriesException: 13-June-2019");
//        java.beans.PropertyChangeListener propertyChangeListener43 = null;
//        timeSeries10.removePropertyChangeListener(propertyChangeListener43);
//        timeSeries10.removeAgedItems(0L, true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440320493L + "'", long19 == 1560440320493L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440320493L + "'", long20 == 1560440320493L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 'a');
        timeSeriesDataItem6.setValue((java.lang.Number) 1560440304773L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 2958465);
//        long long3 = day0.getFirstMillisecond();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date4);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.general.SeriesException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 10L);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        long long7 = month6.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.previous();
//        java.lang.String str9 = month6.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 100);
//        long long12 = month6.getLastMillisecond();
//        boolean boolean13 = fixedMillisecond0.equals((java.lang.Object) month6);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        boolean boolean17 = day15.equals((java.lang.Object) 2958465);
//        long long18 = day15.getSerialIndex();
//        java.lang.Class<?> wildcardClass19 = day15.getClass();
//        java.lang.Object obj20 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass19);
//        boolean boolean21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month6, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year22 = month6.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month6.previous();
//        java.util.Date date24 = month6.getEnd();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440321264L + "'", long4 == 1560440321264L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440321264L + "'", long5 == 1560440321264L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 24234L + "'", long7 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "June 2019" + "'", str9.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43629L + "'", long18 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNull(obj20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(date24);
//    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        timeSeries10.setNotify(true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (double) 10L);
//        java.util.Calendar calendar44 = null;
//        long long45 = fixedMillisecond41.getMiddleMillisecond(calendar44);
//        long long46 = fixedMillisecond41.getSerialIndex();
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        long long48 = month47.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month47.previous();
//        java.lang.String str50 = month47.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month47, (java.lang.Number) (byte) 100);
//        long long53 = month47.getLastMillisecond();
//        boolean boolean54 = fixedMillisecond41.equals((java.lang.Object) month47);
//        java.util.Calendar calendar55 = null;
//        long long56 = fixedMillisecond41.getFirstMillisecond(calendar55);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57, (double) 10L);
//        long long60 = fixedMillisecond57.getFirstMillisecond();
//        int int61 = fixedMillisecond41.compareTo((java.lang.Object) fixedMillisecond57);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57);
//        timeSeries10.removeAgedItems(0L, true);
//        timeSeries10.setDomainDescription("April");
//        java.lang.String str68 = timeSeries10.getRangeDescription();
//        timeSeries10.setKey((java.lang.Comparable) (-1L));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440321360L + "'", long19 == 1560440321360L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440321360L + "'", long20 == 1560440321360L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560440321364L + "'", long45 == 1560440321364L);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560440321364L + "'", long46 == 1560440321364L);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 24234L + "'", long48 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "June 2019" + "'", str50.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1561964399999L + "'", long53 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560440321364L + "'", long56 == 1560440321364L);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560440321369L + "'", long60 == 1560440321369L);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
//        org.junit.Assert.assertNull(timeSeriesDataItem62);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "ThreadContext" + "'", str68.equals("ThreadContext"));
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) ' ');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
//        java.lang.String str3 = month0.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem5.getPeriod();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        boolean boolean11 = day9.equals((java.lang.Object) 2958465);
//        long long12 = day9.getSerialIndex();
//        java.lang.Class<?> wildcardClass13 = day9.getClass();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        boolean boolean17 = day15.equals((java.lang.Object) 2958465);
//        long long18 = day15.getSerialIndex();
//        java.lang.Class<?> wildcardClass19 = day15.getClass();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        boolean boolean22 = day20.equals((java.lang.Object) 2958465);
//        long long23 = day20.getSerialIndex();
//        java.lang.Class<?> wildcardClass24 = day20.getClass();
//        java.lang.Object obj25 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass19, (java.lang.Class) wildcardClass24);
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
//        java.lang.Object obj27 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("13-June-2019", (java.lang.Class) wildcardClass13, class26);
//        java.io.InputStream inputStream28 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Nearest", class26);
//        int int29 = timeSeriesDataItem5.compareTo((java.lang.Object) inputStream28);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = timeSeriesDataItem5.getPeriod();
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        long long32 = month31.getMiddleMillisecond();
//        boolean boolean34 = month31.equals((java.lang.Object) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month31.previous();
//        int int36 = month31.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month31.next();
//        int int38 = timeSeriesDataItem5.compareTo((java.lang.Object) month31);
//        java.lang.String str39 = month31.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43629L + "'", long12 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43629L + "'", long18 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43629L + "'", long23 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNull(obj25);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertNull(obj27);
//        org.junit.Assert.assertNull(inputStream28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560668399999L + "'", long32 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "June 2019" + "'", str39.equals("June 2019"));
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 10L);
//        long long3 = fixedMillisecond0.getFirstMillisecond();
//        long long4 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440321688L + "'", long3 == 1560440321688L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440321688L + "'", long4 == 1560440321688L);
//    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        timeSeries10.setNotify(true);
//        timeSeries10.setNotify(false);
//        java.beans.PropertyChangeListener propertyChangeListener43 = null;
//        timeSeries10.addPropertyChangeListener(propertyChangeListener43);
//        timeSeries10.removeAgedItems(false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440321711L + "'", long19 == 1560440321711L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440321711L + "'", long20 == 1560440321711L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        timeSeries10.setNotify(true);
//        java.util.List list41 = timeSeries10.getItems();
//        boolean boolean42 = timeSeries10.isEmpty();
//        timeSeries10.setDomainDescription("Nearest");
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries10.getDataItem((-1));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440321838L + "'", long19 == 1560440321838L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440321838L + "'", long20 == 1560440321838L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(list41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-458) + "'", int1 == (-458));
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener39 = null;
//        timeSeries10.addChangeListener(seriesChangeListener39);
//        timeSeries10.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month();
//        long long44 = month43.getSerialIndex();
//        org.jfree.data.time.Year year45 = month43.getYear();
//        long long46 = year45.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year45.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) year45);
//        java.lang.String str49 = timeSeries10.getDomainDescription();
//        java.beans.PropertyChangeListener propertyChangeListener50 = null;
//        timeSeries10.addPropertyChangeListener(propertyChangeListener50);
//        java.lang.Comparable comparable52 = timeSeries10.getKey();
//        try {
//            timeSeries10.delete(5, 1900);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440321882L + "'", long19 == 1560440321882L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440321882L + "'", long20 == 1560440321882L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 24234L + "'", long44 == 24234L);
//        org.junit.Assert.assertNotNull(year45);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 2019L + "'", long46 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNull(timeSeriesDataItem48);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "" + "'", str49.equals(""));
//        org.junit.Assert.assertTrue("'" + comparable52 + "' != '" + 2019 + "'", comparable52.equals(2019));
//    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        boolean boolean5 = day3.equals((java.lang.Object) 2958465);
//        long long6 = day3.getSerialIndex();
//        java.lang.Class<?> wildcardClass7 = day3.getClass();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        boolean boolean10 = day8.equals((java.lang.Object) 2958465);
//        long long11 = day8.getSerialIndex();
//        java.lang.Class<?> wildcardClass12 = day8.getClass();
//        java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass7, (java.lang.Class) wildcardClass12);
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        java.io.InputStream inputStream15 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("org.jfree.data.general.SeriesException: 13-June-2019", (java.lang.Class) wildcardClass7);
//        java.lang.Object obj16 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("August", (java.lang.Class) wildcardClass7);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43629L + "'", long11 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNull(obj13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNull(inputStream15);
//        org.junit.Assert.assertNull(obj16);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((-460), (int) 'a', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 2958465);
//        long long3 = day0.getFirstMillisecond();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date4);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        long long8 = month7.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
//        java.util.Date date10 = month7.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date10);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date10);
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date10, timeZone15);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date4, timeZone15);
//        int int19 = month17.compareTo((java.lang.Object) 9);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 24234L + "'", long8 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean9 = day7.equals((java.lang.Object) 2958465);
//        long long10 = day7.getSerialIndex();
//        java.lang.Class<?> wildcardClass11 = day7.getClass();
//        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        long long15 = month14.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month14.previous();
//        java.util.Date date17 = month14.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 10L);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond18.getMiddleMillisecond(calendar21);
//        long long23 = fixedMillisecond18.getSerialIndex();
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        long long25 = month24.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month24.previous();
//        java.lang.String str27 = month24.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (java.lang.Number) (byte) 100);
//        long long30 = month24.getLastMillisecond();
//        boolean boolean31 = fixedMillisecond18.equals((java.lang.Object) month24);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        boolean boolean35 = day33.equals((java.lang.Object) 2958465);
//        long long36 = day33.getSerialIndex();
//        java.lang.Class<?> wildcardClass37 = day33.getClass();
//        java.lang.Object obj38 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass37);
//        boolean boolean39 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month24, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year40 = month24.getYear();
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) year40);
//        timeSeries13.setNotify(true);
//        java.util.List list44 = timeSeries13.getItems();
//        java.lang.String str45 = timeSeries13.getDomainDescription();
//        timeSeries13.removeAgedItems(false);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener48 = null;
//        timeSeries13.removeChangeListener(seriesChangeListener48);
//        java.util.List list50 = timeSeries13.getItems();
//        int int51 = day0.compareTo((java.lang.Object) timeSeries13);
//        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
//        long long53 = month52.getSerialIndex();
//        org.jfree.data.time.Year year54 = month52.getYear();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent55 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year54);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = year54.next();
//        try {
//            timeSeries13.update(regularTimePeriod56, (java.lang.Number) 1560440247145L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43629L + "'", long10 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(uRL12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 24234L + "'", long15 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440322069L + "'", long22 == 1560440322069L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440322069L + "'", long23 == 1560440322069L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "June 2019" + "'", str27.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1561964399999L + "'", long30 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 43629L + "'", long36 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNull(obj38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(year40);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertNotNull(list44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
//        org.junit.Assert.assertNotNull(list50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 24234L + "'", long53 == 24234L);
//        org.junit.Assert.assertNotNull(year54);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(1, (int) (short) -1, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        long long8 = month7.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
//        java.lang.String str10 = month7.toString();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        long long12 = day11.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate13 = day11.getSerialDate();
//        boolean boolean14 = month7.equals((java.lang.Object) day11);
//        int int15 = day4.compareTo((java.lang.Object) day11);
//        org.jfree.data.time.SerialDate serialDate16 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths((-459), serialDate16);
//        int int18 = spreadsheetDate2.compare(serialDate16);
//        int int19 = spreadsheetDate2.getMonth();
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        long long21 = month20.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month20.previous();
//        java.util.Date date23 = month20.getEnd();
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date23);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date23);
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date23);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.previous();
//        org.jfree.data.time.SerialDate serialDate31 = day29.getSerialDate();
//        java.lang.String str32 = serialDate31.toString();
//        java.lang.String str33 = serialDate31.toString();
//        boolean boolean35 = spreadsheetDate2.isInRange(serialDate27, serialDate31, 13);
//        try {
//            org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(2958465, serialDate27);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 24234L + "'", long8 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560495599999L + "'", long12 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-43617) + "'", int18 == (-43617));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 24234L + "'", long21 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "13-June-2019" + "'", str32.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "13-June-2019" + "'", str33.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        long long2 = day1.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, serialDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        boolean boolean7 = day5.equals((java.lang.Object) 1560440245620L);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.lang.String str14 = month11.toString();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        long long16 = day15.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate17 = day15.getSerialDate();
//        boolean boolean18 = month11.equals((java.lang.Object) day15);
//        int int19 = day8.compareTo((java.lang.Object) day15);
//        int int20 = day5.compareTo((java.lang.Object) int19);
//        int int21 = day5.getYear();
//        long long22 = day5.getMiddleMillisecond();
//        java.lang.String str23 = day5.toString();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560495599999L + "'", long9 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560495599999L + "'", long16 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2027 + "'", int21 == 2027);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1823453999999L + "'", long22 == 1823453999999L);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-October-2027" + "'", str23.equals("13-October-2027"));
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("13-June-2019");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("13-June-2019");
        java.lang.String str5 = seriesException4.toString();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("");
        seriesException4.addSuppressed((java.lang.Throwable) seriesException8);
        java.lang.String str10 = seriesException8.toString();
        java.lang.Throwable[] throwableArray11 = seriesException8.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: 13-June-2019" + "'", str2.equals("org.jfree.data.general.SeriesException: 13-June-2019"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: 13-June-2019" + "'", str5.equals("org.jfree.data.general.SeriesException: 13-June-2019"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str10.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
//        java.lang.String str3 = month0.toString();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
//        boolean boolean7 = month0.equals((java.lang.Object) day4);
//        long long8 = day4.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43629L + "'", long8 == 43629L);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        java.lang.String str2 = spreadsheetDate1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "11-January-1900" + "'", str2.equals("11-January-1900"));
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        java.lang.String str39 = timeSeries38.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (double) 10L);
//        java.util.Date date43 = fixedMillisecond40.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) 1560440246790L);
//        int int46 = timeSeries38.getMaximumItemCount();
//        java.lang.String str47 = timeSeries38.getDescription();
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440322858L + "'", long19 == 1560440322858L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440322858L + "'", long20 == 1560440322858L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNull(timeSeriesDataItem45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2147483647 + "'", int46 == 2147483647);
//        org.junit.Assert.assertNull(str47);
//    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        long long3 = day2.getLastMillisecond();
//        java.lang.String str4 = day2.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) 12);
//        int int7 = fixedMillisecond1.compareTo((java.lang.Object) day2);
//        int int8 = day2.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day2.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) 1560440283048L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeriesDataItem11.getPeriod();
//        java.lang.Number number13 = timeSeriesDataItem11.getValue();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1560440283048L + "'", number13.equals(1560440283048L));
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 2958465);
//        long long3 = day0.getFirstMillisecond();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = month5.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year2);
        java.lang.Object obj4 = seriesChangeEvent3.getSource();
        java.lang.Object obj5 = seriesChangeEvent3.getSource();
        java.lang.String str6 = seriesChangeEvent3.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2019]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=2019]"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        timeSeries10.setNotify(true);
//        java.util.List list41 = timeSeries10.getItems();
//        java.lang.String str42 = timeSeries10.getDomainDescription();
//        timeSeries10.removeAgedItems(false);
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
//        long long46 = month45.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = month45.previous();
//        java.util.Date date48 = month45.getEnd();
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(date48);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date48);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond(date48);
//        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance(date48);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(serialDate52);
//        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) day53, (java.lang.Number) 1560440238575L, false);
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
//        boolean boolean58 = timeSeries10.equals((java.lang.Object) day57);
//        boolean boolean59 = timeSeries10.isEmpty();
//        long long60 = timeSeries10.getMaximumItemAge();
//        timeSeries10.clear();
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440323110L + "'", long19 == 1560440323110L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440323110L + "'", long20 == 1560440323110L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(list41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 24234L + "'", long46 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 9223372036854775807L + "'", long60 == 9223372036854775807L);
//    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 10L);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        long long7 = month6.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.previous();
//        java.lang.String str9 = month6.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 100);
//        long long12 = month6.getLastMillisecond();
//        boolean boolean13 = fixedMillisecond0.equals((java.lang.Object) month6);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        boolean boolean17 = day15.equals((java.lang.Object) 2958465);
//        long long18 = day15.getSerialIndex();
//        java.lang.Class<?> wildcardClass19 = day15.getClass();
//        java.lang.Object obj20 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass19);
//        boolean boolean21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month6, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year22 = month6.getYear();
//        int int23 = year22.getYear();
//        java.lang.Class<?> wildcardClass24 = year22.getClass();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440323437L + "'", long4 == 1560440323437L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440323437L + "'", long5 == 1560440323437L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 24234L + "'", long7 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "June 2019" + "'", str9.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43629L + "'", long18 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNull(obj20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        boolean boolean5 = day3.equals((java.lang.Object) 2958465);
//        long long6 = day3.getSerialIndex();
//        java.lang.Class<?> wildcardClass7 = day3.getClass();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        boolean boolean10 = day8.equals((java.lang.Object) 2958465);
//        long long11 = day8.getSerialIndex();
//        java.lang.Class<?> wildcardClass12 = day8.getClass();
//        java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass7, (java.lang.Class) wildcardClass12);
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        java.net.URL uRL15 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesException: 13-June-2019", (java.lang.Class) wildcardClass7);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1, (java.lang.Class) wildcardClass7);
//        timeSeries16.setDescription("June 2019");
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
//        long long20 = month19.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month19.previous();
//        java.lang.String str22 = month19.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = timeSeriesDataItem24.getPeriod();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        int int28 = timeSeriesDataItem24.compareTo((java.lang.Object) 100);
//        timeSeriesDataItem24.setValue((java.lang.Number) 100.0d);
//        timeSeriesDataItem24.setValue((java.lang.Number) (-1));
//        try {
//            timeSeries16.add(timeSeriesDataItem24, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43629L + "'", long11 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNull(obj13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNull(uRL15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 24234L + "'", long20 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "June 2019" + "'", str22.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 'a');
        java.lang.Object obj7 = timeSeriesDataItem6.clone();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(obj7);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        int int3 = day0.getYear();
//        long long4 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        timeSeries10.setNotify(true);
//        java.util.List list41 = timeSeries10.getItems();
//        timeSeries10.removeAgedItems(1560409200000L, false);
//        java.util.Collection collection45 = timeSeries10.getTimePeriods();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        long long48 = fixedMillisecond47.getFirstMillisecond();
//        long long49 = fixedMillisecond47.getMiddleMillisecond();
//        java.lang.String str50 = fixedMillisecond47.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) 1560440260894L);
//        timeSeries10.removeAgedItems(1560440280438L, true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440323566L + "'", long19 == 1560440323566L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440323566L + "'", long20 == 1560440323566L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(list41);
//        org.junit.Assert.assertNotNull(collection45);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 100L + "'", long48 == 100L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 100L + "'", long49 == 100L);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str50.equals("Wed Dec 31 16:00:00 PST 1969"));
//        org.junit.Assert.assertNull(timeSeriesDataItem52);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year2);
        java.lang.Object obj4 = seriesChangeEvent3.getSource();
        java.lang.String str5 = seriesChangeEvent3.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2019]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=2019]"));
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        timeSeries10.setNotify(true);
//        java.util.List list41 = timeSeries10.getItems();
//        boolean boolean42 = timeSeries10.isEmpty();
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        boolean boolean49 = day47.equals((java.lang.Object) 2958465);
//        long long50 = day47.getSerialIndex();
//        java.lang.Class<?> wildcardClass51 = day47.getClass();
//        java.net.URL uRL52 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass51);
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass51);
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month();
//        long long55 = month54.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = month54.previous();
//        java.util.Date date57 = month54.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond58, (double) 10L);
//        java.util.Calendar calendar61 = null;
//        long long62 = fixedMillisecond58.getMiddleMillisecond(calendar61);
//        long long63 = fixedMillisecond58.getSerialIndex();
//        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month();
//        long long65 = month64.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = month64.previous();
//        java.lang.String str67 = month64.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month64, (java.lang.Number) (byte) 100);
//        long long70 = month64.getLastMillisecond();
//        boolean boolean71 = fixedMillisecond58.equals((java.lang.Object) month64);
//        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day();
//        boolean boolean75 = day73.equals((java.lang.Object) 2958465);
//        long long76 = day73.getSerialIndex();
//        java.lang.Class<?> wildcardClass77 = day73.getClass();
//        java.lang.Object obj78 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass77);
//        boolean boolean79 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month64, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year80 = month64.getYear();
//        org.jfree.data.time.TimeSeries timeSeries81 = timeSeries53.createCopy((org.jfree.data.time.RegularTimePeriod) month54, (org.jfree.data.time.RegularTimePeriod) year80);
//        timeSeries53.setNotify(true);
//        java.util.List list84 = timeSeries53.getItems();
//        timeSeries53.removeAgedItems(1560409200000L, false);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener88 = null;
//        timeSeries53.removeChangeListener(seriesChangeListener88);
//        org.jfree.data.time.TimeSeries timeSeries90 = timeSeries10.addAndOrUpdate(timeSeries53);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener91 = null;
//        timeSeries90.removeChangeListener(seriesChangeListener91);
//        java.lang.String str93 = timeSeries90.getDomainDescription();
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440323786L + "'", long19 == 1560440323786L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440323786L + "'", long20 == 1560440323786L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(list41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 43629L + "'", long50 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertNull(uRL52);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 24234L + "'", long55 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560440323799L + "'", long62 == 1560440323799L);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560440323799L + "'", long63 == 1560440323799L);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 24234L + "'", long65 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "June 2019" + "'", str67.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1561964399999L + "'", long70 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 43629L + "'", long76 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass77);
//        org.junit.Assert.assertNull(obj78);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//        org.junit.Assert.assertNotNull(year80);
//        org.junit.Assert.assertNotNull(timeSeries81);
//        org.junit.Assert.assertNotNull(list84);
//        org.junit.Assert.assertNotNull(timeSeries90);
//        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "Time" + "'", str93.equals("Time"));
//    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        timeSeries10.setNotify(true);
//        timeSeries10.setDescription("org.jfree.data.general.SeriesException: 13-June-2019");
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        boolean boolean49 = day47.equals((java.lang.Object) 2958465);
//        long long50 = day47.getSerialIndex();
//        java.lang.Class<?> wildcardClass51 = day47.getClass();
//        java.net.URL uRL52 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass51);
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass51);
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month();
//        long long55 = month54.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = month54.previous();
//        java.util.Date date57 = month54.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond58, (double) 10L);
//        java.util.Calendar calendar61 = null;
//        long long62 = fixedMillisecond58.getMiddleMillisecond(calendar61);
//        long long63 = fixedMillisecond58.getSerialIndex();
//        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month();
//        long long65 = month64.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = month64.previous();
//        java.lang.String str67 = month64.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month64, (java.lang.Number) (byte) 100);
//        long long70 = month64.getLastMillisecond();
//        boolean boolean71 = fixedMillisecond58.equals((java.lang.Object) month64);
//        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day();
//        boolean boolean75 = day73.equals((java.lang.Object) 2958465);
//        long long76 = day73.getSerialIndex();
//        java.lang.Class<?> wildcardClass77 = day73.getClass();
//        java.lang.Object obj78 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass77);
//        boolean boolean79 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month64, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year80 = month64.getYear();
//        org.jfree.data.time.TimeSeries timeSeries81 = timeSeries53.createCopy((org.jfree.data.time.RegularTimePeriod) month54, (org.jfree.data.time.RegularTimePeriod) year80);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener82 = null;
//        timeSeries53.addChangeListener(seriesChangeListener82);
//        org.jfree.data.time.TimeSeries timeSeries86 = timeSeries53.createCopy(0, 0);
//        org.jfree.data.time.TimeSeries timeSeries87 = timeSeries10.addAndOrUpdate(timeSeries86);
//        timeSeries86.removeAgedItems(true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440324346L + "'", long19 == 1560440324346L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440324346L + "'", long20 == 1560440324346L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 43629L + "'", long50 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertNull(uRL52);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 24234L + "'", long55 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560440324354L + "'", long62 == 1560440324354L);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560440324354L + "'", long63 == 1560440324354L);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 24234L + "'", long65 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "June 2019" + "'", str67.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1561964399999L + "'", long70 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 43629L + "'", long76 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass77);
//        org.junit.Assert.assertNull(obj78);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//        org.junit.Assert.assertNotNull(year80);
//        org.junit.Assert.assertNotNull(timeSeries81);
//        org.junit.Assert.assertNotNull(timeSeries86);
//        org.junit.Assert.assertNotNull(timeSeries87);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        int int2 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year2);
        long long4 = year2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 'a');
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        long long8 = month7.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        java.lang.String str10 = month7.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem12.getPeriod();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
        int int16 = timeSeriesDataItem12.compareTo((java.lang.Object) 100);
        int int17 = fixedMillisecond1.compareTo((java.lang.Object) int16);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        long long19 = month18.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod20);
        int int22 = fixedMillisecond1.compareTo((java.lang.Object) regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 24234L + "'", long8 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 24234L + "'", long19 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        timeSeries10.setNotify(true);
//        java.util.List list41 = timeSeries10.getItems();
//        timeSeries10.removeAgedItems(1560409200000L, false);
//        java.util.Collection collection45 = timeSeries10.getTimePeriods();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        long long48 = fixedMillisecond47.getFirstMillisecond();
//        long long49 = fixedMillisecond47.getMiddleMillisecond();
//        java.lang.String str50 = fixedMillisecond47.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) 1560440260894L);
//        java.util.Collection collection53 = timeSeries10.getTimePeriods();
//        timeSeries10.removeAgedItems(false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440325009L + "'", long19 == 1560440325009L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440325009L + "'", long20 == 1560440325009L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(list41);
//        org.junit.Assert.assertNotNull(collection45);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 100L + "'", long48 == 100L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 100L + "'", long49 == 100L);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str50.equals("Wed Dec 31 16:00:00 PST 1969"));
//        org.junit.Assert.assertNull(timeSeriesDataItem52);
//        org.junit.Assert.assertNotNull(collection53);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod2);
        timeSeries3.setRangeDescription("2019");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(12);
        java.lang.String str3 = serialDate2.toString();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths(13, serialDate2);
        try {
            org.jfree.data.time.SerialDate serialDate6 = serialDate2.getPreviousDayOfWeek(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "11-January-1900" + "'", str3.equals("11-January-1900"));
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        long long3 = month0.getFirstMillisecond();
        java.lang.String str4 = month0.toString();
        long long5 = month0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 24234L + "'", long5 == 24234L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.Year year2 = month0.getYear();
        int int3 = year2.getYear();
        java.lang.String str4 = year2.toString();
        long long5 = year2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        java.util.Date date3 = month0.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
        java.lang.String str6 = year5.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long9 = fixedMillisecond8.getFirstMillisecond();
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond8.getMiddleMillisecond(calendar10);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        long long13 = month12.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        java.lang.String str15 = month12.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) (byte) 100);
        boolean boolean18 = fixedMillisecond8.equals((java.lang.Object) month12);
        long long19 = fixedMillisecond8.getLastMillisecond();
        boolean boolean20 = year5.equals((java.lang.Object) fixedMillisecond8);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 24234L + "'", long13 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "June 2019" + "'", str15.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean4 = day2.equals((java.lang.Object) 2958465);
//        long long5 = day2.getSerialIndex();
//        java.lang.Class<?> wildcardClass6 = day2.getClass();
//        java.net.URL uRL7 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass6);
//        java.lang.ClassLoader classLoader8 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass6);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        boolean boolean11 = day9.equals((java.lang.Object) 2958465);
//        long long12 = day9.getFirstMillisecond();
//        java.util.Date date13 = day9.getStart();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date13);
//        java.lang.Class<?> wildcardClass17 = date13.getClass();
//        java.lang.Object obj18 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass6, (java.lang.Class) wildcardClass17);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNull(uRL7);
//        org.junit.Assert.assertNotNull(classLoader8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNull(obj18);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.Year year2 = month0.getYear();
        long long3 = year2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year2.previous();
        long long6 = year2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year2.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        timeSeries10.setNotify(true);
//        java.util.List list41 = timeSeries10.getItems();
//        java.lang.String str42 = timeSeries10.getDomainDescription();
//        timeSeries10.removeAgedItems(false);
//        java.lang.Class class45 = timeSeries10.getTimePeriodClass();
//        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance(7);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(serialDate47);
//        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day48);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440325420L + "'", long19 == 1560440325420L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440325420L + "'", long20 == 1560440325420L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(list41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
//        org.junit.Assert.assertNotNull(class45);
//        org.junit.Assert.assertNotNull(serialDate47);
//    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        timeSeries10.setNotify(true);
//        java.util.List list41 = timeSeries10.getItems();
//        timeSeries10.removeAgedItems(1560409200000L, false);
//        java.util.Collection collection45 = timeSeries10.getTimePeriods();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        long long48 = fixedMillisecond47.getFirstMillisecond();
//        long long49 = fixedMillisecond47.getMiddleMillisecond();
//        java.lang.String str50 = fixedMillisecond47.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) 1560440260894L);
//        java.util.Date date53 = fixedMillisecond47.getEnd();
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440325654L + "'", long19 == 1560440325654L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440325654L + "'", long20 == 1560440325654L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(list41);
//        org.junit.Assert.assertNotNull(collection45);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 100L + "'", long48 == 100L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 100L + "'", long49 == 100L);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str50.equals("Wed Dec 31 16:00:00 PST 1969"));
//        org.junit.Assert.assertNull(timeSeriesDataItem52);
//        org.junit.Assert.assertNotNull(date53);
//    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(12);
//        boolean boolean4 = spreadsheetDate1.isOnOrBefore(serialDate3);
//        int int5 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(2);
//        boolean boolean8 = spreadsheetDate1.isBefore(serialDate7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate11 = day9.getSerialDate();
//        int int12 = spreadsheetDate1.compare(serialDate11);
//        java.lang.String str13 = serialDate11.toString();
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 11 + "'", int5 == 11);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-43617) + "'", int12 == (-43617));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 12);
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        java.lang.Class<?> wildcardClass6 = day0.getClass();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener39 = null;
//        timeSeries10.addChangeListener(seriesChangeListener39);
//        timeSeries10.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month();
//        long long44 = month43.getSerialIndex();
//        org.jfree.data.time.Year year45 = month43.getYear();
//        long long46 = year45.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year45.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) year45);
//        java.lang.String str49 = timeSeries10.getDomainDescription();
//        java.beans.PropertyChangeListener propertyChangeListener50 = null;
//        timeSeries10.addPropertyChangeListener(propertyChangeListener50);
//        timeSeries10.setDomainDescription("April");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        long long56 = fixedMillisecond55.getFirstMillisecond();
//        long long57 = fixedMillisecond55.getMiddleMillisecond();
//        long long58 = fixedMillisecond55.getSerialIndex();
//        timeSeries10.setKey((java.lang.Comparable) long58);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440325972L + "'", long19 == 1560440325972L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440325972L + "'", long20 == 1560440325972L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 24234L + "'", long44 == 24234L);
//        org.junit.Assert.assertNotNull(year45);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 2019L + "'", long46 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNull(timeSeriesDataItem48);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "" + "'", str49.equals(""));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 100L + "'", long56 == 100L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 100L + "'", long57 == 100L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 100L + "'", long58 == 100L);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        int int2 = month0.getYearValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        boolean boolean5 = day3.equals((java.lang.Object) 2958465);
//        long long6 = day3.getSerialIndex();
//        java.lang.Class<?> wildcardClass7 = day3.getClass();
//        java.lang.Object obj8 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass7);
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("2019", (java.lang.Class) wildcardClass7);
//        java.io.InputStream inputStream10 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Wed Dec 31 16:00:00 PST 1969", (java.lang.Class) wildcardClass7);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNull(obj8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertNull(inputStream10);
//    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        boolean boolean7 = day5.equals((java.lang.Object) 2958465);
//        long long8 = day5.getSerialIndex();
//        java.lang.Class<?> wildcardClass9 = day5.getClass();
//        java.net.URL uRL10 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass9);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass9);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        long long13 = month12.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
//        java.util.Date date15 = month12.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) 10L);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond16.getMiddleMillisecond(calendar19);
//        long long21 = fixedMillisecond16.getSerialIndex();
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        long long23 = month22.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month22.previous();
//        java.lang.String str25 = month22.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) (byte) 100);
//        long long28 = month22.getLastMillisecond();
//        boolean boolean29 = fixedMillisecond16.equals((java.lang.Object) month22);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        boolean boolean33 = day31.equals((java.lang.Object) 2958465);
//        long long34 = day31.getSerialIndex();
//        java.lang.Class<?> wildcardClass35 = day31.getClass();
//        java.lang.Object obj36 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass35);
//        boolean boolean37 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month22, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year38 = month22.getYear();
//        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month12, (org.jfree.data.time.RegularTimePeriod) year38);
//        boolean boolean41 = month12.equals((java.lang.Object) 13);
//        org.jfree.data.time.Year year42 = month12.getYear();
//        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(8, year42);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43629L + "'", long8 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNull(uRL10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 24234L + "'", long13 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440326200L + "'", long20 == 1560440326200L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560440326200L + "'", long21 == 1560440326200L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 24234L + "'", long23 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "June 2019" + "'", str25.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1561964399999L + "'", long28 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 43629L + "'", long34 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNull(obj36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(year38);
//        org.junit.Assert.assertNotNull(timeSeries39);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(year42);
//    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.Year year13 = month11.getYear();
//        long long14 = year13.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
//        int int16 = year13.getYear();
//        int int17 = year13.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 10L);
//        java.util.Date date21 = fixedMillisecond18.getTime();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond18.getMiddleMillisecond(calendar22);
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) year13, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond18.getLastMillisecond(calendar25);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440326397L + "'", long23 == 1560440326397L);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560440326397L + "'", long26 == 1560440326397L);
//    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 10L);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        long long7 = month6.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.previous();
//        java.lang.String str9 = month6.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 100);
//        long long12 = month6.getLastMillisecond();
//        boolean boolean13 = fixedMillisecond0.equals((java.lang.Object) month6);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond0.getFirstMillisecond(calendar14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) 10L);
//        long long19 = fixedMillisecond16.getFirstMillisecond();
//        int int20 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond16);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond0.getFirstMillisecond(calendar21);
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond0.getLastMillisecond(calendar23);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440326454L + "'", long4 == 1560440326454L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440326454L + "'", long5 == 1560440326454L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 24234L + "'", long7 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "June 2019" + "'", str9.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560440326454L + "'", long15 == 1560440326454L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440326456L + "'", long19 == 1560440326456L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440326454L + "'", long22 == 1560440326454L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560440326454L + "'", long24 == 1560440326454L);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (byte) 100);
        long long6 = month0.getLastMillisecond();
        long long7 = month0.getLastMillisecond();
        java.lang.String str8 = month0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        long long2 = month1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month1.previous();
        java.util.Date date4 = month1.getEnd();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(11, year6);
        int int8 = month7.getYearValue();
        long long9 = month7.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 24239L + "'", long9 == 24239L);
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 2958465);
//        long long3 = day0.getFirstMillisecond();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        try {
//            org.jfree.data.time.SerialDate serialDate7 = serialDate5.getFollowingDayOfWeek(2019);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("January");
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getMiddleMillisecond();
        boolean boolean3 = month0.equals((java.lang.Object) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.previous();
        int int5 = month0.getMonth();
        long long6 = month0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 2958465);
//        long long3 = day0.getFirstMillisecond();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date4);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date4);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        java.util.Date date5 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod6, (double) 1562097599999L);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        java.util.Date date0 = null;
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        long long2 = month1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month1.previous();
        java.util.Date date4 = month1.getEnd();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date4, timeZone8);
        try {
            org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date0, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone8);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        timeSeries10.setNotify(true);
//        java.util.List list41 = timeSeries10.getItems();
//        java.lang.String str42 = timeSeries10.getDomainDescription();
//        timeSeries10.removeAgedItems(false);
//        java.lang.Class class45 = timeSeries10.getTimePeriodClass();
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
//        long long47 = month46.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month46.previous();
//        java.util.Date date49 = month46.getEnd();
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month(date49);
//        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date49);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond(date49);
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month(date49, timeZone53);
//        timeSeries10.setKey((java.lang.Comparable) date49);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440326785L + "'", long19 == 1560440326785L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440326785L + "'", long20 == 1560440326785L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(list41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
//        org.junit.Assert.assertNotNull(class45);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 24234L + "'", long47 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone53);
//    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.Year year13 = month11.getYear();
//        long long14 = year13.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
//        int int16 = year13.getYear();
//        int int17 = year13.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 10L);
//        java.util.Date date21 = fixedMillisecond18.getTime();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond18.getMiddleMillisecond(calendar22);
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) year13, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
//        timeSeries24.removeChangeListener(seriesChangeListener25);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        boolean boolean33 = day31.equals((java.lang.Object) 2958465);
//        long long34 = day31.getSerialIndex();
//        java.lang.Class<?> wildcardClass35 = day31.getClass();
//        java.net.URL uRL36 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass35);
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass35);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        boolean boolean44 = day42.equals((java.lang.Object) 2958465);
//        long long45 = day42.getSerialIndex();
//        java.lang.Class<?> wildcardClass46 = day42.getClass();
//        java.net.URL uRL47 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass46);
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass46);
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
//        long long50 = month49.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = month49.previous();
//        java.util.Date date52 = month49.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53, (double) 10L);
//        java.util.Calendar calendar56 = null;
//        long long57 = fixedMillisecond53.getMiddleMillisecond(calendar56);
//        long long58 = fixedMillisecond53.getSerialIndex();
//        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month();
//        long long60 = month59.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = month59.previous();
//        java.lang.String str62 = month59.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month59, (java.lang.Number) (byte) 100);
//        long long65 = month59.getLastMillisecond();
//        boolean boolean66 = fixedMillisecond53.equals((java.lang.Object) month59);
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
//        boolean boolean70 = day68.equals((java.lang.Object) 2958465);
//        long long71 = day68.getSerialIndex();
//        java.lang.Class<?> wildcardClass72 = day68.getClass();
//        java.lang.Object obj73 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass72);
//        boolean boolean74 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month59, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year75 = month59.getYear();
//        org.jfree.data.time.TimeSeries timeSeries76 = timeSeries48.createCopy((org.jfree.data.time.RegularTimePeriod) month49, (org.jfree.data.time.RegularTimePeriod) year75);
//        timeSeries48.setNotify(true);
//        java.util.List list79 = timeSeries48.getItems();
//        java.lang.Class<?> wildcardClass80 = timeSeries48.getClass();
//        boolean boolean81 = timeSeries37.equals((java.lang.Object) wildcardClass80);
//        boolean boolean82 = timeSeries24.equals((java.lang.Object) timeSeries37);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = timeSeries37.getTimePeriod(7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440327276L + "'", long23 == 1560440327276L);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 43629L + "'", long34 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNull(uRL36);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 43629L + "'", long45 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertNull(uRL47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 24234L + "'", long50 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560440327281L + "'", long57 == 1560440327281L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560440327281L + "'", long58 == 1560440327281L);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 24234L + "'", long60 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "June 2019" + "'", str62.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1561964399999L + "'", long65 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 43629L + "'", long71 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass72);
//        org.junit.Assert.assertNull(obj73);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertNotNull(year75);
//        org.junit.Assert.assertNotNull(timeSeries76);
//        org.junit.Assert.assertNotNull(list79);
//        org.junit.Assert.assertNotNull(wildcardClass80);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
//    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 10L);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        long long7 = month6.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.previous();
//        java.lang.String str9 = month6.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 100);
//        long long12 = month6.getLastMillisecond();
//        boolean boolean13 = fixedMillisecond0.equals((java.lang.Object) month6);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond0.getFirstMillisecond(calendar14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) 10L);
//        long long19 = fixedMillisecond16.getFirstMillisecond();
//        int int20 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond0.next();
//        java.util.Calendar calendar22 = null;
//        long long23 = regularTimePeriod21.getMiddleMillisecond(calendar22);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440327309L + "'", long4 == 1560440327309L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440327309L + "'", long5 == 1560440327309L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 24234L + "'", long7 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "June 2019" + "'", str9.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560440327309L + "'", long15 == 1560440327309L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440327312L + "'", long19 == 1560440327312L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440327310L + "'", long23 == 1560440327310L);
//    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        long long8 = day7.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
//        java.lang.String str10 = serialDate9.toString();
//        org.jfree.data.time.SerialDate serialDate11 = serialDate6.getEndOfCurrentMonth(serialDate9);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths(11, serialDate11);
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(100, serialDate11);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths((int) (byte) -1, serialDate11);
//        try {
//            org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays(2147483647, serialDate14);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560495599999L + "'", long8 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) -1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 'a');
        long long7 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond1.previous();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(12);
//        boolean boolean4 = spreadsheetDate1.isOnOrBefore(serialDate3);
//        int int5 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(2);
//        boolean boolean8 = spreadsheetDate1.isBefore(serialDate7);
//        boolean boolean10 = spreadsheetDate1.equals((java.lang.Object) 1560440283495L);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        long long13 = day12.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate14 = day12.getSerialDate();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        long long16 = day15.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate17 = day15.getSerialDate();
//        java.lang.String str18 = serialDate17.toString();
//        org.jfree.data.time.SerialDate serialDate19 = serialDate14.getEndOfCurrentMonth(serialDate17);
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(6, serialDate14);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(12);
//        boolean boolean25 = spreadsheetDate22.isOnOrBefore(serialDate24);
//        int int26 = spreadsheetDate22.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(2);
//        boolean boolean29 = spreadsheetDate22.isBefore(serialDate28);
//        boolean boolean31 = spreadsheetDate22.equals((java.lang.Object) "");
//        boolean boolean33 = spreadsheetDate1.isInRange(serialDate20, (org.jfree.data.time.SerialDate) spreadsheetDate22, 1900);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        boolean boolean36 = day34.equals((java.lang.Object) 2958465);
//        long long37 = day34.getFirstMillisecond();
//        java.util.Date date38 = day34.getStart();
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date38);
//        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(date38);
//        boolean boolean41 = spreadsheetDate1.isOnOrAfter(serialDate40);
//        int int42 = spreadsheetDate1.getDayOfMonth();
//        java.lang.String str43 = spreadsheetDate1.getDescription();
//        int int44 = spreadsheetDate1.getMonth();
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 11 + "'", int5 == 11);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560495599999L + "'", long16 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 11 + "'", int26 == 11);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560409200000L + "'", long37 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 11 + "'", int42 == 11);
//        org.junit.Assert.assertNull(str43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 2958465);
//        long long3 = day0.getSerialIndex();
//        java.lang.Class<?> wildcardClass4 = day0.getClass();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        boolean boolean7 = day5.equals((java.lang.Object) 2958465);
//        long long8 = day5.getFirstMillisecond();
//        java.util.Date date9 = day5.getStart();
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date9);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date9);
//        boolean boolean13 = day0.equals((java.lang.Object) date9);
//        org.jfree.data.time.SerialDate serialDate14 = day0.getSerialDate();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43629L + "'", long3 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560409200000L + "'", long8 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(serialDate14);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.Year year2 = month0.getYear();
        int int3 = year2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year2.next();
        long long5 = year2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        long long2 = day1.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, serialDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        java.lang.Class<?> wildcardClass6 = serialDate4.getClass();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        long long3 = month2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        java.util.Date date5 = month2.getEnd();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        int int7 = month6.getYearValue();
        boolean boolean8 = month0.equals((java.lang.Object) month6);
        int int10 = month0.compareTo((java.lang.Object) 1560440304228L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        long long7 = month6.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.previous();
//        java.lang.String str9 = month6.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
//        boolean boolean13 = month6.equals((java.lang.Object) day10);
//        int int14 = day3.compareTo((java.lang.Object) day10);
//        org.jfree.data.time.SerialDate serialDate15 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths((-459), serialDate15);
//        int int17 = spreadsheetDate1.compare(serialDate15);
//        int int18 = spreadsheetDate1.getMonth();
//        int int19 = spreadsheetDate1.toSerial();
//        int int20 = spreadsheetDate1.getYYYY();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 24234L + "'", long7 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "June 2019" + "'", str9.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560495599999L + "'", long11 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-43617) + "'", int17 == (-43617));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 12 + "'", int19 == 12);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1900 + "'", int20 == 1900);
//    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        timeSeries10.setNotify(true);
//        java.util.List list41 = timeSeries10.getItems();
//        timeSeries10.removeAgedItems(1560409200000L, false);
//        java.util.Collection collection45 = timeSeries10.getTimePeriods();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        long long48 = fixedMillisecond47.getFirstMillisecond();
//        long long49 = fixedMillisecond47.getMiddleMillisecond();
//        java.lang.String str50 = fixedMillisecond47.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) 1560440260894L);
//        timeSeries10.setNotify(false);
//        java.lang.Comparable comparable55 = timeSeries10.getKey();
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440327739L + "'", long19 == 1560440327739L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440327739L + "'", long20 == 1560440327739L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(list41);
//        org.junit.Assert.assertNotNull(collection45);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 100L + "'", long48 == 100L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 100L + "'", long49 == 100L);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str50.equals("Wed Dec 31 16:00:00 PST 1969"));
//        org.junit.Assert.assertNull(timeSeriesDataItem52);
//        org.junit.Assert.assertTrue("'" + comparable55 + "' != '" + 2019 + "'", comparable55.equals(2019));
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Following" + "'", str1.equals("Following"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(12);
        boolean boolean4 = spreadsheetDate1.isOnOrBefore(serialDate3);
        int int5 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(2);
        boolean boolean8 = spreadsheetDate1.isBefore(serialDate7);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 11 + "'", int5 == 11);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(12);
//        boolean boolean4 = spreadsheetDate1.isOnOrBefore(serialDate3);
//        int int5 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(2);
//        boolean boolean8 = spreadsheetDate1.isBefore(serialDate7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate11 = day9.getSerialDate();
//        int int12 = spreadsheetDate1.compare(serialDate11);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        long long17 = day16.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate18 = day16.getSerialDate();
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
//        long long20 = month19.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month19.previous();
//        java.lang.String str22 = month19.toString();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        long long24 = day23.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate25 = day23.getSerialDate();
//        boolean boolean26 = month19.equals((java.lang.Object) day23);
//        int int27 = day16.compareTo((java.lang.Object) day23);
//        org.jfree.data.time.SerialDate serialDate28 = day16.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addMonths((-459), serialDate28);
//        int int30 = spreadsheetDate14.compare(serialDate28);
//        int int31 = spreadsheetDate14.getYYYY();
//        int int32 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 11 + "'", int5 == 11);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-43617) + "'", int12 == (-43617));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560495599999L + "'", long17 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 24234L + "'", long20 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "June 2019" + "'", str22.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560495599999L + "'", long24 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-43617) + "'", int30 == (-43617));
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1900 + "'", int31 == 1900);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(12);
        boolean boolean4 = spreadsheetDate1.isOnOrBefore(serialDate3);
        int int5 = spreadsheetDate1.getDayOfMonth();
        int int6 = spreadsheetDate1.toSerial();
        spreadsheetDate1.setDescription("");
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 11 + "'", int5 == 11);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 10L);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        int int6 = fixedMillisecond0.compareTo((java.lang.Object) 1560440281609L);
//        java.util.Calendar calendar7 = null;
//        fixedMillisecond0.peg(calendar7);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440328138L + "'", long4 == 1560440328138L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 10L);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        long long7 = month6.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.previous();
//        java.lang.String str9 = month6.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 100);
//        long long12 = month6.getLastMillisecond();
//        boolean boolean13 = fixedMillisecond0.equals((java.lang.Object) month6);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        boolean boolean17 = day15.equals((java.lang.Object) 2958465);
//        long long18 = day15.getSerialIndex();
//        java.lang.Class<?> wildcardClass19 = day15.getClass();
//        java.lang.Object obj20 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass19);
//        boolean boolean21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month6, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year22 = month6.getYear();
//        org.jfree.data.time.Year year23 = month6.getYear();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        boolean boolean26 = day24.equals((java.lang.Object) 2958465);
//        long long27 = day24.getSerialIndex();
//        boolean boolean28 = year23.equals((java.lang.Object) long27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year23.previous();
//        long long30 = year23.getLastMillisecond();
//        long long31 = year23.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440328152L + "'", long4 == 1560440328152L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440328152L + "'", long5 == 1560440328152L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 24234L + "'", long7 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "June 2019" + "'", str9.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43629L + "'", long18 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNull(obj20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43629L + "'", long27 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1577865599999L + "'", long30 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2019L + "'", long31 == 2019L);
//    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        timeSeries10.setNotify(true);
//        java.lang.String str41 = timeSeries10.getDomainDescription();
//        java.lang.String str42 = timeSeries10.getRangeDescription();
//        java.util.Collection collection43 = timeSeries10.getTimePeriods();
//        try {
//            timeSeries10.delete((int) (byte) 1, 1900);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440328227L + "'", long19 == 1560440328227L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440328227L + "'", long20 == 1560440328227L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "ThreadContext" + "'", str42.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(collection43);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(7, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.Year year2 = month0.getYear();
        long long3 = year2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year2.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (java.lang.Number) 13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year2.next();
        long long8 = year2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("13-June-2019");
//        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("13-June-2019");
//        java.lang.String str4 = seriesException3.toString();
//        java.lang.String str5 = seriesException3.toString();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getLastMillisecond();
//        java.lang.String str8 = day6.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, (java.lang.Number) 12);
//        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("13-June-2019");
//        java.lang.String str13 = seriesException12.toString();
//        java.lang.Throwable[] throwableArray14 = seriesException12.getSuppressed();
//        boolean boolean15 = timeSeriesDataItem10.equals((java.lang.Object) seriesException12);
//        seriesException3.addSuppressed((java.lang.Throwable) seriesException12);
//        java.lang.String str17 = seriesException12.toString();
//        seriesException1.addSuppressed((java.lang.Throwable) seriesException12);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: 13-June-2019" + "'", str4.equals("org.jfree.data.general.SeriesException: 13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: 13-June-2019" + "'", str5.equals("org.jfree.data.general.SeriesException: 13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.general.SeriesException: 13-June-2019" + "'", str13.equals("org.jfree.data.general.SeriesException: 13-June-2019"));
//        org.junit.Assert.assertNotNull(throwableArray14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.general.SeriesException: 13-June-2019" + "'", str17.equals("org.jfree.data.general.SeriesException: 13-June-2019"));
//    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener39 = null;
//        timeSeries10.addChangeListener(seriesChangeListener39);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
//        long long42 = month41.getSerialIndex();
//        org.jfree.data.time.Year year43 = month41.getYear();
//        long long44 = year43.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year43.previous();
//        int int46 = year43.getYear();
//        int int47 = year43.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year43, (double) 1900);
//        java.util.List list50 = timeSeries10.getItems();
//        timeSeries10.setKey((java.lang.Comparable) 1560440247145L);
//        int int53 = timeSeries10.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, (double) 10L);
//        java.util.Calendar calendar57 = null;
//        fixedMillisecond54.peg(calendar57);
//        java.util.Calendar calendar59 = null;
//        fixedMillisecond54.peg(calendar59);
//        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440328326L + "'", long19 == 1560440328326L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440328326L + "'", long20 == 1560440328326L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 24234L + "'", long42 == 24234L);
//        org.junit.Assert.assertNotNull(year43);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 2019L + "'", long44 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNotNull(list50);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        timeSeries10.setNotify(true);
//        java.util.List list41 = timeSeries10.getItems();
//        java.lang.String str42 = timeSeries10.getDomainDescription();
//        timeSeries10.removeAgedItems(false);
//        java.lang.Class class45 = timeSeries10.getTimePeriodClass();
//        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize(class45);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440328689L + "'", long19 == 1560440328689L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440328689L + "'", long20 == 1560440328689L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(list41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
//        org.junit.Assert.assertNotNull(class45);
//        org.junit.Assert.assertNotNull(class46);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 10L);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560440309720L);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        long long6 = month5.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month5.previous();
        long long8 = month5.getFirstMillisecond();
        boolean boolean9 = timeSeriesDataItem2.equals((java.lang.Object) month5);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560452399999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24234L + "'", long6 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1559372400000L + "'", long8 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        boolean boolean5 = day3.equals((java.lang.Object) 2958465);
//        long long6 = day3.getSerialIndex();
//        java.lang.Class<?> wildcardClass7 = day3.getClass();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        boolean boolean10 = day8.equals((java.lang.Object) 2958465);
//        long long11 = day8.getSerialIndex();
//        java.lang.Class<?> wildcardClass12 = day8.getClass();
//        java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass7, (java.lang.Class) wildcardClass12);
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        java.net.URL uRL15 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesException: 13-June-2019", (java.lang.Class) wildcardClass7);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1, (java.lang.Class) wildcardClass7);
//        timeSeries16.setDescription("June 2019");
//        java.util.List list19 = timeSeries16.getItems();
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43629L + "'", long11 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNull(obj13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNull(uRL15);
//        org.junit.Assert.assertNotNull(list19);
//    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener39 = null;
//        timeSeries10.addChangeListener(seriesChangeListener39);
//        timeSeries10.setMaximumItemCount((int) (short) 0);
//        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month();
//        long long44 = month43.getSerialIndex();
//        org.jfree.data.time.Year year45 = month43.getYear();
//        long long46 = year45.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year45.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) year45);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49, (double) 10L);
//        long long52 = fixedMillisecond49.getFirstMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = fixedMillisecond53.previous();
//        long long55 = regularTimePeriod54.getMiddleMillisecond();
//        boolean boolean56 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) fixedMillisecond49, (java.lang.Object) regularTimePeriod54);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries10.getDataItem(regularTimePeriod54);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        long long61 = day60.getLastMillisecond();
//        java.lang.String str62 = day60.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day60, (java.lang.Number) 12);
//        int int65 = fixedMillisecond59.compareTo((java.lang.Object) day60);
//        int int66 = day60.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = day60.next();
//        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month();
//        long long69 = month68.getSerialIndex();
//        org.jfree.data.time.Year year70 = month68.getYear();
//        int int71 = year70.getYear();
//        java.lang.String str72 = year70.toString();
//        long long73 = year70.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries74 = timeSeries10.createCopy(regularTimePeriod67, (org.jfree.data.time.RegularTimePeriod) year70);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = null;
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = timeSeries74.getDataItem(regularTimePeriod75);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440328992L + "'", long19 == 1560440328992L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440328992L + "'", long20 == 1560440328992L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 24234L + "'", long44 == 24234L);
//        org.junit.Assert.assertNotNull(year45);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 2019L + "'", long46 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNull(timeSeriesDataItem48);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560440329000L + "'", long52 == 1560440329000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560440328999L + "'", long55 == 1560440328999L);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem57);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560495599999L + "'", long61 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "13-June-2019" + "'", str62.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 13 + "'", int66 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 24234L + "'", long69 == 24234L);
//        org.junit.Assert.assertNotNull(year70);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 2019 + "'", int71 == 2019);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "2019" + "'", str72.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1577865599999L + "'", long73 == 1577865599999L);
//        org.junit.Assert.assertNotNull(timeSeries74);
//    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        timeSeries10.setNotify(true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (double) 10L);
//        java.util.Calendar calendar44 = null;
//        long long45 = fixedMillisecond41.getMiddleMillisecond(calendar44);
//        long long46 = fixedMillisecond41.getSerialIndex();
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        long long48 = month47.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month47.previous();
//        java.lang.String str50 = month47.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month47, (java.lang.Number) (byte) 100);
//        long long53 = month47.getLastMillisecond();
//        boolean boolean54 = fixedMillisecond41.equals((java.lang.Object) month47);
//        java.util.Calendar calendar55 = null;
//        long long56 = fixedMillisecond41.getFirstMillisecond(calendar55);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57, (double) 10L);
//        long long60 = fixedMillisecond57.getFirstMillisecond();
//        int int61 = fixedMillisecond41.compareTo((java.lang.Object) fixedMillisecond57);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57);
//        timeSeries10.removeAgedItems(0L, true);
//        try {
//            timeSeries10.update((int) (byte) 0, (java.lang.Number) 1560440299862L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440329033L + "'", long19 == 1560440329033L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440329033L + "'", long20 == 1560440329033L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560440329037L + "'", long45 == 1560440329037L);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560440329037L + "'", long46 == 1560440329037L);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 24234L + "'", long48 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "June 2019" + "'", str50.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1561964399999L + "'", long53 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560440329037L + "'", long56 == 1560440329037L);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560440329039L + "'", long60 == 1560440329039L);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
//        org.junit.Assert.assertNull(timeSeriesDataItem62);
//    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
//        java.util.Date date14 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 10L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        long long22 = month21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
//        java.lang.String str24 = month21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (byte) 100);
//        long long27 = month21.getLastMillisecond();
//        boolean boolean28 = fixedMillisecond15.equals((java.lang.Object) month21);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 2958465);
//        long long33 = day30.getSerialIndex();
//        java.lang.Class<?> wildcardClass34 = day30.getClass();
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass34);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) month21, (java.lang.Object) "June 2019");
//        org.jfree.data.time.Year year37 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year37);
//        timeSeries10.removeAgedItems(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (double) 10L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
//        java.util.Calendar calendar45 = null;
//        long long46 = fixedMillisecond41.getFirstMillisecond(calendar45);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440329066L + "'", long19 == 1560440329066L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440329066L + "'", long20 == 1560440329066L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNull(timeSeriesDataItem44);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560440329078L + "'", long46 == 1560440329078L);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.Year year2 = month0.getYear();
        int int3 = year2.getYear();
        java.lang.String str4 = year2.toString();
        long long5 = year2.getMiddleMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        long long2 = day1.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
//        java.lang.String str7 = serialDate6.toString();
//        org.jfree.data.time.SerialDate serialDate8 = serialDate3.getEndOfCurrentMonth(serialDate6);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addMonths(11, serialDate8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
//        java.lang.String str13 = serialDate12.toString();
//        org.jfree.data.time.SerialDate serialDate14 = serialDate8.getEndOfCurrentMonth(serialDate12);
//        serialDate8.setDescription("June 2019");
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560495599999L + "'", long11 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate14);
//    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 2958465);
//        long long7 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019, "", "ThreadContext", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        long long12 = month11.getSerialIndex();
//        org.jfree.data.time.Year year13 = month11.getYear();
//        long long14 = year13.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
//        int int16 = year13.getYear();
//        int int17 = year13.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 10L);
//        java.util.Date date21 = fixedMillisecond18.getTime();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond18.getMiddleMillisecond(calendar22);
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) year13, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
//        java.util.Date date25 = fixedMillisecond18.getTime();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        boolean boolean28 = day26.equals((java.lang.Object) 2958465);
//        long long29 = day26.getFirstMillisecond();
//        java.util.Date date30 = day26.getStart();
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date30);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (double) 10L);
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond34.getMiddleMillisecond(calendar37);
//        long long39 = fixedMillisecond34.getSerialIndex();
//        java.lang.Object obj40 = null;
//        boolean boolean41 = fixedMillisecond34.equals(obj40);
//        java.util.Calendar calendar42 = null;
//        fixedMillisecond34.peg(calendar42);
//        java.util.Date date44 = fixedMillisecond34.getStart();
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
//        long long46 = month45.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = month45.previous();
//        java.util.Date date48 = month45.getEnd();
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(date48);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date48);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond(date48);
//        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month(date48, timeZone52);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date44, timeZone52);
//        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month(date30, timeZone52);
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date25, timeZone52);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440329289L + "'", long23 == 1560440329289L);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560409200000L + "'", long29 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560440329291L + "'", long38 == 1560440329291L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560440329291L + "'", long39 == 1560440329291L);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 24234L + "'", long46 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeZone52);
//    }
//}

