import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (java.lang.Number) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 1, (int) (byte) 0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.util.Date date0 = null;
        java.util.Date date1 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(date0, date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            year0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 10, (long) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(4, 8, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (-1), (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 0);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 0);
        java.util.Calendar calendar4 = null;
        try {
            year0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        boolean boolean4 = year0.equals((java.lang.Object) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod3, "hi!", "");
        boolean boolean7 = timePeriodValues6.isEmpty();
        int int8 = timePeriodValues6.getMinEndIndex();
        boolean boolean9 = year0.equals((java.lang.Object) int8);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year0.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            day0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod3, "hi!", "");
        boolean boolean7 = timePeriodValues6.isEmpty();
        int int8 = timePeriodValues6.getMinEndIndex();
        boolean boolean9 = year0.equals((java.lang.Object) int8);
        java.util.Calendar calendar10 = null;
        try {
            year0.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = null;
        try {
            timePeriodValues4.add(timePeriodValue7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test041");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        int int4 = year3.getYear();
//        boolean boolean5 = day0.equals((java.lang.Object) int4);
//        int int6 = day0.getYear();
//        java.util.Calendar calendar7 = null;
//        try {
//            day0.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        try {
            timePeriodValues4.delete(11, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        try {
            timePeriodValues4.update((int) (byte) 0, (java.lang.Number) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.lang.String str6 = timePeriodValues4.getDomainDescription();
        boolean boolean7 = timePeriodValues4.isEmpty();
        try {
            timePeriodValues4.update((int) (byte) 10, (java.lang.Number) 43629L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(5, 10, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        try {
            int int10 = simpleTimePeriod8.compareTo((java.lang.Object) (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Double cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue7 = timePeriodValues4.getDataItem((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        timePeriodValues4.delete((int) ' ', 0);
        try {
            timePeriodValues4.delete(4, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.Class<?> wildcardClass2 = year0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = regularTimePeriod3.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod10, "hi!", "");
        int int14 = timePeriodValues13.getMinStartIndex();
        int int15 = timePeriodValues13.getItemCount();
        boolean boolean16 = simpleTimePeriod8.equals((java.lang.Object) timePeriodValues13);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod18, "hi!", "");
        boolean boolean22 = timePeriodValues21.isEmpty();
        int int23 = timePeriodValues21.getMaxStartIndex();
        timePeriodValues21.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues21.setDescription("");
        try {
            int int28 = simpleTimePeriod8.compareTo((java.lang.Object) timePeriodValues21);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        timePeriodValues4.delete((int) ' ', 0);
        int int9 = timePeriodValues4.getMaxStartIndex();
        try {
            timePeriodValues4.update(0, (java.lang.Number) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test055");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        int int4 = year3.getYear();
//        boolean boolean5 = day0.equals((java.lang.Object) int4);
//        int int6 = day0.getYear();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test056");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        int int4 = year3.getYear();
//        boolean boolean5 = day0.equals((java.lang.Object) int4);
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod2, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        java.lang.String str7 = timePeriodValues4.getDescription();
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        try {
            timePeriodValues4.update((int) '#', (java.lang.Number) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener6);
        try {
            timePeriodValues4.update(8, (java.lang.Number) 1560495599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        long long10 = simpleTimePeriod8.getEndMillis();
        boolean boolean12 = simpleTimePeriod8.equals((java.lang.Object) 12);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1609487999999L + "'", long10 == 1609487999999L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 1593676799999L);
        timePeriodValues4.add(timePeriodValue10);
        org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValue10.getPeriod();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timePeriod12);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TimePeriodValue[2019,1.593676799999E12]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        timePeriodValues4.delete((int) ' ', 0);
        try {
            java.lang.Number number10 = timePeriodValues4.getValue(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date3);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year9.getMiddleMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test065");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getLastMillisecond();
//        java.lang.Object obj3 = null;
//        boolean boolean4 = day0.equals(obj3);
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        java.util.Date date10 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        int int14 = year12.getYear();
        java.util.Date date15 = year12.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(date10, date15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        int int2 = year0.getYear();
        java.util.Date date3 = year0.getStart();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        int int7 = year6.getYear();
        java.lang.Class<?> wildcardClass8 = year6.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.previous();
        boolean boolean10 = timePeriodValues4.equals((java.lang.Object) regularTimePeriod9);
        timePeriodValues4.setNotify(false);
        try {
            org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValues4.getTimePeriod((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        try {
            java.lang.Number number6 = timePeriodValues4.getValue((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod10, "hi!", "");
        int int14 = timePeriodValues13.getMinStartIndex();
        int int15 = timePeriodValues13.getItemCount();
        boolean boolean16 = simpleTimePeriod8.equals((java.lang.Object) timePeriodValues13);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue18 = timePeriodValues13.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.setDescription("");
        int int11 = timePeriodValues4.getItemCount();
        java.lang.Comparable comparable12 = null;
        try {
            timePeriodValues4.setKey(comparable12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test077");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        int int4 = year3.getYear();
//        boolean boolean5 = day0.equals((java.lang.Object) int4);
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test078");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        int int2 = day0.getMonth();
//        long long3 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43629L + "'", long3 == 43629L);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.Class<?> wildcardClass2 = year0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        long long4 = year0.getFirstMillisecond();
        int int5 = year0.getYear();
        long long6 = year0.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        java.lang.String str7 = timePeriodValues4.getDescription();
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        try {
            org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValues4.getTimePeriod((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        long long10 = simpleTimePeriod8.getEndMillis();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod12, "hi!", "");
        int int16 = timePeriodValues15.getMaxEndIndex();
        boolean boolean17 = timePeriodValues15.isEmpty();
        java.lang.Object obj18 = timePeriodValues15.clone();
        try {
            int int19 = simpleTimePeriod8.compareTo(obj18);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1609487999999L + "'", long10 == 1609487999999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("2020");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        int int7 = year6.getYear();
        java.lang.Class<?> wildcardClass8 = year6.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.previous();
        boolean boolean10 = timePeriodValues4.equals((java.lang.Object) regularTimePeriod9);
        timePeriodValues4.setNotify(false);
        java.lang.Object obj13 = timePeriodValues4.clone();
        int int14 = timePeriodValues4.getMaxMiddleIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test084");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2019);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate3 = day2.getSerialDate();
//        long long4 = day2.getSerialIndex();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day2, (java.lang.Number) 10);
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day2.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        int int6 = timePeriodValues4.getItemCount();
        timePeriodValues4.setKey((java.lang.Comparable) "");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues4.removeChangeListener(seriesChangeListener9);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.Class<?> wildcardClass2 = year0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        long long4 = year0.getFirstMillisecond();
        int int5 = year0.getYear();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year0.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
        boolean boolean14 = timePeriodValues4.equals((java.lang.Object) year11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) 1593676799999L);
        java.lang.Number number20 = timePeriodValue19.getValue();
        java.lang.Number number21 = timePeriodValue19.getValue();
        timePeriodValues4.add(timePeriodValue19);
        java.lang.String str23 = timePeriodValue19.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1.593676799999E12d + "'", number20.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1.593676799999E12d + "'", number21.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "TimePeriodValue[2019,1.593676799999E12]" + "'", str23.equals("TimePeriodValue[2019,1.593676799999E12]"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (97) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.Class<?> wildcardClass2 = year0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        long long4 = year0.getFirstMillisecond();
        int int5 = year0.getYear();
        long long6 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 0);
        timePeriodValue3.setValue((java.lang.Number) 100L);
        java.lang.Object obj6 = timePeriodValue3.clone();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        long long3 = year0.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        timePeriodValues4.setDescription("2019");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener8);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        try {
            java.lang.Number number6 = timePeriodValues4.getValue(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.next();
        java.util.Date date9 = regularTimePeriod8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date9, date13);
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (double) (byte) 1);
        java.lang.Object obj18 = new java.lang.Object();
        try {
            int int19 = simpleTimePeriod14.compareTo(obj18);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Object cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        java.lang.String str7 = timePeriodValues4.getDescription();
        int int8 = timePeriodValues4.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener9);
        timePeriodValues4.setNotify(true);
        try {
            org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValues4.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 1593676799999L);
        java.lang.Number number5 = timePeriodValue4.getValue();
        java.lang.Object obj6 = timePeriodValue4.clone();
        timePeriodValue4.setValue((java.lang.Number) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.593676799999E12d + "'", number5.equals(1.593676799999E12d));
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2019);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        int int3 = year2.getYear();
        java.lang.Class<?> wildcardClass4 = year2.getClass();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year2, (double) 2019);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year2.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (6) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod3, "hi!", "");
        boolean boolean7 = timePeriodValues6.isEmpty();
        int int8 = year0.compareTo((java.lang.Object) boolean7);
        long long9 = year0.getLastMillisecond();
        java.util.Date date10 = year0.getStart();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year0.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Object obj8 = timePeriodValues4.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod12, "hi!", "");
        boolean boolean16 = timePeriodValues15.isEmpty();
        int int17 = year9.compareTo((java.lang.Object) boolean16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year9.previous();
        timePeriodValues4.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.previous();
        timePeriodValues4.setKey((java.lang.Comparable) day20);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue24 = timePeriodValues4.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int2 = day0.getMonth();
        int int3 = day0.getYear();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test103");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        java.util.Calendar calendar4 = null;
//        try {
//            day0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        java.lang.String str7 = timePeriodValues4.getDescription();
        java.lang.Object obj8 = timePeriodValues4.clone();
        boolean boolean9 = timePeriodValues4.getNotify();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        int int4 = year3.getYear();
//        boolean boolean5 = day0.equals((java.lang.Object) int4);
//        int int6 = day0.getYear();
//        int int7 = day0.getDayOfMonth();
//        java.lang.String str8 = day0.toString();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Object obj8 = timePeriodValues4.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod12, "hi!", "");
        boolean boolean16 = timePeriodValues15.isEmpty();
        int int17 = year9.compareTo((java.lang.Object) boolean16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year9.previous();
        timePeriodValues4.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.previous();
        timePeriodValues4.setKey((java.lang.Comparable) day20);
        int int23 = day20.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) 'a', (int) (byte) 10, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 0);
        timePeriodValue3.setValue((java.lang.Number) 100L);
        timePeriodValue3.setValue((java.lang.Number) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod3, "hi!", "");
        boolean boolean7 = timePeriodValues6.isEmpty();
        int int8 = year0.compareTo((java.lang.Object) boolean7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "2019", "2019");
        java.util.Calendar calendar13 = null;
        try {
            long long14 = year0.getMiddleMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        timePeriodValues4.setDescription("2019");
        timePeriodValues4.fireSeriesChanged();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        timePeriodValues4.setDescription("2019");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue9 = timePeriodValues4.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.Class<?> wildcardClass2 = year0.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.util.Date date4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date4, timeZone5);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year8.next();
        java.util.Date date11 = regularTimePeriod10.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.next();
        java.util.Date date15 = regularTimePeriod14.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date11, date15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date15, timeZone17);
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod18, (java.lang.Number) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        timePeriodValues4.delete((int) ' ', 0);
        int int9 = timePeriodValues4.getMaxStartIndex();
        try {
            timePeriodValues4.delete(5, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test114");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        int int4 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getLastMillisecond();
//        long long3 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43629L + "'", long3 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.setDescription("");
        java.lang.String str11 = timePeriodValues4.getRangeDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (35) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int2 = day0.getMonth();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        try {
            timePeriodValues4.update(9, (java.lang.Number) 1560495599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date3);
        long long10 = year9.getFirstMillisecond();
        java.lang.String str11 = year9.toString();
        java.lang.String str12 = year9.toString();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = year9.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865600000L + "'", long10 == 1577865600000L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2020" + "'", str11.equals("2020"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2020" + "'", str12.equals("2020"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.setNotify(false);
        int int11 = timePeriodValues4.getMinStartIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test123");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        long long5 = day0.getSerialIndex();
//        long long6 = day0.getFirstMillisecond();
//        java.util.Date date7 = day0.getEnd();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        int int9 = year8.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) (short) 0);
//        int int12 = day0.compareTo((java.lang.Object) year8);
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = day0.getLastMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        boolean boolean6 = timePeriodValues4.isEmpty();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int8 = year7.getYear();
        long long9 = year7.getLastMillisecond();
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) year7, (-1.0d));
        java.lang.String str12 = timePeriodValues4.getDomainDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        java.util.Date date4 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod(date3, date4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        int int2 = year0.getYear();
//        java.util.Date date3 = year0.getStart();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
//        long long7 = day5.getLastMillisecond();
//        boolean boolean8 = year4.equals((java.lang.Object) long7);
//        long long9 = year4.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod10, "hi!", "");
        int int14 = timePeriodValues13.getMinStartIndex();
        int int15 = timePeriodValues13.getItemCount();
        boolean boolean16 = simpleTimePeriod8.equals((java.lang.Object) timePeriodValues13);
        java.util.Date date17 = simpleTimePeriod8.getStart();
        java.util.Date date18 = simpleTimePeriod8.getStart();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod10, "hi!", "");
        int int14 = timePeriodValues13.getMinStartIndex();
        int int15 = timePeriodValues13.getItemCount();
        boolean boolean16 = simpleTimePeriod8.equals((java.lang.Object) timePeriodValues13);
        long long17 = simpleTimePeriod8.getStartMillis();
        java.util.Date date18 = simpleTimePeriod8.getEnd();
        long long19 = simpleTimePeriod8.getEndMillis();
        java.lang.Object obj20 = null;
        boolean boolean21 = simpleTimePeriod8.equals(obj20);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1609487999999L + "'", long17 == 1609487999999L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1609487999999L + "'", long19 == 1609487999999L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.lang.String str6 = timePeriodValues4.getDomainDescription();
        boolean boolean7 = timePeriodValues4.isEmpty();
        java.lang.Object obj8 = timePeriodValues4.clone();
        timePeriodValues4.setRangeDescription("");
        try {
            org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValues4.getTimePeriod(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
        boolean boolean14 = timePeriodValues4.equals((java.lang.Object) year11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) 1593676799999L);
        java.lang.Number number20 = timePeriodValue19.getValue();
        java.lang.Number number21 = timePeriodValue19.getValue();
        timePeriodValues4.add(timePeriodValue19);
        java.lang.Number number23 = timePeriodValue19.getValue();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1.593676799999E12d + "'", number20.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1.593676799999E12d + "'", number21.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 1.593676799999E12d + "'", number23.equals(1.593676799999E12d));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener6);
        timePeriodValues4.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Object obj8 = timePeriodValues4.clone();
        timePeriodValues4.setDomainDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.next();
        timePeriodValues4.setKey((java.lang.Comparable) year11);
        int int14 = timePeriodValues4.getItemCount();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1577865600000L);
        java.lang.String str2 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1577865600000]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=1577865600000]"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        boolean boolean6 = timePeriodValues4.isEmpty();
        java.lang.String str7 = timePeriodValues4.getDomainDescription();
        try {
            timePeriodValues4.update(12, (java.lang.Number) 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date3);
        long long10 = year9.getFirstMillisecond();
        long long11 = year9.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865600000L + "'", long10 == 1577865600000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1609487999999L + "'", long11 == 1609487999999L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues4.getMinStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) false);
        java.lang.Comparable comparable11 = null;
        try {
            timePeriodValues4.setKey(comparable11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.Class<?> wildcardClass2 = year0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.String str3 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray6 = seriesException5.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str3.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 1593676799999L);
        java.lang.Class<?> wildcardClass5 = year0.getClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod9, "hi!", "");
        boolean boolean13 = timePeriodValues12.isEmpty();
        int int14 = year6.compareTo((java.lang.Object) boolean13);
        long long15 = year6.getLastMillisecond();
        java.util.Date date16 = year6.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        int int19 = year17.getYear();
        java.util.Date date20 = year17.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date20, timeZone23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date16, timeZone23);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        long long27 = year26.getLastMillisecond();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod29, "hi!", "");
        boolean boolean33 = timePeriodValues32.isEmpty();
        int int34 = year26.compareTo((java.lang.Object) boolean33);
        long long35 = year26.getLastMillisecond();
        java.util.Date date36 = year26.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod(date16, date36);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date36);
        java.lang.Object obj39 = null;
        int int40 = year38.compareTo(obj39);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1577865599999L + "'", long35 == 1577865599999L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener8);
        try {
            java.lang.Number number11 = timePeriodValues4.getValue((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Object obj8 = timePeriodValues4.clone();
        timePeriodValues4.setDomainDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.next();
        timePeriodValues4.setKey((java.lang.Comparable) year11);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = year11.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesChangeEvent[source=1577865600000]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1560409200000L);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener2);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test147");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2019);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate3 = day2.getSerialDate();
//        long long4 = day2.getSerialIndex();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day2, (java.lang.Number) 10);
//        timePeriodValues1.setNotify(true);
//        java.lang.Comparable comparable9 = timePeriodValues1.getKey();
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 2019 + "'", comparable9.equals(2019));
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        java.lang.String str7 = timePeriodValues4.getDescription();
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        int int9 = timePeriodValues4.getMinEndIndex();
        timePeriodValues4.setRangeDescription("TimePeriodValue[2019,1.593676799999E12]");
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = null;
        try {
            timePeriodValues4.add(timePeriodValue12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        java.util.Date date10 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        java.util.Calendar calendar12 = null;
        try {
            year11.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        long long9 = simpleTimePeriod8.getStartMillis();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod11, "hi!", "");
        boolean boolean15 = timePeriodValues14.isEmpty();
        int int16 = timePeriodValues14.getMaxStartIndex();
        timePeriodValues14.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues14.setDescription("");
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year21.next();
        boolean boolean24 = timePeriodValues14.equals((java.lang.Object) year21);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year25.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year25, (double) 1593676799999L);
        java.lang.Number number30 = timePeriodValue29.getValue();
        java.lang.Number number31 = timePeriodValue29.getValue();
        timePeriodValues14.add(timePeriodValue29);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day33.previous();
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) regularTimePeriod34, (java.lang.Number) 1577865599999L);
        try {
            int int37 = simpleTimePeriod8.compareTo((java.lang.Object) 1577865599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1609487999999L + "'", long9 == 1609487999999L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 1.593676799999E12d + "'", number30.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 1.593676799999E12d + "'", number31.equals(1.593676799999E12d));
        org.junit.Assert.assertNotNull(regularTimePeriod34);
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test151");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        long long5 = day0.getSerialIndex();
//        long long6 = day0.getFirstMillisecond();
//        java.util.Date date7 = day0.getEnd();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        int int9 = year8.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) (short) 0);
//        int int12 = day0.compareTo((java.lang.Object) year8);
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int12, "", "TimePeriodValue[2019,1.593676799999E12]");
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 1593676799999L);
        java.lang.Number number5 = null;
        timePeriodValue4.setValue(number5);
        java.lang.Number number7 = timePeriodValue4.getValue();
        timePeriodValue4.setValue((java.lang.Number) 1609487999999L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod3, "hi!", "");
        boolean boolean7 = timePeriodValues6.isEmpty();
        int int8 = year0.compareTo((java.lang.Object) boolean7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "2019", "2019");
        java.lang.String str13 = timePeriodValues12.getDescription();
        timePeriodValues12.setKey((java.lang.Comparable) true);
        boolean boolean16 = timePeriodValues12.isEmpty();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.next();
        java.util.Date date17 = regularTimePeriod16.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(date13, date17);
        java.util.Date date19 = simpleTimePeriod18.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date7, date19);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        java.lang.String str7 = timePeriodValues4.getDescription();
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        int int9 = timePeriodValues4.getMinEndIndex();
        timePeriodValues4.setRangeDescription("TimePeriodValue[2019,1.593676799999E12]");
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        int int13 = year12.getYear();
        java.lang.Class<?> wildcardClass14 = year12.getClass();
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date16, timeZone17);
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.next();
        java.util.Date date23 = regularTimePeriod22.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year24.next();
        java.util.Date date27 = regularTimePeriod26.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(date23, date27);
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date27, timeZone29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        long long32 = year31.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year31.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year31, (double) 1593676799999L);
        java.lang.Class<?> wildcardClass36 = year31.getClass();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        long long38 = year37.getLastMillisecond();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year39.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod40, "hi!", "");
        boolean boolean44 = timePeriodValues43.isEmpty();
        int int45 = year37.compareTo((java.lang.Object) boolean44);
        long long46 = year37.getLastMillisecond();
        java.util.Date date47 = year37.getStart();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        long long49 = year48.getLastMillisecond();
        int int50 = year48.getYear();
        java.util.Date date51 = year48.getStart();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date51);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date51);
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date51, timeZone54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date47, timeZone54);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date27, timeZone54);
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) day57, (java.lang.Number) (byte) 1);
        long long60 = day57.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1577865599999L + "'", long38 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1577865599999L + "'", long46 == 1577865599999L);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1577865599999L + "'", long49 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2019 + "'", int50 == 2019);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1609487999999L + "'", long60 == 1609487999999L);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        int int4 = year3.getYear();
//        boolean boolean5 = day0.equals((java.lang.Object) int4);
//        java.lang.String str6 = day0.toString();
//        int int7 = day0.getMonth();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day0.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        int int2 = year0.getYear();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.delete(7, 0);
        timePeriodValues4.setDomainDescription("");
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener8);
        try {
            timePeriodValues4.update((int) (short) 100, (java.lang.Number) 1560495599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.Class<?> wildcardClass2 = year0.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.util.Date date4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date4, timeZone5);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(class8);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date3);
        long long10 = year9.getFirstMillisecond();
        java.lang.String str11 = year9.toString();
        java.util.Calendar calendar12 = null;
        try {
            year9.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865600000L + "'", long10 == 1577865600000L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2020" + "'", str11.equals("2020"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2019);
        timePeriodValues1.fireSeriesChanged();
        java.lang.String str3 = timePeriodValues1.getDomainDescription();
        int int4 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(100L, (long) 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.Class<?> wildcardClass2 = year0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        long long4 = year0.getFirstMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            year0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
        boolean boolean14 = timePeriodValues4.equals((java.lang.Object) year11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) 1593676799999L);
        java.lang.Number number20 = timePeriodValue19.getValue();
        java.lang.Number number21 = timePeriodValue19.getValue();
        timePeriodValues4.add(timePeriodValue19);
        int int23 = timePeriodValues4.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener24);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1.593676799999E12d + "'", number20.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1.593676799999E12d + "'", number21.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        long long3 = year0.getFirstMillisecond();
        long long4 = year0.getLastMillisecond();
        long long5 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 1593676799999L);
        timePeriodValues4.add(timePeriodValue10);
        org.jfree.data.time.TimePeriod timePeriod12 = null;
        try {
            timePeriodValues4.add(timePeriod12, (java.lang.Number) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues4.getMinStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) false);
        java.lang.Object obj11 = timePeriodValues4.clone();
        boolean boolean12 = timePeriodValues4.getNotify();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) '#', (int) (short) 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.Class<?> wildcardClass2 = year0.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.util.Date date4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date4, timeZone5);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year8.next();
        java.util.Date date11 = regularTimePeriod10.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.next();
        java.util.Date date15 = regularTimePeriod14.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date11, date15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date15, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        int int20 = year19.getYear();
        java.lang.Class<?> wildcardClass21 = year19.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        java.util.Date date23 = null;
        java.util.TimeZone timeZone24 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date23, timeZone24);
        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year27.next();
        java.util.Date date30 = regularTimePeriod29.getEnd();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        long long32 = year31.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year31.next();
        java.util.Date date34 = regularTimePeriod33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod(date30, date34);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date34, timeZone36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date15, timeZone36);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        long long40 = year39.getLastMillisecond();
        int int41 = year39.getYear();
        java.util.Date date42 = year39.getStart();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date42);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod(date15, date42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2019 + "'", int41 == 2019);
        org.junit.Assert.assertNotNull(date42);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        try {
            int int11 = simpleTimePeriod8.compareTo((java.lang.Object) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Float cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 8, (long) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 1593676799999L);
        java.lang.Number number5 = timePeriodValue4.getValue();
        java.lang.Object obj6 = timePeriodValue4.clone();
        java.lang.String str7 = timePeriodValue4.toString();
        java.lang.String str8 = timePeriodValue4.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str13 = timePeriodFormatException12.toString();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str19 = timePeriodFormatException18.toString();
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        boolean boolean22 = timePeriodValue4.equals((java.lang.Object) timePeriodFormatException10);
        java.lang.Class<?> wildcardClass23 = timePeriodValue4.getClass();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.593676799999E12d + "'", number5.equals(1.593676799999E12d));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TimePeriodValue[2019,1.593676799999E12]" + "'", str7.equals("TimePeriodValue[2019,1.593676799999E12]"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[2019,1.593676799999E12]" + "'", str8.equals("TimePeriodValue[2019,1.593676799999E12]"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str19.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        long long10 = simpleTimePeriod8.getEndMillis();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str13 = timePeriodFormatException12.toString();
        java.lang.String str14 = timePeriodFormatException12.toString();
        try {
            int int15 = simpleTimePeriod8.compareTo((java.lang.Object) timePeriodFormatException12);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodFormatException cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1609487999999L + "'", long10 == 1609487999999L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod10, "hi!", "");
        int int14 = timePeriodValues13.getMinStartIndex();
        int int15 = timePeriodValues13.getItemCount();
        boolean boolean16 = simpleTimePeriod8.equals((java.lang.Object) timePeriodValues13);
        long long17 = simpleTimePeriod8.getStartMillis();
        java.util.Date date18 = simpleTimePeriod8.getStart();
        try {
            int int20 = simpleTimePeriod8.compareTo((java.lang.Object) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Character cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1609487999999L + "'", long17 == 1609487999999L);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2019);
        timePeriodValues1.fireSeriesChanged();
        java.lang.String str3 = timePeriodValues1.getDomainDescription();
        java.lang.String str4 = timePeriodValues1.getDescription();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100L, "Time", "org.jfree.data.general.SeriesException: hi!");
        int int4 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1577865599999L, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxStartIndex();
        java.lang.Object obj6 = timePeriodValues4.clone();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        timePeriodValues4.setDescription("2019");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
        int int10 = day8.getMonth();
        int int11 = day8.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day8, 0.0d);
        timePeriodValues4.setKey((java.lang.Comparable) day8);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 100, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Object obj8 = timePeriodValues4.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod12, "hi!", "");
        boolean boolean16 = timePeriodValues15.isEmpty();
        int int17 = year9.compareTo((java.lang.Object) boolean16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year9.previous();
        timePeriodValues4.setKey((java.lang.Comparable) year9);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 100.0d);
        java.lang.Object obj22 = seriesChangeEvent21.getSource();
        boolean boolean23 = timePeriodValues4.equals(obj22);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + obj22 + "' != '" + 100.0d + "'", obj22.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod3, "hi!", "");
        boolean boolean7 = timePeriodValues6.isEmpty();
        int int8 = year0.compareTo((java.lang.Object) boolean7);
        long long9 = year0.getLastMillisecond();
        java.util.Date date10 = year0.getStart();
        int int11 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 0.0d);
        timePeriodValue13.setValue((java.lang.Number) 100);
        java.lang.Object obj16 = timePeriodValue13.clone();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        boolean boolean6 = timePeriodValues4.isEmpty();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int8 = year7.getYear();
        long long9 = year7.getLastMillisecond();
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) year7, (-1.0d));
        int int12 = timePeriodValues4.getMinEndIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        java.lang.String str7 = timePeriodValues4.getDescription();
        int int8 = timePeriodValues4.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener11);
        java.lang.Number number14 = null;
        try {
            timePeriodValues4.update(100, number14);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        java.lang.String str7 = timePeriodValues4.getDescription();
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        int int9 = timePeriodValues4.getMinEndIndex();
        timePeriodValues4.setRangeDescription("TimePeriodValue[2019,1.593676799999E12]");
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        int int13 = year12.getYear();
        java.lang.Class<?> wildcardClass14 = year12.getClass();
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date16, timeZone17);
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.next();
        java.util.Date date23 = regularTimePeriod22.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year24.next();
        java.util.Date date27 = regularTimePeriod26.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(date23, date27);
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date27, timeZone29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        long long32 = year31.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year31.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year31, (double) 1593676799999L);
        java.lang.Class<?> wildcardClass36 = year31.getClass();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        long long38 = year37.getLastMillisecond();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year39.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod40, "hi!", "");
        boolean boolean44 = timePeriodValues43.isEmpty();
        int int45 = year37.compareTo((java.lang.Object) boolean44);
        long long46 = year37.getLastMillisecond();
        java.util.Date date47 = year37.getStart();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        long long49 = year48.getLastMillisecond();
        int int50 = year48.getYear();
        java.util.Date date51 = year48.getStart();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date51);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date51);
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date51, timeZone54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date47, timeZone54);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date27, timeZone54);
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) day57, (java.lang.Number) (byte) 1);
        java.lang.Object obj60 = timePeriodValues4.clone();
        int int61 = timePeriodValues4.getMinEndIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1577865599999L + "'", long38 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1577865599999L + "'", long46 == 1577865599999L);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1577865599999L + "'", long49 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2019 + "'", int50 == 2019);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(obj60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        java.lang.String str7 = timePeriodValues4.getDescription();
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod10, "hi!", "");
        boolean boolean14 = timePeriodValues13.isEmpty();
        int int15 = timePeriodValues13.getMaxStartIndex();
        java.lang.String str16 = timePeriodValues13.getDescription();
        java.lang.Object obj17 = timePeriodValues13.clone();
        boolean boolean18 = timePeriodValues4.equals((java.lang.Object) timePeriodValues13);
        int int19 = timePeriodValues4.getMaxEndIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Calendar calendar2 = null;
        try {
            year0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues4.getMinStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) false);
        java.lang.Comparable comparable11 = timePeriodValues4.getKey();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + false + "'", comparable11.equals(false));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Object obj8 = timePeriodValues4.clone();
        boolean boolean9 = timePeriodValues4.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues4.createCopy((int) (byte) -1, (int) '#');
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue14 = timePeriodValues12.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(timePeriodValues12);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        long long4 = year0.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        timePeriodValues4.setDescription("2019");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year8.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) 1593676799999L);
        java.lang.Number number13 = timePeriodValue12.getValue();
        java.lang.String str14 = timePeriodValue12.toString();
        timePeriodValues4.add(timePeriodValue12);
        timePeriodValues4.setRangeDescription("Time");
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1.593676799999E12d + "'", number13.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TimePeriodValue[2019,1.593676799999E12]" + "'", str14.equals("TimePeriodValue[2019,1.593676799999E12]"));
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        long long5 = day0.getSerialIndex();
//        long long6 = day0.getFirstMillisecond();
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod8, "hi!", "");
//        boolean boolean12 = timePeriodValues11.isEmpty();
//        int int13 = timePeriodValues11.getMaxStartIndex();
//        timePeriodValues11.setKey((java.lang.Comparable) 1577865599999L);
//        timePeriodValues11.setDescription("");
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        long long19 = year18.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.next();
//        boolean boolean21 = timePeriodValues11.equals((java.lang.Object) year18);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        long long23 = year22.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year22.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (double) 1593676799999L);
//        java.lang.Number number27 = timePeriodValue26.getValue();
//        java.lang.Number number28 = timePeriodValue26.getValue();
//        timePeriodValues11.add(timePeriodValue26);
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
//        int int31 = year30.getYear();
//        java.lang.Class<?> wildcardClass32 = year30.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year30.previous();
//        timePeriodValues11.setKey((java.lang.Comparable) regularTimePeriod33);
//        boolean boolean35 = day0.equals((java.lang.Object) regularTimePeriod33);
//        java.util.Date date36 = regularTimePeriod33.getStart();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 1.593676799999E12d + "'", number27.equals(1.593676799999E12d));
//        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 1.593676799999E12d + "'", number28.equals(1.593676799999E12d));
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(date36);
//    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        long long5 = day0.getSerialIndex();
//        long long6 = day0.getFirstMillisecond();
//        java.util.Date date7 = day0.getEnd();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        int int9 = year8.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) (short) 0);
//        int int12 = day0.compareTo((java.lang.Object) year8);
//        long long13 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560409200000L + "'", long13 == 1560409200000L);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        int int2 = year0.getYear();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        long long5 = day0.getSerialIndex();
//        long long6 = day0.getFirstMillisecond();
//        java.util.Date date7 = day0.getEnd();
//        java.lang.Object obj8 = null;
//        boolean boolean9 = day0.equals(obj8);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        java.util.Date date10 = simpleTimePeriod8.getEnd();
        long long11 = simpleTimePeriod8.getEndMillis();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1609487999999L + "'", long11 == 1609487999999L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.Class<?> wildcardClass2 = year0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        long long4 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date3);
        long long10 = year9.getFirstMillisecond();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year9.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865600000L + "'", long10 == 1577865600000L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Object obj8 = timePeriodValues4.clone();
        timePeriodValues4.setDomainDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues4.createCopy(10, (int) (byte) 0);
        int int14 = timePeriodValues4.getMaxStartIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
        boolean boolean14 = timePeriodValues4.equals((java.lang.Object) year11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) 1593676799999L);
        java.lang.Number number20 = timePeriodValue19.getValue();
        java.lang.Number number21 = timePeriodValue19.getValue();
        timePeriodValues4.add(timePeriodValue19);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        int int24 = year23.getYear();
        java.lang.Class<?> wildcardClass25 = year23.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year23.previous();
        timePeriodValues4.setKey((java.lang.Comparable) regularTimePeriod26);
        java.lang.Comparable comparable28 = timePeriodValues4.getKey();
        timePeriodValues4.setRangeDescription("Time");
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1.593676799999E12d + "'", number20.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1.593676799999E12d + "'", number21.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(comparable28);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date3);
        long long10 = year9.getFirstMillisecond();
        java.lang.String str11 = year9.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (short) 1);
        timePeriodValue13.setValue((java.lang.Number) 0.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865600000L + "'", long10 == 1577865600000L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2020" + "'", str11.equals("2020"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        java.util.Calendar calendar3 = null;
        try {
            year0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("TimePeriodValue[2019,0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 100, (long) (short) 100);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        long long4 = day0.getFirstMillisecond();
//        int int5 = day0.getMonth();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        timePeriodValues4.setDescription("2019");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues4.getMaxEndIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date3);
        long long10 = year9.getFirstMillisecond();
        java.lang.String str11 = year9.toString();
        java.util.Date date12 = year9.getStart();
        java.lang.Object obj13 = null;
        int int14 = year9.compareTo(obj13);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865600000L + "'", long10 == 1577865600000L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2020" + "'", str11.equals("2020"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues4.getMinStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) false);
        java.lang.Object obj11 = timePeriodValues4.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues4.removeChangeListener(seriesChangeListener12);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        try {
            timePeriodValues4.delete((int) (short) 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 1593676799999L);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod6, "hi!", "");
        boolean boolean10 = timePeriodValues9.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener11);
        java.lang.Object obj13 = timePeriodValues9.clone();
        boolean boolean14 = timePeriodValues9.getNotify();
        boolean boolean15 = timePeriodValue4.equals((java.lang.Object) timePeriodValues9);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int2 = day0.getMonth();
        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) serialDate3, "org.jfree.data.general.SeriesException: hi!", "TimePeriodValue[2019,0]");
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod3, "hi!", "");
        boolean boolean7 = timePeriodValues6.isEmpty();
        int int8 = year0.compareTo((java.lang.Object) boolean7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "2019", "2019");
        java.lang.String str13 = timePeriodValues12.getDescription();
        timePeriodValues12.setKey((java.lang.Comparable) true);
        int int16 = timePeriodValues12.getMaxMiddleIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod18 = timePeriodValues12.getTimePeriod(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        java.lang.Object obj3 = null;
        boolean boolean4 = timePeriodValues2.equals(obj3);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.next();
        java.util.Date date9 = regularTimePeriod8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date9, date13);
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (double) (byte) 1);
        timePeriodValues4.delete(2019, (int) (byte) 10);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        boolean boolean6 = timePeriodValues4.isEmpty();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int8 = year7.getYear();
        long long9 = year7.getLastMillisecond();
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) year7, (-1.0d));
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues4.removeChangeListener(seriesChangeListener12);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        java.lang.String str7 = timePeriodValues4.getDescription();
        boolean boolean8 = timePeriodValues4.isEmpty();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue10 = timePeriodValues4.getDataItem(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        java.lang.String str4 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        long long4 = day0.getFirstMillisecond();
//        long long5 = day0.getSerialIndex();
//        java.util.Date date6 = day0.getEnd();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        java.util.Date date10 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        long long12 = year11.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2020L + "'", long12 == 2020L);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        boolean boolean10 = simpleTimePeriod8.equals((java.lang.Object) 12);
        long long11 = simpleTimePeriod8.getStartMillis();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1609487999999L + "'", long11 == 1609487999999L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException3.getSuppressed();
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray9 = seriesException8.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) seriesException8);
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("");
        seriesException15.addSuppressed((java.lang.Throwable) seriesException17);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) seriesException17);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 1593676799999L);
        java.lang.Number number5 = timePeriodValue4.getValue();
        java.lang.Object obj6 = timePeriodValue4.clone();
        java.lang.String str7 = timePeriodValue4.toString();
        java.lang.String str8 = timePeriodValue4.toString();
        timePeriodValue4.setValue((java.lang.Number) 2019L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.593676799999E12d + "'", number5.equals(1.593676799999E12d));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TimePeriodValue[2019,1.593676799999E12]" + "'", str7.equals("TimePeriodValue[2019,1.593676799999E12]"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[2019,1.593676799999E12]" + "'", str8.equals("TimePeriodValue[2019,1.593676799999E12]"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
        boolean boolean14 = timePeriodValues4.equals((java.lang.Object) year11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues4.removeChangeListener(seriesChangeListener15);
        int int17 = timePeriodValues4.getMaxMiddleIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues4.getMinStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener11);
        java.lang.String str13 = timePeriodValues4.getDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(str13);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        java.util.Calendar calendar4 = null;
//        try {
//            day0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesChangeEvent[source=1577865600000]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        int int6 = timePeriodValues4.getItemCount();
        java.lang.String str7 = timePeriodValues4.getDescription();
        timePeriodValues4.fireSeriesChanged();
        boolean boolean9 = timePeriodValues4.getNotify();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        long long5 = day0.getSerialIndex();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1560495599999L);
//        java.lang.String str8 = timePeriodValue7.toString();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,1.560495599999E12]" + "'", str8.equals("TimePeriodValue[13-June-2019,1.560495599999E12]"));
//    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        long long5 = day0.getSerialIndex();
//        long long6 = day0.getFirstMillisecond();
//        java.util.Date date7 = day0.getEnd();
//        long long8 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43629L + "'", long8 == 43629L);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        boolean boolean6 = timePeriodValues4.isEmpty();
        java.lang.String str7 = timePeriodValues4.getDomainDescription();
        timePeriodValues4.setDomainDescription("TimePeriodValue[2019,0]");
        try {
            java.lang.Number number11 = timePeriodValues4.getValue((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        int int4 = year3.getYear();
//        boolean boolean5 = day0.equals((java.lang.Object) int4);
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
//        long long8 = day7.getSerialIndex();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43629L + "'", long8 == 43629L);
//    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        long long5 = day0.getSerialIndex();
//        long long6 = day0.getFirstMillisecond();
//        java.util.Date date7 = day0.getEnd();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        int int9 = year8.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) (short) 0);
//        int int12 = day0.compareTo((java.lang.Object) year8);
//        int int13 = day0.getYear();
//        long long14 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod3, "hi!", "");
        boolean boolean7 = timePeriodValues6.isEmpty();
        int int8 = year0.compareTo((java.lang.Object) boolean7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year0.previous();
        int int11 = year0.compareTo((java.lang.Object) 1560495599999L);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = year0.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Object obj8 = timePeriodValues4.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod12, "hi!", "");
        boolean boolean16 = timePeriodValues15.isEmpty();
        int int17 = year9.compareTo((java.lang.Object) boolean16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year9.previous();
        timePeriodValues4.setKey((java.lang.Comparable) year9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timePeriodValues4.removeChangeListener(seriesChangeListener20);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Object obj8 = timePeriodValues4.clone();
        boolean boolean9 = timePeriodValues4.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues4.createCopy((int) (byte) -1, (int) '#');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues12.addChangeListener(seriesChangeListener13);
        int int15 = timePeriodValues12.getMinEndIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        long long10 = simpleTimePeriod8.getEndMillis();
        long long11 = simpleTimePeriod8.getStartMillis();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod13, "hi!", "");
        int int17 = timePeriodValues16.getMaxEndIndex();
        timePeriodValues16.setDescription("2019");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year20, (double) 1593676799999L);
        java.lang.Number number25 = timePeriodValue24.getValue();
        java.lang.String str26 = timePeriodValue24.toString();
        timePeriodValues16.add(timePeriodValue24);
        int int28 = timePeriodValues16.getItemCount();
        java.lang.String str29 = timePeriodValues16.getRangeDescription();
        java.lang.Comparable comparable30 = timePeriodValues16.getKey();
        boolean boolean31 = simpleTimePeriod8.equals((java.lang.Object) comparable30);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1609487999999L + "'", long10 == 1609487999999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1609487999999L + "'", long11 == 1609487999999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 1.593676799999E12d + "'", number25.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "TimePeriodValue[2019,1.593676799999E12]" + "'", str26.equals("TimePeriodValue[2019,1.593676799999E12]"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(comparable30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.lang.String str6 = timePeriodValues4.getDomainDescription();
        boolean boolean7 = timePeriodValues4.isEmpty();
        java.lang.Object obj8 = timePeriodValues4.clone();
        timePeriodValues4.setRangeDescription("");
        boolean boolean11 = timePeriodValues4.getNotify();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue13 = timePeriodValues4.getDataItem(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100L, "Time", "org.jfree.data.general.SeriesException: hi!");
        timePeriodValues3.fireSeriesChanged();
        try {
            org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValues3.getTimePeriod((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        int int7 = year6.getYear();
        java.lang.Class<?> wildcardClass8 = year6.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.previous();
        boolean boolean10 = timePeriodValues4.equals((java.lang.Object) regularTimePeriod9);
        try {
            timePeriodValues4.update(2019, (java.lang.Number) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date3);
        long long10 = year9.getFirstMillisecond();
        java.lang.String str11 = year9.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (short) 1);
        long long14 = year9.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865600000L + "'", long10 == 1577865600000L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2020" + "'", str11.equals("2020"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1593676799999L + "'", long14 == 1593676799999L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues4.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timePeriodValues4.getDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod3, "hi!", "");
        boolean boolean7 = timePeriodValues6.isEmpty();
        int int8 = year0.compareTo((java.lang.Object) boolean7);
        long long9 = year0.getLastMillisecond();
        java.util.Date date10 = year0.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        java.lang.Object obj12 = null;
        boolean boolean13 = year11.equals(obj12);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("TimePeriodValue[2019,1.593676799999E12]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.Class<?> wildcardClass2 = year0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = regularTimePeriod4.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        int int4 = year3.getYear();
//        boolean boolean5 = day0.equals((java.lang.Object) int4);
//        int int6 = day0.getYear();
//        int int7 = day0.getDayOfMonth();
//        int int8 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.Class<?> wildcardClass2 = year0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        long long4 = year0.getFirstMillisecond();
        int int5 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod3, "hi!", "");
        boolean boolean7 = timePeriodValues6.isEmpty();
        int int8 = timePeriodValues6.getMinEndIndex();
        boolean boolean9 = year0.equals((java.lang.Object) int8);
        int int11 = year0.compareTo((java.lang.Object) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        java.util.Date date10 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.next();
        java.util.Date date9 = regularTimePeriod8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date9, date13);
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (double) (byte) 1);
        long long18 = simpleTimePeriod14.getEndMillis();
        java.util.Date date19 = simpleTimePeriod14.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1609487999999L + "'", long18 == 1609487999999L);
        org.junit.Assert.assertNotNull(date19);
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        int int2 = day0.getYear();
//        long long3 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test259");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        long long4 = day0.getFirstMillisecond();
//        long long5 = day0.getSerialIndex();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getMiddleMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod3, "hi!", "");
        boolean boolean7 = timePeriodValues6.isEmpty();
        int int8 = year0.compareTo((java.lang.Object) boolean7);
        long long9 = year0.getLastMillisecond();
        java.util.Date date10 = year0.getStart();
        int int11 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        java.lang.String str7 = timePeriodValues4.getDescription();
        int int8 = timePeriodValues4.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener9);
        timePeriodValues4.setNotify(true);
        int int13 = timePeriodValues4.getMaxStartIndex();
        int int14 = timePeriodValues4.getItemCount();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.Class<?> wildcardClass2 = year0.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.util.Date date4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date4, timeZone5);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year8.next();
        java.util.Date date11 = regularTimePeriod10.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.next();
        java.util.Date date15 = regularTimePeriod14.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date11, date15);
        java.util.Date date17 = simpleTimePeriod16.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        int int19 = year18.getYear();
        java.lang.Class<?> wildcardClass20 = year18.getClass();
        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date22, timeZone23);
        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        long long27 = year26.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year26.next();
        java.util.Date date29 = regularTimePeriod28.getEnd();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        long long31 = year30.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year30.next();
        java.util.Date date33 = regularTimePeriod32.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod34 = new org.jfree.data.time.SimpleTimePeriod(date29, date33);
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date33, timeZone35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date17, timeZone35);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        long long4 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getFirstMillisecond();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate4);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues4.getMinEndIndex();
        int int11 = timePeriodValues4.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues4.removeChangeListener(seriesChangeListener12);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        int int7 = year6.getYear();
        java.lang.Class<?> wildcardClass8 = year6.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.previous();
        boolean boolean10 = timePeriodValues4.equals((java.lang.Object) regularTimePeriod9);
        timePeriodValues4.fireSeriesChanged();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.String str3 = seriesException1.toString();
        java.lang.Throwable[] throwableArray4 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray4);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getMonth();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        java.lang.String str7 = timePeriodValues4.getDescription();
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        int int9 = timePeriodValues4.getMinEndIndex();
        timePeriodValues4.setRangeDescription("TimePeriodValue[2019,1.593676799999E12]");
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        int int13 = year12.getYear();
        java.lang.Class<?> wildcardClass14 = year12.getClass();
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date16, timeZone17);
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.next();
        java.util.Date date23 = regularTimePeriod22.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year24.next();
        java.util.Date date27 = regularTimePeriod26.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(date23, date27);
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date27, timeZone29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        long long32 = year31.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year31.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year31, (double) 1593676799999L);
        java.lang.Class<?> wildcardClass36 = year31.getClass();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        long long38 = year37.getLastMillisecond();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year39.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod40, "hi!", "");
        boolean boolean44 = timePeriodValues43.isEmpty();
        int int45 = year37.compareTo((java.lang.Object) boolean44);
        long long46 = year37.getLastMillisecond();
        java.util.Date date47 = year37.getStart();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        long long49 = year48.getLastMillisecond();
        int int50 = year48.getYear();
        java.util.Date date51 = year48.getStart();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date51);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date51);
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date51, timeZone54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date47, timeZone54);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date27, timeZone54);
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) day57, (java.lang.Number) (byte) 1);
        java.lang.Object obj60 = timePeriodValues4.clone();
        int int61 = timePeriodValues4.getMaxMiddleIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1577865599999L + "'", long38 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1577865599999L + "'", long46 == 1577865599999L);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1577865599999L + "'", long49 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2019 + "'", int50 == 2019);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(obj60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        java.lang.String str7 = timePeriodValues4.getDescription();
        java.lang.Object obj8 = timePeriodValues4.clone();
        timePeriodValues4.setNotify(true);
        timePeriodValues4.setNotify(true);
        try {
            java.lang.Number number14 = timePeriodValues4.getValue((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        timePeriodValues4.setDescription("2019");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year8.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) 1593676799999L);
        java.lang.Number number13 = timePeriodValue12.getValue();
        java.lang.String str14 = timePeriodValue12.toString();
        timePeriodValues4.add(timePeriodValue12);
        boolean boolean16 = timePeriodValues4.getNotify();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1.593676799999E12d + "'", number13.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TimePeriodValue[2019,1.593676799999E12]" + "'", str14.equals("TimePeriodValue[2019,1.593676799999E12]"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        int int2 = year0.getYear();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) 10.0f);
        int int7 = year4.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
        boolean boolean14 = timePeriodValues4.equals((java.lang.Object) year11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues4.removeChangeListener(seriesChangeListener15);
        timePeriodValues4.setDomainDescription("");
        boolean boolean19 = timePeriodValues4.isEmpty();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test274");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        long long4 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        long long6 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        timePeriodValues4.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener8);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues(comparable0, "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.general.SeriesChangeEvent[source=1577865600000]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 1593676799999L);
        timePeriodValues4.add(timePeriodValue10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues4.removeChangeListener(seriesChangeListener12);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int2 = day0.getMonth();
        java.util.Date date3 = day0.getStart();
        java.util.Calendar calendar4 = null;
        try {
            day0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        boolean boolean11 = simpleTimePeriod8.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (double) 1593676799999L);
        try {
            int int17 = simpleTimePeriod8.compareTo((java.lang.Object) timePeriodValue16);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValue cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int2 = day0.getMonth();
        java.util.Date date3 = day0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        int int2 = year0.getYear();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year5.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.Class<?> wildcardClass2 = year0.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.util.Date date4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date4, timeZone5);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year8.next();
        java.util.Date date11 = regularTimePeriod10.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.next();
        java.util.Date date15 = regularTimePeriod14.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date11, date15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date15, timeZone17);
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize(class7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(class19);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date3);
        long long10 = year9.getFirstMillisecond();
        java.lang.String str11 = year9.toString();
        java.util.Date date12 = year9.getStart();
        java.util.Date date13 = year9.getEnd();
        java.util.Date date14 = year9.getStart();
        java.util.Date date15 = year9.getStart();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865600000L + "'", long10 == 1577865600000L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2020" + "'", str11.equals("2020"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        int int6 = timePeriodValues4.getItemCount();
        int int7 = timePeriodValues4.getMaxStartIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMinEndIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue8 = timePeriodValues4.getDataItem((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(4, 9, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        long long3 = year0.getFirstMillisecond();
        long long4 = year0.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        int int2 = day0.getYear();
        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.delete(7, 0);
        int int12 = timePeriodValues4.getMinMiddleIndex();
        timePeriodValues4.fireSeriesChanged();
        timePeriodValues4.setRangeDescription("2019");
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
//        boolean boolean5 = timePeriodValues4.isEmpty();
//        java.lang.String str6 = timePeriodValues4.getDomainDescription();
//        boolean boolean7 = timePeriodValues4.isEmpty();
//        java.lang.Object obj8 = timePeriodValues4.clone();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timePeriodValues4.removeChangeListener(seriesChangeListener9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
//        long long13 = day11.getLastMillisecond();
//        long long14 = day11.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate15 = day11.getSerialDate();
//        boolean boolean16 = timePeriodValues4.equals((java.lang.Object) serialDate15);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 1560495599999L);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getFirstMillisecond();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        int int6 = year5.getYear();
//        java.lang.Class<?> wildcardClass7 = year5.getClass();
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        java.util.Date date9 = null;
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date9, timeZone10);
//        boolean boolean12 = day0.equals((java.lang.Object) timeZone10);
//        org.jfree.data.time.SerialDate serialDate13 = day0.getSerialDate();
//        long long14 = day0.getFirstMillisecond();
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = day0.getLastMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2019);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        int int3 = year2.getYear();
        java.lang.Class<?> wildcardClass4 = year2.getClass();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year2, (double) 2019);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
        java.lang.String str8 = seriesChangeEvent7.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues4.getMinEndIndex();
        java.lang.String str11 = timePeriodValues4.getDomainDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 1593676799999L);
        java.lang.String str5 = timePeriodValue4.toString();
        org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValue4.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue4.getPeriod();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TimePeriodValue[2019,1.593676799999E12]" + "'", str5.equals("TimePeriodValue[2019,1.593676799999E12]"));
        org.junit.Assert.assertNotNull(timePeriod6);
        org.junit.Assert.assertNotNull(timePeriod7);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 1593676799999L);
        java.lang.Number number5 = timePeriodValue4.getValue();
        java.lang.Number number6 = timePeriodValue4.getValue();
        java.lang.String str7 = timePeriodValue4.toString();
        java.lang.Object obj8 = timePeriodValue4.clone();
        java.lang.String str9 = timePeriodValue4.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.593676799999E12d + "'", number5.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.593676799999E12d + "'", number6.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TimePeriodValue[2019,1.593676799999E12]" + "'", str7.equals("TimePeriodValue[2019,1.593676799999E12]"));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TimePeriodValue[2019,1.593676799999E12]" + "'", str9.equals("TimePeriodValue[2019,1.593676799999E12]"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues4.getItemCount();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod12, "hi!", "");
        boolean boolean16 = timePeriodValues15.isEmpty();
        int int17 = year9.compareTo((java.lang.Object) boolean16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year9.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year9.previous();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int21 = year20.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year20, (double) (short) 0);
        java.util.Date date24 = year20.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year20.previous();
        int int26 = year9.compareTo((java.lang.Object) regularTimePeriod25);
        int int27 = year9.getYear();
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) year9, (java.lang.Number) 8);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        timePeriodValues4.delete((int) ' ', 0);
        int int9 = timePeriodValues4.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener10);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "org.jfree.data.general.SeriesChangeEvent[source=0]", "13-June-2019", "13-June-2019");
        timePeriodValues3.setRangeDescription("2020");
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str6 = timePeriodFormatException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
//        java.util.Date date3 = regularTimePeriod2.getEnd();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        long long5 = year4.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
//        java.util.Date date7 = regularTimePeriod6.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        int int10 = year9.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (short) 0);
//        java.util.Date date13 = year9.getEnd();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        long long15 = year14.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 1593676799999L);
//        java.lang.Class<?> wildcardClass19 = year14.getClass();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        long long21 = year20.getLastMillisecond();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod23, "hi!", "");
//        boolean boolean27 = timePeriodValues26.isEmpty();
//        int int28 = year20.compareTo((java.lang.Object) boolean27);
//        long long29 = year20.getLastMillisecond();
//        java.util.Date date30 = year20.getStart();
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        long long32 = year31.getLastMillisecond();
//        int int33 = year31.getYear();
//        java.util.Date date34 = year31.getStart();
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date34);
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date34);
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date34, timeZone37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date30, timeZone37);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
//        int int41 = year40.getYear();
//        java.lang.Class<?> wildcardClass42 = year40.getClass();
//        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
//        java.util.Date date44 = null;
//        java.util.TimeZone timeZone45 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date44, timeZone45);
//        java.lang.Class class47 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
//        long long49 = year48.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year48.next();
//        java.util.Date date51 = regularTimePeriod50.getEnd();
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
//        long long53 = year52.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year52.next();
//        java.util.Date date55 = regularTimePeriod54.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod56 = new org.jfree.data.time.SimpleTimePeriod(date51, date55);
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date55, timeZone57);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date30, timeZone57);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date13, timeZone57);
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date3, timeZone57);
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate63 = day62.getSerialDate();
//        long long64 = day62.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate65 = day62.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = day62.next();
//        long long67 = day62.getSerialIndex();
//        int int68 = day61.compareTo((java.lang.Object) day62);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2019 + "'", int41 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(class47);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1577865599999L + "'", long49 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1577865599999L + "'", long53 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(serialDate63);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560409200000L + "'", long64 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate65);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 43629L + "'", long67 == 43629L);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 567 + "'", int68 == 567);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2019);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        int int3 = year2.getYear();
        java.lang.Class<?> wildcardClass4 = year2.getClass();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year2, (double) 2019);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        boolean boolean12 = year7.equals((java.lang.Object) "2019");
        int int13 = year2.compareTo((java.lang.Object) "2019");
        java.util.Calendar calendar14 = null;
        try {
            long long15 = year2.getMiddleMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod3, "hi!", "");
        boolean boolean7 = timePeriodValues6.isEmpty();
        int int8 = year0.compareTo((java.lang.Object) boolean7);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) boolean7, "2019", "hi!");
        int int12 = timePeriodValues11.getMaxStartIndex();
        boolean boolean13 = timePeriodValues11.getNotify();
        java.lang.String str14 = timePeriodValues11.getDescription();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        boolean boolean11 = simpleTimePeriod8.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        java.util.Date date12 = simpleTimePeriod8.getEnd();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 1593676799999L);
        timePeriodValues4.add(timePeriodValue10);
        java.lang.String str12 = timePeriodValues4.getDescription();
        int int13 = timePeriodValues4.getMinStartIndex();
        boolean boolean14 = timePeriodValues4.getNotify();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues4.getItemCount();
        int int9 = timePeriodValues4.getItemCount();
        int int10 = timePeriodValues4.getMaxMiddleIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[2019,1.593676799999E12]");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str7 = timePeriodFormatException6.toString();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray12 = seriesException11.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException11.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.String str16 = timePeriodFormatException14.toString();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.Class<?> wildcardClass18 = timePeriodFormatException4.getClass();
        org.jfree.data.general.SeriesException seriesException20 = new org.jfree.data.general.SeriesException("TimePeriodValue[2019,1.593676799999E12]");
        java.lang.Throwable[] throwableArray21 = seriesException20.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str26 = timePeriodFormatException25.toString();
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        seriesException20.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        org.jfree.data.general.SeriesException seriesException30 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray31 = seriesException30.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException30.addSuppressed((java.lang.Throwable) timePeriodFormatException33);
        java.lang.String str35 = timePeriodFormatException33.toString();
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException33);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException33);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str26.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str35.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 0);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) 1593676799999L);
        java.lang.Number number9 = timePeriodValue8.getValue();
        java.lang.String str10 = timePeriodValue8.toString();
        java.lang.Object obj11 = timePeriodValue8.clone();
        boolean boolean12 = timePeriodValue3.equals((java.lang.Object) timePeriodValue8);
        java.lang.String str13 = timePeriodValue3.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1.593676799999E12d + "'", number9.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,1.593676799999E12]" + "'", str10.equals("TimePeriodValue[2019,1.593676799999E12]"));
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TimePeriodValue[2019,0]" + "'", str13.equals("TimePeriodValue[2019,0]"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.setDescription("");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue12 = timePeriodValues4.getDataItem(567);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 567, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.Class<?> wildcardClass2 = year0.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.util.Date date4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date4, timeZone5);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year8.next();
        java.util.Date date11 = regularTimePeriod10.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.next();
        java.util.Date date15 = regularTimePeriod14.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date11, date15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date15, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        int int20 = year19.getYear();
        java.lang.Class<?> wildcardClass21 = year19.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        java.util.Date date23 = null;
        java.util.TimeZone timeZone24 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date23, timeZone24);
        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year27.next();
        java.util.Date date30 = regularTimePeriod29.getEnd();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        long long32 = year31.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year31.next();
        java.util.Date date34 = regularTimePeriod33.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod(date30, date34);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date34, timeZone36);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        int int39 = year38.getYear();
        java.lang.Class<?> wildcardClass40 = year38.getClass();
        java.lang.Class class41 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass40);
        java.util.Date date42 = null;
        java.util.TimeZone timeZone43 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date42, timeZone43);
        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass40);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        long long47 = year46.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year46.next();
        java.util.Date date49 = regularTimePeriod48.getEnd();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        long long51 = year50.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.next();
        java.util.Date date53 = regularTimePeriod52.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod(date49, date53);
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date53, timeZone55);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date34, timeZone55);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date15, timeZone55);
        long long59 = day58.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(class41);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(class45);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1577865599999L + "'", long47 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1577865599999L + "'", long51 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1609487999999L + "'", long59 == 1609487999999L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 8);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
        boolean boolean14 = timePeriodValues4.equals((java.lang.Object) year11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) 1593676799999L);
        java.lang.Number number20 = timePeriodValue19.getValue();
        java.lang.Number number21 = timePeriodValue19.getValue();
        timePeriodValues4.add(timePeriodValue19);
        int int23 = timePeriodValues4.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timePeriodValues4.removeChangeListener(seriesChangeListener24);
        timePeriodValues4.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1.593676799999E12d + "'", number20.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1.593676799999E12d + "'", number21.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        timePeriodValues4.setDescription("2019");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener8);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test315");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate2 = day1.getSerialDate();
//        long long3 = day1.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day1.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day1.next();
//        long long6 = day1.getSerialIndex();
//        long long7 = day1.getFirstMillisecond();
//        java.util.Date date8 = day1.getEnd();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        int int10 = year9.getYear();
//        java.lang.Class<?> wildcardClass11 = year9.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year9.previous();
//        java.util.Date date13 = regularTimePeriod12.getStart();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        long long15 = year14.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 1593676799999L);
//        java.lang.Class<?> wildcardClass19 = year14.getClass();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        long long21 = year20.getLastMillisecond();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod23, "hi!", "");
//        boolean boolean27 = timePeriodValues26.isEmpty();
//        int int28 = year20.compareTo((java.lang.Object) boolean27);
//        long long29 = year20.getLastMillisecond();
//        java.util.Date date30 = year20.getStart();
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        long long32 = year31.getLastMillisecond();
//        int int33 = year31.getYear();
//        java.util.Date date34 = year31.getStart();
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date34);
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date34);
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date34, timeZone37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date30, timeZone37);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date13, timeZone37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone37);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560409200000L + "'", long7 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=0]");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=0]" + "'", str2.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=0]"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.Class<?> wildcardClass2 = year0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        java.util.Date date4 = regularTimePeriod3.getStart();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date3);
        long long10 = year9.getFirstMillisecond();
        java.lang.String str11 = year9.toString();
        java.util.Date date12 = year9.getStart();
        long long13 = year9.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865600000L + "'", long10 == 1577865600000L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2020" + "'", str11.equals("2020"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2020L + "'", long13 == 2020L);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str10 = timePeriodFormatException9.toString();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("Time");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException14);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod3, "hi!", "");
        boolean boolean7 = timePeriodValues6.isEmpty();
        int int8 = year0.compareTo((java.lang.Object) boolean7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year0.previous();
        java.util.Calendar calendar11 = null;
        try {
            year0.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        int int2 = year0.getYear();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod4, "hi!", "");
        int int8 = timePeriodValues7.getMaxEndIndex();
        boolean boolean9 = timePeriodValues7.isEmpty();
        int int10 = year0.compareTo((java.lang.Object) boolean9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod14, "hi!", "");
        boolean boolean18 = timePeriodValues17.isEmpty();
        int int19 = year11.compareTo((java.lang.Object) boolean18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year11.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year11.previous();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int23 = year22.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (double) (short) 0);
        java.util.Date date26 = year22.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year22.previous();
        int int28 = year11.compareTo((java.lang.Object) regularTimePeriod27);
        int int29 = year0.compareTo((java.lang.Object) int28);
        java.lang.Class<?> wildcardClass30 = year0.getClass();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(wildcardClass30);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        long long8 = year5.getFirstMillisecond();
        boolean boolean9 = timePeriodValues4.equals((java.lang.Object) long8);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.lang.String str6 = timePeriodValues4.getDomainDescription();
        boolean boolean7 = timePeriodValues4.isEmpty();
        java.lang.Object obj8 = timePeriodValues4.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues4.removeChangeListener(seriesChangeListener9);
        boolean boolean11 = timePeriodValues4.getNotify();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        java.lang.String str7 = timePeriodValues4.getDescription();
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        int int9 = timePeriodValues4.getMinEndIndex();
        timePeriodValues4.setRangeDescription("TimePeriodValue[2019,1.593676799999E12]");
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        int int13 = year12.getYear();
        java.lang.Class<?> wildcardClass14 = year12.getClass();
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date16, timeZone17);
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.next();
        java.util.Date date23 = regularTimePeriod22.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year24.next();
        java.util.Date date27 = regularTimePeriod26.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(date23, date27);
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date27, timeZone29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        long long32 = year31.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year31.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year31, (double) 1593676799999L);
        java.lang.Class<?> wildcardClass36 = year31.getClass();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        long long38 = year37.getLastMillisecond();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year39.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod40, "hi!", "");
        boolean boolean44 = timePeriodValues43.isEmpty();
        int int45 = year37.compareTo((java.lang.Object) boolean44);
        long long46 = year37.getLastMillisecond();
        java.util.Date date47 = year37.getStart();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        long long49 = year48.getLastMillisecond();
        int int50 = year48.getYear();
        java.util.Date date51 = year48.getStart();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date51);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date51);
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date51, timeZone54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date47, timeZone54);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date27, timeZone54);
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) day57, (java.lang.Number) (byte) 1);
        timePeriodValues4.update(0, (java.lang.Number) 8);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1577865599999L + "'", long38 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1577865599999L + "'", long46 == 1577865599999L);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1577865599999L + "'", long49 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2019 + "'", int50 == 2019);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        java.lang.Comparable comparable9 = timePeriodValues4.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues4.removeChangeListener(seriesChangeListener10);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 1577865599999L + "'", comparable9.equals(1577865599999L));
    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test326");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
//        int int5 = timePeriodValues4.getMinStartIndex();
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener6);
//        int int8 = timePeriodValues4.getItemCount();
//        int int9 = timePeriodValues4.getItemCount();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
//        long long12 = day10.getLastMillisecond();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        int int14 = year13.getYear();
//        boolean boolean15 = day10.equals((java.lang.Object) int14);
//        org.jfree.data.time.SerialDate serialDate16 = day10.getSerialDate();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
//        timePeriodValues4.setKey((java.lang.Comparable) serialDate16);
//        java.lang.String str19 = timePeriodValues4.getDescription();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560495599999L + "'", long12 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNull(str19);
//    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod3, "hi!", "");
        boolean boolean7 = timePeriodValues6.isEmpty();
        int int8 = year0.compareTo((java.lang.Object) boolean7);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) boolean7, "2019", "hi!");
        boolean boolean12 = timePeriodValues11.getNotify();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
        boolean boolean14 = timePeriodValues4.equals((java.lang.Object) year11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) 1593676799999L);
        java.lang.Number number20 = timePeriodValue19.getValue();
        java.lang.Number number21 = timePeriodValue19.getValue();
        timePeriodValues4.add(timePeriodValue19);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        int int24 = year23.getYear();
        java.lang.Class<?> wildcardClass25 = year23.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year23.previous();
        timePeriodValues4.setKey((java.lang.Comparable) regularTimePeriod26);
        java.lang.Comparable comparable28 = timePeriodValues4.getKey();
        try {
            org.jfree.data.time.TimePeriod timePeriod30 = timePeriodValues4.getTimePeriod((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1.593676799999E12d + "'", number20.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1.593676799999E12d + "'", number21.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(comparable28);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
        boolean boolean14 = timePeriodValues4.equals((java.lang.Object) year11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) 1593676799999L);
        java.lang.Number number20 = timePeriodValue19.getValue();
        java.lang.Number number21 = timePeriodValue19.getValue();
        timePeriodValues4.add(timePeriodValue19);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        int int24 = year23.getYear();
        java.lang.Class<?> wildcardClass25 = year23.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year23.previous();
        timePeriodValues4.setKey((java.lang.Comparable) regularTimePeriod26);
        java.lang.Class<?> wildcardClass28 = timePeriodValues4.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1.593676799999E12d + "'", number20.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1.593676799999E12d + "'", number21.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(wildcardClass28);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener6);
        try {
            java.lang.Number number9 = timePeriodValues4.getValue((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (short) 0);
        java.lang.Object obj4 = timePeriodValue3.clone();
        timePeriodValue3.setValue((java.lang.Number) 0);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod8, "hi!", "");
        boolean boolean12 = timePeriodValues11.isEmpty();
        int int13 = timePeriodValues11.getMaxStartIndex();
        timePeriodValues11.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues11.setDescription("");
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.next();
        boolean boolean21 = timePeriodValues11.equals((java.lang.Object) year18);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year22.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (double) 1593676799999L);
        java.lang.Number number27 = timePeriodValue26.getValue();
        java.lang.Number number28 = timePeriodValue26.getValue();
        timePeriodValues11.add(timePeriodValue26);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        int int31 = year30.getYear();
        java.lang.Class<?> wildcardClass32 = year30.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year30.previous();
        timePeriodValues11.setKey((java.lang.Comparable) regularTimePeriod33);
        boolean boolean35 = timePeriodValue3.equals((java.lang.Object) regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 1.593676799999E12d + "'", number27.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 1.593676799999E12d + "'", number28.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str6 = timePeriodFormatException4.toString();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        long long5 = year4.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
//        java.util.Date date7 = regularTimePeriod6.getEnd();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        long long9 = year8.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year8.next();
//        java.util.Date date11 = regularTimePeriod10.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(date7, date11);
//        java.util.Date date13 = simpleTimePeriod12.getEnd();
//        long long14 = simpleTimePeriod12.getEndMillis();
//        boolean boolean15 = day0.equals((java.lang.Object) simpleTimePeriod12);
//        int int16 = day0.getMonth();
//        long long17 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1609487999999L + "'", long14 == 1609487999999L);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560495599999L + "'", long17 == 1560495599999L);
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int2 = day0.getMonth();
        int int3 = day0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 0.0d);
        int int6 = day0.getMonth();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesException: hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date3);
        long long10 = year9.getFirstMillisecond();
        java.lang.String str11 = year9.toString();
        java.util.Date date12 = year9.getStart();
        java.util.Date date13 = year9.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod15, "hi!", "");
        boolean boolean19 = timePeriodValues18.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues18.addPropertyChangeListener(propertyChangeListener20);
        java.lang.Object obj22 = timePeriodValues18.clone();
        timePeriodValues18.setDomainDescription("");
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.next();
        timePeriodValues18.setKey((java.lang.Comparable) year25);
        int int28 = year25.getYear();
        boolean boolean29 = year9.equals((java.lang.Object) int28);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865600000L + "'", long10 == 1577865600000L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2020" + "'", str11.equals("2020"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
//        boolean boolean5 = timePeriodValues4.isEmpty();
//        java.lang.String str6 = timePeriodValues4.getDomainDescription();
//        boolean boolean7 = timePeriodValues4.isEmpty();
//        timePeriodValues4.setRangeDescription("");
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
//        long long12 = day10.getLastMillisecond();
//        long long13 = day10.getSerialIndex();
//        timePeriodValues4.add((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) (byte) 0);
//        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day10, 1.593676799999E12d);
//        org.jfree.data.time.TimePeriod timePeriod18 = timePeriodValue17.getPeriod();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560495599999L + "'", long12 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43629L + "'", long13 == 43629L);
//        org.junit.Assert.assertNotNull(timePeriod18);
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 1593676799999L);
        timePeriodValues4.add(timePeriodValue10);
        java.lang.Number number12 = null;
        timePeriodValue10.setValue(number12);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.lang.String str6 = timePeriodValues4.getDomainDescription();
        boolean boolean7 = timePeriodValues4.isEmpty();
        java.lang.Object obj8 = timePeriodValues4.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues4.removeChangeListener(seriesChangeListener9);
        timePeriodValues4.setRangeDescription("TimePeriodValue[2019,0]");
        boolean boolean13 = timePeriodValues4.getNotify();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        long long5 = day0.getSerialIndex();
//        long long6 = day0.getFirstMillisecond();
//        java.util.Date date7 = day0.getEnd();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        int int9 = year8.getYear();
//        java.lang.Class<?> wildcardClass10 = year8.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        java.util.Date date12 = null;
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date12, timeZone13);
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        long long17 = year16.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.next();
//        java.util.Date date19 = regularTimePeriod18.getEnd();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        long long21 = year20.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.next();
//        java.util.Date date23 = regularTimePeriod22.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod(date19, date23);
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date23, timeZone25);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        int int28 = year27.getYear();
//        java.lang.Class<?> wildcardClass29 = year27.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.util.Date date31 = null;
//        java.util.TimeZone timeZone32 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date31, timeZone32);
//        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
//        long long36 = year35.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year35.next();
//        java.util.Date date38 = regularTimePeriod37.getEnd();
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
//        long long40 = year39.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year39.next();
//        java.util.Date date42 = regularTimePeriod41.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date38, date42);
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date42, timeZone44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date23, timeZone44);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod(date7, date23);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date23);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(class34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1577865599999L + "'", long36 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int2 = day0.getMonth();
        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year8.next();
        java.util.Date date11 = regularTimePeriod10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(date7, date11);
        java.util.Date date13 = simpleTimePeriod12.getEnd();
        long long14 = simpleTimePeriod12.getEndMillis();
        boolean boolean15 = day0.equals((java.lang.Object) simpleTimePeriod12);
        int int16 = day0.getYear();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1609487999999L + "'", long14 == 1609487999999L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 1593676799999L);
        timePeriodValues4.add(timePeriodValue10);
        int int12 = timePeriodValues4.getMaxStartIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100L, "Time", "org.jfree.data.general.SeriesException: hi!");
        timePeriodValues3.setNotify(true);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        int int6 = timePeriodValues4.getItemCount();
        java.lang.String str7 = timePeriodValues4.getDescription();
        timePeriodValues4.fireSeriesChanged();
        try {
            org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValues4.getTimePeriod(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(str7);
    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getLastMillisecond();
//        long long3 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        java.util.Date date10 = simpleTimePeriod8.getEnd();
        java.util.Date date11 = simpleTimePeriod8.getStart();
        long long12 = simpleTimePeriod8.getStartMillis();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.next();
        java.util.Date date16 = regularTimePeriod15.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.next();
        java.util.Date date20 = regularTimePeriod19.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date16, date20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod23, "hi!", "");
        int int27 = timePeriodValues26.getMinStartIndex();
        int int28 = timePeriodValues26.getItemCount();
        boolean boolean29 = simpleTimePeriod21.equals((java.lang.Object) timePeriodValues26);
        boolean boolean30 = simpleTimePeriod8.equals((java.lang.Object) timePeriodValues26);
        timePeriodValues26.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1609487999999L + "'", long12 == 1609487999999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener11);
        boolean boolean13 = timePeriodValues4.getNotify();
        java.lang.String str14 = timePeriodValues4.getDomainDescription();
        try {
            timePeriodValues4.delete(4, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Object obj8 = timePeriodValues4.clone();
        boolean boolean9 = timePeriodValues4.getNotify();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod11, "hi!", "");
        boolean boolean15 = timePeriodValues14.isEmpty();
        java.lang.String str16 = timePeriodValues14.getDomainDescription();
        boolean boolean17 = timePeriodValues14.isEmpty();
        boolean boolean18 = timePeriodValues4.equals((java.lang.Object) boolean17);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener19);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.delete(7, 0);
        java.lang.String str12 = timePeriodValues4.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues4.removeChangeListener(seriesChangeListener13);
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) seriesChangeListener13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
        boolean boolean14 = timePeriodValues4.equals((java.lang.Object) year11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) 1593676799999L);
        java.lang.Number number20 = timePeriodValue19.getValue();
        java.lang.Number number21 = timePeriodValue19.getValue();
        timePeriodValues4.add(timePeriodValue19);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        int int24 = year23.getYear();
        java.lang.Class<?> wildcardClass25 = year23.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year23.previous();
        timePeriodValues4.setKey((java.lang.Comparable) regularTimePeriod26);
        java.lang.Comparable comparable28 = timePeriodValues4.getKey();
        timePeriodValues4.setDomainDescription("2019");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue32 = timePeriodValues4.getDataItem((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1.593676799999E12d + "'", number20.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1.593676799999E12d + "'", number21.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(comparable28);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        java.lang.String str7 = timePeriodValues4.getDescription();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        int int9 = year8.getYear();
        java.lang.Class<?> wildcardClass10 = year8.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.util.Date date12 = null;
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date12, timeZone13);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.next();
        java.util.Date date19 = regularTimePeriod18.getEnd();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.next();
        java.util.Date date23 = regularTimePeriod22.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod(date19, date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date23, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        int int28 = year27.getYear();
        java.lang.Class<?> wildcardClass29 = year27.getClass();
        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
        java.util.Date date31 = null;
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date31, timeZone32);
        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        long long36 = year35.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year35.next();
        java.util.Date date38 = regularTimePeriod37.getEnd();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        long long40 = year39.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year39.next();
        java.util.Date date42 = regularTimePeriod41.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date38, date42);
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date42, timeZone44);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        int int47 = year46.getYear();
        java.lang.Class<?> wildcardClass48 = year46.getClass();
        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
        java.util.Date date50 = null;
        java.util.TimeZone timeZone51 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date50, timeZone51);
        java.lang.Class class53 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        long long55 = year54.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = year54.next();
        java.util.Date date57 = regularTimePeriod56.getEnd();
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
        long long59 = year58.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = year58.next();
        java.util.Date date61 = regularTimePeriod60.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod62 = new org.jfree.data.time.SimpleTimePeriod(date57, date61);
        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date61, timeZone63);
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date42, timeZone63);
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date23, timeZone63);
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) day66, (double) (short) -1);
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = year69.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues73 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod70, "hi!", "");
        int int74 = timePeriodValues73.getMaxEndIndex();
        timePeriodValues73.delete((int) ' ', 0);
        int int78 = timePeriodValues73.getMinStartIndex();
        int int79 = day66.compareTo((java.lang.Object) timePeriodValues73);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(class34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1577865599999L + "'", long36 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(class49);
        org.junit.Assert.assertNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(class53);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1577865599999L + "'", long55 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1577865599999L + "'", long59 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(timeZone63);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1) + "'", int78 == (-1));
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("13-June-2019");
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 0);
        timePeriodValue3.setValue((java.lang.Number) 100L);
        timePeriodValue3.setValue((java.lang.Number) 2);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 2);
        java.lang.String str9 = seriesChangeEvent8.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2]" + "'", str9.equals("org.jfree.data.general.SeriesChangeEvent[source=2]"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod10, "hi!", "");
        int int14 = timePeriodValues13.getMinStartIndex();
        int int15 = timePeriodValues13.getItemCount();
        boolean boolean16 = simpleTimePeriod8.equals((java.lang.Object) timePeriodValues13);
        long long17 = simpleTimePeriod8.getStartMillis();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.next();
        java.util.Date date21 = regularTimePeriod20.getEnd();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year22.next();
        java.util.Date date25 = regularTimePeriod24.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(date21, date25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date21);
        long long28 = year27.getFirstMillisecond();
        boolean boolean29 = simpleTimePeriod8.equals((java.lang.Object) long28);
        long long30 = simpleTimePeriod8.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long30, "13-June-2019", "TimePeriodValue[2019,0]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener34 = null;
        timePeriodValues33.addChangeListener(seriesChangeListener34);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1609487999999L + "'", long17 == 1609487999999L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865600000L + "'", long28 == 1577865600000L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1609487999999L + "'", long30 == 1609487999999L);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues4.getMinEndIndex();
        int int11 = timePeriodValues4.getMaxEndIndex();
        java.lang.String str12 = timePeriodValues4.getDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNull(str12);
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test356");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        int int4 = day0.getMonth();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.Class<?> wildcardClass2 = year0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        java.util.Date date4 = regularTimePeriod3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year5, (double) 1593676799999L);
        java.lang.Class<?> wildcardClass10 = year5.getClass();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod14, "hi!", "");
        boolean boolean18 = timePeriodValues17.isEmpty();
        int int19 = year11.compareTo((java.lang.Object) boolean18);
        long long20 = year11.getLastMillisecond();
        java.util.Date date21 = year11.getStart();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getLastMillisecond();
        int int24 = year22.getYear();
        java.util.Date date25 = year22.getStart();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date25);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date25, timeZone28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date21, timeZone28);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date4, timeZone28);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        int int2 = day0.getYear();
//        int int3 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 0);
        timePeriodValue3.setValue((java.lang.Number) 100L);
        timePeriodValue3.setValue((java.lang.Number) 2);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 2);
        java.lang.Object obj9 = seriesChangeEvent8.getSource();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + obj9 + "' != '" + 2 + "'", obj9.equals(2));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
        boolean boolean14 = timePeriodValues4.equals((java.lang.Object) year11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) 1593676799999L);
        java.lang.Number number20 = timePeriodValue19.getValue();
        java.lang.Number number21 = timePeriodValue19.getValue();
        timePeriodValues4.add(timePeriodValue19);
        org.jfree.data.time.TimePeriod timePeriod23 = timePeriodValue19.getPeriod();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1.593676799999E12d + "'", number20.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1.593676799999E12d + "'", number21.equals(1.593676799999E12d));
        org.junit.Assert.assertNotNull(timePeriod23);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        timePeriodValues4.setDescription("2019");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year8.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) 1593676799999L);
        java.lang.Number number13 = timePeriodValue12.getValue();
        java.lang.String str14 = timePeriodValue12.toString();
        timePeriodValues4.add(timePeriodValue12);
        try {
            java.lang.Number number17 = timePeriodValues4.getValue((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1.593676799999E12d + "'", number13.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TimePeriodValue[2019,1.593676799999E12]" + "'", str14.equals("TimePeriodValue[2019,1.593676799999E12]"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(100L, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int10 = year9.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (short) 0);
        java.util.Date date13 = year9.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 1593676799999L);
        java.lang.Class<?> wildcardClass19 = year14.getClass();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getLastMillisecond();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod23, "hi!", "");
        boolean boolean27 = timePeriodValues26.isEmpty();
        int int28 = year20.compareTo((java.lang.Object) boolean27);
        long long29 = year20.getLastMillisecond();
        java.util.Date date30 = year20.getStart();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        long long32 = year31.getLastMillisecond();
        int int33 = year31.getYear();
        java.util.Date date34 = year31.getStart();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date34);
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date34, timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date30, timeZone37);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        int int41 = year40.getYear();
        java.lang.Class<?> wildcardClass42 = year40.getClass();
        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
        java.util.Date date44 = null;
        java.util.TimeZone timeZone45 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date44, timeZone45);
        java.lang.Class class47 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        long long49 = year48.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year48.next();
        java.util.Date date51 = regularTimePeriod50.getEnd();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        long long53 = year52.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year52.next();
        java.util.Date date55 = regularTimePeriod54.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod56 = new org.jfree.data.time.SimpleTimePeriod(date51, date55);
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date55, timeZone57);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date30, timeZone57);
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date13, timeZone57);
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date3, timeZone57);
        long long62 = day61.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2019 + "'", int41 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(class43);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(class47);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1577865599999L + "'", long49 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1577865599999L + "'", long53 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1609401600000L + "'", long62 == 1609401600000L);
    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test364");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        long long5 = day0.getLastMillisecond();
//        int int6 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.previous();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod3, "hi!", "");
        boolean boolean7 = timePeriodValues6.isEmpty();
        int int8 = year0.compareTo((java.lang.Object) boolean7);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) boolean7, "2019", "hi!");
        int int12 = timePeriodValues11.getMaxStartIndex();
        boolean boolean13 = timePeriodValues11.getNotify();
        timePeriodValues11.delete(11, 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener8);
        timePeriodValues4.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
        int int12 = timePeriodValues4.getMinMiddleIndex();
        timePeriodValues4.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        int int7 = year6.getYear();
        java.lang.Class<?> wildcardClass8 = year6.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.previous();
        boolean boolean10 = timePeriodValues4.equals((java.lang.Object) regularTimePeriod9);
        timePeriodValues4.setNotify(false);
        timePeriodValues4.delete(7, (-1));
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener16);
        boolean boolean18 = timePeriodValues4.getNotify();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.delete(7, 0);
        timePeriodValues4.setNotify(false);
        java.lang.Object obj14 = timePeriodValues4.clone();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.delete(7, 0);
        java.lang.String str12 = timePeriodValues4.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues4.removeChangeListener(seriesChangeListener13);
        java.lang.Class<?> wildcardClass15 = timePeriodValues4.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        timePeriodValues4.delete((int) ' ', 0);
        int int9 = timePeriodValues4.getMaxStartIndex();
        try {
            timePeriodValues4.update((int) 'a', (java.lang.Number) 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        long long4 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        timePeriodValues4.setDescription("2019");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year8.next();
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) regularTimePeriod10, (double) 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test373");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
//        java.util.Date date3 = regularTimePeriod2.getEnd();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        long long5 = year4.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
//        java.util.Date date7 = regularTimePeriod6.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date3);
//        long long10 = year9.getFirstMillisecond();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
//        long long13 = day11.getFirstMillisecond();
//        int int14 = year9.compareTo((java.lang.Object) day11);
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = day11.getFirstMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865600000L + "'", long10 == 1577865600000L);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560409200000L + "'", long13 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener8);
        timePeriodValues4.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener12);
        int int14 = timePeriodValues4.getMaxMiddleIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 0, (int) (byte) 1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues4.getMinStartIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) 1593676799999L);
        java.lang.Number number14 = timePeriodValue13.getValue();
        java.lang.Object obj15 = timePeriodValue13.clone();
        java.lang.String str16 = timePeriodValue13.toString();
        timePeriodValues4.add(timePeriodValue13);
        int int18 = timePeriodValues4.getMaxStartIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1.593676799999E12d + "'", number14.equals(1.593676799999E12d));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TimePeriodValue[2019,1.593676799999E12]" + "'", str16.equals("TimePeriodValue[2019,1.593676799999E12]"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int2 = day0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
        int int4 = day0.getYear();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        timePeriodValues4.setDescription("2019");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener8);
        boolean boolean10 = timePeriodValues4.isEmpty();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 1577865600000L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Object obj8 = timePeriodValues4.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod12, "hi!", "");
        boolean boolean16 = timePeriodValues15.isEmpty();
        int int17 = year9.compareTo((java.lang.Object) boolean16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year9.previous();
        timePeriodValues4.setKey((java.lang.Comparable) year9);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year21, (java.lang.Number) 0);
        java.lang.Number number25 = timePeriodValue24.getValue();
        java.lang.Number number26 = timePeriodValue24.getValue();
        java.lang.String str27 = timePeriodValue24.toString();
        timePeriodValues4.add(timePeriodValue24);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        long long30 = year29.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year29.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue33 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year29, (double) 1593676799999L);
        java.lang.Number number34 = timePeriodValue33.getValue();
        java.lang.String str35 = timePeriodValue33.toString();
        java.lang.Object obj36 = timePeriodValue33.clone();
        timePeriodValues4.add(timePeriodValue33);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 0 + "'", number25.equals(0));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 0 + "'", number26.equals(0));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "TimePeriodValue[2019,0]" + "'", str27.equals("TimePeriodValue[2019,0]"));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1577865599999L + "'", long30 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 1.593676799999E12d + "'", number34.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "TimePeriodValue[2019,1.593676799999E12]" + "'", str35.equals("TimePeriodValue[2019,1.593676799999E12]"));
        org.junit.Assert.assertNotNull(obj36);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.delete(7, 0);
        int int12 = timePeriodValues4.getMinMiddleIndex();
        timePeriodValues4.fireSeriesChanged();
        timePeriodValues4.setRangeDescription("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=0]");
        int int16 = timePeriodValues4.getMinMiddleIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
//        boolean boolean5 = timePeriodValues4.isEmpty();
//        java.lang.String str6 = timePeriodValues4.getDomainDescription();
//        boolean boolean7 = timePeriodValues4.isEmpty();
//        timePeriodValues4.setRangeDescription("");
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
//        long long12 = day10.getLastMillisecond();
//        long long13 = day10.getSerialIndex();
//        timePeriodValues4.add((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) (byte) 0);
//        try {
//            org.jfree.data.time.TimePeriodValue timePeriodValue17 = timePeriodValues4.getDataItem((int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560495599999L + "'", long12 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43629L + "'", long13 == 43629L);
//    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int2 = day0.getMonth();
        int int3 = day0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 0.0d);
        org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValue5.getPeriod();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(timePeriod6);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        boolean boolean6 = timePeriodValues4.isEmpty();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int8 = year7.getYear();
        long long9 = year7.getLastMillisecond();
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) year7, (-1.0d));
        long long12 = year7.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getLastMillisecond();
//        java.lang.Object obj3 = null;
//        boolean boolean4 = day0.equals(obj3);
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        int int7 = day6.getDayOfMonth();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.lang.String str6 = timePeriodValues4.getDomainDescription();
        int int7 = timePeriodValues4.getMinStartIndex();
        java.lang.Object obj8 = timePeriodValues4.clone();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(obj8);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2019);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate3 = day2.getSerialDate();
//        long long4 = day2.getSerialIndex();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day2, (java.lang.Number) 10);
//        timePeriodValues1.setNotify(true);
//        try {
//            timePeriodValues1.update((int) '#', (java.lang.Number) (short) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod3, "hi!", "");
        boolean boolean7 = timePeriodValues6.isEmpty();
        int int8 = year0.compareTo((java.lang.Object) boolean7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year0.previous();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year0.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues4.getMinStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) false);
        java.lang.Object obj11 = timePeriodValues4.clone();
        try {
            org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValues4.getTimePeriod((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.delete(7, 0);
        timePeriodValues4.setNotify(false);
        java.lang.Comparable comparable14 = timePeriodValues4.getKey();
        timePeriodValues4.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 1577865599999L + "'", comparable14.equals(1577865599999L));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        int int2 = year0.getYear();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3);
        int int7 = day6.getMonth();
        int int8 = day6.getYear();
        java.lang.String str9 = day6.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1-January-2019" + "'", str9.equals("1-January-2019"));
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getFirstMillisecond();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate4);
//        long long7 = day6.getLastMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        java.util.Date date10 = simpleTimePeriod8.getEnd();
        java.util.Date date11 = simpleTimePeriod8.getStart();
        long long12 = simpleTimePeriod8.getStartMillis();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.next();
        java.util.Date date16 = regularTimePeriod15.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.next();
        java.util.Date date20 = regularTimePeriod19.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date16, date20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod23, "hi!", "");
        int int27 = timePeriodValues26.getMinStartIndex();
        int int28 = timePeriodValues26.getItemCount();
        boolean boolean29 = simpleTimePeriod21.equals((java.lang.Object) timePeriodValues26);
        boolean boolean30 = simpleTimePeriod8.equals((java.lang.Object) timePeriodValues26);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year31.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod32, "hi!", "");
        boolean boolean36 = timePeriodValues35.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timePeriodValues35.addPropertyChangeListener(propertyChangeListener37);
        java.lang.Object obj39 = timePeriodValues35.clone();
        timePeriodValues35.setDomainDescription("");
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year42.next();
        timePeriodValues35.setKey((java.lang.Comparable) year42);
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) year42, (double) 1560409200000L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1609487999999L + "'", long12 == 1609487999999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2019);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        int int3 = year2.getYear();
        java.lang.Class<?> wildcardClass4 = year2.getClass();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year2, (double) 2019);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        boolean boolean12 = year7.equals((java.lang.Object) "2019");
        int int13 = year2.compareTo((java.lang.Object) "2019");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year2.previous();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = year2.getFirstMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
//        boolean boolean7 = day0.equals((java.lang.Object) "13-June-2019");
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (short) 0);
        int int4 = year0.getYear();
        long long5 = year0.getSerialIndex();
        java.util.Calendar calendar6 = null;
        try {
            year0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test398");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        long long5 = day0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
//        java.util.Calendar calendar7 = null;
//        try {
//            day0.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod3, "hi!", "");
        boolean boolean7 = timePeriodValues6.isEmpty();
        int int8 = year0.compareTo((java.lang.Object) boolean7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "2019", "2019");
        java.lang.String str13 = timePeriodValues12.getDescription();
        timePeriodValues12.setKey((java.lang.Comparable) true);
        int int16 = timePeriodValues12.getMaxMiddleIndex();
        java.lang.String str17 = timePeriodValues12.getDescription();
        try {
            java.lang.Number number19 = timePeriodValues12.getValue(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int2 = day0.getMonth();
        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
        int int5 = day4.getYear();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day4.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        java.util.Date date10 = simpleTimePeriod8.getEnd();
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
//        int int5 = timePeriodValues4.getMinStartIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
//        timePeriodValues4.addChangeListener(seriesChangeListener6);
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener8);
//        timePeriodValues4.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
//        long long14 = day12.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (double) 11);
//        timePeriodValues4.setKey((java.lang.Comparable) day12);
//        java.beans.PropertyChangeListener propertyChangeListener19 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener19);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate15);
//    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Object obj8 = timePeriodValues4.clone();
        timePeriodValues4.setDomainDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues4.createCopy(10, (int) (byte) 0);
        java.lang.String str14 = timePeriodValues13.getDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        int int2 = year0.getYear();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.String str6 = year5.toString();
        int int7 = year4.compareTo((java.lang.Object) year5);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (short) 0);
        int int4 = year0.getYear();
        java.lang.Object obj5 = null;
        int int6 = year0.compareTo(obj5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 1593676799999L);
        java.lang.Class<?> wildcardClass5 = year0.getClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod9, "hi!", "");
        boolean boolean13 = timePeriodValues12.isEmpty();
        int int14 = year6.compareTo((java.lang.Object) boolean13);
        long long15 = year6.getLastMillisecond();
        java.util.Date date16 = year6.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        int int19 = year17.getYear();
        java.util.Date date20 = year17.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date20, timeZone23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date16, timeZone23);
        java.util.Date date26 = regularTimePeriod25.getEnd();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 100);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.setNotify(false);
        int int11 = timePeriodValues4.getItemCount();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.Class<?> wildcardClass2 = year0.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.util.Date date4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date4, timeZone5);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year8.next();
        java.util.Date date11 = regularTimePeriod10.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.next();
        java.util.Date date15 = regularTimePeriod14.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date11, date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date11);
        long long18 = year17.getFirstMillisecond();
        java.lang.String str19 = year17.toString();
        java.util.Date date20 = year17.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int22 = year21.getYear();
        java.lang.Class<?> wildcardClass23 = year21.getClass();
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
        java.util.Date date25 = null;
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date25, timeZone26);
        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        long long30 = year29.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year29.next();
        java.util.Date date32 = regularTimePeriod31.getEnd();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        long long34 = year33.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year33.next();
        java.util.Date date36 = regularTimePeriod35.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod(date32, date36);
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date36, timeZone38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        long long41 = year40.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year40.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue44 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year40, (double) 1593676799999L);
        java.lang.Class<?> wildcardClass45 = year40.getClass();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        long long47 = year46.getLastMillisecond();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year48.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues52 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod49, "hi!", "");
        boolean boolean53 = timePeriodValues52.isEmpty();
        int int54 = year46.compareTo((java.lang.Object) boolean53);
        long long55 = year46.getLastMillisecond();
        java.util.Date date56 = year46.getStart();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        long long58 = year57.getLastMillisecond();
        int int59 = year57.getYear();
        java.util.Date date60 = year57.getStart();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date60);
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date60);
        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date60, timeZone63);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date56, timeZone63);
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date36, timeZone63);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date20, timeZone63);
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
        long long69 = year68.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = year68.next();
        java.util.Date date71 = regularTimePeriod70.getEnd();
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year();
        long long73 = year72.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = year72.next();
        java.util.Date date75 = regularTimePeriod74.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod76 = new org.jfree.data.time.SimpleTimePeriod(date71, date75);
        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date71);
        long long78 = year77.getFirstMillisecond();
        java.lang.String str79 = year77.toString();
        java.util.Date date80 = year77.getStart();
        java.util.Date date81 = year77.getEnd();
        java.util.Date date82 = year77.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod83 = new org.jfree.data.time.SimpleTimePeriod(date20, date82);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865600000L + "'", long18 == 1577865600000L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2020" + "'", str19.equals("2020"));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1577865599999L + "'", long30 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577865599999L + "'", long34 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1577865599999L + "'", long47 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1577865599999L + "'", long55 == 1577865599999L);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1577865599999L + "'", long58 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(timeZone63);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1577865599999L + "'", long69 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1577865599999L + "'", long73 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 1577865600000L + "'", long78 == 1577865600000L);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "2020" + "'", str79.equals("2020"));
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertNotNull(date82);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        timePeriodValues4.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        boolean boolean8 = timePeriodValues4.isEmpty();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener8);
        timePeriodValues4.delete(1, 0);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener13);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
        boolean boolean14 = timePeriodValues4.equals((java.lang.Object) year11);
        java.util.Calendar calendar15 = null;
        try {
            year11.peg(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        java.util.Date date10 = simpleTimePeriod8.getEnd();
        java.util.Date date11 = simpleTimePeriod8.getStart();
        long long12 = simpleTimePeriod8.getStartMillis();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.next();
        java.util.Date date16 = regularTimePeriod15.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.next();
        java.util.Date date20 = regularTimePeriod19.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date16, date20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod23, "hi!", "");
        int int27 = timePeriodValues26.getMinStartIndex();
        int int28 = timePeriodValues26.getItemCount();
        boolean boolean29 = simpleTimePeriod21.equals((java.lang.Object) timePeriodValues26);
        boolean boolean30 = simpleTimePeriod8.equals((java.lang.Object) timePeriodValues26);
        java.lang.String str31 = timePeriodValues26.getRangeDescription();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1609487999999L + "'", long12 == 1609487999999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod10, "hi!", "");
        int int14 = timePeriodValues13.getMinStartIndex();
        int int15 = timePeriodValues13.getItemCount();
        boolean boolean16 = simpleTimePeriod8.equals((java.lang.Object) timePeriodValues13);
        long long17 = simpleTimePeriod8.getStartMillis();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.next();
        java.util.Date date21 = regularTimePeriod20.getEnd();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year22.next();
        java.util.Date date25 = regularTimePeriod24.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(date21, date25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date21);
        long long28 = year27.getFirstMillisecond();
        boolean boolean29 = simpleTimePeriod8.equals((java.lang.Object) long28);
        long long30 = simpleTimePeriod8.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long30, "13-June-2019", "TimePeriodValue[2019,0]");
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        long long35 = year34.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year34.next();
        java.util.Date date37 = regularTimePeriod36.getEnd();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        long long39 = year38.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year38.next();
        java.util.Date date41 = regularTimePeriod40.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(date37, date41);
        long long43 = simpleTimePeriod42.getStartMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue45 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod42, 0.0d);
        java.lang.Number number46 = timePeriodValue45.getValue();
        timePeriodValues33.add(timePeriodValue45);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1609487999999L + "'", long17 == 1609487999999L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865600000L + "'", long28 == 1577865600000L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1609487999999L + "'", long30 == 1609487999999L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1577865599999L + "'", long35 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1609487999999L + "'", long43 == 1609487999999L);
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + 0.0d + "'", number46.equals(0.0d));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=1577865600000]");
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date3);
        long long10 = year9.getFirstMillisecond();
        java.lang.String str11 = year9.toString();
        long long12 = year9.getSerialIndex();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = year9.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865600000L + "'", long10 == 1577865600000L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2020" + "'", str11.equals("2020"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2020L + "'", long12 == 2020L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        java.lang.Class<?> wildcardClass3 = timePeriodValues2.getClass();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.delete(7, 0);
        timePeriodValues4.setRangeDescription("TimePeriodValue[2019,1.593676799999E12]");
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
        boolean boolean14 = timePeriodValues4.equals((java.lang.Object) year11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) 1593676799999L);
        java.lang.Number number20 = timePeriodValue19.getValue();
        java.lang.Number number21 = timePeriodValue19.getValue();
        timePeriodValues4.add(timePeriodValue19);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        int int24 = year23.getYear();
        java.lang.Class<?> wildcardClass25 = year23.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year23.previous();
        timePeriodValues4.setKey((java.lang.Comparable) regularTimePeriod26);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
        timePeriodValues4.removeChangeListener(seriesChangeListener28);
        int int30 = timePeriodValues4.getMaxStartIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1.593676799999E12d + "'", number20.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1.593676799999E12d + "'", number21.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 1593676799999L);
        java.lang.Class<?> wildcardClass5 = year0.getClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod9, "hi!", "");
        boolean boolean13 = timePeriodValues12.isEmpty();
        int int14 = year6.compareTo((java.lang.Object) boolean13);
        long long15 = year6.getLastMillisecond();
        java.util.Date date16 = year6.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        int int19 = year17.getYear();
        java.util.Date date20 = year17.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date20, timeZone23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date16, timeZone23);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        int int27 = year26.getYear();
        java.lang.Class<?> wildcardClass28 = year26.getClass();
        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
        java.util.Date date30 = null;
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date30, timeZone31);
        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        long long35 = year34.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year34.next();
        java.util.Date date37 = regularTimePeriod36.getEnd();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        long long39 = year38.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year38.next();
        java.util.Date date41 = regularTimePeriod40.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(date37, date41);
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date41, timeZone43);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date16, timeZone43);
        java.util.Calendar calendar46 = null;
        try {
            long long47 = year45.getFirstMillisecond(calendar46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(class29);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(class33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1577865599999L + "'", long35 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        java.util.Date date10 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TimePeriodValue[13-June-2019,1.560495599999E12]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 100.0d);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.String str4 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 100.0d + "'", obj2.equals(100.0d));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 100.0d + "'", obj3.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=100.0]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=100.0]"));
    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 12);
//        java.lang.String str6 = day0.toString();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        int int6 = timePeriodValues4.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        int int9 = year7.getYear();
        java.util.Date date10 = year7.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date10);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date10, timeZone13);
        java.lang.Class<?> wildcardClass15 = timeZone13.getClass();
        boolean boolean16 = timePeriodValues4.equals((java.lang.Object) wildcardClass15);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 567, 2020L);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod3, "hi!", "");
        boolean boolean7 = timePeriodValues6.isEmpty();
        int int8 = timePeriodValues6.getMinEndIndex();
        boolean boolean9 = year0.equals((java.lang.Object) int8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod11, "hi!", "");
        boolean boolean15 = timePeriodValues14.isEmpty();
        int int16 = timePeriodValues14.getMaxStartIndex();
        timePeriodValues14.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues14.delete(7, 0);
        java.lang.String str22 = timePeriodValues14.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timePeriodValues14.removeChangeListener(seriesChangeListener23);
        boolean boolean25 = year0.equals((java.lang.Object) seriesChangeListener23);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues4.getMinStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener13);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test431");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        long long5 = day0.getSerialIndex();
//        long long6 = day0.getFirstMillisecond();
//        java.util.Date date7 = day0.getEnd();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        int int9 = year8.getYear();
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) (short) 0);
//        int int12 = day0.compareTo((java.lang.Object) year8);
//        java.lang.Object obj13 = null;
//        int int14 = day0.compareTo(obj13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day0.previous();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        long long2 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2019);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate3 = day2.getSerialDate();
//        long long4 = day2.getSerialIndex();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day2, (java.lang.Number) 10);
//        timePeriodValues1.setDomainDescription("");
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod10, "hi!", "");
//        int int14 = timePeriodValues13.getMinStartIndex();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        long long16 = year15.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) 1593676799999L);
//        timePeriodValues13.add(timePeriodValue19);
//        java.lang.Class<?> wildcardClass21 = timePeriodValues13.getClass();
//        boolean boolean22 = timePeriodValues1.equals((java.lang.Object) wildcardClass21);
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener23);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        int int2 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        long long2 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.delete(7, 0);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        int int13 = year12.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (double) (short) 0);
        java.lang.Object obj16 = timePeriodValue15.clone();
        boolean boolean17 = timePeriodValues4.equals((java.lang.Object) timePeriodValue15);
        timePeriodValue15.setValue((java.lang.Number) 0);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 0);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=0]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=0]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (short) 0 + "'", obj3.equals((short) 0));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + (short) 0 + "'", obj4.equals((short) 0));
    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getFirstMillisecond();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        int int6 = year5.getYear();
//        java.lang.Class<?> wildcardClass7 = year5.getClass();
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        java.util.Date date9 = null;
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date9, timeZone10);
//        boolean boolean12 = day0.equals((java.lang.Object) timeZone10);
//        org.jfree.data.time.SerialDate serialDate13 = day0.getSerialDate();
//        java.lang.String str14 = day0.toString();
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = day0.getFirstMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
//        boolean boolean5 = timePeriodValues4.isEmpty();
//        java.lang.String str6 = timePeriodValues4.getDomainDescription();
//        boolean boolean7 = timePeriodValues4.isEmpty();
//        timePeriodValues4.setRangeDescription("");
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
//        long long12 = day10.getLastMillisecond();
//        long long13 = day10.getSerialIndex();
//        timePeriodValues4.add((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) (byte) 0);
//        timePeriodValues4.fireSeriesChanged();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560495599999L + "'", long12 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43629L + "'", long13 == 43629L);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (short) 0);
        java.lang.Object obj4 = timePeriodValue3.clone();
        java.lang.Object obj5 = timePeriodValue3.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("");
        seriesException5.addSuppressed((java.lang.Throwable) seriesException7);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException7);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        int int2 = year0.getYear();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date3, timeZone6);
        long long8 = year7.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        int int2 = year0.getYear();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date3, timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getLastMillisecond();
        int int10 = year8.getYear();
        java.util.Date date11 = year8.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date11);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date11, timeZone14);
        java.lang.Class<?> wildcardClass16 = timeZone14.getClass();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date3, timeZone14);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 567);
    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test446");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        long long5 = day0.getSerialIndex();
//        long long6 = day0.getSerialIndex();
//        int int7 = day0.getYear();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day0.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getSerialIndex();
//        java.util.Date date3 = day0.getEnd();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod5, "hi!", "");
//        boolean boolean9 = timePeriodValues8.isEmpty();
//        int int10 = timePeriodValues8.getMaxStartIndex();
//        java.lang.String str11 = timePeriodValues8.getDescription();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        int int13 = year12.getYear();
//        java.lang.Class<?> wildcardClass14 = year12.getClass();
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
//        java.util.Date date16 = null;
//        java.util.TimeZone timeZone17 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date16, timeZone17);
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        long long21 = year20.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.next();
//        java.util.Date date23 = regularTimePeriod22.getEnd();
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        long long25 = year24.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year24.next();
//        java.util.Date date27 = regularTimePeriod26.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(date23, date27);
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date27, timeZone29);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        int int32 = year31.getYear();
//        java.lang.Class<?> wildcardClass33 = year31.getClass();
//        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
//        java.util.Date date35 = null;
//        java.util.TimeZone timeZone36 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date35, timeZone36);
//        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
//        long long40 = year39.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year39.next();
//        java.util.Date date42 = regularTimePeriod41.getEnd();
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
//        long long44 = year43.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year43.next();
//        java.util.Date date46 = regularTimePeriod45.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod(date42, date46);
//        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date46, timeZone48);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        int int51 = year50.getYear();
//        java.lang.Class<?> wildcardClass52 = year50.getClass();
//        java.lang.Class class53 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass52);
//        java.util.Date date54 = null;
//        java.util.TimeZone timeZone55 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date54, timeZone55);
//        java.lang.Class class57 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass52);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
//        long long59 = year58.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = year58.next();
//        java.util.Date date61 = regularTimePeriod60.getEnd();
//        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
//        long long63 = year62.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = year62.next();
//        java.util.Date date65 = regularTimePeriod64.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod66 = new org.jfree.data.time.SimpleTimePeriod(date61, date65);
//        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date65, timeZone67);
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date46, timeZone67);
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date27, timeZone67);
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day70, (double) (short) -1);
//        long long73 = day70.getSerialIndex();
//        java.lang.Number number74 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue75 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day70, number74);
//        int int76 = day0.compareTo((java.lang.Object) number74);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNull(str11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(class34);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1577865599999L + "'", long44 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone48);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertNotNull(class53);
//        org.junit.Assert.assertNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(class57);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1577865599999L + "'", long59 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1577865599999L + "'", long63 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(timeZone67);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 44196L + "'", long73 == 44196L);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
//    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        int int2 = year0.getYear();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3);
        int int7 = day6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day6.next();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day6.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        java.util.Date date10 = simpleTimePeriod8.getEnd();
        java.util.Date date11 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        int int13 = year12.getYear();
        java.lang.Class<?> wildcardClass14 = year12.getClass();
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date16, timeZone17);
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.next();
        java.util.Date date23 = regularTimePeriod22.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year24.next();
        java.util.Date date27 = regularTimePeriod26.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(date23, date27);
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date27, timeZone29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        int int32 = year31.getYear();
        java.lang.Class<?> wildcardClass33 = year31.getClass();
        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
        java.util.Date date35 = null;
        java.util.TimeZone timeZone36 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date35, timeZone36);
        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        long long40 = year39.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year39.next();
        java.util.Date date42 = regularTimePeriod41.getEnd();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        long long44 = year43.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year43.next();
        java.util.Date date46 = regularTimePeriod45.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod(date42, date46);
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date46, timeZone48);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date27, timeZone48);
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date11, timeZone48);
        java.util.Calendar calendar52 = null;
        try {
            long long53 = year51.getLastMillisecond(calendar52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(class34);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(class38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1577865599999L + "'", long44 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.delete(7, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues4.removeChangeListener(seriesChangeListener12);
        try {
            timePeriodValues4.update(0, (java.lang.Number) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.lang.String str6 = timePeriodValues4.getDomainDescription();
        boolean boolean7 = timePeriodValues4.isEmpty();
        int int8 = timePeriodValues4.getMaxMiddleIndex();
        timePeriodValues4.setDomainDescription("");
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 1593676799999L);
        java.lang.Class<?> wildcardClass5 = year0.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(class8);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        int int2 = year0.getYear();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod4, "hi!", "");
        int int8 = timePeriodValues7.getMaxEndIndex();
        boolean boolean9 = timePeriodValues7.isEmpty();
        int int10 = year0.compareTo((java.lang.Object) boolean9);
        java.lang.Class<?> wildcardClass11 = year0.getClass();
        java.util.Calendar calendar12 = null;
        try {
            year0.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener11);
        int int13 = timePeriodValues4.getMaxEndIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 1593676799999L);
        java.lang.Number number5 = timePeriodValue4.getValue();
        java.lang.Number number6 = timePeriodValue4.getValue();
        timePeriodValue4.setValue((java.lang.Number) 43629L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.593676799999E12d + "'", number5.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.593676799999E12d + "'", number6.equals(1.593676799999E12d));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        boolean boolean6 = timePeriodValues4.isEmpty();
        java.lang.String str7 = timePeriodValues4.getDomainDescription();
        timePeriodValues4.setDomainDescription("TimePeriodValue[2019,0]");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue11 = timePeriodValues4.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.lang.String str6 = timePeriodValues4.getDomainDescription();
        boolean boolean7 = timePeriodValues4.isEmpty();
        timePeriodValues4.setRangeDescription("");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod11, "hi!", "");
        boolean boolean15 = timePeriodValues14.isEmpty();
        int int16 = timePeriodValues14.getMaxStartIndex();
        java.lang.String str17 = timePeriodValues14.getDescription();
        java.lang.String str18 = timePeriodValues14.getDomainDescription();
        int int19 = timePeriodValues14.getMinEndIndex();
        timePeriodValues14.setRangeDescription("TimePeriodValue[2019,1.593676799999E12]");
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int23 = year22.getYear();
        java.lang.Class<?> wildcardClass24 = year22.getClass();
        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date26, timeZone27);
        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        long long31 = year30.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year30.next();
        java.util.Date date33 = regularTimePeriod32.getEnd();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        long long35 = year34.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year34.next();
        java.util.Date date37 = regularTimePeriod36.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date33, date37);
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date37, timeZone39);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        long long42 = year41.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year41.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue45 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year41, (double) 1593676799999L);
        java.lang.Class<?> wildcardClass46 = year41.getClass();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
        long long48 = year47.getLastMillisecond();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year49.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues53 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod50, "hi!", "");
        boolean boolean54 = timePeriodValues53.isEmpty();
        int int55 = year47.compareTo((java.lang.Object) boolean54);
        long long56 = year47.getLastMillisecond();
        java.util.Date date57 = year47.getStart();
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
        long long59 = year58.getLastMillisecond();
        int int60 = year58.getYear();
        java.util.Date date61 = year58.getStart();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date61);
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year(date61);
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date61, timeZone64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date57, timeZone64);
        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(date37, timeZone64);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) day67, (java.lang.Number) (byte) 1);
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) day67, (java.lang.Number) 0.0d);
        int int72 = day67.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = day67.next();
        long long74 = day67.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(class29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1577865599999L + "'", long35 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1577865599999L + "'", long42 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1577865599999L + "'", long48 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1577865599999L + "'", long56 == 1577865599999L);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1577865599999L + "'", long59 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 12 + "'", int72 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 44196L + "'", long74 == 44196L);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
        boolean boolean14 = timePeriodValues4.equals((java.lang.Object) year11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) 1593676799999L);
        java.lang.Number number20 = timePeriodValue19.getValue();
        java.lang.Number number21 = timePeriodValue19.getValue();
        timePeriodValues4.add(timePeriodValue19);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) regularTimePeriod24, (java.lang.Number) 1577865599999L);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener27);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener29);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1.593676799999E12d + "'", number20.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1.593676799999E12d + "'", number21.equals(1.593676799999E12d));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        int int4 = year3.getYear();
//        boolean boolean5 = day0.equals((java.lang.Object) int4);
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        java.lang.String str7 = day0.toString();
//        long long8 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560452399999L + "'", long8 == 1560452399999L);
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[2019,1.593676799999E12]");
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        java.lang.String str7 = timePeriodValues4.getDescription();
        java.lang.String str8 = timePeriodValues4.getDomainDescription();
        int int9 = timePeriodValues4.getMinEndIndex();
        timePeriodValues4.setRangeDescription("TimePeriodValue[2019,1.593676799999E12]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues4.removeChangeListener(seriesChangeListener12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod15, "hi!", "");
        boolean boolean19 = timePeriodValues18.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues18.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timePeriodValues18.removeChangeListener(seriesChangeListener22);
        java.lang.Comparable comparable24 = timePeriodValues18.getKey();
        timePeriodValues4.setKey(comparable24);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(comparable24);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.util.Date date0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.next();
        java.util.Date date4 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.next();
        java.util.Date date8 = regularTimePeriod7.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date4, date8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) (short) 0);
        java.util.Date date14 = year10.getEnd();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) 1593676799999L);
        java.lang.Class<?> wildcardClass20 = year15.getClass();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getLastMillisecond();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod24, "hi!", "");
        boolean boolean28 = timePeriodValues27.isEmpty();
        int int29 = year21.compareTo((java.lang.Object) boolean28);
        long long30 = year21.getLastMillisecond();
        java.util.Date date31 = year21.getStart();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        long long33 = year32.getLastMillisecond();
        int int34 = year32.getYear();
        java.util.Date date35 = year32.getStart();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date35);
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date35, timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date31, timeZone38);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        int int42 = year41.getYear();
        java.lang.Class<?> wildcardClass43 = year41.getClass();
        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
        java.util.Date date45 = null;
        java.util.TimeZone timeZone46 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date45, timeZone46);
        java.lang.Class class48 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        long long50 = year49.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year49.next();
        java.util.Date date52 = regularTimePeriod51.getEnd();
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        long long54 = year53.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = year53.next();
        java.util.Date date56 = regularTimePeriod55.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod57 = new org.jfree.data.time.SimpleTimePeriod(date52, date56);
        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date56, timeZone58);
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year(date31, timeZone58);
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date14, timeZone58);
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date4, timeZone58);
        try {
            org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date0, timeZone58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1577865599999L + "'", long30 == 1577865599999L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577865599999L + "'", long33 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(class44);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(class48);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1577865599999L + "'", long50 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1577865599999L + "'", long54 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
        boolean boolean14 = timePeriodValues4.equals((java.lang.Object) year11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues4.removeChangeListener(seriesChangeListener15);
        java.lang.Comparable comparable17 = timePeriodValues4.getKey();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + 1577865599999L + "'", comparable17.equals(1577865599999L));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("1-January-2019");
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date3);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.Class<?> wildcardClass2 = year0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        long long4 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long4, "", "2020");
        int int8 = timePeriodValues7.getMaxStartIndex();
        int int9 = timePeriodValues7.getItemCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date3);
        long long10 = year9.getFirstMillisecond();
        java.lang.String str11 = year9.toString();
        java.util.Date date12 = year9.getStart();
        java.util.Date date13 = year9.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year9.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865600000L + "'", long10 == 1577865600000L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2020" + "'", str11.equals("2020"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        int int7 = year6.getYear();
        java.lang.Class<?> wildcardClass8 = year6.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.previous();
        boolean boolean10 = timePeriodValues4.equals((java.lang.Object) regularTimePeriod9);
        timePeriodValues4.setNotify(false);
        timePeriodValues4.delete(7, (-1));
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener16);
        try {
            java.lang.Number number19 = timePeriodValues4.getValue((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getFirstMillisecond();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        int int6 = year5.getYear();
//        java.lang.Class<?> wildcardClass7 = year5.getClass();
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        java.util.Date date9 = null;
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date9, timeZone10);
//        boolean boolean12 = day0.equals((java.lang.Object) timeZone10);
//        org.jfree.data.time.SerialDate serialDate13 = day0.getSerialDate();
//        long long14 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day0.previous();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        int int4 = year3.getYear();
//        boolean boolean5 = day0.equals((java.lang.Object) int4);
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        long long7 = day0.getSerialIndex();
//        java.lang.Class<?> wildcardClass8 = day0.getClass();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod10, "hi!", "");
//        int int14 = timePeriodValues13.getMaxStartIndex();
//        boolean boolean15 = timePeriodValues13.isEmpty();
//        boolean boolean16 = day0.equals((java.lang.Object) timePeriodValues13);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Object obj8 = timePeriodValues4.clone();
        timePeriodValues4.setDomainDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.next();
        timePeriodValues4.setKey((java.lang.Comparable) year11);
        int int14 = timePeriodValues4.getMaxStartIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener8);
        timePeriodValues4.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues4.setDescription("TimePeriodValue[2019,1.593676799999E12]");
        java.lang.String str14 = timePeriodValues4.getRangeDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 1593676799999L);
        java.lang.Class<?> wildcardClass5 = year0.getClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod9, "hi!", "");
        boolean boolean13 = timePeriodValues12.isEmpty();
        int int14 = year6.compareTo((java.lang.Object) boolean13);
        long long15 = year6.getLastMillisecond();
        java.util.Date date16 = year6.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        int int19 = year17.getYear();
        java.util.Date date20 = year17.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date20, timeZone23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date16, timeZone23);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        long long27 = year26.getLastMillisecond();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod29, "hi!", "");
        boolean boolean33 = timePeriodValues32.isEmpty();
        int int34 = year26.compareTo((java.lang.Object) boolean33);
        long long35 = year26.getLastMillisecond();
        java.util.Date date36 = year26.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod(date16, date36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate39 = day38.getSerialDate();
        int int40 = day38.getMonth();
        java.util.Date date41 = day38.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(date16, date41);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        long long44 = year43.getLastMillisecond();
        int int45 = year43.getYear();
        java.util.Date date46 = year43.getStart();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date46);
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date46);
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date46, timeZone49);
        java.lang.Class<?> wildcardClass51 = timeZone49.getClass();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date16, timeZone49);
        long long53 = year52.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1577865599999L + "'", long35 == 1577865599999L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1577865599999L + "'", long44 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2019 + "'", int45 == 2019);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1562097599999L + "'", long53 == 1562097599999L);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod10, "hi!", "");
        int int14 = timePeriodValues13.getMinStartIndex();
        int int15 = timePeriodValues13.getItemCount();
        boolean boolean16 = simpleTimePeriod8.equals((java.lang.Object) timePeriodValues13);
        long long17 = simpleTimePeriod8.getStartMillis();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.next();
        java.util.Date date21 = regularTimePeriod20.getEnd();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year22.next();
        java.util.Date date25 = regularTimePeriod24.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(date21, date25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date21);
        long long28 = year27.getFirstMillisecond();
        boolean boolean29 = simpleTimePeriod8.equals((java.lang.Object) long28);
        long long30 = simpleTimePeriod8.getStartMillis();
        java.util.Date date31 = simpleTimePeriod8.getStart();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1609487999999L + "'", long17 == 1609487999999L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865600000L + "'", long28 == 1577865600000L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1609487999999L + "'", long30 == 1609487999999L);
        org.junit.Assert.assertNotNull(date31);
    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod4, "hi!", "");
//        boolean boolean8 = timePeriodValues7.isEmpty();
//        int int9 = timePeriodValues7.getMinEndIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timePeriodValues7.removeChangeListener(seriesChangeListener10);
//        int int12 = day0.compareTo((java.lang.Object) timePeriodValues7);
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//    }

//    @Test
//    public void test478() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test478");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        long long2 = day0.getFirstMillisecond();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate4);
//        java.lang.String str7 = day6.toString();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.Class<?> wildcardClass2 = year0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        long long4 = year0.getFirstMillisecond();
        int int5 = year0.getYear();
        java.util.Calendar calendar6 = null;
        try {
            year0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        java.lang.String str7 = timePeriodValues4.getDescription();
        java.lang.Object obj8 = timePeriodValues4.clone();
        timePeriodValues4.setNotify(true);
        timePeriodValues4.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener13);
        timePeriodValues4.fireSeriesChanged();
        try {
            timePeriodValues4.update((int) (byte) 100, (java.lang.Number) (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.Class<?> wildcardClass2 = year0.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.util.Date date4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date4, timeZone5);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year8.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year8, (double) 1593676799999L);
        java.lang.Class<?> wildcardClass13 = year8.getClass();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod17, "hi!", "");
        boolean boolean21 = timePeriodValues20.isEmpty();
        int int22 = year14.compareTo((java.lang.Object) boolean21);
        long long23 = year14.getLastMillisecond();
        java.util.Date date24 = year14.getStart();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getLastMillisecond();
        int int27 = year25.getYear();
        java.util.Date date28 = year25.getStart();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date28);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date28, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date24, timeZone31);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        long long35 = year34.getLastMillisecond();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year36.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod37, "hi!", "");
        boolean boolean41 = timePeriodValues40.isEmpty();
        int int42 = year34.compareTo((java.lang.Object) boolean41);
        long long43 = year34.getLastMillisecond();
        java.util.Date date44 = year34.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod(date24, date44);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date44);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date44);
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date44, timeZone48);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1577865599999L + "'", long35 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1577865599999L + "'", long43 == 1577865599999L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Time");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int10 = year9.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (short) 0);
        java.util.Date date13 = year9.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 1593676799999L);
        java.lang.Class<?> wildcardClass19 = year14.getClass();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getLastMillisecond();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod23, "hi!", "");
        boolean boolean27 = timePeriodValues26.isEmpty();
        int int28 = year20.compareTo((java.lang.Object) boolean27);
        long long29 = year20.getLastMillisecond();
        java.util.Date date30 = year20.getStart();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        long long32 = year31.getLastMillisecond();
        int int33 = year31.getYear();
        java.util.Date date34 = year31.getStart();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date34);
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date34, timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date30, timeZone37);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        int int41 = year40.getYear();
        java.lang.Class<?> wildcardClass42 = year40.getClass();
        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
        java.util.Date date44 = null;
        java.util.TimeZone timeZone45 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date44, timeZone45);
        java.lang.Class class47 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        long long49 = year48.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year48.next();
        java.util.Date date51 = regularTimePeriod50.getEnd();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        long long53 = year52.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year52.next();
        java.util.Date date55 = regularTimePeriod54.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod56 = new org.jfree.data.time.SimpleTimePeriod(date51, date55);
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date55, timeZone57);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date30, timeZone57);
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date13, timeZone57);
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date3, timeZone57);
        java.lang.String str62 = day61.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2019 + "'", int41 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(class43);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(class47);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1577865599999L + "'", long49 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1577865599999L + "'", long53 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "31-December-2020" + "'", str62.equals("31-December-2020"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
        boolean boolean14 = timePeriodValues4.equals((java.lang.Object) year11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) 1593676799999L);
        java.lang.Number number20 = timePeriodValue19.getValue();
        java.lang.Number number21 = timePeriodValue19.getValue();
        timePeriodValues4.add(timePeriodValue19);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) regularTimePeriod24, (java.lang.Number) 1577865599999L);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener27);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener29);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1.593676799999E12d + "'", number20.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1.593676799999E12d + "'", number21.equals(1.593676799999E12d));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int2 = day0.getMonth();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) 1593676799999L);
        java.lang.String str8 = timePeriodValue7.toString();
        boolean boolean9 = day0.equals((java.lang.Object) str8);
        org.jfree.data.time.SerialDate serialDate10 = day0.getSerialDate();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[2019,1.593676799999E12]" + "'", str8.equals("TimePeriodValue[2019,1.593676799999E12]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 0);
        java.lang.Number number4 = timePeriodValue3.getValue();
        java.lang.Number number5 = timePeriodValue3.getValue();
        java.lang.String str6 = timePeriodValue3.toString();
        java.lang.Object obj7 = timePeriodValue3.clone();
        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue3.getPeriod();
        java.lang.String str9 = timePeriodValue3.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TimePeriodValue[2019,0]" + "'", str6.equals("TimePeriodValue[2019,0]"));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(timePeriod8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TimePeriodValue[2019,0]" + "'", str9.equals("TimePeriodValue[2019,0]"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) 1593676799999L);
        timePeriodValues4.add(timePeriodValue10);
        java.lang.Class<?> wildcardClass12 = timePeriodValues4.getClass();
        try {
            timePeriodValues4.update((int) (short) 100, (java.lang.Number) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 1593676799999L);
        java.lang.Number number5 = timePeriodValue4.getValue();
        java.lang.Number number6 = timePeriodValue4.getValue();
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue4.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue4.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue4.getPeriod();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.593676799999E12d + "'", number5.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.593676799999E12d + "'", number6.equals(1.593676799999E12d));
        org.junit.Assert.assertNotNull(timePeriod7);
        org.junit.Assert.assertNotNull(timePeriod8);
        org.junit.Assert.assertNotNull(timePeriod9);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMaxEndIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.next();
        java.util.Date date9 = regularTimePeriod8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date9, date13);
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        timePeriodValues4.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (double) (byte) 1);
        long long18 = simpleTimePeriod14.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long18);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1609487999999L + "'", long18 == 1609487999999L);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        int int2 = day0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 12);
        java.util.Calendar calendar6 = null;
        try {
            day0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (short) 0);
        java.util.Date date4 = year0.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year5, (double) 1593676799999L);
        java.lang.Class<?> wildcardClass10 = year5.getClass();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod14, "hi!", "");
        boolean boolean18 = timePeriodValues17.isEmpty();
        int int19 = year11.compareTo((java.lang.Object) boolean18);
        long long20 = year11.getLastMillisecond();
        java.util.Date date21 = year11.getStart();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getLastMillisecond();
        int int24 = year22.getYear();
        java.util.Date date25 = year22.getStart();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date25);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date25, timeZone28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date21, timeZone28);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        int int32 = year31.getYear();
        java.lang.Class<?> wildcardClass33 = year31.getClass();
        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
        java.util.Date date35 = null;
        java.util.TimeZone timeZone36 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date35, timeZone36);
        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        long long40 = year39.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year39.next();
        java.util.Date date42 = regularTimePeriod41.getEnd();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        long long44 = year43.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year43.next();
        java.util.Date date46 = regularTimePeriod45.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod(date42, date46);
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date46, timeZone48);
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date21, timeZone48);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date4, timeZone48);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(class34);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(class38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1577865599999L + "'", long44 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test492");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
//        java.util.Date date3 = regularTimePeriod2.getEnd();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        long long5 = year4.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
//        java.util.Date date7 = regularTimePeriod6.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
//        long long12 = day10.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate13 = day10.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day10.next();
//        long long15 = day10.getSerialIndex();
//        long long16 = day10.getFirstMillisecond();
//        java.util.Date date17 = day10.getEnd();
//        int int18 = day9.compareTo((java.lang.Object) day10);
//        long long19 = day10.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43629L + "'", long15 == 43629L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560409200000L + "'", long16 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 567 + "'", int18 == 567);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560409200000L + "'", long19 == 1560409200000L);
//    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.String str5 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str5.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1577865600000L);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 1577865600000L + "'", obj2.equals(1577865600000L));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        int int6 = timePeriodValues4.getMaxStartIndex();
        timePeriodValues4.setKey((java.lang.Comparable) 1577865599999L);
        timePeriodValues4.setDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
        boolean boolean14 = timePeriodValues4.equals((java.lang.Object) year11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) 1593676799999L);
        java.lang.Number number20 = timePeriodValue19.getValue();
        java.lang.Number number21 = timePeriodValue19.getValue();
        timePeriodValues4.add(timePeriodValue19);
        int int23 = timePeriodValues4.getMaxStartIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod25 = timePeriodValues4.getTimePeriod(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1.593676799999E12d + "'", number20.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1.593676799999E12d + "'", number21.equals(1.593676799999E12d));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Object obj8 = timePeriodValues4.clone();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod12, "hi!", "");
        boolean boolean16 = timePeriodValues15.isEmpty();
        int int17 = year9.compareTo((java.lang.Object) boolean16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year9.previous();
        timePeriodValues4.setKey((java.lang.Comparable) year9);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues4);
        java.lang.String str21 = seriesChangeEvent20.toString();
        java.lang.String str22 = seriesChangeEvent20.toString();
        java.lang.Object obj23 = seriesChangeEvent20.getSource();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        boolean boolean5 = timePeriodValues4.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Object obj8 = timePeriodValues4.clone();
        timePeriodValues4.setDomainDescription("");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.next();
        timePeriodValues4.setKey((java.lang.Comparable) year11);
        int int14 = year11.getYear();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = year11.getMiddleMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 1593676799999L);
        java.lang.Number number5 = null;
        timePeriodValue4.setValue(number5);
        java.lang.Object obj7 = timePeriodValue4.clone();
        java.lang.Number number8 = timePeriodValue4.getValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod1, "hi!", "");
        int int5 = timePeriodValues4.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues4.getMinEndIndex();
        timePeriodValues4.fireSeriesChanged();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) (short) 100, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }
}

