import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.shift(range0, (double) '#', false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean1 = categoryAxis3D0.isTickLabelsVisible();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            double double6 = categoryAxis3D0.getCategoryMiddle(0, (int) (byte) -1, rectangle2D4, rectangleEdge5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.Rotation rotation1 = null;
        try {
            ringPlot0.setDirection(rotation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'direction' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        java.awt.Paint paint3 = null;
        try {
            ringPlot0.setBaseSectionOutlinePaint(paint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(0.0d, (double) 10L, (double) (byte) 1, 100.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color1 = java.awt.Color.BLUE;
        categoryAxis3D0.setTickLabelPaint((java.awt.Paint) color1);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            double double7 = categoryAxis3D0.getCategoryEnd(0, (int) (short) -1, rectangle2D5, rectangleEdge6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean1 = categoryAxis3D0.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot2 = categoryAxis3D0.getPlot();
        java.lang.String str3 = categoryAxis3D0.getLabelToolTip();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color1 = java.awt.Color.BLUE;
        categoryAxis3D0.setTickLabelPaint((java.awt.Paint) color1);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean8 = rectangleEdge6.equals((java.lang.Object) 10L);
        try {
            double double9 = categoryAxis3D0.getCategoryMiddle((int) ' ', 2, rectangle2D5, rectangleEdge6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (java.lang.Comparable) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("hi!", "hi!");
        java.lang.String str3 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, (double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer1 = polarPlot0.getRenderer();
        org.junit.Assert.assertNull(polarItemRenderer1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (byte) 1, 0.0d, (double) '#', (double) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        double double3 = ringPlot0.getOuterSeparatorExtension();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        ringPlot4.setIgnoreNullValues(true);
        java.awt.Stroke stroke7 = ringPlot4.getSeparatorStroke();
        ringPlot0.setLabelLinkStroke(stroke7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.Point2D point2D11 = null;
        org.jfree.chart.plot.PlotState plotState12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            ringPlot0.draw(graphics2D9, rectangle2D10, point2D11, plotState12, plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = null;
        try {
            ringPlot0.setLabelDistributor(abstractPieLabelDistributor2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis2 = polarPlot0.getAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        try {
            polarPlot0.zoomRangeAxes(0.2d, plotRenderingInfo4, point2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(valueAxis2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, (float) 10, (float) (byte) 100, (double) '#', (float) 'a', (float) 1);
        org.junit.Assert.assertNull(shape7);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        ringPlot0.setBackgroundAlpha((float) (-1));
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            ringPlot0.drawBackground(graphics2D4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("hi!", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = ringPlot0.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNull(pieSectionLabelGenerator1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean6 = rectangleEdge4.equals((java.lang.Object) 10L);
        try {
            double double7 = numberAxis1.valueToJava2D((double) ' ', rectangle2D3, rectangleEdge4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        try {
            textBlock0.setLineAlignment(horizontalAlignment1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, (double) (short) -1);
        org.jfree.chart.block.BlockContainer blockContainer5 = null;
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = null;
        try {
            org.jfree.chart.util.Size2D size2D8 = flowArrangement4.arrange(blockContainer5, graphics2D6, rectangleConstraint7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range3 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint4 = polarPlot0.getRadiusGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        try {
            polarPlot0.zoomRangeAxes((double) 10, plotRenderingInfo6, point2D7, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.data.RangeType rangeType2 = null;
        try {
            numberAxis1.setRangeType(rangeType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        java.awt.Stroke stroke3 = ringPlot0.getSeparatorStroke();
        double double4 = ringPlot0.getMinimumArcAngleToDraw();
        ringPlot0.setLabelLinksVisible(true);
        boolean boolean7 = ringPlot0.getLabelLinksVisible();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-5d + "'", double4 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range3 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        dateAxis6.setAutoTickUnitSelection(true, false);
        java.util.Date date11 = dateAxis6.getMaximumDate();
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = polarPlot12.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range15 = polarPlot12.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis14);
        dateAxis14.setAutoTickUnitSelection(true, false);
        java.util.Date date19 = dateAxis14.getMaximumDate();
        try {
            dateAxis2.setRange(date11, date19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis2 = polarPlot0.getAxis();
        polarPlot0.removeCornerTextItem("hi!");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        try {
            polarPlot0.zoomRangeAxes((double) (-1.0f), plotRenderingInfo6, point2D7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(valueAxis2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        java.awt.Stroke stroke3 = ringPlot0.getSeparatorStroke();
        double double4 = ringPlot0.getMinimumArcAngleToDraw();
        java.lang.Comparable comparable5 = null;
        try {
            java.awt.Paint paint6 = ringPlot0.getSectionPaint(comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-5d + "'", double4 == 1.0E-5d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        java.awt.Stroke stroke3 = ringPlot0.getSeparatorStroke();
        double double5 = ringPlot0.getExplodePercent((java.lang.Comparable) '#');
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.data.KeyToGroupMap keyToGroupMap20 = null;
        try {
            org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset19, keyToGroupMap20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = null;
        try {
            polarPlot0.setInsets(rectangleInsets2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange((double) 100);
        double double3 = dateAxis0.getFixedAutoRange();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        dateAxis6.setAutoTickUnitSelection(true, false);
        java.util.Date date11 = dateAxis6.getMaximumDate();
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = polarPlot12.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range15 = polarPlot12.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis14);
        dateAxis14.setAutoTickUnitSelection(true, false);
        java.util.Date date19 = dateAxis14.getMaximumDate();
        try {
            dateAxis0.setRange(date11, date19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.awt.Color color0 = java.awt.Color.black;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getUpperMargin();
        java.awt.Font font3 = null;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 1.0E-8d, font3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "TextAnchor.BOTTOM_LEFT", "hi!", "TextAnchor.BOTTOM_LEFT", "hi!");
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        java.awt.Shape shape3 = numberAxis1.getDownArrow();
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range3 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis2);
        dateAxis2.setAutoTickUnitSelection(true, false);
        java.util.Date date7 = dateAxis2.getMaximumDate();
        boolean boolean8 = dateAxis2.isTickMarksVisible();
        double double9 = dateAxis2.getFixedAutoRange();
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        double double11 = ringPlot10.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = ringPlot10.getLabelPadding();
        ringPlot10.setMaximumLabelWidth((double) 0);
        double double15 = ringPlot10.getInnerSeparatorExtension();
        dateAxis2.setPlot((org.jfree.chart.plot.Plot) ringPlot10);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.2d + "'", double15 == 0.2d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        valueMarker1.setValue(0.05d);
        java.awt.Paint paint4 = null;
        try {
            valueMarker1.setPaint(paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getMaximumExplodePercent();
        ringPlot1.setBackgroundAlpha((float) (-1));
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot1);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        ringPlot1.setLabelFont(font6);
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font6);
        java.awt.Graphics2D graphics2D9 = null;
        try {
            org.jfree.chart.util.Size2D size2D10 = textLine8.calculateDimensions(graphics2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("TextAnchor.BOTTOM_LEFT");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        boolean boolean7 = textAnchor5.equals((java.lang.Object) (byte) 10);
        try {
            textLine1.draw(graphics2D2, (-1.0f), 10.0f, textAnchor5, (float) (short) 100, 100.0f, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, (double) (short) -1);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.block.Arrangement arrangement6 = null;
        try {
            blockContainer5.setArrangement(arrangement6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("hi!", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        polarPlot0.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        double double6 = categoryAxis3D5.getCategoryMargin();
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = polarPlot12.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis14 = polarPlot12.getAxis();
        polarPlot12.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("hi!", font11, (org.jfree.chart.plot.Plot) polarPlot12, true);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("hi!", font11);
        java.awt.geom.Rectangle2D rectangle2D20 = textTitle19.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double22 = categoryAxis3D5.getCategoryStart((int) (short) 10, (int) '4', rectangle2D20, rectangleEdge21);
        try {
            polarPlot0.drawOutline(graphics2D4, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Pie Plot", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        java.awt.Stroke stroke3 = ringPlot0.getSeparatorStroke();
        double double4 = ringPlot0.getMinimumArcAngleToDraw();
        double double5 = ringPlot0.getSectionDepth();
        ringPlot0.setForegroundAlpha(0.5f);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = ringPlot0.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = ringPlot0.getToolTipGenerator();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-5d + "'", double4 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener9 = null;
        jFreeChart8.removeProgressListener(chartProgressListener9);
        try {
            org.jfree.chart.plot.XYPlot xYPlot11 = jFreeChart8.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PolarPlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color1 = java.awt.Color.BLUE;
        categoryAxis3D0.setTickLabelPaint((java.awt.Paint) color1);
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis3D0.setTickLabelFont((java.lang.Comparable) 10.0f, font4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        ringPlot7.setIgnoreNullValues(true);
        java.awt.Stroke stroke10 = ringPlot7.getSeparatorStroke();
        double double11 = ringPlot7.getMinimumArcAngleToDraw();
        double double12 = ringPlot7.getSectionDepth();
        ringPlot7.setForegroundAlpha(0.5f);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = ringPlot7.getDrawingSupplier();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        double double17 = categoryAxis3D16.getCategoryMargin();
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = polarPlot23.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis25 = polarPlot23.getAxis();
        polarPlot23.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("hi!", font22, (org.jfree.chart.plot.Plot) polarPlot23, true);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("hi!", font22);
        java.awt.geom.Rectangle2D rectangle2D31 = textTitle30.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double33 = categoryAxis3D16.getCategoryStart((int) (short) 10, (int) '4', rectangle2D31, rectangleEdge32);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean36 = rectangleEdge34.equals((java.lang.Object) 10L);
        org.jfree.chart.axis.AxisSpace axisSpace37 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace38 = categoryAxis3D0.reserveSpace(graphics2D6, (org.jfree.chart.plot.Plot) ringPlot7, rectangle2D31, rectangleEdge34, axisSpace37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0E-5d + "'", double11 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis2 = polarPlot0.getAxis();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        polarPlot0.drawBackgroundImage(graphics2D3, rectangle2D4);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        polarPlot0.setRenderer(polarItemRenderer6);
        java.awt.Paint paint8 = polarPlot0.getOutlinePaint();
        try {
            polarPlot0.zoom((double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double double0 = org.jfree.chart.plot.PolarPlot.DEFAULT_ANGLE_TICK_UNIT_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 45.0d + "'", double0 == 45.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        try {
            xYPlot14.setRangeAxisLocation(axisLocation16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        ringPlot0.setBackgroundAlpha((float) (-1));
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.plot.Plot plot5 = plotChangeEvent4.getPlot();
        org.jfree.chart.plot.Plot plot6 = plotChangeEvent4.getPlot();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = plotChangeEvent4.getType();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        ringPlot0.setShadowYOffset((double) 100.0f);
        java.awt.Paint paint5 = ringPlot0.getShadowPaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        double double3 = ringPlot0.getInnerSeparatorExtension();
        ringPlot0.setOuterSeparatorExtension(0.0d);
        java.awt.Paint paint6 = ringPlot0.getLabelOutlinePaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator1 = null;
        ringPlot0.setURLGenerator(pieURLGenerator1);
        boolean boolean3 = ringPlot0.isOutlineVisible();
        ringPlot0.setMinimumArcAngleToDraw(0.0d);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator6 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator6);
        java.lang.Object obj8 = standardPieSectionLabelGenerator6.clone();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundAlpha((float) (-1));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        try {
            polarPlot0.zoomRangeAxes(0.0d, 0.025d, plotRenderingInfo5, point2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        double double3 = ringPlot0.getInnerSeparatorExtension();
        ringPlot0.setOuterSeparatorExtension(0.0d);
        org.jfree.chart.util.Rotation rotation6 = ringPlot0.getDirection();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor8 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) -1);
        ringPlot0.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor8);
        pieLabelDistributor8.clear();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(rotation6);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        valueMarker1.setValue(0.05d);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType4 = null;
        try {
            valueMarker1.setLabelOffsetType(lengthAdjustmentType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        java.awt.Stroke stroke2 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis2 = polarPlot0.getAxis();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        polarPlot0.drawBackgroundImage(graphics2D3, rectangle2D4);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        polarPlot0.setRenderer(polarItemRenderer6);
        java.awt.Paint paint8 = polarPlot0.getOutlinePaint();
        java.awt.Image image9 = polarPlot0.getBackgroundImage();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(image9);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        double double3 = ringPlot0.getInnerSeparatorExtension();
        int int4 = ringPlot0.getBackgroundImageAlignment();
        org.jfree.data.general.PieDataset pieDataset5 = ringPlot0.getDataset();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = ringPlot0.getToolTipGenerator();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(pieDataset5);
        org.junit.Assert.assertNull(pieToolTipGenerator6);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        java.awt.Stroke stroke3 = ringPlot0.getSeparatorStroke();
        double double4 = ringPlot0.getMinimumArcAngleToDraw();
        ringPlot0.setCircular(true, false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-5d + "'", double4 == 1.0E-5d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double1 = range0.getUpperBound();
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range0, (double) 'a');
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart8.removeProgressListener(chartProgressListener11);
        int int13 = jFreeChart8.getSubtitleCount();
        jFreeChart8.clearSubtitles();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        jFreeChart8.setBorderPaint((java.awt.Paint) color15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D();
        double double19 = categoryAxis3D18.getCategoryMargin();
        java.awt.Font font24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis27 = polarPlot25.getAxis();
        polarPlot25.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart31 = new org.jfree.chart.JFreeChart("hi!", font24, (org.jfree.chart.plot.Plot) polarPlot25, true);
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("hi!", font24);
        java.awt.geom.Rectangle2D rectangle2D33 = textTitle32.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double35 = categoryAxis3D18.getCategoryStart((int) (short) 10, (int) '4', rectangle2D33, rectangleEdge34);
        java.awt.geom.Point2D point2D36 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo37 = null;
        try {
            jFreeChart8.draw(graphics2D17, rectangle2D33, point2D36, chartRenderingInfo37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.2d + "'", double19 == 0.2d);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range3 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis2);
        dateAxis2.setAutoTickUnitSelection(true, false);
        boolean boolean7 = dateAxis2.isAutoTickUnitSelection();
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = polarPlot8.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range11 = polarPlot8.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis10);
        dateAxis10.setAutoTickUnitSelection(true, false);
        java.util.Date date15 = dateAxis10.getMaximumDate();
        java.util.Date date16 = null;
        try {
            dateAxis2.setRange(date15, date16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) '4', (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        java.awt.Stroke stroke3 = ringPlot0.getSeparatorStroke();
        double double4 = ringPlot0.getMinimumArcAngleToDraw();
        double double5 = ringPlot0.getSectionDepth();
        ringPlot0.setForegroundAlpha(0.5f);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        double double10 = categoryAxis9.getUpperMargin();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        double double14 = categoryAxis3D13.getCategoryMargin();
        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = polarPlot20.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis22 = polarPlot20.getAxis();
        polarPlot20.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("hi!", font19, (org.jfree.chart.plot.Plot) polarPlot20, true);
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("hi!", font19);
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle27.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double30 = categoryAxis3D13.getCategoryStart((int) (short) 10, (int) '4', rectangle2D28, rectangleEdge29);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double32 = categoryAxis9.getCategoryEnd(15, (int) '4', rectangle2D28, rectangleEdge31);
        ringPlot0.drawBackgroundImage(graphics2D8, rectangle2D28);
        ringPlot0.setIgnoreZeroValues(false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-5d + "'", double4 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range3 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        try {
            polarPlot0.zoomRangeAxes((double) (byte) 100, plotRenderingInfo5, point2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange((double) 100);
        boolean boolean3 = dateAxis0.isTickMarksVisible();
        org.jfree.data.Range range4 = dateAxis0.getRange();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        double double3 = ringPlot2.getMaximumExplodePercent();
        ringPlot2.setBackgroundAlpha((float) (-1));
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot2);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        ringPlot2.setLabelFont(font7);
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("", font7);
        java.awt.Paint paint10 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("http://www.jfree.org/jfreechart/index.html", font7, paint10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) (byte) 0, 10.0f, textAnchor4, (double) 0, (float) 100, (float) (byte) 10);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        double double3 = rectangleInsets2.getRight();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets2.createOutsetRectangle(rectangle2D4, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isRangeGridlinesVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        int int17 = xYPlot14.getIndexOf(xYItemRenderer16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = xYPlot14.getRenderer((int) (byte) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot14.zoomDomainAxes((double) 10, (double) (byte) 10, plotRenderingInfo22, point2D23);
        org.jfree.data.xy.XYDataset xYDataset25 = xYPlot14.getDataset();
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        valueMarker27.setValue(0.05d);
        try {
            boolean boolean30 = xYPlot14.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(xYItemRenderer19);
        org.junit.Assert.assertNull(xYDataset25);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        java.awt.Image image9 = null;
        jFreeChart8.setBackgroundImage(image9);
        jFreeChart8.setBackgroundImageAlpha((float) 8);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart8.removeProgressListener(chartProgressListener11);
        int int13 = jFreeChart8.getSubtitleCount();
        jFreeChart8.clearSubtitles();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        jFreeChart8.setBorderPaint((java.awt.Paint) color15);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot17 = jFreeChart8.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PolarPlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        double double17 = ringPlot16.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = ringPlot16.getLabelPadding();
        double double19 = rectangleInsets18.getRight();
        double double21 = rectangleInsets18.trimHeight((double) (byte) 1);
        xYPlot14.setInsets(rectangleInsets18);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis27 = polarPlot25.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = polarPlot28.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range31 = polarPlot28.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis30);
        polarPlot25.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis30);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat35 = numberAxis34.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit36 = numberAxis34.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis30, (org.jfree.chart.axis.ValueAxis) numberAxis34, xYItemRenderer37);
        boolean boolean39 = xYPlot38.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation40 = xYPlot38.getDomainAxisLocation();
        try {
            xYPlot14.setRangeAxisLocation((int) (short) -1, axisLocation40, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-3.0d) + "'", double21 == (-3.0d));
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNull(range31);
        org.junit.Assert.assertNull(numberFormat35);
        org.junit.Assert.assertNotNull(numberTickUnit36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(axisLocation40);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo1);
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        projectInfo1.addLibrary((org.jfree.chart.ui.Library) projectInfo3);
        java.awt.Image image5 = null;
        projectInfo3.setLogo(image5);
        java.lang.String str7 = projectInfo3.getVersion();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.2.0-pre" + "'", str7.equals("1.2.0-pre"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range3 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis2);
        dateAxis2.setAutoTickUnitSelection(true, false);
        java.util.Date date7 = dateAxis2.getMaximumDate();
        boolean boolean8 = dateAxis2.isTickMarksVisible();
        java.lang.String str9 = dateAxis2.getLabel();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        double double12 = ringPlot11.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = ringPlot11.getLabelPadding();
        java.lang.Object obj14 = ringPlot11.clone();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        ringPlot11.handleClick(15, 15, plotRenderingInfo17);
        java.awt.Paint paint19 = ringPlot11.getBaseSectionOutlinePaint();
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = polarPlot23.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis25 = polarPlot23.getAxis();
        polarPlot23.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("hi!", font22, (org.jfree.chart.plot.Plot) polarPlot23, true);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("hi!", font22);
        textTitle30.setPadding((double) (short) 10, (-1.0d), 0.2d, (double) '#');
        java.awt.geom.Rectangle2D rectangle2D36 = textTitle30.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double38 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D36, rectangleEdge37);
        java.awt.Font font41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot42 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = polarPlot42.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis44 = polarPlot42.getAxis();
        polarPlot42.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart48 = new org.jfree.chart.JFreeChart("hi!", font41, (org.jfree.chart.plot.Plot) polarPlot42, true);
        org.jfree.chart.title.TextTitle textTitle49 = new org.jfree.chart.title.TextTitle("hi!", font41);
        textTitle49.setPadding((double) (short) 10, (-1.0d), 0.2d, (double) '#');
        java.awt.geom.Rectangle2D rectangle2D55 = textTitle49.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double57 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D55, rectangleEdge56);
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace59 = dateAxis2.reserveSpace(graphics2D10, (org.jfree.chart.plot.Plot) ringPlot11, rectangle2D36, rectangleEdge56, axisSpace58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNull(valueAxis44);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.util.SortOrder sortOrder35 = null;
        try {
            categoryPlot34.setRowRenderingOrder(sortOrder35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.title.LegendTitle legendTitle11 = null;
        try {
            jFreeChart8.addLegend(legendTitle11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        org.jfree.chart.LegendItemCollection legendItemCollection39 = categoryPlot34.getFixedLegendItems();
        java.lang.String str40 = categoryPlot34.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.plot.PolarPlot polarPlot43 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = polarPlot43.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis45 = polarPlot43.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot46 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = polarPlot46.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range49 = polarPlot46.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis48);
        polarPlot43.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis48);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat53 = numberAxis52.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit54 = numberAxis52.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer55 = null;
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot(xYDataset42, (org.jfree.chart.axis.ValueAxis) dateAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis52, xYItemRenderer55);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer57 = xYPlot56.getRenderer();
        xYPlot56.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer60 = null;
        java.util.Collection collection61 = xYPlot56.getDomainMarkers(layer60);
        org.jfree.chart.plot.ValueMarker valueMarker63 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot56.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker63);
        org.jfree.chart.util.Layer layer65 = null;
        try {
            boolean boolean66 = categoryPlot34.removeRangeMarker(3, (org.jfree.chart.plot.Marker) valueMarker63, layer65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNull(legendItemCollection39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Category Plot" + "'", str40.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNull(valueAxis45);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertNull(numberFormat53);
        org.junit.Assert.assertNotNull(numberTickUnit54);
        org.junit.Assert.assertNull(xYItemRenderer57);
        org.junit.Assert.assertNull(collection61);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        ringPlot2.setIgnoreNullValues(true);
        double double5 = ringPlot2.getInnerSeparatorExtension();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat8 = numberAxis7.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = numberAxis7.getTickUnit();
        ringPlot2.setExplodePercent((java.lang.Comparable) numberTickUnit9, (double) 2);
        numberAxis1.setTickUnit(numberTickUnit9, false, false);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D();
        double double18 = categoryAxis3D17.getCategoryMargin();
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = polarPlot24.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis26 = polarPlot24.getAxis();
        polarPlot24.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("hi!", font23, (org.jfree.chart.plot.Plot) polarPlot24, true);
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle("hi!", font23);
        java.awt.geom.Rectangle2D rectangle2D32 = textTitle31.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double34 = categoryAxis3D17.getCategoryStart((int) (short) 10, (int) '4', rectangle2D32, rectangleEdge33);
        try {
            double double35 = numberAxis1.valueToJava2D((double) 100.0f, rectangle2D16, rectangleEdge33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(numberTickUnit9);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.2d + "'", double18 == 0.2d);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        xYPlot14.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getCategoryMargin();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = polarPlot7.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis9 = polarPlot7.getAxis();
        polarPlot7.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("hi!", font6, (org.jfree.chart.plot.Plot) polarPlot7, true);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("hi!", font6);
        java.awt.geom.Rectangle2D rectangle2D15 = textTitle14.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double17 = categoryAxis3D0.getCategoryStart((int) (short) 10, (int) '4', rectangle2D15, rectangleEdge16);
        java.awt.Font font19 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        categoryAxis3D0.setTickLabelFont((java.lang.Comparable) 100.0f, font19);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isRangeGridlinesVisible();
        java.awt.Stroke stroke16 = xYPlot14.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        org.jfree.chart.util.Layer layer19 = null;
        try {
            boolean boolean20 = xYPlot14.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker18, layer19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = polarPlot3.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis5 = polarPlot3.getAxis();
        polarPlot3.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", font2, (org.jfree.chart.plot.Plot) polarPlot3, true);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font2);
        textTitle10.setPadding((double) (short) 10, (-1.0d), 0.2d, (double) '#');
        textTitle10.setMargin((double) '4', 0.0d, (double) (short) 1, 0.0d);
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = textTitle10.getVerticalAlignment();
        textTitle10.setURLText("");
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(verticalAlignment21);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, (double) (short) -1);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        blockContainer5.clear();
        double double7 = blockContainer5.getHeight();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        ringPlot9.setIgnoreNullValues(true);
        java.awt.Stroke stroke12 = ringPlot9.getSeparatorStroke();
        double double13 = ringPlot9.getMinimumArcAngleToDraw();
        double double14 = ringPlot9.getSectionDepth();
        ringPlot9.setForegroundAlpha(0.5f);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        double double19 = categoryAxis18.getUpperMargin();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D22 = new org.jfree.chart.axis.CategoryAxis3D();
        double double23 = categoryAxis3D22.getCategoryMargin();
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = polarPlot29.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis31 = polarPlot29.getAxis();
        polarPlot29.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("hi!", font28, (org.jfree.chart.plot.Plot) polarPlot29, true);
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("hi!", font28);
        java.awt.geom.Rectangle2D rectangle2D37 = textTitle36.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double39 = categoryAxis3D22.getCategoryStart((int) (short) 10, (int) '4', rectangle2D37, rectangleEdge38);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double41 = categoryAxis18.getCategoryEnd(15, (int) '4', rectangle2D37, rectangleEdge40);
        ringPlot9.drawBackgroundImage(graphics2D17, rectangle2D37);
        try {
            java.lang.Object obj44 = blockContainer5.draw(graphics2D8, rectangle2D37, (java.lang.Object) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0E-5d + "'", double13 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNull(valueAxis31);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setCategoryMargin((double) (short) -1);
        float float3 = categoryAxis3D0.getMaximumCategoryLabelWidthRatio();
        java.lang.Comparable comparable4 = null;
        try {
            categoryAxis3D0.addCategoryLabelToolTip(comparable4, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        java.lang.Object obj3 = ringPlot0.clone();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        ringPlot0.handleClick(15, 15, plotRenderingInfo6);
        double double8 = ringPlot0.getShadowYOffset();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator1 = null;
        ringPlot0.setURLGenerator(pieURLGenerator1);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        ringPlot0.setLegendLabelURLGenerator(pieURLGenerator3);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setLowerMargin((double) (short) 10);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers(layer18);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot14.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        xYPlot14.setRenderer(xYItemRenderer23);
        java.awt.Paint paint25 = xYPlot14.getDomainTickBandPaint();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNull(paint25);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        java.lang.Object obj3 = ringPlot0.clone();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        ringPlot0.handleClick(15, 15, plotRenderingInfo6);
        ringPlot0.setForegroundAlpha(0.0f);
        java.awt.Paint paint10 = ringPlot0.getBaseSectionOutlinePaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = polarPlot3.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis5 = polarPlot3.getAxis();
        polarPlot3.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", font2, (org.jfree.chart.plot.Plot) polarPlot3, true);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font2);
        textTitle10.setPadding((double) (short) 10, (-1.0d), 0.2d, (double) '#');
        java.awt.geom.Rectangle2D rectangle2D16 = textTitle10.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16);
        java.awt.Shape shape18 = chartEntity17.getArea();
        java.awt.Shape shape19 = chartEntity17.getArea();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = polarPlot6.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis8 = polarPlot6.getAxis();
        polarPlot6.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("hi!", font5, (org.jfree.chart.plot.Plot) polarPlot6, true);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("hi!", font5);
        textTitle13.setPadding((double) (short) 10, (-1.0d), 0.2d, (double) '#');
        java.awt.geom.Rectangle2D rectangle2D19 = textTitle13.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double21 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D19, rectangleEdge20);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        try {
            org.jfree.chart.axis.AxisState axisState25 = numberAxis0.draw(graphics2D1, (double) 0, rectangle2D19, rectangle2D22, rectangleEdge23, plotRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.util.Rotation rotation1 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = polarPlot5.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range8 = polarPlot5.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis7);
        polarPlot2.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis7);
        boolean boolean10 = rotation1.equals((java.lang.Object) polarPlot2);
        double double11 = polarPlot2.getMaxRadius();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot2);
        java.awt.Paint paint13 = polarPlot2.getAngleLabelPaint();
        org.jfree.chart.axis.ValueAxis valueAxis14 = polarPlot2.getAxis();
        valueAxis14.setTickMarkInsideLength((float) 'a');
        org.junit.Assert.assertNotNull(rotation1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(valueAxis14);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo1);
        projectInfo1.setCopyright("http://www.jfree.org/jfreechart/index.html");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection16 = xYPlot14.getLegendItems();
        org.jfree.chart.LegendItem legendItem17 = null;
        legendItemCollection16.add(legendItem17);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNotNull(legendItemCollection16);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setCategoryMargin((double) (short) -1);
        java.awt.Paint paint3 = categoryAxis3D0.getTickMarkPaint();
        double double4 = categoryAxis3D0.getUpperMargin();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color2 = java.awt.Color.BLUE;
        categoryAxis3D1.setTickLabelPaint((java.awt.Paint) color2);
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis3D1.setTickLabelFont((java.lang.Comparable) 10.0f, font5);
        piePlot0.setLabelFont(font5);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart8.removeProgressListener(chartProgressListener11);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart8.getLegend((int) (byte) 100);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart8.getLegend();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle15.setLegendItemGraphicLocation(rectangleAnchor16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D();
        double double20 = categoryAxis3D19.getCategoryMargin();
        java.awt.Font font25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = polarPlot26.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis28 = polarPlot26.getAxis();
        polarPlot26.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart("hi!", font25, (org.jfree.chart.plot.Plot) polarPlot26, true);
        org.jfree.chart.title.TextTitle textTitle33 = new org.jfree.chart.title.TextTitle("hi!", font25);
        java.awt.geom.Rectangle2D rectangle2D34 = textTitle33.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double36 = categoryAxis3D19.getCategoryStart((int) (short) 10, (int) '4', rectangle2D34, rectangleEdge35);
        org.jfree.chart.plot.RingPlot ringPlot37 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator38 = null;
        ringPlot37.setURLGenerator(pieURLGenerator38);
        boolean boolean40 = ringPlot37.isOutlineVisible();
        double double41 = ringPlot37.getInteriorGap();
        try {
            java.lang.Object obj42 = legendTitle15.draw(graphics2D18, rectangle2D34, (java.lang.Object) ringPlot37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertNotNull(legendTitle15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.2d + "'", double20 == 0.2d);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.08d + "'", double41 == 0.08d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        ringPlot0.setBackgroundAlpha((float) (-1));
        boolean boolean4 = ringPlot0.getLabelLinksVisible();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 10, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        xYPlot14.clearRangeMarkers();
        java.awt.Font font16 = xYPlot14.getNoDataMessageFont();
        java.awt.geom.Point2D point2D17 = null;
        try {
            xYPlot14.setQuadrantOrigin(point2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = polarPlot3.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis5 = polarPlot3.getAxis();
        polarPlot3.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", font2, (org.jfree.chart.plot.Plot) polarPlot3, true);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = textTitle10.getTextAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle10.setHorizontalAlignment(horizontalAlignment12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = textTitle10.getPosition();
        java.lang.String str15 = textTitle10.getToolTipText();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = null;
        try {
            org.jfree.chart.util.Size2D size2D18 = textTitle10.arrange(graphics2D16, rectangleConstraint17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getUpperMargin();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D4 = new org.jfree.chart.axis.CategoryAxis3D();
        double double5 = categoryAxis3D4.getCategoryMargin();
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = polarPlot11.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis13 = polarPlot11.getAxis();
        polarPlot11.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("hi!", font10, (org.jfree.chart.plot.Plot) polarPlot11, true);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("hi!", font10);
        java.awt.geom.Rectangle2D rectangle2D19 = textTitle18.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double21 = categoryAxis3D4.getCategoryStart((int) (short) 10, (int) '4', rectangle2D19, rectangleEdge20);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double23 = categoryAxis0.getCategoryEnd(15, (int) '4', rectangle2D19, rectangleEdge22);
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundAlpha((float) (-1));
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = polarPlot0.getLegendItems();
        org.junit.Assert.assertNotNull(legendItemCollection4);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis2 = polarPlot0.getAxis();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        polarPlot0.drawBackgroundImage(graphics2D3, rectangle2D4);
        polarPlot0.setAngleGridlinesVisible(false);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(valueAxis2);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Color color2 = java.awt.Color.getColor("TextAnchor.BOTTOM_LEFT", color1);
        java.awt.color.ColorSpace colorSpace3 = null;
        float[] floatArray7 = new float[] { (-1), 15, (short) 10 };
        try {
            float[] floatArray8 = color1.getComponents(colorSpace3, floatArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray7);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        double double3 = ringPlot0.getInnerSeparatorExtension();
        ringPlot0.setOuterSeparatorExtension(0.0d);
        org.jfree.chart.util.Rotation rotation6 = ringPlot0.getDirection();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor8 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) -1);
        ringPlot0.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor8);
        pieLabelDistributor8.distributeLabels(1.0d, (double) 0.5f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(rotation6);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.awt.Paint paint0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isRangeGridlinesVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        int int17 = xYPlot14.getIndexOf(xYItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = polarPlot20.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis22 = polarPlot20.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = polarPlot23.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range26 = polarPlot23.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis25);
        polarPlot20.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis25);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat30 = numberAxis29.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit31 = numberAxis29.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) dateAxis25, (org.jfree.chart.axis.ValueAxis) numberAxis29, xYItemRenderer32);
        boolean boolean34 = xYPlot33.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot33.getDomainAxisLocation();
        try {
            xYPlot14.setDomainAxisLocation((-1), axisLocation35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNull(numberFormat30);
        org.junit.Assert.assertNotNull(numberTickUnit31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(axisLocation35);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range3 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis2);
        dateAxis2.setAutoTickUnitSelection(true, false);
        java.util.Date date7 = dateAxis2.getMaximumDate();
        boolean boolean8 = dateAxis2.isTickMarksVisible();
        java.awt.Font font9 = dateAxis2.getLabelFont();
        dateAxis2.resizeRange((double) 0.5f, 45.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition13 = null;
        try {
            dateAxis2.setTickMarkPosition(dateTickMarkPosition13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range3 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        org.jfree.chart.title.LegendTitle legendTitle5 = jFreeChart4.getLegend();
        try {
            org.jfree.chart.title.Title title7 = jFreeChart4.getSubtitle((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(legendTitle5);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isRangeGridlinesVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        int int17 = xYPlot14.getIndexOf(xYItemRenderer16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = xYPlot14.getRenderer((int) (byte) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot14.zoomDomainAxes((double) 10, (double) (byte) 10, plotRenderingInfo22, point2D23);
        java.awt.Stroke stroke25 = null;
        try {
            xYPlot14.setDomainCrosshairStroke(stroke25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(xYItemRenderer19);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers(layer18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = null;
        xYPlot14.setDomainAxisLocation(15, axisLocation21, false);
        xYPlot14.setDomainCrosshairVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace26 = xYPlot14.getFixedRangeAxisSpace();
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        float float29 = valueMarker28.getAlpha();
        java.lang.Object obj30 = valueMarker28.clone();
        org.jfree.chart.util.Layer layer31 = null;
        try {
            boolean boolean32 = xYPlot14.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker28, layer31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNull(axisSpace26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.8f + "'", float29 == 0.8f);
        org.junit.Assert.assertNotNull(obj30);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test197");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo1);
//        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo1.addLibrary((org.jfree.chart.ui.Library) projectInfo3);
//        java.lang.String str5 = projectInfo1.getInfo();
//        org.jfree.chart.ui.Library[] libraryArray6 = projectInfo1.getLibraries();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(projectInfo1);
//        org.junit.Assert.assertNotNull(projectInfo3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "http://www.jfree.org/jfreechart/index.html" + "'", str5.equals("http://www.jfree.org/jfreechart/index.html"));
//        org.junit.Assert.assertNotNull(libraryArray6);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "" + "'", str0.equals(""));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toFixedWidth(4.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("Category Plot", "hi!", "1.2.0-pre", "");
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.util.Rotation rotation1 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = polarPlot5.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range8 = polarPlot5.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis7);
        polarPlot2.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis7);
        boolean boolean10 = rotation1.equals((java.lang.Object) polarPlot2);
        double double11 = polarPlot2.getMaxRadius();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        polarPlot2.zoomRangeAxes(3.0d, (double) ' ', plotRenderingInfo15, point2D16);
        org.junit.Assert.assertNotNull(rotation1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange((double) 100);
        dateAxis0.setAutoTickUnitSelection(true, true);
        java.awt.Stroke stroke6 = dateAxis0.getTickMarkStroke();
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        categoryAxis3D20.setCategoryLabelPositionOffset((int) (byte) 10);
        categoryAxis3D20.setCategoryMargin((double) 1.0f);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("http://www.jfree.org/jfreechart/index.html", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo1);
//        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo1.addLibrary((org.jfree.chart.ui.Library) projectInfo3);
//        java.lang.String str5 = projectInfo1.getInfo();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = projectInfo1.equals(obj6);
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(projectInfo1);
//        org.junit.Assert.assertNotNull(projectInfo3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "http://www.jfree.org/jfreechart/index.html" + "'", str5.equals("http://www.jfree.org/jfreechart/index.html"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        categoryPlot34.setFixedDomainAxisSpace(axisSpace35);
        float float37 = categoryPlot34.getForegroundAlpha();
        categoryPlot34.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 1.0f + "'", float37 == 1.0f);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        float float2 = valueMarker1.getAlpha();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = null;
        try {
            valueMarker1.setLabelOffsetType(lengthAdjustmentType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.8f + "'", float2 == 0.8f);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.awt.Color color1 = java.awt.Color.BLUE;
        float[] floatArray8 = new float[] { 10.0f, 100L, 1, (-1.0f), (byte) 100, 100 };
        float[] floatArray9 = color1.getColorComponents(floatArray8);
        java.awt.Color color10 = java.awt.Color.getColor("Pie Plot", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean1 = categoryAxis3D0.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot2 = categoryAxis3D0.getPlot();
        categoryAxis3D0.setCategoryMargin(0.08d);
        categoryAxis3D0.removeCategoryLabelToolTip((java.lang.Comparable) "1.2.0-pre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(plot2);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        categoryPlot34.setFixedDomainAxisSpace(axisSpace35);
        boolean boolean37 = categoryPlot34.isRangeCrosshairVisible();
        org.jfree.chart.util.SortOrder sortOrder38 = null;
        try {
            categoryPlot34.setColumnRenderingOrder(sortOrder38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isRangeGridlinesVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        int int17 = xYPlot14.getIndexOf(xYItemRenderer16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = xYPlot14.getRenderer((int) (byte) 0);
        boolean boolean20 = xYPlot14.isDomainZeroBaselineVisible();
        int int21 = xYPlot14.getDomainAxisCount();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(xYItemRenderer19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis2 = polarPlot0.getAxis();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        polarPlot0.drawBackgroundImage(graphics2D3, rectangle2D4);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        polarPlot0.setRenderer(polarItemRenderer6);
        java.awt.Paint paint8 = polarPlot0.getOutlinePaint();
        try {
            double double9 = polarPlot0.getMaxRadius();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        double double2 = ringPlot1.getLabelLinkMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.025d + "'", double2 == 0.025d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.lang.Class class0 = null;
        try {
            java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        xYPlot14.clearRangeMarkers();
        java.awt.Font font16 = xYPlot14.getNoDataMessageFont();
        java.awt.Stroke stroke17 = xYPlot14.getDomainGridlineStroke();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        xYPlot14.setRenderer((int) (byte) 100, xYItemRenderer19);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.Font font24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis27 = polarPlot25.getAxis();
        polarPlot25.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart31 = new org.jfree.chart.JFreeChart("hi!", font24, (org.jfree.chart.plot.Plot) polarPlot25, true);
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("hi!", font24);
        textTitle32.setPadding((double) (short) 10, (-1.0d), 0.2d, (double) '#');
        java.awt.geom.Rectangle2D rectangle2D38 = textTitle32.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity39 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D38);
        try {
            xYPlot14.drawBackground(graphics2D21, rectangle2D38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(rectangle2D38);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis2 = polarPlot0.getAxis();
        polarPlot0.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.data.xy.XYDataset xYDataset5 = polarPlot0.getDataset();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(xYDataset5);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.awt.Paint paint0 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        categoryAxis3D20.setUpperMargin((double) 0);
        categoryAxis3D20.setCategoryMargin((double) (short) 10);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range5 = polarPlot2.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Paint paint6 = polarPlot2.getRadiusGridlinePaint();
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("TextAnchor.BOTTOM_LEFT", font1, paint6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        try {
            java.awt.Shape shape15 = textBlock7.calculateBounds(graphics2D8, (float) (short) 0, (float) 15, textBlockAnchor11, 0.0f, (float) (byte) 0, (double) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(textBlockAnchor11);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        java.lang.Number number35 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset19);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset19, false);
        try {
            org.jfree.data.general.PieDataset pieDataset39 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset19, (java.lang.Comparable) 0.8f);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + (-1.0d) + "'", number35.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range37);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo1);
        java.lang.String str3 = projectInfo0.toString();
        java.util.List list4 = projectInfo0.getContributors();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        int int35 = categoryPlot34.getRangeAxisCount();
        categoryPlot34.clearDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = categoryPlot34.getRenderer((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D39 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D39.setCategoryMargin((double) (short) -1);
        int int42 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D39);
        int int43 = categoryAxis3D39.getCategoryLabelPositionOffset();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNull(categoryItemRenderer38);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 4 + "'", int43 == 4);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        waferMapPlot0.setRenderer(waferMapRenderer1);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        waferMapPlot0.setRenderer(waferMapRenderer3);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.util.Locale locale1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.lang.Class<?> wildcardClass3 = color2.getClass();
        java.lang.ClassLoader classLoader4 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass3);
        try {
            java.util.ResourceBundle resourceBundle5 = java.util.ResourceBundle.getBundle("1.2.0-pre", locale1, classLoader4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(classLoader4);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = xYPlot14.getRenderer(3);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer16);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis2 = polarPlot0.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = polarPlot3.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range6 = polarPlot3.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis5);
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        boolean boolean8 = polarPlot0.isAngleGridlinesVisible();
        java.awt.Paint paint9 = polarPlot0.getAngleGridlinePaint();
        polarPlot0.zoom((double) 0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot14.getDomainMarkers(1, layer16);
        java.awt.Paint paint18 = xYPlot14.getDomainCrosshairPaint();
        boolean boolean19 = xYPlot14.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        try {
            xYPlot14.zoomDomainAxes((double) 1L, (double) 0.5f, plotRenderingInfo22, point2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        categoryPlot34.setFixedDomainAxisSpace(axisSpace35);
        org.jfree.data.category.CategoryDataset categoryDataset37 = categoryPlot34.getDataset();
        try {
            org.jfree.data.general.PieDataset pieDataset39 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset37, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(categoryDataset37);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.lang.Object obj1 = legendItemCollection0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.util.Locale locale1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.lang.Class<?> wildcardClass3 = color2.getClass();
        java.lang.ClassLoader classLoader4 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass3);
        try {
            java.util.ResourceBundle resourceBundle5 = java.util.ResourceBundle.getBundle("hi!", locale1, classLoader4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(classLoader4);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = polarPlot3.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis5 = polarPlot3.getAxis();
        polarPlot3.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", font2, (org.jfree.chart.plot.Plot) polarPlot3, true);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font2);
        textTitle10.setPadding((double) (short) 10, (-1.0d), 0.2d, (double) '#');
        java.lang.Object obj16 = textTitle10.clone();
        textTitle10.setWidth(0.0d);
        textTitle10.setToolTipText("");
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers(layer18);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot14.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker21);
        org.jfree.chart.axis.AxisLocation axisLocation23 = null;
        try {
            xYPlot14.setRangeAxisLocation(axisLocation23, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(collection19);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.setAutoRangeIncludesZero(true);
        numberAxis1.configure();
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range3 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis2);
        dateAxis2.setAutoTickUnitSelection(true, false);
        java.util.Date date7 = dateAxis2.getMaximumDate();
        boolean boolean8 = dateAxis2.isTickMarksVisible();
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = polarPlot9.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range12 = polarPlot9.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.util.Date date13 = dateAxis11.getMinimumDate();
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = polarPlot14.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range17 = polarPlot14.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis16);
        java.util.Date date18 = dateAxis16.getMinimumDate();
        try {
            dateAxis2.setRange(date13, date18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = polarPlot3.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis5 = polarPlot3.getAxis();
        polarPlot3.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", font2, (org.jfree.chart.plot.Plot) polarPlot3, true);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font2);
        textTitle10.setPadding((double) (short) 10, (-1.0d), 0.2d, (double) '#');
        textTitle10.setMargin((double) '4', 0.0d, (double) (short) 1, 0.0d);
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = textTitle10.getVerticalAlignment();
        boolean boolean23 = verticalAlignment21.equals((java.lang.Object) (short) 100);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(verticalAlignment21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis2 = polarPlot0.getAxis();
        polarPlot0.setForegroundAlpha((float) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        try {
            polarPlot0.zoomRangeAxes(0.0d, (double) (byte) 0, plotRenderingInfo7, point2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(valueAxis2);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isRangeGridlinesVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        int int17 = xYPlot14.getIndexOf(xYItemRenderer16);
        java.awt.Paint paint18 = xYPlot14.getDomainTickBandPaint();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(paint18);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart8.removeProgressListener(chartProgressListener11);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart8.getLegend((int) (byte) 100);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart8.getLegend();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle15.setLegendItemGraphicLocation(rectangleAnchor16);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = null;
        legendTitle15.setLegendItemGraphicLocation(rectangleAnchor18);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertNotNull(legendTitle15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.trimHeight(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.0d) + "'", double2 == (-2.0d));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        java.lang.Comparable comparable1 = null;
        try {
            boolean boolean2 = strokeMap0.containsKey(comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range4 = polarPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis3);
        dateAxis3.setAutoTickUnitSelection(true, false);
        java.util.Date date8 = dateAxis3.getMaximumDate();
        boolean boolean9 = dateAxis3.isTickMarksVisible();
        java.awt.Font font10 = dateAxis3.getLabelFont();
        org.jfree.data.Range range11 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range14 = org.jfree.data.Range.shift(range11, (double) 10, false);
        dateAxis3.setRange(range11, false, true);
        boolean boolean18 = plotOrientation0.equals((java.lang.Object) dateAxis3);
        java.lang.Object obj19 = dateAxis3.clone();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers(layer18);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot14.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        xYPlot14.setRenderer(xYItemRenderer23);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        dateAxis25.centerRange((double) 100);
        java.lang.String str28 = dateAxis25.getLabelToolTip();
        xYPlot14.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis25);
        boolean boolean30 = xYPlot14.isDomainZeroBaselineVisible();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = numberAxis1.getTickUnit();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = numberAxis1.getTickUnit();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat7 = numberAxis6.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = numberAxis6.getTickUnit();
        numberAxis1.setTickUnit(numberTickUnit8);
        org.jfree.data.RangeType rangeType10 = numberAxis1.getRangeType();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = polarPlot17.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis19 = polarPlot17.getAxis();
        polarPlot17.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font16, (org.jfree.chart.plot.Plot) polarPlot17, true);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("hi!", font16);
        textTitle24.setPadding((double) (short) 10, (-1.0d), 0.2d, (double) '#');
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle24.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double32 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D30, rectangleEdge31);
        boolean boolean33 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge31);
        try {
            java.util.List list34 = numberAxis1.refreshTicks(graphics2D11, axisState12, rectangle2D13, rectangleEdge31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(numberTickUnit8);
        org.junit.Assert.assertNotNull(rangeType10);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        int int35 = categoryPlot34.getRangeAxisCount();
        categoryPlot34.clearDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = categoryPlot34.getRenderer((int) (short) 100);
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        try {
            boolean boolean41 = categoryPlot34.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNull(categoryItemRenderer38);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color1 = java.awt.Color.BLUE;
        categoryAxis3D0.setTickLabelPaint((java.awt.Paint) color1);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = polarPlot9.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis11 = polarPlot9.getAxis();
        polarPlot9.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("hi!", font8, (org.jfree.chart.plot.Plot) polarPlot9, true);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("hi!", font8);
        textTitle16.setPadding((double) (short) 10, (-1.0d), 0.2d, (double) '#');
        java.awt.geom.Rectangle2D rectangle2D22 = textTitle16.getBounds();
        java.awt.Font font25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = polarPlot26.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis28 = polarPlot26.getAxis();
        polarPlot26.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart("hi!", font25, (org.jfree.chart.plot.Plot) polarPlot26, true);
        org.jfree.chart.title.TextTitle textTitle33 = new org.jfree.chart.title.TextTitle("hi!", font25);
        textTitle33.setPadding((double) (short) 10, (-1.0d), 0.2d, (double) '#');
        textTitle33.setMargin((double) '4', 0.0d, (double) (short) 1, 0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.util.RectangleEdge.LEFT;
        textTitle33.setPosition(rectangleEdge44);
        try {
            double double46 = categoryAxis3D0.getCategoryJava2DCoordinate(categoryAnchor3, 10, (int) (byte) 0, rectangle2D22, rectangleEdge44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertNotNull(rectangleEdge44);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(10);
        java.lang.Object obj2 = objectList1.clone();
        java.lang.Object obj4 = objectList1.get(0);
        java.lang.Object obj5 = objectList1.clone();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        double double3 = ringPlot0.getOuterSeparatorExtension();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        ringPlot4.setIgnoreNullValues(true);
        java.awt.Stroke stroke7 = ringPlot4.getSeparatorStroke();
        ringPlot0.setLabelLinkStroke(stroke7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = ringPlot0.getDrawingSupplier();
        java.lang.Comparable comparable10 = null;
        java.awt.Paint paint11 = null;
        try {
            ringPlot0.setSectionPaint(comparable10, paint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(drawingSupplier9);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean1 = categoryAxis3D0.isTickLabelsVisible();
        java.lang.String str2 = categoryAxis3D0.getLabelToolTip();
        categoryAxis3D0.configure();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor4 = null;
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        ringPlot7.setIgnoreNullValues(true);
        java.awt.Stroke stroke10 = ringPlot7.getSeparatorStroke();
        double double11 = ringPlot7.getMinimumArcAngleToDraw();
        double double12 = ringPlot7.getSectionDepth();
        ringPlot7.setForegroundAlpha(0.5f);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        double double17 = categoryAxis16.getUpperMargin();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        double double21 = categoryAxis3D20.getCategoryMargin();
        java.awt.Font font26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = polarPlot27.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis29 = polarPlot27.getAxis();
        polarPlot27.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart33 = new org.jfree.chart.JFreeChart("hi!", font26, (org.jfree.chart.plot.Plot) polarPlot27, true);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("hi!", font26);
        java.awt.geom.Rectangle2D rectangle2D35 = textTitle34.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double37 = categoryAxis3D20.getCategoryStart((int) (short) 10, (int) '4', rectangle2D35, rectangleEdge36);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double39 = categoryAxis16.getCategoryEnd(15, (int) '4', rectangle2D35, rectangleEdge38);
        ringPlot7.drawBackgroundImage(graphics2D15, rectangle2D35);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis();
        double double42 = categoryAxis41.getUpperMargin();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D45 = new org.jfree.chart.axis.CategoryAxis3D();
        double double46 = categoryAxis3D45.getCategoryMargin();
        java.awt.Font font51 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot52 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = polarPlot52.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis54 = polarPlot52.getAxis();
        polarPlot52.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart58 = new org.jfree.chart.JFreeChart("hi!", font51, (org.jfree.chart.plot.Plot) polarPlot52, true);
        org.jfree.chart.title.TextTitle textTitle59 = new org.jfree.chart.title.TextTitle("hi!", font51);
        java.awt.geom.Rectangle2D rectangle2D60 = textTitle59.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double62 = categoryAxis3D45.getCategoryStart((int) (short) 10, (int) '4', rectangle2D60, rectangleEdge61);
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double64 = categoryAxis41.getCategoryEnd(15, (int) '4', rectangle2D60, rectangleEdge63);
        try {
            double double65 = categoryAxis3D0.getCategoryJava2DCoordinate(categoryAnchor4, 2, 2, rectangle2D35, rectangleEdge63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0E-5d + "'", double11 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.2d + "'", double21 == 0.2d);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.05d + "'", double42 == 0.05d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.2d + "'", double46 == 0.2d);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertNull(valueAxis54);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(rectangleEdge61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getMaximumExplodePercent();
        ringPlot1.setBackgroundAlpha((float) (-1));
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot1);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        ringPlot1.setLabelFont(font6);
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font6);
        org.jfree.chart.text.TextFragment textFragment9 = textLine8.getLastTextFragment();
        java.awt.Graphics2D graphics2D10 = null;
        try {
            org.jfree.chart.util.Size2D size2D11 = textLine8.calculateDimensions(graphics2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(textFragment9);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        java.awt.Stroke stroke3 = ringPlot0.getSeparatorStroke();
        double double4 = ringPlot0.getMinimumArcAngleToDraw();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = polarPlot7.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis9 = polarPlot7.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = polarPlot10.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range13 = polarPlot10.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis12);
        polarPlot7.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis12);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat17 = numberAxis16.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit18 = numberAxis16.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis16, xYItemRenderer19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = xYPlot20.getRenderer();
        xYPlot20.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = xYPlot20.getDomainMarkers(layer24);
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = xYPlot20.getRangeMarkers((-1), layer27);
        java.awt.Stroke stroke29 = xYPlot20.getDomainCrosshairStroke();
        ringPlot0.setSectionOutlineStroke((java.lang.Comparable) 0.0d, stroke29);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-5d + "'", double4 == 1.0E-5d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNull(numberFormat17);
        org.junit.Assert.assertNotNull(numberTickUnit18);
        org.junit.Assert.assertNull(xYItemRenderer21);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range3 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis2);
        dateAxis2.setLabelURL("hi!");
        boolean boolean6 = dateAxis2.isInverted();
        double double7 = dateAxis2.getUpperMargin();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers(layer18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = null;
        xYPlot14.setDomainAxisLocation(15, axisLocation21, false);
        xYPlot14.mapDatasetToRangeAxis((int) 'a', (int) (byte) -1);
        int int27 = xYPlot14.getSeriesCount();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        double double3 = ringPlot0.getInnerSeparatorExtension();
        ringPlot0.setOuterSeparatorExtension(0.0d);
        org.jfree.chart.util.Rotation rotation6 = ringPlot0.getDirection();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor8 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) -1);
        ringPlot0.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor8);
        pieLabelDistributor8.sort();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(rotation6);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        boolean boolean16 = xYPlot14.isDomainZeroBaselineVisible();
        int int17 = xYPlot14.getSeriesCount();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        ringPlot19.setIgnoreNullValues(true);
        java.awt.Stroke stroke22 = ringPlot19.getSeparatorStroke();
        double double23 = ringPlot19.getMinimumArcAngleToDraw();
        double double24 = ringPlot19.getSectionDepth();
        ringPlot19.setForegroundAlpha(0.5f);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        double double29 = categoryAxis28.getUpperMargin();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D32 = new org.jfree.chart.axis.CategoryAxis3D();
        double double33 = categoryAxis3D32.getCategoryMargin();
        java.awt.Font font38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot39 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = polarPlot39.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis41 = polarPlot39.getAxis();
        polarPlot39.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart45 = new org.jfree.chart.JFreeChart("hi!", font38, (org.jfree.chart.plot.Plot) polarPlot39, true);
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle("hi!", font38);
        java.awt.geom.Rectangle2D rectangle2D47 = textTitle46.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double49 = categoryAxis3D32.getCategoryStart((int) (short) 10, (int) '4', rectangle2D47, rectangleEdge48);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double51 = categoryAxis28.getCategoryEnd(15, (int) '4', rectangle2D47, rectangleEdge50);
        ringPlot19.drawBackgroundImage(graphics2D27, rectangle2D47);
        try {
            xYPlot14.drawBackground(graphics2D18, rectangle2D47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0E-5d + "'", double23 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.2d + "'", double24 == 0.2d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.2d + "'", double33 == 0.2d);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNull(valueAxis41);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        double double3 = ringPlot0.getInnerSeparatorExtension();
        ringPlot0.setOuterSeparatorExtension(0.0d);
        org.jfree.chart.util.Rotation rotation6 = ringPlot0.getDirection();
        ringPlot0.setSectionDepth(0.05d);
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        ringPlot9.setIgnoreNullValues(true);
        double double12 = ringPlot9.getInnerSeparatorExtension();
        int int13 = ringPlot9.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = ringPlot9.getSimpleLabelOffset();
        ringPlot0.setLabelPadding(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(rotation6);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer2 = new org.jfree.chart.text.G2TextMeasurer(graphics2D1);
        boolean boolean3 = blockBorder0.equals((java.lang.Object) g2TextMeasurer2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D();
        double double6 = categoryAxis3D5.getCategoryMargin();
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = polarPlot12.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis14 = polarPlot12.getAxis();
        polarPlot12.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("hi!", font11, (org.jfree.chart.plot.Plot) polarPlot12, true);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("hi!", font11);
        java.awt.geom.Rectangle2D rectangle2D20 = textTitle19.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double22 = categoryAxis3D5.getCategoryStart((int) (short) 10, (int) '4', rectangle2D20, rectangleEdge21);
        org.jfree.chart.entity.ChartEntity chartEntity25 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D20, "Pie Plot", "TextAnchor.BOTTOM_LEFT");
        try {
            blockBorder0.draw(graphics2D4, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        polarPlot0.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit2);
        polarPlot0.clearCornerTextItems();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(numberTickUnit2);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart8.removeProgressListener(chartProgressListener11);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent13 = null;
        try {
            jFreeChart8.titleChanged(titleChangeEvent13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        double double3 = ringPlot0.getOuterSeparatorExtension();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        ringPlot4.setIgnoreNullValues(true);
        java.awt.Stroke stroke7 = ringPlot4.getSeparatorStroke();
        ringPlot0.setLabelLinkStroke(stroke7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = ringPlot0.getDrawingSupplier();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = ringPlot0.getDrawingSupplier();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = ringPlot0.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(drawingSupplier9);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertNull(pieSectionLabelGenerator11);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean1 = categoryAxis3D0.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot2 = categoryAxis3D0.getPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        double[] doubleArray11 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray15 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray19 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray23 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray11, doubleArray15, doubleArray19, doubleArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray24);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D26 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean27 = categoryAxis3D26.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot28 = categoryAxis3D26.getPlot();
        categoryAxis3D26.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot31 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = polarPlot31.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range34 = polarPlot31.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis33);
        dateAxis33.setAutoTickUnitSelection(true, false);
        java.util.Date date38 = dateAxis33.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D26, (org.jfree.chart.axis.ValueAxis) dateAxis33, categoryItemRenderer39);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D42 = new org.jfree.chart.axis.CategoryAxis3D();
        double double43 = categoryAxis3D42.getCategoryMargin();
        java.awt.Font font48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot49 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = polarPlot49.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis51 = polarPlot49.getAxis();
        polarPlot49.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart55 = new org.jfree.chart.JFreeChart("hi!", font48, (org.jfree.chart.plot.Plot) polarPlot49, true);
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle("hi!", font48);
        java.awt.geom.Rectangle2D rectangle2D57 = textTitle56.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double59 = categoryAxis3D42.getCategoryStart((int) (short) 10, (int) '4', rectangle2D57, rectangleEdge58);
        categoryPlot40.drawBackgroundImage(graphics2D41, rectangle2D57);
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            double double62 = categoryAxis3D0.getCategoryJava2DCoordinate(categoryAnchor3, 0, (int) (byte) 1, rectangle2D57, rectangleEdge61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNull(plot28);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.2d + "'", double43 == 0.2d);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNull(valueAxis51);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge61);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange((double) 100);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis6 = polarPlot4.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = polarPlot7.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range10 = polarPlot7.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis9);
        polarPlot4.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat14 = numberAxis13.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = numberAxis13.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = xYPlot17.getRenderer();
        xYPlot17.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot17.getDomainMarkers(layer21);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot17.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        xYPlot17.setRenderer(xYItemRenderer26);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot17);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = polarPlot30.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis32 = polarPlot30.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot33 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = polarPlot33.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range36 = polarPlot33.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis35);
        polarPlot30.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat40 = numberAxis39.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit41 = numberAxis39.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) dateAxis35, (org.jfree.chart.axis.ValueAxis) numberAxis39, xYItemRenderer42);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = xYPlot43.getRenderer();
        xYPlot43.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer47 = null;
        java.util.Collection collection48 = xYPlot43.getDomainMarkers(layer47);
        org.jfree.chart.plot.ValueMarker valueMarker50 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot43.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker50);
        try {
            boolean boolean52 = xYPlot17.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(numberFormat14);
        org.junit.Assert.assertNotNull(numberTickUnit15);
        org.junit.Assert.assertNull(xYItemRenderer18);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(valueAxis32);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNull(range36);
        org.junit.Assert.assertNull(numberFormat40);
        org.junit.Assert.assertNotNull(numberTickUnit41);
        org.junit.Assert.assertNull(xYItemRenderer44);
        org.junit.Assert.assertNull(collection48);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range4 = org.jfree.data.Range.shift(range1, (double) 10, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 10, range1);
        org.jfree.data.Range range6 = rectangleConstraint5.getHeightRange();
        org.jfree.data.Range range7 = rectangleConstraint5.getHeightRange();
        boolean boolean9 = range7.contains((double) 4);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        double double17 = ringPlot16.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = ringPlot16.getLabelPadding();
        double double19 = rectangleInsets18.getRight();
        double double21 = rectangleInsets18.trimHeight((double) (byte) 1);
        xYPlot14.setInsets(rectangleInsets18);
        java.lang.String str23 = rectangleInsets18.toString();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-3.0d) + "'", double21 == (-3.0d));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]" + "'", str23.equals("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range4 = org.jfree.data.Range.shift(range1, (double) 10, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 10, range1);
        org.jfree.data.Range range6 = rectangleConstraint5.getHeightRange();
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = polarPlot7.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range10 = polarPlot7.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis9);
        dateAxis9.setAutoTickUnitSelection(true, false);
        java.util.Date date14 = dateAxis9.getMaximumDate();
        boolean boolean15 = dateAxis9.isTickMarksVisible();
        java.awt.Font font16 = dateAxis9.getLabelFont();
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range20 = org.jfree.data.Range.shift(range17, (double) 10, false);
        dateAxis9.setRange(range17, false, true);
        double double24 = range17.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = rectangleConstraint5.toRangeHeight(range17);
        double double27 = range17.constrain((double) 10L);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator1 = null;
        ringPlot0.setURLGenerator(pieURLGenerator1);
        boolean boolean3 = ringPlot0.isOutlineVisible();
        double double4 = ringPlot0.getInteriorGap();
        ringPlot0.setLabelLinkMargin((double) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.08d + "'", double4 == 0.08d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = numberAxis1.getTickUnit();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = null;
        ringPlot6.setURLGenerator(pieURLGenerator7);
        boolean boolean9 = ringPlot6.isOutlineVisible();
        ringPlot6.setMinimumArcAngleToDraw(0.0d);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot6.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator12);
        java.text.AttributedString attributedString15 = null;
        standardPieSectionLabelGenerator12.setAttributedLabel(0, attributedString15);
        java.text.NumberFormat numberFormat17 = standardPieSectionLabelGenerator12.getPercentFormat();
        numberAxis1.setNumberFormatOverride(numberFormat17);
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberFormat17);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(false, false);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        double double6 = ringPlot5.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = ringPlot5.getLabelPadding();
        ringPlot5.setMaximumLabelWidth((double) 0);
        double double10 = ringPlot5.getStartAngle();
        double[] doubleArray16 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray20 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray24 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray28 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray29 = new double[][] { doubleArray16, doubleArray20, doubleArray24, doubleArray28 };
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray29);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D31 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean32 = categoryAxis3D31.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot33 = categoryAxis3D31.getPlot();
        categoryAxis3D31.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = polarPlot36.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range39 = polarPlot36.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis38);
        dateAxis38.setAutoTickUnitSelection(true, false);
        java.util.Date date43 = dateAxis38.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D31, (org.jfree.chart.axis.ValueAxis) dateAxis38, categoryItemRenderer44);
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D47 = new org.jfree.chart.axis.CategoryAxis3D();
        double double48 = categoryAxis3D47.getCategoryMargin();
        java.awt.Font font53 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot54 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = polarPlot54.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis56 = polarPlot54.getAxis();
        polarPlot54.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart60 = new org.jfree.chart.JFreeChart("hi!", font53, (org.jfree.chart.plot.Plot) polarPlot54, true);
        org.jfree.chart.title.TextTitle textTitle61 = new org.jfree.chart.title.TextTitle("hi!", font53);
        java.awt.geom.Rectangle2D rectangle2D62 = textTitle61.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double64 = categoryAxis3D47.getCategoryStart((int) (short) 10, (int) '4', rectangle2D62, rectangleEdge63);
        categoryPlot45.drawBackgroundImage(graphics2D46, rectangle2D62);
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.axis.AxisSpace axisSpace67 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace68 = dateAxis0.reserveSpace(graphics2D4, (org.jfree.chart.plot.Plot) ringPlot5, rectangle2D62, rectangleEdge66, axisSpace67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNull(plot33);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.2d + "'", double48 == 0.2d);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNull(valueAxis56);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertNotNull(rectangleEdge63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge66);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Category Plot", graphics2D1, (float) 10L, (float) 'a', (double) 0L, 1.0f, (float) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isRangeGridlinesVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        int int17 = xYPlot14.getIndexOf(xYItemRenderer16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = xYPlot14.getRenderer((int) (byte) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot14.zoomDomainAxes((double) 10, (double) (byte) 10, plotRenderingInfo22, point2D23);
        org.jfree.data.xy.XYDataset xYDataset25 = xYPlot14.getDataset();
        java.awt.Stroke stroke26 = xYPlot14.getRangeZeroBaselineStroke();
        xYPlot14.setDomainCrosshairValue((double) '4', false);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(xYItemRenderer19);
        org.junit.Assert.assertNull(xYDataset25);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        ringPlot0.setBackgroundAlpha((float) (-1));
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        ringPlot0.setLabelFont(font5);
        org.jfree.data.general.PieDataset pieDataset7 = ringPlot0.getDataset();
        java.awt.Paint paint8 = ringPlot0.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(pieDataset7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        java.lang.Object obj3 = ringPlot0.clone();
        double double4 = ringPlot0.getInnerSeparatorExtension();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        int int35 = categoryPlot34.getRangeAxisCount();
        categoryPlot34.clearDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = categoryPlot34.getRenderer((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D39 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D39.setCategoryMargin((double) (short) -1);
        int int42 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D39);
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        float float45 = valueMarker44.getAlpha();
        org.jfree.chart.plot.RingPlot ringPlot46 = new org.jfree.chart.plot.RingPlot();
        ringPlot46.setIgnoreNullValues(true);
        java.awt.Stroke stroke49 = ringPlot46.getSeparatorStroke();
        double double50 = ringPlot46.getMinimumArcAngleToDraw();
        double double51 = ringPlot46.getSectionDepth();
        ringPlot46.setForegroundAlpha(0.5f);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier54 = ringPlot46.getDrawingSupplier();
        valueMarker44.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) ringPlot46);
        org.jfree.chart.util.Layer layer56 = null;
        try {
            boolean boolean57 = categoryPlot34.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker44, layer56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNull(categoryItemRenderer38);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + float45 + "' != '" + 0.8f + "'", float45 == 0.8f);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0E-5d + "'", double50 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.2d + "'", double51 == 0.2d);
        org.junit.Assert.assertNotNull(drawingSupplier54);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        float float2 = valueMarker1.getAlpha();
        java.lang.Object obj3 = valueMarker1.clone();
        java.lang.String str4 = valueMarker1.getLabel();
        valueMarker1.setLabel("Category Plot");
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.8f + "'", float2 == 0.8f);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range4 = org.jfree.data.Range.shift(range1, (double) 10, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 10, range1);
        org.jfree.data.Range range6 = rectangleConstraint5.getHeightRange();
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = polarPlot7.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range10 = polarPlot7.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis9);
        dateAxis9.setAutoTickUnitSelection(true, false);
        java.util.Date date14 = dateAxis9.getMaximumDate();
        boolean boolean15 = dateAxis9.isTickMarksVisible();
        java.awt.Font font16 = dateAxis9.getLabelFont();
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range20 = org.jfree.data.Range.shift(range17, (double) 10, false);
        dateAxis9.setRange(range17, false, true);
        double double24 = range17.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = rectangleConstraint5.toRangeHeight(range17);
        java.lang.String str26 = rectangleConstraint25.toString();
        double double27 = rectangleConstraint25.getWidth();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=1.0]" + "'", str26.equals("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=1.0]"));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.0d + "'", double27 == 10.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, (double) (short) -1);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        blockContainer5.clear();
        boolean boolean7 = blockContainer5.isEmpty();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        double double10 = categoryAxis9.getUpperMargin();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        double double14 = categoryAxis3D13.getCategoryMargin();
        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = polarPlot20.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis22 = polarPlot20.getAxis();
        polarPlot20.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("hi!", font19, (org.jfree.chart.plot.Plot) polarPlot20, true);
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("hi!", font19);
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle27.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double30 = categoryAxis3D13.getCategoryStart((int) (short) 10, (int) '4', rectangle2D28, rectangleEdge29);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double32 = categoryAxis9.getCategoryEnd(15, (int) '4', rectangle2D28, rectangleEdge31);
        try {
            blockContainer5.draw(graphics2D8, rectangle2D28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = ringPlot1.getLabelPadding();
        double double4 = ringPlot1.getOuterSeparatorExtension();
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        ringPlot5.setIgnoreNullValues(true);
        double double8 = ringPlot5.getInnerSeparatorExtension();
        ringPlot5.setOuterSeparatorExtension(0.0d);
        org.jfree.chart.util.Rotation rotation11 = ringPlot5.getDirection();
        ringPlot1.setParent((org.jfree.chart.plot.Plot) ringPlot5);
        java.awt.Paint paint14 = ringPlot5.getSectionOutlinePaint((java.lang.Comparable) 0.08d);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        double double16 = ringPlot5.getExplodePercent((java.lang.Comparable) numberTickUnit15);
        polarPlot0.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit15);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertNotNull(rotation11);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(numberTickUnit15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        ringPlot2.setIgnoreNullValues(true);
        double double5 = ringPlot2.getInnerSeparatorExtension();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat8 = numberAxis7.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = numberAxis7.getTickUnit();
        ringPlot2.setExplodePercent((java.lang.Comparable) numberTickUnit9, (double) 2);
        numberAxis1.setTickUnit(numberTickUnit9, false, false);
        numberAxis1.setVerticalTickLabels(false);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        double[] doubleArray24 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray28 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray32 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray36 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray37 = new double[][] { doubleArray24, doubleArray28, doubleArray32, doubleArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray37);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D39 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean40 = categoryAxis3D39.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot41 = categoryAxis3D39.getPlot();
        categoryAxis3D39.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot44 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = polarPlot44.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range47 = polarPlot44.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis46);
        dateAxis46.setAutoTickUnitSelection(true, false);
        java.util.Date date51 = dateAxis46.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D39, (org.jfree.chart.axis.ValueAxis) dateAxis46, categoryItemRenderer52);
        java.awt.Graphics2D graphics2D54 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D55 = new org.jfree.chart.axis.CategoryAxis3D();
        double double56 = categoryAxis3D55.getCategoryMargin();
        java.awt.Font font61 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot62 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = polarPlot62.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis64 = polarPlot62.getAxis();
        polarPlot62.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart68 = new org.jfree.chart.JFreeChart("hi!", font61, (org.jfree.chart.plot.Plot) polarPlot62, true);
        org.jfree.chart.title.TextTitle textTitle69 = new org.jfree.chart.title.TextTitle("hi!", font61);
        java.awt.geom.Rectangle2D rectangle2D70 = textTitle69.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double72 = categoryAxis3D55.getCategoryStart((int) (short) 10, (int) '4', rectangle2D70, rectangleEdge71);
        categoryPlot53.drawBackgroundImage(graphics2D54, rectangle2D70);
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            java.util.List list75 = numberAxis1.refreshTicks(graphics2D17, axisState18, rectangle2D70, rectangleEdge74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(numberTickUnit9);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(plot41);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNull(range47);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.2d + "'", double56 == 0.2d);
        org.junit.Assert.assertNotNull(font61);
        org.junit.Assert.assertNotNull(rectangleInsets63);
        org.junit.Assert.assertNull(valueAxis64);
        org.junit.Assert.assertNotNull(rectangle2D70);
        org.junit.Assert.assertNotNull(rectangleEdge71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge74);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        categoryAxis3D20.setUpperMargin((double) 0);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions37 = categoryAxis3D20.getCategoryLabelPositions();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(categoryLabelPositions37);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape8 = textBlock0.calculateBounds(graphics2D1, (float) 0L, (float) (short) 10, textBlockAnchor4, (float) (short) 0, 0.0f, 0.05d);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = null;
        textBlock0.draw(graphics2D9, (float) 1L, (float) ' ', textBlockAnchor12, 100.0f, 0.8f, (double) (byte) 0);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor20 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        textBlock0.draw(graphics2D17, 0.0f, 0.0f, textBlockAnchor20);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(textBlockAnchor20);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("hi!", "Pie Plot");
        java.lang.String str3 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        java.awt.Stroke stroke3 = ringPlot0.getSeparatorStroke();
        double double4 = ringPlot0.getMinimumArcAngleToDraw();
        double double5 = ringPlot0.getSectionDepth();
        ringPlot0.setCircular(false);
        java.awt.Paint paint8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot0.setBaseSectionOutlinePaint(paint8);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-5d + "'", double4 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot14.getDomainMarkers(1, layer16);
        java.awt.Paint paint18 = xYPlot14.getDomainCrosshairPaint();
        boolean boolean19 = xYPlot14.isRangeCrosshairVisible();
        boolean boolean20 = xYPlot14.isRangeZoomable();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart8.removeProgressListener(chartProgressListener11);
        int int13 = jFreeChart8.getSubtitleCount();
        jFreeChart8.clearSubtitles();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        jFreeChart8.setBorderPaint((java.awt.Paint) color15);
        boolean boolean17 = jFreeChart8.getAntiAlias();
        java.lang.Object obj18 = jFreeChart8.getTextAntiAlias();
        jFreeChart8.setBackgroundImageAlignment(100);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.Point2D point2D23 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        try {
            jFreeChart8.draw(graphics2D21, rectangle2D22, point2D23, chartRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(obj18);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, 0.0d, (double) (short) -1);
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment7, verticalAlignment8, 0.0d, (double) (short) -1);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        boolean boolean13 = flowArrangement11.equals((java.lang.Object) textBlockAnchor12);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0, (org.jfree.chart.block.Arrangement) flowArrangement5, (org.jfree.chart.block.Arrangement) flowArrangement11);
        flowArrangement11.clear();
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        xYPlot14.clearRangeMarkers();
        java.awt.Font font16 = xYPlot14.getNoDataMessageFont();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis18 = xYPlot14.getDomainAxisForDataset((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 35 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range3 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis2);
        dateAxis2.setAutoTickUnitSelection(true, false);
        java.util.Date date7 = dateAxis2.getMaximumDate();
        boolean boolean8 = dateAxis2.isTickMarksVisible();
        dateAxis2.setRange(0.12d, (double) 100.0f);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        xYPlot14.clearRangeMarkers();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        int int35 = categoryPlot34.getRangeAxisCount();
        categoryPlot34.clearDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = categoryPlot34.getRenderer((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = categoryPlot34.getDomainAxis();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNull(categoryItemRenderer38);
        org.junit.Assert.assertNull(categoryAxis39);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = piePlotState1.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection2);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) 0.4d);
        java.lang.Object obj3 = strokeMap0.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = polarPlot3.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis5 = polarPlot3.getAxis();
        polarPlot3.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", font2, (org.jfree.chart.plot.Plot) polarPlot3, true);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = textTitle10.getTextAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle10.setHorizontalAlignment(horizontalAlignment12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = textTitle10.getMargin();
        java.lang.String str15 = textTitle10.getText();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        polarPlot0.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        polarPlot0.datasetChanged(datasetChangeEvent4);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(numberTickUnit2);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        double double3 = ringPlot0.getInnerSeparatorExtension();
        ringPlot0.setOuterSeparatorExtension(0.0d);
        org.jfree.chart.util.Rotation rotation6 = ringPlot0.getDirection();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = polarPlot8.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis10 = polarPlot8.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = polarPlot11.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range14 = polarPlot11.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis13);
        polarPlot8.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat18 = numberAxis17.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit19 = numberAxis17.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis17, xYItemRenderer20);
        xYPlot21.clearRangeMarkers();
        boolean boolean23 = rotation6.equals((java.lang.Object) xYPlot21);
        java.awt.Stroke stroke24 = xYPlot21.getDomainCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        xYPlot21.setDataset(xYDataset25);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(rotation6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(numberFormat18);
        org.junit.Assert.assertNotNull(numberTickUnit19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        org.jfree.chart.LegendItemCollection legendItemCollection39 = categoryPlot34.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot34.getRangeAxisEdge((int) '4');
        categoryPlot34.clearRangeMarkers();
        org.jfree.chart.util.SortOrder sortOrder43 = categoryPlot34.getColumnRenderingOrder();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNull(legendItemCollection39);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(sortOrder43);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        polarPlot2.setBackgroundAlpha((float) (-1));
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot2);
        int int6 = polarPlot2.getSeriesCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        polarPlot2.zoomDomainAxes(0.2d, plotRenderingInfo8, point2D9, false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        polarPlot2.setRenderer(polarItemRenderer12);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        ringPlot14.setIgnoreNullValues(true);
        java.awt.Stroke stroke17 = ringPlot14.getSeparatorStroke();
        double double18 = ringPlot14.getMinimumArcAngleToDraw();
        ringPlot14.setLabelLinksVisible(true);
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = polarPlot23.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis25 = polarPlot23.getAxis();
        polarPlot23.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("hi!", font22, (org.jfree.chart.plot.Plot) polarPlot23, true);
        org.jfree.chart.title.Title title30 = null;
        jFreeChart29.removeSubtitle(title30);
        org.jfree.chart.event.ChartProgressListener chartProgressListener32 = null;
        jFreeChart29.removeProgressListener(chartProgressListener32);
        int int34 = jFreeChart29.getSubtitleCount();
        jFreeChart29.clearSubtitles();
        java.awt.Color color36 = org.jfree.chart.ChartColor.LIGHT_RED;
        jFreeChart29.setBorderPaint((java.awt.Paint) color36);
        ringPlot14.setSeparatorPaint((java.awt.Paint) color36);
        java.awt.Font font40 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot41 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = polarPlot41.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range44 = polarPlot41.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis43);
        java.awt.Paint paint45 = polarPlot41.getRadiusGridlinePaint();
        org.jfree.chart.text.TextBlock textBlock46 = org.jfree.chart.text.TextUtilities.createTextBlock("TextAnchor.BOTTOM_LEFT", font40, paint45);
        ringPlot14.setLabelLinkPaint(paint45);
        polarPlot2.setAngleGridlinePaint(paint45);
        try {
            org.jfree.chart.text.TextFragment textFragment50 = new org.jfree.chart.text.TextFragment("Pie Plot", font1, paint45, (float) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0E-5d + "'", double18 == 1.0E-5d);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNull(range44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(textBlock46);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis2 = polarPlot0.getAxis();
        polarPlot0.setForegroundAlpha((float) (byte) 10);
        org.jfree.chart.axis.ValueAxis valueAxis5 = polarPlot0.getAxis();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(valueAxis5);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        xYPlot14.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot14.getDomainAxis((int) (short) 0);
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot14.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker19);
        boolean boolean21 = xYPlot14.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisSpace axisSpace22 = xYPlot14.getFixedDomainAxisSpace();
        xYPlot14.setDomainCrosshairValue((double) (short) 1, false);
        org.jfree.chart.LegendItemCollection legendItemCollection26 = xYPlot14.getLegendItems();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(valueAxis17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(axisSpace22);
        org.junit.Assert.assertNotNull(legendItemCollection26);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange((double) 100);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis6 = polarPlot4.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = polarPlot7.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range10 = polarPlot7.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis9);
        polarPlot4.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat14 = numberAxis13.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = numberAxis13.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = xYPlot17.getRenderer();
        xYPlot17.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot17.getDomainMarkers(layer21);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot17.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        xYPlot17.setRenderer(xYItemRenderer26);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot17);
        boolean boolean29 = xYPlot17.isDomainCrosshairLockedOnData();
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        float float32 = valueMarker31.getAlpha();
        java.lang.Object obj33 = valueMarker31.clone();
        java.lang.String str34 = valueMarker31.getLabel();
        org.jfree.chart.util.Layer layer35 = null;
        try {
            boolean boolean36 = xYPlot17.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker31, layer35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(numberFormat14);
        org.junit.Assert.assertNotNull(numberTickUnit15);
        org.junit.Assert.assertNull(xYItemRenderer18);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 0.8f + "'", float32 == 0.8f);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNull(str34);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", "hi!", "hi!");
        java.lang.String str5 = basicProjectInfo4.getCopyright();
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        categoryAxis3D20.setUpperMargin((double) 0);
        int int37 = categoryAxis3D20.getCategoryLabelPositionOffset();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range3 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        org.jfree.chart.title.LegendTitle legendTitle5 = jFreeChart4.getLegend();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = jFreeChart4.getPadding();
        jFreeChart4.setAntiAlias(false);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(legendTitle5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo1);
        java.awt.Image image3 = projectInfo1.getLogo();
        java.lang.String str4 = projectInfo1.toString();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(image3);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        org.jfree.chart.LegendItemCollection legendItemCollection39 = categoryPlot34.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot34.getRangeAxisEdge((int) '4');
        categoryPlot34.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D44 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean45 = categoryAxis3D44.isTickLabelsVisible();
        java.lang.Object obj46 = categoryAxis3D44.clone();
        java.awt.Font font48 = categoryAxis3D44.getTickLabelFont((java.lang.Comparable) 1.0d);
        boolean boolean49 = categoryAxis3D44.isTickMarksVisible();
        categoryPlot34.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D44, false);
        categoryPlot34.setAnchorValue(100.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNull(legendItemCollection39);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (byte) 10, 0.0d, (double) (-1), (double) 1);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = polarPlot5.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis7 = polarPlot5.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = polarPlot8.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range11 = polarPlot8.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis10);
        polarPlot5.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis10);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat15 = numberAxis14.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = numberAxis14.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis14, xYItemRenderer17);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = xYPlot18.getDomainMarkers(1, layer20);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot18.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker23);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType25 = valueMarker23.getLabelOffsetType();
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = polarPlot27.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis29 = polarPlot27.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = polarPlot30.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range33 = polarPlot30.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis32);
        polarPlot27.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis32);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat37 = numberAxis36.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit38 = numberAxis36.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) dateAxis32, (org.jfree.chart.axis.ValueAxis) numberAxis36, xYItemRenderer39);
        org.jfree.chart.util.Layer layer42 = null;
        java.util.Collection collection43 = xYPlot40.getDomainMarkers(1, layer42);
        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot40.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker45);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType47 = valueMarker45.getLabelOffsetType();
        try {
            java.awt.geom.Rectangle2D rectangle2D48 = rectangleInsets2.createAdjustedRectangle(rectangle2D3, lengthAdjustmentType25, lengthAdjustmentType47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNotNull(numberTickUnit16);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(lengthAdjustmentType25);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNull(numberFormat37);
        org.junit.Assert.assertNotNull(numberTickUnit38);
        org.junit.Assert.assertNull(collection43);
        org.junit.Assert.assertNotNull(lengthAdjustmentType47);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = null;
        waferMapPlot0.axisChanged(axisChangeEvent1);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = null;
        waferMapPlot0.rendererChanged(rendererChangeEvent3);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) '#');
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertNotNull(range2);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers(layer18);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        float float23 = valueMarker22.getAlpha();
        java.lang.Object obj24 = valueMarker22.clone();
        java.lang.String str25 = valueMarker22.getLabel();
        org.jfree.chart.util.Layer layer26 = null;
        xYPlot14.addRangeMarker((int) '4', (org.jfree.chart.plot.Marker) valueMarker22, layer26);
        java.awt.Color color28 = java.awt.Color.green;
        valueMarker22.setLabelPaint((java.awt.Paint) color28);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.lang.Class<?> wildcardClass31 = color30.getClass();
        java.lang.ClassLoader classLoader32 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass31);
        try {
            java.util.EventListener[] eventListenerArray33 = valueMarker22.getListeners((java.lang.Class) wildcardClass31);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Ljava.awt.Color; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.8f + "'", float23 == 0.8f);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(classLoader32);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.setAutoRangeIncludesZero(true);
        numberAxis1.setAutoRangeStickyZero(false);
        org.jfree.data.Range range6 = null;
        try {
            numberAxis1.setRange(range6, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = polarPlot3.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis5 = polarPlot3.getAxis();
        polarPlot3.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", font2, (org.jfree.chart.plot.Plot) polarPlot3, true);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font2);
        textTitle10.setPadding((double) (short) 10, (-1.0d), 0.2d, (double) '#');
        java.lang.Object obj16 = textTitle10.clone();
        textTitle10.setURLText("");
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        ringPlot0.setShadowYOffset((double) 100.0f);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = ringPlot0.getURLGenerator();
        try {
            ringPlot0.setBackgroundImageAlpha((float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(pieURLGenerator5);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getLabelLinksVisible();
        ringPlot0.setSectionOutlinesVisible(true);
        boolean boolean4 = ringPlot0.getSimpleLabels();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean1 = categoryAxis3D0.isTickLabelsVisible();
        java.awt.Stroke stroke2 = categoryAxis3D0.getTickMarkStroke();
        categoryAxis3D0.setCategoryMargin((double) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getMaximumExplodePercent();
        ringPlot1.setBackgroundAlpha((float) (-1));
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot1);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        ringPlot1.setLabelFont(font6);
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font6);
        org.jfree.chart.text.TextFragment textFragment9 = textLine8.getLastTextFragment();
        java.awt.Font font10 = textFragment9.getFont();
        float float11 = textFragment9.getBaselineOffset();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(textFragment9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart8.removeProgressListener(chartProgressListener11);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart8.getLegend((int) (byte) 100);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart8.getLegend();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray16 = legendTitle15.getSources();
        double[] doubleArray22 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray26 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray30 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray34 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray35 = new double[][] { doubleArray22, doubleArray26, doubleArray30, doubleArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray35);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D37 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean38 = categoryAxis3D37.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot39 = categoryAxis3D37.getPlot();
        categoryAxis3D37.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot42 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = polarPlot42.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range45 = polarPlot42.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis44);
        dateAxis44.setAutoTickUnitSelection(true, false);
        java.util.Date date49 = dateAxis44.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D37, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer50);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D52 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean53 = categoryAxis3D52.isTickLabelsVisible();
        boolean boolean54 = categoryAxis3D52.isVisible();
        int int55 = categoryPlot51.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D52);
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = categoryPlot51.getRangeAxisEdge();
        legendTitle15.setLegendItemGraphicEdge(rectangleEdge56);
        java.lang.String str58 = rectangleEdge56.toString();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertNotNull(legendTitle15);
        org.junit.Assert.assertNotNull(legendItemSourceArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNull(plot39);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNull(range45);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "RectangleEdge.LEFT" + "'", str58.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers(layer18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = null;
        xYPlot14.setDomainAxisLocation(15, axisLocation21, false);
        xYPlot14.mapDatasetToRangeAxis((int) 'a', (int) (byte) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        xYPlot14.zoomDomainAxes(1.0d, plotRenderingInfo28, point2D29, false);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(collection19);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart8.removeProgressListener(chartProgressListener11);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart8.getLegend((int) (byte) 100);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart8.getLegend();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle15.setLegendItemGraphicLocation(rectangleAnchor16);
        double double18 = legendTitle15.getContentYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle15.getLegendItemGraphicPadding();
        double double21 = rectangleInsets19.calculateRightInset((double) 10.0f);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertNotNull(legendTitle15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.0d + "'", double18 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = polarPlot3.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis5 = polarPlot3.getAxis();
        polarPlot3.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", font2, (org.jfree.chart.plot.Plot) polarPlot3, true);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font2);
        textTitle10.setPadding((double) (short) 10, (-1.0d), 0.2d, (double) '#');
        textTitle10.setMargin((double) '4', 0.0d, (double) (short) 1, 0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.util.RectangleEdge.LEFT;
        textTitle10.setPosition(rectangleEdge21);
        textTitle10.setPadding((double) (byte) -1, (double) 10L, (double) 1L, (double) (short) 100);
        org.jfree.chart.block.BlockFrame blockFrame28 = textTitle10.getFrame();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(blockFrame28);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) ' ', (double) 0.8f, 90.0d, (double) 100.0f);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range3 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis2);
        dateAxis2.setAutoTickUnitSelection(true, false);
        java.util.Date date7 = dateAxis2.getMaximumDate();
        boolean boolean8 = dateAxis2.isTickMarksVisible();
        java.lang.String str9 = dateAxis2.getLabel();
        org.jfree.data.Range range10 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range13 = org.jfree.data.Range.shift(range10, (double) 10, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint(range10, 0.2d);
        dateAxis2.setRange(range10, true, false);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(range13);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        double double3 = ringPlot0.getInnerSeparatorExtension();
        int int4 = ringPlot0.getBackgroundImageAlignment();
        org.jfree.data.general.PieDataset pieDataset5 = ringPlot0.getDataset();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        double double7 = ringPlot6.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = ringPlot6.getLabelPadding();
        double double9 = rectangleInsets8.getRight();
        double double11 = rectangleInsets8.trimHeight((double) (byte) 1);
        boolean boolean12 = ringPlot0.equals((java.lang.Object) double11);
        ringPlot0.setLabelGap((double) 10L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(pieDataset5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-3.0d) + "'", double11 == (-3.0d));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        double double3 = ringPlot0.getOuterSeparatorExtension();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        ringPlot4.setIgnoreNullValues(true);
        java.awt.Stroke stroke7 = ringPlot4.getSeparatorStroke();
        ringPlot0.setLabelLinkStroke(stroke7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = ringPlot0.getDrawingSupplier();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = ringPlot0.getDrawingSupplier();
        org.jfree.chart.util.Rotation rotation11 = org.jfree.chart.util.Rotation.CLOCKWISE;
        ringPlot0.setDirection(rotation11);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(drawingSupplier9);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertNotNull(rotation11);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", graphics2D1, (float) (short) 1, 0.8f, textAnchor4, (double) (byte) 10, (float) (-1), 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis2 = polarPlot0.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = polarPlot3.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range6 = polarPlot3.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis5);
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        boolean boolean8 = polarPlot0.isAngleGridlinesVisible();
        java.awt.Paint paint9 = polarPlot0.getAngleGridlinePaint();
        double double10 = polarPlot0.getMaxRadius();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        polarPlot0.zoomDomainAxes((double) 100L, plotRenderingInfo12, point2D13, false);
        boolean boolean17 = polarPlot0.equals((java.lang.Object) (short) 10);
        java.awt.Stroke stroke18 = polarPlot0.getRadiusGridlineStroke();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setPieCenterX((double) 0);
        piePlotState1.setPieWRadius((double) 10.0f);
        int int6 = piePlotState1.getPassesRequired();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        boolean boolean16 = xYPlot14.isDomainZeroBaselineVisible();
        int int17 = xYPlot14.getSeriesCount();
        java.awt.Paint paint18 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        xYPlot14.setBackgroundPaint(paint18);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.lang.Class<?> wildcardClass3 = color2.getClass();
        java.lang.ClassLoader classLoader4 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass3);
        java.net.URL uRL5 = org.jfree.chart.util.ObjectUtilities.getResource("http://www.jfree.org/jfreechart/index.html", (java.lang.Class) wildcardClass3);
        java.net.URL uRL6 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass3);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(classLoader4);
        org.junit.Assert.assertNull(uRL5);
        org.junit.Assert.assertNotNull(uRL6);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getLabelLinksVisible();
        ringPlot0.setSectionOutlinesVisible(true);
        java.awt.Paint paint4 = ringPlot0.getBaseSectionOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = ringPlot0.getLabelPadding();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo1);
        projectInfo1.setCopyright("Pie Plot");
        projectInfo1.setInfo("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange((double) 100);
        java.lang.String str3 = dateAxis0.getLabelToolTip();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis0.getTickUnit();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateTickUnit4);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        ringPlot0.setShadowYOffset((double) 100.0f);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = ringPlot0.getURLGenerator();
        double double6 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color7);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = polarPlot11.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis13 = polarPlot11.getAxis();
        polarPlot11.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("hi!", font10, (org.jfree.chart.plot.Plot) polarPlot11, true);
        java.awt.Image image18 = null;
        jFreeChart17.setBackgroundImage(image18);
        boolean boolean20 = ringPlot0.equals((java.lang.Object) jFreeChart17);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.util.Rotation rotation1 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = polarPlot5.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range8 = polarPlot5.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis7);
        polarPlot2.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis7);
        boolean boolean10 = rotation1.equals((java.lang.Object) polarPlot2);
        double double11 = polarPlot2.getMaxRadius();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot2);
        polarPlot2.setAngleGridlinesVisible(false);
        polarPlot2.setAngleLabelsVisible(false);
        org.junit.Assert.assertNotNull(rotation1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlock textBlock4 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.awt.Shape shape12 = textBlock4.calculateBounds(graphics2D5, (float) (short) 0, 0.0f, textBlockAnchor8, (float) 2, (float) 1, 0.05d);
        textBlock0.draw(graphics2D1, (float) 10L, (float) '#', textBlockAnchor8, 0.0f, (float) '#', (double) (byte) 1);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        boolean boolean16 = xYPlot14.isDomainZeroBaselineVisible();
        java.awt.geom.Point2D point2D17 = null;
        try {
            xYPlot14.setQuadrantOrigin(point2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        double double3 = ringPlot0.getOuterSeparatorExtension();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        ringPlot4.setIgnoreNullValues(true);
        java.awt.Stroke stroke7 = ringPlot4.getSeparatorStroke();
        ringPlot0.setLabelLinkStroke(stroke7);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = polarPlot10.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis12 = polarPlot10.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = polarPlot13.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range16 = polarPlot13.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis15);
        polarPlot10.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis15);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat20 = numberAxis19.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit21 = numberAxis19.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis19, xYItemRenderer22);
        xYPlot23.clearRangeMarkers();
        java.awt.Font font25 = xYPlot23.getNoDataMessageFont();
        ringPlot0.setLabelFont(font25);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNull(numberFormat20);
        org.junit.Assert.assertNotNull(numberTickUnit21);
        org.junit.Assert.assertNotNull(font25);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart8.removeProgressListener(chartProgressListener11);
        org.jfree.chart.title.LegendTitle legendTitle13 = jFreeChart8.getLegend();
        jFreeChart8.setBorderVisible(true);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(legendTitle13);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        java.lang.Number number35 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset19);
        try {
            java.lang.Number number36 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset19);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + (-1.0d) + "'", number35.equals((-1.0d)));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("http://www.jfree.org/jfreechart/index.html");
        numberAxis1.setUpperMargin((double) ' ');
        double double4 = numberAxis1.getLabelAngle();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator1 = null;
        ringPlot0.setURLGenerator(pieURLGenerator1);
        boolean boolean3 = ringPlot0.isOutlineVisible();
        ringPlot0.setMinimumArcAngleToDraw(0.0d);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator6 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator6);
        java.text.AttributedString attributedString9 = null;
        standardPieSectionLabelGenerator6.setAttributedLabel(0, attributedString9);
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        ringPlot11.setIgnoreNullValues(true);
        double double14 = ringPlot11.getInnerSeparatorExtension();
        ringPlot11.setOuterSeparatorExtension(0.0d);
        org.jfree.chart.util.Rotation rotation17 = ringPlot11.getDirection();
        java.lang.Object obj18 = ringPlot11.clone();
        float float19 = ringPlot11.getForegroundAlpha();
        boolean boolean20 = standardPieSectionLabelGenerator6.equals((java.lang.Object) ringPlot11);
        ringPlot11.setStartAngle(4.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertNotNull(rotation17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundAlpha((float) (-1));
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        java.lang.Object obj4 = jFreeChart3.clone();
        java.lang.Object obj5 = jFreeChart3.clone();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        try {
            java.awt.image.BufferedImage bufferedImage9 = jFreeChart3.createBufferedImage((int) (byte) 100, (int) (byte) -1, chartRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (100) and height (-1) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        java.awt.Stroke stroke3 = ringPlot0.getSeparatorStroke();
        double double4 = ringPlot0.getMinimumArcAngleToDraw();
        ringPlot0.setLabelLinksVisible(true);
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = polarPlot9.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis11 = polarPlot9.getAxis();
        polarPlot9.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("hi!", font8, (org.jfree.chart.plot.Plot) polarPlot9, true);
        org.jfree.chart.title.Title title16 = null;
        jFreeChart15.removeSubtitle(title16);
        org.jfree.chart.event.ChartProgressListener chartProgressListener18 = null;
        jFreeChart15.removeProgressListener(chartProgressListener18);
        int int20 = jFreeChart15.getSubtitleCount();
        jFreeChart15.clearSubtitles();
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_RED;
        jFreeChart15.setBorderPaint((java.awt.Paint) color22);
        ringPlot0.setSeparatorPaint((java.awt.Paint) color22);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator25 = ringPlot0.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-5d + "'", double4 == 1.0E-5d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(pieSectionLabelGenerator25);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range3 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis2);
        dateAxis2.setLabelURL("hi!");
        dateAxis2.configure();
        dateAxis2.setAutoTickUnitSelection(true);
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        double double10 = ringPlot9.getMaximumExplodePercent();
        ringPlot9.setBackgroundAlpha((float) (-1));
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot9);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        ringPlot9.setLabelFont(font14);
        java.lang.String str16 = ringPlot9.getPlotType();
        boolean boolean17 = dateAxis2.equals((java.lang.Object) ringPlot9);
        dateAxis2.setFixedAutoRange((double) 'a');
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Pie Plot" + "'", str16.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setPieCenterX((double) 0);
        piePlotState1.setPieWRadius((double) 10.0f);
        piePlotState1.setLatestAngle(0.0d);
        double double8 = piePlotState1.getTotal();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range3 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis2);
        dateAxis2.setLabelURL("hi!");
        boolean boolean6 = dateAxis2.isInverted();
        dateAxis2.configure();
        java.util.Date date8 = dateAxis2.getMaximumDate();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean1 = categoryAxis3D0.isTickLabelsVisible();
        java.lang.Object obj2 = categoryAxis3D0.clone();
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = polarPlot8.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis10 = polarPlot8.getAxis();
        polarPlot8.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font7, (org.jfree.chart.plot.Plot) polarPlot8, true);
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("hi!", font7);
        textTitle15.setPadding((double) (short) 10, (-1.0d), 0.2d, (double) '#');
        java.awt.geom.Rectangle2D rectangle2D21 = textTitle15.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D21);
        double[] doubleArray28 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray32 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray36 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray40 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray41 = new double[][] { doubleArray28, doubleArray32, doubleArray36, doubleArray40 };
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray41);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D43 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean44 = categoryAxis3D43.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot45 = categoryAxis3D43.getPlot();
        categoryAxis3D43.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot48 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = polarPlot48.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range51 = polarPlot48.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis50);
        dateAxis50.setAutoTickUnitSelection(true, false);
        java.util.Date date55 = dateAxis50.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D43, (org.jfree.chart.axis.ValueAxis) dateAxis50, categoryItemRenderer56);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D58 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean59 = categoryAxis3D58.isTickLabelsVisible();
        boolean boolean60 = categoryAxis3D58.isVisible();
        int int61 = categoryPlot57.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D58);
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = categoryPlot57.getRangeAxisEdge();
        double double63 = categoryAxis3D0.getCategoryMiddle((int) (short) 10, (int) (short) -1, rectangle2D21, rectangleEdge62);
        org.jfree.chart.plot.RingPlot ringPlot66 = new org.jfree.chart.plot.RingPlot();
        double double67 = ringPlot66.getMaximumExplodePercent();
        ringPlot66.setBackgroundAlpha((float) (-1));
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent70 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot66);
        java.awt.Font font71 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        ringPlot66.setLabelFont(font71);
        org.jfree.chart.text.TextLine textLine73 = new org.jfree.chart.text.TextLine("", font71);
        org.jfree.chart.text.TextFragment textFragment74 = textLine73.getLastTextFragment();
        java.awt.Font font75 = textFragment74.getFont();
        categoryAxis3D0.setTickLabelFont((java.lang.Comparable) (short) 0, font75);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNull(plot45);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNull(range51);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(font71);
        org.junit.Assert.assertNotNull(textFragment74);
        org.junit.Assert.assertNotNull(font75);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.awt.Color color2 = java.awt.Color.getColor("1.2.0-pre", (int) (short) 1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers(layer18);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot14.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        xYPlot14.setRenderer(xYItemRenderer23);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        dateAxis25.centerRange((double) 100);
        java.lang.String str28 = dateAxis25.getLabelToolTip();
        xYPlot14.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis25);
        dateAxis25.configure();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNull(str28);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = null;
        xYPlot14.datasetChanged(datasetChangeEvent18);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = xYPlot14.getRangeAxisEdge();
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        int int22 = xYPlot14.indexOf(xYDataset21);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = polarPlot3.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis5 = polarPlot3.getAxis();
        polarPlot3.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", font2, (org.jfree.chart.plot.Plot) polarPlot3, true);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font2);
        textTitle10.setPadding((double) (short) 10, (-1.0d), 0.2d, (double) '#');
        textTitle10.setMargin((double) '4', 0.0d, (double) (short) 1, 0.0d);
        java.awt.Font font21 = textTitle10.getFont();
        java.awt.Font font22 = textTitle10.getFont();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(font22);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean1 = categoryAxis3D0.isTickLabelsVisible();
        java.lang.Object obj2 = categoryAxis3D0.clone();
        java.awt.Font font4 = categoryAxis3D0.getTickLabelFont((java.lang.Comparable) 1.0d);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = categoryAxis3D0.getCategoryLabelPositions();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        ringPlot4.setIgnoreNullValues(true);
        java.awt.Stroke stroke7 = ringPlot4.getSeparatorStroke();
        ringPlot0.setSectionOutlineStroke((java.lang.Comparable) 0, stroke7);
        boolean boolean9 = ringPlot0.getSectionOutlinesVisible();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 0.05d, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundAlpha((float) (-1));
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        polarPlot0.datasetChanged(datasetChangeEvent4);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) 2.0d);
        java.lang.Object obj3 = strokeMap0.clone();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        double double5 = ringPlot4.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = ringPlot4.getLabelPadding();
        double double7 = ringPlot4.getOuterSeparatorExtension();
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        ringPlot8.setIgnoreNullValues(true);
        double double11 = ringPlot8.getInnerSeparatorExtension();
        ringPlot8.setOuterSeparatorExtension(0.0d);
        org.jfree.chart.util.Rotation rotation14 = ringPlot8.getDirection();
        ringPlot4.setParent((org.jfree.chart.plot.Plot) ringPlot8);
        boolean boolean16 = strokeMap0.equals((java.lang.Object) ringPlot8);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertNotNull(rotation14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis2 = polarPlot0.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = polarPlot3.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range6 = polarPlot3.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis5);
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        boolean boolean8 = polarPlot0.isAngleGridlinesVisible();
        java.awt.Paint paint9 = polarPlot0.getAngleGridlinePaint();
        double double10 = polarPlot0.getMaxRadius();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        polarPlot0.zoomDomainAxes((double) 100L, plotRenderingInfo12, point2D13, false);
        boolean boolean17 = polarPlot0.equals((java.lang.Object) (short) 10);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat20 = numberAxis19.getNumberFormatOverride();
        org.jfree.data.Range range21 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis19);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(numberFormat20);
        org.junit.Assert.assertNull(range21);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = polarPlot5.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range8 = polarPlot5.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis7);
        polarPlot2.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat12 = numberAxis11.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = numberAxis11.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis11, xYItemRenderer14);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot15.getDomainMarkers(1, layer17);
        java.awt.Paint paint19 = xYPlot15.getDomainCrosshairPaint();
        boolean boolean20 = xYPlot15.isRangeCrosshairVisible();
        java.awt.Paint paint21 = xYPlot15.getOutlinePaint();
        double[] doubleArray27 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray31 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray35 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray39 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray40 = new double[][] { doubleArray27, doubleArray31, doubleArray35, doubleArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray40);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D42 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean43 = categoryAxis3D42.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot44 = categoryAxis3D42.getPlot();
        categoryAxis3D42.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot47 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = polarPlot47.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range50 = polarPlot47.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis49);
        dateAxis49.setAutoTickUnitSelection(true, false);
        java.util.Date date54 = dateAxis49.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer55 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D42, (org.jfree.chart.axis.ValueAxis) dateAxis49, categoryItemRenderer55);
        org.jfree.chart.axis.AxisSpace axisSpace57 = null;
        categoryPlot56.setFixedDomainAxisSpace(axisSpace57);
        categoryPlot56.setWeight((int) '4');
        categoryPlot56.clearAnnotations();
        java.awt.Stroke stroke62 = categoryPlot56.getRangeCrosshairStroke();
        java.awt.Paint paint63 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        java.awt.Stroke stroke64 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker66 = new org.jfree.chart.plot.ValueMarker(1.0d, paint21, stroke62, paint63, stroke64, (float) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(numberFormat12);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNull(plot44);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(paint63);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        ringPlot2.setIgnoreNullValues(true);
        double double5 = ringPlot2.getInnerSeparatorExtension();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat8 = numberAxis7.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = numberAxis7.getTickUnit();
        ringPlot2.setExplodePercent((java.lang.Comparable) numberTickUnit9, (double) 2);
        numberAxis1.setTickUnit(numberTickUnit9, false, false);
        numberAxis1.setTickMarkInsideLength((float) (byte) 100);
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        numberAxis1.setLabelFont(font17);
        boolean boolean19 = numberAxis1.isTickMarksVisible();
        java.lang.Object obj20 = numberAxis1.clone();
        float float21 = numberAxis1.getTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(numberTickUnit9);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 100.0f + "'", float21 == 100.0f);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        java.awt.Image image9 = null;
        jFreeChart8.setBackgroundImage(image9);
        jFreeChart8.setBackgroundImageAlpha((float) 0L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        java.awt.image.BufferedImage bufferedImage16 = jFreeChart8.createBufferedImage(1, (int) '4', chartRenderingInfo15);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(bufferedImage16);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        org.jfree.chart.LegendItemCollection legendItemCollection39 = categoryPlot34.getFixedLegendItems();
        double double40 = categoryPlot34.getRangeCrosshairValue();
        java.util.List list41 = categoryPlot34.getAnnotations();
        int int42 = categoryPlot34.getWeight();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation43 = null;
        try {
            boolean boolean44 = categoryPlot34.removeAnnotation(categoryAnnotation43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNull(legendItemCollection39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range4 = org.jfree.data.Range.shift(range1, (double) 10, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 10, range1);
        org.jfree.data.Range range6 = rectangleConstraint5.getHeightRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint5.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        categoryPlot34.setFixedDomainAxisSpace(axisSpace35);
        categoryPlot34.setWeight((int) '4');
        categoryPlot34.clearAnnotations();
        categoryPlot34.setAnchorValue((double) 8, false);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot14.getDomainAxisLocation();
        java.awt.Stroke stroke17 = xYPlot14.getDomainZeroBaselineStroke();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        java.awt.Stroke stroke3 = ringPlot0.getSeparatorStroke();
        double double4 = ringPlot0.getMinimumArcAngleToDraw();
        double double5 = ringPlot0.getSectionDepth();
        ringPlot0.setCircular(false);
        java.awt.Stroke stroke8 = ringPlot0.getLabelOutlineStroke();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-5d + "'", double4 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        int int35 = categoryPlot34.getRangeAxisCount();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray36 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot34.setRangeAxes(valueAxisArray36);
        org.jfree.chart.util.Rotation rotation39 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D40 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean41 = categoryAxis3D40.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot42 = categoryAxis3D40.getPlot();
        boolean boolean43 = rotation39.equals((java.lang.Object) categoryAxis3D40);
        categoryPlot34.setDomainAxis((int) 'a', (org.jfree.chart.axis.CategoryAxis) categoryAxis3D40);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(valueAxisArray36);
        org.junit.Assert.assertNotNull(rotation39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNull(plot42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("TextAnchor.BOTTOM_LEFT", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=1.0]", "Category Plot", "TextAnchor.BOTTOM_LEFT");
        java.lang.String str5 = library4.getName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextAnchor.BOTTOM_LEFT" + "'", str5.equals("TextAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        org.jfree.chart.LegendItemCollection legendItemCollection39 = categoryPlot34.getFixedLegendItems();
        java.lang.String str40 = categoryPlot34.getPlotType();
        categoryPlot34.configureRangeAxes();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNull(legendItemCollection39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Category Plot" + "'", str40.equals("Category Plot"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        ringPlot3.setIgnoreNullValues(true);
        double double6 = ringPlot3.getInnerSeparatorExtension();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat9 = numberAxis8.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = numberAxis8.getTickUnit();
        ringPlot3.setExplodePercent((java.lang.Comparable) numberTickUnit10, (double) 2);
        numberAxis2.setTickUnit(numberTickUnit10, false, false);
        numberAxis2.setTickMarkInsideLength((float) (byte) 100);
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        numberAxis2.setLabelFont(font18);
        java.awt.Color color23 = java.awt.Color.getHSBColor(1.0f, (float) 10L, (float) '4');
        org.jfree.chart.text.TextBlock textBlock24 = org.jfree.chart.text.TextUtilities.createTextBlock("", font18, (java.awt.Paint) color23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor28 = null;
        textBlock24.draw(graphics2D25, (float) 10L, (-1.0f), textBlockAnchor28);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNull(numberFormat9);
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(textBlock24);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        java.awt.Shape shape13 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D7, 0.0f, (float) 10, textAnchor10, 0.025d, textAnchor12);
        try {
            java.awt.Shape shape14 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=1.0]", graphics2D1, (float) (-1L), (float) 100L, textAnchor4, (double) 8, textAnchor12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNull(shape13);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = numberAxis10.getTickLabelInsets();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        categoryPlot34.setFixedDomainAxisSpace(axisSpace35);
        categoryPlot34.setWeight((int) '4');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        java.awt.geom.Point2D point2D41 = null;
        categoryPlot34.zoomDomainAxes(0.0d, plotRenderingInfo40, point2D41, false);
        boolean boolean44 = categoryPlot34.isRangeZoomable();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        org.jfree.chart.LegendItemCollection legendItemCollection39 = categoryPlot34.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot34.getRangeAxisEdge((int) '4');
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean44 = categoryPlot34.equals((java.lang.Object) numberAxis43);
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = categoryPlot34.getRendererForDataset(categoryDataset45);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        java.awt.geom.Point2D point2D50 = null;
        categoryPlot34.zoomRangeAxes(1.0E-5d, 10.0d, plotRenderingInfo49, point2D50);
        java.awt.Paint paint52 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        categoryPlot34.setDomainGridlinePaint(paint52);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNull(legendItemCollection39);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(categoryItemRenderer46);
        org.junit.Assert.assertNotNull(paint52);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.awt.Color color0 = java.awt.Color.green;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        ringPlot1.setIgnoreNullValues(true);
        double double4 = ringPlot1.getInnerSeparatorExtension();
        ringPlot1.setOuterSeparatorExtension(0.0d);
        org.jfree.chart.util.Rotation rotation7 = ringPlot1.getDirection();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = polarPlot9.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis11 = polarPlot9.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = polarPlot12.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range15 = polarPlot12.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis14);
        polarPlot9.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat19 = numberAxis18.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit20 = numberAxis18.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis18, xYItemRenderer21);
        xYPlot22.clearRangeMarkers();
        boolean boolean24 = rotation7.equals((java.lang.Object) xYPlot22);
        java.awt.Stroke stroke25 = xYPlot22.getDomainCrosshairStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = null;
        try {
            org.jfree.chart.block.LineBorder lineBorder27 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke25, rectangleInsets26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNull(numberFormat19);
        org.junit.Assert.assertNotNull(numberTickUnit20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range3 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) polarPlot0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = plotChangeEvent5.getType();
        org.jfree.chart.JFreeChart jFreeChart7 = plotChangeEvent5.getChart();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(chartChangeEventType6);
        org.junit.Assert.assertNull(jFreeChart7);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        double double3 = ringPlot0.getInnerSeparatorExtension();
        ringPlot0.setOuterSeparatorExtension(0.0d);
        org.jfree.chart.util.Rotation rotation6 = ringPlot0.getDirection();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor8 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) -1);
        ringPlot0.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor8);
        int int10 = pieLabelDistributor8.getItemCount();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(rotation6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (double) 3, (double) (-1), 0.0d);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean7 = categoryAxis3D6.isTickLabelsVisible();
        java.lang.Object obj8 = categoryAxis3D6.clone();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = polarPlot14.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis16 = polarPlot14.getAxis();
        polarPlot14.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("hi!", font13, (org.jfree.chart.plot.Plot) polarPlot14, true);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("hi!", font13);
        textTitle21.setPadding((double) (short) 10, (-1.0d), 0.2d, (double) '#');
        java.awt.geom.Rectangle2D rectangle2D27 = textTitle21.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity28 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D27);
        double[] doubleArray34 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray38 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray42 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray46 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray47 = new double[][] { doubleArray34, doubleArray38, doubleArray42, doubleArray46 };
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray47);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D49 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean50 = categoryAxis3D49.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot51 = categoryAxis3D49.getPlot();
        categoryAxis3D49.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot54 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = polarPlot54.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range57 = polarPlot54.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis56);
        dateAxis56.setAutoTickUnitSelection(true, false);
        java.util.Date date61 = dateAxis56.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer62 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot63 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D49, (org.jfree.chart.axis.ValueAxis) dateAxis56, categoryItemRenderer62);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D64 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean65 = categoryAxis3D64.isTickLabelsVisible();
        boolean boolean66 = categoryAxis3D64.isVisible();
        int int67 = categoryPlot63.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D64);
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = categoryPlot63.getRangeAxisEdge();
        double double69 = categoryAxis3D6.getCategoryMiddle((int) (short) 10, (int) (short) -1, rectangle2D27, rectangleEdge68);
        java.awt.geom.Rectangle2D rectangle2D70 = rectangleInsets5.createOutsetRectangle(rectangle2D27);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNull(plot51);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNull(range57);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D70);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange((double) 100);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis6 = polarPlot4.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = polarPlot7.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range10 = polarPlot7.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis9);
        polarPlot4.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat14 = numberAxis13.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = numberAxis13.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = xYPlot17.getRenderer();
        xYPlot17.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot17.getDomainMarkers(layer21);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot17.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        xYPlot17.setRenderer(xYItemRenderer26);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot17);
        double double29 = dateAxis0.getFixedAutoRange();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(numberFormat14);
        org.junit.Assert.assertNotNull(numberTickUnit15);
        org.junit.Assert.assertNull(xYItemRenderer18);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = numberAxis1.getTickUnit();
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        org.jfree.chart.plot.Plot plot5 = null;
        numberAxis1.setPlot(plot5);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = null;
        numberAxis1.setMarkerBand(markerAxisBand7);
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("1.2.0-pre", graphics2D1, (float) (-1), 0.5f, textAnchor4, 45.0d, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) "RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", (double) 1L, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        waferMapPlot0.setRenderer(waferMapRenderer1);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = waferMapPlot0.getDataset();
        org.junit.Assert.assertNull(waferMapDataset3);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        int int35 = categoryPlot34.getRangeAxisCount();
        categoryPlot34.clearDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        categoryPlot34.setRenderer(categoryItemRenderer37);
        double double39 = categoryPlot34.getAnchorValue();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        double double3 = ringPlot0.getOuterSeparatorExtension();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        ringPlot4.setIgnoreNullValues(true);
        java.awt.Stroke stroke7 = ringPlot4.getSeparatorStroke();
        ringPlot0.setLabelLinkStroke(stroke7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = ringPlot0.getDrawingSupplier();
        java.lang.String str10 = ringPlot0.getPlotType();
        java.awt.Font font11 = ringPlot0.getLabelFont();
        java.awt.Color color12 = java.awt.Color.white;
        ringPlot0.setSeparatorPaint((java.awt.Paint) color12);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(drawingSupplier9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Pie Plot" + "'", str10.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        xYPlot14.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot14.getDomainAxis((int) (short) 0);
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot14.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker19);
        boolean boolean21 = xYPlot14.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisSpace axisSpace22 = xYPlot14.getFixedDomainAxisSpace();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        double double25 = categoryAxis24.getUpperMargin();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D28 = new org.jfree.chart.axis.CategoryAxis3D();
        double double29 = categoryAxis3D28.getCategoryMargin();
        java.awt.Font font34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot35 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = polarPlot35.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis37 = polarPlot35.getAxis();
        polarPlot35.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart41 = new org.jfree.chart.JFreeChart("hi!", font34, (org.jfree.chart.plot.Plot) polarPlot35, true);
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("hi!", font34);
        java.awt.geom.Rectangle2D rectangle2D43 = textTitle42.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double45 = categoryAxis3D28.getCategoryStart((int) (short) 10, (int) '4', rectangle2D43, rectangleEdge44);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double47 = categoryAxis24.getCategoryEnd(15, (int) '4', rectangle2D43, rectangleEdge46);
        try {
            xYPlot14.drawBackground(graphics2D23, rectangle2D43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(valueAxis17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(axisSpace22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.2d + "'", double29 == 0.2d);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNull(valueAxis37);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis6 = polarPlot4.getAxis();
        polarPlot4.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("hi!", font3, (org.jfree.chart.plot.Plot) polarPlot4, true);
        org.jfree.chart.title.Title title11 = null;
        jFreeChart10.removeSubtitle(title11);
        org.jfree.chart.event.ChartProgressListener chartProgressListener13 = null;
        jFreeChart10.removeProgressListener(chartProgressListener13);
        int int15 = jFreeChart10.getSubtitleCount();
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        jFreeChart10.setBorderStroke(stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        ringPlot21.setIgnoreNullValues(true);
        java.awt.Stroke stroke24 = ringPlot21.getSeparatorStroke();
        java.awt.Stroke[] strokeArray25 = new java.awt.Stroke[] { stroke16, stroke18, stroke19, stroke20, stroke24 };
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D29 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean30 = categoryAxis3D29.isTickLabelsVisible();
        java.awt.Stroke stroke31 = categoryAxis3D29.getTickMarkStroke();
        java.awt.Stroke[] strokeArray32 = new java.awt.Stroke[] { stroke26, stroke27, stroke28, stroke31 };
        org.jfree.chart.plot.RingPlot ringPlot33 = new org.jfree.chart.plot.RingPlot();
        double double34 = ringPlot33.getMaximumExplodePercent();
        java.awt.Shape shape35 = ringPlot33.getLegendItemShape();
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] { shape35, shape36 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray25, strokeArray32, shapeArray37);
        java.awt.Stroke stroke39 = defaultDrawingSupplier38.getNextStroke();
        java.awt.Paint paint40 = defaultDrawingSupplier38.getNextPaint();
        java.lang.Object obj41 = defaultDrawingSupplier38.clone();
        java.awt.Shape shape42 = defaultDrawingSupplier38.getNextShape();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(strokeArray25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(strokeArray32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNotNull(shape42);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        categoryPlot34.setFixedDomainAxisSpace(axisSpace35);
        categoryPlot34.setWeight((int) '4');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        java.awt.geom.Point2D point2D41 = null;
        categoryPlot34.zoomDomainAxes(0.0d, plotRenderingInfo40, point2D41, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = null;
        try {
            categoryPlot34.setAxisOffset(rectangleInsets44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        int int35 = categoryPlot34.getDomainAxisCount();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 1.0E-5d, 0.08d);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, (double) (short) -1);
        flowArrangement4.clear();
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers(layer18);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot14.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        xYPlot14.setRenderer(xYItemRenderer23);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        dateAxis25.centerRange((double) 100);
        java.lang.String str28 = dateAxis25.getLabelToolTip();
        xYPlot14.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis25);
        org.jfree.chart.axis.ValueAxis valueAxis30 = xYPlot14.getDomainAxis();
        boolean boolean31 = xYPlot14.isDomainGridlinesVisible();
        xYPlot14.clearRangeMarkers();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(valueAxis30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isRangeGridlinesVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        int int17 = xYPlot14.getIndexOf(xYItemRenderer16);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot14.getDomainAxisEdge(100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        try {
            xYPlot14.zoomRangeAxes((double) 100, 45.0d, plotRenderingInfo22, point2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (105.0) <= upper (47.25).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        double double3 = ringPlot0.getOuterSeparatorExtension();
        double double4 = ringPlot0.getInteriorGap();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.08d + "'", double4 == 0.08d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean1 = categoryAxis3D0.isTickLabelsVisible();
        java.lang.Object obj2 = categoryAxis3D0.clone();
        double[] doubleArray8 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray12 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray16 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray20 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray21 = new double[][] { doubleArray8, doubleArray12, doubleArray16, doubleArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray21);
        boolean boolean23 = categoryAxis3D0.equals((java.lang.Object) "");
        categoryAxis3D0.setUpperMargin((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        boolean boolean39 = categoryPlot34.getDrawSharedDomainAxis();
        categoryPlot34.setRangeCrosshairValue((double) (byte) -1, false);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot34.getRangeAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset40 = categoryPlot34.getDataset();
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = null;
        org.jfree.chart.util.Layer layer42 = null;
        try {
            categoryPlot34.addDomainMarker(categoryMarker41, layer42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(categoryDataset40);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        int int35 = categoryPlot34.getRangeAxisCount();
        categoryPlot34.clearDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = categoryPlot34.getRenderer((int) (short) 100);
        java.awt.Paint paint39 = categoryPlot34.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNull(categoryItemRenderer38);
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        java.lang.Number number35 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset19);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset19, false);
        try {
            org.jfree.data.general.PieDataset pieDataset39 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset19, (java.lang.Comparable) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + (-1.0d) + "'", number35.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range37);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        org.jfree.chart.LegendItemCollection legendItemCollection39 = categoryPlot34.getFixedLegendItems();
        double double40 = categoryPlot34.getRangeCrosshairValue();
        java.util.List list41 = categoryPlot34.getAnnotations();
        categoryPlot34.zoom(2.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNull(legendItemCollection39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(list41);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        java.lang.Number number35 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset19);
        java.lang.Number number36 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset19);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + (-1.0d) + "'", number35.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 208.0d + "'", number36.equals(208.0d));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart8.removeProgressListener(chartProgressListener11);
        jFreeChart8.setAntiAlias(false);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = lineBorder0.getInsets();
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getCategoryMargin();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = polarPlot7.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis9 = polarPlot7.getAxis();
        polarPlot7.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("hi!", font6, (org.jfree.chart.plot.Plot) polarPlot7, true);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("hi!", font6);
        java.awt.geom.Rectangle2D rectangle2D15 = textTitle14.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double17 = categoryAxis3D0.getCategoryStart((int) (short) 10, (int) '4', rectangle2D15, rectangleEdge16);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = polarPlot24.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis26 = polarPlot24.getAxis();
        polarPlot24.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("hi!", font23, (org.jfree.chart.plot.Plot) polarPlot24, true);
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle("hi!", font23);
        textTitle31.setPadding((double) (short) 10, (-1.0d), 0.2d, (double) '#');
        textTitle31.setMargin((double) '4', 0.0d, (double) (short) 1, 0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = org.jfree.chart.util.RectangleEdge.LEFT;
        textTitle31.setPosition(rectangleEdge42);
        try {
            double double44 = categoryAxis3D0.getCategoryMiddle(0, 8, rectangle2D20, rectangleEdge42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertNotNull(rectangleEdge42);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent39 = null;
        categoryPlot34.datasetChanged(datasetChangeEvent39);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        java.awt.geom.Point2D point2D44 = null;
        categoryPlot34.zoomRangeAxes((double) 0.8f, 0.0d, plotRenderingInfo43, point2D44);
        java.awt.Paint paint46 = categoryPlot34.getBackgroundPaint();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(paint46);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers(layer18);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot14.getRangeMarkers((-1), layer21);
        java.awt.Stroke stroke23 = xYPlot14.getDomainCrosshairStroke();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.plot.RingPlot ringPlot25 = new org.jfree.chart.plot.RingPlot();
        double double26 = ringPlot25.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = ringPlot25.getLabelPadding();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator28 = null;
        ringPlot25.setLegendLabelToolTipGenerator(pieSectionLabelGenerator28);
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.Font font33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot34 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = polarPlot34.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis36 = polarPlot34.getAxis();
        polarPlot34.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart40 = new org.jfree.chart.JFreeChart("hi!", font33, (org.jfree.chart.plot.Plot) polarPlot34, true);
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle("hi!", font33);
        textTitle41.setPadding((double) (short) 10, (-1.0d), 0.2d, (double) '#');
        java.awt.geom.Rectangle2D rectangle2D47 = textTitle41.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double49 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D47, rectangleEdge48);
        ringPlot25.drawBackgroundImage(graphics2D30, rectangle2D47);
        xYPlot14.drawBackgroundImage(graphics2D24, rectangle2D47);
        java.awt.Paint paint52 = xYPlot14.getDomainCrosshairPaint();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNull(valueAxis36);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(paint52);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        java.awt.Stroke stroke3 = ringPlot0.getSeparatorStroke();
        double double4 = ringPlot0.getMinimumArcAngleToDraw();
        ringPlot0.setLabelLinksVisible(true);
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = polarPlot9.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis11 = polarPlot9.getAxis();
        polarPlot9.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("hi!", font8, (org.jfree.chart.plot.Plot) polarPlot9, true);
        org.jfree.chart.title.Title title16 = null;
        jFreeChart15.removeSubtitle(title16);
        org.jfree.chart.event.ChartProgressListener chartProgressListener18 = null;
        jFreeChart15.removeProgressListener(chartProgressListener18);
        int int20 = jFreeChart15.getSubtitleCount();
        jFreeChart15.clearSubtitles();
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_RED;
        jFreeChart15.setBorderPaint((java.awt.Paint) color22);
        ringPlot0.setSeparatorPaint((java.awt.Paint) color22);
        double double25 = ringPlot0.getStartAngle();
        java.awt.Image image26 = ringPlot0.getBackgroundImage();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-5d + "'", double4 == 1.0E-5d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNull(image26);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart8.removeProgressListener(chartProgressListener11);
        int int13 = jFreeChart8.getSubtitleCount();
        jFreeChart8.clearSubtitles();
        jFreeChart8.fireChartChanged();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers(layer18);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot14.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        xYPlot14.setRenderer(xYItemRenderer23);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        dateAxis25.centerRange((double) 100);
        java.lang.String str28 = dateAxis25.getLabelToolTip();
        xYPlot14.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis25);
        org.jfree.chart.axis.ValueAxis valueAxis30 = xYPlot14.getDomainAxis();
        org.jfree.chart.axis.ValueAxis valueAxis32 = xYPlot14.getDomainAxis((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation33 = null;
        try {
            xYPlot14.setDomainAxisLocation(axisLocation33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(valueAxis30);
        org.junit.Assert.assertNull(valueAxis32);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        ringPlot2.setIgnoreNullValues(true);
        double double5 = ringPlot2.getInnerSeparatorExtension();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat8 = numberAxis7.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = numberAxis7.getTickUnit();
        ringPlot2.setExplodePercent((java.lang.Comparable) numberTickUnit9, (double) 2);
        numberAxis1.setTickUnit(numberTickUnit9, false, false);
        numberAxis1.setFixedAutoRange((double) 2.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNull(numberFormat8);
        org.junit.Assert.assertNotNull(numberTickUnit9);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range3 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        polarPlot0.zoomDomainAxes(0.0d, plotRenderingInfo6, point2D7, false);
        java.awt.Paint paint10 = polarPlot0.getRadiusGridlinePaint();
        polarPlot0.addCornerTextItem("Size2D[width=0.0, height=0.0]");
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = null;
        try {
            dateAxis0.setRange(range1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setPieCenterX((double) 0);
        java.awt.geom.Rectangle2D rectangle2D4 = piePlotState1.getPieArea();
        double double5 = piePlotState1.getPieWRadius();
        org.junit.Assert.assertNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        xYPlot14.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot14.getDomainAxis((int) (short) 0);
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot14.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker19);
        boolean boolean21 = xYPlot14.isRangeZeroBaselineVisible();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(valueAxis17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        int int35 = categoryPlot34.getRangeAxisCount();
        categoryPlot34.clearDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = categoryPlot34.getRenderer((int) (short) 100);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        categoryPlot34.setDataset(categoryDataset39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = categoryPlot34.getDataset();
        int int42 = categoryPlot34.getDomainAxisCount();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNull(categoryItemRenderer38);
        org.junit.Assert.assertNull(categoryDataset41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeStickyZero();
        numberAxis0.setAutoRangeStickyZero(false);
        boolean boolean4 = numberAxis0.getAutoRangeStickyZero();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        valueMarker1.setValue((double) 3);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart8.removeProgressListener(chartProgressListener11);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart8.getLegend((int) (byte) 100);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart8.getLegend();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle15.setLegendItemGraphicLocation(rectangleAnchor16);
        org.jfree.chart.block.BlockContainer blockContainer18 = legendTitle15.getItemContainer();
        double double19 = blockContainer18.getContentXOffset();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertNotNull(legendTitle15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(blockContainer18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setPieCenterX((double) 0);
        piePlotState1.setPieWRadius((double) 10.0f);
        piePlotState1.setLatestAngle(0.0d);
        double double8 = piePlotState1.getLatestAngle();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = polarPlot3.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis5 = polarPlot3.getAxis();
        polarPlot3.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", font2, (org.jfree.chart.plot.Plot) polarPlot3, true);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font2);
        textTitle10.setPadding((double) (short) 10, (-1.0d), 0.2d, (double) '#');
        textTitle10.setMargin((double) '4', 0.0d, (double) (short) 1, 0.0d);
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = textTitle10.getVerticalAlignment();
        org.jfree.chart.plot.RingPlot ringPlot22 = new org.jfree.chart.plot.RingPlot();
        ringPlot22.setIgnoreNullValues(true);
        double double25 = ringPlot22.getInnerSeparatorExtension();
        int int26 = ringPlot22.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = ringPlot22.getSimpleLabelOffset();
        ringPlot22.setCircular(true, true);
        java.awt.Stroke stroke31 = ringPlot22.getSeparatorStroke();
        ringPlot22.setSectionOutlinesVisible(true);
        boolean boolean34 = verticalAlignment21.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(verticalAlignment21);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.2d + "'", double25 == 0.2d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 15 + "'", int26 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("TextAnchor.BOTTOM_LEFT", graphics2D1, (double) 1, 0.0f, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        double double3 = ringPlot0.getOuterSeparatorExtension();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        ringPlot4.setIgnoreNullValues(true);
        java.awt.Stroke stroke7 = ringPlot4.getSeparatorStroke();
        ringPlot0.setLabelLinkStroke(stroke7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = ringPlot0.getDrawingSupplier();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = ringPlot0.getDrawingSupplier();
        double double11 = ringPlot0.getOuterSeparatorExtension();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean13 = categoryAxis3D12.isTickLabelsVisible();
        java.lang.Object obj14 = categoryAxis3D12.clone();
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot();
        ringPlot15.setIgnoreNullValues(true);
        double double18 = ringPlot15.getInnerSeparatorExtension();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat21 = numberAxis20.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit22 = numberAxis20.getTickUnit();
        ringPlot15.setExplodePercent((java.lang.Comparable) numberTickUnit22, (double) 2);
        java.awt.Font font25 = categoryAxis3D12.getTickLabelFont((java.lang.Comparable) numberTickUnit22);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = polarPlot27.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis29 = polarPlot27.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot30 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = polarPlot30.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range33 = polarPlot30.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis32);
        polarPlot27.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis32);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat37 = numberAxis36.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit38 = numberAxis36.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) dateAxis32, (org.jfree.chart.axis.ValueAxis) numberAxis36, xYItemRenderer39);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = xYPlot40.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection42 = xYPlot40.getLegendItems();
        xYPlot40.mapDatasetToRangeAxis(10, (int) (byte) 1);
        java.awt.Paint paint46 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        xYPlot40.setDomainZeroBaselinePaint(paint46);
        ringPlot0.setSectionPaint((java.lang.Comparable) numberTickUnit22, paint46);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(drawingSupplier9);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.2d + "'", double18 == 0.2d);
        org.junit.Assert.assertNull(numberFormat21);
        org.junit.Assert.assertNotNull(numberTickUnit22);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNull(numberFormat37);
        org.junit.Assert.assertNotNull(numberTickUnit38);
        org.junit.Assert.assertNull(xYItemRenderer41);
        org.junit.Assert.assertNotNull(legendItemCollection42);
        org.junit.Assert.assertNotNull(paint46);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", "hi!", "hi!");
        basicProjectInfo4.addOptionalLibrary("http://www.jfree.org/jfreechart/index.html");
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo1);
        projectInfo1.setName("http://www.jfree.org/jfreechart/index.html");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers(layer18);
        boolean boolean20 = xYPlot14.isRangeZoomable();
        boolean boolean21 = xYPlot14.isRangeCrosshairLockedOnData();
        java.awt.Paint paint22 = xYPlot14.getDomainGridlinePaint();
        java.awt.Paint paint23 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        xYPlot14.setDomainZeroBaselinePaint(paint23);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = null;
        xYPlot14.datasetChanged(datasetChangeEvent18);
        xYPlot14.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.2d);
        valueMarker23.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = valueMarker23.getLabelOffset();
        org.jfree.chart.util.Layer layer27 = null;
        try {
            boolean boolean28 = xYPlot14.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker23, layer27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNotNull(rectangleInsets26);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = categoryPlot34.getDomainAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        java.awt.geom.Point2D point2D42 = null;
        categoryPlot34.zoomDomainAxes((double) 10.0f, plotRenderingInfo41, point2D42, false);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(categoryAxis39);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = polarPlot3.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis5 = polarPlot3.getAxis();
        polarPlot3.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", font2, (org.jfree.chart.plot.Plot) polarPlot3, true);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = textTitle10.getTextAlignment();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = polarPlot13.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis15 = polarPlot13.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = polarPlot16.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range19 = polarPlot16.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis18);
        polarPlot13.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis18);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat23 = numberAxis22.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit24 = numberAxis22.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer25);
        xYPlot26.clearRangeMarkers();
        java.awt.Font font28 = xYPlot26.getNoDataMessageFont();
        textTitle10.setFont(font28);
        textTitle10.setToolTipText("http://www.jfree.org/jfreechart/index.html");
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNull(numberFormat23);
        org.junit.Assert.assertNotNull(numberTickUnit24);
        org.junit.Assert.assertNotNull(font28);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis2 = polarPlot0.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = polarPlot3.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range6 = polarPlot3.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis5);
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        boolean boolean8 = polarPlot0.isAngleGridlinesVisible();
        java.awt.Paint paint9 = polarPlot0.getAngleGridlinePaint();
        double double10 = polarPlot0.getMaxRadius();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        polarPlot0.zoomDomainAxes((double) 100L, plotRenderingInfo12, point2D13, false);
        polarPlot0.setForegroundAlpha((float) (short) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        polarPlot0.zoomDomainAxes((double) 0.0f, (double) 0.0f, plotRenderingInfo20, point2D21);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        polarPlot0.setDataset(xYDataset23);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, (double) (short) -1);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        blockContainer5.clear();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.Size2D size2D8 = blockContainer5.arrange(graphics2D7);
        blockContainer5.clear();
        blockContainer5.clear();
        double double11 = blockContainer5.getHeight();
        org.junit.Assert.assertNotNull(size2D8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isVisible();
        dateAxis0.setAutoRangeMinimumSize(1.0E-5d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double1 = range0.getUpperBound();
        double double2 = range0.getLength();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        xYPlot14.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot14.getDomainAxis((int) (short) 0);
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot14.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker19);
        boolean boolean21 = xYPlot14.isDomainCrosshairVisible();
        int int22 = xYPlot14.getSeriesCount();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(valueAxis17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setPieCenterX((double) 0);
        piePlotState1.setPieWRadius((double) 10.0f);
        double double6 = piePlotState1.getPieCenterX();
        double double7 = piePlotState1.getLatestAngle();
        double double8 = piePlotState1.getPieWRadius();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart8.removeProgressListener(chartProgressListener11);
        org.jfree.chart.title.LegendTitle legendTitle13 = jFreeChart8.getLegend();
        org.jfree.chart.util.UnitType unitType14 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets(unitType14, 0.0d, (double) 3, (double) (-1), 0.0d);
        jFreeChart8.setPadding(rectangleInsets19);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(legendTitle13);
        org.junit.Assert.assertNotNull(unitType14);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        polarPlot0.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = polarPlot0.getInsets();
        double double6 = rectangleInsets4.trimHeight((double) (byte) 1);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-7.0d) + "'", double6 == (-7.0d));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = polarPlot3.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis5 = polarPlot3.getAxis();
        polarPlot3.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", font2, (org.jfree.chart.plot.Plot) polarPlot3, true);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = textTitle10.getTextAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle10.setHorizontalAlignment(horizontalAlignment12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = textTitle10.getPosition();
        textTitle10.setExpandToFitSpace(false);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis2 = polarPlot0.getAxis();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        polarPlot0.drawBackgroundImage(graphics2D3, rectangle2D4);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        polarPlot0.setRenderer(polarItemRenderer6);
        java.awt.Paint paint8 = polarPlot0.getOutlinePaint();
        polarPlot0.setAngleLabelsVisible(false);
        polarPlot0.setAngleLabelsVisible(true);
        boolean boolean13 = polarPlot0.isAngleGridlinesVisible();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers(layer18);
        boolean boolean20 = xYPlot14.isRangeZoomable();
        boolean boolean21 = xYPlot14.isRangeCrosshairLockedOnData();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent22 = null;
        xYPlot14.rendererChanged(rendererChangeEvent22);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo1);
        projectInfo1.addOptionalLibrary("");
        java.lang.String str5 = projectInfo1.getLicenceName();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "LGPL" + "'", str5.equals("LGPL"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        java.lang.Object obj3 = ringPlot0.clone();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        ringPlot0.handleClick(15, 15, plotRenderingInfo6);
        java.awt.Paint paint8 = ringPlot0.getBaseSectionOutlinePaint();
        float float9 = ringPlot0.getBackgroundAlpha();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.setAutoRangeIncludesZero(true);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isRangeGridlinesVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        int int17 = xYPlot14.getIndexOf(xYItemRenderer16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = xYPlot14.getRenderer((int) (byte) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot14.zoomDomainAxes((double) 10, (double) (byte) 10, plotRenderingInfo22, point2D23);
        org.jfree.data.xy.XYDataset xYDataset25 = xYPlot14.getDataset();
        java.awt.Stroke stroke26 = xYPlot14.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D28 = new org.jfree.chart.axis.CategoryAxis3D();
        double double29 = categoryAxis3D28.getCategoryMargin();
        java.awt.Font font34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot35 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = polarPlot35.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis37 = polarPlot35.getAxis();
        polarPlot35.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart41 = new org.jfree.chart.JFreeChart("hi!", font34, (org.jfree.chart.plot.Plot) polarPlot35, true);
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("hi!", font34);
        java.awt.geom.Rectangle2D rectangle2D43 = textTitle42.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double45 = categoryAxis3D28.getCategoryStart((int) (short) 10, (int) '4', rectangle2D43, rectangleEdge44);
        xYPlot14.drawBackgroundImage(graphics2D27, rectangle2D43);
        org.jfree.chart.axis.ValueAxis valueAxis48 = xYPlot14.getRangeAxis((int) (byte) 100);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(xYItemRenderer19);
        org.junit.Assert.assertNull(xYDataset25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.2d + "'", double29 == 0.2d);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNull(valueAxis37);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNull(valueAxis48);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Paint paint1 = blockBorder0.getPaint();
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = polarPlot3.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis5 = polarPlot3.getAxis();
        polarPlot3.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", font2, (org.jfree.chart.plot.Plot) polarPlot3, true);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = textTitle10.getTextAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle10.setHorizontalAlignment(horizontalAlignment12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = textTitle10.getMargin();
        org.jfree.chart.block.BlockFrame blockFrame15 = textTitle10.getFrame();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(blockFrame15);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.lang.Class<?> wildcardClass2 = color1.getClass();
        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass2);
        java.net.URL uRL4 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("TextAnchor.BOTTOM_LEFT", (java.lang.Class) wildcardClass2);
        java.lang.ClassLoader classLoader5 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass2);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(classLoader3);
        org.junit.Assert.assertNull(uRL4);
        org.junit.Assert.assertNotNull(classLoader5);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range3 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis2);
        dateAxis2.setAutoTickUnitSelection(true, false);
        java.util.Date date7 = dateAxis2.getMaximumDate();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis2.setTickUnit(dateTickUnit8);
        dateAxis2.resizeRange((double) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        dateAxis2.setLabelInsets(rectangleInsets12);
        double double14 = rectangleInsets12.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        double double3 = ringPlot0.getInnerSeparatorExtension();
        int int4 = ringPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = ringPlot0.getSimpleLabelOffset();
        ringPlot0.setCircular(true, true);
        java.awt.Stroke stroke9 = ringPlot0.getSeparatorStroke();
        double double10 = ringPlot0.getOuterSeparatorExtension();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        categoryPlot34.setFixedDomainAxisSpace(axisSpace35);
        categoryPlot34.setWeight((int) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        categoryPlot34.setRenderer(1, categoryItemRenderer40);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot34.getRangeAxisEdge(8);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(rectangleEdge43);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.util.Rotation rotation1 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = polarPlot5.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range8 = polarPlot5.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis7);
        polarPlot2.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis7);
        boolean boolean10 = rotation1.equals((java.lang.Object) polarPlot2);
        double double11 = polarPlot2.getMaxRadius();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot2);
        java.awt.Paint paint13 = polarPlot2.getAngleLabelPaint();
        org.jfree.chart.axis.ValueAxis valueAxis14 = polarPlot2.getAxis();
        org.jfree.data.xy.XYDataset xYDataset15 = polarPlot2.getDataset();
        boolean boolean16 = polarPlot2.isAngleLabelsVisible();
        java.lang.String str17 = polarPlot2.getPlotType();
        org.junit.Assert.assertNotNull(rotation1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(valueAxis14);
        org.junit.Assert.assertNull(xYDataset15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Polar Plot" + "'", str17.equals("Polar Plot"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        java.lang.Object obj3 = ringPlot0.clone();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        ringPlot0.handleClick(15, 15, plotRenderingInfo6);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = ringPlot0.getLegendLabelGenerator();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator9 = null;
        ringPlot0.setLegendLabelURLGenerator(pieURLGenerator9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = ringPlot0.getLabelPadding();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        double double3 = ringPlot0.getOuterSeparatorExtension();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        ringPlot4.setIgnoreNullValues(true);
        java.awt.Stroke stroke7 = ringPlot4.getSeparatorStroke();
        ringPlot0.setLabelLinkStroke(stroke7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = ringPlot0.getDrawingSupplier();
        java.lang.String str10 = ringPlot0.getPlotType();
        java.awt.Paint paint11 = ringPlot0.getSeparatorPaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(drawingSupplier9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Pie Plot" + "'", str10.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range3 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis2);
        dateAxis2.setAutoTickUnitSelection(true, false);
        java.util.Date date7 = dateAxis2.getMaximumDate();
        boolean boolean8 = dateAxis2.isTickMarksVisible();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis2.setAxisLineStroke(stroke9);
        float float11 = dateAxis2.getTickMarkOutsideLength();
        boolean boolean13 = dateAxis2.isHiddenValue((long) 15);
        double double14 = dateAxis2.getUpperMargin();
        dateAxis2.setNegativeArrowVisible(false);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 2.0f + "'", float11 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = null;
        waferMapPlot0.axisChanged(axisChangeEvent1);
        java.awt.Paint paint3 = waferMapPlot0.getBackgroundPaint();
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("JFreeChart", "");
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.addCornerTextItem("Pie Plot");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        polarPlot0.setAngleLabelPaint(paint3);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("Pie Plot", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }
}

