import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange((double) 100);
        double double3 = dateAxis0.getFixedAutoRange();
        java.util.TimeZone timeZone4 = null;
        try {
            dateAxis0.setTimeZone(timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range3 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis2);
        dateAxis2.setLabelURL("hi!");
        try {
            dateAxis2.zoomRange((double) (byte) 1, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator1 = null;
        ringPlot0.setURLGenerator(pieURLGenerator1);
        boolean boolean3 = ringPlot0.isOutlineVisible();
        ringPlot0.setMinimumArcAngleToDraw(0.0d);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator6 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator6);
        java.text.AttributedString attributedString9 = null;
        standardPieSectionLabelGenerator6.setAttributedLabel(0, attributedString9);
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        ringPlot11.setIgnoreNullValues(true);
        double double14 = ringPlot11.getInnerSeparatorExtension();
        ringPlot11.setOuterSeparatorExtension(0.0d);
        org.jfree.chart.util.Rotation rotation17 = ringPlot11.getDirection();
        java.lang.Object obj18 = ringPlot11.clone();
        float float19 = ringPlot11.getForegroundAlpha();
        boolean boolean20 = standardPieSectionLabelGenerator6.equals((java.lang.Object) ringPlot11);
        java.awt.Font font21 = ringPlot11.getNoDataMessageFont();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertNotNull(rotation17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(font21);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        double double3 = ringPlot0.getInnerSeparatorExtension();
        boolean boolean4 = ringPlot0.getSeparatorsVisible();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        ringPlot0.setDataset(pieDataset5);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        double double3 = ringPlot0.getInnerSeparatorExtension();
        ringPlot0.setOuterSeparatorExtension(0.0d);
        org.jfree.chart.util.Rotation rotation6 = ringPlot0.getDirection();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor8 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) -1);
        ringPlot0.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor8);
        java.awt.Paint paint10 = ringPlot0.getLabelOutlinePaint();
        double double11 = ringPlot0.getStartAngle();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(rotation6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis2 = polarPlot0.getAxis();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        polarPlot0.drawBackgroundImage(graphics2D3, rectangle2D4);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        polarPlot0.datasetChanged(datasetChangeEvent6);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(valueAxis2);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        double double3 = ringPlot0.getOuterSeparatorExtension();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = ringPlot0.getLegendLabelURLGenerator();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNull(pieURLGenerator4);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range3 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        org.jfree.chart.title.LegendTitle legendTitle5 = jFreeChart4.getLegend();
        java.awt.Paint paint6 = legendTitle5.getItemPaint();
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        ringPlot7.setIgnoreNullValues(true);
        double double10 = ringPlot7.getInnerSeparatorExtension();
        int int11 = ringPlot7.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = ringPlot7.getSimpleLabelOffset();
        legendTitle5.setPadding(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(legendTitle5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 100);
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat4 = numberAxis3.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = numberAxis3.getTickUnit();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis3.setMarkerBand(markerAxisBand6);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.centerRange((double) 100);
        java.lang.String str11 = dateAxis8.getLabelToolTip();
        java.awt.Shape shape12 = dateAxis8.getLeftArrow();
        numberAxis3.setLeftArrow(shape12);
        int int14 = objectList1.indexOf((java.lang.Object) numberAxis3);
        numberAxis3.setInverted(false);
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        java.lang.Object obj22 = categoryAxis3D20.clone();
        java.awt.Font font27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = polarPlot28.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis30 = polarPlot28.getAxis();
        polarPlot28.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart34 = new org.jfree.chart.JFreeChart("hi!", font27, (org.jfree.chart.plot.Plot) polarPlot28, true);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("hi!", font27);
        textTitle35.setPadding((double) (short) 10, (-1.0d), 0.2d, (double) '#');
        java.awt.geom.Rectangle2D rectangle2D41 = textTitle35.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity42 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D41);
        double[] doubleArray48 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray52 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray56 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray60 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray61 = new double[][] { doubleArray48, doubleArray52, doubleArray56, doubleArray60 };
        org.jfree.data.category.CategoryDataset categoryDataset62 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray61);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D63 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean64 = categoryAxis3D63.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot65 = categoryAxis3D63.getPlot();
        categoryAxis3D63.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot68 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = polarPlot68.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range71 = polarPlot68.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis70);
        dateAxis70.setAutoTickUnitSelection(true, false);
        java.util.Date date75 = dateAxis70.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer76 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot77 = new org.jfree.chart.plot.CategoryPlot(categoryDataset62, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D63, (org.jfree.chart.axis.ValueAxis) dateAxis70, categoryItemRenderer76);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D78 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean79 = categoryAxis3D78.isTickLabelsVisible();
        boolean boolean80 = categoryAxis3D78.isVisible();
        int int81 = categoryPlot77.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D78);
        org.jfree.chart.util.RectangleEdge rectangleEdge82 = categoryPlot77.getRangeAxisEdge();
        double double83 = categoryAxis3D20.getCategoryMiddle((int) (short) 10, (int) (short) -1, rectangle2D41, rectangleEdge82);
        org.jfree.chart.axis.NumberAxis numberAxis85 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat86 = numberAxis85.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit87 = numberAxis85.getTickUnit();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer88 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot89 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) numberAxis85, categoryItemRenderer88);
        numberAxis85.setTickMarksVisible(false);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNull(valueAxis30);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(categoryDataset62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNull(plot65);
        org.junit.Assert.assertNotNull(rectangleInsets69);
        org.junit.Assert.assertNull(range71);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + (-1) + "'", int81 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertNull(numberFormat86);
        org.junit.Assert.assertNotNull(numberTickUnit87);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo1);
//        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo1.addLibrary((org.jfree.chart.ui.Library) projectInfo3);
//        java.lang.String str5 = projectInfo3.getName();
//        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo10 = new org.jfree.chart.ui.BasicProjectInfo("TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", "hi!", "hi!");
//        projectInfo3.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo10);
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(projectInfo1);
//        org.junit.Assert.assertNotNull(projectInfo3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "http://www.jfree.org/jfreechart/index.html" + "'", str5.equals("http://www.jfree.org/jfreechart/index.html"));
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        java.awt.Font font40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot41 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = polarPlot41.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis43 = polarPlot41.getAxis();
        polarPlot41.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart47 = new org.jfree.chart.JFreeChart("hi!", font40, (org.jfree.chart.plot.Plot) polarPlot41, true);
        org.jfree.chart.title.Title title48 = null;
        jFreeChart47.removeSubtitle(title48);
        org.jfree.chart.event.ChartProgressListener chartProgressListener50 = null;
        jFreeChart47.removeProgressListener(chartProgressListener50);
        int int52 = jFreeChart47.getSubtitleCount();
        java.awt.Stroke stroke53 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        jFreeChart47.setBorderStroke(stroke53);
        categoryPlot34.setDomainGridlineStroke(stroke53);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D57 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Font font58 = categoryAxis3D57.getLabelFont();
        categoryPlot34.setDomainAxis(10, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D57, true);
        org.jfree.chart.plot.Marker marker62 = null;
        org.jfree.chart.util.Layer layer63 = null;
        try {
            boolean boolean64 = categoryPlot34.removeRangeMarker((int) '#', marker62, layer63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNull(valueAxis43);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(font58);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) '#');
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord2 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart8.removeProgressListener(chartProgressListener11);
        int int13 = jFreeChart8.getSubtitleCount();
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        jFreeChart8.setBorderStroke(stroke14);
        java.awt.Paint paint16 = jFreeChart8.getBackgroundPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        waferMapPlot0.setRenderer(waferMapRenderer1);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = null;
        waferMapPlot0.rendererChanged(rendererChangeEvent3);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        categoryAxis3D35.setTickMarkInsideLength((float) (-1));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis6 = polarPlot4.getAxis();
        polarPlot4.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("hi!", font3, (org.jfree.chart.plot.Plot) polarPlot4, true);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("hi!", font3);
        textTitle11.setPadding((double) (short) 10, (-1.0d), 0.2d, (double) '#');
        textTitle11.setMargin((double) '4', 0.0d, (double) (short) 1, 0.0d);
        java.awt.Font font22 = textTitle11.getFont();
        java.awt.Paint paint23 = null;
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer27 = new org.jfree.chart.text.G2TextMeasurer(graphics2D26);
        boolean boolean28 = blockBorder25.equals((java.lang.Object) g2TextMeasurer27);
        try {
            org.jfree.chart.text.TextBlock textBlock29 = org.jfree.chart.text.TextUtilities.createTextBlock("JFreeChart", font22, paint23, (float) 0, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range3 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis2);
        dateAxis2.setLabelURL("hi!");
        dateAxis2.configure();
        dateAxis2.setAutoTickUnitSelection(true);
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        double double10 = ringPlot9.getMaximumExplodePercent();
        ringPlot9.setBackgroundAlpha((float) (-1));
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot9);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        ringPlot9.setLabelFont(font14);
        java.lang.String str16 = ringPlot9.getPlotType();
        boolean boolean17 = dateAxis2.equals((java.lang.Object) ringPlot9);
        dateAxis2.configure();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Pie Plot" + "'", str16.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        double double3 = ringPlot0.getOuterSeparatorExtension();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = ringPlot0.getInsets();
        java.awt.Paint[] paintArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = polarPlot9.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis11 = polarPlot9.getAxis();
        polarPlot9.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("hi!", font8, (org.jfree.chart.plot.Plot) polarPlot9, true);
        org.jfree.chart.title.Title title16 = null;
        jFreeChart15.removeSubtitle(title16);
        org.jfree.chart.event.ChartProgressListener chartProgressListener18 = null;
        jFreeChart15.removeProgressListener(chartProgressListener18);
        int int20 = jFreeChart15.getSubtitleCount();
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        jFreeChart15.setBorderStroke(stroke21);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.RingPlot ringPlot26 = new org.jfree.chart.plot.RingPlot();
        ringPlot26.setIgnoreNullValues(true);
        java.awt.Stroke stroke29 = ringPlot26.getSeparatorStroke();
        java.awt.Stroke[] strokeArray30 = new java.awt.Stroke[] { stroke21, stroke23, stroke24, stroke25, stroke29 };
        java.awt.Stroke stroke31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D34 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean35 = categoryAxis3D34.isTickLabelsVisible();
        java.awt.Stroke stroke36 = categoryAxis3D34.getTickMarkStroke();
        java.awt.Stroke[] strokeArray37 = new java.awt.Stroke[] { stroke31, stroke32, stroke33, stroke36 };
        org.jfree.chart.plot.RingPlot ringPlot38 = new org.jfree.chart.plot.RingPlot();
        double double39 = ringPlot38.getMaximumExplodePercent();
        java.awt.Shape shape40 = ringPlot38.getLegendItemShape();
        java.awt.Shape shape41 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray42 = new java.awt.Shape[] { shape40, shape41 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier43 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray5, paintArray6, strokeArray30, strokeArray37, shapeArray42);
        java.awt.Stroke stroke44 = defaultDrawingSupplier43.getNextStroke();
        java.awt.Paint paint45 = defaultDrawingSupplier43.getNextPaint();
        java.lang.Object obj46 = defaultDrawingSupplier43.clone();
        java.awt.Paint paint47 = defaultDrawingSupplier43.getNextOutlinePaint();
        ringPlot0.setLabelShadowPaint(paint47);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(strokeArray30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(strokeArray37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(shapeArray42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertNotNull(paint47);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundAlpha((float) (-1));
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        int int4 = polarPlot0.getSeriesCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        polarPlot0.zoomDomainAxes(0.2d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.ValueAxis valueAxis10 = polarPlot0.getAxis();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(valueAxis10);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = polarPlot3.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis5 = polarPlot3.getAxis();
        polarPlot3.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", font2, (org.jfree.chart.plot.Plot) polarPlot3, true);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font2);
        textTitle10.setPadding((double) (short) 10, (-1.0d), 0.2d, (double) '#');
        textTitle10.setMargin((double) '4', 0.0d, (double) (short) 1, 0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.util.RectangleEdge.LEFT;
        textTitle10.setPosition(rectangleEdge21);
        java.lang.Object obj23 = textTitle10.clone();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        ringPlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator3);
        java.lang.Comparable comparable5 = null;
        try {
            double double6 = ringPlot0.getExplodePercent(comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        int int35 = categoryPlot34.getRangeAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis36 = categoryPlot34.getRangeAxis();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(valueAxis36);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        numberAxis10.setUpperMargin(0.025d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = polarPlot3.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis5 = polarPlot3.getAxis();
        polarPlot3.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", font2, (org.jfree.chart.plot.Plot) polarPlot3, true);
        org.jfree.chart.title.Title title10 = null;
        jFreeChart9.removeSubtitle(title10);
        org.jfree.chart.event.ChartProgressListener chartProgressListener12 = null;
        jFreeChart9.removeProgressListener(chartProgressListener12);
        int int14 = jFreeChart9.getSubtitleCount();
        jFreeChart9.clearSubtitles();
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_RED;
        jFreeChart9.setBorderPaint((java.awt.Paint) color16);
        java.util.List list18 = jFreeChart9.getSubtitles();
        boolean boolean19 = standardPieSectionLabelGenerator0.equals((java.lang.Object) jFreeChart9);
        java.text.AttributedString attributedString21 = null;
        try {
            standardPieSectionLabelGenerator0.setAttributedLabel((-1), attributedString21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart8.removeProgressListener(chartProgressListener11);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart8.getLegend((int) (byte) 100);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart8.getLegend();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle15.setLegendItemGraphicLocation(rectangleAnchor16);
        org.jfree.chart.block.BlockContainer blockContainer18 = legendTitle15.getItemContainer();
        legendTitle15.setNotify(false);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray21 = legendTitle15.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = legendTitle15.getItemLabelPadding();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertNotNull(legendTitle15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(blockContainer18);
        org.junit.Assert.assertNotNull(legendItemSourceArray21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        java.awt.Stroke stroke3 = ringPlot0.getSeparatorStroke();
        double double4 = ringPlot0.getMinimumArcAngleToDraw();
        double double5 = ringPlot0.getSectionDepth();
        ringPlot0.setCircular(false);
        boolean boolean8 = ringPlot0.isCircular();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-5d + "'", double4 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart8.removeProgressListener(chartProgressListener11);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart8.getLegend((int) (byte) 100);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart8.getLegend();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray16 = legendTitle15.getSources();
        double[] doubleArray22 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray26 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray30 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray34 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray35 = new double[][] { doubleArray22, doubleArray26, doubleArray30, doubleArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray35);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D37 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean38 = categoryAxis3D37.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot39 = categoryAxis3D37.getPlot();
        categoryAxis3D37.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot42 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = polarPlot42.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range45 = polarPlot42.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis44);
        dateAxis44.setAutoTickUnitSelection(true, false);
        java.util.Date date49 = dateAxis44.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D37, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer50);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D52 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean53 = categoryAxis3D52.isTickLabelsVisible();
        boolean boolean54 = categoryAxis3D52.isVisible();
        int int55 = categoryPlot51.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D52);
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = categoryPlot51.getRangeAxisEdge();
        legendTitle15.setLegendItemGraphicEdge(rectangleEdge56);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment58 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        legendTitle15.setHorizontalAlignment(horizontalAlignment58);
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = legendTitle15.getLegendItemGraphicEdge();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertNotNull(legendTitle15);
        org.junit.Assert.assertNotNull(legendItemSourceArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNull(plot39);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNull(range45);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertNotNull(horizontalAlignment58);
        org.junit.Assert.assertNotNull(rectangleEdge60);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        double double3 = ringPlot0.getInnerSeparatorExtension();
        ringPlot0.setOuterSeparatorExtension(0.0d);
        org.jfree.chart.util.Rotation rotation6 = ringPlot0.getDirection();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = polarPlot8.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis10 = polarPlot8.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = polarPlot11.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range14 = polarPlot11.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis13);
        polarPlot8.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat18 = numberAxis17.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit19 = numberAxis17.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis17, xYItemRenderer20);
        xYPlot21.clearRangeMarkers();
        boolean boolean23 = rotation6.equals((java.lang.Object) xYPlot21);
        java.awt.Stroke stroke24 = xYPlot21.getDomainCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot21.setDataset(1, xYDataset26);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot21.getRangeAxisEdge((-1));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(rotation6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(numberFormat18);
        org.junit.Assert.assertNotNull(numberTickUnit19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range3 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Font font4 = polarPlot0.getAngleLabelFont();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        java.awt.Font font40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot41 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = polarPlot41.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis43 = polarPlot41.getAxis();
        polarPlot41.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart47 = new org.jfree.chart.JFreeChart("hi!", font40, (org.jfree.chart.plot.Plot) polarPlot41, true);
        org.jfree.chart.title.Title title48 = null;
        jFreeChart47.removeSubtitle(title48);
        org.jfree.chart.event.ChartProgressListener chartProgressListener50 = null;
        jFreeChart47.removeProgressListener(chartProgressListener50);
        int int52 = jFreeChart47.getSubtitleCount();
        java.awt.Stroke stroke53 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        jFreeChart47.setBorderStroke(stroke53);
        categoryPlot34.setDomainGridlineStroke(stroke53);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D57 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Font font58 = categoryAxis3D57.getLabelFont();
        categoryPlot34.setDomainAxis(10, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D57, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = categoryPlot34.getDomainAxisEdge((int) (short) 0);
        org.jfree.data.xy.XYDataset xYDataset63 = null;
        org.jfree.chart.plot.PolarPlot polarPlot64 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = polarPlot64.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis66 = polarPlot64.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot67 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = polarPlot67.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis69 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range70 = polarPlot67.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis69);
        polarPlot64.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis69);
        org.jfree.chart.axis.NumberAxis numberAxis73 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat74 = numberAxis73.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit75 = numberAxis73.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer76 = null;
        org.jfree.chart.plot.XYPlot xYPlot77 = new org.jfree.chart.plot.XYPlot(xYDataset63, (org.jfree.chart.axis.ValueAxis) dateAxis69, (org.jfree.chart.axis.ValueAxis) numberAxis73, xYItemRenderer76);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer78 = xYPlot77.getRenderer();
        xYPlot77.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer81 = null;
        java.util.Collection collection82 = xYPlot77.getDomainMarkers(layer81);
        org.jfree.chart.plot.ValueMarker valueMarker84 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot77.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker84);
        org.jfree.chart.util.Layer layer86 = null;
        try {
            boolean boolean87 = categoryPlot34.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker84, layer86);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNull(valueAxis43);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertNotNull(rectangleInsets65);
        org.junit.Assert.assertNull(valueAxis66);
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertNull(range70);
        org.junit.Assert.assertNull(numberFormat74);
        org.junit.Assert.assertNotNull(numberTickUnit75);
        org.junit.Assert.assertNull(xYItemRenderer78);
        org.junit.Assert.assertNull(collection82);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = textTitle0.getPosition();
        org.junit.Assert.assertNotNull(rectangleEdge1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.Color color4 = java.awt.Color.BLUE;
        float[] floatArray11 = new float[] { 10.0f, 100L, 1, (-1.0f), (byte) 100, 100 };
        float[] floatArray12 = color4.getColorComponents(floatArray11);
        float[] floatArray13 = java.awt.Color.RGBtoHSB((int) (short) 1, (int) (short) 0, (int) ' ', floatArray11);
        float[] floatArray14 = color0.getColorComponents(floatArray11);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.lang.Class<?> wildcardClass3 = color2.getClass();
        java.lang.ClassLoader classLoader4 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass3);
        java.net.URL uRL5 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("TextAnchor.BOTTOM_LEFT", (java.lang.Class) wildcardClass3);
        java.io.InputStream inputStream6 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Pie Plot", (java.lang.Class) wildcardClass3);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(classLoader4);
        org.junit.Assert.assertNull(uRL5);
        org.junit.Assert.assertNull(inputStream6);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundAlpha((float) (-1));
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        java.awt.Paint paint4 = jFreeChart3.getBackgroundPaint();
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(paint4);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (java.lang.Comparable) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers(layer18);
        boolean boolean20 = xYPlot14.isRangeZoomable();
        boolean boolean21 = xYPlot14.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D23 = new org.jfree.chart.axis.CategoryAxis3D("TextAnchor.BOTTOM_LEFT");
        boolean boolean24 = xYPlot14.equals((java.lang.Object) "TextAnchor.BOTTOM_LEFT");
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = polarPlot26.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis28 = polarPlot26.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = polarPlot29.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range32 = polarPlot29.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis31);
        polarPlot26.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis31);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat36 = numberAxis35.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit37 = numberAxis35.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) dateAxis31, (org.jfree.chart.axis.ValueAxis) numberAxis35, xYItemRenderer38);
        org.jfree.chart.util.Layer layer41 = null;
        java.util.Collection collection42 = xYPlot39.getDomainMarkers(1, layer41);
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot39.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker44);
        try {
            boolean boolean46 = xYPlot14.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertNull(numberFormat36);
        org.junit.Assert.assertNotNull(numberTickUnit37);
        org.junit.Assert.assertNull(collection42);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        float float9 = polarPlot2.getForegroundAlpha();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = null;
        xYPlot14.datasetChanged(datasetChangeEvent18);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = xYPlot14.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace21 = null;
        xYPlot14.setFixedDomainAxisSpace(axisSpace21, true);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        numberAxis1.setRangeAboutValue(0.0d, 0.0d);
        boolean boolean6 = numberAxis1.isTickLabelsVisible();
        numberAxis1.setAutoRangeStickyZero(true);
        org.jfree.data.Range range9 = numberAxis1.getDefaultAutoRange();
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(range9);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        ringPlot0.setBackgroundAlpha((float) (-1));
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        ringPlot0.setLabelFont(font5);
        java.awt.Paint paint7 = ringPlot0.getBaseSectionPaint();
        ringPlot0.setSeparatorsVisible(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        int int35 = categoryPlot34.getRangeAxisCount();
        categoryPlot34.clearDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = categoryPlot34.getRenderer((int) (short) 100);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D39 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D39.setCategoryMargin((double) (short) -1);
        int int42 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D39);
        org.jfree.chart.util.SortOrder sortOrder43 = categoryPlot34.getColumnRenderingOrder();
        java.util.List list44 = categoryPlot34.getAnnotations();
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        float float47 = valueMarker46.getAlpha();
        org.jfree.chart.plot.RingPlot ringPlot48 = new org.jfree.chart.plot.RingPlot();
        ringPlot48.setIgnoreNullValues(true);
        java.awt.Stroke stroke51 = ringPlot48.getSeparatorStroke();
        double double52 = ringPlot48.getMinimumArcAngleToDraw();
        double double53 = ringPlot48.getSectionDepth();
        ringPlot48.setForegroundAlpha(0.5f);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier56 = ringPlot48.getDrawingSupplier();
        valueMarker46.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) ringPlot48);
        try {
            boolean boolean58 = categoryPlot34.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNull(categoryItemRenderer38);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(sortOrder43);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.8f + "'", float47 == 0.8f);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0E-5d + "'", double52 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.2d + "'", double53 == 0.2d);
        org.junit.Assert.assertNotNull(drawingSupplier56);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        double double3 = ringPlot0.getOuterSeparatorExtension();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        ringPlot4.setIgnoreNullValues(true);
        java.awt.Stroke stroke7 = ringPlot4.getSeparatorStroke();
        ringPlot0.setLabelLinkStroke(stroke7);
        float float9 = ringPlot0.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.5f + "'", float9 == 0.5f);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isRangeGridlinesVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        int int17 = xYPlot14.getIndexOf(xYItemRenderer16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = xYPlot14.getRenderer((int) (byte) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot14.zoomDomainAxes((double) 10, (double) (byte) 10, plotRenderingInfo22, point2D23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.RingPlot ringPlot26 = new org.jfree.chart.plot.RingPlot();
        ringPlot26.setIgnoreNullValues(true);
        java.awt.Stroke stroke29 = ringPlot26.getSeparatorStroke();
        double double30 = ringPlot26.getMinimumArcAngleToDraw();
        double double31 = ringPlot26.getSectionDepth();
        ringPlot26.setForegroundAlpha(0.5f);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis();
        double double36 = categoryAxis35.getUpperMargin();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D39 = new org.jfree.chart.axis.CategoryAxis3D();
        double double40 = categoryAxis3D39.getCategoryMargin();
        java.awt.Font font45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot46 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = polarPlot46.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis48 = polarPlot46.getAxis();
        polarPlot46.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart52 = new org.jfree.chart.JFreeChart("hi!", font45, (org.jfree.chart.plot.Plot) polarPlot46, true);
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("hi!", font45);
        java.awt.geom.Rectangle2D rectangle2D54 = textTitle53.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double56 = categoryAxis3D39.getCategoryStart((int) (short) 10, (int) '4', rectangle2D54, rectangleEdge55);
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double58 = categoryAxis35.getCategoryEnd(15, (int) '4', rectangle2D54, rectangleEdge57);
        ringPlot26.drawBackgroundImage(graphics2D34, rectangle2D54);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = null;
        xYPlot14.drawAnnotations(graphics2D25, rectangle2D54, plotRenderingInfo60);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        try {
            xYPlot14.handleClick((int) (short) 10, 0, plotRenderingInfo64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(xYItemRenderer19);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0E-5d + "'", double30 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.2d + "'", double31 == 0.2d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.2d + "'", double40 == 0.2d);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNull(valueAxis48);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        java.lang.Object obj3 = ringPlot0.clone();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        ringPlot0.handleClick(15, 15, plotRenderingInfo6);
        ringPlot0.setForegroundAlpha(0.0f);
        double double10 = ringPlot0.getLabelGap();
        java.awt.Paint paint11 = ringPlot0.getSeparatorPaint();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = polarPlot14.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis16 = polarPlot14.getAxis();
        polarPlot14.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("hi!", font13, (org.jfree.chart.plot.Plot) polarPlot14, true);
        org.jfree.chart.title.Title title21 = null;
        jFreeChart20.removeSubtitle(title21);
        org.jfree.chart.event.ChartProgressListener chartProgressListener23 = null;
        jFreeChart20.removeProgressListener(chartProgressListener23);
        int int25 = jFreeChart20.getSubtitleCount();
        jFreeChart20.clearSubtitles();
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_RED;
        jFreeChart20.setBorderPaint((java.awt.Paint) color27);
        java.util.List list29 = jFreeChart20.getSubtitles();
        java.awt.image.BufferedImage bufferedImage32 = jFreeChart20.createBufferedImage(1, 10);
        java.awt.RenderingHints renderingHints33 = jFreeChart20.getRenderingHints();
        org.jfree.chart.event.ChartProgressListener chartProgressListener34 = null;
        jFreeChart20.addProgressListener(chartProgressListener34);
        boolean boolean36 = ringPlot0.equals((java.lang.Object) jFreeChart20);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.025d + "'", double10 == 0.025d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(bufferedImage32);
        org.junit.Assert.assertNotNull(renderingHints33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        double double3 = ringPlot0.getInnerSeparatorExtension();
        int int4 = ringPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = ringPlot0.getSimpleLabelOffset();
        double double7 = rectangleInsets5.extendHeight((double) (byte) 10);
        double double9 = rectangleInsets5.calculateBottomInset((double) 1L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 15.625d + "'", double7 == 15.625d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.18d + "'", double9 == 0.18d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str1 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.ABSOLUTE" + "'", str1.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        double double3 = ringPlot0.getInnerSeparatorExtension();
        ringPlot0.setOuterSeparatorExtension(0.0d);
        org.jfree.chart.util.Rotation rotation6 = ringPlot0.getDirection();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = polarPlot8.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis10 = polarPlot8.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = polarPlot11.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range14 = polarPlot11.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis13);
        polarPlot8.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat18 = numberAxis17.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit19 = numberAxis17.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis17, xYItemRenderer20);
        xYPlot21.clearRangeMarkers();
        boolean boolean23 = rotation6.equals((java.lang.Object) xYPlot21);
        xYPlot21.clearRangeMarkers();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(rotation6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(numberFormat18);
        org.junit.Assert.assertNotNull(numberTickUnit19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator1 = null;
        ringPlot0.setURLGenerator(pieURLGenerator1);
        boolean boolean3 = ringPlot0.isOutlineVisible();
        ringPlot0.setMinimumArcAngleToDraw(0.0d);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator6 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator6);
        java.text.AttributedString attributedString9 = null;
        standardPieSectionLabelGenerator6.setAttributedLabel(0, attributedString9);
        java.lang.Object obj11 = standardPieSectionLabelGenerator6.clone();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.BASELINE_CENTER" + "'", str1.equals("TextAnchor.BASELINE_CENTER"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = polarPlot3.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis5 = polarPlot3.getAxis();
        polarPlot3.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", font2, (org.jfree.chart.plot.Plot) polarPlot3, true);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = textTitle10.getTextAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle10.setHorizontalAlignment(horizontalAlignment12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = textTitle10.getMargin();
        textTitle10.setHeight(10.0d);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = polarPlot5.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range8 = polarPlot5.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis7);
        polarPlot2.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat12 = numberAxis11.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = numberAxis11.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis11, xYItemRenderer14);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot15.getDomainMarkers(1, layer17);
        java.awt.Paint paint19 = xYPlot15.getDomainCrosshairPaint();
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("TextAnchor.BOTTOM_LEFT", (org.jfree.chart.plot.Plot) xYPlot15);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.RingPlot ringPlot25 = new org.jfree.chart.plot.RingPlot();
        double double26 = ringPlot25.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = ringPlot25.getLabelPadding();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator28 = null;
        ringPlot25.setLegendLabelToolTipGenerator(pieSectionLabelGenerator28);
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.Font font33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot34 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = polarPlot34.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis36 = polarPlot34.getAxis();
        polarPlot34.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart40 = new org.jfree.chart.JFreeChart("hi!", font33, (org.jfree.chart.plot.Plot) polarPlot34, true);
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle("hi!", font33);
        textTitle41.setPadding((double) (short) 10, (-1.0d), 0.2d, (double) '#');
        java.awt.geom.Rectangle2D rectangle2D47 = textTitle41.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double49 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D47, rectangleEdge48);
        ringPlot25.drawBackgroundImage(graphics2D30, rectangle2D47);
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = org.jfree.chart.util.RectangleEdge.TOP;
        double double52 = categoryAxis22.getCategoryStart(0, 0, rectangle2D47, rectangleEdge51);
        try {
            jFreeChart20.draw(graphics2D21, rectangle2D47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(numberFormat12);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNull(valueAxis36);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean1 = categoryAxis3D0.isTickLabelsVisible();
        java.lang.Object obj2 = categoryAxis3D0.clone();
        java.awt.Font font4 = categoryAxis3D0.getTickLabelFont((java.lang.Comparable) 1.0d);
        categoryAxis3D0.setUpperMargin(0.05d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        float[] floatArray13 = new float[] { (byte) 10, 1, (-1.0f), 1L, 10, 10.0f };
        float[] floatArray14 = color0.getComponents(floatArray13);
        java.awt.color.ColorSpace colorSpace15 = null;
        float[] floatArray18 = new float[] { 2.0f, 2.0f };
        try {
            float[] floatArray19 = color0.getComponents(colorSpace15, floatArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray18);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        ringPlot3.setIgnoreNullValues(true);
        double double6 = ringPlot3.getInnerSeparatorExtension();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat9 = numberAxis8.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = numberAxis8.getTickUnit();
        ringPlot3.setExplodePercent((java.lang.Comparable) numberTickUnit10, (double) 2);
        numberAxis2.setTickUnit(numberTickUnit10, false, false);
        numberAxis2.setTickMarkInsideLength((float) (byte) 100);
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        numberAxis2.setLabelFont(font18);
        java.awt.Color color23 = java.awt.Color.getHSBColor(1.0f, (float) 10L, (float) '4');
        org.jfree.chart.text.TextBlock textBlock24 = org.jfree.chart.text.TextUtilities.createTextBlock("", font18, (java.awt.Paint) color23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor28 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        textBlock24.draw(graphics2D25, (float) '4', 0.0f, textBlockAnchor28, 0.0f, 0.0f, 0.08d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNull(numberFormat9);
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(textBlock24);
        org.junit.Assert.assertNotNull(textBlockAnchor28);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range3 = org.jfree.data.Range.shift(range0, (double) 10, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint(range0, 0.2d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = rectangleConstraint5.getWidthConstraintType();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange((double) 100);
        double double3 = dateAxis0.getFixedAutoRange();
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis0.setUpArrow(shape4);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.awt.Shape shape7 = chartEntity6.getArea();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = polarPlot9.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis11 = polarPlot9.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = polarPlot12.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range15 = polarPlot12.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis14);
        polarPlot9.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat19 = numberAxis18.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit20 = numberAxis18.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis18, xYItemRenderer21);
        boolean boolean23 = xYPlot22.isRangeGridlinesVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        int int25 = xYPlot22.getIndexOf(xYItemRenderer24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = xYPlot22.getRenderer((int) (byte) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        xYPlot22.zoomDomainAxes((double) 10, (double) (byte) 10, plotRenderingInfo30, point2D31);
        org.jfree.data.xy.XYDataset xYDataset33 = xYPlot22.getDataset();
        java.awt.Stroke stroke34 = xYPlot22.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        double double37 = categoryAxis3D36.getCategoryMargin();
        java.awt.Font font42 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot43 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = polarPlot43.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis45 = polarPlot43.getAxis();
        polarPlot43.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart49 = new org.jfree.chart.JFreeChart("hi!", font42, (org.jfree.chart.plot.Plot) polarPlot43, true);
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle("hi!", font42);
        java.awt.geom.Rectangle2D rectangle2D51 = textTitle50.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double53 = categoryAxis3D36.getCategoryStart((int) (short) 10, (int) '4', rectangle2D51, rectangleEdge52);
        xYPlot22.drawBackgroundImage(graphics2D35, rectangle2D51);
        org.jfree.chart.entity.ChartEntity chartEntity57 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D51, "", "Category Plot");
        chartEntity6.setArea((java.awt.Shape) rectangle2D51);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNull(numberFormat19);
        org.junit.Assert.assertNotNull(numberTickUnit20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNull(xYItemRenderer27);
        org.junit.Assert.assertNull(xYDataset33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.2d + "'", double37 == 0.2d);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNull(valueAxis45);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Font font2 = ringPlot1.getNoDataMessageFont();
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis6 = polarPlot4.getAxis();
        polarPlot4.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("hi!", font3, (org.jfree.chart.plot.Plot) polarPlot4, true);
        org.jfree.chart.title.Title title11 = null;
        jFreeChart10.removeSubtitle(title11);
        org.jfree.chart.event.ChartProgressListener chartProgressListener13 = null;
        jFreeChart10.removeProgressListener(chartProgressListener13);
        int int15 = jFreeChart10.getSubtitleCount();
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        jFreeChart10.setBorderStroke(stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        ringPlot21.setIgnoreNullValues(true);
        java.awt.Stroke stroke24 = ringPlot21.getSeparatorStroke();
        java.awt.Stroke[] strokeArray25 = new java.awt.Stroke[] { stroke16, stroke18, stroke19, stroke20, stroke24 };
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D29 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean30 = categoryAxis3D29.isTickLabelsVisible();
        java.awt.Stroke stroke31 = categoryAxis3D29.getTickMarkStroke();
        java.awt.Stroke[] strokeArray32 = new java.awt.Stroke[] { stroke26, stroke27, stroke28, stroke31 };
        org.jfree.chart.plot.RingPlot ringPlot33 = new org.jfree.chart.plot.RingPlot();
        double double34 = ringPlot33.getMaximumExplodePercent();
        java.awt.Shape shape35 = ringPlot33.getLegendItemShape();
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] { shape35, shape36 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray25, strokeArray32, shapeArray37);
        java.awt.Stroke stroke39 = defaultDrawingSupplier38.getNextStroke();
        java.awt.Paint paint40 = defaultDrawingSupplier38.getNextPaint();
        java.lang.Object obj41 = defaultDrawingSupplier38.clone();
        java.awt.Paint paint42 = defaultDrawingSupplier38.getNextOutlinePaint();
        java.awt.Shape shape43 = defaultDrawingSupplier38.getNextShape();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(strokeArray25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(strokeArray32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(shape43);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.util.Rotation rotation1 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = polarPlot5.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range8 = polarPlot5.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis7);
        polarPlot2.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis7);
        boolean boolean10 = rotation1.equals((java.lang.Object) polarPlot2);
        double double11 = polarPlot2.getMaxRadius();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot2);
        java.awt.Paint paint13 = polarPlot2.getAngleLabelPaint();
        org.jfree.chart.axis.ValueAxis valueAxis14 = polarPlot2.getAxis();
        org.jfree.data.xy.XYDataset xYDataset15 = polarPlot2.getDataset();
        boolean boolean16 = polarPlot2.isAngleLabelsVisible();
        org.jfree.chart.axis.TickUnit tickUnit17 = polarPlot2.getAngleTickUnit();
        org.junit.Assert.assertNotNull(rotation1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(valueAxis14);
        org.junit.Assert.assertNull(xYDataset15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(tickUnit17);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("UnitType.ABSOLUTE", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=1.0]", "hi!", "TextAnchor.BOTTOM_LEFT");
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        ringPlot0.setPieIndex(1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot14.getDomainMarkers(1, layer16);
        java.awt.Paint paint18 = xYPlot14.getDomainCrosshairPaint();
        boolean boolean19 = xYPlot14.isRangeCrosshairVisible();
        java.awt.Paint paint20 = xYPlot14.getRangeGridlinePaint();
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot14.getDomainMarkers(layer21);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(collection22);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean1 = categoryAxis3D0.isTickLabelsVisible();
        java.lang.Object obj2 = categoryAxis3D0.clone();
        categoryAxis3D0.addCategoryLabelToolTip((java.lang.Comparable) "{0}", "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers(layer18);
        org.jfree.chart.axis.ValueAxis valueAxis21 = xYPlot14.getDomainAxis(0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNotNull(valueAxis21);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        ringPlot0.setShadowYOffset((double) 100.0f);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = ringPlot0.getURLGenerator();
        double double6 = ringPlot0.getOuterSeparatorExtension();
        java.awt.Font font7 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        ringPlot0.setLabelFont(font7);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (double) 3, (double) (-1), 0.0d);
        java.lang.String str6 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UnitType.ABSOLUTE" + "'", str6.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        ringPlot0.setBackgroundAlpha((float) (-1));
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        ringPlot0.setLabelFont(font5);
        java.awt.Paint paint7 = ringPlot0.getBaseSectionPaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = null;
        ringPlot0.setURLGenerator(pieURLGenerator8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        float float2 = valueMarker1.getAlpha();
        java.lang.Object obj3 = valueMarker1.clone();
        java.lang.String str4 = valueMarker1.getLabel();
        java.awt.Font font5 = valueMarker1.getLabelFont();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.8f + "'", float2 == 0.8f);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers(layer18);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot14.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker21);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        xYPlot14.setDataset(xYDataset23);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(collection19);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = null;
        xYPlot14.datasetChanged(datasetChangeEvent18);
        xYPlot14.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = xYPlot14.getRangeMarkers((int) (short) 1, layer23);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(collection24);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart8.removeProgressListener(chartProgressListener11);
        int int13 = jFreeChart8.getSubtitleCount();
        jFreeChart8.clearSubtitles();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        jFreeChart8.setBorderPaint((java.awt.Paint) color15);
        boolean boolean17 = jFreeChart8.getAntiAlias();
        java.lang.Object obj18 = jFreeChart8.getTextAntiAlias();
        jFreeChart8.setBackgroundImageAlignment(100);
        jFreeChart8.setNotify(false);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        dateAxis23.centerRange((double) 100);
        java.lang.String str26 = dateAxis23.getLabelToolTip();
        java.awt.Shape shape27 = dateAxis23.getLeftArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = dateAxis23.getLabelInsets();
        boolean boolean30 = rectangleInsets28.equals((java.lang.Object) 0.2d);
        jFreeChart8.setPadding(rectangleInsets28);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        java.lang.Object obj3 = ringPlot0.clone();
        boolean boolean4 = ringPlot0.getSimpleLabels();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(10);
        java.lang.Object obj2 = objectList1.clone();
        java.lang.Object obj4 = objectList1.get(0);
        double[] doubleArray11 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray15 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray19 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray23 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray24 = new double[][] { doubleArray11, doubleArray15, doubleArray19, doubleArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray24);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D26 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean27 = categoryAxis3D26.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot28 = categoryAxis3D26.getPlot();
        categoryAxis3D26.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot31 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = polarPlot31.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range34 = polarPlot31.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis33);
        dateAxis33.setAutoTickUnitSelection(true, false);
        java.util.Date date38 = dateAxis33.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D26, (org.jfree.chart.axis.ValueAxis) dateAxis33, categoryItemRenderer39);
        org.jfree.chart.axis.AxisSpace axisSpace41 = null;
        categoryPlot40.setFixedDomainAxisSpace(axisSpace41);
        categoryPlot40.setWeight((int) '4');
        categoryPlot40.clearAnnotations();
        java.awt.Stroke stroke46 = categoryPlot40.getRangeCrosshairStroke();
        objectList1.set((int) (byte) 0, (java.lang.Object) stroke46);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNull(plot28);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(stroke46);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers(layer18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = null;
        xYPlot14.setDomainAxisLocation(15, axisLocation21, false);
        xYPlot14.setDomainCrosshairVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace26 = xYPlot14.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        xYPlot14.setFixedRangeAxisSpace(axisSpace27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        xYPlot14.zoomRangeAxes((-7.0d), 0.0d, plotRenderingInfo31, point2D32);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNull(axisSpace26);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        org.jfree.chart.LegendItemCollection legendItemCollection39 = categoryPlot34.getFixedLegendItems();
        boolean boolean40 = categoryPlot34.getDrawSharedDomainAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection41 = categoryPlot34.getLegendItems();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNull(legendItemCollection39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(legendItemCollection41);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparable0, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        ringPlot3.setIgnoreNullValues(true);
        java.awt.Stroke stroke6 = ringPlot3.getSeparatorStroke();
        double double7 = ringPlot3.getMinimumArcAngleToDraw();
        ringPlot3.setLabelLinksVisible(true);
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = polarPlot12.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis14 = polarPlot12.getAxis();
        polarPlot12.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("hi!", font11, (org.jfree.chart.plot.Plot) polarPlot12, true);
        org.jfree.chart.title.Title title19 = null;
        jFreeChart18.removeSubtitle(title19);
        org.jfree.chart.event.ChartProgressListener chartProgressListener21 = null;
        jFreeChart18.removeProgressListener(chartProgressListener21);
        int int23 = jFreeChart18.getSubtitleCount();
        jFreeChart18.clearSubtitles();
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_RED;
        jFreeChart18.setBorderPaint((java.awt.Paint) color25);
        ringPlot3.setSeparatorPaint((java.awt.Paint) color25);
        java.awt.Color color31 = java.awt.Color.BLUE;
        float[] floatArray38 = new float[] { 10.0f, 100L, 1, (-1.0f), (byte) 100, 100 };
        float[] floatArray39 = color31.getColorComponents(floatArray38);
        float[] floatArray40 = java.awt.Color.RGBtoHSB((int) (short) 1, (int) (short) 0, (int) ' ', floatArray38);
        float[] floatArray41 = color25.getColorComponents(floatArray40);
        float[] floatArray42 = color2.getColorComponents(floatArray40);
        try {
            float[] floatArray43 = color0.getComponents(colorSpace1, floatArray42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0E-5d + "'", double7 == 1.0E-5d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setPieCenterX((double) 0);
        piePlotState1.setPieWRadius((double) 10.0f);
        double double6 = piePlotState1.getLatestAngle();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        org.jfree.chart.LegendItemCollection legendItemCollection39 = categoryPlot34.getFixedLegendItems();
        categoryPlot34.setAnchorValue((double) 0L);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNull(legendItemCollection39);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 3, (double) 100L, (double) 4, (double) 4);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis2 = polarPlot0.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = polarPlot3.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range6 = polarPlot3.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis5);
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        dateAxis5.setAxisLineStroke(stroke8);
        java.text.DateFormat dateFormat10 = dateAxis5.getDateFormatOverride();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(dateFormat10);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        categoryPlot34.setFixedDomainAxisSpace(axisSpace35);
        categoryPlot34.setWeight((int) '4');
        categoryPlot34.clearAnnotations();
        java.awt.Stroke stroke40 = categoryPlot34.getRangeCrosshairStroke();
        org.jfree.chart.util.SortOrder sortOrder41 = categoryPlot34.getRowRenderingOrder();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(sortOrder41);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        double double3 = ringPlot0.getInnerSeparatorExtension();
        ringPlot0.setOuterSeparatorExtension(0.0d);
        org.jfree.chart.util.Rotation rotation6 = ringPlot0.getDirection();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor8 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) -1);
        ringPlot0.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor8);
        java.awt.Paint paint10 = ringPlot0.getLabelOutlinePaint();
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        double double12 = ringPlot11.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = ringPlot11.getLabelPadding();
        double double14 = rectangleInsets13.getRight();
        double double16 = rectangleInsets13.calculateRightInset((double) 3);
        ringPlot0.setLabelPadding(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(rotation6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        categoryPlot34.setFixedDomainAxisSpace(axisSpace35);
        boolean boolean37 = categoryPlot34.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        java.awt.geom.Point2D point2D41 = null;
        categoryPlot34.zoomDomainAxes((double) 2, 0.2d, plotRenderingInfo40, point2D41);
        org.jfree.chart.plot.PolarPlot polarPlot43 = new org.jfree.chart.plot.PolarPlot();
        polarPlot43.setBackgroundAlpha((float) (-1));
        org.jfree.chart.JFreeChart jFreeChart46 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot43);
        int int47 = polarPlot43.getSeriesCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        java.awt.geom.Point2D point2D50 = null;
        polarPlot43.zoomDomainAxes(0.2d, plotRenderingInfo49, point2D50, false);
        java.awt.Color color53 = org.jfree.chart.ChartColor.DARK_BLUE;
        polarPlot43.setBackgroundPaint((java.awt.Paint) color53);
        categoryPlot34.setRangeCrosshairPaint((java.awt.Paint) color53);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(color53);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo1);
        org.jfree.chart.ui.Library[] libraryArray3 = projectInfo1.getLibraries();
        org.jfree.chart.ui.Library[] libraryArray4 = projectInfo1.getLibraries();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(libraryArray3);
        org.junit.Assert.assertNotNull(libraryArray4);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart8.removeProgressListener(chartProgressListener11);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart8.getLegend((int) (byte) 100);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart8.getLegend();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle15.setLegendItemGraphicLocation(rectangleAnchor16);
        org.jfree.chart.block.BlockContainer blockContainer18 = legendTitle15.getItemContainer();
        java.util.List list19 = blockContainer18.getBlocks();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertNotNull(legendTitle15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(blockContainer18);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer2 = new org.jfree.chart.text.G2TextMeasurer(graphics2D1);
        boolean boolean3 = blockBorder0.equals((java.lang.Object) g2TextMeasurer2);
        org.jfree.chart.text.TextBlock textBlock4 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape12 = textBlock4.calculateBounds(graphics2D5, (float) 0L, (float) (short) 10, textBlockAnchor8, (float) (short) 0, 0.0f, 0.05d);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        double double15 = ringPlot14.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = ringPlot14.getLabelPadding();
        double double17 = ringPlot14.getOuterSeparatorExtension();
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot();
        ringPlot18.setIgnoreNullValues(true);
        java.awt.Stroke stroke21 = ringPlot18.getSeparatorStroke();
        ringPlot14.setLabelLinkStroke(stroke21);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier23 = ringPlot14.getDrawingSupplier();
        java.lang.String str24 = ringPlot14.getPlotType();
        java.awt.Font font25 = ringPlot14.getLabelFont();
        java.awt.Paint paint26 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        textBlock4.addLine("Polar Plot", font25, paint26);
        boolean boolean28 = blockBorder0.equals((java.lang.Object) paint26);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(drawingSupplier23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pie Plot" + "'", str24.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        textTitle0.setBackgroundPaint((java.awt.Paint) color1);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        ringPlot0.setBackgroundAlpha((float) (-1));
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.plot.Plot plot5 = plotChangeEvent4.getPlot();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = plotChangeEvent4.getType();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertNotNull(chartChangeEventType6);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers(layer18);
        boolean boolean20 = xYPlot14.isRangeZoomable();
        boolean boolean21 = xYPlot14.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D23 = new org.jfree.chart.axis.CategoryAxis3D("TextAnchor.BOTTOM_LEFT");
        boolean boolean24 = xYPlot14.equals((java.lang.Object) "TextAnchor.BOTTOM_LEFT");
        java.awt.Paint paint25 = xYPlot14.getRangeGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        try {
            xYPlot14.handleClick(15, (int) (byte) 100, plotRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        ringPlot0.setBackgroundAlpha((float) (-1));
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        ringPlot0.setLabelFont(font5);
        int int7 = ringPlot0.getBackgroundImageAlignment();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        ringPlot0.markerChanged(markerChangeEvent8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        double double3 = ringPlot0.getOuterSeparatorExtension();
        ringPlot0.setOuterSeparatorExtension((double) (byte) 0);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ringPlot0.setBackgroundPaint((java.awt.Paint) color6);
        double double8 = ringPlot0.getMinimumArcAngleToDraw();
        org.jfree.chart.util.Rotation rotation9 = ringPlot0.getDirection();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0E-5d + "'", double8 == 1.0E-5d);
        org.junit.Assert.assertNotNull(rotation9);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundAlpha((float) (-1));
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        int int4 = polarPlot0.getSeriesCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        polarPlot0.zoomDomainAxes(0.2d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        polarPlot0.setRenderer(polarItemRenderer10);
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        ringPlot12.setIgnoreNullValues(true);
        double double15 = ringPlot12.getInnerSeparatorExtension();
        int int16 = ringPlot12.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = ringPlot12.getSimpleLabelOffset();
        polarPlot0.setInsets(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.2d + "'", double15 == 0.2d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        numberAxis1.setRangeAboutValue(0.0d, 0.0d);
        boolean boolean6 = numberAxis1.isTickLabelsVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis1.setNumberFormatOverride(numberFormat7);
        numberAxis1.setAutoRange(true);
        java.awt.Paint paint11 = numberAxis1.getLabelPaint();
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        try {
            org.jfree.chart.plot.XYPlot xYPlot11 = jFreeChart8.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PolarPlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getLabelLinkMargin();
        ringPlot0.setSeparatorsVisible(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025d + "'", double1 == 0.025d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=1.0]");
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        double double4 = ringPlot3.getMaximumExplodePercent();
        ringPlot3.setBackgroundAlpha((float) (-1));
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot3);
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        ringPlot3.setLabelFont(font8);
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("", font8);
        org.jfree.chart.text.TextFragment textFragment11 = textLine10.getLastTextFragment();
        java.awt.Font font12 = textFragment11.getFont();
        boolean boolean14 = textFragment11.equals((java.lang.Object) "http://www.jfree.org/jfreechart/index.html");
        textLine1.removeFragment(textFragment11);
        java.awt.Graphics2D graphics2D16 = null;
        try {
            org.jfree.chart.util.Size2D size2D17 = textFragment11.calculateDimensions(graphics2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(textFragment11);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        org.jfree.chart.LegendItemCollection legendItemCollection39 = categoryPlot34.getFixedLegendItems();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent40 = null;
        categoryPlot34.datasetChanged(datasetChangeEvent40);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNull(legendItemCollection39);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = polarPlot3.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis5 = polarPlot3.getAxis();
        polarPlot3.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", font2, (org.jfree.chart.plot.Plot) polarPlot3, true);
        org.jfree.chart.title.Title title10 = null;
        jFreeChart9.removeSubtitle(title10);
        org.jfree.chart.event.ChartProgressListener chartProgressListener12 = null;
        jFreeChart9.removeProgressListener(chartProgressListener12);
        int int14 = jFreeChart9.getSubtitleCount();
        jFreeChart9.clearSubtitles();
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_RED;
        jFreeChart9.setBorderPaint((java.awt.Paint) color16);
        java.util.List list18 = jFreeChart9.getSubtitles();
        java.awt.image.BufferedImage bufferedImage21 = jFreeChart9.createBufferedImage(1, 10);
        java.awt.RenderingHints renderingHints22 = jFreeChart9.getRenderingHints();
        boolean boolean23 = textTitle0.equals((java.lang.Object) renderingHints22);
        java.awt.Paint paint24 = textTitle0.getBackgroundPaint();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(bufferedImage21);
        org.junit.Assert.assertNotNull(renderingHints22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(paint24);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart8.removeProgressListener(chartProgressListener11);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart8.getLegend((int) (byte) 100);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart8.getLegend();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = legendTitle15.getLegendItemGraphicAnchor();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray17 = legendTitle15.getSources();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertNotNull(legendTitle15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(legendItemSourceArray17);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean2 = range0.contains(0.0d);
        double double4 = range0.constrain((double) '#');
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        double double3 = ringPlot0.getOuterSeparatorExtension();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        ringPlot4.setIgnoreNullValues(true);
        java.awt.Stroke stroke7 = ringPlot4.getSeparatorStroke();
        ringPlot0.setLabelLinkStroke(stroke7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = ringPlot0.getDrawingSupplier();
        ringPlot0.setInnerSeparatorExtension((double) (byte) 100);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator12 = ringPlot0.getURLGenerator();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        boolean boolean14 = ringPlot0.equals((java.lang.Object) numberTickUnit13);
        java.awt.Graphics2D graphics2D15 = null;
        double[] doubleArray21 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray25 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray29 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray33 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray34 = new double[][] { doubleArray21, doubleArray25, doubleArray29, doubleArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray34);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean37 = categoryAxis3D36.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot38 = categoryAxis3D36.getPlot();
        categoryAxis3D36.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot41 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = polarPlot41.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range44 = polarPlot41.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis43);
        dateAxis43.setAutoTickUnitSelection(true, false);
        java.util.Date date48 = dateAxis43.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) dateAxis43, categoryItemRenderer49);
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D52 = new org.jfree.chart.axis.CategoryAxis3D();
        double double53 = categoryAxis3D52.getCategoryMargin();
        java.awt.Font font58 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot59 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = polarPlot59.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis61 = polarPlot59.getAxis();
        polarPlot59.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart65 = new org.jfree.chart.JFreeChart("hi!", font58, (org.jfree.chart.plot.Plot) polarPlot59, true);
        org.jfree.chart.title.TextTitle textTitle66 = new org.jfree.chart.title.TextTitle("hi!", font58);
        java.awt.geom.Rectangle2D rectangle2D67 = textTitle66.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double69 = categoryAxis3D52.getCategoryStart((int) (short) 10, (int) '4', rectangle2D67, rectangleEdge68);
        categoryPlot50.drawBackgroundImage(graphics2D51, rectangle2D67);
        org.jfree.chart.plot.RingPlot ringPlot71 = new org.jfree.chart.plot.RingPlot();
        ringPlot71.setIgnoreNullValues(true);
        double double74 = ringPlot71.getInnerSeparatorExtension();
        int int75 = ringPlot71.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets76 = ringPlot71.getSimpleLabelOffset();
        java.awt.Paint paint77 = ringPlot71.getLabelShadowPaint();
        boolean boolean78 = ringPlot71.isCircular();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo80 = null;
        org.jfree.chart.plot.PiePlotState piePlotState81 = ringPlot0.initialise(graphics2D15, rectangle2D67, (org.jfree.chart.plot.PiePlot) ringPlot71, (java.lang.Integer) 15, plotRenderingInfo80);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(drawingSupplier9);
        org.junit.Assert.assertNull(pieURLGenerator12);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(plot38);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNull(range44);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.2d + "'", double53 == 0.2d);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertNull(valueAxis61);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(rectangleEdge68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.2d + "'", double74 == 0.2d);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 15 + "'", int75 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets76);
        org.junit.Assert.assertNotNull(paint77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(piePlotState81);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("http://www.jfree.org/jfreechart/index.html");
        numberAxis1.setUpperMargin((double) ' ');
        numberAxis1.setFixedDimension((double) 0L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range3 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis2);
        dateAxis2.setLabelURL("hi!");
        dateAxis2.setAutoTickUnitSelection(false);
        java.lang.Object obj8 = null;
        boolean boolean9 = dateAxis2.equals(obj8);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        double double3 = ringPlot0.getInnerSeparatorExtension();
        int int4 = ringPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = ringPlot0.getSimpleLabelOffset();
        java.awt.Paint paint6 = ringPlot0.getLabelShadowPaint();
        java.awt.Paint paint7 = ringPlot0.getLabelOutlinePaint();
        boolean boolean8 = ringPlot0.getSimpleLabels();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis6 = polarPlot4.getAxis();
        polarPlot4.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("hi!", font3, (org.jfree.chart.plot.Plot) polarPlot4, true);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("hi!", font3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = textTitle11.getTextAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle11.setHorizontalAlignment(horizontalAlignment13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = textTitle11.getMargin();
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        double double17 = ringPlot16.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = ringPlot16.getLabelPadding();
        ringPlot16.setMaximumLabelWidth((double) 0);
        double double21 = ringPlot16.getStartAngle();
        try {
            blockContainer0.add((org.jfree.chart.block.Block) textTitle11, (java.lang.Object) double21);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Double cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = numberAxis1.getTickUnit();
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        org.jfree.chart.plot.Plot plot5 = null;
        numberAxis1.setPlot(plot5);
        java.awt.Paint paint7 = numberAxis1.getTickLabelPaint();
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("hi!", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = polarPlot3.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis5 = polarPlot3.getAxis();
        polarPlot3.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", font2, (org.jfree.chart.plot.Plot) polarPlot3, true);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font2);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        textTitle10.setPaint((java.awt.Paint) color11);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = polarPlot3.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis5 = polarPlot3.getAxis();
        polarPlot3.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", font2, (org.jfree.chart.plot.Plot) polarPlot3, true);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font2);
        textTitle10.setPadding((double) (short) 10, (-1.0d), 0.2d, (double) '#');
        java.awt.geom.Rectangle2D rectangle2D16 = textTitle10.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16);
        chartEntity17.setToolTipText("JFreeChart");
        java.lang.String str20 = chartEntity17.getToolTipText();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "JFreeChart" + "'", str20.equals("JFreeChart"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setPieCenterX((double) 0);
        piePlotState1.setPieWRadius((double) 10.0f);
        double double6 = piePlotState1.getPieCenterX();
        piePlotState1.setPieCenterX((double) 'a');
        double double9 = piePlotState1.getLatestAngle();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        double double3 = rectangleInsets2.getRight();
        double double5 = rectangleInsets2.calculateRightInset((double) 3);
        double double6 = rectangleInsets2.getTop();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        java.awt.Font font40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot41 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = polarPlot41.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis43 = polarPlot41.getAxis();
        polarPlot41.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart47 = new org.jfree.chart.JFreeChart("hi!", font40, (org.jfree.chart.plot.Plot) polarPlot41, true);
        org.jfree.chart.title.Title title48 = null;
        jFreeChart47.removeSubtitle(title48);
        org.jfree.chart.event.ChartProgressListener chartProgressListener50 = null;
        jFreeChart47.removeProgressListener(chartProgressListener50);
        int int52 = jFreeChart47.getSubtitleCount();
        java.awt.Stroke stroke53 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        jFreeChart47.setBorderStroke(stroke53);
        categoryPlot34.setDomainGridlineStroke(stroke53);
        org.jfree.chart.plot.Plot plot56 = categoryPlot34.getParent();
        boolean boolean57 = categoryPlot34.isRangeZoomable();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNull(valueAxis43);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNull(plot56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        xYPlot14.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot14.getDomainAxis((int) (short) 0);
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot14.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker19);
        boolean boolean21 = xYPlot14.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisSpace axisSpace22 = xYPlot14.getFixedDomainAxisSpace();
        xYPlot14.setDomainCrosshairValue((double) (short) 1, false);
        org.jfree.chart.axis.ValueAxis valueAxis26 = xYPlot14.getDomainAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        xYPlot14.setRenderer(0, xYItemRenderer28, false);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(valueAxis17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(axisSpace22);
        org.junit.Assert.assertNotNull(valueAxis26);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, (double) (short) -1);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        blockContainer5.clear();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.Size2D size2D8 = blockContainer5.arrange(graphics2D7);
        java.lang.Object obj9 = size2D8.clone();
        double double10 = size2D8.getHeight();
        size2D8.setHeight((double) (byte) 1);
        java.lang.String str13 = size2D8.toString();
        org.junit.Assert.assertNotNull(size2D8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Size2D[width=0.0, height=1.0]" + "'", str13.equals("Size2D[width=0.0, height=1.0]"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        ringPlot0.setBackgroundAlpha((float) (-1));
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        ringPlot0.setLabelFont(font5);
        java.awt.Paint paint7 = ringPlot0.getBaseSectionPaint();
        java.lang.String str8 = ringPlot0.getNoDataMessage();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        java.awt.Stroke stroke3 = ringPlot0.getSeparatorStroke();
        double double4 = ringPlot0.getMinimumArcAngleToDraw();
        double double5 = ringPlot0.getSectionDepth();
        ringPlot0.setForegroundAlpha(0.5f);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        double double10 = categoryAxis9.getUpperMargin();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        double double14 = categoryAxis3D13.getCategoryMargin();
        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = polarPlot20.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis22 = polarPlot20.getAxis();
        polarPlot20.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("hi!", font19, (org.jfree.chart.plot.Plot) polarPlot20, true);
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("hi!", font19);
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle27.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double30 = categoryAxis3D13.getCategoryStart((int) (short) 10, (int) '4', rectangle2D28, rectangleEdge29);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double32 = categoryAxis9.getCategoryEnd(15, (int) '4', rectangle2D28, rectangleEdge31);
        ringPlot0.drawBackgroundImage(graphics2D8, rectangle2D28);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator34 = ringPlot0.getToolTipGenerator();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-5d + "'", double4 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(pieToolTipGenerator34);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange((double) 100);
        double double3 = dateAxis0.getFixedAutoRange();
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis0.setUpArrow(shape4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = polarPlot7.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis9 = polarPlot7.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = polarPlot10.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range13 = polarPlot10.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis12);
        polarPlot7.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis12);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat17 = numberAxis16.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit18 = numberAxis16.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis16, xYItemRenderer19);
        xYPlot20.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot20.getDomainAxis((int) (short) 0);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot20.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker25);
        boolean boolean27 = xYPlot20.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisSpace axisSpace28 = xYPlot20.getFixedDomainAxisSpace();
        xYPlot20.setDomainCrosshairValue(3.0d);
        xYPlot20.setDomainCrosshairValue(1.0E-5d, true);
        dateAxis0.setPlot((org.jfree.chart.plot.Plot) xYPlot20);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNull(numberFormat17);
        org.junit.Assert.assertNotNull(numberTickUnit18);
        org.junit.Assert.assertNotNull(valueAxis23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(axisSpace28);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str1.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        int int35 = categoryPlot34.getRangeAxisCount();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray36 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot34.setRangeAxes(valueAxisArray36);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot34.getRangeAxisEdge();
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis();
        java.lang.String str41 = numberAxis40.getLabel();
        categoryPlot34.setRangeAxis((int) (byte) 0, (org.jfree.chart.axis.ValueAxis) numberAxis40);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot34.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(valueAxisArray36);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(rectangleEdge43);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis2 = polarPlot0.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = polarPlot3.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range6 = polarPlot3.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis5);
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        double double8 = dateAxis5.getUpperBound();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis6 = polarPlot4.getAxis();
        polarPlot4.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("hi!", font3, (org.jfree.chart.plot.Plot) polarPlot4, true);
        org.jfree.chart.title.Title title11 = null;
        jFreeChart10.removeSubtitle(title11);
        org.jfree.chart.event.ChartProgressListener chartProgressListener13 = null;
        jFreeChart10.removeProgressListener(chartProgressListener13);
        int int15 = jFreeChart10.getSubtitleCount();
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        jFreeChart10.setBorderStroke(stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        ringPlot21.setIgnoreNullValues(true);
        java.awt.Stroke stroke24 = ringPlot21.getSeparatorStroke();
        java.awt.Stroke[] strokeArray25 = new java.awt.Stroke[] { stroke16, stroke18, stroke19, stroke20, stroke24 };
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D29 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean30 = categoryAxis3D29.isTickLabelsVisible();
        java.awt.Stroke stroke31 = categoryAxis3D29.getTickMarkStroke();
        java.awt.Stroke[] strokeArray32 = new java.awt.Stroke[] { stroke26, stroke27, stroke28, stroke31 };
        org.jfree.chart.plot.RingPlot ringPlot33 = new org.jfree.chart.plot.RingPlot();
        double double34 = ringPlot33.getMaximumExplodePercent();
        java.awt.Shape shape35 = ringPlot33.getLegendItemShape();
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] { shape35, shape36 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray25, strokeArray32, shapeArray37);
        java.awt.Stroke stroke39 = defaultDrawingSupplier38.getNextStroke();
        java.awt.Paint paint40 = defaultDrawingSupplier38.getNextPaint();
        java.awt.Paint paint41 = defaultDrawingSupplier38.getNextOutlinePaint();
        java.awt.Paint paint42 = defaultDrawingSupplier38.getNextPaint();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(strokeArray25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(strokeArray32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        org.jfree.chart.LegendItemCollection legendItemCollection39 = categoryPlot34.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot34.getRangeAxisEdge((int) '4');
        org.jfree.chart.util.Layer layer43 = null;
        java.util.Collection collection44 = categoryPlot34.getRangeMarkers((int) (short) -1, layer43);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNull(legendItemCollection39);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNull(collection44);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot14.getDomainMarkers(1, layer16);
        java.awt.Paint paint18 = xYPlot14.getDomainCrosshairPaint();
        boolean boolean19 = xYPlot14.isRangeCrosshairVisible();
        java.awt.Paint paint20 = xYPlot14.getOutlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot14.zoomDomainAxes((-2.0d), plotRenderingInfo22, point2D23);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        categoryPlot34.setFixedDomainAxisSpace(axisSpace35);
        categoryPlot34.setWeight((int) '4');
        categoryPlot34.clearAnnotations();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        categoryPlot34.setRenderer((int) 'a', categoryItemRenderer41);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation43 = null;
        try {
            categoryPlot34.addAnnotation(categoryAnnotation43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange((double) 100);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis6 = polarPlot4.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = polarPlot7.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range10 = polarPlot7.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis9);
        polarPlot4.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat14 = numberAxis13.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = numberAxis13.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = xYPlot17.getRenderer();
        xYPlot17.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot17.getDomainMarkers(layer21);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot17.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        xYPlot17.setRenderer(xYItemRenderer26);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot17);
        boolean boolean29 = xYPlot17.isDomainCrosshairLockedOnData();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.RingPlot ringPlot34 = new org.jfree.chart.plot.RingPlot();
        double double35 = ringPlot34.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = ringPlot34.getLabelPadding();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator37 = null;
        ringPlot34.setLegendLabelToolTipGenerator(pieSectionLabelGenerator37);
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.Font font42 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot43 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = polarPlot43.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis45 = polarPlot43.getAxis();
        polarPlot43.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart49 = new org.jfree.chart.JFreeChart("hi!", font42, (org.jfree.chart.plot.Plot) polarPlot43, true);
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle("hi!", font42);
        textTitle50.setPadding((double) (short) 10, (-1.0d), 0.2d, (double) '#');
        java.awt.geom.Rectangle2D rectangle2D56 = textTitle50.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double58 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D56, rectangleEdge57);
        ringPlot34.drawBackgroundImage(graphics2D39, rectangle2D56);
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = org.jfree.chart.util.RectangleEdge.TOP;
        double double61 = categoryAxis31.getCategoryStart(0, 0, rectangle2D56, rectangleEdge60);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo62 = null;
        xYPlot17.drawAnnotations(graphics2D30, rectangle2D56, plotRenderingInfo62);
        org.jfree.chart.axis.ValueAxis valueAxis65 = xYPlot17.getDomainAxis(0);
        org.jfree.data.xy.XYDataset xYDataset67 = null;
        xYPlot17.setDataset(0, xYDataset67);
        xYPlot17.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(numberFormat14);
        org.junit.Assert.assertNotNull(numberTickUnit15);
        org.junit.Assert.assertNull(xYItemRenderer18);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNull(valueAxis45);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangleEdge57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxis65);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        xYPlot14.setDataset((int) 'a', xYDataset19);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        double double3 = ringPlot0.getInnerSeparatorExtension();
        boolean boolean4 = ringPlot0.getSeparatorsVisible();
        ringPlot0.setSimpleLabels(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = ringPlot0.getLabelPadding();
        double double9 = rectangleInsets7.calculateRightOutset(2.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range(208.0d, (double) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (208.0) <= upper (3.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart8.removeProgressListener(chartProgressListener11);
        int int13 = jFreeChart8.getSubtitleCount();
        jFreeChart8.clearSubtitles();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        jFreeChart8.setBorderPaint((java.awt.Paint) color15);
        java.util.List list17 = jFreeChart8.getSubtitles();
        java.awt.image.BufferedImage bufferedImage20 = jFreeChart8.createBufferedImage(1, 10);
        java.awt.RenderingHints renderingHints21 = jFreeChart8.getRenderingHints();
        org.jfree.chart.event.ChartProgressListener chartProgressListener22 = null;
        jFreeChart8.addProgressListener(chartProgressListener22);
        jFreeChart8.setBackgroundImageAlignment(0);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(bufferedImage20);
        org.junit.Assert.assertNotNull(renderingHints21);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Pie Plot");
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.util.Rotation rotation1 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = polarPlot5.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range8 = polarPlot5.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis7);
        polarPlot2.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis7);
        boolean boolean10 = rotation1.equals((java.lang.Object) polarPlot2);
        double double11 = polarPlot2.getMaxRadius();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot2);
        java.awt.Paint paint13 = polarPlot2.getAngleLabelPaint();
        org.jfree.chart.axis.ValueAxis valueAxis14 = polarPlot2.getAxis();
        org.jfree.data.xy.XYDataset xYDataset15 = polarPlot2.getDataset();
        boolean boolean16 = polarPlot2.isAngleLabelsVisible();
        boolean boolean17 = polarPlot2.isRangeZoomable();
        org.junit.Assert.assertNotNull(rotation1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(valueAxis14);
        org.junit.Assert.assertNull(xYDataset15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        java.awt.Stroke stroke3 = ringPlot0.getSeparatorStroke();
        double double4 = ringPlot0.getMinimumArcAngleToDraw();
        ringPlot0.setLabelLinksVisible(true);
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = polarPlot9.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis11 = polarPlot9.getAxis();
        polarPlot9.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("hi!", font8, (org.jfree.chart.plot.Plot) polarPlot9, true);
        org.jfree.chart.title.Title title16 = null;
        jFreeChart15.removeSubtitle(title16);
        org.jfree.chart.event.ChartProgressListener chartProgressListener18 = null;
        jFreeChart15.removeProgressListener(chartProgressListener18);
        int int20 = jFreeChart15.getSubtitleCount();
        jFreeChart15.clearSubtitles();
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_RED;
        jFreeChart15.setBorderPaint((java.awt.Paint) color22);
        ringPlot0.setSeparatorPaint((java.awt.Paint) color22);
        double double25 = ringPlot0.getStartAngle();
        org.jfree.chart.ui.ProjectInfo projectInfo26 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo27 = org.jfree.chart.JFreeChart.INFO;
        projectInfo26.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo27);
        org.jfree.chart.ui.Library[] libraryArray29 = projectInfo27.getLibraries();
        java.awt.Image image30 = projectInfo27.getLogo();
        ringPlot0.setBackgroundImage(image30);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-5d + "'", double4 == 1.0E-5d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(projectInfo26);
        org.junit.Assert.assertNotNull(projectInfo27);
        org.junit.Assert.assertNotNull(libraryArray29);
        org.junit.Assert.assertNotNull(image30);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers(layer18);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot14.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        xYPlot14.setRenderer(xYItemRenderer23);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        dateAxis25.centerRange((double) 100);
        java.lang.String str28 = dateAxis25.getLabelToolTip();
        xYPlot14.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis25);
        java.lang.String str30 = xYPlot14.getPlotType();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "XY Plot" + "'", str30.equals("XY Plot"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers(layer18);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot14.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        xYPlot14.setRenderer(xYItemRenderer23);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        dateAxis25.centerRange((double) 100);
        java.lang.String str28 = dateAxis25.getLabelToolTip();
        xYPlot14.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis25);
        org.jfree.chart.axis.ValueAxis valueAxis30 = xYPlot14.getDomainAxis();
        int int31 = xYPlot14.getDomainAxisCount();
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        org.jfree.chart.util.Layer layer35 = null;
        xYPlot14.addRangeMarker(15, (org.jfree.chart.plot.Marker) valueMarker34, layer35);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(valueAxis30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.awt.Color color0 = java.awt.Color.gray;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart8.removeProgressListener(chartProgressListener11);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart8.getLegend((int) (byte) 100);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart8.getLegend();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray16 = legendTitle15.getSources();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = legendTitle15.getHorizontalAlignment();
        java.awt.Paint paint18 = null;
        try {
            legendTitle15.setItemPaint(paint18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertNotNull(legendTitle15);
        org.junit.Assert.assertNotNull(legendItemSourceArray16);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        ringPlot17.setIgnoreNullValues(true);
        double double20 = ringPlot17.getInnerSeparatorExtension();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat23 = numberAxis22.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit24 = numberAxis22.getTickUnit();
        ringPlot17.setExplodePercent((java.lang.Comparable) numberTickUnit24, (double) 2);
        numberAxis16.setTickUnit(numberTickUnit24, false, false);
        numberAxis16.setTickMarkInsideLength((float) (byte) 100);
        java.awt.Font font32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        numberAxis16.setLabelFont(font32);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean35 = numberAxis16.equals((java.lang.Object) rectangleInsets34);
        int int36 = xYPlot14.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis16);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.2d + "'", double20 == 0.2d);
        org.junit.Assert.assertNull(numberFormat23);
        org.junit.Assert.assertNotNull(numberTickUnit24);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.trimWidth(1.0E-8d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.99999999d) + "'", double2 == (-7.99999999d));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeIncludesZero(true);
        numberAxis2.setAutoRangeStickyZero(false);
        numberAxis2.setUpperBound((double) '4');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer9);
        java.lang.String str11 = polarPlot10.getNoDataMessage();
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        xYPlot14.clearRangeMarkers();
        java.awt.Font font16 = xYPlot14.getNoDataMessageFont();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot14.setRangeTickBandPaint((java.awt.Paint) color17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.Color color20 = java.awt.Color.BLUE;
        float[] floatArray27 = new float[] { 10.0f, 100L, 1, (-1.0f), (byte) 100, 100 };
        float[] floatArray28 = color20.getColorComponents(floatArray27);
        float[] floatArray29 = color19.getColorComponents(floatArray27);
        float[] floatArray30 = color17.getComponents(floatArray27);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        xYPlot14.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot14.getDomainAxis((int) (short) 0);
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double19 = range18.getUpperBound();
        valueAxis17.setRange(range18);
        double double21 = range18.getUpperBound();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(valueAxis17);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart8.removeProgressListener(chartProgressListener11);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart8.getLegend((int) (byte) 100);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart8.getLegend();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = legendTitle15.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = legendTitle15.getLegendItemGraphicAnchor();
        java.lang.String str18 = legendTitle15.getID();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertNotNull(legendTitle15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = polarPlot3.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis5 = polarPlot3.getAxis();
        polarPlot3.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", font2, (org.jfree.chart.plot.Plot) polarPlot3, true);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font2);
        textTitle10.setPadding((double) (short) 10, (-1.0d), 0.2d, (double) '#');
        java.awt.geom.Rectangle2D rectangle2D16 = textTitle10.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat20 = numberAxis19.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit21 = numberAxis19.getTickUnit();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand22 = null;
        numberAxis19.setMarkerBand(markerAxisBand22);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        dateAxis24.centerRange((double) 100);
        java.lang.String str27 = dateAxis24.getLabelToolTip();
        java.awt.Shape shape28 = dateAxis24.getLeftArrow();
        numberAxis19.setLeftArrow(shape28);
        chartEntity17.setArea(shape28);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNull(numberFormat20);
        org.junit.Assert.assertNotNull(numberTickUnit21);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(shape28);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.util.List list1 = textBlock0.getLines();
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        float float4 = valueMarker3.getAlpha();
        java.lang.Object obj5 = valueMarker3.clone();
        boolean boolean6 = textBlock0.equals((java.lang.Object) valueMarker3);
        double double7 = valueMarker3.getValue();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.8f + "'", float4 == 0.8f);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        categoryPlot34.setFixedDomainAxisSpace(axisSpace35);
        categoryPlot34.setWeight((int) '4');
        categoryPlot34.clearAnnotations();
        categoryPlot34.clearRangeMarkers();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean2 = range0.contains(0.0d);
        double double3 = range0.getLowerBound();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        double double1 = size2D0.height;
        size2D0.setHeight(10.0d);
        double double4 = size2D0.getWidth();
        double double5 = size2D0.getHeight();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        org.jfree.chart.LegendItemCollection legendItemCollection39 = categoryPlot34.getFixedLegendItems();
        double double40 = categoryPlot34.getRangeCrosshairValue();
        java.util.List list41 = categoryPlot34.getAnnotations();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder42 = categoryPlot34.getDatasetRenderingOrder();
        java.awt.Paint paint43 = categoryPlot34.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = categoryPlot34.getDomainAxis();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNull(legendItemCollection39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertNotNull(datasetRenderingOrder42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(categoryAxis44);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { (short) -1, (-1), 100.0f, (-1L), 15.625d, 1.0E-8d };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (short) -1, (-1), 100.0f, (-1L), 15.625d, 1.0E-8d };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { (short) -1, (-1), 100.0f, (-1L), 15.625d, 1.0E-8d };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (short) -1, (-1), 100.0f, (-1L), 15.625d, 1.0E-8d };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { (short) -1, (-1), 100.0f, (-1L), 15.625d, 1.0E-8d };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { (short) -1, (-1), 100.0f, (-1L), 15.625d, 1.0E-8d };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray8, numberArray15, numberArray22, numberArray29, numberArray36, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray44);
        java.lang.Comparable comparable46 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset45, comparable46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getCategoryMargin();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = polarPlot7.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis9 = polarPlot7.getAxis();
        polarPlot7.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("hi!", font6, (org.jfree.chart.plot.Plot) polarPlot7, true);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("hi!", font6);
        java.awt.geom.Rectangle2D rectangle2D15 = textTitle14.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double17 = categoryAxis3D0.getCategoryStart((int) (short) 10, (int) '4', rectangle2D15, rectangleEdge16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers(layer18);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot14.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        xYPlot14.setRenderer(xYItemRenderer23);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        polarPlot25.setBackgroundAlpha((float) (-1));
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot25);
        java.awt.Paint paint29 = jFreeChart28.getBackgroundPaint();
        xYPlot14.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart28);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent31 = null;
        try {
            jFreeChart28.plotChanged(plotChangeEvent31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart8.removeProgressListener(chartProgressListener11);
        int int13 = jFreeChart8.getSubtitleCount();
        jFreeChart8.clearSubtitles();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        jFreeChart8.setBorderPaint((java.awt.Paint) color15);
        java.util.List list17 = jFreeChart8.getSubtitles();
        java.awt.Paint paint18 = jFreeChart8.getBorderPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers(layer18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = null;
        xYPlot14.setDomainAxisLocation(15, axisLocation21, false);
        org.jfree.chart.axis.AxisSpace axisSpace24 = null;
        xYPlot14.setFixedRangeAxisSpace(axisSpace24, true);
        xYPlot14.setRangeCrosshairValue(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(collection19);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setPieCenterY(1.0E-8d);
        int int4 = piePlotState1.getPassesRequired();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        ringPlot0.setStartAngle((double) 0);
        boolean boolean4 = ringPlot0.getIgnoreNullValues();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("TextAnchor.BASELINE_CENTER", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=1.0]", "", "RectangleEdge.LEFT");
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isRangeGridlinesVisible();
        boolean boolean16 = xYPlot14.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("Size2D[width=0.0, height=0.0]", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.awt.Color color0 = java.awt.Color.blue;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setPieCenterX((double) 0);
        double double4 = piePlotState1.getTotal();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        double double3 = ringPlot2.getMaximumExplodePercent();
        ringPlot2.setBackgroundAlpha((float) (-1));
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot2);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        ringPlot2.setLabelFont(font7);
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("", font7);
        org.jfree.chart.text.TextFragment textFragment10 = textLine9.getLastTextFragment();
        java.awt.Font font11 = textFragment10.getFont();
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("1.2.0-pre", font11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = org.jfree.chart.block.RectangleConstraint.NONE;
        try {
            org.jfree.chart.util.Size2D size2D15 = textTitle12.arrange(graphics2D13, rectangleConstraint14);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(textFragment10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        int int35 = categoryPlot34.getRangeAxisCount();
        categoryPlot34.clearDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        categoryPlot34.zoomRangeAxes((double) (-1L), plotRenderingInfo38, point2D39, false);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        categoryPlot34.setFixedDomainAxisSpace(axisSpace35);
        boolean boolean37 = categoryPlot34.isRangeCrosshairVisible();
        categoryPlot34.setRangeCrosshairValue((double) 0.5f);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = categoryPlot34.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleEdge40);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        categoryPlot34.setFixedDomainAxisSpace(axisSpace35);
        categoryPlot34.setWeight((int) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        categoryPlot34.setRenderer(1, categoryItemRenderer40);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.plot.PolarPlot polarPlot43 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = polarPlot43.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis45 = polarPlot43.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot46 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = polarPlot46.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range49 = polarPlot46.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis48);
        polarPlot43.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis48);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat53 = numberAxis52.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit54 = numberAxis52.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer55 = null;
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot(xYDataset42, (org.jfree.chart.axis.ValueAxis) dateAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis52, xYItemRenderer55);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer57 = xYPlot56.getRenderer();
        xYPlot56.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer60 = null;
        java.util.Collection collection61 = xYPlot56.getDomainMarkers(layer60);
        org.jfree.chart.plot.ValueMarker valueMarker63 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot56.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker63);
        java.awt.Color color65 = org.jfree.chart.ChartColor.DARK_GREEN;
        valueMarker63.setOutlinePaint((java.awt.Paint) color65);
        try {
            boolean boolean67 = categoryPlot34.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNull(valueAxis45);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertNull(numberFormat53);
        org.junit.Assert.assertNotNull(numberTickUnit54);
        org.junit.Assert.assertNull(xYItemRenderer57);
        org.junit.Assert.assertNull(collection61);
        org.junit.Assert.assertNotNull(color65);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isRangeGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = xYPlot14.getRendererForDataset(xYDataset16);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        org.jfree.chart.util.Layer layer21 = null;
        try {
            boolean boolean22 = xYPlot14.removeDomainMarker(3, (org.jfree.chart.plot.Marker) valueMarker20, layer21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(xYItemRenderer17);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart8.removeProgressListener(chartProgressListener11);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart8.getLegend((int) (byte) 100);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart8.getLegend();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray16 = legendTitle15.getSources();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = legendTitle15.getHorizontalAlignment();
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        double double20 = ringPlot19.getMaximumExplodePercent();
        ringPlot19.setBackgroundAlpha((float) (-1));
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent23 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot19);
        java.awt.Font font24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        ringPlot19.setLabelFont(font24);
        org.jfree.chart.text.TextLine textLine26 = new org.jfree.chart.text.TextLine("", font24);
        legendTitle15.setItemFont(font24);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertNotNull(legendTitle15);
        org.junit.Assert.assertNotNull(legendItemSourceArray16);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(font24);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator1 = null;
        ringPlot0.setURLGenerator(pieURLGenerator1);
        boolean boolean3 = ringPlot0.isOutlineVisible();
        ringPlot0.setMinimumArcAngleToDraw(0.0d);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator6 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        ringPlot0.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator6);
        java.text.AttributedString attributedString9 = null;
        standardPieSectionLabelGenerator6.setAttributedLabel(0, attributedString9);
        java.text.NumberFormat numberFormat11 = standardPieSectionLabelGenerator6.getPercentFormat();
        java.text.NumberFormat numberFormat12 = standardPieSectionLabelGenerator6.getNumberFormat();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberFormat12);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        org.jfree.chart.LegendItemCollection legendItemCollection39 = categoryPlot34.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot34.getRangeAxisEdge((int) '4');
        categoryPlot34.setWeight((int) (short) 100);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNull(legendItemCollection39);
        org.junit.Assert.assertNotNull(rectangleEdge41);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot34.getRangeAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset41 = categoryPlot34.getDataset((int) 'a');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNull(categoryDataset41);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart8.removeProgressListener(chartProgressListener11);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart8.getLegend((int) (byte) 100);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart8.getLegend();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray16 = legendTitle15.getSources();
        double[] doubleArray22 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray26 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray30 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray34 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray35 = new double[][] { doubleArray22, doubleArray26, doubleArray30, doubleArray34 };
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray35);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D37 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean38 = categoryAxis3D37.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot39 = categoryAxis3D37.getPlot();
        categoryAxis3D37.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot42 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = polarPlot42.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range45 = polarPlot42.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis44);
        dateAxis44.setAutoTickUnitSelection(true, false);
        java.util.Date date49 = dateAxis44.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D37, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer50);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D52 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean53 = categoryAxis3D52.isTickLabelsVisible();
        boolean boolean54 = categoryAxis3D52.isVisible();
        int int55 = categoryPlot51.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D52);
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = categoryPlot51.getRangeAxisEdge();
        legendTitle15.setLegendItemGraphicEdge(rectangleEdge56);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D58 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean59 = categoryAxis3D58.isTickLabelsVisible();
        java.lang.Object obj60 = categoryAxis3D58.clone();
        org.jfree.chart.plot.RingPlot ringPlot61 = new org.jfree.chart.plot.RingPlot();
        ringPlot61.setIgnoreNullValues(true);
        double double64 = ringPlot61.getInnerSeparatorExtension();
        org.jfree.chart.axis.NumberAxis numberAxis66 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat67 = numberAxis66.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit68 = numberAxis66.getTickUnit();
        ringPlot61.setExplodePercent((java.lang.Comparable) numberTickUnit68, (double) 2);
        java.awt.Font font71 = categoryAxis3D58.getTickLabelFont((java.lang.Comparable) numberTickUnit68);
        legendTitle15.setItemFont(font71);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertNotNull(legendTitle15);
        org.junit.Assert.assertNotNull(legendItemSourceArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNull(plot39);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNull(range45);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(obj60);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.2d + "'", double64 == 0.2d);
        org.junit.Assert.assertNull(numberFormat67);
        org.junit.Assert.assertNotNull(numberTickUnit68);
        org.junit.Assert.assertNotNull(font71);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        org.jfree.chart.LegendItemCollection legendItemCollection39 = categoryPlot34.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot34.getRangeAxisEdge((int) '4');
        categoryPlot34.clearRangeMarkers();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        categoryPlot34.setRenderer(categoryItemRenderer43);
        org.jfree.chart.axis.AxisSpace axisSpace45 = null;
        categoryPlot34.setFixedDomainAxisSpace(axisSpace45);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        categoryPlot34.setRenderer(categoryItemRenderer47, true);
        org.jfree.chart.util.Layer layer51 = null;
        java.util.Collection collection52 = categoryPlot34.getDomainMarkers((int) ' ', layer51);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNull(legendItemCollection39);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNull(collection52);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        double double3 = ringPlot0.getOuterSeparatorExtension();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        ringPlot4.setIgnoreNullValues(true);
        java.awt.Stroke stroke7 = ringPlot4.getSeparatorStroke();
        ringPlot0.setLabelLinkStroke(stroke7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = ringPlot0.getDrawingSupplier();
        ringPlot0.setInnerSeparatorExtension((double) (byte) 100);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator12 = ringPlot0.getLegendLabelGenerator();
        java.awt.Paint paint13 = ringPlot0.getLabelBackgroundPaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(drawingSupplier9);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) 2.0d);
        java.lang.Object obj3 = strokeMap0.clone();
        java.awt.Stroke stroke5 = strokeMap0.getStroke((java.lang.Comparable) 2);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(stroke5);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis2 = polarPlot0.getAxis();
        polarPlot0.removeCornerTextItem("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis5 = polarPlot0.getAxis();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(valueAxis5);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers(layer18);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot14.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        xYPlot14.setRenderer(xYItemRenderer23);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        dateAxis25.centerRange((double) 100);
        java.lang.String str28 = dateAxis25.getLabelToolTip();
        xYPlot14.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis25);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        float float32 = valueMarker31.getAlpha();
        org.jfree.chart.plot.RingPlot ringPlot33 = new org.jfree.chart.plot.RingPlot();
        ringPlot33.setIgnoreNullValues(true);
        java.awt.Stroke stroke36 = ringPlot33.getSeparatorStroke();
        double double37 = ringPlot33.getMinimumArcAngleToDraw();
        double double38 = ringPlot33.getSectionDepth();
        ringPlot33.setForegroundAlpha(0.5f);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier41 = ringPlot33.getDrawingSupplier();
        valueMarker31.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) ringPlot33);
        xYPlot14.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker31);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 0.8f + "'", float32 == 0.8f);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0E-5d + "'", double37 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.2d + "'", double38 == 0.2d);
        org.junit.Assert.assertNotNull(drawingSupplier41);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        org.jfree.chart.LegendItemCollection legendItemCollection39 = categoryPlot34.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot34.getRangeAxisEdge((int) '4');
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean44 = categoryPlot34.equals((java.lang.Object) numberAxis43);
        int int45 = categoryPlot34.getRangeAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = categoryPlot34.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNull(legendItemCollection39);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge46);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.addCornerTextItem("Pie Plot");
        polarPlot0.setBackgroundImageAlignment(0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers(layer18);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        float float23 = valueMarker22.getAlpha();
        java.lang.Object obj24 = valueMarker22.clone();
        java.lang.String str25 = valueMarker22.getLabel();
        org.jfree.chart.util.Layer layer26 = null;
        xYPlot14.addRangeMarker((int) '4', (org.jfree.chart.plot.Marker) valueMarker22, layer26);
        valueMarker22.setValue((double) 0.8f);
        java.awt.Paint paint30 = valueMarker22.getOutlinePaint();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.8f + "'", float23 == 0.8f);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent18 = null;
        xYPlot14.markerChanged(markerChangeEvent18);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot14);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        org.jfree.chart.LegendItemCollection legendItemCollection39 = categoryPlot34.getFixedLegendItems();
        categoryPlot34.configureDomainAxes();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNull(legendItemCollection39);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis6 = polarPlot4.getAxis();
        polarPlot4.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("hi!", font3, (org.jfree.chart.plot.Plot) polarPlot4, true);
        org.jfree.chart.title.Title title11 = null;
        jFreeChart10.removeSubtitle(title11);
        org.jfree.chart.event.ChartProgressListener chartProgressListener13 = null;
        jFreeChart10.removeProgressListener(chartProgressListener13);
        int int15 = jFreeChart10.getSubtitleCount();
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        jFreeChart10.setBorderStroke(stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        ringPlot21.setIgnoreNullValues(true);
        java.awt.Stroke stroke24 = ringPlot21.getSeparatorStroke();
        java.awt.Stroke[] strokeArray25 = new java.awt.Stroke[] { stroke16, stroke18, stroke19, stroke20, stroke24 };
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D29 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean30 = categoryAxis3D29.isTickLabelsVisible();
        java.awt.Stroke stroke31 = categoryAxis3D29.getTickMarkStroke();
        java.awt.Stroke[] strokeArray32 = new java.awt.Stroke[] { stroke26, stroke27, stroke28, stroke31 };
        org.jfree.chart.plot.RingPlot ringPlot33 = new org.jfree.chart.plot.RingPlot();
        double double34 = ringPlot33.getMaximumExplodePercent();
        java.awt.Shape shape35 = ringPlot33.getLegendItemShape();
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] { shape35, shape36 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray25, strokeArray32, shapeArray37);
        java.awt.Stroke stroke39 = defaultDrawingSupplier38.getNextStroke();
        java.awt.Paint paint40 = defaultDrawingSupplier38.getNextPaint();
        java.awt.Paint paint41 = defaultDrawingSupplier38.getNextOutlinePaint();
        java.awt.Stroke stroke42 = defaultDrawingSupplier38.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(strokeArray25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(strokeArray32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(stroke42);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=1.0]");
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=1.0]");
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        double double6 = ringPlot5.getMaximumExplodePercent();
        ringPlot5.setBackgroundAlpha((float) (-1));
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot5);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        ringPlot5.setLabelFont(font10);
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("", font10);
        org.jfree.chart.text.TextFragment textFragment13 = textLine12.getLastTextFragment();
        java.awt.Font font14 = textFragment13.getFont();
        boolean boolean16 = textFragment13.equals((java.lang.Object) "http://www.jfree.org/jfreechart/index.html");
        textLine3.removeFragment(textFragment13);
        org.jfree.chart.text.TextFragment textFragment18 = textLine3.getLastTextFragment();
        textLine1.addFragment(textFragment18);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(textFragment13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(textFragment18);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, (double) (short) -1);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        blockContainer5.clear();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment7, verticalAlignment8, 0.0d, (double) (short) -1);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement11);
        blockContainer5.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement11);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart8.removeProgressListener(chartProgressListener11);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart8.getLegend((int) (byte) 100);
        double[] doubleArray20 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray24 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray28 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray32 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray33 = new double[][] { doubleArray20, doubleArray24, doubleArray28, doubleArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot37 = categoryAxis3D35.getPlot();
        categoryAxis3D35.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot40 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = polarPlot40.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range43 = polarPlot40.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis42);
        dateAxis42.setAutoTickUnitSelection(true, false);
        java.util.Date date47 = dateAxis42.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D35, (org.jfree.chart.axis.ValueAxis) dateAxis42, categoryItemRenderer48);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D50 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean51 = categoryAxis3D50.isTickLabelsVisible();
        boolean boolean52 = categoryAxis3D50.isVisible();
        int int53 = categoryPlot49.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D50);
        org.jfree.chart.LegendItemCollection legendItemCollection54 = categoryPlot49.getFixedLegendItems();
        double double55 = categoryPlot49.getRangeCrosshairValue();
        java.util.List list56 = categoryPlot49.getAnnotations();
        jFreeChart8.setSubtitles(list56);
        org.jfree.chart.title.LegendTitle legendTitle59 = jFreeChart8.getLegend((int) '4');
        jFreeChart8.setBackgroundImageAlignment((int) (short) 1);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNull(plot37);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNull(range43);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNull(legendItemCollection54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(list56);
        org.junit.Assert.assertNull(legendTitle59);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        xYPlot14.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot14.getDomainAxis((int) (short) 0);
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double19 = range18.getUpperBound();
        valueAxis17.setRange(range18);
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = polarPlot23.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis25 = polarPlot23.getAxis();
        polarPlot23.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("hi!", font22, (org.jfree.chart.plot.Plot) polarPlot23, true);
        org.jfree.chart.title.Title title30 = null;
        jFreeChart29.removeSubtitle(title30);
        org.jfree.chart.title.LegendTitle legendTitle33 = jFreeChart29.getLegend((int) (short) 1);
        jFreeChart29.setTextAntiAlias(false);
        boolean boolean36 = range18.equals((java.lang.Object) jFreeChart29);
        jFreeChart29.clearSubtitles();
        java.awt.image.BufferedImage bufferedImage40 = jFreeChart29.createBufferedImage((int) '4', 15);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(valueAxis17);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertNull(legendTitle33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(bufferedImage40);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        double double3 = ringPlot0.getInnerSeparatorExtension();
        int int4 = ringPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = ringPlot0.getSimpleLabelOffset();
        ringPlot0.setCircular(true, true);
        java.awt.Stroke stroke9 = ringPlot0.getSeparatorStroke();
        ringPlot0.setSectionOutlinesVisible(true);
        java.awt.Font font12 = ringPlot0.getNoDataMessageFont();
        double double13 = ringPlot0.getSectionDepth();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.2d + "'", double13 == 0.2d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        double double4 = ringPlot3.getMaximumExplodePercent();
        ringPlot3.setBackgroundAlpha((float) (-1));
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot3);
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        ringPlot3.setLabelFont(font8);
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("", font8);
        org.jfree.chart.text.TextFragment textFragment11 = textLine10.getLastTextFragment();
        java.awt.Font font12 = textFragment11.getFont();
        boolean boolean14 = textFragment11.equals((java.lang.Object) "http://www.jfree.org/jfreechart/index.html");
        textLine1.removeFragment(textFragment11);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(textFragment11);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        java.lang.String str1 = size2D0.toString();
        double double2 = size2D0.getWidth();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str1.equals("Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        org.jfree.chart.LegendItemCollection legendItemCollection16 = xYPlot14.getLegendItems();
        xYPlot14.mapDatasetToRangeAxis(10, (int) (byte) 1);
        java.awt.Paint paint20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        xYPlot14.setDomainZeroBaselinePaint(paint20);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        try {
            xYPlot14.setDataset((int) (byte) -1, xYDataset23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNotNull(legendItemCollection16);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("Polar Plot");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        boolean boolean7 = textAnchor5.equals((java.lang.Object) (byte) 10);
        java.lang.String str8 = textAnchor5.toString();
        boolean boolean10 = textAnchor5.equals((java.lang.Object) 1.0E-8d);
        try {
            textLine1.draw(graphics2D2, (float) (-1L), (float) 2, textAnchor5, (float) 0, (float) 100, 2.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TextAnchor.BOTTOM_LEFT" + "'", str8.equals("TextAnchor.BOTTOM_LEFT"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (double) 3, (double) (-1), 0.0d);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        double double7 = ringPlot6.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = ringPlot6.getLabelPadding();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = null;
        ringPlot6.setLegendLabelToolTipGenerator(pieSectionLabelGenerator9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = polarPlot15.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis17 = polarPlot15.getAxis();
        polarPlot15.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("hi!", font14, (org.jfree.chart.plot.Plot) polarPlot15, true);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("hi!", font14);
        textTitle22.setPadding((double) (short) 10, (-1.0d), 0.2d, (double) '#');
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle22.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double30 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D28, rectangleEdge29);
        ringPlot6.drawBackgroundImage(graphics2D11, rectangle2D28);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType32 = null;
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.plot.PolarPlot polarPlot34 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = polarPlot34.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis36 = polarPlot34.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot37 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = polarPlot37.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range40 = polarPlot37.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis39);
        polarPlot34.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis39);
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat44 = numberAxis43.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit45 = numberAxis43.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset33, (org.jfree.chart.axis.ValueAxis) dateAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis43, xYItemRenderer46);
        org.jfree.chart.util.Layer layer49 = null;
        java.util.Collection collection50 = xYPlot47.getDomainMarkers(1, layer49);
        org.jfree.chart.plot.ValueMarker valueMarker52 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot47.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker52);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType54 = valueMarker52.getLabelOffsetType();
        java.awt.geom.Rectangle2D rectangle2D55 = rectangleInsets5.createAdjustedRectangle(rectangle2D28, lengthAdjustmentType32, lengthAdjustmentType54);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNull(valueAxis36);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNull(range40);
        org.junit.Assert.assertNull(numberFormat44);
        org.junit.Assert.assertNotNull(numberTickUnit45);
        org.junit.Assert.assertNull(collection50);
        org.junit.Assert.assertNotNull(lengthAdjustmentType54);
        org.junit.Assert.assertNotNull(rectangle2D55);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        polarPlot0.setAxis(valueAxis1);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        polarPlot0.setDataset(xYDataset3);
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        polarPlot0.setRadiusGridlinePaint(paint5);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        boolean boolean9 = polarPlot1.isAngleGridlinesVisible();
        boolean boolean10 = blockBorder0.equals((java.lang.Object) polarPlot1);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        ringPlot13.setIgnoreNullValues(true);
        double double16 = ringPlot13.getInnerSeparatorExtension();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat19 = numberAxis18.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit20 = numberAxis18.getTickUnit();
        ringPlot13.setExplodePercent((java.lang.Comparable) numberTickUnit20, (double) 2);
        numberAxis12.setTickUnit(numberTickUnit20, false, false);
        numberAxis12.setTickMarkInsideLength((float) (byte) 100);
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        numberAxis12.setLabelFont(font28);
        boolean boolean30 = numberAxis12.isTickMarksVisible();
        java.lang.Object obj31 = numberAxis12.clone();
        boolean boolean32 = blockBorder0.equals((java.lang.Object) numberAxis12);
        numberAxis12.setAutoRangeIncludesZero(true);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.2d + "'", double16 == 0.2d);
        org.junit.Assert.assertNull(numberFormat19);
        org.junit.Assert.assertNotNull(numberTickUnit20);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        double double3 = ringPlot0.getOuterSeparatorExtension();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        ringPlot4.setIgnoreNullValues(true);
        java.awt.Stroke stroke7 = ringPlot4.getSeparatorStroke();
        ringPlot0.setLabelLinkStroke(stroke7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = ringPlot0.getDrawingSupplier();
        ringPlot0.setInnerSeparatorExtension((double) (byte) 100);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator12 = ringPlot0.getURLGenerator();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        boolean boolean14 = ringPlot0.equals((java.lang.Object) numberTickUnit13);
        ringPlot0.setStartAngle((double) 1);
        ringPlot0.setCircular(false, false);
        ringPlot0.setCircular(true, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(drawingSupplier9);
        org.junit.Assert.assertNull(pieURLGenerator12);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis2 = polarPlot0.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = polarPlot3.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range6 = polarPlot3.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis5);
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        dateAxis5.setAxisLineStroke(stroke8);
        dateAxis5.setUpperMargin(0.0d);
        dateAxis5.configure();
        dateAxis5.centerRange((double) (byte) 0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers(layer18);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = xYPlot14.getDomainMarkers(layer20);
        xYPlot14.setDomainCrosshairVisible(true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray25 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer24 };
        xYPlot14.setRenderers(xYItemRendererArray25);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(xYItemRendererArray25);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        double[] doubleArray3 = new double[] { 2 };
        double[] doubleArray5 = new double[] { 2 };
        double[] doubleArray7 = new double[] { 2 };
        double[] doubleArray9 = new double[] { 2 };
        double[] doubleArray11 = new double[] { 2 };
        double[] doubleArray13 = new double[] { 2 };
        double[][] doubleArray14 = new double[][] { doubleArray3, doubleArray5, doubleArray7, doubleArray9, doubleArray11, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "hi!", doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range3 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis2);
        dateAxis2.setAutoTickUnitSelection(true, false);
        java.util.Date date7 = dateAxis2.getMaximumDate();
        boolean boolean8 = dateAxis2.isTickMarksVisible();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis2.setAxisLineStroke(stroke9);
        org.jfree.chart.axis.Timeline timeline11 = dateAxis2.getTimeline();
        dateAxis2.zoomRange(1.0E-8d, 0.0d);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D();
        double double18 = categoryAxis3D17.getCategoryMargin();
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = polarPlot24.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis26 = polarPlot24.getAxis();
        polarPlot24.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("hi!", font23, (org.jfree.chart.plot.Plot) polarPlot24, true);
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle("hi!", font23);
        java.awt.geom.Rectangle2D rectangle2D32 = textTitle31.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double34 = categoryAxis3D17.getCategoryStart((int) (short) 10, (int) '4', rectangle2D32, rectangleEdge33);
        org.jfree.chart.entity.ChartEntity chartEntity37 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D32, "Pie Plot", "TextAnchor.BOTTOM_LEFT");
        double[] doubleArray43 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray47 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray51 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray55 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray56 = new double[][] { doubleArray43, doubleArray47, doubleArray51, doubleArray55 };
        org.jfree.data.category.CategoryDataset categoryDataset57 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray56);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D58 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean59 = categoryAxis3D58.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot60 = categoryAxis3D58.getPlot();
        categoryAxis3D58.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot63 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = polarPlot63.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range66 = polarPlot63.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis65);
        dateAxis65.setAutoTickUnitSelection(true, false);
        java.util.Date date70 = dateAxis65.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer71 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot72 = new org.jfree.chart.plot.CategoryPlot(categoryDataset57, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D58, (org.jfree.chart.axis.ValueAxis) dateAxis65, categoryItemRenderer71);
        java.awt.Graphics2D graphics2D73 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D74 = new org.jfree.chart.axis.CategoryAxis3D();
        double double75 = categoryAxis3D74.getCategoryMargin();
        java.awt.Font font80 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot81 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets82 = polarPlot81.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis83 = polarPlot81.getAxis();
        polarPlot81.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart87 = new org.jfree.chart.JFreeChart("hi!", font80, (org.jfree.chart.plot.Plot) polarPlot81, true);
        org.jfree.chart.title.TextTitle textTitle88 = new org.jfree.chart.title.TextTitle("hi!", font80);
        java.awt.geom.Rectangle2D rectangle2D89 = textTitle88.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge90 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double91 = categoryAxis3D74.getCategoryStart((int) (short) 10, (int) '4', rectangle2D89, rectangleEdge90);
        categoryPlot72.drawBackgroundImage(graphics2D73, rectangle2D89);
        org.jfree.chart.util.RectangleEdge rectangleEdge93 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo94 = null;
        try {
            org.jfree.chart.axis.AxisState axisState95 = dateAxis2.draw(graphics2D15, 0.0d, rectangle2D32, rectangle2D89, rectangleEdge93, plotRenderingInfo94);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(timeline11);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.2d + "'", double18 == 0.2d);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(categoryDataset57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNull(plot60);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertNull(range66);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.2d + "'", double75 == 0.2d);
        org.junit.Assert.assertNotNull(font80);
        org.junit.Assert.assertNotNull(rectangleInsets82);
        org.junit.Assert.assertNull(valueAxis83);
        org.junit.Assert.assertNotNull(rectangle2D89);
        org.junit.Assert.assertNotNull(rectangleEdge90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge93);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        int int35 = categoryPlot34.getRangeAxisCount();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray36 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot34.setRangeAxes(valueAxisArray36);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot34.getRangeAxisEdge();
        categoryPlot34.configureRangeAxes();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(valueAxisArray36);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ThreadContext", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange((double) 100);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis6 = polarPlot4.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = polarPlot7.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range10 = polarPlot7.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis9);
        polarPlot4.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat14 = numberAxis13.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = numberAxis13.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = xYPlot17.getRenderer();
        xYPlot17.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot17.getDomainMarkers(layer21);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot17.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        xYPlot17.setRenderer(xYItemRenderer26);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot17);
        xYPlot17.setDomainCrosshairValue(90.0d);
        java.awt.Paint paint31 = xYPlot17.getRangeCrosshairPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        xYPlot17.setRenderer(xYItemRenderer32);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(numberFormat14);
        org.junit.Assert.assertNotNull(numberTickUnit15);
        org.junit.Assert.assertNull(xYItemRenderer18);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isVisible();
        dateAxis0.setNegativeArrowVisible(true);
        java.util.Date date4 = dateAxis0.getMinimumDate();
        org.jfree.data.Range range5 = dateAxis0.getDefaultAutoRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis0.getTickUnit();
        double double7 = dateAxis0.getAutoRangeMinimumSize();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        xYPlot14.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot14.getDomainAxis((int) (short) 0);
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot14.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker19);
        boolean boolean21 = xYPlot14.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisSpace axisSpace22 = xYPlot14.getFixedDomainAxisSpace();
        xYPlot14.setDomainCrosshairValue((double) (short) 1, false);
        org.jfree.chart.axis.ValueAxis valueAxis26 = xYPlot14.getDomainAxis();
        java.lang.Object obj27 = xYPlot14.clone();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(valueAxis17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(axisSpace22);
        org.junit.Assert.assertNotNull(valueAxis26);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range3 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.awt.Paint paint4 = polarPlot0.getAngleLabelPaint();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart8.removeProgressListener(chartProgressListener11);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart8.getLegend((int) (byte) 100);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart8.getLegend();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = legendTitle15.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = legendTitle15.getLegendItemGraphicAnchor();
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_GREEN;
        legendTitle15.setItemPaint((java.awt.Paint) color18);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertNotNull(legendTitle15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setInfo("hi!");
        double[] doubleArray8 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray12 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray16 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray20 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray21 = new double[][] { doubleArray8, doubleArray12, doubleArray16, doubleArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray21);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D23 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean24 = categoryAxis3D23.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot25 = categoryAxis3D23.getPlot();
        categoryAxis3D23.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = polarPlot28.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range31 = polarPlot28.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis30);
        dateAxis30.setAutoTickUnitSelection(true, false);
        java.util.Date date35 = dateAxis30.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D23, (org.jfree.chart.axis.ValueAxis) dateAxis30, categoryItemRenderer36);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D38 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean39 = categoryAxis3D38.isTickLabelsVisible();
        boolean boolean40 = categoryAxis3D38.isVisible();
        int int41 = categoryPlot37.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D38);
        org.jfree.chart.LegendItemCollection legendItemCollection42 = categoryPlot37.getFixedLegendItems();
        double double43 = categoryPlot37.getRangeCrosshairValue();
        java.util.List list44 = categoryPlot37.getAnnotations();
        categoryPlot37.clearRangeMarkers((int) (byte) 100);
        boolean boolean47 = projectInfo0.equals((java.lang.Object) categoryPlot37);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNull(range31);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNull(legendItemCollection42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        double double3 = ringPlot0.getInnerSeparatorExtension();
        int int4 = ringPlot0.getBackgroundImageAlignment();
        org.jfree.data.general.PieDataset pieDataset5 = ringPlot0.getDataset();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = ringPlot0.getLegendLabelGenerator();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(pieDataset5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        ringPlot1.setIgnoreNullValues(true);
        double double4 = ringPlot1.getInnerSeparatorExtension();
        ringPlot1.setOuterSeparatorExtension(0.0d);
        org.jfree.chart.util.Rotation rotation7 = ringPlot1.getDirection();
        java.lang.Object obj8 = ringPlot1.clone();
        boolean boolean9 = lineBorder0.equals((java.lang.Object) ringPlot1);
        java.awt.Stroke stroke10 = null;
        try {
            ringPlot1.setBaseSectionOutlineStroke(stroke10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = numberAxis1.getTickUnit();
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        double double6 = ringPlot5.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = ringPlot5.getLabelPadding();
        java.lang.Object obj8 = ringPlot5.clone();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        ringPlot5.handleClick(15, 15, plotRenderingInfo11);
        java.awt.Paint paint13 = ringPlot5.getBaseSectionOutlinePaint();
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) ringPlot5);
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        int int35 = categoryPlot34.getRangeAxisCount();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray36 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot34.setRangeAxes(valueAxisArray36);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot34.getRangeAxisEdge();
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis();
        java.lang.String str41 = numberAxis40.getLabel();
        categoryPlot34.setRangeAxis((int) (byte) 0, (org.jfree.chart.axis.ValueAxis) numberAxis40);
        categoryPlot34.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(valueAxisArray36);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNull(str41);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        categoryPlot34.setFixedDomainAxisSpace(axisSpace35);
        categoryPlot34.setWeight((int) '4');
        categoryPlot34.clearAnnotations();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        int int41 = categoryPlot34.getIndexOf(categoryItemRenderer40);
        categoryPlot34.zoom((double) (byte) 0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        xYPlot14.clearRangeMarkers();
        java.awt.Font font16 = xYPlot14.getNoDataMessageFont();
        java.awt.Stroke stroke17 = xYPlot14.getDomainGridlineStroke();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = xYPlot14.getRenderer();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(xYItemRenderer18);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        categoryPlot34.setFixedDomainAxisSpace(axisSpace35);
        categoryPlot34.setWeight((int) '4');
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D39 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D39.setCategoryMargin((double) (short) -1);
        org.jfree.chart.plot.RingPlot ringPlot42 = new org.jfree.chart.plot.RingPlot();
        double double43 = ringPlot42.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = ringPlot42.getLabelPadding();
        java.lang.Object obj45 = ringPlot42.clone();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        ringPlot42.handleClick(15, 15, plotRenderingInfo48);
        ringPlot42.setForegroundAlpha(0.0f);
        java.awt.Paint paint52 = ringPlot42.getLabelOutlinePaint();
        categoryAxis3D39.setTickLabelPaint(paint52);
        java.util.List list54 = categoryPlot34.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D39);
        org.jfree.chart.axis.ValueAxis valueAxis55 = categoryPlot34.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace56 = null;
        categoryPlot34.setFixedDomainAxisSpace(axisSpace56);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer59 = categoryPlot34.getRenderer((int) (short) -1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(list54);
        org.junit.Assert.assertNotNull(valueAxis55);
        org.junit.Assert.assertNull(categoryItemRenderer59);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        double double3 = ringPlot0.getInnerSeparatorExtension();
        int int4 = ringPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = ringPlot0.getSimpleLabelOffset();
        java.awt.Paint paint6 = ringPlot0.getLabelShadowPaint();
        boolean boolean7 = ringPlot0.isCircular();
        java.awt.Stroke stroke9 = ringPlot0.getSectionOutlineStroke((java.lang.Comparable) (-7.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(stroke9);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        java.lang.Number number35 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset19);
        org.jfree.data.Range range37 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset19, false);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset19);
        org.jfree.data.Range range41 = org.jfree.data.Range.expand(range38, (double) (short) 100, (double) 10L);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + (-1.0d) + "'", number35.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(range41);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent39 = null;
        categoryPlot34.datasetChanged(datasetChangeEvent39);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        java.awt.geom.Point2D point2D44 = null;
        categoryPlot34.zoomRangeAxes((double) 0.8f, 0.0d, plotRenderingInfo43, point2D44);
        categoryPlot34.setWeight((int) 'a');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange((double) 100);
        double double3 = dateAxis0.getFixedAutoRange();
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis0.setUpArrow(shape4);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.awt.Shape shape7 = chartEntity6.getArea();
        chartEntity6.setURLText("Size2D[width=0.0, height=0.0]");
        java.lang.String str10 = chartEntity6.toString();
        java.lang.String str11 = chartEntity6.getShapeCoords();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ChartEntity: tooltip = null" + "'", str10.equals("ChartEntity: tooltip = null"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-4,-4,4,4" + "'", str11.equals("-4,-4,4,4"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint1 = piePlot3D0.getLabelOutlinePaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo1);
        projectInfo1.addOptionalLibrary("");
        projectInfo1.setInfo("");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        ringPlot1.setIgnoreNullValues(true);
        double double4 = ringPlot1.getInnerSeparatorExtension();
        ringPlot1.setOuterSeparatorExtension(0.0d);
        org.jfree.chart.util.Rotation rotation7 = ringPlot1.getDirection();
        java.lang.Object obj8 = ringPlot1.clone();
        boolean boolean9 = lineBorder0.equals((java.lang.Object) ringPlot1);
        java.awt.Paint paint10 = ringPlot1.getLabelOutlinePaint();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.getIgnoreZeroValues();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = piePlot1.getLegendItems();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(legendItemCollection3);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        org.jfree.chart.LegendItemCollection legendItemCollection39 = categoryPlot34.getFixedLegendItems();
        double double40 = categoryPlot34.getRangeCrosshairValue();
        java.util.List list41 = categoryPlot34.getAnnotations();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder42 = categoryPlot34.getDatasetRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis43 = categoryPlot34.getRangeAxis();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNull(legendItemCollection39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertNotNull(datasetRenderingOrder42);
        org.junit.Assert.assertNotNull(valueAxis43);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        ringPlot0.setShadowYOffset((double) 100.0f);
        java.awt.Color color5 = java.awt.Color.red;
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        org.jfree.chart.LegendItemCollection legendItemCollection39 = categoryPlot34.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot34.getRangeAxisEdge((int) '4');
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D42 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean43 = categoryAxis3D42.isTickLabelsVisible();
        java.lang.Object obj44 = categoryAxis3D42.clone();
        java.awt.Font font46 = categoryAxis3D42.getTickLabelFont((java.lang.Comparable) 1.0d);
        boolean boolean47 = categoryAxis3D42.isTickMarksVisible();
        java.util.List list48 = categoryPlot34.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D42);
        boolean boolean49 = categoryPlot34.isRangeGridlinesVisible();
        java.awt.Paint paint50 = categoryPlot34.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNull(legendItemCollection39);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(list48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(paint50);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        java.lang.Object obj3 = ringPlot0.clone();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        ringPlot0.handleClick(15, 15, plotRenderingInfo6);
        ringPlot0.setForegroundAlpha(0.0f);
        double double10 = ringPlot0.getLabelGap();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = null;
        ringPlot0.setURLGenerator(pieURLGenerator11);
        boolean boolean13 = ringPlot0.getIgnoreNullValues();
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = polarPlot16.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis18 = polarPlot16.getAxis();
        polarPlot16.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("hi!", font15, (org.jfree.chart.plot.Plot) polarPlot16, true);
        org.jfree.chart.title.Title title23 = null;
        jFreeChart22.removeSubtitle(title23);
        org.jfree.chart.event.ChartProgressListener chartProgressListener25 = null;
        jFreeChart22.removeProgressListener(chartProgressListener25);
        int int27 = jFreeChart22.getSubtitleCount();
        java.awt.Stroke stroke28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        jFreeChart22.setBorderStroke(stroke28);
        ringPlot0.setBaseSectionOutlineStroke(stroke28);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.025d + "'", double10 == 0.025d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = polarPlot3.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis5 = polarPlot3.getAxis();
        polarPlot3.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", font2, (org.jfree.chart.plot.Plot) polarPlot3, true);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!", font2);
        java.awt.geom.Rectangle2D rectangle2D11 = textTitle10.getBounds();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textTitle10.setTextAlignment(horizontalAlignment12);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = polarPlot15.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis17 = polarPlot15.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = polarPlot18.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range21 = polarPlot18.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis20);
        polarPlot15.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat25 = numberAxis24.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit26 = numberAxis24.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis24, xYItemRenderer27);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = xYPlot28.getRenderer();
        xYPlot28.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer32 = null;
        java.util.Collection collection33 = xYPlot28.getDomainMarkers(layer32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = null;
        xYPlot28.setDomainAxisLocation(15, axisLocation35, false);
        xYPlot28.setDomainCrosshairVisible(true);
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        int int41 = xYPlot28.indexOf(xYDataset40);
        boolean boolean42 = horizontalAlignment12.equals((java.lang.Object) xYPlot28);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNull(numberFormat25);
        org.junit.Assert.assertNotNull(numberTickUnit26);
        org.junit.Assert.assertNull(xYItemRenderer29);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers(layer18);
        boolean boolean20 = xYPlot14.isRangeZoomable();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        double double23 = categoryAxis22.getUpperMargin();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D26 = new org.jfree.chart.axis.CategoryAxis3D();
        double double27 = categoryAxis3D26.getCategoryMargin();
        java.awt.Font font32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot33 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = polarPlot33.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis35 = polarPlot33.getAxis();
        polarPlot33.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart39 = new org.jfree.chart.JFreeChart("hi!", font32, (org.jfree.chart.plot.Plot) polarPlot33, true);
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("hi!", font32);
        java.awt.geom.Rectangle2D rectangle2D41 = textTitle40.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double43 = categoryAxis3D26.getCategoryStart((int) (short) 10, (int) '4', rectangle2D41, rectangleEdge42);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double45 = categoryAxis22.getCategoryEnd(15, (int) '4', rectangle2D41, rectangleEdge44);
        java.awt.geom.Point2D point2D46 = null;
        org.jfree.chart.plot.PlotState plotState47 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        xYPlot14.draw(graphics2D21, rectangle2D41, point2D46, plotState47, plotRenderingInfo48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        xYPlot14.setRenderer(3, xYItemRenderer51, true);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.05d + "'", double23 == 0.05d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.2d + "'", double27 == 0.2d);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNull(valueAxis35);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getMaximumExplodePercent();
        ringPlot1.setBackgroundAlpha((float) (-1));
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot1);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        ringPlot1.setLabelFont(font6);
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font6);
        org.jfree.chart.text.TextFragment textFragment9 = textLine8.getLastTextFragment();
        java.lang.String str10 = textFragment9.getText();
        java.lang.String str11 = textFragment9.getText();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(textFragment9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.setCategoryMargin((double) (short) -1);
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        double double4 = ringPlot3.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = ringPlot3.getLabelPadding();
        java.lang.Object obj6 = ringPlot3.clone();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        ringPlot3.handleClick(15, 15, plotRenderingInfo9);
        ringPlot3.setForegroundAlpha(0.0f);
        java.awt.Paint paint13 = ringPlot3.getLabelOutlinePaint();
        categoryAxis3D0.setTickLabelPaint(paint13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.Plot plot16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        double[] doubleArray23 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray27 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray31 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray35 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray36 = new double[][] { doubleArray23, doubleArray27, doubleArray31, doubleArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray36);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D38 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean39 = categoryAxis3D38.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot40 = categoryAxis3D38.getPlot();
        categoryAxis3D38.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot43 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = polarPlot43.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range46 = polarPlot43.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis45);
        dateAxis45.setAutoTickUnitSelection(true, false);
        java.util.Date date50 = dateAxis45.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D38, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer51);
        categoryAxis3D38.setUpperMargin((double) 0);
        categoryAxis3D38.clearCategoryLabelToolTips();
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = new org.jfree.chart.axis.CategoryAxis();
        double double59 = categoryAxis58.getUpperMargin();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D62 = new org.jfree.chart.axis.CategoryAxis3D();
        double double63 = categoryAxis3D62.getCategoryMargin();
        java.awt.Font font68 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot69 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = polarPlot69.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis71 = polarPlot69.getAxis();
        polarPlot69.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart75 = new org.jfree.chart.JFreeChart("hi!", font68, (org.jfree.chart.plot.Plot) polarPlot69, true);
        org.jfree.chart.title.TextTitle textTitle76 = new org.jfree.chart.title.TextTitle("hi!", font68);
        java.awt.geom.Rectangle2D rectangle2D77 = textTitle76.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge78 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double79 = categoryAxis3D62.getCategoryStart((int) (short) 10, (int) '4', rectangle2D77, rectangleEdge78);
        org.jfree.chart.util.RectangleEdge rectangleEdge80 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double81 = categoryAxis58.getCategoryEnd(15, (int) '4', rectangle2D77, rectangleEdge80);
        org.jfree.chart.util.RectangleEdge rectangleEdge82 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean84 = rectangleEdge82.equals((java.lang.Object) 10L);
        double double85 = categoryAxis3D38.getCategoryMiddle((int) (byte) 10, (int) (byte) 10, rectangle2D77, rectangleEdge82);
        org.jfree.chart.axis.AxisSpace axisSpace86 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace87 = categoryAxis3D0.reserveSpace(graphics2D15, plot16, rectangle2D17, rectangleEdge82, axisSpace86);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNull(plot40);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.05d + "'", double59 == 0.05d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.2d + "'", double63 == 0.2d);
        org.junit.Assert.assertNotNull(font68);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertNull(valueAxis71);
        org.junit.Assert.assertNotNull(rectangle2D77);
        org.junit.Assert.assertNotNull(rectangleEdge78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart8.removeProgressListener(chartProgressListener11);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart8.getLegend((int) (byte) 100);
        double[] doubleArray20 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray24 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray28 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray32 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray33 = new double[][] { doubleArray20, doubleArray24, doubleArray28, doubleArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot37 = categoryAxis3D35.getPlot();
        categoryAxis3D35.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot40 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = polarPlot40.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range43 = polarPlot40.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis42);
        dateAxis42.setAutoTickUnitSelection(true, false);
        java.util.Date date47 = dateAxis42.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D35, (org.jfree.chart.axis.ValueAxis) dateAxis42, categoryItemRenderer48);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D50 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean51 = categoryAxis3D50.isTickLabelsVisible();
        boolean boolean52 = categoryAxis3D50.isVisible();
        int int53 = categoryPlot49.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D50);
        org.jfree.chart.LegendItemCollection legendItemCollection54 = categoryPlot49.getFixedLegendItems();
        double double55 = categoryPlot49.getRangeCrosshairValue();
        java.util.List list56 = categoryPlot49.getAnnotations();
        jFreeChart8.setSubtitles(list56);
        org.jfree.chart.title.LegendTitle legendTitle59 = jFreeChart8.getLegend((int) '4');
        org.jfree.chart.plot.Plot plot60 = jFreeChart8.getPlot();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNull(plot37);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNull(range43);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNull(legendItemCollection54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(list56);
        org.junit.Assert.assertNull(legendTitle59);
        org.junit.Assert.assertNotNull(plot60);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        categoryPlot34.setFixedDomainAxisSpace(axisSpace35);
        categoryPlot34.setWeight((int) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        categoryPlot34.setRenderer(1, categoryItemRenderer40);
        categoryPlot34.clearDomainMarkers();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 'a', (float) (byte) 0, (float) '#');
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        double double3 = ringPlot2.getMaximumExplodePercent();
        ringPlot2.setBackgroundAlpha((float) (-1));
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot2);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        ringPlot2.setLabelFont(font7);
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("", font7);
        org.jfree.chart.text.TextFragment textFragment10 = textLine9.getLastTextFragment();
        java.awt.Font font11 = textFragment10.getFont();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer15 = new org.jfree.chart.text.G2TextMeasurer(graphics2D14);
        try {
            org.jfree.chart.text.TextBlock textBlock16 = org.jfree.chart.text.TextUtilities.createTextBlock("Polar Plot", font11, (java.awt.Paint) color12, (float) (-1), (org.jfree.chart.text.TextMeasurer) g2TextMeasurer15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(textFragment10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        double double3 = ringPlot0.getInnerSeparatorExtension();
        ringPlot0.setOuterSeparatorExtension(0.0d);
        org.jfree.chart.util.Rotation rotation6 = ringPlot0.getDirection();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = polarPlot8.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis10 = polarPlot8.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = polarPlot11.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range14 = polarPlot11.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis13);
        polarPlot8.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat18 = numberAxis17.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit19 = numberAxis17.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis17, xYItemRenderer20);
        xYPlot21.clearRangeMarkers();
        boolean boolean23 = rotation6.equals((java.lang.Object) xYPlot21);
        java.awt.Stroke stroke24 = xYPlot21.getDomainCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot21.setDataset(1, xYDataset26);
        org.jfree.chart.text.TextBlock textBlock28 = new org.jfree.chart.text.TextBlock();
        java.util.List list29 = textBlock28.getLines();
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        float float32 = valueMarker31.getAlpha();
        java.lang.Object obj33 = valueMarker31.clone();
        boolean boolean34 = textBlock28.equals((java.lang.Object) valueMarker31);
        org.jfree.chart.util.Layer layer35 = null;
        try {
            boolean boolean36 = xYPlot21.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker31, layer35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(rotation6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(numberFormat18);
        org.junit.Assert.assertNotNull(numberTickUnit19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 0.8f + "'", float32 == 0.8f);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers(layer18);
        boolean boolean20 = xYPlot14.isRangeZoomable();
        boolean boolean21 = xYPlot14.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D23 = new org.jfree.chart.axis.CategoryAxis3D("TextAnchor.BOTTOM_LEFT");
        boolean boolean24 = xYPlot14.equals((java.lang.Object) "TextAnchor.BOTTOM_LEFT");
        xYPlot14.configureDomainAxes();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = piePlot3D1.getSimpleLabelOffset();
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isRangeGridlinesVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        int int17 = xYPlot14.getIndexOf(xYItemRenderer16);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot14.getDomainAxisEdge(100);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = xYPlot14.getLegendItems();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(legendItemCollection20);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers(layer18);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot14.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        xYPlot14.setRenderer(xYItemRenderer23);
        boolean boolean25 = xYPlot14.isDomainCrosshairLockedOnData();
        boolean boolean26 = xYPlot14.isSubplot();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.setAutoRangeIncludesZero(true);
        numberAxis1.setFixedDimension((-3.0d));
        java.awt.Shape shape6 = numberAxis1.getRightArrow();
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        org.jfree.chart.LegendItemCollection legendItemCollection39 = categoryPlot34.getFixedLegendItems();
        double double40 = categoryPlot34.getRangeCrosshairValue();
        java.util.List list41 = categoryPlot34.getAnnotations();
        int int42 = categoryPlot34.getWeight();
        java.awt.Font font44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot45 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = polarPlot45.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis47 = polarPlot45.getAxis();
        polarPlot45.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart51 = new org.jfree.chart.JFreeChart("hi!", font44, (org.jfree.chart.plot.Plot) polarPlot45, true);
        org.jfree.chart.title.Title title52 = null;
        jFreeChart51.removeSubtitle(title52);
        org.jfree.chart.event.ChartProgressListener chartProgressListener54 = null;
        jFreeChart51.removeProgressListener(chartProgressListener54);
        org.jfree.chart.title.LegendTitle legendTitle57 = jFreeChart51.getLegend((int) (byte) 100);
        org.jfree.chart.title.LegendTitle legendTitle58 = jFreeChart51.getLegend();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor59 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle58.setLegendItemGraphicLocation(rectangleAnchor59);
        java.awt.Color color61 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        legendTitle58.setItemPaint((java.awt.Paint) color61);
        categoryPlot34.setDomainGridlinePaint((java.awt.Paint) color61);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNull(legendItemCollection39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNull(valueAxis47);
        org.junit.Assert.assertNull(legendTitle57);
        org.junit.Assert.assertNotNull(legendTitle58);
        org.junit.Assert.assertNotNull(rectangleAnchor59);
        org.junit.Assert.assertNotNull(color61);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        double double3 = ringPlot0.getInnerSeparatorExtension();
        int int4 = ringPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = ringPlot0.getSimpleLabelOffset();
        ringPlot0.setCircular(false);
        double double8 = ringPlot0.getInnerSeparatorExtension();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isRangeGridlinesVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        int int17 = xYPlot14.getIndexOf(xYItemRenderer16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = xYPlot14.getRenderer((int) (byte) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot14.zoomDomainAxes((double) 10, (double) (byte) 10, plotRenderingInfo22, point2D23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.RingPlot ringPlot26 = new org.jfree.chart.plot.RingPlot();
        ringPlot26.setIgnoreNullValues(true);
        java.awt.Stroke stroke29 = ringPlot26.getSeparatorStroke();
        double double30 = ringPlot26.getMinimumArcAngleToDraw();
        double double31 = ringPlot26.getSectionDepth();
        ringPlot26.setForegroundAlpha(0.5f);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis();
        double double36 = categoryAxis35.getUpperMargin();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D39 = new org.jfree.chart.axis.CategoryAxis3D();
        double double40 = categoryAxis3D39.getCategoryMargin();
        java.awt.Font font45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot46 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = polarPlot46.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis48 = polarPlot46.getAxis();
        polarPlot46.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart52 = new org.jfree.chart.JFreeChart("hi!", font45, (org.jfree.chart.plot.Plot) polarPlot46, true);
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("hi!", font45);
        java.awt.geom.Rectangle2D rectangle2D54 = textTitle53.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double56 = categoryAxis3D39.getCategoryStart((int) (short) 10, (int) '4', rectangle2D54, rectangleEdge55);
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double58 = categoryAxis35.getCategoryEnd(15, (int) '4', rectangle2D54, rectangleEdge57);
        ringPlot26.drawBackgroundImage(graphics2D34, rectangle2D54);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = null;
        xYPlot14.drawAnnotations(graphics2D25, rectangle2D54, plotRenderingInfo60);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation62 = null;
        try {
            boolean boolean63 = xYPlot14.removeAnnotation(xYAnnotation62);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(xYItemRenderer19);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0E-5d + "'", double30 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.2d + "'", double31 == 0.2d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.2d + "'", double40 == 0.2d);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNull(valueAxis48);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        categoryPlot34.setFixedDomainAxisSpace(axisSpace35);
        categoryPlot34.setWeight((int) '4');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        java.awt.geom.Point2D point2D41 = null;
        categoryPlot34.zoomDomainAxes(0.0d, plotRenderingInfo40, point2D41, false);
        categoryPlot34.setAnchorValue((double) 10);
        int int46 = categoryPlot34.getDomainAxisCount();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        xYPlot14.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot14.getDomainAxis((int) (short) 0);
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double19 = range18.getUpperBound();
        valueAxis17.setRange(range18);
        org.jfree.chart.text.TextBlock textBlock21 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor25 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.awt.Shape shape29 = textBlock21.calculateBounds(graphics2D22, (float) (short) 0, 0.0f, textBlockAnchor25, (float) 2, (float) 1, 0.05d);
        valueAxis17.setDownArrow(shape29);
        java.awt.Shape shape31 = valueAxis17.getUpArrow();
        org.jfree.chart.entity.ChartEntity chartEntity34 = new org.jfree.chart.entity.ChartEntity(shape31, "Size2D[width=0.0, height=1.0]", "http://www.jfree.org/jfreechart/index.html");
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(valueAxis17);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(textBlockAnchor25);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(shape31);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getDepthFactor();
        double double2 = piePlot3D0.getDepthFactor();
        double[] doubleArray8 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray12 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray16 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray20 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray21 = new double[][] { doubleArray8, doubleArray12, doubleArray16, doubleArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray21);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D23 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean24 = categoryAxis3D23.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot25 = categoryAxis3D23.getPlot();
        categoryAxis3D23.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = polarPlot28.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range31 = polarPlot28.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis30);
        dateAxis30.setAutoTickUnitSelection(true, false);
        java.util.Date date35 = dateAxis30.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D23, (org.jfree.chart.axis.ValueAxis) dateAxis30, categoryItemRenderer36);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D38 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean39 = categoryAxis3D38.isTickLabelsVisible();
        boolean boolean40 = categoryAxis3D38.isVisible();
        int int41 = categoryPlot37.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D38);
        org.jfree.chart.LegendItemCollection legendItemCollection42 = categoryPlot37.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot37.getRangeAxisEdge((int) '4');
        categoryPlot37.clearRangeMarkers();
        int int46 = categoryPlot37.getWeight();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        java.awt.geom.Point2D point2D49 = null;
        categoryPlot37.zoomDomainAxes((double) 100L, plotRenderingInfo48, point2D49, true);
        boolean boolean52 = piePlot3D0.equals((java.lang.Object) categoryPlot37);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12d + "'", double1 == 0.12d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.12d + "'", double2 == 0.12d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNull(range31);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNull(legendItemCollection42);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis2 = polarPlot0.getAxis();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        polarPlot0.drawBackgroundImage(graphics2D3, rectangle2D4);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        polarPlot0.setRenderer(polarItemRenderer6);
        java.awt.Paint paint8 = polarPlot0.getOutlinePaint();
        polarPlot0.setAngleLabelsVisible(false);
        polarPlot0.setAngleLabelsVisible(true);
        org.jfree.chart.axis.TickUnit tickUnit13 = polarPlot0.getAngleTickUnit();
        java.awt.Paint paint14 = polarPlot0.getAngleGridlinePaint();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D();
        double double17 = categoryAxis3D16.getCategoryMargin();
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = polarPlot23.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis25 = polarPlot23.getAxis();
        polarPlot23.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("hi!", font22, (org.jfree.chart.plot.Plot) polarPlot23, true);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("hi!", font22);
        java.awt.geom.Rectangle2D rectangle2D31 = textTitle30.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double33 = categoryAxis3D16.getCategoryStart((int) (short) 10, (int) '4', rectangle2D31, rectangleEdge32);
        org.jfree.chart.entity.ChartEntity chartEntity36 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D31, "Pie Plot", "TextAnchor.BOTTOM_LEFT");
        java.awt.geom.Point2D point2D37 = null;
        org.jfree.chart.plot.PlotState plotState38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        polarPlot0.draw(graphics2D15, rectangle2D31, point2D37, plotState38, plotRenderingInfo39);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(tickUnit13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        double double3 = ringPlot0.getInnerSeparatorExtension();
        ringPlot0.setOuterSeparatorExtension(0.0d);
        org.jfree.chart.util.Rotation rotation6 = ringPlot0.getDirection();
        ringPlot0.setSectionDepth(0.05d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = ringPlot0.getLegendLabelGenerator();
        ringPlot0.setSimpleLabels(false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(rotation6);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color1 = java.awt.Color.BLUE;
        categoryAxis3D0.setTickLabelPaint((java.awt.Paint) color1);
        java.lang.Object obj3 = categoryAxis3D0.clone();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(10);
        java.lang.Object obj2 = objectList1.clone();
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        boolean boolean4 = objectList1.equals((java.lang.Object) textAnchor3);
        java.lang.Object obj5 = objectList1.clone();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        categoryPlot34.setFixedDomainAxisSpace(axisSpace35);
        categoryPlot34.setWeight((int) '4');
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D39 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D39.setCategoryMargin((double) (short) -1);
        org.jfree.chart.plot.RingPlot ringPlot42 = new org.jfree.chart.plot.RingPlot();
        double double43 = ringPlot42.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = ringPlot42.getLabelPadding();
        java.lang.Object obj45 = ringPlot42.clone();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        ringPlot42.handleClick(15, 15, plotRenderingInfo48);
        ringPlot42.setForegroundAlpha(0.0f);
        java.awt.Paint paint52 = ringPlot42.getLabelOutlinePaint();
        categoryAxis3D39.setTickLabelPaint(paint52);
        java.util.List list54 = categoryPlot34.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D39);
        org.jfree.chart.axis.ValueAxis valueAxis55 = categoryPlot34.getRangeAxis();
        valueAxis55.setLabelAngle(0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(list54);
        org.junit.Assert.assertNotNull(valueAxis55);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.awt.Color color1 = java.awt.Color.getColor("-4,-4,4,4");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, (double) (short) -1);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = polarPlot9.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis11 = polarPlot9.getAxis();
        polarPlot9.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("hi!", font8, (org.jfree.chart.plot.Plot) polarPlot9, true);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("hi!", font8);
        textTitle16.setPadding((double) (short) 10, (-1.0d), 0.2d, (double) '#');
        textTitle16.setMargin((double) '4', 0.0d, (double) (short) 1, 0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.LEFT;
        textTitle16.setPosition(rectangleEdge27);
        textTitle16.setPadding((double) (byte) -1, (double) 10L, (double) 1L, (double) (short) 100);
        java.lang.Object obj34 = null;
        flowArrangement4.add((org.jfree.chart.block.Block) textTitle16, obj34);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        xYPlot14.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot14.getDomainAxis((int) (short) 0);
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double19 = range18.getUpperBound();
        valueAxis17.setRange(range18);
        org.jfree.data.Range range21 = valueAxis17.getDefaultAutoRange();
        org.jfree.data.Range range23 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range26 = org.jfree.data.Range.shift(range23, (double) 10, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 10, range23);
        org.jfree.data.Range range29 = org.jfree.data.Range.shift(range23, (double) 1.0f);
        org.jfree.data.Range range30 = org.jfree.data.Range.combine(range21, range29);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(valueAxis17);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(range30);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setPieCenterX((double) 0);
        piePlotState1.setPieHRadius((-1.0d));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis2 = polarPlot0.getAxis();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        polarPlot0.drawBackgroundImage(graphics2D3, rectangle2D4);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        polarPlot0.setRenderer(polarItemRenderer6);
        java.awt.Paint paint8 = polarPlot0.getRadiusGridlinePaint();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setPieCenterX((double) 0);
        piePlotState1.setPieWRadius((double) 10.0f);
        double double6 = piePlotState1.getPieCenterX();
        piePlotState1.setPassesRequired((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis2 = polarPlot0.getAxis();
        polarPlot0.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = polarPlot5.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range8 = polarPlot5.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis7);
        dateAxis7.setAutoTickUnitSelection(true, false);
        java.util.Date date12 = dateAxis7.getMaximumDate();
        boolean boolean13 = dateAxis7.isTickMarksVisible();
        java.lang.String str14 = dateAxis7.getLabel();
        java.lang.String str15 = dateAxis7.getLabelToolTip();
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset19);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(range35);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange((double) 100);
        double double3 = dateAxis0.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = polarPlot5.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis7 = polarPlot5.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = polarPlot8.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range11 = polarPlot8.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis10);
        polarPlot5.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis10);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat15 = numberAxis14.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = numberAxis14.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis14, xYItemRenderer17);
        org.jfree.data.Range range19 = dateAxis10.getRange();
        dateAxis0.setRange(range19);
        org.jfree.chart.axis.DateTickUnit dateTickUnit21 = null;
        dateAxis0.setTickUnit(dateTickUnit21, true, false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNotNull(numberTickUnit16);
        org.junit.Assert.assertNotNull(range19);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        double double3 = ringPlot0.getInnerSeparatorExtension();
        ringPlot0.setOuterSeparatorExtension(0.0d);
        org.jfree.chart.util.Rotation rotation6 = ringPlot0.getDirection();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = ringPlot0.getToolTipGenerator();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(rotation6);
        org.junit.Assert.assertNull(pieToolTipGenerator7);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Color color1 = java.awt.Color.BLUE;
        categoryAxis3D0.setTickLabelPaint((java.awt.Paint) color1);
        java.awt.Paint paint3 = categoryAxis3D0.getTickLabelPaint();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        polarPlot4.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) numberTickUnit6, (java.awt.Paint) color8);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(numberTickUnit6);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        categoryPlot34.setFixedDomainAxisSpace(axisSpace35);
        categoryPlot34.setWeight((int) '4');
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D39 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean40 = categoryAxis3D39.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot41 = categoryAxis3D39.getPlot();
        float float42 = categoryAxis3D39.getTickMarkOutsideLength();
        categoryPlot34.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D39);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(plot41);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 2.0f + "'", float42 == 2.0f);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        boolean boolean15 = xYPlot14.isRangeGridlinesVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        int int17 = xYPlot14.getIndexOf(xYItemRenderer16);
        xYPlot14.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = null;
        xYPlot14.rendererChanged(rendererChangeEvent20);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart8.removeProgressListener(chartProgressListener11);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart8.getLegend((int) (byte) 100);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart8.getLegend();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray16 = legendTitle15.getSources();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        legendTitle15.setLegendItemGraphicLocation(rectangleAnchor17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle15.getItemLabelPadding();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.plot.PolarPlot polarPlot22 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = polarPlot22.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis24 = polarPlot22.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        polarPlot22.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis27);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat32 = numberAxis31.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit33 = numberAxis31.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) dateAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis31, xYItemRenderer34);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = xYPlot35.getRenderer();
        org.jfree.chart.plot.RingPlot ringPlot37 = new org.jfree.chart.plot.RingPlot();
        double double38 = ringPlot37.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = ringPlot37.getLabelPadding();
        double double40 = rectangleInsets39.getRight();
        double double42 = rectangleInsets39.trimHeight((double) (byte) 1);
        xYPlot35.setInsets(rectangleInsets39);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis();
        double double45 = categoryAxis44.getUpperMargin();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D48 = new org.jfree.chart.axis.CategoryAxis3D();
        double double49 = categoryAxis3D48.getCategoryMargin();
        java.awt.Font font54 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot55 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = polarPlot55.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis57 = polarPlot55.getAxis();
        polarPlot55.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart61 = new org.jfree.chart.JFreeChart("hi!", font54, (org.jfree.chart.plot.Plot) polarPlot55, true);
        org.jfree.chart.title.TextTitle textTitle62 = new org.jfree.chart.title.TextTitle("hi!", font54);
        java.awt.geom.Rectangle2D rectangle2D63 = textTitle62.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double65 = categoryAxis3D48.getCategoryStart((int) (short) 10, (int) '4', rectangle2D63, rectangleEdge64);
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double67 = categoryAxis44.getCategoryEnd(15, (int) '4', rectangle2D63, rectangleEdge66);
        java.awt.geom.Rectangle2D rectangle2D70 = rectangleInsets39.createInsetRectangle(rectangle2D63, true, false);
        try {
            legendTitle15.draw(graphics2D20, rectangle2D63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertNotNull(legendTitle15);
        org.junit.Assert.assertNotNull(legendItemSourceArray16);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNull(numberFormat32);
        org.junit.Assert.assertNotNull(numberTickUnit33);
        org.junit.Assert.assertNull(xYItemRenderer36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 2.0d + "'", double40 == 2.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + (-3.0d) + "'", double42 == (-3.0d));
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.05d + "'", double45 == 0.05d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.2d + "'", double49 == 0.2d);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertNull(valueAxis57);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D70);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        org.jfree.chart.LegendItemCollection legendItemCollection39 = categoryPlot34.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot34.getRangeAxisEdge((int) '4');
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean44 = categoryPlot34.equals((java.lang.Object) numberAxis43);
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = categoryPlot34.getRendererForDataset(categoryDataset45);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        java.awt.geom.Point2D point2D50 = null;
        categoryPlot34.zoomRangeAxes(1.0E-5d, 10.0d, plotRenderingInfo49, point2D50);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = categoryPlot34.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation53 = categoryPlot34.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNull(legendItemCollection39);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(categoryItemRenderer46);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(axisLocation53);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers(layer18);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        xYPlot14.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        xYPlot14.setRenderer(xYItemRenderer23);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        dateAxis25.centerRange((double) 100);
        java.lang.String str28 = dateAxis25.getLabelToolTip();
        xYPlot14.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis25);
        org.jfree.chart.axis.ValueAxis valueAxis30 = xYPlot14.getDomainAxis();
        int int31 = xYPlot14.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        xYPlot14.zoomRangeAxes(0.08d, plotRenderingInfo33, point2D34);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(valueAxis30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean36 = categoryAxis3D35.isTickLabelsVisible();
        boolean boolean37 = categoryAxis3D35.isVisible();
        int int38 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot34.getRangeAxisEdge();
        categoryPlot34.configureDomainAxes();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = polarPlot2.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis4 = polarPlot2.getAxis();
        polarPlot2.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) polarPlot2, true);
        org.jfree.chart.title.Title title9 = null;
        jFreeChart8.removeSubtitle(title9);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart8.removeProgressListener(chartProgressListener11);
        int int13 = jFreeChart8.getSubtitleCount();
        jFreeChart8.clearSubtitles();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        jFreeChart8.setBorderPaint((java.awt.Paint) color15);
        boolean boolean17 = jFreeChart8.getAntiAlias();
        java.lang.Object obj18 = jFreeChart8.getTextAntiAlias();
        jFreeChart8.setBackgroundImageAlignment(100);
        jFreeChart8.setNotify(false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener23 = null;
        jFreeChart8.addProgressListener(chartProgressListener23);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(obj18);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        double double3 = ringPlot0.getInnerSeparatorExtension();
        int int4 = ringPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = ringPlot0.getSimpleLabelOffset();
        java.awt.Paint paint6 = ringPlot0.getLabelShadowPaint();
        boolean boolean7 = ringPlot0.isCircular();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot0.setLabelOutlineStroke(stroke8);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator10 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.AttributedString attributedString12 = null;
        standardPieSectionLabelGenerator10.setAttributedLabel(15, attributedString12);
        java.lang.Object obj14 = standardPieSectionLabelGenerator10.clone();
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = polarPlot15.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range18 = polarPlot15.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis17);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot15);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) polarPlot15);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType21 = plotChangeEvent20.getType();
        boolean boolean22 = standardPieSectionLabelGenerator10.equals((java.lang.Object) chartChangeEventType21);
        ringPlot0.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNotNull(chartChangeEventType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) 2.0d);
        java.lang.Object obj3 = strokeMap0.clone();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D4 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean5 = categoryAxis3D4.isTickLabelsVisible();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = polarPlot7.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis9 = polarPlot7.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = polarPlot10.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range13 = polarPlot10.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis12);
        polarPlot7.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis12);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat17 = numberAxis16.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit18 = numberAxis16.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis16, xYItemRenderer19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = xYPlot20.getRenderer();
        xYPlot20.clearDomainMarkers((int) 'a');
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = xYPlot20.getDomainMarkers(layer24);
        boolean boolean26 = xYPlot20.isRangeZoomable();
        boolean boolean27 = xYPlot20.isRangeCrosshairLockedOnData();
        java.awt.Paint paint28 = xYPlot20.getDomainGridlinePaint();
        categoryAxis3D4.setTickMarkPaint(paint28);
        boolean boolean30 = strokeMap0.equals((java.lang.Object) paint28);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        boolean boolean32 = dateAxis31.isVisible();
        dateAxis31.setNegativeArrowVisible(true);
        java.util.Date date35 = dateAxis31.getMinimumDate();
        boolean boolean36 = strokeMap0.equals((java.lang.Object) date35);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNull(numberFormat17);
        org.junit.Assert.assertNotNull(numberTickUnit18);
        org.junit.Assert.assertNull(xYItemRenderer21);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        categoryPlot34.setFixedDomainAxisSpace(axisSpace35);
        categoryPlot34.setWeight((int) '4');
        categoryPlot34.clearAnnotations();
        boolean boolean40 = categoryPlot34.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        java.awt.Color color2 = java.awt.Color.getColor("", 0);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        double double3 = ringPlot0.getOuterSeparatorExtension();
        ringPlot0.setOuterSeparatorExtension((double) (byte) 0);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ringPlot0.setBackgroundPaint((java.awt.Paint) color6);
        java.lang.String str8 = color6.toString();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=0,g=0,b=128]" + "'", str8.equals("java.awt.Color[r=0,g=0,b=128]"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        float float2 = valueMarker1.getAlpha();
        java.lang.Object obj3 = valueMarker1.clone();
        java.lang.String str4 = valueMarker1.getLabel();
        double double5 = valueMarker1.getValue();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.8f + "'", float2 == 0.8f);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.setBackgroundAlpha((float) (-1));
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) polarPlot0);
        java.lang.Object obj4 = jFreeChart3.clone();
        java.lang.Object obj5 = jFreeChart3.clone();
        try {
            org.jfree.chart.title.Title title7 = jFreeChart3.getSubtitle((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setIgnoreNullValues(true);
        java.awt.Stroke stroke3 = ringPlot0.getSeparatorStroke();
        double double4 = ringPlot0.getMinimumArcAngleToDraw();
        java.lang.Object obj5 = ringPlot0.clone();
        java.awt.Paint paint6 = ringPlot0.getShadowPaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-5d + "'", double4 == 1.0E-5d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        double double17 = ringPlot16.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = ringPlot16.getLabelPadding();
        double double19 = rectangleInsets18.getRight();
        double double21 = rectangleInsets18.trimHeight((double) (byte) 1);
        xYPlot14.setInsets(rectangleInsets18);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        xYPlot14.rendererChanged(rendererChangeEvent23);
        xYPlot14.setDomainCrosshairVisible(true);
        xYPlot14.setRangeCrosshairValue((double) '4', true);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-3.0d) + "'", double21 == (-3.0d));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        xYPlot14.clearDomainMarkers((int) 'a');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = null;
        xYPlot14.datasetChanged(datasetChangeEvent18);
        xYPlot14.clearDomainMarkers((int) (byte) 0);
        java.awt.Paint[] paintArray22 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray23 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Font font25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = polarPlot26.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis28 = polarPlot26.getAxis();
        polarPlot26.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart("hi!", font25, (org.jfree.chart.plot.Plot) polarPlot26, true);
        org.jfree.chart.title.Title title33 = null;
        jFreeChart32.removeSubtitle(title33);
        org.jfree.chart.event.ChartProgressListener chartProgressListener35 = null;
        jFreeChart32.removeProgressListener(chartProgressListener35);
        int int37 = jFreeChart32.getSubtitleCount();
        java.awt.Stroke stroke38 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        jFreeChart32.setBorderStroke(stroke38);
        java.awt.Stroke stroke40 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke41 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke42 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.RingPlot ringPlot43 = new org.jfree.chart.plot.RingPlot();
        ringPlot43.setIgnoreNullValues(true);
        java.awt.Stroke stroke46 = ringPlot43.getSeparatorStroke();
        java.awt.Stroke[] strokeArray47 = new java.awt.Stroke[] { stroke38, stroke40, stroke41, stroke42, stroke46 };
        java.awt.Stroke stroke48 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke49 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke50 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D51 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean52 = categoryAxis3D51.isTickLabelsVisible();
        java.awt.Stroke stroke53 = categoryAxis3D51.getTickMarkStroke();
        java.awt.Stroke[] strokeArray54 = new java.awt.Stroke[] { stroke48, stroke49, stroke50, stroke53 };
        org.jfree.chart.plot.RingPlot ringPlot55 = new org.jfree.chart.plot.RingPlot();
        double double56 = ringPlot55.getMaximumExplodePercent();
        java.awt.Shape shape57 = ringPlot55.getLegendItemShape();
        java.awt.Shape shape58 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray59 = new java.awt.Shape[] { shape57, shape58 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier60 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray22, paintArray23, strokeArray47, strokeArray54, shapeArray59);
        java.awt.Stroke stroke61 = defaultDrawingSupplier60.getNextStroke();
        xYPlot14.setRangeZeroBaselineStroke(stroke61);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertNotNull(paintArray22);
        org.junit.Assert.assertNotNull(paintArray23);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(strokeArray47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(strokeArray54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertNotNull(shapeArray59);
        org.junit.Assert.assertNotNull(stroke61);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        double double3 = rectangleInsets2.getRight();
        double double5 = rectangleInsets2.calculateRightInset((double) 3);
        double double7 = rectangleInsets2.calculateRightInset((double) 0.8f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.lang.Class<?> wildcardClass2 = color1.getClass();
        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass2);
        java.net.URL uRL4 = org.jfree.chart.util.ObjectUtilities.getResource("http://www.jfree.org/jfreechart/index.html", (java.lang.Class) wildcardClass2);
        java.lang.ClassLoader classLoader5 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass2);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(classLoader3);
        org.junit.Assert.assertNull(uRL4);
        org.junit.Assert.assertNotNull(classLoader5);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = polarPlot1.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot1.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = polarPlot4.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = polarPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis6);
        polarPlot1.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.text.NumberFormat numberFormat11 = numberAxis10.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot14.getRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = null;
        xYPlot14.setDrawingSupplier(drawingSupplier16);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(numberFormat11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(xYItemRenderer15);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("Category Plot");
        dateAxis1.setNegativeArrowVisible(true);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = polarPlot0.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis2 = polarPlot0.getAxis();
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = polarPlot3.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range6 = polarPlot3.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis5);
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis5);
        boolean boolean8 = polarPlot0.isAngleGridlinesVisible();
        java.awt.Paint paint9 = polarPlot0.getAngleGridlinePaint();
        double double10 = polarPlot0.getMaxRadius();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        polarPlot0.zoomDomainAxes((double) 100L, plotRenderingInfo12, point2D13, false);
        polarPlot0.setForegroundAlpha((float) (short) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        polarPlot0.zoomDomainAxes((double) 0.0f, (double) 0.0f, plotRenderingInfo20, point2D21);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer23 = null;
        polarPlot0.setRenderer(polarItemRenderer23);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = polarPlot0.getRenderer();
        boolean boolean26 = polarPlot0.isAngleLabelsVisible();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNull(polarItemRenderer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        boolean boolean3 = textTitle1.equals((java.lang.Object) 1.0f);
        java.awt.Paint[] paintArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = polarPlot8.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis10 = polarPlot8.getAxis();
        polarPlot8.addCornerTextItem("TextAnchor.BOTTOM_LEFT");
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font7, (org.jfree.chart.plot.Plot) polarPlot8, true);
        org.jfree.chart.title.Title title15 = null;
        jFreeChart14.removeSubtitle(title15);
        org.jfree.chart.event.ChartProgressListener chartProgressListener17 = null;
        jFreeChart14.removeProgressListener(chartProgressListener17);
        int int19 = jFreeChart14.getSubtitleCount();
        java.awt.Stroke stroke20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        jFreeChart14.setBorderStroke(stroke20);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.RingPlot ringPlot25 = new org.jfree.chart.plot.RingPlot();
        ringPlot25.setIgnoreNullValues(true);
        java.awt.Stroke stroke28 = ringPlot25.getSeparatorStroke();
        java.awt.Stroke[] strokeArray29 = new java.awt.Stroke[] { stroke20, stroke22, stroke23, stroke24, stroke28 };
        java.awt.Stroke stroke30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D33 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean34 = categoryAxis3D33.isTickLabelsVisible();
        java.awt.Stroke stroke35 = categoryAxis3D33.getTickMarkStroke();
        java.awt.Stroke[] strokeArray36 = new java.awt.Stroke[] { stroke30, stroke31, stroke32, stroke35 };
        org.jfree.chart.plot.RingPlot ringPlot37 = new org.jfree.chart.plot.RingPlot();
        double double38 = ringPlot37.getMaximumExplodePercent();
        java.awt.Shape shape39 = ringPlot37.getLegendItemShape();
        java.awt.Shape shape40 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray41 = new java.awt.Shape[] { shape39, shape40 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier42 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray4, paintArray5, strokeArray29, strokeArray36, shapeArray41);
        java.awt.Stroke stroke43 = defaultDrawingSupplier42.getNextStroke();
        java.awt.Paint paint44 = defaultDrawingSupplier42.getNextPaint();
        java.awt.Paint paint45 = defaultDrawingSupplier42.getNextFillPaint();
        textTitle1.setBackgroundPaint(paint45);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(strokeArray29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(strokeArray36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(shapeArray41);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        double[] doubleArray5 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray9 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray13 = new double[] { (-1.0f), '4', (-1L) };
        double[] doubleArray17 = new double[] { (-1.0f), '4', (-1L) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean21 = categoryAxis3D20.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot22 = categoryAxis3D20.getPlot();
        categoryAxis3D20.setCategoryMargin(0.08d);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = polarPlot25.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range28 = polarPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        dateAxis27.setAutoTickUnitSelection(true, false);
        java.util.Date date32 = dateAxis27.getMaximumDate();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        categoryPlot34.setFixedDomainAxisSpace(axisSpace35);
        categoryPlot34.setWeight((int) '4');
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D39 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D39.setCategoryMargin((double) (short) -1);
        org.jfree.chart.plot.RingPlot ringPlot42 = new org.jfree.chart.plot.RingPlot();
        double double43 = ringPlot42.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = ringPlot42.getLabelPadding();
        java.lang.Object obj45 = ringPlot42.clone();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        ringPlot42.handleClick(15, 15, plotRenderingInfo48);
        ringPlot42.setForegroundAlpha(0.0f);
        java.awt.Paint paint52 = ringPlot42.getLabelOutlinePaint();
        categoryAxis3D39.setTickLabelPaint(paint52);
        java.util.List list54 = categoryPlot34.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D39);
        org.jfree.chart.axis.ValueAxis valueAxis55 = categoryPlot34.getRangeAxis();
        categoryPlot34.setAnchorValue(0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(list54);
        org.junit.Assert.assertNotNull(valueAxis55);
    }
}

