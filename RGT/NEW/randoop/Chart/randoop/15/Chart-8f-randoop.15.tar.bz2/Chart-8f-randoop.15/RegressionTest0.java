import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) ' ', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', (int) (short) 10);
        try {
            org.jfree.data.time.Year year3 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', (int) (short) 10);
        java.lang.String str3 = week2.toString();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 97, 10" + "'", str3.equals("Week 97, 10"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.data.time.Week.FIRST_WEEK_IN_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        java.util.Date date5 = week4.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date2, timeZone7);
        try {
            org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date0, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone7);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test017");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.lang.String str2 = week0.toString();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year3);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.Week.LAST_WEEK_IN_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 53 + "'", int0 == 53);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        java.util.Date date4 = week3.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4, timeZone6);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date1, timeZone6);
        org.jfree.data.time.Year year9 = week8.getYear();
        java.util.Date date10 = year9.getEnd();
        java.util.TimeZone timeZone11 = null;
        try {
            org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(date10);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test020");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        java.util.Calendar calendar2 = null;
//        try {
//            week0.peg(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date1);
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date1);
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        java.util.Date date8 = week7.getEnd();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date8);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date8);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date8, timeZone11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone11);
        java.util.Locale locale14 = null;
        try {
            org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date1, timeZone11, locale14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod13);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2, timeZone4);
        org.jfree.data.time.Year year6 = week5.getYear();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 0, year6);
        long long8 = year6.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1562097599999L + "'", long8 == 1562097599999L);
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test023");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = week0.getMiddleMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test025");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.lang.String str2 = week0.toString();
//        java.util.Calendar calendar3 = null;
//        try {
//            week0.peg(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test026");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.util.Date date4 = week3.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4, timeZone6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date1, timeZone6);
//        long long9 = week8.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 97, 10");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.util.Locale locale3 = null;
        try {
            org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date1, timeZone2, locale3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test031");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date1);
//        long long4 = week3.getLastMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            week3.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test032");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.lang.String str4 = week0.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', (int) (short) 10);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.util.Calendar calendar6 = null;
        try {
            week2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 97, 10" + "'", str3.equals("Week 97, 10"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61793337600001L) + "'", long4 == (-61793337600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
        boolean boolean4 = week2.equals((java.lang.Object) (short) 10);
        java.util.Date date5 = week2.getStart();
        java.lang.Class class6 = null;
        java.util.Date date7 = null;
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
        java.util.Date date9 = week8.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date9, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date7, timeZone12);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date5, timeZone12);
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
        java.util.Date date19 = week18.getEnd();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date19);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date19);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date19, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone22);
        java.util.Locale locale25 = null;
        try {
            org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date5, timeZone22, locale25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod24);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        java.util.Calendar calendar2 = null;
        try {
            week0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test036");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date1);
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date1, timeZone4);
//        long long6 = week5.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, 24);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        boolean boolean5 = week0.equals((java.lang.Object) (short) 100);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date1);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date1, timeZone4);
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date1, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test040");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        int int3 = week0.getWeek();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getMiddleMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(53, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        java.util.Date date5 = week4.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        boolean boolean8 = week6.equals((java.lang.Object) (short) 10);
        java.util.Date date9 = week6.getStart();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        java.util.Date date13 = week12.getEnd();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date13);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date13, timeZone16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone16);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date9, timeZone16);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date2, timeZone16);
        java.util.Locale locale21 = null;
        try {
            org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date0, timeZone16, locale21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNull(regularTimePeriod18);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2, timeZone4);
        org.jfree.data.time.Year year6 = week5.getYear();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 0, year6);
        long long8 = week7.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546156799999L + "'", long8 == 1546156799999L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        java.util.Date date4 = week3.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4, timeZone6);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date1, timeZone6);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week8.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test045");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.util.Date date4 = week3.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4, timeZone6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date1, timeZone6);
//        org.jfree.data.time.Year year9 = week8.getYear();
//        long long10 = week8.getMiddleMillisecond();
//        int int11 = week8.getYearValue();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560365999999L + "'", long10 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        java.util.Date date4 = week3.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4, timeZone6);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date1, timeZone6);
        org.jfree.data.time.Year year9 = week8.getYear();
        long long10 = year9.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1562097599999L + "'", long10 == 1562097599999L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2, timeZone4);
        org.jfree.data.time.Year year6 = week5.getYear();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 0, year6);
        int int8 = week7.getWeek();
        java.util.Calendar calendar9 = null;
        try {
            week7.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test049");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date1);
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date1, timeZone4);
//        long long6 = week5.getSerialIndex();
//        java.lang.Class<?> wildcardClass7 = week5.getClass();
//        long long8 = week5.getLastMillisecond();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week5.getFirstMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2, timeZone4);
        org.jfree.data.time.Year year6 = week5.getYear();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 0, year6);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
        java.util.Date date9 = week8.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
        java.util.Date date12 = week11.getEnd();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date12);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date12, timeZone14);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date9, timeZone14);
        org.jfree.data.time.Year year17 = week16.getYear();
        java.util.Date date18 = year17.getEnd();
        boolean boolean19 = week7.equals((java.lang.Object) year17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week7.next();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2019, 8);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', (int) (short) 10);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 97, 10" + "'", str3.equals("Week 97, 10"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61793337600001L) + "'", long4 == (-61793337600001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61793942400000L) + "'", long5 == (-61793942400000L));
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test053");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.lang.String str2 = week0.toString();
//        long long3 = week0.getLastMillisecond();
//        long long4 = week0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        long long6 = week0.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
        boolean boolean4 = week2.equals((java.lang.Object) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date1, timeZone3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week4.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test056");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date1, timeZone3);
//        org.jfree.data.time.Year year5 = week4.getYear();
//        int int6 = week4.getWeek();
//        org.jfree.data.time.Year year7 = week4.getYear();
//        java.util.Date date8 = week4.getEnd();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getEnd();
//        java.lang.String str11 = week9.toString();
//        long long12 = week9.getLastMillisecond();
//        int int13 = week4.compareTo((java.lang.Object) long12);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 24, 2019" + "'", str11.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560668399999L + "'", long12 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test057");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2, timeZone4);
//        org.jfree.data.time.Year year6 = week5.getYear();
//        int int7 = week5.getWeek();
//        org.jfree.data.time.Year year8 = week5.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) '4', year8);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(year8);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 0);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test060");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date1);
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date1, timeZone4);
//        long long6 = week5.getSerialIndex();
//        java.lang.Class<?> wildcardClass7 = week5.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.util.Date date9 = week8.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week11.next();
//        int int14 = week11.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week11.previous();
//        java.lang.Class<?> wildcardClass16 = regularTimePeriod15.getClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        boolean boolean18 = week10.equals((java.lang.Object) class17);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        java.util.Date date20 = week19.getEnd();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date20);
//        boolean boolean23 = week21.equals((java.lang.Object) (short) 10);
//        java.util.Date date24 = week21.getStart();
//        java.lang.Class class25 = null;
//        java.util.Date date26 = null;
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        java.util.Date date28 = week27.getEnd();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date28);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date28);
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date28, timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone31);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date24, timeZone31);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        java.util.Date date36 = week35.getEnd();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date36);
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week();
//        java.util.Date date39 = week38.getEnd();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date39);
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date39, timeZone41);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date36, timeZone41);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date24, timeZone41);
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week();
//        java.util.Date date46 = week45.getEnd();
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date46);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date46);
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date46, timeZone49);
//        long long51 = week50.getSerialIndex();
//        java.util.Date date52 = week50.getStart();
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week();
//        java.util.Date date54 = week53.getEnd();
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date54);
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date54);
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date54, timeZone57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date52, timeZone57);
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week();
//        java.util.Date date61 = week60.getEnd();
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(date61);
//        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date61, timeZone63);
//        org.jfree.data.time.Year year65 = week64.getYear();
//        int int66 = week64.getWeek();
//        org.jfree.data.time.Year year67 = week64.getYear();
//        java.util.Date date68 = week64.getEnd();
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week();
//        java.util.Date date70 = week69.getEnd();
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date70);
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week();
//        java.util.Date date73 = week72.getEnd();
//        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date73);
//        boolean boolean76 = week74.equals((java.lang.Object) (short) 10);
//        java.util.Date date77 = week74.getStart();
//        java.lang.Class class78 = null;
//        java.util.Date date79 = null;
//        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week();
//        java.util.Date date81 = week80.getEnd();
//        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week(date81);
//        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week(date81);
//        java.util.TimeZone timeZone84 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week(date81, timeZone84);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance(class78, date79, timeZone84);
//        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week(date77, timeZone84);
//        org.jfree.data.time.Week week88 = new org.jfree.data.time.Week(date70, timeZone84);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date68, timeZone84);
//        org.jfree.data.time.Week week90 = new org.jfree.data.time.Week();
//        java.util.Date date91 = week90.getEnd();
//        org.jfree.data.time.Week week92 = new org.jfree.data.time.Week(date91);
//        org.jfree.data.time.Week week93 = new org.jfree.data.time.Week(date91);
//        java.util.TimeZone timeZone94 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week95 = new org.jfree.data.time.Week(date91, timeZone94);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod96 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date68, timeZone94);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 107031L + "'", long51 == 107031L);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(timeZone63);
//        org.junit.Assert.assertNotNull(year65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 24 + "'", int66 == 24);
//        org.junit.Assert.assertNotNull(year67);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(timeZone84);
//        org.junit.Assert.assertNull(regularTimePeriod86);
//        org.junit.Assert.assertNotNull(regularTimePeriod89);
//        org.junit.Assert.assertNotNull(date91);
//        org.junit.Assert.assertNotNull(timeZone94);
//        org.junit.Assert.assertNotNull(regularTimePeriod96);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', (int) (short) 10);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 97, 10" + "'", str3.equals("Week 97, 10"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61793337600001L) + "'", long4 == (-61793337600001L));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        int int4 = week0.compareTo((java.lang.Object) false);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2, timeZone4);
        org.jfree.data.time.Year year6 = week5.getYear();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 0, year6);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
        java.util.Date date9 = week8.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
        java.util.Date date12 = week11.getEnd();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date12);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date12, timeZone14);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date9, timeZone14);
        org.jfree.data.time.Year year17 = week16.getYear();
        java.util.Date date18 = year17.getEnd();
        boolean boolean19 = week7.equals((java.lang.Object) year17);
        long long20 = week7.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1545552000000L + "'", long20 == 1545552000000L);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test064");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.util.Date date5 = week4.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5, timeZone7);
//        org.jfree.data.time.Year year9 = week8.getYear();
//        int int10 = week8.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week8.next();
//        boolean boolean12 = week0.equals((java.lang.Object) week8);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test065");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date1, timeZone3);
//        org.jfree.data.time.Year year5 = week4.getYear();
//        int int6 = week4.getWeek();
//        long long7 = week4.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week4.previous();
//        long long9 = week4.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560668399999L + "'", long9 == 1560668399999L);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
        boolean boolean4 = week2.equals((java.lang.Object) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.util.Calendar calendar6 = null;
        try {
            week2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test067");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date1);
//        long long4 = week3.getLastMillisecond();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week5.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.previous();
//        boolean boolean9 = week3.equals((java.lang.Object) regularTimePeriod8);
//        java.lang.Object obj10 = null;
//        int int11 = week3.compareTo(obj10);
//        java.util.Calendar calendar12 = null;
//        try {
//            long long13 = week3.getMiddleMillisecond(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', (int) (short) 10);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 97, 10" + "'", str3.equals("Week 97, 10"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61793337600001L) + "'", long4 == (-61793337600001L));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date1);
        int int4 = week3.getYearValue();
        java.util.Date date5 = week3.getEnd();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', (int) (short) 10);
        java.lang.String str3 = week2.toString();
        int int5 = week2.compareTo((java.lang.Object) (-61793640000001L));
        java.util.Date date6 = week2.getStart();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 97, 10" + "'", str3.equals("Week 97, 10"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 5);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        int int3 = week0.getYearValue();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date6, timeZone8);
//        org.jfree.data.time.Year year10 = week9.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (short) 0, year10);
//        int int12 = week0.compareTo((java.lang.Object) week11);
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = week11.getLastMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-1), 5);
        java.util.Date date3 = week2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test074");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.lang.String str2 = week0.toString();
//        long long3 = week0.getLastMillisecond();
//        long long4 = week0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getEnd();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date12);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getEnd();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date15, timeZone17);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date12, timeZone17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date7, timeZone17);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        java.util.Date date22 = week21.getEnd();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date22);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        java.util.Date date25 = week24.getEnd();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date25);
//        boolean boolean28 = week26.equals((java.lang.Object) (short) 10);
//        java.util.Date date29 = week26.getStart();
//        java.lang.Class class30 = null;
//        java.util.Date date31 = null;
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        java.util.Date date33 = week32.getEnd();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date33);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date33);
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date33, timeZone36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone36);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date29, timeZone36);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date22, timeZone36);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date7, timeZone36);
//        java.util.TimeZone timeZone42 = null;
//        java.util.Locale locale43 = null;
//        try {
//            org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date7, timeZone42, locale43);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test075");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.util.Date date4 = week3.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4, timeZone6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date1, timeZone6);
//        org.jfree.data.time.Year year9 = week8.getYear();
//        org.jfree.data.time.Year year10 = week8.getYear();
//        int int11 = week8.getWeek();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, 8);
        java.lang.String str3 = week2.toString();
        int int4 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 1, 8" + "'", str3.equals("Week 1, 8"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
        boolean boolean4 = week2.equals((java.lang.Object) (short) 10);
        java.util.Date date5 = week2.getStart();
        java.util.Date date6 = week2.getEnd();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date1);
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date1);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date1);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week5.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', (int) (short) 10);
        java.lang.String str3 = week2.toString();
        int int4 = week2.getYearValue();
        java.util.Calendar calendar5 = null;
        try {
            week2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 97, 10" + "'", str3.equals("Week 97, 10"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Week week1 = new org.jfree.data.time.Week(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, 8);
        java.lang.String str3 = week2.toString();
        java.util.Date date4 = week2.getEnd();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 1, 8" + "'", str3.equals("Week 1, 8"));
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test083");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        int int3 = week0.getWeek();
//        java.util.Date date4 = week0.getEnd();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 6);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test085");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        int int4 = week0.compareTo((java.lang.Object) false);
//        java.lang.String str5 = week0.toString();
//        long long6 = week0.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test086");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        java.lang.Class<?> wildcardClass6 = regularTimePeriod5.getClass();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test087");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.util.Date date4 = week3.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4, timeZone6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date1, timeZone6);
//        boolean boolean10 = week8.equals((java.lang.Object) 100);
//        long long11 = week8.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week8.next();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        java.util.Date date14 = week13.getEnd();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date14);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        java.util.Date date17 = week16.getEnd();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date17);
//        boolean boolean20 = week18.equals((java.lang.Object) (short) 10);
//        java.util.Date date21 = week18.getStart();
//        java.lang.Class class22 = null;
//        java.util.Date date23 = null;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        java.util.Date date25 = week24.getEnd();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date25);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date25);
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date25, timeZone28);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date23, timeZone28);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date21, timeZone28);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date14, timeZone28);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date14);
//        boolean boolean34 = week8.equals((java.lang.Object) date14);
//        int int35 = week8.getYearValue();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560668399999L + "'", long11 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
//    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test088");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        java.util.Date date5 = week0.getStart();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-1), 5);
        java.util.Date date3 = week2.getStart();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date1, timeZone3);
        org.jfree.data.time.Year year5 = week4.getYear();
        org.jfree.data.time.Year year6 = week4.getYear();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week4.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(year6);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(3, 1);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test092");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date1, timeZone3);
//        org.jfree.data.time.Year year5 = week4.getYear();
//        int int6 = week4.getWeek();
//        org.jfree.data.time.Year year7 = week4.getYear();
//        java.util.Date date8 = week4.getEnd();
//        java.lang.Object obj9 = null;
//        boolean boolean10 = week4.equals(obj9);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        int int3 = week0.getWeek();
//        java.util.Date date4 = week0.getEnd();
//        long long5 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test094");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date1, timeZone3);
//        long long5 = week4.getSerialIndex();
//        boolean boolean7 = week4.equals((java.lang.Object) 6);
//        int int8 = week4.getWeek();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) 'a', (int) (short) 10);
        java.lang.String str7 = week6.toString();
        int int9 = week6.compareTo((java.lang.Object) (-61793640000001L));
        java.util.Date date10 = week6.getStart();
        int int12 = week6.compareTo((java.lang.Object) 1545552000000L);
        boolean boolean13 = week0.equals((java.lang.Object) week6);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 97, 10" + "'", str7.equals("Week 97, 10"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        java.lang.String str6 = timePeriodFormatException4.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.String str11 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2, timeZone4);
        org.jfree.data.time.Year year6 = week5.getYear();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 0, year6);
        int int8 = week7.getWeek();
        java.util.Date date9 = week7.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 107006L + "'", long11 == 107006L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, 8);
        long long3 = week2.getLastMillisecond();
        long long4 = week2.getSerialIndex();
        boolean boolean6 = week2.equals((java.lang.Object) 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61914297600001L) + "'", long3 == (-61914297600001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 425L + "'", long4 == 425L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, 8);
        long long3 = week2.getSerialIndex();
        int int4 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 425L + "'", long3 == 425L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', (int) (short) 10);
        long long3 = week2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        long long5 = regularTimePeriod4.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61793640000001L) + "'", long3 == (-61793640000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61794244800001L) + "'", long5 == (-61794244800001L));
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test101");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        int int3 = week0.getYearValue();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date6, timeZone8);
//        org.jfree.data.time.Year year10 = week9.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (short) 0, year10);
//        int int12 = week0.compareTo((java.lang.Object) week11);
//        java.util.Calendar calendar13 = null;
//        try {
//            week11.peg(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, 8);
        long long3 = week2.getLastMillisecond();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getSerialIndex();
        java.util.Date date6 = week2.getEnd();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61914297600001L) + "'", long3 == (-61914297600001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 425L + "'", long4 == 425L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 425L + "'", long5 == 425L);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3, timeZone5);
        org.jfree.data.time.Year year7 = week6.getYear();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, year7);
        int int9 = week8.getWeek();
        java.util.Date date10 = week8.getEnd();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
        org.jfree.data.time.Year year12 = week11.getYear();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (byte) 1, year12);
        long long14 = week13.getSerialIndex();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 106955L + "'", long14 == 106955L);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test104");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        int int4 = week0.compareTo((java.lang.Object) false);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week5.next();
//        int int8 = week5.getWeek();
//        java.util.Date date9 = week5.getEnd();
//        int int10 = week0.compareTo((java.lang.Object) week5);
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = week5.getMiddleMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        java.util.Date date4 = week3.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        java.util.Date date7 = week6.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week6.previous();
        java.lang.Class<?> wildcardClass11 = regularTimePeriod10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        boolean boolean13 = week5.equals((java.lang.Object) class12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
        java.util.Date date15 = week14.getEnd();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
        boolean boolean18 = week16.equals((java.lang.Object) (short) 10);
        java.util.Date date19 = week16.getStart();
        java.lang.Class class20 = null;
        java.util.Date date21 = null;
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
        java.util.Date date23 = week22.getEnd();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date23);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date23);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date23, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone26);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date19, timeZone26);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
        java.util.Date date31 = week30.getEnd();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date31);
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
        java.util.Date date34 = week33.getEnd();
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date34);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date34, timeZone36);
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date31, timeZone36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date19, timeZone36);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date1, timeZone36);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date1);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date1);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test106");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.util.Date date4 = week3.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4, timeZone6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date1, timeZone6);
//        boolean boolean10 = week8.equals((java.lang.Object) 100);
//        long long11 = week8.getLastMillisecond();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        java.util.Date date13 = week12.getEnd();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
//        boolean boolean16 = week14.equals((java.lang.Object) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week14.previous();
//        boolean boolean18 = week8.equals((java.lang.Object) week14);
//        java.util.Calendar calendar19 = null;
//        try {
//            week14.peg(calendar19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560668399999L + "'", long11 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date1, timeZone3);
        org.jfree.data.time.Year year5 = week4.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week4.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test108");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.lang.String str2 = week0.toString();
//        long long3 = week0.getLastMillisecond();
//        long long4 = week0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test109");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', (int) (short) 10);
//        long long3 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.util.Date date5 = week4.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5);
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date5, timeZone8);
//        long long10 = week9.getSerialIndex();
//        java.lang.Class<?> wildcardClass11 = week9.getClass();
//        boolean boolean12 = week2.equals((java.lang.Object) wildcardClass11);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61793640000001L) + "'", long3 == (-61793640000001L));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107031L + "'", long10 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test110");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date1, timeZone3);
//        long long5 = week4.getSerialIndex();
//        boolean boolean7 = week4.equals((java.lang.Object) 6);
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week4.getMiddleMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(5, (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, 8);
        long long3 = week2.getLastMillisecond();
        int int4 = week2.getYearValue();
        long long5 = week2.getMiddleMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61914297600001L) + "'", long3 == (-61914297600001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61914600000001L) + "'", long5 == (-61914600000001L));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', (int) (short) 10);
        java.lang.String str3 = week2.toString();
        int int4 = week2.getYearValue();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        java.util.Date date6 = week5.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week5.next();
        int int8 = week5.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week5.previous();
        java.lang.Class<?> wildcardClass10 = regularTimePeriod9.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        java.util.Date date13 = week12.getEnd();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone15);
        boolean boolean17 = week2.equals((java.lang.Object) class11);
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
        java.util.Date date21 = week20.getEnd();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date21, timeZone23);
        org.jfree.data.time.Year year25 = week24.getYear();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week((int) (short) 0, year25);
        int int27 = week26.getWeek();
        java.util.Date date28 = week26.getEnd();
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
        java.util.Date date30 = week29.getEnd();
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date30);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
        java.util.Date date33 = week32.getEnd();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date33);
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date33, timeZone35);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date30, timeZone35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date28, timeZone35);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
        java.util.Date date40 = week39.getEnd();
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date40);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date40);
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date40);
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date40);
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week();
        java.util.Date date46 = week45.getEnd();
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date46);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
        java.util.Date date49 = week48.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = week48.next();
        int int51 = week48.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = week48.previous();
        java.lang.Class<?> wildcardClass53 = regularTimePeriod52.getClass();
        java.lang.Class class54 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass53);
        boolean boolean55 = week47.equals((java.lang.Object) class54);
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week();
        java.util.Date date57 = week56.getEnd();
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date57);
        boolean boolean60 = week58.equals((java.lang.Object) (short) 10);
        java.util.Date date61 = week58.getStart();
        java.lang.Class class62 = null;
        java.util.Date date63 = null;
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week();
        java.util.Date date65 = week64.getEnd();
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date65);
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date65);
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date65, timeZone68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class62, date63, timeZone68);
        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date61, timeZone68);
        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week();
        java.util.Date date73 = week72.getEnd();
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date73);
        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week();
        java.util.Date date76 = week75.getEnd();
        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date76);
        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week(date76, timeZone78);
        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(date73, timeZone78);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance(class54, date61, timeZone78);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date40, timeZone78);
        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week();
        java.util.Date date84 = week83.getEnd();
        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week(date84);
        boolean boolean87 = week85.equals((java.lang.Object) (short) 10);
        java.util.Date date88 = week85.getStart();
        java.lang.Class class89 = null;
        java.util.Date date90 = null;
        org.jfree.data.time.Week week91 = new org.jfree.data.time.Week();
        java.util.Date date92 = week91.getEnd();
        org.jfree.data.time.Week week93 = new org.jfree.data.time.Week(date92);
        org.jfree.data.time.Week week94 = new org.jfree.data.time.Week(date92);
        java.util.TimeZone timeZone95 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week96 = new org.jfree.data.time.Week(date92, timeZone95);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod97 = org.jfree.data.time.RegularTimePeriod.createInstance(class89, date90, timeZone95);
        org.jfree.data.time.Week week98 = new org.jfree.data.time.Week(date88, timeZone95);
        org.jfree.data.time.Week week99 = new org.jfree.data.time.Week(date40, timeZone95);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 97, 10" + "'", str3.equals("Week 97, 10"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(year25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(class54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(timeZone78);
        org.junit.Assert.assertNotNull(regularTimePeriod81);
        org.junit.Assert.assertNotNull(regularTimePeriod82);
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertNotNull(date92);
        org.junit.Assert.assertNotNull(timeZone95);
        org.junit.Assert.assertNull(regularTimePeriod97);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', (int) (short) 10);
        java.lang.String str3 = week2.toString();
        int int5 = week2.compareTo((java.lang.Object) (-61793640000001L));
        java.util.Date date6 = week2.getStart();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 97, 10" + "'", str3.equals("Week 97, 10"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str7 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test116");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        int int3 = week0.getWeek();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getMiddleMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, 8);
        java.lang.String str3 = week2.toString();
        try {
            org.jfree.data.time.Year year4 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (8) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 1, 8" + "'", str3.equals("Week 1, 8"));
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date1, timeZone3);
//        org.jfree.data.time.Year year5 = week4.getYear();
//        int int6 = week4.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.next();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.util.Date date9 = week8.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9);
//        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date9, timeZone12);
//        long long14 = week13.getSerialIndex();
//        java.util.Date date15 = week13.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week13.previous();
//        boolean boolean17 = week4.equals((java.lang.Object) regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 107031L + "'", long14 == 107031L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        java.util.Date date5 = week4.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date2, timeZone7);
        org.jfree.data.time.Year year10 = week9.getYear();
        org.jfree.data.time.Year year11 = week9.getYear();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', year11);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(year11);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test120");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date1, timeZone3);
//        org.jfree.data.time.Year year5 = week4.getYear();
//        int int6 = week4.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.next();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.util.Date date9 = week8.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week8.next();
//        int int11 = week8.getWeek();
//        java.util.Date date12 = week8.getEnd();
//        int int13 = week4.compareTo((java.lang.Object) date12);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date1, timeZone3);
//        org.jfree.data.time.Year year5 = week4.getYear();
//        int int6 = week4.getWeek();
//        long long7 = week4.getLastMillisecond();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getEnd();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
//        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date10, timeZone12);
//        org.jfree.data.time.Year year14 = week13.getYear();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) 0, year14);
//        int int16 = week15.getWeek();
//        java.util.Date date17 = week15.getEnd();
//        int int18 = week4.compareTo((java.lang.Object) date17);
//        java.util.TimeZone timeZone19 = null;
//        java.util.Locale locale20 = null;
//        try {
//            org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date17, timeZone19, locale20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test123");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date1, timeZone3);
//        org.jfree.data.time.Year year5 = week4.getYear();
//        int int6 = week4.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.next();
//        java.lang.Class<?> wildcardClass8 = week4.getClass();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.util.Date date4 = week3.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4, timeZone6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date1, timeZone6);
//        org.jfree.data.time.Year year9 = week8.getYear();
//        org.jfree.data.time.Year year10 = week8.getYear();
//        long long11 = week8.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560365999999L + "'", long11 == 1560365999999L);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3, timeZone5);
        org.jfree.data.time.Year year7 = week6.getYear();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, year7);
        int int9 = week8.getWeek();
        java.util.Date date10 = week8.getEnd();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
        org.jfree.data.time.Year year12 = week11.getYear();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(24, year12);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = week13.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(year12);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: Week 97, 10");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        java.util.Date date4 = week3.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4, timeZone6);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date1, timeZone6);
        org.jfree.data.time.Year year9 = week8.getYear();
        boolean boolean11 = week8.equals((java.lang.Object) 1.0f);
        org.jfree.data.time.Year year12 = week8.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(year12);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test128");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        int int3 = week0.getWeek();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) 'a', (int) (short) 10);
//        java.lang.String str9 = week8.toString();
//        int int10 = week8.getYearValue();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week11.next();
//        int int14 = week11.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week11.previous();
//        java.lang.Class<?> wildcardClass16 = regularTimePeriod15.getClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        java.util.Date date19 = week18.getEnd();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date19);
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date19, timeZone21);
//        boolean boolean23 = week8.equals((java.lang.Object) class17);
//        long long24 = week8.getFirstMillisecond();
//        int int25 = week8.getWeek();
//        try {
//            int int26 = week0.compareTo((java.lang.Object) week8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 97, 10" + "'", str9.equals("Week 97, 10"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61793942400000L) + "'", long24 == (-61793942400000L));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 97 + "'", int25 == 97);
//    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test129");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.util.Date date4 = week3.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week3.next();
//        int int6 = week3.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week3.previous();
//        java.lang.Class<?> wildcardClass8 = regularTimePeriod7.getClass();
//        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        boolean boolean10 = week2.equals((java.lang.Object) class9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getEnd();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date12);
//        boolean boolean15 = week13.equals((java.lang.Object) (short) 10);
//        java.util.Date date16 = week13.getStart();
//        java.lang.Class class17 = null;
//        java.util.Date date18 = null;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        java.util.Date date20 = week19.getEnd();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date20);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date20);
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date20, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone23);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date16, timeZone23);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        java.util.Date date28 = week27.getEnd();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date28);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        java.util.Date date31 = week30.getEnd();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date31);
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date31, timeZone33);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date28, timeZone33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date16, timeZone33);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        java.util.Date date38 = week37.getEnd();
//        java.lang.String str39 = week37.toString();
//        long long40 = week37.getLastMillisecond();
//        long long41 = week37.getLastMillisecond();
//        java.lang.Class<?> wildcardClass42 = week37.getClass();
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week();
//        java.util.Date date44 = week43.getEnd();
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date44);
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date44);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date44);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
//        java.util.Date date49 = week48.getEnd();
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date49);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week();
//        java.util.Date date52 = week51.getEnd();
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date52);
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date52, timeZone54);
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date49, timeZone54);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date44, timeZone54);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date16, timeZone54);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Week 24, 2019" + "'", str39.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560668399999L + "'", long40 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560668399999L + "'", long41 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, 8);
        long long3 = week2.getLastMillisecond();
        int int4 = week2.getYearValue();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61914297600001L) + "'", long3 == (-61914297600001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test131");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date1, timeZone3);
//        org.jfree.data.time.Year year5 = week4.getYear();
//        int int6 = week4.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.next();
//        int int8 = week4.getWeek();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week4.getMiddleMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, 8);
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        java.util.Date date5 = week4.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5, timeZone7);
        org.jfree.data.time.Year year9 = week8.getYear();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (short) 0, year9);
        boolean boolean11 = week2.equals((java.lang.Object) year9);
        int int12 = week2.getWeek();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, 24);
        long long3 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1273L + "'", long3 == 1273L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        org.jfree.data.time.Year year2 = week0.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(year2);
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        int int4 = week0.compareTo((java.lang.Object) false);
//        java.lang.String str5 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.next();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, 8);
        long long3 = week2.getLastMillisecond();
        int int4 = week2.getYearValue();
        long long5 = week2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        int int7 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61914297600001L) + "'", long3 == (-61914297600001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61914600000001L) + "'", long5 == (-61914600000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', (int) (short) 10);
        java.lang.String str3 = week2.toString();
        int int4 = week2.getYearValue();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        java.util.Date date6 = week5.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week5.next();
        int int8 = week5.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week5.previous();
        java.lang.Class<?> wildcardClass10 = regularTimePeriod9.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        java.util.Date date13 = week12.getEnd();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone15);
        boolean boolean17 = week2.equals((java.lang.Object) class11);
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
        java.util.Date date21 = week20.getEnd();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date21, timeZone23);
        org.jfree.data.time.Year year25 = week24.getYear();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week((int) (short) 0, year25);
        int int27 = week26.getWeek();
        java.util.Date date28 = week26.getEnd();
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
        java.util.Date date30 = week29.getEnd();
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date30);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
        java.util.Date date33 = week32.getEnd();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date33);
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date33, timeZone35);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date30, timeZone35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date28, timeZone35);
        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize(class18);
        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize(class39);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
        java.util.Date date42 = week41.getEnd();
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date42);
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date42);
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date42);
        java.lang.Class class46 = null;
        java.util.Date date47 = null;
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
        java.util.Date date49 = week48.getEnd();
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date49);
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date49);
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date49, timeZone52);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date47, timeZone52);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date42, timeZone52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 97, 10" + "'", str3.equals("Week 97, 10"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(year25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertNotNull(class40);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, (int) 'a');
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test139");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, 8);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.util.Date date4 = week3.getEnd();
//        java.lang.String str5 = week3.toString();
//        long long6 = week3.getLastMillisecond();
//        long long7 = week3.getLastMillisecond();
//        java.lang.Class<?> wildcardClass8 = week3.getClass();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getEnd();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date10);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getEnd();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        java.util.Date date18 = week17.getEnd();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date18);
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date18, timeZone20);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date15, timeZone20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date10, timeZone20);
//        boolean boolean24 = week2.equals((java.lang.Object) date10);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.lang.String str2 = week0.toString();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test142");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date1);
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date1, timeZone4);
//        long long6 = week5.getSerialIndex();
//        java.util.Date date7 = week5.getStart();
//        long long8 = week5.getFirstMillisecond();
//        int int9 = week5.getWeek();
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = week5.getMiddleMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3, timeZone5);
        org.jfree.data.time.Year year7 = week6.getYear();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, year7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(5, year7);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(year7);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.util.Date date5 = week4.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getEnd();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        java.util.Date date13 = week12.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
//        int int15 = week12.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week12.previous();
//        java.lang.Class<?> wildcardClass17 = regularTimePeriod16.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        boolean boolean19 = week11.equals((java.lang.Object) class18);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        java.util.Date date21 = week20.getEnd();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
//        boolean boolean24 = week22.equals((java.lang.Object) (short) 10);
//        java.util.Date date25 = week22.getStart();
//        java.lang.Class class26 = null;
//        java.util.Date date27 = null;
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        java.util.Date date29 = week28.getEnd();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date29);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date29);
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date29, timeZone32);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date27, timeZone32);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date25, timeZone32);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        java.util.Date date37 = week36.getEnd();
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date37);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        java.util.Date date40 = week39.getEnd();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date40);
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date40, timeZone42);
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date37, timeZone42);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date25, timeZone42);
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
//        java.util.Date date47 = week46.getEnd();
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date47);
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date47);
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date47, timeZone50);
//        long long52 = week51.getSerialIndex();
//        java.util.Date date53 = week51.getStart();
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week();
//        java.util.Date date55 = week54.getEnd();
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date55);
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date55);
//        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date55, timeZone58);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date53, timeZone58);
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week();
//        java.util.Date date62 = week61.getEnd();
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date62);
//        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date62, timeZone64);
//        org.jfree.data.time.Year year66 = week65.getYear();
//        int int67 = week65.getWeek();
//        org.jfree.data.time.Year year68 = week65.getYear();
//        java.util.Date date69 = week65.getEnd();
//        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week();
//        java.util.Date date71 = week70.getEnd();
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date71);
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week();
//        java.util.Date date74 = week73.getEnd();
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date74);
//        boolean boolean77 = week75.equals((java.lang.Object) (short) 10);
//        java.util.Date date78 = week75.getStart();
//        java.lang.Class class79 = null;
//        java.util.Date date80 = null;
//        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week();
//        java.util.Date date82 = week81.getEnd();
//        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week(date82);
//        org.jfree.data.time.Week week84 = new org.jfree.data.time.Week(date82);
//        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week86 = new org.jfree.data.time.Week(date82, timeZone85);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance(class79, date80, timeZone85);
//        org.jfree.data.time.Week week88 = new org.jfree.data.time.Week(date78, timeZone85);
//        org.jfree.data.time.Week week89 = new org.jfree.data.time.Week(date71, timeZone85);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date69, timeZone85);
//        org.jfree.data.time.Week week91 = new org.jfree.data.time.Week(date5, timeZone85);
//        java.util.Locale locale92 = null;
//        try {
//            org.jfree.data.time.Week week93 = new org.jfree.data.time.Week(date1, timeZone85, locale92);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 107031L + "'", long52 == 107031L);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(timeZone58);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(timeZone64);
//        org.junit.Assert.assertNotNull(year66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 24 + "'", int67 == 24);
//        org.junit.Assert.assertNotNull(year68);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertNotNull(timeZone85);
//        org.junit.Assert.assertNull(regularTimePeriod87);
//        org.junit.Assert.assertNotNull(regularTimePeriod90);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test147");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.util.Date date4 = week3.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        boolean boolean7 = week5.equals((java.lang.Object) (short) 10);
//        java.util.Date date8 = week5.getStart();
//        java.lang.Class class9 = null;
//        java.util.Date date10 = null;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getEnd();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date12);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date12);
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date12, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date8, timeZone15);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date1, timeZone15);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        java.util.Date date21 = week20.getEnd();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date21);
//        long long24 = week23.getLastMillisecond();
//        java.util.Date date25 = week23.getStart();
//        int int26 = week19.compareTo((java.lang.Object) week23);
//        long long27 = week19.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560668399999L + "'", long24 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 107031L + "'", long27 == 107031L);
//    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date1, timeZone3);
//        org.jfree.data.time.Year year5 = week4.getYear();
//        int int6 = week4.getWeek();
//        org.jfree.data.time.Year year7 = week4.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.util.Date date9 = week8.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week8.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week8.previous();
//        boolean boolean12 = week4.equals((java.lang.Object) week8);
//        java.util.Date date13 = week8.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(date13);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 97, 10");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        java.lang.String str9 = timePeriodFormatException7.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 97, 10" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 97, 10"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test150");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date1);
//        int int6 = week5.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week5.previous();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test151");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date1, timeZone3);
//        org.jfree.data.time.Year year5 = week4.getYear();
//        int int6 = week4.getWeek();
//        long long7 = week4.getLastMillisecond();
//        int int8 = week4.getYearValue();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', (int) (short) 10);
        java.lang.String str3 = week2.toString();
        int int5 = week2.compareTo((java.lang.Object) (-61793640000001L));
        java.util.Date date6 = week2.getStart();
        int int8 = week2.compareTo((java.lang.Object) 1545552000000L);
        java.lang.Class<?> wildcardClass9 = week2.getClass();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 97, 10" + "'", str3.equals("Week 97, 10"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        int int4 = week0.compareTo((java.lang.Object) false);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week5.next();
//        int int8 = week5.getWeek();
//        java.util.Date date9 = week5.getEnd();
//        int int10 = week0.compareTo((java.lang.Object) week5);
//        java.util.Calendar calendar11 = null;
//        try {
//            week5.peg(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2, timeZone4);
        org.jfree.data.time.Year year6 = week5.getYear();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 0, year6);
        int int8 = week7.getWeek();
        java.util.Date date9 = week7.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        org.jfree.data.time.Year year11 = week10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week10.previous();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getFirstMillisecond();
//        java.util.Date date5 = week0.getStart();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date1, timeZone3);
//        org.jfree.data.time.Year year5 = week4.getYear();
//        java.lang.String str6 = week4.toString();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week4.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2, timeZone4);
        org.jfree.data.time.Year year6 = week5.getYear();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 0, year6);
        int int8 = week7.getWeek();
        java.util.Date date9 = week7.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = week10.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        int int4 = week0.compareTo((java.lang.Object) false);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week5.next();
//        int int8 = week5.getWeek();
//        java.util.Date date9 = week5.getEnd();
//        int int10 = week0.compareTo((java.lang.Object) week5);
//        java.lang.Class<?> wildcardClass11 = week0.getClass();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 3);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        java.util.Date date4 = week3.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4, timeZone6);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date1, timeZone6);
        boolean boolean10 = week8.equals((java.lang.Object) 100);
        java.util.Date date11 = week8.getStart();
        java.lang.Class<?> wildcardClass12 = date11.getClass();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date1);
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date1, timeZone4);
//        long long6 = week5.getSerialIndex();
//        java.util.Date date7 = week5.getStart();
//        long long8 = week5.getFirstMillisecond();
//        int int9 = week5.getWeek();
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = week5.getFirstMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test162");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.util.Date date4 = week3.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4, timeZone6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date1, timeZone6);
//        boolean boolean10 = week8.equals((java.lang.Object) 100);
//        int int11 = week8.getWeek();
//        java.lang.Class<?> wildcardClass12 = week8.getClass();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        java.util.Date date4 = week3.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4, timeZone6);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date1, timeZone6);
        org.jfree.data.time.Year year9 = week8.getYear();
        org.jfree.data.time.Year year10 = week8.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week8.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year2);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date1);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date1, timeZone4);
        org.jfree.data.time.Year year6 = week5.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(year6);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test166");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', (int) (short) 10);
//        java.lang.String str3 = week2.toString();
//        int int4 = week2.getYearValue();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week5.next();
//        int int8 = week5.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week5.previous();
//        java.lang.Class<?> wildcardClass10 = regularTimePeriod9.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        java.util.Date date13 = week12.getEnd();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
//        java.util.TimeZone timeZone15 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone15);
//        boolean boolean17 = week2.equals((java.lang.Object) class11);
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        java.util.Date date20 = week19.getEnd();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date20);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date20);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date20);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date20);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        java.util.Date date26 = week25.getEnd();
//        java.lang.String str27 = week25.toString();
//        long long28 = week25.getLastMillisecond();
//        long long29 = week25.getLastMillisecond();
//        java.lang.Class<?> wildcardClass30 = week25.getClass();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        java.util.Date date32 = week31.getEnd();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date32);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date32);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date32);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        java.util.Date date37 = week36.getEnd();
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date37);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        java.util.Date date40 = week39.getEnd();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date40);
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date40, timeZone42);
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date37, timeZone42);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date32, timeZone42);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date20, timeZone42);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 97, 10" + "'", str3.equals("Week 97, 10"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Week 24, 2019" + "'", str27.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560668399999L + "'", long28 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560668399999L + "'", long29 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test167");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        int int4 = week0.compareTo((java.lang.Object) false);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week5.next();
//        int int8 = week5.getWeek();
//        java.util.Date date9 = week5.getEnd();
//        int int10 = week0.compareTo((java.lang.Object) week5);
//        long long11 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560668399999L + "'", long11 == 1560668399999L);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, 8);
        long long3 = week2.getLastMillisecond();
        int int4 = week2.getYearValue();
        long long5 = week2.getMiddleMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61914297600001L) + "'", long3 == (-61914297600001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61914600000001L) + "'", long5 == (-61914600000001L));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        java.util.Date date5 = week4.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        boolean boolean8 = week6.equals((java.lang.Object) (short) 10);
        java.util.Date date9 = week6.getStart();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        java.util.Date date13 = week12.getEnd();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date13);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date13, timeZone16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone16);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date9, timeZone16);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date2, timeZone16);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date2);
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone22);
        java.util.TimeZone timeZone24 = null;
        try {
            org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date2, timeZone24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNull(regularTimePeriod23);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        java.util.Date date4 = week3.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        java.util.Date date7 = week6.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week6.previous();
        java.lang.Class<?> wildcardClass11 = regularTimePeriod10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        boolean boolean13 = week5.equals((java.lang.Object) class12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
        java.util.Date date15 = week14.getEnd();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
        boolean boolean18 = week16.equals((java.lang.Object) (short) 10);
        java.util.Date date19 = week16.getStart();
        java.lang.Class class20 = null;
        java.util.Date date21 = null;
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
        java.util.Date date23 = week22.getEnd();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date23);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date23);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date23, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone26);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date19, timeZone26);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
        java.util.Date date31 = week30.getEnd();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date31);
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
        java.util.Date date34 = week33.getEnd();
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date34);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date34, timeZone36);
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date31, timeZone36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date19, timeZone36);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date1, timeZone36);
        java.util.Calendar calendar41 = null;
        try {
            long long42 = week40.getFirstMillisecond(calendar41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test171");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        int int3 = week0.getWeek();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.util.Date date4 = week3.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4, timeZone6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date1, timeZone6);
//        org.jfree.data.time.Year year9 = week8.getYear();
//        long long10 = week8.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        java.util.Date date5 = week4.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        boolean boolean8 = week6.equals((java.lang.Object) (short) 10);
        java.util.Date date9 = week6.getStart();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        java.util.Date date13 = week12.getEnd();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date13);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date13, timeZone16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone16);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date9, timeZone16);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date2, timeZone16);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date2);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone22);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
        java.util.Date date25 = week24.getEnd();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date25);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
        java.util.Date date28 = week27.getEnd();
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date28);
        boolean boolean31 = week29.equals((java.lang.Object) (short) 10);
        java.util.Date date32 = week29.getStart();
        java.lang.Class class33 = null;
        java.util.Date date34 = null;
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
        java.util.Date date36 = week35.getEnd();
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date36);
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date36);
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date36, timeZone39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date34, timeZone39);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date32, timeZone39);
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date25, timeZone39);
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date25);
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week();
        java.util.Date date46 = week45.getEnd();
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date46);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
        java.util.Date date49 = week48.getEnd();
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date49);
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week();
        java.util.Date date52 = week51.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = week51.next();
        int int54 = week51.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = week51.previous();
        java.lang.Class<?> wildcardClass56 = regularTimePeriod55.getClass();
        java.lang.Class class57 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass56);
        boolean boolean58 = week50.equals((java.lang.Object) class57);
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week();
        java.util.Date date60 = week59.getEnd();
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date60);
        boolean boolean63 = week61.equals((java.lang.Object) (short) 10);
        java.util.Date date64 = week61.getStart();
        java.lang.Class class65 = null;
        java.util.Date date66 = null;
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week();
        java.util.Date date68 = week67.getEnd();
        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date68);
        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week(date68);
        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date68, timeZone71);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance(class65, date66, timeZone71);
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date64, timeZone71);
        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week();
        java.util.Date date76 = week75.getEnd();
        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date76);
        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week();
        java.util.Date date79 = week78.getEnd();
        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(date79);
        java.util.TimeZone timeZone81 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week(date79, timeZone81);
        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week(date76, timeZone81);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date64, timeZone81);
        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week(date46, timeZone81);
        org.jfree.data.time.Week week86 = new org.jfree.data.time.Week(date25, timeZone81);
        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week(date2, timeZone81);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2019 + "'", int54 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertNotNull(class57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(timeZone71);
        org.junit.Assert.assertNull(regularTimePeriod73);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertNotNull(timeZone81);
        org.junit.Assert.assertNotNull(regularTimePeriod84);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.lang.String str2 = week0.toString();
//        long long3 = week0.getLastMillisecond();
//        long long4 = week0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getEnd();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date12);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getEnd();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date15, timeZone17);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date12, timeZone17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date7, timeZone17);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        java.util.Date date22 = week21.getEnd();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date22);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        java.util.Date date25 = week24.getEnd();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date25);
//        boolean boolean28 = week26.equals((java.lang.Object) (short) 10);
//        java.util.Date date29 = week26.getStart();
//        java.lang.Class class30 = null;
//        java.util.Date date31 = null;
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        java.util.Date date33 = week32.getEnd();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date33);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date33);
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date33, timeZone36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone36);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date29, timeZone36);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date22, timeZone36);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date7, timeZone36);
//        java.lang.String str42 = week41.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Week 24, 2019" + "'", str42.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test175");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.lang.String str2 = week0.toString();
//        long long3 = week0.getLastMillisecond();
//        long long4 = week0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(1, 8);
//        java.lang.String str9 = week8.toString();
//        try {
//            int int10 = week0.compareTo((java.lang.Object) week8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (8) outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 1, 8" + "'", str9.equals("Week 1, 8"));
//    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test176");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.util.Date date4 = week3.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        boolean boolean7 = week5.equals((java.lang.Object) (short) 10);
//        java.util.Date date8 = week5.getStart();
//        java.lang.Class class9 = null;
//        java.util.Date date10 = null;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getEnd();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date12);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date12);
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date12, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date8, timeZone15);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date1, timeZone15);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        java.util.Date date21 = week20.getEnd();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date21);
//        long long24 = week23.getLastMillisecond();
//        java.util.Date date25 = week23.getStart();
//        int int26 = week19.compareTo((java.lang.Object) week23);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        java.util.Date date28 = week27.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week27.next();
//        long long30 = week27.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week27.previous();
//        boolean boolean32 = week19.equals((java.lang.Object) regularTimePeriod31);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560668399999L + "'", long24 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 107031L + "'", long30 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        int int4 = week0.compareTo((java.lang.Object) false);
//        long long5 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', (int) (short) 10);
        java.lang.String str3 = week2.toString();
        int int4 = week2.getYearValue();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        java.util.Date date6 = week5.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week5.next();
        int int8 = week5.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week5.previous();
        java.lang.Class<?> wildcardClass10 = regularTimePeriod9.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        java.util.Date date13 = week12.getEnd();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone15);
        boolean boolean17 = week2.equals((java.lang.Object) class11);
        long long18 = week2.getFirstMillisecond();
        int int19 = week2.getWeek();
        java.util.Date date20 = week2.getStart();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 97, 10" + "'", str3.equals("Week 97, 10"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-61793942400000L) + "'", long18 == (-61793942400000L));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 97 + "'", int19 == 97);
        org.junit.Assert.assertNotNull(date20);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2, timeZone4);
        org.jfree.data.time.Year year6 = week5.getYear();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 0, year6);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
        java.util.Date date9 = week8.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
        java.util.Date date12 = week11.getEnd();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date12);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date12, timeZone14);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date9, timeZone14);
        org.jfree.data.time.Year year17 = week16.getYear();
        java.util.Date date18 = year17.getEnd();
        boolean boolean19 = week7.equals((java.lang.Object) year17);
        org.jfree.data.time.Year year20 = week7.getYear();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(year20);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test180");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date1);
//        long long4 = week3.getLastMillisecond();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week5.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.previous();
//        boolean boolean9 = week3.equals((java.lang.Object) regularTimePeriod8);
//        java.lang.Object obj10 = null;
//        int int11 = week3.compareTo(obj10);
//        int int12 = week3.getYearValue();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', (int) (short) 10);
        java.lang.String str3 = week2.toString();
        int int4 = week2.getYearValue();
        int int5 = week2.getWeek();
        boolean boolean7 = week2.equals((java.lang.Object) "Week 97, 10");
        long long8 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 97, 10" + "'", str3.equals("Week 97, 10"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 627L + "'", long8 == 627L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 97, 10");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 97, 10" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 97, 10"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 97, 10" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: Week 97, 10"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        java.util.Date date4 = week3.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        java.util.Date date7 = week6.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        int int9 = week6.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week6.previous();
        java.lang.Class<?> wildcardClass11 = regularTimePeriod10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        boolean boolean13 = week5.equals((java.lang.Object) class12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
        java.util.Date date15 = week14.getEnd();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
        boolean boolean18 = week16.equals((java.lang.Object) (short) 10);
        java.util.Date date19 = week16.getStart();
        java.lang.Class class20 = null;
        java.util.Date date21 = null;
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
        java.util.Date date23 = week22.getEnd();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date23);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date23);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date23, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone26);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date19, timeZone26);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
        java.util.Date date31 = week30.getEnd();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date31);
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
        java.util.Date date34 = week33.getEnd();
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date34);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date34, timeZone36);
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date31, timeZone36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date19, timeZone36);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date1, timeZone36);
        org.jfree.data.time.Year year41 = week40.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(year41);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        java.util.Date date5 = week4.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date2, timeZone7);
        org.jfree.data.time.Year year10 = week9.getYear();
        org.jfree.data.time.Year year11 = week9.getYear();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) (byte) 0, year11);
        long long13 = week12.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546156799999L + "'", long13 == 1546156799999L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', (int) (short) 10);
        long long3 = week2.getMiddleMillisecond();
        long long4 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61793640000001L) + "'", long3 == (-61793640000001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61793337600001L) + "'", long4 == (-61793337600001L));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3, timeZone5);
        org.jfree.data.time.Year year7 = week6.getYear();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, year7);
        int int9 = week8.getWeek();
        java.util.Date date10 = week8.getEnd();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
        org.jfree.data.time.Year year12 = week11.getYear();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (short) 10, year12);
        java.util.Date date14 = week13.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week13.next();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) '#');
        long long3 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61063344000001L) + "'", long3 == (-61063344000001L));
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) '#');
//        java.util.Date date3 = week2.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.util.Date date5 = week4.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.util.Date date8 = week7.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
//        int int10 = week7.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week7.previous();
//        java.lang.Class<?> wildcardClass12 = regularTimePeriod11.getClass();
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        boolean boolean14 = week6.equals((java.lang.Object) class13);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        java.util.Date date16 = week15.getEnd();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date16);
//        boolean boolean19 = week17.equals((java.lang.Object) (short) 10);
//        java.util.Date date20 = week17.getStart();
//        java.lang.Class class21 = null;
//        java.util.Date date22 = null;
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        java.util.Date date24 = week23.getEnd();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date24);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date24);
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date24, timeZone27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone27);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date20, timeZone27);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        java.util.Date date32 = week31.getEnd();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date32);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        java.util.Date date35 = week34.getEnd();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date35);
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date35, timeZone37);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date32, timeZone37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date20, timeZone37);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        java.util.Date date42 = week41.getEnd();
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date42);
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date42);
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date42, timeZone45);
//        long long47 = week46.getSerialIndex();
//        java.util.Date date48 = week46.getStart();
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week();
//        java.util.Date date50 = week49.getEnd();
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date50);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date50);
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date50, timeZone53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date48, timeZone53);
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week();
//        java.util.Date date57 = week56.getEnd();
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date57);
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date57, timeZone59);
//        org.jfree.data.time.Year year61 = week60.getYear();
//        int int62 = week60.getWeek();
//        org.jfree.data.time.Year year63 = week60.getYear();
//        java.util.Date date64 = week60.getEnd();
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week();
//        java.util.Date date66 = week65.getEnd();
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date66);
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week();
//        java.util.Date date69 = week68.getEnd();
//        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week(date69);
//        boolean boolean72 = week70.equals((java.lang.Object) (short) 10);
//        java.util.Date date73 = week70.getStart();
//        java.lang.Class class74 = null;
//        java.util.Date date75 = null;
//        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week();
//        java.util.Date date77 = week76.getEnd();
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(date77);
//        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week(date77);
//        java.util.TimeZone timeZone80 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week(date77, timeZone80);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance(class74, date75, timeZone80);
//        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week(date73, timeZone80);
//        org.jfree.data.time.Week week84 = new org.jfree.data.time.Week(date66, timeZone80);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date64, timeZone80);
//        org.jfree.data.time.Week week86 = new org.jfree.data.time.Week(date3, timeZone80);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 107031L + "'", long47 == 107031L);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNotNull(year61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 24 + "'", int62 == 24);
//        org.junit.Assert.assertNotNull(year63);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertNotNull(timeZone80);
//        org.junit.Assert.assertNull(regularTimePeriod82);
//        org.junit.Assert.assertNotNull(regularTimePeriod85);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', (int) (short) 10);
        java.lang.String str3 = week2.toString();
        int int4 = week2.getYearValue();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        java.util.Date date6 = week5.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week5.next();
        int int8 = week5.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week5.previous();
        java.lang.Class<?> wildcardClass10 = regularTimePeriod9.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        java.util.Date date13 = week12.getEnd();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone15);
        boolean boolean17 = week2.equals((java.lang.Object) class11);
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
        java.util.Date date21 = week20.getEnd();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date21, timeZone23);
        org.jfree.data.time.Year year25 = week24.getYear();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week((int) (short) 0, year25);
        int int27 = week26.getWeek();
        java.util.Date date28 = week26.getEnd();
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
        java.util.Date date30 = week29.getEnd();
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date30);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
        java.util.Date date33 = week32.getEnd();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date33);
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date33, timeZone35);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date30, timeZone35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date28, timeZone35);
        java.util.Date date39 = regularTimePeriod38.getStart();
        long long40 = regularTimePeriod38.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 97, 10" + "'", str3.equals("Week 97, 10"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(year25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1546156799999L + "'", long40 == 1546156799999L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.String str9 = timePeriodFormatException7.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException7.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray11);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        int int4 = week0.compareTo((java.lang.Object) false);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week5.next();
//        int int8 = week5.getWeek();
//        java.util.Date date9 = week5.getEnd();
//        int int10 = week0.compareTo((java.lang.Object) week5);
//        int int12 = week5.compareTo((java.lang.Object) (byte) -1);
//        int int13 = week5.getYearValue();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.util.Date date4 = week3.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        boolean boolean7 = week5.equals((java.lang.Object) (short) 10);
//        java.util.Date date8 = week5.getStart();
//        java.lang.Class class9 = null;
//        java.util.Date date10 = null;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getEnd();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date12);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date12);
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date12, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date8, timeZone15);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date1, timeZone15);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        java.util.Date date22 = week21.getEnd();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date22);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        java.util.Date date25 = week24.getEnd();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date25);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        java.util.Date date28 = week27.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week27.next();
//        int int30 = week27.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week27.previous();
//        java.lang.Class<?> wildcardClass32 = regularTimePeriod31.getClass();
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
//        boolean boolean34 = week26.equals((java.lang.Object) class33);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        java.util.Date date36 = week35.getEnd();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date36);
//        boolean boolean39 = week37.equals((java.lang.Object) (short) 10);
//        java.util.Date date40 = week37.getStart();
//        java.lang.Class class41 = null;
//        java.util.Date date42 = null;
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week();
//        java.util.Date date44 = week43.getEnd();
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date44);
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date44);
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date44, timeZone47);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date42, timeZone47);
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date40, timeZone47);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week();
//        java.util.Date date52 = week51.getEnd();
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date52);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week();
//        java.util.Date date55 = week54.getEnd();
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date55);
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date55, timeZone57);
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date52, timeZone57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date40, timeZone57);
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date22, timeZone57);
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(date1, timeZone57);
//        java.lang.Class<?> wildcardClass63 = week62.getClass();
//        long long64 = week62.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(wildcardClass63);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560365999999L + "'", long64 == 1560365999999L);
//    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test193");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        long long2 = week0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.String str4 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException6.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException9.getSuppressed();
        java.lang.String str11 = timePeriodFormatException9.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        java.lang.String str6 = timePeriodFormatException4.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException8.getSuppressed();
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException8.getSuppressed();
        java.lang.Throwable throwable13 = null;
        try {
            timePeriodFormatException8.addSuppressed(throwable13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date1);
        java.util.Date date4 = week3.getEnd();
        java.util.Date date5 = week3.getStart();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2, timeZone4);
        org.jfree.data.time.Year year6 = week5.getYear();
        org.jfree.data.time.Year year7 = week5.getYear();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) ' ', year7);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(year7);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date1, timeZone3);
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getLastMillisecond();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray9 = timePeriodFormatException8.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str12 = timePeriodFormatException11.toString();
//        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
//        java.lang.Throwable[] throwableArray14 = timePeriodFormatException11.getSuppressed();
//        int int15 = week4.compareTo((java.lang.Object) throwableArray14);
//        java.util.Calendar calendar16 = null;
//        try {
//            long long17 = week4.getFirstMillisecond(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertNotNull(throwableArray9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(throwableArray14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, 24);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test200");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.util.Date date4 = week3.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4, timeZone6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date1, timeZone6);
//        boolean boolean10 = week8.equals((java.lang.Object) 100);
//        java.util.Date date11 = week8.getStart();
//        long long12 = week8.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week8.next();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560668399999L + "'", long12 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        java.util.Date date5 = week4.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date2, timeZone7);
        org.jfree.data.time.Year year10 = week9.getYear();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', year10);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(year10);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test202");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date1);
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date1, timeZone4);
//        long long6 = week5.getSerialIndex();
//        long long7 = week5.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.util.Date date4 = week3.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4, timeZone6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date1, timeZone6);
//        boolean boolean10 = week8.equals((java.lang.Object) 100);
//        int int11 = week8.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week8.previous();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.lang.String str2 = week0.toString();
//        long long3 = week0.getLastMillisecond();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertNotNull(year4);
//    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test205");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        boolean boolean4 = week2.equals((java.lang.Object) (short) 10);
//        long long5 = week2.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        int int3 = week0.getYearValue();
//        int int4 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        java.util.Date date6 = regularTimePeriod5.getEnd();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.lang.String str2 = week0.toString();
//        long long3 = week0.getLastMillisecond();
//        long long4 = week0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getEnd();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date12);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getEnd();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date15, timeZone17);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date12, timeZone17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date7, timeZone17);
//        java.util.TimeZone timeZone21 = null;
//        java.util.Locale locale22 = null;
//        try {
//            org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date7, timeZone21, locale22);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', (int) (short) 10);
        java.lang.String str3 = week2.toString();
        int int4 = week2.getYearValue();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        java.util.Date date6 = week5.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week5.next();
        int int8 = week5.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week5.previous();
        java.lang.Class<?> wildcardClass10 = regularTimePeriod9.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        java.util.Date date13 = week12.getEnd();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone15);
        boolean boolean17 = week2.equals((java.lang.Object) class11);
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
        java.util.Date date21 = week20.getEnd();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date21, timeZone23);
        org.jfree.data.time.Year year25 = week24.getYear();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week((int) (short) 0, year25);
        int int27 = week26.getWeek();
        java.util.Date date28 = week26.getEnd();
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
        java.util.Date date30 = week29.getEnd();
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date30);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
        java.util.Date date33 = week32.getEnd();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date33);
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date33, timeZone35);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date30, timeZone35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date28, timeZone35);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
        java.util.Date date40 = week39.getEnd();
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date40);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date40);
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date40);
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date40);
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week();
        java.util.Date date46 = week45.getEnd();
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date46);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
        java.util.Date date49 = week48.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = week48.next();
        int int51 = week48.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = week48.previous();
        java.lang.Class<?> wildcardClass53 = regularTimePeriod52.getClass();
        java.lang.Class class54 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass53);
        boolean boolean55 = week47.equals((java.lang.Object) class54);
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week();
        java.util.Date date57 = week56.getEnd();
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date57);
        boolean boolean60 = week58.equals((java.lang.Object) (short) 10);
        java.util.Date date61 = week58.getStart();
        java.lang.Class class62 = null;
        java.util.Date date63 = null;
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week();
        java.util.Date date65 = week64.getEnd();
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date65);
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date65);
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date65, timeZone68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class62, date63, timeZone68);
        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date61, timeZone68);
        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week();
        java.util.Date date73 = week72.getEnd();
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date73);
        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week();
        java.util.Date date76 = week75.getEnd();
        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date76);
        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week(date76, timeZone78);
        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(date73, timeZone78);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance(class54, date61, timeZone78);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date40, timeZone78);
        java.util.Date date83 = regularTimePeriod82.getStart();
        java.util.Date date84 = regularTimePeriod82.getStart();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 97, 10" + "'", str3.equals("Week 97, 10"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(year25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(class54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(timeZone78);
        org.junit.Assert.assertNotNull(regularTimePeriod81);
        org.junit.Assert.assertNotNull(regularTimePeriod82);
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(date84);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', (int) (short) 10);
        java.lang.String str3 = week2.toString();
        int int5 = week2.compareTo((java.lang.Object) (-61793640000001L));
        java.util.Date date6 = week2.getStart();
        int int8 = week2.compareTo((java.lang.Object) 1545552000000L);
        long long9 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 97, 10" + "'", str3.equals("Week 97, 10"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61793640000001L) + "'", long9 == (-61793640000001L));
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.lang.String str2 = week0.toString();
//        long long3 = week0.getLastMillisecond();
//        long long4 = week0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        org.jfree.data.time.Year year6 = week0.getYear();
//        org.jfree.data.time.Year year7 = week0.getYear();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(year7);
//    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.util.Date date4 = week3.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4, timeZone6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date1, timeZone6);
//        boolean boolean10 = week8.equals((java.lang.Object) 100);
//        long long11 = week8.getFirstMillisecond();
//        java.util.Calendar calendar12 = null;
//        try {
//            week8.peg(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560063600000L + "'", long11 == 1560063600000L);
//    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test213");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.util.Date date4 = week3.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        boolean boolean7 = week5.equals((java.lang.Object) (short) 10);
//        java.util.Date date8 = week5.getStart();
//        java.lang.Class class9 = null;
//        java.util.Date date10 = null;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getEnd();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date12);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date12);
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date12, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date8, timeZone15);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date1, timeZone15);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date1);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        java.util.Date date22 = week21.getEnd();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date22);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        java.util.Date date25 = week24.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week24.next();
//        int int27 = week24.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week24.previous();
//        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        boolean boolean31 = week23.equals((java.lang.Object) class30);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        java.util.Date date33 = week32.getEnd();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date33);
//        boolean boolean36 = week34.equals((java.lang.Object) (short) 10);
//        java.util.Date date37 = week34.getStart();
//        java.lang.Class class38 = null;
//        java.util.Date date39 = null;
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
//        java.util.Date date41 = week40.getEnd();
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date41);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date41);
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date41, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date39, timeZone44);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date37, timeZone44);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
//        java.util.Date date49 = week48.getEnd();
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date49);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week();
//        java.util.Date date52 = week51.getEnd();
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date52);
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date52, timeZone54);
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date49, timeZone54);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date37, timeZone54);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week();
//        java.util.Date date59 = week58.getEnd();
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date59);
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date59);
//        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date59, timeZone62);
//        long long64 = week63.getSerialIndex();
//        java.util.Date date65 = week63.getStart();
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week();
//        java.util.Date date67 = week66.getEnd();
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(date67);
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date67);
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date67, timeZone70);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date65, timeZone70);
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date1, timeZone70);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(timeZone62);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 107031L + "'", long64 == 107031L);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//    }
//}

